// Government Dashboard Module for Life Command Center
// Loaded after index.html, has access to global variables and functions

// Module state variables
let govCharts = {};
let researchQueue = [];
let researchIdx = 0;
let researchCompleted = 0;
let researchMode = "pending_updates"; // pipeline order: pending_updates → pipeline_control → ownership → leads → intel → financial_overrides → monitor
let researchFilter = "pending";
let countyCache = {};
let acTimeout = null;
let govEvidenceState = {
  contextKey: '',
  review: null,
  artifactId: null,
  loading: false,
  queue: [],
  queueLoading: false,
  queueLoaded: false,
  queueError: '',
  _toastShown: false,
  healthLoading: false,
  brokerFeedback: null,
  brokerFeedbackLoading: false,
  health: null,
  conflicts: [],
  detectedSource: null
};

// ============================================================================
// DIRTY FORM TRACKING
// ============================================================================

window.addEventListener('beforeunload', function(e) {
  if (!researchQueue || researchQueue.length === 0) return;
  if (researchIdx >= researchQueue.length) return;
  const card = document.querySelector('.research-card');
  if (!card) return;
  const inputs = card.querySelectorAll('input[type="text"], input[type="number"], input[type="date"], textarea, select');
  const hasDirty = Array.from(inputs).some(function(inp) {
    if (inp.tagName === 'SELECT') return inp.selectedIndex > 0;
    return inp.value && inp.value.trim() !== '' && inp.value !== (inp.defaultValue || '');
  });
  if (hasDirty) {
    e.preventDefault();
    e.returnValue = 'You have unsaved research changes.';
  }
});

// State code to full name mapping
const STATE_FULL = {
  'AL': 'Alabama', 'AK': 'Alaska', 'AZ': 'Arizona', 'AR': 'Arkansas',
  'CA': 'California', 'CO': 'Colorado', 'CT': 'Connecticut', 'DE': 'Delaware',
  'FL': 'Florida', 'GA': 'Georgia', 'HI': 'Hawaii', 'ID': 'Idaho',
  'IL': 'Illinois', 'IN': 'Indiana', 'IA': 'Iowa', 'KS': 'Kansas',
  'KY': 'Kentucky', 'LA': 'Louisiana', 'ME': 'Maine', 'MD': 'Maryland',
  'MA': 'Massachusetts', 'MI': 'Michigan', 'MN': 'Minnesota', 'MS': 'Mississippi',
  'MO': 'Missouri', 'MT': 'Montana', 'NE': 'Nebraska', 'NV': 'Nevada',
  'NH': 'New Hampshire', 'NJ': 'New Jersey', 'NM': 'New Mexico', 'NY': 'New York',
  'NC': 'North Carolina', 'ND': 'North Dakota', 'OH': 'Ohio', 'OK': 'Oklahoma',
  'OR': 'Oregon', 'PA': 'Pennsylvania', 'RI': 'Rhode Island', 'SC': 'South Carolina',
  'SD': 'South Dakota', 'TN': 'Tennessee', 'TX': 'Texas', 'UT': 'Utah',
  'VT': 'Vermont', 'VA': 'Virginia', 'WA': 'Washington', 'WV': 'West Virginia',
  'WI': 'Wisconsin', 'WY': 'Wyoming', 'DC': 'District of Columbia'
};

// ============================================================================
// HELPER FUNCTIONS FOR SAFE NUMERIC PARSING
// ============================================================================

// Parse float from string or element value, handling zero correctly
function _pf(el) { const v = (typeof el === 'string' ? el : el?.value)?.trim(); return v ? parseFloat(v) : null; }

// Parse int from string or element value, handling zero correctly
function _pi(el) { const v = (typeof el === 'string' ? el : el?.value)?.trim(); return v ? parseInt(v, 10) : null; }

// Parse a 4-digit year (year_built / year_renovated). Returns null for
// blank/non-numeric/zero/out-of-range so we never persist year_built = 0 and
// never trip the DB CHECK constraint (1600-2100) added in
// sql/20260415_properties_year_built_null_zero.sql. Mirrors parseYearSafe()
// in api/_handlers/sidebar-pipeline.js. Accepts an element, a string, or a
// raw scalar — so both `_py(q('#id'))` and `_py(_d['key'])` work.
function _py(src) {
  const raw = (src && typeof src === 'object' && 'value' in src) ? src.value : src;
  if (raw == null) return null;
  const str = String(raw).trim();
  if (!str) return null;
  const num = parseInt(str, 10);
  if (isNaN(num) || num <= 0) return null;
  if (num < 1600 || num > 2100) return null;
  return num;
}

// ============================================================================
// CORE API FUNCTION
// ============================================================================

async function govQuery(table, select, params = {}) {
  // Query via serverless proxy — keeps secret key server-side
  const url = new URL('/api/gov-query', window.location.origin);
  url.searchParams.set('table', table);
  url.searchParams.set('select', select);
  if (params.filter) url.searchParams.set('filter', params.filter);
  // Gov-query proxy supports a second column filter; mirror diaQuery so
  // callers can pass an extra condition (e.g. exclude_from_market_metrics)
  // without bypassing the proxy.
  if (params.filter2) url.searchParams.set('filter2', params.filter2);
  if (params.order) url.searchParams.set('order', params.order);
  if (params.limit !== undefined) url.searchParams.set('limit', params.limit);
  if (params.offset !== undefined) url.searchParams.set('offset', params.offset);
  if (params.count === false) url.searchParams.set('count', 'false');

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000);
  try {
    const response = await fetch(url.toString(), { signal: controller.signal });
    clearTimeout(timeout);

    if (!response.ok) {
      const errBody = await response.text();
      console.error(`govQuery ${table}: HTTP ${response.status}`, errBody);
      return { data: [], count: 0 };
    }

    const result = await response.json();
    return { data: result.data || [], count: result.count || 0 };
  } catch (err) {
    clearTimeout(timeout);
    if (err.name === 'AbortError') { console.warn('govQuery ' + table + ' timed out (30s)'); return { data: [], count: 0 }; }
    console.error('govQuery error:', err);
    return { data: [], count: 0 };
  }
}
// Tier-4 Unit 1: expose the REAL govQuery on window (mirrors dialysis.js's
// `window.diaQuery = diaQuery`). app.js declares a no-op `function govQuery`
// stub; without this rebind, any surface that calls the global `govQuery`
// (e.g. ops.js renderDomainHealthSummary) can resolve to the stub and render
// blank when a stale-cached gov.js is served. Binding here guarantees the real
// proxy-backed reader wins regardless of script load/cache order.
window.govQuery = govQuery;

// Gov write service — routes through /api/gov-write
// (R5-FE-1, 2026-05-20: was /api/data-proxy?_route=gov-write — data-proxy was
// absorbed into admin.js and has no rewrite/file, so that route 404'd. The live
// route is /api/gov-write, which vercel.json rewrites to
// /api/admin?_route=edge-data&_edgeRoute=gov-write.)
// Endpoints: 'ownership', 'lead-research', 'financial', 'resolve-pending'
async function govWriteService(endpoint, data) {
  const url = new URL('/api/gov-write', window.location.origin);
  url.searchParams.set('endpoint', endpoint);

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000);
  try {
    const resp = await fetch(url.toString(), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
      signal: controller.signal
    });
    clearTimeout(timeout);

    if (!resp.ok) {
      const errBody = await resp.json().catch(() => ({ error: 'Unknown error' }));
      throw new Error(errBody.error || errBody.detail || 'Gov write service returned ' + resp.status);
    }

    return await resp.json();
  } catch (err) {
    clearTimeout(timeout);
    if (err.name === 'AbortError') throw new Error('Request timed out (30s) — please retry');
    throw err;
  }
}

// Paginated fetch — loops with offset to get ALL rows past PostgREST 1000-row cap
async function govQueryAll(table, select, params = {}) {
  // QA-33 (2026-05-18): reverted to serial pagination. QA-26's parallel fix
  // caused 194-second full loads and unresponsive browser because ~60
  // concurrent HTTP requests overwhelm Vercel/Supabase/browser. Going back
  // to one-at-a-time pagination — slower but predictable. A throttled-
  // parallel approach (concurrency=4) is the better long-term fix; deferred.
  let all = [], offset = 0;
  const pageSize = 1000;  // PostgREST max-rows cap
  const maxTime = 120000; // 2-minute total timeout
  const start = Date.now();
  while (true) {
    if (Date.now() - start > maxTime) {
      console.warn('govQueryAll(' + table + ') total timeout after ' + Math.round((Date.now() - start) / 1000) + 's — returning ' + all.length + ' rows');
      break;
    }
    const result = await govQuery(table, select, { ...params, limit: pageSize, offset, count: false });
    all = all.concat(result.data || []);
    if ((result.data || []).length < pageSize) break;
    offset += pageSize;
  }
  return { data: all, count: all.length };
}

// ============================================================================
// QA-28 (2026-05-18): private "Federal" name detector
// ============================================================================
// ~826 properties had agency values like "Campco Federal Credit Union",
// "10 Federal Self Storage", "First Federal Lakewood" etc. These are
// private businesses with "Federal" in the name, not federal tenants.
// The canonicalize_agency() SQL function correctly returns NULL for them
// (no federal match), but the Agency Breakdown chart's fallback to raw
// .agency would surface them at the bottom of the chart. This helper
// classifies them so the chart can roll them into "Unknown" instead.
//
// Patterns covered (case-insensitive):
//   - federal credit union (162+130+125+114+1+1 = 533 props)
//   - federal self storage / "<n> federal self storage" (154+1 props)
//   - federal savings, federal bank
//   - first federal <bank-name> (141 props)
//   - "federal way" (city name in WA, not federal)
// ============================================================================
function _govIsPrivateFederalNamedEntity(name) {
  if (!name) return false;
  const s = String(name).toLowerCase();
  if (/federal\s+credit\s+union/.test(s)) return true;
  if (/federal\s+savings/.test(s)) return true;
  if (/federal\s+bank\b/.test(s)) return true;
  if (/^first\s+federal\b/.test(s)) return true;
  if (/\bself[\s-]?storage\b/.test(s)) return true;
  if (/^\d+\s+federal\b/.test(s)) return true;
  if (/^federal\s+way\b/.test(s)) return true;
  return false;
}
if (typeof window !== 'undefined') window._govIsPrivateFederalNamedEntity = _govIsPrivateFederalNamedEntity;

// ============================================================================
// METRIC CARD HTML
// ============================================================================

function metricHTML(label, value, sub, color, extraAttrs) {
  const colorMap = {
    'blue': '#6c8cff',
    'green': '#34d399',
    'yellow': '#fbbf24',
    'red': '#f87171',
    'purple': '#a78bfa',
    'cyan': '#22d3ee'
  };

  const bgColor = colorMap[color] || '#6c8cff';

  return `
    <div class="metric-card" ${extraAttrs || ''}>
      <div class="metric-label">${label}</div>
      <div class="metric-value" style="color: ${bgColor};">${value}</div>
      ${sub ? `<div class="metric-sub">${sub}</div>` : ''}
    </div>
  `;
}

// ============================================================================
// DATA LOADING
// ============================================================================

// Fast-path: load pre-computed overview stats from materialized view (~100ms)
// This renders the overview immediately while the full 20s data load runs in background
let govOverviewStats = null;
let govOverviewStatsLoading = false;

async function loadGovOverviewStats() {
  if (govOverviewStats || govOverviewStatsLoading) return;
  govOverviewStatsLoading = true;
  try {
    const res = await govQuery('mv_gov_overview_stats', '*', { limit: 1 });
    const rows = res.data || [];
    if (rows.length > 0) {
      govOverviewStats = rows[0];
      console.debug('[Gov] Overview stats loaded from materialized view:', govOverviewStats);
      // If we're on the overview tab, render immediately
      if (typeof currentBizTab !== 'undefined' && currentBizTab === 'government' && currentGovTab === 'overview') {
        renderGovTab();
      }
    }
  } catch (e) {
    console.warn('[Gov] mv_gov_overview_stats not available, will use full data load:', e.message);
  }
  govOverviewStatsLoading = false;
}

let _govDataLoading = false;

// Helper function to paginate a query until all rows are fetched
// Paginated fetch — loops with offset to get ALL rows past PostgREST 1000-row cap.
// pageSize MUST be ≤ Supabase's max_rows (1000) — passing a larger value caused
// every batch to come back with len < pageSize on the first call, exiting the
// loop after a single page and silently truncating the result. Round 76el.
async function _loadPaginatedQuery(table, columns, options = {}, pageSize = 1000) {
  // QA-33 (2026-05-18): reverted to serial pagination. See govQueryAll comment.
  let all = [], offset = 0;
  while (true) {
    const batch = await govQuery(table, columns, { ...options, limit: pageSize, offset, count: false });
    all = all.concat(batch.data || []);
    if (!batch.data || batch.data.length < pageSize) break;
    offset += pageSize;
  }
  return all;
}

async function loadGovData() {
  if (_govDataLoading) return;  // Prevent concurrent loads
  _govDataLoading = true;

  // Kick off fast overview stats immediately (non-blocking)
  if (!govOverviewStats && !govOverviewStatsLoading) {
    loadGovOverviewStats();
  }

  // Show loading indicator (only if overview stats haven't rendered yet)
  var inner = document.getElementById('bizPageInner');
  if (inner && !govOverviewStats) {
    inner.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading government data...</p></div>';
  }

  govData.properties = [];
  govData.portfolioProperties = [];
  govData.salesComps = [];
  govData.leads = [];
  govData.contacts = [];
  govData.listings = [];
  govData.ownership = [];
  govData.gsaEvents = [];
  govData.gsaSnapshots = [];
  govData.frppRecords = [];
  govData.countyAuth = [];
  govData.loans = [];
  // R4-C §5 loading honesty: distinguish "Phase-2 data not loaded yet" from a
  // genuine zero so the overview can skeleton instead of painting literal 0s.
  govData._phase2Loaded = false;
  govData.researchOutcomes = [];

  showToast('Loading government data...', 'info');
  var _govLoadStart = Date.now();

  try {
    // ── PHASE 1: Critical data for overview + research ────────────────
    // Loads leads, portfolio properties, property count, listings first
    // so the dashboard renders quickly (~3-5s) before heavier tables arrive
    // Resilient load (2026-07-14): Promise.allSettled so ONE transient failure
    // (a cold-start 503, or a canonical view still 403'd behind the edge-
    // allowlist redeploy) can't reject the whole batch and strand every tile +
    // leave the "Loading detailed data…" banner spinning forever. Each result
    // is extracted defensively; every downstream tile already has a null/empty
    // fallback, so the queries that succeed still land.
    var _govSettled = await Promise.allSettled([
      // PERF (2026-05-31): was govQueryAll (unbounded serial pagination of all
      // ~11.5k leads -> the 14.6s Gov-tab freeze). The leads array is a
      // prioritized WORKING SET (pipeline already caps at 1,000 via atCap), not
      // the authoritative total. Load the top-1,000 by priority_score in ONE
      // bounded call; the same call returns the exact DB count for true totals.
      govQuery('prospect_leads',
        'lead_id, lease_number, location_code, address, city, state, lessor_name, annual_rent, estimated_value, square_feet, year_built, agency_full_name, tenant_agency, lease_effective, lease_expiration, firm_term_remaining, priority_score, lead_temperature, lead_source, pipeline_status, research_status, contact_name, contact_phone, contact_email, contact_company, contact_title, recorded_owner, true_owner, owner_type, research_notes, matched_property_id, matched_contact_id, sf_lead_id, sf_contact_id, sf_opportunity_id, sf_sync_status, state_of_incorporation, phone_2, mailing_address, mailing_address_2, principal_names, rba, land_acres, year_renovated',
        { order: 'priority_score.desc', limit: 1000 }
      ),
      _loadPaginatedQuery('properties',
        // Identifier + research handles + financials + intel signals.
        // Intel card needs all of these; the auto-resolve sweep keys on
        // intel_status + the no-handle bucket. Round 76em.
        'property_id,lease_number,location_code,address,city,state,zip_code,' +
        'agency,agency_canonical,agency_full_name,government_type,' +
        'rba,sf_leased,year_built,year_renovated,land_acres,' +
        'lease_commencement,lease_expiration,firm_term_remaining,term_remaining,firm_term_years,total_term_years,' +
        'gross_rent,gross_rent_psf,noi,noi_psf,estimated_value,' +
        'recorded_owner_id,true_owner_id,assessed_owner,latest_deed_grantee,latest_deed_date,latest_sale_price,' +
        'investment_score,deal_grade,agency_risk_level,location_tier,' +
        'intel_status,status,data_source',
        // Value-weighted sort (Item #9 Phase A, 2026-05-17): most valuable
        // gov holdings surface first. Falls back through gross_rent, then
        // RBA so properties missing a value still rank by rent/size.
        { order: 'estimated_value.desc.nullslast,gross_rent.desc.nullslast,rba.desc.nullslast' }
      ),
      govQuery('properties', 'property_id', { limit: 0 }),
      govQueryAll('available_listings',
        // Embed the matched property row via FK so the UI can show
        // year_built / land_acres / assessed_owner without a second
        // round-trip. PostgREST resource-embed syntax (properties is
        // the FK target of available_listings.property_id).
        'listing_id, property_id, address, city, state, asking_price, asking_cap_rate, ' +
        'listing_source, listing_status, url_status, days_on_market, tenant_agency, ' +
        'first_seen_at, listing_date, listing_broker, listing_firm, annual_rent, lease_expiration, ' +
        'square_feet, intake_artifact_path, intake_artifact_type, source_url, tracked_urls, ' +
        'property:properties(year_built,land_acres,rba,assessed_owner,recorded_owner_id,true_owner_id)',
        // Sort by most-recently-ingested first so freshly staged OMs
        // (asking_price=NULL government build-to-suits, etc.) surface
        // at the top of the display instead of getting buried 250+ rows
        // deep. `listing_date.desc` is a coarse date column; we fall back
        // to `asking_price.desc` as a tiebreaker for rows with the same
        // date so the classic "biggest deals first" view still holds
        // within a given day.
        { order: 'listing_date.desc.nullslast,asking_price.desc.nullslast' }
      ),
      // Canonical CURRENT on-market set — the ONE source of "currently on market"
      // (v_gov_on_market: active + no exit + recent-24mo). Both the Overview
      // On-Market tile and the Listings tab filter govData.listings by this
      // listing_id membership, so neither computes its own filter and both
      // reconcile with the CM available count. Light (~278 rows).
      govQuery('v_gov_on_market', 'listing_id', { limit: 1000 }),
      // ── Data-Health tiles: read the ONE canonical view per metric on the
      // Overview load (mirrors dia), so they render SYNCHRONOUSLY and the
      // re-render can't strand them on "loading…". All small (aggregated / a
      // bounded page — gov listings-confirm ~67, prospect top-250).
      govQuery('v_ownership_coverage', '*', { limit: 1 }),
      govQuery('v_llc_research_queue_health', '*', { limit: 50 }),
      govQuery('v_listings_needing_manual_confirmation', '*', { limit: 1000 }),
      govQuery('v_prospect_targets', 'true_owner_id,name,prop_count,state,entity_type', { order: 'prop_count.desc.nullslast', limit: 250 })
    ]);
    // Extract each result defensively — a rejected query becomes null and the
    // tile it feeds falls back to its own empty/error state (never a page-wide
    // strand). NOTE: portfolioPropsRes comes from _loadPaginatedQuery (returns
    // an array, not a {data} envelope), so it's null-on-failure directly.
    var _gv = function (i) { return _govSettled[i].status === 'fulfilled' ? _govSettled[i].value : null; };
    var leadsRes = _gv(0), portfolioPropsRes = _gv(1), propsCountRes = _gv(2),
        listingsRes = _gv(3), onMarketRes = _gv(4), govOwnershipCovRes = _gv(5),
        govLlcHealthRes = _gv(6), govListingConfirmRes = _gv(7), govProspectRes = _gv(8);
    var _govFailedCount = _govSettled.filter(function (r) { return r.status === 'rejected'; }).length;
    if (_govFailedCount > 0) {
      console.warn('[gov] ' + _govFailedCount + ' of ' + _govSettled.length + ' overview queries failed (transient); rendering with the ones that succeeded');
    }

    govData.leads = (leadsRes && leadsRes.data) || [];
    // True DB total (exact count from the bounded query above) — distinct from
    // the loaded working-set length. Used where the real total must be shown.
    govData.leadsTotal = (leadsRes && typeof leadsRes.count === 'number' && leadsRes.count > 0) ? leadsRes.count : govData.leads.length;
    govData.portfolioProperties = portfolioPropsRes || [];
    govData.properties = [{ count: (propsCountRes && propsCountRes.count) || 0 }];
    govData.listings = (listingsRes && listingsRes.data) || [];
    // Set of listing_ids that are CURRENTLY on market per the canonical view.
    // null (query failed) → surfaces fall back to lccIsListingActive so the
    // tile never blanks. Empty Set is a legit "0 on market" (honest), distinct
    // from null.
    govData.onMarketIds = (onMarketRes && Array.isArray(onMarketRes.data))
      ? new Set(onMarketRes.data.map(r => r.listing_id))
      : null;

    // ── Canonical Data-Health tile sources (rendered synchronously) ──
    // Ownership Coverage — the ONE single-row summary view.
    window._govOwnershipCoverage = (govOwnershipCovRes && govOwnershipCovRes.data && govOwnershipCovRes.data[0]) || null;
    window._govOwnershipCoverageLoadedFlag = true;
    // LLC Research Queue counts — status → row_count from the ONE health view.
    (function() {
      var byStatus = {}, total = 0;
      ((govLlcHealthRes && govLlcHealthRes.data) || []).forEach(function(r) {
        byStatus[r.status] = Number(r.row_count) || 0; total += Number(r.row_count) || 0;
      });
      window._govLlcPending = byStatus.deferred || 0;
      window._govLlcDone = byStatus.done || 0;
      window._govLlcTotalRows = total;
      window._govLlcHealthLoaded = true;
    })();
    // Listings Needing Confirmation — the bounded row set (drives counts + list).
    window._govLcConfirmRows = (govListingConfirmRes && govListingConfirmRes.data) || [];
    window._govListingConfirmDataLoaded = true;
    // Unprospected Owners — count + the modal top-list.
    (function() {
      var pt = (govProspectRes && govProspectRes.data) || [];
      window._govTopUnprospected = pt;
      window._govUnprospectedTotal = (govProspectRes && typeof govProspectRes.count === 'number' && govProspectRes.count > 0)
        ? govProspectRes.count : pt.length;
    })();

    // Mark connected so dashboard renders immediately with Phase 1 data
    govConnected = true;
    govDataLoaded = true;
    _govDataLoading = false;

    var _p1Sec = ((Date.now() - _govLoadStart) / 1000).toFixed(1);
    showToast('Gov: ' + govData.leadsTotal.toLocaleString() + ' leads' + (govData.leads.length < govData.leadsTotal ? ' (top ' + govData.leads.length.toLocaleString() + ' loaded)' : '') + ', ' + govData.portfolioProperties.length + ' properties (' + _p1Sec + 's)', 'success');
    if (typeof currentBizTab !== 'undefined' && currentBizTab === 'government') renderGovTab();

    // ── PHASE 2: Background load — remaining tables ───────────────────
    _loadGovPhase2(_govLoadStart);

  } catch (err) {
    console.error('Error loading government data:', err);
    govConnected = false;
    _govDataLoading = false;
    showToast('Error loading data', 'error');
    inner = document.getElementById('bizPageInner');
    if (inner) {
      inner.innerHTML = '<div style="text-align:center;padding:32px;color:var(--red)"><p style="font-size:16px;margin-bottom:8px">Failed to load government data</p><p style="color:var(--text2);font-size:13px">' + esc(err.message || 'Unknown error') + '</p><button class="gov-btn" onclick="this.disabled=true;this.textContent=\'Loading\u2026\';loadGovData()" style="margin-top:12px">Retry</button></div>';
    }
  }
}

// Phase 2: Background load of secondary gov tables
// Runs non-blocking after Phase 1 renders the dashboard
async function _loadGovPhase2(startTime) {
  try {
    var [ownershipRes, contactsRes, gsaEventsRes, researchOutcomesRes,
         gsaSnapshotsRes, frppRes, loansRes, countyAuthRes, salesCompsRes
    ] = await Promise.all([
      govQueryAll('ownership_history',
        'ownership_id, lease_number, address, city, state, prior_owner, new_owner, transfer_date, square_feet, annual_rent, estimated_value, sale_price, cap_rate, research_status, recorded_owner_name, true_owner_name, principal_names, state_of_incorporation',
        { order: 'estimated_value.desc' }
      ),
      govQueryAll('contacts',
        'contact_id, name, contact_type, total_volume, phone, email',
        {}
      ),
      govQuery('gsa_lease_events',
        'lease_number, location_code, event_type, event_date, annual_rent, lease_rsf, lessor_name, changed_fields',
        { order: 'event_date.desc', limit: 500, count: false }
      ),
      govQuery('research_queue_outcomes',
        'queue_type, status, notes, assigned_at, created_at, assigned_to, selected_property_id, clinic_id',
        { order: 'assigned_at.desc', limit: 500, count: false }
      ),
      govQuery('gsa_snapshots',
        'snapshot_date, lease_number, address, city, state, lease_rsf, annual_rent, lessor_name, lease_effective, lease_expiration, field_office_name',
        { order: 'snapshot_date.desc', limit: 500, count: false }
      ),
      govQuery('frpp_records',
        'using_agency, using_bureau, street_address, city_name, state_name, square_feet, annual_rent_to_lessor, lease_expiration_date, property_type',
        { limit: 5000, count: false }
      ),
      govQuery('loans',
        'property_id, index_name, loan_amount, loan_type, status',
        { limit: 500, count: false }
      ),
      _loadPaginatedQuery('county_authorities',
        'county_name, state_code, netronline_url, assessor_url, recorder_url, treasurer_url, tax_url, gis_url, clerk_url, other_urls'
      ),
      _loadPaginatedQuery('sales_transactions',
        '*',
        // Value-weighted sort (Item #9 Phase A, 2026-05-17): biggest comps
        // surface first. Tiebreaker on sale_date keeps recency where prices
        // are equal/null.
        { order: 'sold_price.desc.nullslast,sale_date.desc.nullslast' }
      )
    ]);

    govData.ownership = ownershipRes.data || [];
    govData.contacts = contactsRes.data || [];
    govData.gsaEvents = gsaEventsRes.data || [];
    govData.researchOutcomes = researchOutcomesRes.data || [];
    govData.gsaSnapshots = gsaSnapshotsRes.data || [];
    govData.frppRecords = frppRes.data || [];
    govData.frppCount = frppRes.count || govData.frppRecords.length;
    govData.loans = loansRes.data || [];
    govData.countyAuth = countyAuthRes || [];
    govData.salesComps = salesCompsRes || [];
    govData._phase2Loaded = true;  // R4-C §5: Phase-2 arrays are now real

    var _totalSec = ((Date.now() - startTime) / 1000).toFixed(1);
    console.debug('GOV PHASE 2 LOADED (' + _totalSec + 's total):', {
      ownership: govData.ownership.length,
      contacts: govData.contacts.length,
      gsaEvents: govData.gsaEvents.length,
      gsaSnapshots: govData.gsaSnapshots.length,
      frpp: govData.frppRecords.length,
      county: govData.countyAuth.length,
      salesComps: govData.salesComps.length,
      loans: govData.loans.length
    });
    showToast('Gov background data loaded (' + _totalSec + 's total)', 'info');
    // Re-render if user is still on gov tab so new data appears
    if (typeof currentBizTab !== 'undefined' && currentBizTab === 'government') renderGovTab();

  } catch (err) {
    console.error('Gov Phase 2 error (non-fatal):', err);
    showToast('Some gov data failed to load — try refreshing', 'warning');
  }
}

// ============================================================================
// CHART HELPERS
// ============================================================================

function destroyChart(id) {
  if (govCharts[id]) {
    govCharts[id].destroy();
    delete govCharts[id];
  }
}

function renderBarChart(id, labels, datasets, isMoney) {
  destroyChart(id);
  
  const canvas = document.getElementById(id);
  if (!canvas) return;
  
  const ctx = canvas.getContext('2d');
  
  govCharts[id] = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: datasets.map((ds, i) => ({
        label: ds.label,
        data: ds.data,
        backgroundColor: ['#6c8cff', '#34d399', '#fbbf24', '#f87171', '#a78bfa', '#22d3ee'][i % 6],
        borderColor: 'transparent',
        borderRadius: 4
      }))
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      indexAxis: 'x',
      plugins: {
        legend: {
          display: datasets.length > 1,
          labels: {
            color: '#9498a8',
            font: { size: 12 }
          }
        },
        tooltip: {
          backgroundColor: '#1f2937',
          titleColor: '#fff',
          bodyColor: '#fff',
          callbacks: {
            label: function(context) {
              let val = context.parsed.y || 0;
              if (isMoney) val = fmt(val);
              return context.dataset.label + ': ' + val;
            }
          }
        }
      },
      scales: {
        x: {
          ticks: { color: '#9498a8', font: { size: 11 } },
          grid: { color: '#2e3345' }
        },
        y: {
          ticks: {
            color: '#9498a8',
            font: { size: 11 },
            callback: function(val) {
              if (isMoney) return fmt(val);
              return fmtN(val);
            }
          },
          grid: { color: '#2e3345' }
        }
      }
    }
  });
}

function renderPieChart(id, labels, data) {
  destroyChart(id);
  
  const canvas = document.getElementById(id);
  if (!canvas) return;
  
  const ctx = canvas.getContext('2d');
  
  const colors = ['#6c8cff', '#34d399', '#fbbf24', '#f87171', '#a78bfa', '#22d3ee', '#06b6d4', '#8b5cf6'];
  
  govCharts[id] = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: labels,
      datasets: [{
        data: data,
        backgroundColor: colors.slice(0, data.length),
        borderColor: '#0f172a',
        borderWidth: 2
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            color: '#9498a8',
            font: { size: 12 },
            padding: 15
          }
        },
        tooltip: {
          backgroundColor: '#1f2937',
          titleColor: '#fff',
          bodyColor: '#fff'
        }
      }
    }
  });
}

function renderHBarChart(id, labels, data, colors) {
  destroyChart(id);
  
  const canvas = document.getElementById(id);
  if (!canvas) return;
  
  const ctx = canvas.getContext('2d');
  
  if (!colors) {
    colors = labels.map(() => '#6c8cff');
  }
  
  govCharts[id] = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        data: data,
        backgroundColor: colors,
        borderColor: 'transparent',
        borderRadius: 4
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#1f2937',
          titleColor: '#fff',
          bodyColor: '#fff'
        }
      },
      scales: {
        x: {
          ticks: { color: '#9498a8', font: { size: 11 } },
          grid: { color: '#2e3345' }
        },
        y: {
          ticks: { color: '#9498a8', font: { size: 11 } },
          grid: { display: false }
        }
      }
    }
  });
}

function renderGovCharts() {
  // Charts will be rendered by individual tab functions
}

// ============================================================================
// TABLE RENDERING
// ============================================================================

function ownershipTable(rows) {
  if (!rows || rows.length === 0) {
    return '<div class="table-empty">No ownership changes yet</div>';
  }
  
  let html = '<div class="table-wrapper"><table class="data-table"><thead><tr>';
  html += '<th>Lease</th><th>Address</th><th>City, State</th><th>From</th><th>To</th><th>Date</th><th>Est. Value</th><th>Status</th>';
  html += '</tr></thead><tbody>';

  rows.slice(0, 50).forEach(r => {
    const status = r.research_status || 'pending';
    const statusDot = dotClass(status);

    html += `<tr class="clickable-tr" onclick='showDetail(${safeJSON(r)}, "gov-ownership")'>`;
    html += `<td><code>${esc(r.lease_number || '')}</code></td>`;
    html += `<td class="truncate">${esc(norm(r.address) || '—')}</td>`;
    html += `<td>${esc(norm(r.city) || '')}, ${esc(r.state || '')}</td>`;
    html += `<td class="truncate">${esc(norm(r.prior_owner) || '')}</td>`;
    html += `<td class="truncate">${esc(norm(r.new_owner) || '')}</td>`;
    html += `<td>${r.transfer_date ? r.transfer_date.substring(0, 10) : ''}</td>`;
    html += `<td>${fmt(r.estimated_value || 0)}</td>`;
    html += `<td><span class="status-dot ${statusDot}"></span>${cleanLabel(status)}</td>`;
    html += '</tr>';
  });
  
  html += '</tbody></table></div>';
  return html;
}

function leadsTable(rows) {
  if (!rows || rows.length === 0) {
    return '<div class="table-empty">No leads yet</div>';
  }
  
  let html = '<div class="table-wrapper"><table class="data-table"><thead><tr>';
  html += '<th>Score</th><th>Temp</th><th>Address</th><th>City, State</th><th>Tenant</th><th>Lessor</th><th>Rent</th><th>Value</th><th>Pipeline</th>';
  html += '</tr></thead><tbody>';

  rows.slice(0, 50).forEach(r => {
    const tempColor = {
      'hot': '#f87171',
      'warm': '#fbbf24',
      'cool': '#6c8cff'
    }[r.lead_temperature] || '#9498a8';

    const pipelineStatus = r.pipeline_status || 'new';

    html += `<tr class="clickable-tr" onclick='showDetail(${safeJSON(r)}, "gov-lead")'>`;
    html += `<td><strong>${r.priority_score || 0}</strong></td>`;
    html += `<td><span style="color:${tempColor};">${r.lead_temperature || 'cool'}</span></td>`;
    html += `<td class="truncate">${esc(norm(r.address) || '—')}</td>`;
    html += `<td>${esc(norm(r.city) || '')}, ${esc(r.state || '')}</td>`;
    html += `<td class="truncate">${esc(norm(r.tenant_agency || r.agency_full_name) || '—')}</td>`;
    html += `<td class="truncate">${esc(norm(r.lessor_name) || '')}</td>`;
    html += `<td>${fmt(r.annual_rent || 0)}/yr</td>`;
    html += `<td>${fmt(r.estimated_value || 0)}</td>`;
    html += `<td><span class="pill">${cleanLabel(pipelineStatus)}</span></td>`;
    html += '</tr>';
  });
  
  html += '</tbody></table></div>';
  return html;
}

function listingsTable(rows) {
  if (!rows || rows.length === 0) {
    return '<div class="table-empty">No listings yet</div>';
  }

  // DOM = days since listing_date (client-computed). Rows from CoStar have
  // days_on_market populated; LCC-intake rows are fresh so compute from date.
  const today = new Date();
  const computeDom = (r) => {
    if (r.days_on_market != null && r.days_on_market !== '') return r.days_on_market;
    if (!r.listing_date) return '-';
    const ms = today - new Date(r.listing_date);
    const days = Math.floor(ms / 86400000);
    return days >= 0 ? days : '-';
  };
  // Handle both r.property (embed from FK join) and legacy rows without it.
  const propOf = (r) => r.property || {};
  const sfOf   = (r) => {
    // Prefer listing.square_feet (building SF from OM), fall back to
    // property.rba (rentable building area) from gov properties.
    if (r.square_feet) return r.square_feet;
    const p = propOf(r);
    return p.rba || null;
  };
  const acres = (r) => propOf(r).land_acres || null;

  let html = '<div class="table-wrapper"><table class="data-table"><thead><tr>';
  html += '<th>Tenant</th><th>Address</th><th>City, State</th>';
  html += '<th>Year</th><th>SF</th><th>Acres</th>';
  html += '<th>Asking</th><th>Cap Rate</th><th>DOM</th>';
  html += '<th>Owner</th><th>Status</th><th>Source</th>';
  html += '<th style="text-align:center;min-width:100px">Actions</th>';
  html += '</tr></thead><tbody>';

  rows.slice(0, 50).forEach(r => {
    const p = propOf(r);
    const capRate = r.asking_cap_rate ? pct(r.asking_cap_rate) : '-';
    const status = r.listing_status || 'active';
    const sf = sfOf(r);
    const ac = acres(r);
    const yb = p.year_built;
    const owner = p.assessed_owner || '';

    html += `<tr class="clickable-tr" onclick='showDetail(${safeJSON(r)}, "gov-listing")'>`;
    html += `<td class="truncate" style="font-weight:500">${esc(norm(r.tenant_agency) || '—')}</td>`;
    html += `<td class="truncate">${esc(norm(r.address) || '')}</td>`;
    html += `<td>${esc(norm(r.city) || '')}${r.state ? ', ' + esc(r.state) : ''}</td>`;
    html += `<td>${yb || '-'}</td>`;
    html += `<td>${sf ? fmtN(sf) : '-'}</td>`;
    html += `<td>${ac != null ? Number(ac).toFixed(2) : '-'}</td>`;
    html += `<td>${fmt(r.asking_price || 0)}</td>`;
    html += `<td>${capRate}</td>`;
    html += `<td>${computeDom(r)}</td>`;
    html += `<td class="truncate" title="${esc(owner)}">${esc(owner || '-')}</td>`;
    html += `<td><span class="pill">${cleanLabel(status)}</span></td>`;
    html += `<td>${esc(cleanLabel(r.listing_source || ''))}</td>`;
    html += `<td style="text-align:center" onclick="event.stopPropagation()"><div style="display:flex;gap:3px;justify-content:center;flex-wrap:wrap">`;
    // Marketing collateral cell — renders any combination of:
    //   📄 OM/flyer PDF      (intake_artifact_path → signed Supabase URL)
    //   C/L/★/B/…            (marketplace listing URLs in tracked_urls/source_url)
    //   🌐                   (broker microsite / other website)
    //   🔗                   (fallback link)
    html += buildCollateralIcons(r, {
      pdf:         'intake_artifact_path',
      pdfType:     'intake_artifact_type',
      primaryUrl:  'source_url',
      trackedUrls: 'tracked_urls'
    });
    html += `<button class="gov-row-action" onclick='showDetail(${safeJSON(r)}, "gov-listing", "Ownership")' title="View owner & contacts">📞</button>`;
    html += `<button class="gov-row-action accent" onclick='showDetail(${safeJSON(r)}, "gov-listing", "Intel")' title="Research & intel">🔍</button>`;
    html += `</div></td>`;
    html += '</tr>';
  });

  html += '</tbody></table></div>';
  return html;
}

// ============================================================================
// COUNTY AUTHORITY SYSTEM
// ============================================================================

async function loadCountyAuthorities(states) {
  const uniqueStates = [...new Set(states)];
  
  for (const state of uniqueStates) {
    if (countyCache[state]) continue;
    
    const res = await govQuery('county_authorities',
      'county_name, state_code, netronline_url, assessor_url, recorder_url, treasurer_url, tax_url, gis_url, clerk_url, other_urls',
      { filter: `state_code=eq.${state}` }
    );
    
    countyCache[state] = {};
    res.data.forEach(c => {
      if (c.county_name) countyCache[state][c.county_name.toLowerCase()] = c;
    });
  }
}

function findCountyAuth(city, state) {
  if (!state) return null;

  // The bulk loader populates govData.countyAuth (a flat array). Lazily index
  // it into countyCache on first lookup so countyBtns works on all three
  // research surfaces without an extra async fetch.
  if (!countyCache[state] && Array.isArray(govData.countyAuth) && govData.countyAuth.length) {
    countyCache[state] = {};
    for (const c of govData.countyAuth) {
      if (c.state_code === state && c.county_name) {
        countyCache[state][c.county_name.toLowerCase()] = c;
      }
    }
  }

  if (!city || !countyCache[state]) return null;

  const cityLower = city.toLowerCase();
  const counties = countyCache[state];
  
  // Direct match
  if (counties[cityLower]) return counties[cityLower];
  
  // Partial match
  for (const key in counties) {
    if (key.includes(cityLower)) return counties[key];
  }
  
  // Word-level match
  const cityWords = cityLower.split(/\s+/);
  for (const key in counties) {
    const keyWords = key.split(/\s+/);
    for (const cw of cityWords) {
      for (const kw of keyWords) {
        if (cw === kw && cw.length > 3) return counties[key];
      }
    }
  }
  
  // Prefix match
  for (const key in counties) {
    if (key.startsWith(cityLower.substring(0, 4))) return counties[key];
  }
  
  return null;
}

function countyBtns(city, state) {
  const auth = findCountyAuth(city, state);
  if (!auth) return '';
  
  let html = '<div class="county-btns">';
  
  if (auth.assessor_url) {
    html += linkBtn('Assessor', auth.assessor_url);
  }
  if (auth.recorder_url) {
    html += linkBtn('Recorder', auth.recorder_url);
  }
  if (auth.netronline_url) {
    html += linkBtn('NetRonline', auth.netronline_url);
  }
  if (auth.tax_url) {
    html += linkBtn('Taxes', auth.tax_url);
  }
  if (auth.gis_url) {
    html += linkBtn('GIS', auth.gis_url);
  }
  
  html += '</div>';
  return html;
}

// ============================================================================
// SEARCH & LINK BUTTONS
// ============================================================================

function searchBtn(label, query) {
  const encoded = encodeURIComponent(query);
  return `<a href="https://www.google.com/search?q=${encoded}" target="_blank" rel="noopener" class="btn-search">${label}</a>`;
}

function sosBtns(propState, incorpState) {
  let html = '<div class="sos-btns">';
  
  const states = new Set();
  if (propState) states.add(propState);
  if (incorpState) states.add(incorpState);
  states.add('DE');
  
  states.forEach(state => {
    const url = SOS_URLS[state];
    if (url) {
      html += `<a href="${url}" target="_blank" rel="noopener" class="btn-sos">${esc(state)} SOS</a>`;
    }
  });
  
  html += '</div>';
  return html;
}

function linkBtn(label, url) {
  if (!url) return '';
  const safe = safeHref(url);
  if (safe === '#') return '';
  return `<a href="${safe}" target="_blank" rel="noopener" class="btn-link">${label}</a>`;
}

function linkBtnGreen(label, url) {
  if (!url) return '';
  const safe = safeHref(url);
  if (safe === '#') return '';
  return `<a href="${safe}" target="_blank" rel="noopener" class="btn-link-green">${label}</a>`;
}

// ============================================================================
// AUTOCOMPLETE SYSTEM
// ============================================================================

async function searchEntities(query, dropId, inputId, onSelect) {
  if (!query || query.length < 2) {
    const dropEl = q(`#${dropId}`);
    if (dropEl) dropEl.style.display = 'none';
    return;
  }

  const q_lower = query.toLowerCase();
  let results = [];

  // Search local contacts
  for (const contact of govData.contacts) {
    if (contact.name && contact.name.toLowerCase().includes(q_lower)) {
      results.push({
        type: 'contact',
        label: contact.name,
        value: contact.name,
        data: contact
      });
    }
  }

  // Search ownership history (true owners, new owners/SPEs)
  for (const own of govData.ownership) {
    if (own.true_owner_name && own.true_owner_name.toLowerCase().includes(q_lower)) {
      results.push({
        type: 'owner',
        label: `${own.true_owner_name} (Owner)`,
        value: own.true_owner_name,
        data: own
      });
    }
    if (own.new_owner && own.new_owner.toLowerCase().includes(q_lower)) {
      results.push({
        type: 'spe',
        label: `${own.new_owner} (SPE)`,
        value: own.new_owner,
        data: own
      });
    }
  }

  // Search prospect leads
  for (const lead of govData.leads) {
    if (lead.true_owner && lead.true_owner.toLowerCase().includes(q_lower)) {
      results.push({
        type: 'lead_owner',
        label: `${lead.true_owner} (Lead Owner)`,
        value: lead.true_owner,
        data: lead
      });
    }
  }

  // Search canonical entities (includes SF-linked records)
  if (query.length >= 3) {
    try {
      const headers = { 'Content-Type': 'application/json' };
      if (LCC_USER.workspace_id) headers['x-lcc-workspace'] = LCC_USER.workspace_id;
      const _ec = new AbortController(); const _et = setTimeout(() => _ec.abort(), 15000);
      const res = await fetch(`/api/entities?action=search&q=${encodeURIComponent(query)}&limit=15`, { headers, signal: _ec.signal });
      clearTimeout(_et);
      if (res.ok) {
        const data = await res.json();
        for (const ent of (data.entities || [])) {
          const sfIds = (ent.external_identities || []).filter(x => x.source_system === 'salesforce');
          const sfTag = sfIds.length > 0 ? ' \u2022 SF' : '';
          const typeTag = ent.entity_type === 'person' ? 'Contact' : ent.entity_type === 'organization' ? 'Company' : 'Asset';
          results.push({
            type: 'canonical',
            label: `${ent.name} (${typeTag}${sfTag})`,
            value: ent.name,
            data: {
              canonical_id: ent.id,
              name: ent.name,
              email: ent.email,
              phone: ent.phone,
              address: ent.address,
              city: ent.city,
              state: ent.state,
              entity_type: ent.entity_type,
              sf_ids: sfIds
            }
          });
        }
      }
    } catch (e) {
      // Canonical search is best-effort; local results still show
    }
  }

  // Deduplicate and limit
  const seen = new Set();
  results = results.filter(r => {
    const key = `${r.type}:${r.value}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 15);

  const dropEl = q(`#${dropId}`);

  if (results.length === 0) {
    dropEl.style.display = 'none';
    return;
  }

  // Store results for selection lookup
  window._acResults = window._acResults || {};
  window._acResults[dropId] = results;

  dropEl.innerHTML = results.map((r, i) => {
    const cls = r.type === 'canonical' ? 'ac-item ac-canonical' : 'ac-item';
    return `<div class="${cls}" onclick='selectAC(${safeJSON(inputId)}, ${safeJSON(r.value)}, ${safeJSON(dropId)}, ${i})'>${esc(r.label)}</div>`;
  }).join('');

  dropEl.style.display = 'block';
}

function setupAutocomplete(inputId, onSelect) {
  const inp = q(`#${inputId}`);
  if (!inp) return;
  
  const dropId = `${inputId}-drop`;
  
  // Create dropdown
  let drop = q(`#${dropId}`);
  if (!drop) {
    drop = document.createElement('div');
    drop.id = dropId;
    drop.className = 'ac-dropdown';
    inp.parentNode.insertBefore(drop, inp.nextSibling);
  }
  
  inp.addEventListener('input', () => {
    clearTimeout(acTimeout);
    acTimeout = setTimeout(() => {
      searchEntities(inp.value, dropId, inputId, onSelect);
    }, 150);
  });
  
  inp.addEventListener('blur', () => {
    setTimeout(() => {
      drop.style.display = 'none';
    }, 250); // 250ms delay to allow mousedown on dropdown items to fire first
  });
}

function selectAC(inputId, value, dropId, resultIdx) {
  const inputEl = q(`#${inputId}`);
  const dropEl = q(`#${dropId}`);
  if (inputEl) inputEl.value = value;
  if (dropEl) dropEl.style.display = 'none';

  // Auto-fill related fields from canonical entity data
  const results = window._acResults && window._acResults[dropId];
  if (results && resultIdx != null && results[resultIdx] && results[resultIdx].type === 'canonical') {
    const d = results[resultIdx].data;
    // Determine the prefix based on research mode
    const prefix = researchMode === 'ownership' ? 'res-own-' : 'res-lead-';
    
    // Fill email if available and field exists
    const emailEl = q(`#${prefix}principal-email`);
    if (emailEl && d.email && !emailEl.value) emailEl.value = d.email;
    // Fill phone
    const phoneEl = q(`#${prefix}phone`);
    if (phoneEl && d.phone && !phoneEl.value) phoneEl.value = d.phone;
    // Fill state of incorporation from entity state
    const incEl = q(`#${prefix}incorporation`);
    if (incEl && d.state && !incEl.value) incEl.value = d.state;

    // Show SF link badge if SF IDs exist
    if (d.sf_ids && d.sf_ids.length > 0) {
      const sfTypes = d.sf_ids.map(s => `${s.source_type}:${s.external_id}`).join(', ');
      showToast(`Linked to Salesforce: ${sfTypes}`, 'success');
    }
  }
}


function attachAutocomplete() {
  // Attach autocomplete based on current research mode
  if (researchMode === 'ownership') {
    setupAutocomplete('res-own-recorded-owner', null);
    setupAutocomplete('res-own-true-owner', null);
    setupAutocomplete('res-own-principal-names', null);
    setupAutocomplete('res-own-lender', null);
  } else if (researchMode === 'leads') {
    setupAutocomplete('res-lead-recorded-owner', null);
    setupAutocomplete('res-lead-true-owner', null);
    setupAutocomplete('res-lead-principal-names', null);
    setupAutocomplete('res-lead-lender', null);
  }
  // Intel mode doesn't use these autocomplete fields
}

// ============================================================================
// RESEARCH WORKBENCH
// ============================================================================

// ──────────────────────────────────────────────────────────────
// Ownership queue annotation — used by the prioritised research queue
// loader to surface what's missing and whether the comp is already on
// file before the reviewer commits to a card.
// Priority semantics (lower number = higher priority):
//   1  no sale + no owners                  — urgent, gather everything
//   2  no sale, partial owners              — sale price still missing
//   3  sale present, owners missing         — fill in owner fields
//   4  sale present + at least one owner    — verify only
//   5  comp already on file in sales_txns   — bottom of queue
function govOwnershipAnnotate(rec) {
  if (!rec) return;
  const norm = (s) => String(s || '').trim().toLowerCase();
  const hasSale = !!(rec.sale_price);
  const hasRecordedOwner = !!(rec.recorded_owner_name && String(rec.recorded_owner_name).trim());
  const hasTrueOwner = !!(rec.true_owner_name && String(rec.true_owner_name).trim());
  const ownerCount = (hasRecordedOwner ? 1 : 0) + (hasTrueOwner ? 1 : 0);

  // Comp-on-file detection — mirrors gov_auto_resolve_ownership so the
  // queue ranks rows the sweep would auto-resolve at the bottom even
  // before the sweep runs. Three match tiers:
  //   strict   — same lease_number + sale_date within ±90d of transfer_date
  //   loose    — same lease_number, ±365d window OR either date null
  //   property — same property_id + sale_date within ±90d of transfer_date
  let compMatch = null;
  let compMatchTier = null;
  if (Array.isArray(govData.salesComps)) {
    const transferTs = rec.transfer_date ? new Date(rec.transfer_date).getTime() : null;
    const strictWin = 90 * 86400 * 1000;
    const looseWin = 365 * 86400 * 1000;
    const ln = rec.lease_number ? norm(rec.lease_number) : null;
    const pid = rec.property_id != null ? rec.property_id : null;
    let strict = null, loose = null, property = null;
    for (const c of govData.salesComps) {
      const ct = c.sale_date ? new Date(c.sale_date).getTime() : null;
      const cln = c.lease_number ? norm(c.lease_number) : null;
      const leaseMatch = ln && cln && cln === ln;
      const propertyMatch = pid != null && c.property_id != null && c.property_id === pid;
      if (leaseMatch) {
        if (transferTs && ct && Math.abs(ct - transferTs) <= strictWin) { strict = strict || c; }
        else if (!transferTs || !ct || Math.abs(ct - transferTs) <= looseWin) { loose = loose || c; }
      }
      if (!strict && propertyMatch && transferTs && ct && Math.abs(ct - transferTs) <= strictWin) {
        property = property || c;
      }
      if (strict) break;
    }
    if (strict)        { compMatch = strict;   compMatchTier = 'strict'; }
    else if (loose)    { compMatch = loose;    compMatchTier = 'loose'; }
    else if (property) { compMatch = property; compMatchTier = 'property'; }
  }

  const missing = [];
  if (!hasSale) missing.push('Sale price');
  if (!rec.transfer_date) missing.push('Transfer date');
  if (!hasRecordedOwner) missing.push('Recorded owner');
  if (!hasTrueOwner) missing.push('True owner');
  if (!rec.cap_rate) missing.push('Cap rate');

  let priority;
  if (compMatch) priority = 5;
  else if (hasSale && ownerCount >= 1) priority = 4;
  else if (hasSale) priority = 3;
  else if (ownerCount >= 1) priority = 2;
  else priority = 1;

  rec._compOnFile = !!compMatch;
  rec._compMatchTier = compMatchTier;
  rec._matchedComp = compMatch;
  rec._missingFields = missing;
  rec._priority = priority;
  rec._completeness = Math.round(
    (((hasSale ? 1 : 0) + (rec.transfer_date ? 1 : 0) + (hasRecordedOwner ? 1 : 0) + (hasTrueOwner ? 1 : 0) + (rec.cap_rate ? 1 : 0)) / 5) * 100
  );
}

// Two-step UX: preview (dry run) shows bucket counts; confirm runs the
// apply pass on the gov DB. govRpc strips down to the first row of a
// rowset, but we need all three buckets, so call /api/gov-query directly.
async function _govOwnershipSweepCall(dryRun) {
  const url = new URL('/api/gov-query', window.location.origin);
  url.searchParams.set('table', 'rpc/gov_auto_resolve_ownership');
  const resp = await fetch(url.toString(), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ p_dry_run: dryRun })
  });
  const text = await resp.text();
  let data; try { data = JSON.parse(text); } catch (_) { data = text; }
  if (!resp.ok) {
    const detail = (data && data.error) || (typeof data === 'string' ? data : ('HTTP ' + resp.status));
    const err = new Error(detail);
    err.status = resp.status;
    throw err;
  }
  return Array.isArray(data) ? data : (data ? [data] : []);
}

window.govOwnershipSweepPreview = async function() {
  const btn = document.activeElement && document.activeElement.tagName === 'BUTTON' ? document.activeElement : null;
  const orig = btn?.textContent;
  if (btn) { btn.disabled = true; btn.textContent = 'Previewing…'; }
  try {
    const buckets = await _govOwnershipSweepCall(true);
    const total = buckets.reduce((s, b) => s + (Number(b.matched) || 0), 0);
    if (total === 0) {
      showToast('Nothing to sweep — no auto-resolvable rows in the queue', 'info');
      return;
    }
    const labels = {
      empty_shell:           'Empty shells (only true_owner_name)',
      placeholder:           'Boilerplate prior_owner ("Unknown" / "Previous Owner")',
      comp_on_file:          'Comp already in sales_transactions (±90d match)',
      comp_on_file_loose:    'Comp already in sales_transactions (same lease, ±365d or null date)',
      comp_on_file_property: 'Comp already in sales_transactions (property_id + ±90d match)',
      exact_dup:             'Exact-duplicate event rows (same lease + date + new_owner)'
    };
    const lines = buckets
      .filter(b => Number(b.matched) > 0)
      .map(b => '  • ' + (labels[b.bucket] || b.bucket) + ': ' + b.matched)
      .join('\n');
    const ok = await lccConfirm(
      'Auto-resolve ' + total + ' ownership_history row' + (total === 1 ? '' : 's') + '?\n\n' + lines + '\n\n' +
      'Empty shells → research_status="junk_no_data"\n' +
      'Placeholder rows → research_status="junk_placeholder"\n' +
      'Comp-on-file (all three buckets) → research_status="comp_on_file", matched_sale_id linked\n' +
      'Exact-dup events → research_status="duplicate_of_event" (oldest row kept)\n\n' +
      'You can re-run this sweep any time.',
      'Apply sweep'
    );
    if (!ok) return;
    if (btn) { btn.textContent = 'Applying…'; }
    const applied = await _govOwnershipSweepCall(false);
    const appliedTotal = applied.reduce((s, b) => s + (Number(b.applied) || 0), 0);
    showToast('Swept ' + appliedTotal + ' row' + (appliedTotal === 1 ? '' : 's') + ' — refreshing queue', 'success');
    // Force a fresh fetch of ownership_history; reload the research
    // queue once new data lands so the sweep effect is visible.
    govData.ownership = [];
    researchQueue = [];
    researchIdx = 0;
    if (typeof loadGovData === 'function') {
      loadGovData().then(() => loadResearchQueue()).then(() => renderGovTab());
    } else {
      await loadResearchQueue();
      renderGovTab();
    }
  } catch (err) {
    console.error('govOwnershipSweepPreview failed:', err);
    const msg = (err && err.message) || String(err);
    const friendly = /could not find the function|function .* does not exist|404/i.test(msg)
      ? 'RPC gov_auto_resolve_ownership not deployed yet — apply sql/20260507_gov_rpc_auto_resolve_ownership.sql'
      : msg;
    showToast('Sweep failed: ' + friendly, 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = orig || '🧹 Sweep auto-resolvable (preview)'; }
  }
};

// Intel sweep — same two-step pattern, hits gov_auto_resolve_intel which
// only has the true_junk_stub bucket today (8 rows in 2026-05-08 audit).
async function _govIntelSweepCall(dryRun) {
  const url = new URL('/api/gov-query', window.location.origin);
  url.searchParams.set('table', 'rpc/gov_auto_resolve_intel');
  const resp = await fetch(url.toString(), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ p_dry_run: dryRun })
  });
  const text = await resp.text();
  let data; try { data = JSON.parse(text); } catch (_) { data = text; }
  if (!resp.ok) {
    const detail = (data && data.error) || (typeof data === 'string' ? data : ('HTTP ' + resp.status));
    const err = new Error(detail);
    err.status = resp.status;
    throw err;
  }
  return Array.isArray(data) ? data : (data ? [data] : []);
}

// Jump the reviewer to the first row in a given Intel priority tier.
// Useful for "start with the 386 Tier 2 ready-to-approve rows" before
// digging into the bigger Hot Research bucket.
window.govIntelJumpToTier = function(targetTier) {
  if (!Array.isArray(researchQueue) || researchQueue.length === 0) {
    showToast('Queue is empty', 'info');
    return;
  }
  const idx = researchQueue.findIndex(r => (r._priority || 9) === Number(targetTier));
  if (idx < 0) {
    showToast('No rows in Tier ' + targetTier + ' in the current view', 'info');
    return;
  }
  researchIdx = idx;
  showToast('Jumped to Tier ' + targetTier + ' (' + (idx + 1) + ' / ' + researchQueue.length + ')', 'success');
  renderGovTab();
};

window.govIntelSweepPreview = async function() {
  const btn = document.activeElement && document.activeElement.tagName === 'BUTTON' ? document.activeElement : null;
  const orig = btn?.textContent;
  if (btn) { btn.disabled = true; btn.textContent = 'Previewing…'; }
  try {
    const buckets = await _govIntelSweepCall(true);
    const total = buckets.reduce((s, b) => s + (Number(b.matched) || 0), 0);
    if (total === 0) {
      showToast('Nothing to sweep — no auto-resolvable rows in the Intel queue', 'info');
      return;
    }
    const labels = {
      true_junk_stub:         'Stub properties (no RBA / year / owner / county data / firm term) → mark junk',
      tier2_complete:         'Tier 2 complete — A/B grade in window, all intel filled → mark approved',
      tier3c_complete:        'Tier 3c complete — C grade in window, all intel filled → mark approved',
      stale_lease_no_renewal: 'Stale lease — expired 5+ yrs ago, no GSA renewal, not in active deal pipeline',
      frpp_year_built:        'Backfill year_built from FRPP year_of_construction',
      frpp_rba:               'Backfill RBA from FRPP square_feet',
      gsa_lease_rba:          'Backfill RBA from gsa_leases.lease_rsf (where FRPP didn\'t have it)',
      sale_sync:              'Sync latest sale price + deed date from sales_transactions (last 5y)',
      true_owner_non_spe:     'Default true_owner = recorded_owner for non-SPE properties (owner_is_spe=false)'
    };
    const _resolveBuckets = ['true_junk_stub', 'tier2_complete', 'tier3c_complete', 'stale_lease_no_renewal'];
    const _backfillBuckets = ['frpp_year_built', 'frpp_rba', 'gsa_lease_rba', 'sale_sync', 'true_owner_non_spe'];
    const _resolveLines = buckets
      .filter(b => Number(b.matched) > 0 && _resolveBuckets.includes(b.bucket))
      .map(b => '  • ' + (labels[b.bucket] || b.bucket) + ': ' + b.matched);
    const _backfillLines = buckets
      .filter(b => Number(b.matched) > 0 && _backfillBuckets.includes(b.bucket))
      .map(b => '  • ' + (labels[b.bucket] || b.bucket) + ': ' + b.matched);
    const sections = [];
    if (_resolveLines.length) sections.push('▸ Resolve queue items:\n' + _resolveLines.join('\n'));
    if (_backfillLines.length) sections.push('▸ Backfill missing fields:\n' + _backfillLines.join('\n'));
    const lines = sections.join('\n\n');
    const ok = await lccConfirm(
      'Auto-resolve ' + total + ' propert' + (total === 1 ? 'y' : 'ies') + '?\n\n' + lines + '\n\n' +
      'You can re-run this sweep any time as new data lands.',
      'Apply sweep'
    );
    if (!ok) return;
    if (btn) { btn.textContent = 'Applying…'; }
    const applied = await _govIntelSweepCall(false);
    // Distinguish queue exits (status writes) from field backfills (data
    // writes). Without this split, "Swept 2,000 properties — refreshing
    // queue" misleads the reviewer when only 3 rows actually leave the
    // queue and 1,997 just had RBA / year_built backfilled. Round 76eo.
    const _exitBuckets    = new Set(['true_junk_stub', 'tier2_complete', 'tier3c_complete', 'stale_lease_no_renewal']);
    const exitTotal     = applied.filter(b => _exitBuckets.has(b.bucket)).reduce((s, b) => s + (Number(b.applied) || 0), 0);
    const backfillTotal = applied.filter(b => !_exitBuckets.has(b.bucket)).reduce((s, b) => s + (Number(b.applied) || 0), 0);
    const parts = [];
    if (exitTotal)     parts.push(exitTotal.toLocaleString() + ' queue exit' + (exitTotal === 1 ? '' : 's'));
    if (backfillTotal) parts.push(backfillTotal.toLocaleString() + ' field backfill' + (backfillTotal === 1 ? '' : 's'));
    const summary = parts.length ? parts.join(' + ') : 'no changes applied';
    showToast('Swept: ' + summary + ' — refreshing queue', 'success');
    govData.portfolioProperties = [];
    researchQueue = [];
    researchIdx = 0;
    if (typeof loadGovData === 'function') {
      loadGovData().then(() => loadResearchQueue()).then(() => renderGovTab());
    } else {
      await loadResearchQueue();
      renderGovTab();
    }
  } catch (err) {
    console.error('govIntelSweepPreview failed:', err);
    const msg = (err && err.message) || String(err);
    const friendly = /could not find the function|function .* does not exist|404/i.test(msg)
      ? 'RPC gov_auto_resolve_intel not deployed yet — apply sql/20260508_gov_intel_status_and_auto_resolve.sql'
      : msg;
    showToast('Sweep failed: ' + friendly, 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = orig || '🧹 Sweep auto-resolvable (preview)'; }
  }
};

// ──────────────────────────────────────────────────────────────
// Intel queue annotation — prioritises the Intel research workbench
// against the LCC sidebar workflow. The queue is dominated by 10K+
// properties and the matcher / pipeline already filled most of the
// non-research fields, so the reviewer's job is "fill the gaps that
// matter for the sell-side conversation."
//
// Priority semantics (lower = higher priority):
//   1  Hot: A/B grade + firm_term in [-1, 5] + missing core intel
//   2  Hot: A/B grade + firm_term in [-1, 5] + intel mostly there
//      (still review for accuracy)
//   3  Warm: A/B grade + firm_term > 5 (long-fuse pipeline)
//   4  Cold: C grade or unknown firm_term
//   5  D/F grade or junk stub (deprioritised)
//
// Adds:
//   _priority (number)
//   _priorityLabel (text), _priorityClass (badge color)
//   _missingFields (array of human labels)
//   _completeness (percent)
//   _hasCountyData (bool — assessed_owner / latest_deed_grantee filled)
//   _termWindow ("expired" | "<2y" | "2-5y" | ">5y" | "unknown")
function govIntelAnnotate(rec) {
  if (!rec) return;
  const grade = rec.deal_grade || null;
  const firm  = (rec.firm_term_remaining == null) ? null : Number(rec.firm_term_remaining);
  const isAB  = grade === 'A' || grade === 'B';
  const isC   = grade === 'C';
  const inHotWindow = firm != null && firm >= -1 && firm <= 5;
  const longFuse    = firm != null && firm > 5;

  // What's missing for a complete intel write-up
  const missing = [];
  if (!rec.rba)                                 missing.push('RBA');
  if (!rec.year_built)                          missing.push('Year built');
  if (!rec.recorded_owner_id && !rec.assessed_owner) missing.push('Recorded owner');
  if (!rec.true_owner_id)                       missing.push('True owner');
  if (!rec.gross_rent && !rec.noi)              missing.push('Rent / NOI');
  // estimated_value is intentionally NOT in the missing list — the column
  // exists but no production pipeline populates it (audit 2026-05-08
  // showed has_est_value=0 across all 10,647 rows). Including it inflated
  // every row's missing_count by 1 and pushed otherwise-complete records
  // into Tier 1 (Hot research). Compute downstream from NOI / cap rate
  // when needed, don't gate the queue on it.
  // Sale recency: a county-records sale within the last 5y satisfies the
  // "do we have a comp?" question
  const fiveYrsAgo = Date.now() - 5 * 365.25 * 86400 * 1000;
  const recentDeed = rec.latest_deed_date && new Date(rec.latest_deed_date).getTime() >= fiveYrsAgo;
  const recentSale = !!rec.latest_sale_price && recentDeed;
  if (!recentSale)                              missing.push('Recent sale');

  const coreMissing = missing.length >= 3;

  let priority;
  if (grade === 'D' || grade === 'F')           priority = 5;
  else if (isAB && inHotWindow && coreMissing)  priority = 1;
  else if (isAB && inHotWindow)                 priority = 2;
  else if (isAB && longFuse)                    priority = 3;
  else if (isC && inHotWindow)                  priority = 3;
  else                                          priority = 4;

  let priorityLabel, priorityClass, priorityHint;
  switch (priority) {
    case 1: priorityLabel = 'Hot — research'; priorityClass = 'urgent';      priorityHint = 'A/B grade in sell-side window; core intel missing'; break;
    case 2: priorityLabel = 'Hot — verify';   priorityClass = 'urgent';      priorityHint = 'A/B grade in sell-side window; intel ready to confirm'; break;
    case 3: priorityLabel = 'Warm';            priorityClass = 'needs-input'; priorityHint = isAB ? 'A/B grade, longer fuse' : 'C grade, sell-side window'; break;
    case 4: priorityLabel = 'Backfill';        priorityClass = 'ready';       priorityHint = 'Maintenance — fill gaps as time allows'; break;
    case 5: priorityLabel = 'Low value';       priorityClass = 'ready';       priorityHint = 'D/F grade; deprioritised'; break;
  }

  // Term window category (drives the secondary sort)
  let termWindow;
  if (firm == null)              termWindow = 'unknown';
  else if (firm <= 0)            termWindow = 'expired';
  else if (firm <= 2)            termWindow = '<2y';
  else if (firm <= 5)            termWindow = '2-5y';
  else                            termWindow = '>5y';

  // Annotator now tracks 5 fields (RBA / year built / recorded owner /
  // true owner / rent or NOI / recent sale) — est_value is dropped per
  // the audit. Add 1 because there are actually 6 checks above (recent
  // sale included).
  const totalChecks = 6;
  const filled = totalChecks - missing.length;
  rec._priority      = priority;
  rec._priorityLabel = priorityLabel;
  rec._priorityClass = priorityClass;
  rec._priorityHint  = priorityHint;
  rec._missingFields = missing;
  rec._completeness  = Math.max(0, Math.round((filled / totalChecks) * 100));
  rec._hasCountyData = !!(rec.assessed_owner || rec.latest_deed_grantee || rec.latest_sale_price);
  rec._termWindow    = termWindow;
}

async function loadResearchQueue() {
  researchQueue = [];
  researchIdx = 0;
  researchCompleted = 0;

  let filtered;
  if (researchMode === 'ownership') {
    if (researchFilter === 'all') {
      filtered = govData.ownership.slice();
    } else {
      filtered = govData.ownership.filter(o => !o.sale_price && (!o.research_status || o.research_status === 'pending'));
    }
  } else if (researchMode === 'intel') {
    // Intel queue: portfolio properties needing intel research. Annotate
    // every row first so the priority/missing-fields chips are correct
    // for both Pending and All views.
    const portfolio = govData.portfolioProperties || [];
    portfolio.forEach(govIntelAnnotate);
    if (researchFilter === 'all') {
      filtered = portfolio.slice();
    } else {
      // Pending = anything not in a terminal status. NULL = pending.
      filtered = portfolio.filter(p => !p.intel_status || p.intel_status === 'pending');
    }
  } else {
    if (researchFilter === 'all') {
      filtered = govData.leads.slice();
    } else {
      filtered = govData.leads.filter(l => !l.research_status || l.research_status === 'pending');
    }
  }

  if (filtered.length === 0) {
    showToast('No pending ' + researchMode + ' records found', 'info');
    return;
  }

  const maxToLoad = 50;
  for (const rec of filtered.slice(0, maxToLoad)) {
    // Enrich with GSA snapshots
    const snapshot = govData.gsaSnapshots.find(s => s.lease_number === rec.lease_number);
    if (snapshot) {
      rec.gsa_snapshot = snapshot;
    }

    // Enrich with GSA events
    rec.gsa_events = govData.gsaEvents.filter(e => e.lease_number === rec.lease_number).slice(0, 10);

    // Enrich with FRPP
    const frpp = govData.frppRecords.find(f =>
      f.street_address && f.street_address.includes(rec.address) &&
      f.city_name === rec.city &&
      f.state_name === STATE_FULL[rec.state]
    );
    if (frpp) {
      rec.frpp = frpp;
    }

    // Enrich with loan data for intel mode
    if (researchMode === 'intel') {
      const loan = (govData.loans || []).find(l => l.property_id === rec.property_id);
      if (loan) rec._loan = loan;
    }

    // Ownership rows: annotate with priority + comp-on-file so the queue
    // can be sorted to surface missing sales/owners first and bury items
    // we already have comps for.
    if (researchMode === 'ownership') {
      govOwnershipAnnotate(rec);
    }

    researchQueue.push(rec);
  }

  // Re-order ownership queue by priority (urgent first, comp-on-file last).
  // Tiebreaker: most-recent transfer_date first so fresh activity surfaces.
  if (researchMode === 'ownership') {
    researchQueue.sort((a, b) => {
      const pa = a._priority || 9, pb = b._priority || 9;
      if (pa !== pb) return pa - pb;
      const ta = a.transfer_date ? new Date(a.transfer_date).getTime() : 0;
      const tb = b.transfer_date ? new Date(b.transfer_date).getTime() : 0;
      return tb - ta;
    });
  }

  // Intel queue: priority asc, then by firm-term proximity to the sell-side
  // window (closer to expiration / holdover surfaces first inside each tier),
  // then by investment_score desc as a final tiebreaker. Round 76em.
  if (researchMode === 'intel') {
    const _termRank = { 'expired': 0, '<2y': 1, '2-5y': 2, '>5y': 3, 'unknown': 4 };
    researchQueue.sort((a, b) => {
      const pa = a._priority || 9, pb = b._priority || 9;
      if (pa !== pb) return pa - pb;
      const ta = _termRank[a._termWindow] ?? 5;
      const tb = _termRank[b._termWindow] ?? 5;
      if (ta !== tb) return ta - tb;
      const sa = Number(a.investment_score) || 0;
      const sb = Number(b.investment_score) || 0;
      return sb - sa;
    });
  }

  if (filtered.length > maxToLoad) {
    showToast('Loaded ' + maxToLoad + ' of ' + filtered.length + ' pending records', 'info');
  }
}

// ──────────────────────────────────────────────────────────────
// RESEARCH CARD STEP NAVIGATION (with draft state preservation)
// ──────────────────────────────────────────────────────────────
let govResearchStep = 0;
window._govFormDraft = {};  // Holds unsaved form values across subtab switches

/** Capture all visible ownership form field values into _govFormDraft */
function captureOwnershipDraft() {
  const fields = [
    'res-own-sale-date', 'res-own-sale-price', 'res-own-cap-rate',
    'res-own-price-source', 'res-own-buyer', 'res-own-seller',
    'res-own-recorded-owner', 'res-own-incorporation', 'res-own-phone', 'res-own-mailing',
    'res-own-true-owner', 'res-own-principal-names', 'res-own-principal-email',
    'res-own-phone-2', 'res-own-mailing-2',
    'res-own-rba', 'res-own-land-acres', 'res-own-year-built', 'res-own-year-renovated',
    'res-own-lender', 'res-own-loan-amount', 'res-own-loan-type', 'res-own-loan-status',
    'res-own-notes',
    'res-ps-date', 'res-ps-price', 'res-ps-buyer', 'res-ps-seller', 'res-ps-cap', 'res-ps-source'
  ];
  fields.forEach(function(id) {
    var el = q('#' + id);
    if (el && el.value !== undefined && el.value !== '') {
      window._govFormDraft[id] = el.value;
    }
  });
}

window.govStepNav = function(idx) {
  // Capture form values before re-render so data survives subtab switches
  if (researchMode === 'ownership') captureOwnershipDraft();
  govResearchStep = idx;
  renderGovTab();
  // After render, restore any draft values that weren't in the record
  requestAnimationFrame(function() {
    Object.keys(window._govFormDraft).forEach(function(id) {
      var el = q('#' + id);
      if (el && !el.value) el.value = window._govFormDraft[id];
    });
  });
};

// ──────────────────────────────────────────────────────────────
// PIPELINE OPS STATE VARIABLES
// ──────────────────────────────────────────────────────────────
let govResearchSection = 'research'; // 'research' | 'pipeline_ops'
let govPendingUpdates = null;
let govPendingUpdatesLoading = false;
let govPendingUpdatesIdx = 0;
let govPendingAutoResolved = null;
let govPendingFilter = 'all'; // category filter (taxonomy.category id)
let govPendingSubtypeFilter = 'all'; // optional reason filter within a category
let govPendingKeysBound = false;
let govFinOverrideRec = null;
let govPipelineRuns = null;
let govPipelineLoading = false;
let govMonitorData = null;
let govMonitorLoading = false;
let govIntakeQueue = null;
let govIntakeLoading = false;
let govIntakeIdx = 0;

/**
 * Load email intake queue for government domain
 */
async function loadGovIntakeQueue() {
  if (govIntakeLoading) return;
  govIntakeLoading = true;
  try {
    const url = new URL('/api/intake-queue', window.location.origin);
    url.searchParams.set('domain', 'government');
    url.searchParams.set('limit', '50');
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000);
    const response = await fetch(url.toString(), { signal: controller.signal });
    clearTimeout(timeout);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const result = await response.json();
    govIntakeQueue = result.items || [];
  } catch(e) {
    console.error('loadGovIntakeQueue error:', e);
    showToast('Intake queue load failed', 'error');
    govIntakeQueue = [];
  }
  govIntakeLoading = false;
  if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'government') return;
  renderGovTab();
}

/**
 * Render government intake queue
 */
function renderGovIntakeQueue() {
  if (govIntakeLoading || !govIntakeQueue) {
    return '<div style="text-align:center;padding:40px;color:var(--text3)"><div class="spinner"></div><div style="margin-top:12px">Loading intake queue...</div></div>';
  }

  const items = govIntakeQueue;
  if (items.length === 0) {
    return '<div style="text-align:center;padding:40px">'
      + '<div style="font-size:36px;margin-bottom:12px">📬</div>'
      + '<div style="font-size:15px;font-weight:600;color:var(--text)">No intake items</div>'
      + '<div style="font-size:12px;color:var(--text3);margin-top:4px">Documents from email intake will appear here for review</div>'
      + '<button onclick="govIntakeQueue=null;loadGovIntakeQueue()" style="margin-top:12px;padding:6px 16px;border-radius:6px;border:1px solid var(--border);background:var(--s2);color:var(--text2);cursor:pointer;font-size:12px">Refresh</button>'
      + '</div>';
  }

  let html = '<div style="margin-bottom:12px;display:flex;align-items:center;justify-content:space-between">';
  html += `<div style="font-size:13px;color:var(--text2)">${items.length} item${items.length !== 1 ? 's' : ''} awaiting review</div>`;
  html += '<button onclick="govIntakeQueue=null;loadGovIntakeQueue()" style="padding:4px 12px;border-radius:6px;border:1px solid var(--border);background:var(--s2);color:var(--text2);cursor:pointer;font-size:11px">Refresh</button>';
  html += '</div>';

  html += '<div style="display:flex;flex-direction:column;gap:10px">';
  items.forEach((item, idx) => {
    html += renderIntakeCard(item, idx, 'gov');
  });
  html += '</div>';

  return html;
}

function renderOwnershipResearchCard(rec) {
  // Track record changes to reset step and clear draft
  if (window._govLastRecId !== (rec.property_id)) {
    govResearchStep = 0;
    window._govLastRecId = rec.property_id;
    window._govFormDraft = {};
  }

  // Make sure annotation flags exist even on records that didn't pass through
  // the queue loader (defensive — the loader does this for the current view).
  if (rec._priority == null) govOwnershipAnnotate(rec);

  const snapshot = rec.gsa_snapshot || {};
  const frpp = rec.frpp || {};
  const loan = (govData.loans || []).find(l => l.property_id === rec.property_id) || {};

  let html = '<div class="research-card own-research-card">';

  // ────────────────────────────────────────────────────────────
  // CONTEXT PANEL (LEFT) — research-first read view.
  // The reviewer ingests data via the LCC Chrome sidebar against
  // CoStar / county pages in another tab, so the manual entry form
  // is collapsed by default (see <details> on the right).
  // ────────────────────────────────────────────────────────────
  html += '<div class="research-context">';

  // Task header — badge reflects the prioritisation tier
  const _priorityMeta = (() => {
    if (rec._compOnFile)  return { cls: 'comp',         label: 'Comp on file', sub: 'Already in sales_transactions' };
    if (rec._priority === 1) return { cls: 'urgent',    label: 'Urgent',       sub: 'No sale, no owners' };
    if (rec._priority === 2) return { cls: 'urgent',    label: 'Sale missing', sub: 'Owner data partial' };
    if (rec._priority === 3) return { cls: 'needs-input', label: 'Owners missing', sub: 'Sale on file, owners blank' };
    if (rec._priority === 4) return { cls: 'ready',     label: 'Verify',       sub: 'Sale + 1 owner present' };
    return { cls: 'ready', label: 'Review', sub: '' };
  })();
  html += '<div class="task-header">';
  html += '<div>Ownership Change Research</div>';
  html += `<span class="task-badge ${_priorityMeta.cls}">${esc(_priorityMeta.label)}</span>`;
  html += '</div>';
  if (_priorityMeta.sub) {
    html += `<div class="own-priority-sub">${esc(_priorityMeta.sub)}${rec._completeness != null ? ' · ' + rec._completeness + '% complete' : ''}</div>`;
  }

  // Comp-on-file banner — surfaces the matching sales_transactions row
  // and lets the reviewer one-click clear the queue entry.
  if (rec._compOnFile && rec._matchedComp) {
    const c = rec._matchedComp;
    const sd = c.sale_date ? String(c.sale_date).substring(0, 10) : '—';
    const tierLabel = rec._compMatchTier === 'loose'
      ? 'lease match · wider date window'
      : rec._compMatchTier === 'property'
        ? 'property match · ±90d'
        : 'lease match · ±90d';
    html += '<div class="own-comp-banner">';
    html += '<div class="own-comp-banner-row">';
    html += '<span class="own-comp-banner-icon">✓</span>';
    html += '<span class="own-comp-banner-label">Comp already on file</span>';
    html += `<span class="own-comp-banner-meta">${esc(sd)} · ${c.sold_price ? fmt(c.sold_price) : 'price unknown'}${c.sold_cap_rate ? ' · ' + (Number(c.sold_cap_rate) * 100).toFixed(2) + '%' : ''} · ${esc(tierLabel)}</span>`;
    html += '</div>';
    html += '<div class="own-comp-banner-sub">This ownership row duplicates a sales_transactions record — clear it with <strong>Already on file</strong> below.</div>';
    html += '</div>';
  }

  // Property facts. Fall back from ownership_history.address (often NULL on
  // bot-generated rows) → gsa_snapshots.address (joined by lease_number) →
  // FRPP street_address. Make the source explicit so the reviewer trusts it.
  const _addr  = rec.address  || snapshot.address  || frpp.street_address || '';
  const _city  = rec.city     || snapshot.city     || frpp.city_name      || '';
  const _state = rec.state    || snapshot.state    || frpp.state_name      || '';
  const _addrSrc = rec.address ? '' : (snapshot.address ? ' · from gsa_snapshots' : (frpp.street_address ? ' · from FRPP' : ''));
  const _isEmptyShell = !_addr && !rec.lease_number && !rec.prior_owner && !rec.new_owner && !rec.transfer_date && !rec.sale_price && !rec.recorded_owner_name;
  const rba = rec.rba || rec.square_feet || frpp.square_feet || snapshot.lease_rsf || null;
  const yearBuilt = rec.year_built || frpp.year_built || null;
  const tenant = rec.tenant_agency || rec.agency_full_name || frpp.using_agency || frpp.using_bureau || '';
  html += '<div class="context-block">';
  html += '<div class="context-label">Property' + (_addrSrc ? ' <span class="own-addr-src">' + esc(_addrSrc) + '</span>' : '') + '</div>';
  if (_isEmptyShell) {
    html += '<div class="context-value own-empty-shell">No research handle on this row</div>';
    html += '<div class="context-sub">Only true_owner_name is set — no lease #, address, or transfer info to chase. Use <strong>Reject</strong> or the <em>Sweep auto-resolvable</em> button.</div>';
  } else {
    html += `<div class="context-value">${esc(_addr || '—')}</div>`;
    html += `<div class="context-sub">${esc(_city)}${_city && _state ? ', ' : ''}${esc(_state)}</div>`;
    const _facts = [];
    if (rba)        _facts.push(fmtN(rba) + ' SF');
    if (yearBuilt)  _facts.push('Built ' + esc(yearBuilt));
    if (tenant)     _facts.push(esc(tenant));
    if (_facts.length) html += `<div class="own-facts-row">${_facts.join(' · ')}</div>`;
  }
  html += '</div>';

  // Lease summary
  if (rec.lease_number || rec.annual_rent || snapshot.lease_effective) {
    html += '<div class="context-block">';
    html += '<div class="context-label">Lease</div>';
    if (rec.lease_number) html += `<div class="context-value"><code>${esc(rec.lease_number)}</code>${rec.location_code ? ' <span style="color:var(--text3)">· loc ' + esc(rec.location_code) + '</span>' : ''}</div>`;
    const _annual = rec.annual_rent || snapshot.annual_rent || null;
    if (_annual) html += `<div class="context-sub">${fmt(_annual)}/yr${snapshot.lease_rsf ? ' · ' + fmtN(snapshot.lease_rsf) + ' RSF' : ''}</div>`;
    if (snapshot.lease_effective) {
      html += `<div class="context-sub">Term: ${snapshot.lease_effective.substring(0, 10)} → ${(snapshot.lease_expiration || '').substring(0, 10)}</div>`;
    }
    html += '</div>';
  }

  // Sale block — explicit "blank" rendering when missing
  html += '<div class="context-block own-sale-block">';
  html += '<div class="context-label">Sale</div>';
  html += '<dl class="own-kv">';
  html += '<dt>Sale date</dt><dd>' + (rec.transfer_date ? esc(String(rec.transfer_date).substring(0, 10)) : '<span class="own-blank">—</span>') + '</dd>';
  html += '<dt>Sale price</dt><dd>' + (rec.sale_price ? fmt(rec.sale_price) : '<span class="own-blank">—</span>') + '</dd>';
  html += '<dt>Cap rate</dt><dd>' + (rec.cap_rate ? (Number(rec.cap_rate) <= 1 ? (Number(rec.cap_rate) * 100).toFixed(2) : Number(rec.cap_rate).toFixed(2)) + '%' : '<span class="own-blank">—</span>') + '</dd>';
  html += '</dl>';
  if (rec._missingFields && rec._missingFields.length) {
    html += `<div class="own-missing">Missing: ${rec._missingFields.map(esc).join(', ')}</div>`;
  }
  html += '</div>';

  // Owners side-by-side — Recorded (deed-level) vs True (beneficial)
  // Each side carries the prior → new pair so the reviewer sees the
  // transfer in one glance.
  html += '<div class="own-owners-grid">';
  html += '<div class="own-owners-col-head">Recorded owner <span class="own-owners-col-sub">(deed)</span></div>';
  html += '<div class="own-owners-col-head">True owner <span class="own-owners-col-sub">(beneficial / parent)</span></div>';

  // Recorded side
  html += '<div class="own-owners-cell">';
  html += '<div class="own-owners-flow">';
  html += `<div class="own-owners-prior"><span class="own-owners-tag">Prior</span> ${esc(rec.prior_owner || '—')}</div>`;
  html += `<div class="own-owners-arrow">↓</div>`;
  html += `<div class="own-owners-new"><span class="own-owners-tag own-owners-tag-new">New</span> ${esc(rec.new_owner || rec.recorded_owner_name || '—')}</div>`;
  html += '</div>';
  if (rec.recorded_owner_name && rec.recorded_owner_name !== rec.new_owner) {
    html += `<div class="own-owners-detail">Recorded as: <strong>${esc(rec.recorded_owner_name)}</strong></div>`;
  }
  if (rec.state_of_incorporation) {
    html += `<div class="own-owners-detail">State of inc: ${esc(rec.state_of_incorporation)}</div>`;
  }
  if (rec.mailing_address) {
    html += `<div class="own-owners-detail own-owners-mailing">${esc(rec.mailing_address)}${rec.mailing_address_2 ? '<br>' + esc(rec.mailing_address_2) : ''}</div>`;
  }
  html += '</div>';

  // True side
  html += '<div class="own-owners-cell">';
  if (rec.true_owner_name) {
    html += `<div class="own-owners-flow"><div class="own-owners-new"><span class="own-owners-tag own-owners-tag-new">Current</span> ${esc(rec.true_owner_name)}</div></div>`;
  } else {
    html += '<div class="own-owners-flow own-owners-empty">— sidebar / county lookup needed —</div>';
  }
  if (rec.principal_names) {
    html += `<div class="own-owners-detail">Principals: ${esc(rec.principal_names)}</div>`;
  }
  if (rec.phone_2) {
    html += `<div class="own-owners-detail">Phone: ${esc(rec.phone_2)}</div>`;
  }
  html += '</div>';
  html += '</div>'; // own-owners-grid

  // Research links — surface county/SOS/Google buttons up front so the
  // reviewer can chase a missing true owner without opening the manual form.
  const _ownSearchQuery = (rec.recorded_owner_name || rec.new_owner || rec.true_owner_name || '')
    + ' ' + (_addr || '') + ' ' + (_city || '') + ' ' + (_state || '');
  const _ownCountyHtml = countyBtns(_city, _state);
  const _ownSosHtml = sosBtns(_state, rec.state_of_incorporation);
  if (_ownSearchQuery.trim() || _ownCountyHtml || _ownSosHtml) {
    html += '<div class="quick-actions own-research-links">';
    if (_ownSearchQuery.trim()) {
      html += searchBtn('Google Search', _ownSearchQuery.trim());
    }
    html += _ownSosHtml;
    html += _ownCountyHtml;
    html += '</div>';
  }

  // Sidebar tip — explicit, since the form is collapsed by default
  html += '<div class="own-sidebar-tip">';
  html += '<span class="own-sidebar-tip-icon">📎</span>';
  html += '<span>Capture from CoStar / county records via the <strong>LCC sidebar</strong> (Chrome) — values land here automatically. Use the manual form below only when no source page is available.</span>';
  html += '</div>';

  if (frpp.street_address) {
    html += `<div class="context-block" style="opacity:0.75">
      <div class="context-label">FRPP Reference</div>
      <div class="context-value">${esc(frpp.property_type || '')}</div>
      <div class="context-sub">${fmtN(frpp.square_feet || 0)} SF${frpp.using_agency ? ' · ' + esc(frpp.using_agency) : ''}</div>
    </div>`;
  }

  html += '</div>';

  // ────────────────────────────────────────────────────────────
  // RIGHT PANEL — research-first action surface.
  // Most ingestion flows through the LCC Chrome sidebar against CoStar /
  // county pages, so the manual 6-step form is collapsed into a <details>
  // block by default. The reviewer's primary actions live up top:
  //   ✓ Approve   — research complete, mark resolved
  //   ⛓ Reject    — out of scope / bad data
  //   ↻ SPE Rename — same true owner, different SPE
  //   N/A         — not applicable
  //   ✓ Already on file — comp_on_file shortcut (also surfaces when matched)
  // ────────────────────────────────────────────────────────────
  html += '<div class="research-form">';

  // Completeness bar
  const allFields = [rec.sale_price, rec.recorded_owner_name, rec.true_owner_name, rec.rba, loan.index_name];
  const completeness = computeCompleteness(allFields.map((v, i) => ({ value: v, required: [0, 1, 2, 3].includes(i) })));
  html += renderCompletenessBar(completeness);

  // Manual entry is collapsed by default. Open it only when the sidebar
  // can't reach the source data (e.g. paper-only deeds, manual notes).
  const _priorSales = window._govPriorSales || [];
  const _formOpen = !!window._govOwnFormOpen;
  html += '<details class="own-manual-details"' + (_formOpen ? ' open' : '') + ' ontoggle="window._govOwnFormOpen=this.open">';
  html += '<summary class="own-manual-summary">';
  html += '<span class="own-manual-summary-icon">✏️</span>';
  html += '<span class="own-manual-summary-label">Edit fields manually</span>';
  html += '<span class="own-manual-summary-hint">— sidebar capture preferred; open only when no source page is available</span>';
  html += '</summary>';

  // Step navigation (6 steps — added Prior Sales)
  const steps = [
    {label: 'Sale Details', complete: !!rec.sale_price},
    {label: 'Entity', complete: !!rec.recorded_owner_name},
    {label: 'True Owner', complete: !!rec.true_owner_name},
    {label: 'Property', complete: !!rec.rba},
    {label: 'Financing', complete: !!loan.index_name},
    {label: 'Prior Sales', complete: _priorSales.length > 0}
  ];
  html += renderStepNav(govResearchStep, steps, 'window.govStepNav');

  // ──── STEP 0: SALE DETAILS ────
  html += `<div class="form-step${govResearchStep === 0 ? ' active' : ''}">`;
  html += '<div class="form-step-head"><span class="step-num">1</span> Sale Details</div>';
  html += guidedField('res-own-sale-date', 'Sale Date', rec.sale_date ? rec.sale_date.substring(0, 10) : '', {type:'date'});
  html += guidedField('res-own-sale-price', 'Sale Price', rec.sale_price || '', {type:'number', required:true, placeholder:'e.g. 5000000'});
  html += guidedField('res-own-cap-rate', 'Cap Rate (%)', rec.cap_rate || '', {type:'number', step:'0.1', placeholder:'e.g. 4.5'});
  html += guidedField('res-own-price-source', 'Price Source', '', {placeholder:'CoStar, CBRE, etc.'});
  html += guidedField('res-own-buyer', 'Buyer', rec.new_owner || '', {placeholder:'Purchasing entity'});
  html += guidedField('res-own-seller', 'Seller', rec.prior_owner || '', {placeholder:'Selling entity'});
  html += '</div>';

  // ──── STEP 1: ENTITY DETAILS ────
  html += `<div class="form-step${govResearchStep === 1 ? ' active' : ''}">`;
  html += '<div class="form-step-head"><span class="step-num">2</span> Entity</div>';
  html += guidedField('res-own-recorded-owner', 'Recorded Owner Name', rec.recorded_owner_name || '', {required:true, placeholder:'From deed'});
  html += guidedField('res-own-incorporation', 'State of Incorporation', rec.state_of_incorporation || '', {placeholder:'e.g. DE'});
  html += guidedField('res-own-phone', 'Phone', rec.recorded_owner_phone || '', {placeholder:'(555) 123-4567'});
  html += guidedField('res-own-mailing', 'Mailing Address', rec.mailing_address || '', {});
  html += '<div class="quick-actions">';
  html += searchBtn('Google Search', `${rec.recorded_owner_name || rec.address}`);
  html += sosBtns(rec.state, rec.state_of_incorporation);
  html += '</div>';
  html += '</div>';

  // ──── STEP 2: TRUE OWNER / PARENTS ────
  html += `<div class="form-step${govResearchStep === 2 ? ' active' : ''}">`;
  html += '<div class="form-step-head"><span class="step-num">3</span> True Owner</div>';
  html += guidedField('res-own-true-owner', 'True Owner / Parent Company', rec.true_owner_name || '', {required:true});
  html += guidedField('res-own-principal-names', 'Principal Names', rec.principal_names || '', {placeholder:'CEO, Owner, etc.'});
  html += guidedField('res-own-principal-email', 'Contact Email', '', {type:'email', placeholder:'contact@example.com'});
  html += guidedField('res-own-phone-2', 'Phone 2', rec.phone_2 || '', {});
  html += guidedField('res-own-mailing-2', 'Mailing Address 2', rec.mailing_address_2 || '', {});
  html += '</div>';

  // ──── STEP 3: PROPERTY DETAILS ────
  html += `<div class="form-step${govResearchStep === 3 ? ' active' : ''}">`;
  html += '<div class="form-step-head"><span class="step-num">4</span> Property</div>';
  html += guidedField('res-own-rba', 'RBA (Rentable Building Area)', rec.rba || '', {type:'number', required:true});
  html += guidedField('res-own-land-acres', 'Land Acres', rec.land_acres || '', {type:'number', step:'0.01'});
  html += guidedField('res-own-year-built', 'Year Built', rec.year_built || '', {type:'number', placeholder:'YYYY'});
  html += guidedField('res-own-year-renovated', 'Year Renovated', rec.year_renovated || '', {type:'number', placeholder:'YYYY'});
  html += '</div>';

  // ──── STEP 4: FINANCING ────
  html += `<div class="form-step${govResearchStep === 4 ? ' active' : ''}">`;
  html += '<div class="form-step-head"><span class="step-num">5</span> Financing</div>';
  html += guidedField('res-own-lender', 'Lender Name', loan.index_name || '', {source: loan.index_name ? 'loan records' : null});
  html += guidedField('res-own-loan-amount', 'Loan Amount', loan.loan_amount || '', {type:'number', source: loan.loan_amount ? 'loan records' : null});
  html += guidedField('res-own-loan-type', 'Loan Type', loan.loan_type || '', {placeholder:'Refinance, Construction, etc.'});
  html += guidedField('res-own-loan-status', 'Loan Status', loan.status || '', {});
  html += guidedField('res-own-notes', 'Research Notes', rec.research_notes || '', {type:'textarea', rows:4, placeholder:'Key findings...'});
  html += '</div>';

  // ──── STEP 5: PRIOR SALES (bulk entry) ────
  html += `<div class="form-step${govResearchStep === 5 ? ' active' : ''}">`;
  html += '<div class="form-step-head"><span class="step-num">6</span> Prior Sales</div>';
  html += '<div style="font-size:12px;color:var(--text2);margin-bottom:12px">Add previous transactions for this property. Data dumps multiple sales while the record is open.</div>';

  // Existing prior sales entries
  if (!window._govPriorSales) window._govPriorSales = [];
  if (window._govPriorSales.length > 0) {
    html += '<div style="margin-bottom:12px">';
    window._govPriorSales.forEach((ps, pi) => {
      html += `<div style="display:flex;align-items:center;gap:8px;padding:8px 10px;margin-bottom:4px;background:var(--s2);border-radius:6px;font-size:12px">`;
      html += `<span style="color:var(--text2)">${esc(ps.date || '—')}</span>`;
      html += `<span style="color:var(--accent);font-weight:600">${ps.price ? '$' + Number(ps.price).toLocaleString() : '—'}</span>`;
      html += `<span style="flex:1;color:var(--text)">${esc(ps.buyer || '')} ← ${esc(ps.seller || '')}</span>`;
      html += `<button class="btn-action" onclick="window._govPriorSales.splice(${pi},1);renderGovTab()" style="padding:2px 6px;font-size:10px">✕</button>`;
      html += '</div>';
    });
    html += '</div>';
  }

  // Add new prior sale form
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">';
  html += guidedField('res-ps-date', 'Sale Date', '', {type:'date'});
  html += guidedField('res-ps-price', 'Sale Price', '', {type:'number', placeholder:'e.g. 4500000'});
  html += guidedField('res-ps-buyer', 'Buyer', '', {placeholder:'Purchasing entity'});
  html += guidedField('res-ps-seller', 'Seller', '', {placeholder:'Selling entity'});
  html += guidedField('res-ps-cap', 'Cap Rate (%)', '', {type:'number', step:'0.1', placeholder:'e.g. 5.25'});
  html += guidedField('res-ps-source', 'Source', '', {placeholder:'CoStar, County records, etc.'});
  html += '</div>';
  html += `<button class="btn-action" onclick="govAddPriorSale()" style="margin-bottom:8px">+ Add Prior Sale</button>`;
  html += '</div>';

  // Manual-form internal action row (Back / Next / Save) lives inside the
  // <details> so it only shows when the reviewer opens the form.
  html += '<div class="action-row own-manual-action-row">';
  if (govResearchStep > 0) {
    html += `<button class="btn-action" onclick="govStepNav(${govResearchStep - 1})">← Back</button>`;
  }
  if (govResearchStep < 5) {
    html += `<button class="btn-action" onclick="govStepNav(${govResearchStep + 1})">Next →</button>`;
  }
  html += `<button class="btn-action primary" onclick="_udBtnGuard(this, researchSaveInPlace)">Save manual edits</button>`;
  html += `<button class="btn-action" onclick="_udBtnGuard(this, researchSave)">Save &amp; Next</button>`;
  html += '</div>';

  html += '</details>'; // own-manual-details

  // ────────────────────────────────────────────────────────────
  // PRIMARY ACTION ROW — research-driven decisions, always visible.
  // ────────────────────────────────────────────────────────────
  html += '<div class="action-row own-primary-actions">';
  if (rec._compOnFile) {
    html += `<button class="btn-action primary" title="Already in sales_transactions — clear from queue" onclick="_udActionBtnGuard(this, researchMark, 'comp_on_file')">✓ Already on file</button>`;
  } else {
    html += `<button class="btn-action primary" title="Research complete — mark resolved" onclick="_udActionBtnGuard(this, researchMark, 'approve')">✓ Approve</button>`;
  }
  html += `<button class="btn-action danger" title="Out of scope / bad data" onclick="_udActionBtnGuard(this, researchMark, 'reject')">✗ Reject</button>`;
  html += `<button class="btn-action" onclick="researchNav(1,true)" title="Skip to next">→ Skip</button>`;
  html += `<button class="btn-action" onclick="_udActionBtnGuard(this, researchMark, 'spe_rename')" title="Same true owner, different SPE">↻ SPE Rename</button>`;
  html += `<button class="btn-action" onclick="_udActionBtnGuard(this, researchMark, 'na')" title="Not applicable">N/A</button>`;
  html += `<button class="btn-action danger" onclick="_udActionBtnGuard(this, researchMark, 'multi_tenant')" title="Discard — small lease in a multi-tenant building (out of single-tenant scope)">🚫 Multi-tenant</button>`;
  if (rec._compOnFile) {
    // Still expose Approve as a secondary path even when comp is on file,
    // for cases where the reviewer wants to record additional research.
    html += `<button class="btn-action" style="margin-left:auto" title="Mark research complete" onclick="_udActionBtnGuard(this, researchMark, 'approve')">Approve</button>`;
  }
  html += '</div>';

  html += '</div>'; // research-form

  return html;
}

function renderLeadResearchCard(rec) {
  // Track record changes to reset step
  if (window._govLastRecId !== (rec.lead_id || rec.id)) {
    govResearchStep = 0;
    window._govLastRecId = rec.lead_id || rec.id;
  }

  const snapshot = rec.gsa_snapshot || {};
  const frpp = rec.frpp || {};
  const loan = (govData.loans || []).find(l => l.property_id === rec.matched_property_id) || {};

  let html = '<div class="research-card">';

  // ────────────────────────────────────────────────────────────
  // CONTEXT PANEL (LEFT)
  // ────────────────────────────────────────────────────────────
  html += '<div class="research-context">';

  // Task header
  html += '<div class="task-header">';
  html += '<div>Lead Research</div>';
  let badge = 'ready';
  if (rec.lead_temperature === 'hot') badge = 'urgent';
  else if (!rec.recorded_owner || !rec.true_owner) badge = 'needs-input';
  html += `<span class="task-badge ${badge}">${badge === 'urgent' ? 'Urgent' : badge === 'needs-input' ? 'Needs Input' : 'Ready'}</span>`;
  html += '</div>';

  html += `<div class="context-block">
    <div class="context-label">Property</div>
    <div class="context-value">${esc(rec.address || '')}</div>
    <div class="context-sub">${esc(rec.city || '')}, ${esc(rec.state || '')}</div>
  </div>`;

  html += `<div class="context-block">
    <div class="context-label">Lessor / Owner</div>
    <div class="context-value">${esc(rec.lessor_name || '')}</div>
    <div class="context-sub">Lead Temp: ${rec.lead_temperature || 'cool'}</div>
  </div>`;

  html += `<div class="context-block">
    <div class="context-label">Lease / Annual Rent</div>
    <div class="context-value"><code>${esc(rec.lease_number || '')}</code></div>
    <div class="context-sub">${rec.location_code ? 'Loc: ' + esc(rec.location_code) + ' · ' : ''}${fmt(rec.annual_rent || 0)}/yr</div>
  </div>`;

  if (snapshot.lease_effective) {
    html += `<div class="context-block">
      <div class="context-label">GSA Lease Term</div>
      <div class="context-value">${snapshot.lease_effective.substring(0, 10)} - ${(snapshot.lease_expiration || '').substring(0, 10)}</div>
      <div class="context-sub">Firm: ${rec.firm_term_remaining || 'TBD'}</div>
    </div>`;
  }

  if (frpp.street_address) {
    html += `<div class="context-block">
      <div class="context-label">FRPP Type</div>
      <div class="context-value">${esc(frpp.property_type || '')}</div>
      <div class="context-sub">${fmtN(frpp.square_feet || 0)} SF</div>
    </div>`;
  }

  if (loan.index_name) {
    html += `<div class="context-block">
      <div class="context-label">Known Lender</div>
      <div class="context-value">${esc(loan.index_name)}</div>
      <div class="context-sub">${loan.loan_amount ? fmt(loan.loan_amount) : ''} ${loan.loan_type ? '· ' + esc(loan.loan_type) : ''}</div>
    </div>`;
  }

  html += '</div>';

  // ────────────────────────────────────────────────────────────
  // FORM PANEL (RIGHT) - 5-STEP GUIDED WORKFLOW
  // ────────────────────────────────────────────────────────────
  html += '<div class="research-form">';

  // Completeness bar
  const allFields = [rec.square_feet, rec.recorded_owner, rec.true_owner, loan.index_name, rec.annual_rent];
  const completeness = computeCompleteness(allFields.map((v, i) => ({ value: v, required: [1, 2].includes(i) })));
  html += renderCompletenessBar(completeness);

  // Step navigation
  const steps = [
    {label: 'Transaction', complete: false},
    {label: 'Ownership', complete: !!(rec.recorded_owner || rec.true_owner)},
    {label: 'Property', complete: !!rec.square_feet},
    {label: 'Financing', complete: !!loan.index_name},
    {label: 'Valuation', complete: !!rec.annual_rent}
  ];
  html += renderStepNav(govResearchStep, steps, 'window.govStepNav');

  // ──── STEP 0: TRANSACTION ────
  html += `<div class="form-step${govResearchStep === 0 ? ' active' : ''}">`;
  html += '<div class="form-step-head"><span class="step-num">1</span> Transaction</div>';
  html += guidedField('res-lead-sale-date', 'Sale Date', '', {type:'date'});
  html += guidedField('res-lead-sale-price', 'Sale Price', '', {type:'number', placeholder:'e.g. 5000000'});
  html += guidedField('res-lead-cap-rate', 'Cap Rate (%)', '', {type:'number', step:'0.01', placeholder:'e.g. 6.25'});
  html += guidedField('res-lead-price-source', 'Price Source', '', {placeholder:'CoStar, County Records, etc.'});
  html += guidedField('res-lead-buyer', 'Buyer', '', {placeholder:'Purchasing entity'});
  html += guidedField('res-lead-seller', 'Seller', rec.lessor_name || '', {placeholder:'Selling entity'});
  html += '</div>';

  // ──── STEP 1: OWNERSHIP ────
  html += `<div class="form-step${govResearchStep === 1 ? ' active' : ''}">`;
  html += '<div class="form-step-head"><span class="step-num">2</span> Ownership</div>';
  html += guidedField('res-lead-recorded-owner', 'Recorded Owner', rec.recorded_owner || '', {placeholder:'From deed / public records'});
  html += guidedField('res-lead-true-owner', 'True Owner / Parent', rec.true_owner || '', {placeholder:'Beneficial owner'});
  html += guidedField('res-lead-incorporation', 'State of Incorporation', rec.state_of_incorporation || '', {placeholder:'e.g. DE'});
  html += guidedField('res-lead-owner-type', 'Owner Type', '', {
    options: [{value:'Private', label:'Private'}, {value:'Institutional', label:'Institutional'}, {value:'REIT', label:'REIT'}, {value:'Government', label:'Government'}, {value:'Non-Profit', label:'Non-Profit'}, {value:'SPE / LLC', label:'SPE / LLC'}]
  });
  html += guidedField('res-lead-principal-names', 'Principal Names', rec.principal_names || '', {placeholder:'CEO, Managing Member, etc.'});
  html += guidedField('res-lead-principal-email', 'Contact Email', '', {type:'email', placeholder:'contact@example.com'});
  html += guidedField('res-lead-phone', 'Phone', rec.phone_2 || '', {placeholder:'(555) 123-4567'});
  html += guidedField('res-lead-mailing', 'Mailing Address', '', {});
  html += guidedField('res-lead-mailing-2', 'Mailing Address 2', '', {});
  html += '<div class="quick-actions">';
  html += searchBtn('Google Search', `${rec.lessor_name} ${rec.address}`);
  html += sosBtns(rec.state, rec.state_of_incorporation);
  html += countyBtns(rec.city, rec.state);
  html += '</div>';
  html += '</div>';

  // ──── STEP 2: PROPERTY ────
  html += `<div class="form-step${govResearchStep === 2 ? ' active' : ''}">`;
  html += '<div class="form-step-head"><span class="step-num">3</span> Property</div>';
  html += guidedField('res-lead-rba', 'RBA (Rentable Building Area)', rec.square_feet || '', {type:'number', placeholder:'SF'});
  html += guidedField('res-lead-land-acres', 'Land Size (Acres)', '', {type:'number', step:'0.01'});
  html += guidedField('res-lead-year-built', 'Year Built', '', {type:'number', placeholder:'YYYY'});
  html += guidedField('res-lead-year-renovated', 'Year Renovated', '', {type:'number', placeholder:'YYYY'});
  html += guidedField('res-lead-building-class', 'Building Class', '', {
    options: [{value:'A', label:'Class A'}, {value:'B', label:'Class B'}, {value:'C', label:'Class C'}]
  });
  html += guidedField('res-lead-stories', 'Stories / Floors', '', {type:'number'});
  html += guidedField('res-lead-parking', 'Parking Spaces', '', {type:'number'});
  html += guidedField('res-lead-zoning', 'Zoning', '', {placeholder:'e.g. C-2, Industrial'});
  html += guidedField('res-lead-condition', 'Property Condition', '', {
    options: [{value:'Excellent', label:'Excellent'}, {value:'Good', label:'Good'}, {value:'Average', label:'Average'}, {value:'Fair', label:'Fair'}, {value:'Poor', label:'Poor'}]
  });
  html += '</div>';

  // ──── STEP 3: FINANCING ────
  html += `<div class="form-step${govResearchStep === 3 ? ' active' : ''}">`;
  html += '<div class="form-step-head"><span class="step-num">4</span> Financing</div>';
  html += guidedField('res-lead-lender', 'Lender', loan.index_name || '', {placeholder:'Bank or fund name', source: loan.index_name ? 'loan records' : null});
  html += guidedField('res-lead-loan-amount', 'Loan Amount', loan.loan_amount || '', {type:'number', source: loan.loan_amount ? 'loan records' : null});
  html += guidedField('res-lead-interest-rate', 'Interest Rate (%)', loan.interest_rate_percent || '', {type:'number', step:'0.01'});
  html += guidedField('res-lead-loan-type', 'Loan Type', '', {
    options: [{value:'Fixed', label:'Fixed'}, {value:'Variable', label:'Variable'}, {value:'Bridge', label:'Bridge'}, {value:'CMBS', label:'CMBS'}, {value:'Agency', label:'Agency'}, {value:'Construction', label:'Construction'}, {value:'SBA', label:'SBA'}, {value:'Other', label:'Other'}]
  });
  html += guidedField('res-lead-loan-orig', 'Origination Date', loan.origination_date ? loan.origination_date.substring(0, 10) : '', {type:'date'});
  html += guidedField('res-lead-loan-maturity', 'Maturity Date', loan.maturity_date ? loan.maturity_date.substring(0, 10) : '', {type:'date'});
  html += guidedField('res-lead-ltv', 'LTV (%)', loan.loan_to_value || '', {type:'number', step:'0.01'});
  html += guidedField('res-lead-recourse', 'Recourse', '', {
    options: [{value:'Recourse', label:'Recourse'}, {value:'Non-Recourse', label:'Non-Recourse'}, {value:'Partial', label:'Partial'}]
  });
  html += '</div>';

  // ──── STEP 4: VALUATION & NOTES ────
  html += `<div class="form-step${govResearchStep === 4 ? ' active' : ''}">`;
  html += '<div class="form-step-head"><span class="step-num">5</span> Valuation & Notes</div>';
  html += guidedField('res-lead-annual-rent', 'Annual Rent / NOI', rec.annual_rent || '', {type:'number'});
  html += guidedField('res-lead-rent-psf', 'Rent Per SF ($/SF)', '', {type:'number', step:'0.01'});
  html += guidedField('res-lead-expense-type', 'Expense Type', '', {
    options: [{value:'NNN', label:'NNN'}, {value:'Modified Gross', label:'Modified Gross'}, {value:'Full Service Gross', label:'Full Service Gross'}, {value:'Industrial Gross', label:'Industrial Gross'}, {value:'Ground Lease', label:'Ground Lease'}]
  });
  html += guidedField('res-lead-est-value', 'Estimated Property Value', rec.estimated_value || '', {type:'number'});
  html += guidedField('res-lead-current-cap', 'Current Cap Rate (%)', '', {type:'number', step:'0.01'});
  html += guidedField('res-lead-quick-status', 'Quick Status', '', {
    options: [{value:'new_lead', label:'New Lead'}, {value:'researching', label:'Researching'}, {value:'contacted', label:'Contacted'}, {value:'meeting_set', label:'Meeting Set'}, {value:'proposal_sent', label:'Proposal Sent'}, {value:'not_for_sale', label:'Not For Sale'}, {value:'dead', label:'Dead'}]
  });
  html += guidedField('res-lead-notes', 'Research Notes', rec.research_notes || '', {type:'textarea', rows:4, placeholder:'Key findings, data sources, observations...'});
  html += guidedField('res-lead-source', 'Research Source', '', {placeholder:'CoStar, County, Call, Loopnet'});
  html += guidedField('res-lead-date', 'Research Date', new Date().toISOString().substring(0, 10), {type:'date'});
  html += '</div>';

  html += '</div>';

  // ────────────────────────────────────────────────────────────
  // ACTION ROW
  // ────────────────────────────────────────────────────────────
  html += '<div class="action-row">';
  if (govResearchStep > 0) {
    html += `<button class="btn-action" onclick="govStepNav(${govResearchStep - 1})">← Back</button>`;
  }
  if (govResearchStep < 4) {
    html += `<button class="btn-action primary" onclick="govStepNav(${govResearchStep + 1})">Next →</button>`;
  } else {
    html += `<button class="btn-action" onclick="_udBtnGuard(this, researchSaveInPlace)">Save</button>`;
    html += `<button class="btn-action primary" onclick="_udBtnGuard(this, researchSave)">Save & Next</button>`;
  }
  html += `<button class="btn-action" onclick="researchNav(1,true)">Skip</button>`;
  html += `<button class="btn-action" onclick="_udActionBtnGuard(this, researchMark, 'na')">N/A</button>`;
  html += '</div>';

  html += '</div>';

  return html;
}

function renderIntelResearchCard(rec) {
  // Track record changes to reset step and clear draft
  if (window._govLastRecId !== (rec.property_id)) {
    govResearchStep = 0;
    window._govLastRecId = rec.property_id;
    window._govFormDraft = {};
  }

  // Defensive: annotate even if the row didn't pass through the loader
  // (e.g. when the queue is rebuilt mid-session).
  if (rec._priority == null) govIntelAnnotate(rec);

  const snapshot = rec.gsa_snapshot || {};
  const frpp = rec.frpp || {};
  const loan = rec._loan || (govData.loans || []).find(l => l.property_id === rec.property_id) || {};

  let html = '<div class="research-card own-research-card">';

  // ────────────────────────────────────────────────────────────
  // LEFT — research-first read view. The reviewer ingests via the
  // LCC Chrome sidebar against CoStar / county pages in another tab,
  // so the manual entry form on the right is collapsed by default.
  // ────────────────────────────────────────────────────────────
  html += '<div class="research-context">';

  html += '<div class="task-header">';
  html += '<div>Intel Research</div>';
  html += `<span class="task-badge ${esc(rec._priorityClass || 'ready')}">${esc(rec._priorityLabel || 'Review')}</span>`;
  html += '</div>';
  if (rec._priorityHint) {
    html += `<div class="own-priority-sub">${esc(rec._priorityHint)}${rec._completeness != null ? ' · ' + rec._completeness + '% complete' : ''}</div>`;
  }

  // Property header (address + city/state/zip + facts row)
  const _addr = rec.address || frpp.street_address || '';
  const _city = rec.city || frpp.city_name || '';
  const _state = rec.state || frpp.state_name || '';
  const _zip = rec.zip_code || '';
  const _isStub = !_addr && !rec.lease_number && !rec.firm_term_remaining && !rec.assessed_owner;
  const tenant = rec.agency_full_name || rec.agency || frpp.using_agency || frpp.using_bureau || '';
  html += '<div class="context-block">';
  html += '<div class="context-label">Property</div>';
  if (_isStub) {
    html += '<div class="context-value own-empty-shell">No research handle on this row</div>';
    html += '<div class="context-sub">Use <strong>Mark stub</strong> below or the <em>Sweep auto-resolvable</em> button.</div>';
  } else {
    html += `<div class="context-value">${esc(_addr || '—')}</div>`;
    const cityState = [_city, _state].filter(Boolean).join(', ') + (_zip ? ' ' + _zip : '');
    if (cityState.trim()) html += `<div class="context-sub">${esc(cityState)}</div>`;
    const _facts = [];
    if (rec.rba)        _facts.push(fmtN(rec.rba) + ' SF RBA');
    else if (rec.sf_leased) _facts.push(fmtN(rec.sf_leased) + ' SF leased');
    if (rec.year_built) _facts.push('Built ' + esc(rec.year_built));
    if (tenant)         _facts.push(esc(tenant));
    if (_facts.length) html += `<div class="own-facts-row">${_facts.join(' · ')}</div>`;
  }
  html += '</div>';

  // Lease + sale signal block — what we already know vs. what's missing
  html += '<div class="context-block own-sale-block">';
  html += '<div class="context-label">Lease &amp; Income</div>';
  html += '<dl class="own-kv">';
  html += '<dt>Lease #</dt><dd>' + (rec.lease_number ? '<code>' + esc(rec.lease_number) + '</code>' : '<span class="own-blank">—</span>') + '</dd>';
  if (snapshot.lease_effective || rec.lease_commencement) {
    const start = (snapshot.lease_effective || rec.lease_commencement || '').substring(0, 10);
    const end   = (snapshot.lease_expiration || rec.lease_expiration || '').substring(0, 10);
    html += '<dt>Term</dt><dd>' + esc(start || '—') + ' → ' + esc(end || '—') + '</dd>';
  }
  if (rec.firm_term_remaining !== null && rec.firm_term_remaining !== undefined) {
    const yrs = Number(rec.firm_term_remaining).toFixed(1);
    const cls = rec._termWindow === 'expired' ? 'own-term-expired'
              : rec._termWindow === '<2y'     ? 'own-term-hot'
              : rec._termWindow === '2-5y'    ? 'own-term-warm'
              : '';
    html += '<dt>Firm rem.</dt><dd class="' + cls + '">' + yrs + ' yrs</dd>';
  }
  html += '<dt>Gross rent</dt><dd>' + (rec.gross_rent ? fmt(rec.gross_rent) + '/yr' : '<span class="own-blank">—</span>') + '</dd>';
  html += '<dt>NOI</dt><dd>' + (rec.noi ? fmt(rec.noi) + '/yr' : '<span class="own-blank">—</span>') + '</dd>';
  html += '<dt>Est. value</dt><dd>' + (rec.estimated_value ? fmt(rec.estimated_value) : '<span class="own-blank">—</span>') + '</dd>';
  html += '</dl>';
  if (rec._missingFields && rec._missingFields.length) {
    html += `<div class="own-missing">Missing: ${rec._missingFields.map(esc).join(', ')}</div>`;
  }
  html += '</div>';

  // Owners side-by-side: Recorded vs True vs Assessed (county). Assessed
  // gets its own column when present so the reviewer can sanity-check
  // against the deed-level record without leaving the card.
  html += '<div class="own-owners-grid own-owners-grid-3">';
  html += '<div class="own-owners-col-head">Recorded <span class="own-owners-col-sub">(deed)</span></div>';
  html += '<div class="own-owners-col-head">True <span class="own-owners-col-sub">(beneficial)</span></div>';
  html += '<div class="own-owners-col-head">County <span class="own-owners-col-sub">(assessor / latest deed)</span></div>';

  // Recorded
  html += '<div class="own-owners-cell">';
  if (rec.recorded_owner_id || rec.recorded_owner_name) {
    html += `<div class="own-owners-flow"><div class="own-owners-new"><span class="own-owners-tag own-owners-tag-new">Linked</span> ${esc(rec.recorded_owner_name || ('owner #' + rec.recorded_owner_id))}</div></div>`;
  } else {
    html += '<div class="own-owners-flow own-owners-empty">— sidebar / county lookup needed —</div>';
  }
  html += '</div>';

  // True
  html += '<div class="own-owners-cell">';
  if (rec.true_owner_id || rec.true_owner_name) {
    html += `<div class="own-owners-flow"><div class="own-owners-new"><span class="own-owners-tag own-owners-tag-new">Linked</span> ${esc(rec.true_owner_name || ('owner #' + rec.true_owner_id))}</div></div>`;
  } else {
    html += '<div class="own-owners-flow own-owners-empty">— SOS / SPE chain needed —</div>';
  }
  html += '</div>';

  // County / assessor
  html += '<div class="own-owners-cell">';
  if (rec.assessed_owner || rec.latest_deed_grantee) {
    if (rec.assessed_owner) {
      html += `<div class="own-owners-detail"><span class="own-owners-tag">Assessor</span> ${esc(rec.assessed_owner)}</div>`;
    }
    if (rec.latest_deed_grantee && rec.latest_deed_grantee !== rec.assessed_owner) {
      html += `<div class="own-owners-detail"><span class="own-owners-tag">Latest deed</span> ${esc(rec.latest_deed_grantee)}${rec.latest_deed_date ? ' <span style="color:var(--text3)">' + esc(String(rec.latest_deed_date).substring(0, 10)) + '</span>' : ''}</div>`;
    }
    if (rec.latest_sale_price) {
      html += `<div class="own-owners-detail">Latest sale: <strong>${fmt(rec.latest_sale_price)}</strong></div>`;
    }
  } else {
    html += '<div class="own-owners-flow own-owners-empty">— no county data on file —</div>';
  }
  html += '</div>';
  html += '</div>'; // own-owners-grid

  // Investment-quality strip (helps the reviewer prioritise without scrolling)
  if (rec.deal_grade || rec.investment_score || rec.location_tier || rec.agency_risk_level) {
    html += '<div class="context-block">';
    html += '<div class="context-label">Investment quality</div>';
    const parts = [];
    if (rec.deal_grade)        parts.push('<span class="own-grade-pill own-grade-' + esc(String(rec.deal_grade).toLowerCase()) + '">' + esc(rec.deal_grade) + '</span>');
    if (rec.investment_score)  parts.push('<span>score ' + esc(rec.investment_score) + '</span>');
    if (rec.location_tier)     parts.push('<span>' + esc(rec.location_tier) + '</span>');
    if (rec.agency_risk_level) parts.push('<span>risk ' + esc(rec.agency_risk_level) + '</span>');
    html += '<div class="own-quality-row">' + parts.join(' · ') + '</div>';
    html += '</div>';
  }

  // Sidebar tip — make the workflow expectation explicit
  html += '<div class="own-sidebar-tip">';
  html += '<span class="own-sidebar-tip-icon">📎</span>';
  html += '<span>Capture from CoStar / county records via the <strong>LCC sidebar</strong> (Chrome) — values land here automatically. Use the manual form on the right only when no source page is available.</span>';
  html += '</div>';

  if (loan.index_name) {
    html += `<div class="context-block">
      <div class="context-label">Known lender</div>
      <div class="context-value">${esc(loan.index_name)}</div>
      <div class="context-sub">${loan.loan_amount ? fmt(loan.loan_amount) : ''} ${loan.loan_type ? '· ' + esc(loan.loan_type) : ''}</div>
    </div>`;
  }

  html += '</div>';

  // ────────────────────────────────────────────────────────────
  // RIGHT — research-first action surface. Same sidebar-first pattern
  // as the Ownership card: primary action buttons up top, manual form
  // collapsed by default (Round 76em).
  // ────────────────────────────────────────────────────────────
  html += '<div class="research-form">';

  // Completeness bar — representative fields from each step
  const allFields = [
    { value: rec.rba, required: true },                       // Property
    { value: rec.recorded_owner_id || rec.assessed_owner, required: true }, // Ownership
    { value: loan.index_name, required: false },              // Financing
    { value: rec.gross_rent || rec.noi, required: false },    // Valuation
    { value: rec.year_built, required: false },               // Property
    { value: rec.true_owner_id, required: false },            // Ownership
    { value: loan.loan_amount, required: false },             // Financing
    { value: rec.estimated_value, required: false }           // Valuation
  ];
  const completeness = computeCompleteness(allFields);
  html += renderCompletenessBar(completeness);

  const _formOpen = !!window._govIntelFormOpen;
  html += '<details class="own-manual-details"' + (_formOpen ? ' open' : '') + ' ontoggle="window._govIntelFormOpen=this.open">';
  html += '<summary class="own-manual-summary">';
  html += '<span class="own-manual-summary-icon">✏️</span>';
  html += '<span class="own-manual-summary-label">Edit fields manually</span>';
  html += '<span class="own-manual-summary-hint">— sidebar capture preferred; open only when no source page is available</span>';
  html += '</summary>';

  // Step navigation
  const steps = [
    {label: 'Transaction', complete: false},
    {label: 'Property', complete: !!rec.rba},
    {label: 'Ownership', complete: !!(rec.recorded_owner_id || rec.assessed_owner)},
    {label: 'Financing', complete: !!loan.index_name},
    {label: 'Valuation', complete: !!(rec.gross_rent || rec.noi)}
  ];
  html += renderStepNav(govResearchStep, steps, 'window.govStepNav');

  // ──── STEP 0: TRANSACTION ────
  html += `<div class="form-step${govResearchStep === 0 ? ' active' : ''}">`;
  html += '<div class="form-step-head"><span class="step-num">1</span> Transaction</div>';
  html += guidedField('res-intel-sale-date', 'Sale Date', '', {type:'date'});
  html += guidedField('res-intel-sale-price', 'Sale Price', '', {type:'number', placeholder:'e.g. 5000000'});
  html += guidedField('res-intel-cap-rate', 'Cap Rate (%)', '', {type:'number', step:'0.01', placeholder:'e.g. 6.25'});
  html += guidedField('res-intel-price-source', 'Price Source', '', {placeholder:'CoStar, County Records, etc.'});
  html += guidedField('res-intel-buyer', 'Buyer', '', {placeholder:'Purchasing entity'});
  html += guidedField('res-intel-seller', 'Seller', '', {placeholder:'Selling entity'});
  html += '</div>';

  // ──── STEP 1: PROPERTY ────
  html += `<div class="form-step${govResearchStep === 1 ? ' active' : ''}">`;
  html += '<div class="form-step-head"><span class="step-num">2</span> Property</div>';
  html += guidedField('res-intel-rba', 'RBA (Rentable Building Area)', rec.rba || '', {type:'number', placeholder:'SF'});
  html += guidedField('res-intel-land-acres', 'Land Size (Acres)', rec.land_acres || '', {type:'number', step:'0.01'});
  html += guidedField('res-intel-year-built', 'Year Built', rec.year_built || '', {type:'number', placeholder:'YYYY'});
  html += guidedField('res-intel-year-renovated', 'Year Renovated', rec.year_renovated || '', {type:'number', placeholder:'YYYY'});
  html += guidedField('res-intel-building-class', 'Building Class', '', {
    options: [{value:'A', label:'Class A'}, {value:'B', label:'Class B'}, {value:'C', label:'Class C'}]
  });
  html += guidedField('res-intel-stories', 'Stories / Floors', rec.stories || '', {type:'number'});
  html += guidedField('res-intel-parking', 'Parking Spaces', rec.parking_spaces || '', {type:'number'});
  html += guidedField('res-intel-zoning', 'Zoning', rec.zoning || '', {placeholder:'e.g. C-2, Industrial'});
  html += guidedField('res-intel-condition', 'Property Condition', '', {
    options: [{value:'Excellent', label:'Excellent'}, {value:'Good', label:'Good'}, {value:'Average', label:'Average'}, {value:'Fair', label:'Fair'}, {value:'Poor', label:'Poor'}]
  });
  html += '</div>';

  // ──── STEP 2: OWNERSHIP ────
  html += `<div class="form-step${govResearchStep === 2 ? ' active' : ''}">`;
  html += '<div class="form-step-head"><span class="step-num">3</span> Ownership</div>';
  html += guidedField('res-intel-recorded-owner', 'Recorded Owner', rec.recorded_owner || rec.lessor_name || '', {placeholder:'From deed / public records'});
  html += guidedField('res-intel-true-owner', 'True Owner / Parent', rec.true_owner || '', {placeholder:'Beneficial owner'});
  html += guidedField('res-intel-incorp-state', 'State of Incorporation', '', {placeholder:'e.g. DE'});
  html += guidedField('res-intel-owner-type', 'Owner Type', '', {
    options: [{value:'Private', label:'Private'}, {value:'Institutional', label:'Institutional'}, {value:'REIT', label:'REIT'}, {value:'Government', label:'Government'}, {value:'Non-Profit', label:'Non-Profit'}, {value:'SPE / LLC', label:'SPE / LLC'}]
  });
  html += guidedField('res-intel-principals', 'Principal Names', '', {placeholder:'CEO, Managing Member, etc.'});
  html += guidedField('res-intel-email', 'Contact Email', '', {type:'email', placeholder:'contact@example.com'});
  html += guidedField('res-intel-phone', 'Contact Phone', '', {placeholder:'(555) 123-4567'});
  html += guidedField('res-intel-mailing', 'Mailing Address', '', {});
  html += '<div class="quick-actions">';
  html += searchBtn('Google Search', `${rec.address} ${rec.city} ${rec.state}`);
  html += sosBtns(rec.state, null);
  html += countyBtns(rec.city, rec.state);
  html += '</div>';
  html += '</div>';

  // ──── STEP 3: FINANCING ────
  html += `<div class="form-step${govResearchStep === 3 ? ' active' : ''}">`;
  html += '<div class="form-step-head"><span class="step-num">4</span> Financing</div>';
  html += guidedField('res-intel-lender', 'Lender', loan.index_name || '', {placeholder:'Bank or fund name', source: loan.index_name ? 'loan records' : null});
  html += guidedField('res-intel-loan-amount', 'Loan Amount', loan.loan_amount || '', {type:'number', source: loan.loan_amount ? 'loan records' : null});
  html += guidedField('res-intel-interest-rate', 'Interest Rate (%)', loan.interest_rate_percent || '', {type:'number', step:'0.01'});
  html += guidedField('res-intel-loan-type', 'Loan Type', '', {
    options: [{value:'Fixed', label:'Fixed'}, {value:'Variable', label:'Variable'}, {value:'Bridge', label:'Bridge'}, {value:'CMBS', label:'CMBS'}, {value:'Agency', label:'Agency'}, {value:'Construction', label:'Construction'}, {value:'SBA', label:'SBA'}, {value:'Other', label:'Other'}]
  });
  html += guidedField('res-intel-loan-orig', 'Origination Date', loan.origination_date ? loan.origination_date.substring(0, 10) : '', {type:'date'});
  html += guidedField('res-intel-loan-maturity', 'Maturity Date', loan.maturity_date ? loan.maturity_date.substring(0, 10) : '', {type:'date'});
  html += guidedField('res-intel-ltv', 'LTV (%)', loan.loan_to_value || '', {type:'number', step:'0.01'});
  html += guidedField('res-intel-recourse', 'Recourse', '', {
    options: [{value:'Recourse', label:'Recourse'}, {value:'Non-Recourse', label:'Non-Recourse'}, {value:'Partial', label:'Partial'}]
  });
  html += '</div>';

  // ──── STEP 4: VALUATION & NOTES ────
  html += `<div class="form-step${govResearchStep === 4 ? ' active' : ''}">`;
  html += '<div class="form-step-head"><span class="step-num">5</span> Valuation & Notes</div>';
  html += guidedField('res-intel-annual-rent', 'Annual Rent / NOI', rec.last_known_rent || rec.gross_rent || '', {type:'number'});
  html += guidedField('res-intel-rent-psf', 'Rent Per SF ($/SF)', rec.gross_rent_psf || '', {type:'number', step:'0.01'});
  html += guidedField('res-intel-expense-type', 'Expense Type', '', {
    options: [{value:'NNN', label:'NNN'}, {value:'Modified Gross', label:'Modified Gross'}, {value:'Full Service Gross', label:'Full Service Gross'}, {value:'Industrial Gross', label:'Industrial Gross'}, {value:'Ground Lease', label:'Ground Lease'}]
  });
  html += guidedField('res-intel-est-value', 'Estimated Property Value', rec.current_value_estimate || '', {type:'number'});
  html += guidedField('res-intel-current-cap', 'Current Cap Rate (%)', '', {type:'number', step:'0.01'});
  html += guidedField('res-intel-notes', 'Research Notes', '', {type:'textarea', rows:4, placeholder:'Key findings, observations, data sources...'});
  html += guidedField('res-intel-source', 'Research Source', '', {placeholder:'CoStar, County, Call, etc.'});
  html += guidedField('res-intel-date', 'Research Date', new Date().toISOString().substring(0, 10), {type:'date'});
  html += '</div>';

  // Manual-form internal action row (Back / Next / Save) — only shows
  // when the reviewer opens the <details>.
  html += '<div class="action-row own-manual-action-row">';
  if (govResearchStep > 0) {
    html += `<button class="btn-action" onclick="govStepNav(${govResearchStep - 1})">← Back</button>`;
  }
  if (govResearchStep < 4) {
    html += `<button class="btn-action" onclick="govStepNav(${govResearchStep + 1})">Next →</button>`;
  }
  html += `<button class="btn-action primary" onclick="_udBtnGuard(this, researchSaveInPlace)">Save manual edits</button>`;
  html += `<button class="btn-action" onclick="_udBtnGuard(this, researchSave)">Save &amp; Next</button>`;
  html += '</div>';

  html += '</details>'; // own-manual-details

  // ────────────────────────────────────────────────────────────
  // PRIMARY ACTION ROW — research-driven decisions, always visible.
  // ────────────────────────────────────────────────────────────
  html += '<div class="action-row own-primary-actions">';
  if (_isStub) {
    html += `<button class="btn-action primary" title="No research handle — clear from queue" onclick="_udActionBtnGuard(this, researchMark, 'junk_no_data')">⊘ Mark stub</button>`;
  } else {
    html += `<button class="btn-action primary" title="Intel research complete — mark resolved" onclick="_udActionBtnGuard(this, researchMark, 'approve')">✓ Approve</button>`;
  }
  html += `<button class="btn-action danger" title="Out of scope / not actionable" onclick="_udActionBtnGuard(this, researchMark, 'reject')">✗ Reject</button>`;
  html += `<button class="btn-action" onclick="researchNav(1,true)" title="Skip to next">→ Skip</button>`;
  html += `<button class="btn-action" onclick="_udActionBtnGuard(this, researchMark, 'spe_rename')" title="Same true owner, different SPE">↻ SPE Rename</button>`;
  html += `<button class="btn-action" onclick="_udActionBtnGuard(this, researchMark, 'na')" title="Not applicable">N/A</button>`;
  html += '</div>';

  html += '</div>'; // research-form
  html += '</div>'; // research-card

  return html;
}

function renderResearchInner() {
  const rec = researchQueue[researchIdx];
  const progress = Math.round((researchIdx / researchQueue.length) * 100);

  let html = '';

  // Progress bar
  html += `<div class="research-progress">
    <div class="progress-bar" style="width: ${progress}%"></div>
    <div class="progress-text">${researchIdx + 1} / ${researchQueue.length}</div>
  </div>`;

  // Keyboard shortcut hints
  html += '<div style="display:flex;gap:10px;justify-content:flex-end;margin-bottom:8px;font-size:10px;color:var(--text3)">';
  html += '<span><kbd style="padding:1px 4px;border:1px solid var(--border);border-radius:3px;background:var(--s2);font-family:monospace">N</kbd> Next</span>';
  html += '<span><kbd style="padding:1px 4px;border:1px solid var(--border);border-radius:3px;background:var(--s2);font-family:monospace">B</kbd> Back</span>';
  html += '<span><kbd style="padding:1px 4px;border:1px solid var(--border);border-radius:3px;background:var(--s2);font-family:monospace">S</kbd> Save (stay)</span>';
  html += '<span><kbd style="padding:1px 4px;border:1px solid var(--border);border-radius:3px;background:var(--s2);font-family:monospace">K</kbd> Skip</span>';
  html += '</div>';

  // Render card
  if (researchMode === 'ownership') {
    html += renderOwnershipResearchCard(rec);
  } else if (researchMode === 'intel') {
    html += renderIntelResearchCard(rec);
  } else {
    html += renderLeadResearchCard(rec);
  }

  return html;
}

let _researchSaving = false;

/** Save current record in-place (no advance). Used by "S" shortcut. */
async function researchSaveInPlace() {
  if (_researchSaving) { showToast('Save already in progress', 'info'); return; }
  // Capture draft so values from all subtabs are available for save
  if (researchMode === 'ownership') captureOwnershipDraft();
  const rec = researchQueue[researchIdx];
  if (!rec) { showToast('No record to save', 'error'); return; }
  _researchSaving = true;

  let success = true;
  try {
    if (researchMode === 'ownership') {
      success = (await saveOwnership(rec)) !== false;
    } else if (researchMode === 'intel') {
      success = (await saveIntel(rec)) !== false;
    } else {
      success = (await saveLead(rec)) !== false;
    }
  } catch (err) {
    console.error('researchSaveInPlace error:', err);
    showToast('Save failed: ' + err.message, 'error');
    _researchSaving = false;
    return;
  }

  _researchSaving = false;
  if (success) {
    showToast('Saved — staying on current record', 'success');
    window._govFormDraft = {};  // Clear draft after successful save
  }
}
window.researchSaveInPlace = researchSaveInPlace;

async function researchSave() {
  if (_researchSaving) { showToast('Save already in progress', 'info'); return; }
  const rec = researchQueue[researchIdx];
  if (!rec) { showToast('No record to save', 'error'); return; }
  _researchSaving = true;

  const saveBtn = q('[data-save-research]') || q('.research-card button.save-btn') || q('.research-card button[onclick*="researchSave"]');
  if (saveBtn) { saveBtn.disabled = true; saveBtn.dataset.origText = saveBtn.textContent; saveBtn.textContent = 'Saving\u2026'; }

  let success = true;
  try {
    if (researchMode === 'ownership') {
      success = (await saveOwnership(rec)) !== false;
    } else if (researchMode === 'intel') {
      success = (await saveIntel(rec)) !== false;
    } else {
      success = (await saveLead(rec)) !== false;
    }
  } catch (err) {
    console.error('researchSave error:', err);
    showToast('Save failed: ' + err.message + ' \u2014 please retry or skip', 'error');
    if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = saveBtn.dataset.origText || 'Save & Next'; }
    _researchSaving = false;
    return;
  }

  if (!success) { if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = saveBtn.dataset.origText || 'Save & Next'; } _researchSaving = false; return; }

  researchCompleted++;
  researchQueue.splice(researchIdx, 1);
  // Don't increment — splice shifts next item into current index
  _researchSaving = false;

  if (researchIdx >= researchQueue.length) {
    renderGovTab();
    showToast('Research queue complete! All items reviewed.', 'success');
  } else {
    showToast('Saved \u2014 advancing to next item (' + researchIdx + '/' + researchQueue.length + ')', 'success');
    renderGovTab();
  }
}

async function saveOwnership(rec) {
  // Helper: get value from visible DOM or from draft state (for fields on non-visible subtabs)
  var _d = window._govFormDraft || {};
  function _fv(id) { var el = q('#' + id); return (el && el.value) ? el.value : (_d[id] || null); }

  const saleDate = _fv('res-own-sale-date');
  const salePrice = _pf(q('#res-own-sale-price')) || (_d['res-own-sale-price'] ? parseFloat(_d['res-own-sale-price']) : null);
  const capRate = _pf(q('#res-own-cap-rate')) || (_d['res-own-cap-rate'] ? parseFloat(_d['res-own-cap-rate']) : null);
  const buyer = _fv('res-own-buyer');
  const seller = _fv('res-own-seller');

  const recordedOwner = _fv('res-own-recorded-owner');
  const trueOwner = _fv('res-own-true-owner');
  const researchNotes = _fv('res-own-notes');

  // Validate that at least one field is populated
  const _anyOwnField = [saleDate, salePrice, capRate, buyer, seller, recordedOwner, trueOwner, researchNotes].some(v => v !== null && v !== undefined && String(v).trim() !== '');
  if (!_anyOwnField) { showToast('Please fill in at least one field before saving', 'info'); return; }

  // Use Gov write service for ownership updates
  const propertyId = rec.matched_property_id || rec.property_id;
  let writeResult = null;
  if (propertyId) {
    try {
      writeResult = await govWriteService('ownership', {
        property_id: propertyId,
        recorded_owner: recordedOwner,
        true_owner: trueOwner,
        owner_type: null
      });
    } catch (err) {
      console.error('Gov ownership write service error:', err);
      showToast('Error saving ownership via write service: ' + err.message, 'error');
    }
  }

  // ownership_history is not a write-service-protected table — patch directly for
  // sale price, cap rate, and other research fields that live on the history row
  let _partialWarnings = [];
  try {
    await patchRecord('ownership_history', 'ownership_id', rec.ownership_id, {
      sale_date: saleDate,
      sale_price: salePrice,
      cap_rate: capRate,
      buyer: buyer,
      seller: seller,
      recorded_owner_name: recordedOwner,
      state_of_incorporation: _fv('res-own-incorporation'),
      recorded_owner_phone: _fv('res-own-phone'),
      recorded_owner_address: _fv('res-own-mailing'),
      true_owner_name: trueOwner,
      principal_names: _fv('res-own-principal-names'),
      phone_2: _fv('res-own-phone-2'),
      mailing_address_2: _fv('res-own-mailing-2'),
      rba: _pf(q('#res-own-rba')) || (_d['res-own-rba'] ? parseFloat(_d['res-own-rba']) : null),
      land_acres: _pf(q('#res-own-land-acres')) || (_d['res-own-land-acres'] ? parseFloat(_d['res-own-land-acres']) : null),
      year_built: _py(q('#res-own-year-built')) ?? _py(_d['res-own-year-built']),
      year_renovated: _py(q('#res-own-year-renovated')) ?? _py(_d['res-own-year-renovated']),
      research_notes: researchNotes,
      research_status: 'completed',
      evidence_artifact_id: (typeof govEvidenceState !== 'undefined' && govEvidenceState.artifactId) ? govEvidenceState.artifactId : null
    });
  } catch (err) {
    console.error('Ownership history patch error:', err);
    _partialWarnings.push('ownership history');
  }

  // Bridge to canonical model with gov change metadata
  canonicalBridge('save_ownership', {
    domain: 'government',
    external_id: String(propertyId || rec.ownership_id),
    source_system: 'gov',
    source_type: 'asset',
    owner_name: recordedOwner,
    true_owner_name: trueOwner,
    notes: researchNotes,
    gov_change_event_id: writeResult?.change_event_id || null,
    gov_correlation_id: writeResult?.correlation_id || null,
    source_record_id: propertyId,
    source_table: 'properties'
  });

  // Ensure canonical entity link exists for this gov property
  if (propertyId) {
    canonicalBridge('update_entity', {
      external_id: String(propertyId),
      source_system: 'gov',
      source_type: 'asset',
      fields: {
        name: rec.address || rec.property_name || `Government Property ${propertyId}`,
        address: rec.address || null,
        city: rec.city || null,
        state: rec.state || null,
        asset_type: 'government_leased'
      }
    });
  }

  if (salePrice || capRate) {
    try { await saveLoanFields(rec); } catch (err) { console.error('Loan fields save error:', err); _partialWarnings.push('loan fields'); }
  }
  // Save prior sales entries if any were added
  if (window._govPriorSales && window._govPriorSales.length > 0) {
    for (const ps of window._govPriorSales) {
      try {
        await govWriteService('ownership', {
          property_id: propertyId,
          recorded_owner: ps.buyer || null,
          true_owner: null,
          owner_type: 'prior_sale'
        });
      } catch (err) {
        console.warn('Prior sale write error:', err);
        _partialWarnings.push('prior sale ' + (ps.date || ''));
      }
    }
    window._govPriorSales = [];  // Clear after saving
  }

  if (_partialWarnings.length) { showToast('Saved with warnings — failed to update: ' + _partialWarnings.join(', '), 'error'); return true; }
  return true;
}

/** Add a prior sale entry from the bulk entry form */
function govAddPriorSale() {
  const date = q('#res-ps-date')?.value || null;
  const price = q('#res-ps-price')?.value || null;
  const buyer = q('#res-ps-buyer')?.value || null;
  const seller = q('#res-ps-seller')?.value || null;
  const cap = q('#res-ps-cap')?.value || null;
  const source = q('#res-ps-source')?.value || null;

  if (!date && !price && !buyer && !seller) {
    showToast('Fill in at least one field to add a prior sale', 'info');
    return;
  }

  if (!window._govPriorSales) window._govPriorSales = [];
  window._govPriorSales.push({ date, price: price ? parseFloat(price) : null, buyer, seller, cap, source });

  // Clear the form fields
  ['res-ps-date', 'res-ps-price', 'res-ps-buyer', 'res-ps-seller', 'res-ps-cap', 'res-ps-source'].forEach(id => {
    const el = q('#' + id); if (el) el.value = '';
  });

  showToast('Prior sale added (' + window._govPriorSales.length + ' total) — will save with record', 'success');
  renderGovTab();
}
window.govAddPriorSale = govAddPriorSale;

async function saveLead(rec) {
  const saleDate = q('#res-lead-sale-date')?.value || null;
  const salePrice = _pf(q('#res-lead-sale-price'));
  const capRate = _pf(q('#res-lead-cap-rate'));
  const buyer = q('#res-lead-buyer')?.value || null;
  const seller = q('#res-lead-seller')?.value || null;
  const quickStatus = q('#res-lead-quick-status')?.value || null;

  const leadData = {
    lead_id: rec.lead_id,
    lease_number: rec.lease_number || null,
    recorded_owner: q('#res-lead-recorded-owner')?.value || null,
    true_owner: q('#res-lead-true-owner')?.value || null,
    owner_type: q('#res-lead-owner-type')?.value || null,
    contact_email: q('#res-lead-principal-email')?.value || null,
    contact_phone: q('#res-lead-phone')?.value || null,
    contact_mailing: q('#res-lead-mailing')?.value || null,
    research_notes: q('#res-lead-notes')?.value || null,
    research_status: 'completed'
  };

  const _anyLeadField = [saleDate, salePrice, capRate, buyer, seller,
    leadData.recorded_owner, leadData.true_owner, leadData.owner_type,
    leadData.contact_email, leadData.contact_phone, leadData.contact_mailing,
    leadData.research_notes].some(v => v !== null && v !== undefined && String(v).trim() !== '');
  if (!_anyLeadField) { showToast('Please fill in at least one field before saving', 'info'); return; }

  if (quickStatus) {
    leadData.pipeline_status = quickStatus;
  }

  // Use Gov write service for lead research updates
  let writeResult = null;
  try {
    writeResult = await govWriteService('lead-research', leadData);
  } catch (err) {
    console.error('Gov lead-research write service error:', err);
    showToast('Error saving lead via write service: ' + err.message, 'error');
  }

  // ── Prior Sale → sales_transactions ──
  let _leadPartialWarnings = [];
  const propertyId = rec.matched_property_id || rec.property_id;
  if ((saleDate || salePrice || buyer || seller) && propertyId) {
    try {
      await applyInsertWithFallback({
        proxyBase: '/api/gov-query',
        table: 'sales_transactions',
        idColumn: 'property_id',
        recordIdentifier: propertyId,
        data: {
          property_id: propertyId,
          sale_date: saleDate,
          sold_price: salePrice,
          cap_rate: capRate,
          buyer_name: buyer,
          seller_name: seller
        },
        source_surface: 'gov_lead_research',
        propagation_scope: 'prior_sale_record'
      });
    } catch (err) {
      console.error('Error saving sale transaction from lead:', err);
      _leadPartialWarnings.push('sale transaction');
    }
  }

  // ── Property Details → properties table ──
  if (propertyId) {
    const propPatch = {};
    const rba = _pf(q('#res-lead-rba'));
    const landAcres = _pf(q('#res-lead-land-acres'));
    const yearBuilt = _py(q('#res-lead-year-built'));
    const yearRenovated = _py(q('#res-lead-year-renovated'));
    const buildingClass = q('#res-lead-building-class')?.value || null;
    const stories = _pi(q('#res-lead-stories'));
    const parking = _pi(q('#res-lead-parking'));
    const zoning = q('#res-lead-zoning')?.value || null;
    const condition = q('#res-lead-condition')?.value || null;
    const annualRent = _pf(q('#res-lead-annual-rent'));
    const estValue = _pf(q('#res-lead-est-value'));

    if (rba) propPatch.rba = rba;
    if (landAcres) propPatch.land_acres = landAcres;
    if (yearBuilt) propPatch.year_built = yearBuilt;
    if (yearRenovated) propPatch.year_renovated = yearRenovated;
    if (buildingClass) propPatch.building_class = buildingClass;
    if (stories) propPatch.stories = stories;
    if (parking) propPatch.parking_spaces = parking;
    if (zoning) propPatch.zoning = zoning;
    if (condition) propPatch.property_condition = condition;
    if (annualRent) propPatch.last_known_rent = annualRent;
    if (estValue) propPatch.current_value_estimate = estValue;

    if (Object.keys(propPatch).length > 0) {
      try { await patchRecord('properties', 'property_id', propertyId, propPatch); }
      catch (err) { console.error('Property patch error:', err); _leadPartialWarnings.push('property details'); }
    }
  }

  // ── Loan / Debt ──
  const lender = q('#res-lead-lender')?.value || null;
  const loanAmount = _pf(q('#res-lead-loan-amount'));
  const interestRate = _pf(q('#res-lead-interest-rate'));
  const loanType = q('#res-lead-loan-type')?.value || null;
  const loanOrig = q('#res-lead-loan-orig')?.value || null;
  const loanMaturity = q('#res-lead-loan-maturity')?.value || null;
  const ltv = _pf(q('#res-lead-ltv'));
  const recourse = q('#res-lead-recourse')?.value || null;

  if ((lender || loanAmount) && propertyId) {
    const loanData = {
      property_id: propertyId,
      index_name: lender,
      loan_amount: loanAmount,
      interest_rate_percent: interestRate,
      loan_type: loanType,
      origination_date: loanOrig,
      maturity_date: loanMaturity,
      loan_to_value: ltv,
      recourse: recourse
    };

    const existingLoan = (govData.loans || []).find(l => l.property_id === propertyId);
    if (existingLoan) {
      await patchRecord('loans', 'property_id', propertyId, loanData);
    } else {
      try {
        await applyInsertWithFallback({
          proxyBase: '/api/gov-query',
          table: 'loans',
          idColumn: 'property_id',
          recordIdentifier: propertyId,
          data: loanData,
          source_surface: 'gov_lead_research',
          propagation_scope: 'loan_record'
        });
      } catch (err) {
        console.error('Error saving loan from lead:', err);
        _leadPartialWarnings.push('loan');
      }
    }
  }

  if (_leadPartialWarnings.length) showToast('Saved with warnings — failed to update: ' + _leadPartialWarnings.join(', '), 'error');

  // Bridge to canonical model with gov change metadata
  canonicalBridge('complete_research', {
    domain: 'government',
    research_type: 'lead',
    external_id: String(rec.property_id || rec.lead_id),
    source_system: 'gov',
    source_type: 'lead',
    outcome: quickStatus === 'not_applicable' ? 'not_applicable' : 'completed',
    notes: leadData.research_notes,
    evidence_artifact_id: (typeof govEvidenceState !== 'undefined' && govEvidenceState.artifactId) ? govEvidenceState.artifactId : null,
    gov_change_event_id: writeResult?.change_event_id || null,
    gov_correlation_id: writeResult?.correlation_id || null,
    source_record_id: rec.lead_id,
    source_table: 'prospect_leads',
    title: rec.address || rec.lease_number || `Lead ${rec.lead_id}`,
    entity_fields: {
      name: rec.address || leadData.true_owner || leadData.recorded_owner || `Lead ${rec.lead_id}`,
      email: leadData.contact_email || null,
      phone: leadData.contact_phone || null,
      address: rec.address || null,
      city: rec.city || null,
      state: rec.state || null,
      asset_type: 'government_leased'
    }
  });

  // Ensure canonical entity link exists for this gov lead
  if (rec.lead_id) {
    canonicalBridge('update_entity', {
      external_id: String(rec.lead_id),
      source_system: 'gov',
      source_type: 'lead',
      fields: {
        name: rec.address || leadData.true_owner || leadData.recorded_owner || `Lead ${rec.lead_id}`,
        email: leadData.contact_email || null,
        phone: leadData.contact_phone || null,
        address: rec.address || null,
        city: rec.city || null,
        state: rec.state || null,
        asset_type: 'government_leased'
      }
    });
  }
  if (_leadPartialWarnings.length) { showToast('Saved with warnings — failed to update: ' + _leadPartialWarnings.join(', '), 'error'); return true; }
  return true;
}

async function saveIntel(rec) {
  const propertyId = rec.property_id;
  if (!propertyId) {
    showToast('No property ID — cannot save intel', 'error');
    return false;
  }

  const _intelCard = document.querySelector('.research-card');
  if (_intelCard) {
    const _intelInputs = _intelCard.querySelectorAll('input[type="text"], input[type="number"], input[type="date"], textarea, select');
    const _hasIntelData = Array.from(_intelInputs).some(function(inp) {
      if (inp.tagName === 'SELECT') return inp.selectedIndex > 0;
      return inp.value && inp.value.trim() !== '';
    });
    if (!_hasIntelData) { showToast('Please fill in at least one intel field before saving', 'info'); return false; }
  }

  const _intelPartialWarns = [];

  // ── Prior Sale → sales_transactions table ──
  const saleDate = q('#res-intel-sale-date')?.value || null;
  const salePrice = _pf(q('#res-intel-sale-price'));
  const capRate = _pf(q('#res-intel-cap-rate'));
  const buyer = q('#res-intel-buyer')?.value || null;
  const seller = q('#res-intel-seller')?.value || null;

  if (saleDate || salePrice || buyer || seller) {
    const salePayload = {
      property_id: propertyId,
      sale_date: saleDate,
      sold_price: salePrice,
      cap_rate: capRate,
      buyer_name: buyer,
      seller_name: seller
    };
    try {
      await applyInsertWithFallback({
        proxyBase: '/api/gov-query',
        table: 'sales_transactions',
        idColumn: 'property_id',
        recordIdentifier: propertyId,
        data: salePayload,
        source_surface: 'gov_intel_research',
        propagation_scope: 'prior_sale_record'
      });
    } catch (err) {
      console.error('Error saving sale transaction:', err);
      _intelPartialWarns.push('sale transaction');
    }
  }

  // ── Property Details → properties table ──
  const propertyPatch = {};
  const rba = _pf(q('#res-intel-rba'));
  const landAcres = _pf(q('#res-intel-land-acres'));
  const yearBuilt = _py(q('#res-intel-year-built'));
  const yearRenovated = _py(q('#res-intel-year-renovated'));
  const buildingClass = q('#res-intel-building-class')?.value || null;
  const stories = _pi(q('#res-intel-stories'));
  const parking = _pi(q('#res-intel-parking'));
  const zoning = q('#res-intel-zoning')?.value || null;
  const condition = q('#res-intel-condition')?.value || null;
  const annualRent = _pf(q('#res-intel-annual-rent'));
  const estValue = _pf(q('#res-intel-est-value'));
  const recordedOwner = q('#res-intel-recorded-owner')?.value || null;
  const trueOwner = q('#res-intel-true-owner')?.value || null;

  if (rba) propertyPatch.rba = rba;
  if (landAcres) propertyPatch.land_acres = landAcres;
  if (yearBuilt) propertyPatch.year_built = yearBuilt;
  if (yearRenovated) propertyPatch.year_renovated = yearRenovated;
  if (buildingClass) propertyPatch.building_class = buildingClass;
  if (stories) propertyPatch.stories = stories;
  if (parking) propertyPatch.parking_spaces = parking;
  if (zoning) propertyPatch.zoning = zoning;
  if (condition) propertyPatch.property_condition = condition;
  if (annualRent) propertyPatch.last_known_rent = annualRent;
  if (estValue) propertyPatch.current_value_estimate = estValue;
  propertyPatch.intel_status = 'completed';

  if (Object.keys(propertyPatch).length > 1) {
    const ok = await patchRecord('properties', 'property_id', propertyId, propertyPatch);
    if (!ok) {
      showToast('Failed to save property details — please retry', 'error');
      return false;
    }
  }

  // ── Ownership → write service ──
  if (recordedOwner || trueOwner) {
    try {
      await govWriteService('ownership', {
        property_id: propertyId,
        recorded_owner: recordedOwner,
        true_owner: trueOwner,
        owner_type: q('#res-intel-owner-type')?.value || null
      });
    } catch (err) {
      console.error('Gov ownership write error (intel):', err);
      _intelPartialWarns.push('ownership');
    }
  }

  // ── Loan → loans table ──
  const lender = q('#res-intel-lender')?.value || null;
  const loanAmount = _pf(q('#res-intel-loan-amount'));
  const interestRate = _pf(q('#res-intel-interest-rate'));
  const loanType = q('#res-intel-loan-type')?.value || null;
  const loanOrig = q('#res-intel-loan-orig')?.value || null;
  const loanMaturity = q('#res-intel-loan-maturity')?.value || null;
  const ltv = _pf(q('#res-intel-ltv'));
  const recourse = q('#res-intel-recourse')?.value || null;

  if (lender || loanAmount) {
    const loanData = {
      property_id: propertyId,
      index_name: lender,
      loan_amount: loanAmount,
      interest_rate_percent: interestRate,
      loan_type: loanType,
      origination_date: loanOrig,
      maturity_date: loanMaturity,
      loan_to_value: ltv,
      recourse: recourse
    };

    const existingLoan = (govData.loans || []).find(l => l.property_id === propertyId);
    if (existingLoan) {
      await patchRecord('loans', 'property_id', propertyId, loanData);
    } else {
      try {
        await applyInsertWithFallback({
          proxyBase: '/api/gov-query',
          table: 'loans',
          idColumn: 'property_id',
          recordIdentifier: propertyId,
          data: loanData,
          source_surface: 'gov_intel_research',
          propagation_scope: 'loan_record'
        });
      } catch (err) {
        console.error('Error saving loan (intel):', err);
        _intelPartialWarns.push('loan');
      }
    }
  }

  // ── Research Notes → research_queue_outcomes ──
  const notes = q('#res-intel-notes')?.value || null;
  const source = q('#res-intel-source')?.value || null;
  const researchDate = q('#res-intel-date')?.value || null;

  if (notes || source) {
    try {
      const result = await applyInsertWithFallback({
        proxyBase: '/api/gov-query',
        table: 'research_queue_outcomes',
        idColumn: 'selected_property_id',
        recordIdentifier: propertyId,
        data: {
          queue_type: 'intel_research',
          status: 'completed',
          notes: [source ? `[${source}]` : '', notes].filter(Boolean).join(' '),
          selected_property_id: propertyId,
          assigned_at: researchDate || new Date().toISOString()
        },
        source_surface: 'gov_intel_research',
        propagation_scope: 'research_queue_outcome'
      });
      if (!result.ok) {
        console.error('Error saving intel research notes:', result.errors || []);
      }
    } catch (err) {
      console.error('Error saving intel research notes:', err);
      _intelPartialWarns.push('research notes');
    }
  }

  // ── Bridge to canonical model ──
  canonicalBridge('complete_research', {
    domain: 'government',
    research_type: 'intel',
    external_id: String(propertyId),
    source_system: 'gov',
    source_type: 'asset',
    outcome: 'completed',
    notes: notes,
    evidence_artifact_id: (typeof govEvidenceState !== 'undefined' && govEvidenceState.artifactId) ? govEvidenceState.artifactId : null,
    source_record_id: propertyId,
    source_table: 'properties',
    title: rec.address || rec.property_name || `Property ${propertyId}`,
    entity_fields: {
      name: rec.address || rec.property_name || `Property ${propertyId}`,
      address: rec.address || null,
      city: rec.city || null,
      state: rec.state || null,
      asset_type: 'government_leased'
    }
  });

  if (recordedOwner || trueOwner) {
    canonicalBridge('update_entity', {
      external_id: String(propertyId),
      source_system: 'gov',
      source_type: 'asset',
      fields: {
        name: rec.address || rec.property_name || `Property ${propertyId}`,
        address: rec.address || null,
        city: rec.city || null,
        state: rec.state || null,
        asset_type: 'government_leased'
      }
    });
  }

  if (_intelPartialWarns.length) {
    showToast('Saved with warnings — failed: ' + _intelPartialWarns.join(', '), 'warning');
  }

  return true;
}

async function patchRecord(table, idCol, idVal, data) {
  // Route through closed-loop mutation service with fallback to direct PATCH
  try {
    const result = await applyChangeWithFallback({
      proxyBase: '/api/gov-query',
      table,
      idColumn: idCol,
      idValue: idVal,
      data,
      source_surface: 'gov_workspace'
    });

    if (!result.ok) {
      console.error(`patchRecord error: ${(result.errors || []).join(', ')}`);
      showToast('Error saving ' + table + ': ' + (result.errors ? result.errors.join(', ') : 'unknown error'), 'error');
      return false;
    }

    return true;
  } catch (err) {
    console.error('patchRecord error:', err);
    showToast('Error saving ' + table + ': ' + (err.message || 'unknown error'), 'error');
    return false;
  }
}

async function saveLoanFields(rec) {
  const lenderName = q('#res-lender')?.value || null;
  const loanAmount = _pf(q('#res-loan-amount'));
  const loanType = q('#res-loan-type')?.value || null;
  const loanStatus = q('#res-loan-status')?.value || null;
  
  if (!lenderName && !loanAmount) return;
  
  const propertyId = rec.matched_property_id || rec.property_id;
  if (!propertyId) return;
  
  // Find existing loan
  const existingLoan = (govData.loans || []).find(l => l.property_id === propertyId);
  
  const loanData = {
    property_id: propertyId,
    index_name: lenderName || null,
    loan_amount: loanAmount || null,
    loan_type: loanType || null,
    status: loanStatus || null
  };
  
  if (existingLoan) {
    await patchRecord('loans', 'property_id', propertyId, loanData);
  } else {
    try {
      const response = await applyInsertWithFallback({
        proxyBase: '/api/gov-query',
        table: 'loans',
        idColumn: 'property_id',
        recordIdentifier: propertyId,
        data: loanData,
        source_surface: 'gov_research_resolution',
        propagation_scope: 'loan_record'
      });
      
      if (!response.ok) {
        console.error('Error creating loan record:', response.errors || []);
      }
    } catch (err) {
      console.error('Error creating loan record:', err);
    }
  }
}

async function researchMark(mark) {
  const rec = researchQueue[researchIdx];
  if (!rec) return;

  // Disable all mark buttons during async operation
  const markBtns = document.querySelectorAll('.research-card .action-row button[onclick*="researchMark"]');
  markBtns.forEach(b => {
    b.disabled = true;
    b.dataset.origText = b.textContent;
    b.textContent = 'Marking…';
  });

  const _reEnableMarks = () => markBtns.forEach(b => {
    b.disabled = false;
    b.textContent = b.dataset.origText || b.textContent;
  });

  // Confirm before discarding a property as too multi-tenant — this also
  // flags the parent property so it stays out of consideration in other LCC
  // views, not just the ownership queue.
  if (mark === 'multi_tenant') {
    const _confirmed = await lccConfirm(
      'Discard this property as too multi-tenant for our single-tenant focus? ' +
      'The ownership row will be marked discarded and the property will be flagged out of scope.',
      'Discard property'
    );
    if (!_confirmed) { _reEnableMarks(); return; }
  }

  let status = 'marked';
  if (mark === 'spe_rename')   status = 'spe_rename';
  if (mark === 'na')           status = 'not_applicable';
  if (mark === 'approve')      status = 'completed';
  if (mark === 'reject')       status = 'rejected';
  if (mark === 'comp_on_file') status = 'comp_on_file';
  if (mark === 'junk_no_data') status = 'junk_no_data';
  if (mark === 'multi_tenant') status = 'discarded_multi_tenant';

  if (researchMode === 'ownership') {
    const ok = await patchRecord('ownership_history', 'ownership_id', rec.ownership_id, { research_status: status });
    if (!ok) { _reEnableMarks(); return; }
    // For multi-tenant discards, also flag the parent property so it falls
    // out of consideration in other LCC surfaces (intel queue, pipeline, etc).
    if (mark === 'multi_tenant') {
      const propertyId = rec.matched_property_id || rec.property_id;
      if (propertyId) {
        try {
          await patchRecord('properties', 'property_id', propertyId, { intel_status: 'discarded_multi_tenant' });
        } catch (err) {
          console.warn('Multi-tenant discard: ownership row marked but failed to flag property', err);
        }
      }
    }
  } else if (researchMode === 'intel') {
    const propertyId = rec.property_id;
    if (propertyId) {
      const ok = await patchRecord('properties', 'property_id', propertyId, { intel_status: status });
      if (!ok) { _reEnableMarks(); return; }
    }
  } else {
    try {
      await govWriteService('lead-research', {
        lead_id: rec.lead_id,
        research_status: status
      });
    } catch (err) {
      console.error('Error marking lead via write service:', err);
      showToast('Error saving: ' + err.message, 'error');
      _reEnableMarks();
      return;
    }
  }

  const _markLabels = {
    spe_rename: 'SPE Rename',
    na: 'N/A',
    approve: 'Approved (research complete)',
    reject: 'Rejected',
    comp_on_file: '✓ Comp on file',
    junk_no_data: '⊘ Stub — no research handle',
    multi_tenant: '🚫 Discarded — too multi-tenant'
  };
  const markLabel = _markLabels[mark] || mark;
  showToast('Marked as ' + markLabel, 'success');
  researchQueue.splice(researchIdx, 1);
  // Don't increment — splice shifts next item into current index
  renderGovTab();
}

function researchNav(dir, isSkip) {
  if (_researchSaving) { showToast('Save in progress \u2014 please wait', 'info'); return; }
  const prevIdx = researchIdx;
  researchIdx += dir;

  if (researchIdx < 0) {
    researchIdx = 0;
    if (prevIdx === 0) showToast('Already at start of queue', 'info');
  } else if (researchIdx >= researchQueue.length) {
    researchIdx = Math.max(0, researchQueue.length - 1);
    showToast('End of queue reached', 'info');
  } else if (isSkip) {
    showToast('Skipped — ' + (researchIdx + 1) + ' / ' + researchQueue.length, 'info');
  }

  renderGovTab();
}

function setResearchMode(mode) {
  researchMode = mode;
  researchIdx = 0;

  // For pipeline ops modes, don't load research queue
  if (['pending_updates', 'financial_overrides', 'pipeline_control', 'monitor'].includes(mode)) {
    renderGovTab();
  } else {
    // For research modes, load the queue
    loadResearchQueue().then(() => {
      if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'government') return;
      renderGovTab();
    });
  }
}

function setResearchFilter(filter) {
  researchFilter = filter;
  researchIdx = 0;
  loadResearchQueue().then(() => {
    if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'government') return;
    renderGovTab();
  });
}

// Keyboard shortcuts for research workflow
(function() {
  document.addEventListener('keydown', function(e) {
    // Only active when research workbench is visible and no input/textarea is focused
    if (!document.querySelector('.research-card')) return;
    var tag = (e.target.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable) return;


    // Ctrl+Enter / Cmd+Enter to save
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      if (!_researchSaving) researchSave();
      return;
    }
    if (e.key === 'n' || e.key === 'N') {
      e.preventDefault();
      const _maxStep = researchMode === 'ownership' ? 5 : 4;
      if (govResearchStep < _maxStep) {
        govStepNav(govResearchStep + 1);
      } else {
        researchSave();
      }
    } else if (e.key === 'b' || e.key === 'B') {
      e.preventDefault();
      if (govResearchStep > 0) govStepNav(govResearchStep - 1);
    } else if (e.key === 's' || e.key === 'S') {
      e.preventDefault();
      if (!_researchSaving) researchSaveInPlace();
    } else if (e.key === 'k' || e.key === 'K') {
      e.preventDefault();
      if (!_researchSaving) {
        const _skipCard = document.querySelector('.research-card');
        if (_skipCard) {
          const _skipInputs = _skipCard.querySelectorAll('input[type="text"], input[type="number"], input[type="date"], textarea, select');
          const _hasDirty = Array.from(_skipInputs).some(inp => {
            if (inp.tagName === 'SELECT') return inp.selectedIndex > 0;
            return inp.value && inp.value.trim() !== '' && inp.value !== inp.defaultValue;
          });
          if (_hasDirty) {
            lccConfirm('You have unsaved changes. Skip anyway?', 'Skip').then(ok => { if (ok) researchNav(1, true); });
            return;
          }
        }
        researchNav(1, true);
      }
    }
  });
})();

function getGovEvidenceActor() {
  if (typeof LCC_USER !== 'undefined') {
    return LCC_USER.email || LCC_USER.display_name || LCC_USER.id || 'lcc_user';
  }
  return 'lcc_user';
}

function getGovEvidenceContextRecord() {
  return Array.isArray(researchQueue) ? (researchQueue[researchIdx] || null) : null;
}

function getGovEvidenceContextKey(rec) {
  if (!rec) return 'none';
  return [researchMode || 'research', rec.lead_id || '', rec.property_id || rec.matched_property_id || '', rec.ownership_id || '', rec.lease_number || ''].join(':');
}

function getGovEvidenceSourceAttachment() {
  if (typeof getLiveIngestState !== 'function') return null;
  const state = getLiveIngestState('government');
  const attachments = Array.isArray(state?.attachments) ? state.attachments : [];
  const images = attachments.filter((item) => item && item.kind === 'image' && item.data_url);
  return images.length ? images[images.length - 1] : null;
}

function getGovEvidenceSourceLabel() {
  const attachment = getGovEvidenceSourceAttachment();
  return attachment?.name || 'No screenshot uploaded in Live Intake yet';
}
function getGovEvidenceBinding(rec) {
  return {
    lead_id: rec?.lead_id || null,
    property_id: rec?.property_id || rec?.matched_property_id || null,
    ownership_id: rec?.ownership_id || null
  };
}

function syncGovEvidenceContext() {
  const rec = getGovEvidenceContextRecord();
  const nextKey = getGovEvidenceContextKey(rec);
  if (govEvidenceState.contextKey === nextKey) return rec;
  govEvidenceState = {
    contextKey: nextKey,
    review: null,
    artifactId: null,
    loading: false,
    queue: [],
    queueLoading: false,
    queueLoaded: false,
    queueError: '',
    _toastShown: false,
    healthLoading: false,
    brokerFeedback: null,
    brokerFeedbackLoading: false,
    health: null,
    conflicts: [],
    detectedSource: null
  };
  return rec;
}

function getGovEvidenceNotesEl() {
  return document.getElementById(researchMode === 'intel' ? 'res-intel-notes' : 'res-notes');
}

function appendGovEvidenceNote(note) {
  const el = getGovEvidenceNotesEl();
  if (!el || !note) return;
  const stamp = new Date().toISOString().slice(0, 10);
  const line = `[EVIDENCE ${stamp}] ${note}`;
  el.value = el.value ? `${el.value}\n${line}` : line;
}

function setGovEvidenceField(selectors, value) {
  if (value == null || value === '') return;
  for (const selector of selectors) {
    const el = document.querySelector(selector);
    if (!el) continue;
    el.value = value;
    return;
  }
}

function pickGovEvidenceValue(...values) {
  for (const value of values) {
    if (value != null && value !== '') return value;
  }
  return null;
}

function normalizeGovEvidenceCompareValue(value) {
  return String(value == null ? '' : value).trim().toLowerCase();
}

function readGovEvidenceCurrentField(kind, rec) {
  const selectors = {
    owner: ['#res-true-owner', '#res-intel-true-owner', '#res-recorded-owner', '#res-intel-recorded-owner'],
    lender: ['#res-lender', '#res-intel-lender'],
    rba: ['#res-rba', '#res-intel-rba'],
    year_built: ['#res-year-built', '#res-intel-year-built']
  };
  for (const selector of (selectors[kind] || [])) {
    const el = document.querySelector(selector);
    const value = el?.value;
    if (value != null && String(value).trim() !== '') return value;
  }
  if (!rec) return '';
  if (kind === 'owner') return rec.true_owner || rec.recorded_owner || rec.new_owner || rec.prior_owner || '';
  if (kind === 'lender') return rec._loan?.index_name || '';
  if (kind === 'rba') return rec.rba || rec.square_feet || '';
  if (kind === 'year_built') return rec.year_built || '';
  return '';
}

function buildGovEvidenceConflictList(review, rec) {
  if (!review || typeof review !== 'object') return [];
  const candidates = [
    {
      key: 'owner',
      label: 'Owner',
      currentValue: readGovEvidenceCurrentField('owner', rec),
      evidenceValue: pickGovEvidenceValue(review.ownership?.true_owner, review.ownership?.current_owner, review.property?.owner_name)
    },
    {
      key: 'lender',
      label: 'Lender',
      currentValue: readGovEvidenceCurrentField('lender', rec),
      evidenceValue: pickGovEvidenceValue(review.loan?.lender, review.loan?.index_name)
    },
    {
      key: 'rba',
      label: 'RBA',
      currentValue: readGovEvidenceCurrentField('rba', rec),
      evidenceValue: pickGovEvidenceValue(review.property?.rba, review.property?.building_sf, review.building?.rba)
    },
    {
      key: 'year_built',
      label: 'Year Built',
      currentValue: readGovEvidenceCurrentField('year_built', rec),
      evidenceValue: pickGovEvidenceValue(review.property?.year_built, review.building?.year_built)
    }
  ];
  return candidates.filter((item) => {
    if (item.currentValue == null || item.currentValue === '') return false;
    if (item.evidenceValue == null || item.evidenceValue === '') return false;
    return normalizeGovEvidenceCompareValue(item.currentValue) !== normalizeGovEvidenceCompareValue(item.evidenceValue);
  }).map((item, idx) => ({
    id: `${item.key}:${idx}`,
    resolution: '',
    ...item
  }));
}

function applyGovEvidenceConflictResolution(conflictId, resolution) {
  const conflict = govEvidenceState.conflicts.find((item) => item.id === conflictId);
  if (!conflict || !govEvidenceState.review) return;
  conflict.resolution = resolution;
  if (resolution !== 'keep_current') return;

  if (conflict.key === 'owner') {
    govEvidenceState.review.ownership = govEvidenceState.review.ownership || {};
    govEvidenceState.review.property = govEvidenceState.review.property || {};
    govEvidenceState.review.ownership.true_owner = conflict.currentValue;
    govEvidenceState.review.ownership.current_owner = conflict.currentValue;
    govEvidenceState.review.property.owner_name = conflict.currentValue;
  }
  if (conflict.key === 'lender') {
    govEvidenceState.review.loan = govEvidenceState.review.loan || {};
    govEvidenceState.review.loan.lender = conflict.currentValue;
    govEvidenceState.review.loan.index_name = conflict.currentValue;
  }
  if (conflict.key === 'rba') {
    govEvidenceState.review.property = govEvidenceState.review.property || {};
    govEvidenceState.review.building = govEvidenceState.review.building || {};
    govEvidenceState.review.property.rba = conflict.currentValue;
    govEvidenceState.review.property.building_sf = conflict.currentValue;
    govEvidenceState.review.building.rba = conflict.currentValue;
  }
  if (conflict.key === 'year_built') {
    govEvidenceState.review.property = govEvidenceState.review.property || {};
    govEvidenceState.review.building = govEvidenceState.review.building || {};
    govEvidenceState.review.property.year_built = conflict.currentValue;
    govEvidenceState.review.building.year_built = conflict.currentValue;
  }
}

function unresolvedGovEvidenceConflicts() {
  return (govEvidenceState.conflicts || []).filter((item) => !item.resolution);
}

function renderGovEvidenceConflictPanel() {
  if (!govEvidenceState.conflicts?.length) return '';
  const unresolved = unresolvedGovEvidenceConflicts();
  return `<div class="live-ingest-callout warn" style="margin-top:12px">
    <div style="font-weight:700;margin-bottom:8px">Conflict Review Required</div>
    <div style="margin-bottom:10px">The screenshot evidence disagrees with current research values on ${unresolved.length} field${unresolved.length === 1 ? '' : 's'}. Choose whether to keep the current value or trust the screenshot before safe apply.</div>
    <div style="display:grid;gap:8px">
      ${govEvidenceState.conflicts.map((conflict) => `<div style="border:1px solid rgba(248,113,113,0.25);border-radius:8px;padding:10px;background:rgba(248,113,113,0.04)">
        <div style="font-size:12px;font-weight:700;color:var(--text)">${esc(conflict.label)}</div>
        <div style="font-size:12px;color:var(--text2);margin-top:4px">Current: ${esc(String(conflict.currentValue || ''))}</div>
        <div style="font-size:12px;color:var(--text2)">Evidence: ${esc(String(conflict.evidenceValue || ''))}</div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px">
          <button class="btn-secondary" type="button" data-gov-evidence-conflict="${esc(conflict.id)}:keep_current">Keep Current${conflict.resolution === 'keep_current' ? ' ✓' : ''}</button>
          <button class="btn-secondary" type="button" data-gov-evidence-conflict="${esc(conflict.id)}:use_evidence">Use Evidence${conflict.resolution === 'use_evidence' ? ' ✓' : ''}</button>
        </div>
      </div>`).join('')}
    </div>
  </div>`;
}
function applyGovEvidenceReviewToForm(review) {
  if (!review || typeof review !== 'object') return;
  const owner = pickGovEvidenceValue(
    review.ownership?.true_owner,
    review.ownership?.current_owner,
    review.property?.owner_name,
    review.owner?.name
  );
  const recordedOwner = pickGovEvidenceValue(
    review.ownership?.recorded_owner,
    review.property?.owner_name,
    owner
  );
  const lender = pickGovEvidenceValue(review.loan?.lender, review.loan?.index_name);
  const loanAmount = pickGovEvidenceValue(review.loan?.current_balance, review.loan?.loan_amount);
  const rba = pickGovEvidenceValue(review.property?.rba, review.property?.building_sf, review.building?.rba);
  const yearBuilt = pickGovEvidenceValue(review.property?.year_built, review.building?.year_built);
  setGovEvidenceField(['#res-true-owner', '#res-intel-true-owner'], owner);
  setGovEvidenceField(['#res-recorded-owner', '#res-intel-recorded-owner'], recordedOwner);
  setGovEvidenceField(['#res-lender', '#res-intel-lender'], lender);
  setGovEvidenceField(['#res-loan-amount', '#res-intel-loan-amount'], loanAmount);
  setGovEvidenceField(['#res-rba', '#res-intel-rba'], rba);
  setGovEvidenceField(['#res-year-built', '#res-intel-year-built'], yearBuilt);
}

function renderGovEvidenceWorkbench() {
  // Evidence workbench requires the GovernmentProject FastAPI service (GOV_API_URL).
  // Until that service is deployed, skip rendering to avoid error loops.
  return '';
  const rec = syncGovEvidenceContext();
  const binding = getGovEvidenceBinding(rec);
  const queueHtml = govEvidenceState.queueLoading
    ? '<div class="live-ingest-empty" style="margin-top:8px">Loading pending evidence rows...</div>'
    : govEvidenceState.queue.length
      ? `<div style="display:grid;gap:8px;margin-top:10px">${govEvidenceState.queue.map((row, idx) => `
          <div style="border:1px solid var(--border);border-radius:10px;padding:10px;background:rgba(255,255,255,0.02)">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start">
              <div>
                <div style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:0.08em">${esc(row.observation_type || 'observation')}</div>
                <div style="font-size:13px;color:var(--text);margin-top:4px">${esc(row.summary || row.observation_value || 'Pending evidence row')}</div>
                ${Array.isArray(row.review_cues) && row.review_cues.length ? `<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px">${row.review_cues.map((cue) => `<span style="font-size:11px;padding:2px 8px;border-radius:999px;background:rgba(255,255,255,0.06);border:1px solid var(--border);color:var(--text2)">${esc(cue)}</span>`).join('')}</div>` : ''}
                ${row.promotion_guard?.message ? `<div class="live-ingest-callout warn" style="margin-top:8px">${esc(row.promotion_guard.message)}</div>` : ''}
                ${row.promotion_guard?.current_contact_display ? `<div style="font-size:11px;color:var(--text2);margin-top:6px">Current matched contact: ${esc(row.promotion_guard.current_contact_display)}</div>` : ''}
                ${row.promotion_guard?.candidate_contact_display ? `<div style="font-size:11px;color:var(--text2);margin-top:4px">Evidence broker: ${esc(row.promotion_guard.candidate_contact_display)}</div>` : ''}
              </div>
              <div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end">
                <button class="btn-secondary" type="button" data-gov-evidence-note="${idx}">Note</button>
                <button class="btn-secondary" type="button" data-gov-evidence-review="${idx}">Review</button>
                <button class="btn-secondary" type="button" data-gov-evidence-dismiss="${idx}">Dismiss</button>
                <button class="btn-primary" type="button" data-gov-evidence-promote="${idx}">${row.promotion_guard?.message ? 'Confirm Promote' : 'Promote'}</button>
              </div>
              ${Array.isArray(row.dismiss_reason_options) && row.dismiss_reason_options.length ? `<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px;justify-content:flex-end">${row.dismiss_reason_options.map((reason) => `<button class="btn-secondary" type="button" data-gov-evidence-dismiss-reason="${idx}::${esc(reason)}">Dismiss: ${esc(reason)}</button>`).join('')}</div>` : ''}
            </div>
          </div>`).join('')}</div>`
      : '<div class="live-ingest-empty" style="margin-top:8px">No pending observation rows for this record.</div>';

  return `<section class="live-ingest-card" style="margin-top:16px">
    <div class="live-ingest-head">
      <div>
        <div class="live-ingest-kicker">Gov Evidence</div>
        <h3>Extract CoStar screenshots into reviewed government evidence</h3>
        <p>This is the LCC runtime bridge for the GovernmentProject evidence workflow. It saves artifacts, applies low-risk actions, and queues tenant or lease rows for review.</p>
      </div>
      <div class="live-ingest-context">${rec ? `<div><strong>${esc(rec.address || rec.property_name || rec.lease_number || 'Current record')}</strong><span>${esc([binding.lead_id ? `lead ${binding.lead_id}` : '', binding.property_id ? `property ${binding.property_id}` : '', binding.ownership_id ? `ownership ${binding.ownership_id}` : ''].filter(Boolean).join(' | '))}</span></div>` : '<div><strong>No record bound</strong><span>Move to a government research row to use evidence actions.</span></div>'}</div>
    </div>
    <div class="live-ingest-grid">
      <div class="live-ingest-pane">
        <div class="form-group">
          <label>Evidence Source</label>
          <div class="live-ingest-stamp" style="margin-top:8px">Using latest image from Live Intake: ${esc(getGovEvidenceSourceLabel())}</div>
          <div class="live-ingest-stamp" style="margin-top:6px">Upload once in the shared Live Intake panel above. The government evidence workflow will auto-use the latest screenshot image from that queue and route it through automatic source handling.</div>
        </div>
        <div class="live-ingest-actions">
          <button class="btn-primary" type="button" data-gov-evidence-extract ${govEvidenceState.loading || !rec || !getGovEvidenceSourceAttachment() ? 'disabled' : ''}>${govEvidenceState.loading ? 'Extracting...' : 'Extract Latest Screenshot'}</button>
          <button class="btn-secondary" type="button" data-gov-evidence-clear ${govEvidenceState.loading ? 'disabled' : ''}>Clear Review</button>
        </div>
        ${govEvidenceState.review ? `<div class="live-ingest-callout" style="margin-top:12px">${esc(buildGovEvidenceSummary(govEvidenceState.review))}</div>` : ''}
        ${renderGovEvidenceConflictPanel()}
        ${govEvidenceState.queueError ? `<div class="live-ingest-callout warn" style="margin-top:12px">${esc(govEvidenceState.queueError)}</div>` : ''}
      </div>
      <div class="live-ingest-pane">
        <div class="live-ingest-actions" style="margin-bottom:8px;flex-wrap:wrap">
          <button class="btn-secondary" type="button" data-gov-evidence-save ${govEvidenceState.loading || !govEvidenceState.review ? 'disabled' : ''}>Save Artifact</button>
          <button class="btn-secondary" type="button" data-gov-evidence-broker ${govEvidenceState.loading || !govEvidenceState.review ? 'disabled' : ''}>Apply Broker</button>
          <button class="btn-primary" type="button" data-gov-evidence-safe ${govEvidenceState.loading || !govEvidenceState.review || unresolvedGovEvidenceConflicts().length ? 'disabled' : ''}>${unresolvedGovEvidenceConflicts().length ? 'Resolve Conflicts First' : 'Apply Safe Evidence'}</button>
          <button class="btn-secondary" type="button" data-gov-evidence-promote-rows ${govEvidenceState.loading || !govEvidenceState.review ? 'disabled' : ''}>Promote Rows</button>
          <button class="btn-secondary" type="button" data-gov-evidence-refresh-queue ${govEvidenceState.queueLoading || !rec ? 'disabled' : ''}>${govEvidenceState.queueLoading ? 'Refreshing...' : 'Refresh Queue'}</button>
          <button class="btn-secondary" type="button" data-gov-evidence-health ${govEvidenceState.healthLoading ? 'disabled' : ''}>${govEvidenceState.healthLoading ? 'Checking...' : 'Check Evidence Health'}</button>
        </div>
        <div class="live-ingest-stamp">Artifact: ${esc(govEvidenceState.artifactId || 'not saved yet')}</div>
        <div class="live-ingest-stamp" style="margin-top:6px">Source handling: auto from shared intake image</div>
        ${govEvidenceState.detectedSource ? `<div class="live-ingest-stamp" style="margin-top:6px">Detected source: ${esc(govEvidenceState.detectedSource.platform || 'unknown')} (${esc(String(govEvidenceState.detectedSource.confidence ?? ''))})</div>` : ''}
        ${govEvidenceState.health ? `<div class="live-ingest-callout ${govEvidenceState.health.status === 'ok' ? '' : 'warn'}" style="margin-top:10px">${esc(buildGovEvidenceHealthSummary(govEvidenceState.health))}</div>` : ''}
        <div style="margin-top:10px">
        ${govEvidenceState.brokerFeedback ? `<div class="live-ingest-callout" style="margin-top:10px"><strong>Broker Review Feedback</strong><div style="font-size:12px;color:var(--text2);margin-top:6px">${esc(buildGovBrokerFeedbackSummary(govEvidenceState.brokerFeedback))}</div></div>` : ''}
          <div class="live-ingest-results-title">Pending Observation Queue</div>
          ${queueHtml}
        </div>
      </div>
    </div>
  </section>`;
}

function buildGovEvidenceHealthSummary(health) {
  if (!health || typeof health !== 'object') return 'Evidence health unavailable.';
  const bits = [];
  bits.push(`status: ${health.status || 'unknown'}`);
  if (health.configuration) {
    bits.push(`openai: ${health.configuration.openai_api_key_configured ? 'ok' : 'missing'}`);
    bits.push(`supabase: ${health.configuration.supabase_service_role_configured ? 'ok' : 'missing'}`);
  }
  if (health.database) {
    bits.push(`db: ${health.database.connected ? 'ok' : 'down'}`);
    bits.push(`artifacts: ${health.database.research_artifacts_table ? 'ok' : 'missing'}`);
    bits.push(`observations: ${health.database.research_artifact_observations_table ? 'ok' : 'missing'}`);
    if (health.database.error) bits.push(`error: ${health.database.error}`);
  }
  return bits.join(' | ');
}

async function checkGovEvidenceHealth() {
  govEvidenceState.healthLoading = true;
  rerenderGovEvidenceOnly();
  try {
    govEvidenceState.health = await govEvidenceApi('evidence-health');
    showToast(govEvidenceState.health.status === 'ok' ? 'Evidence health check passed' : 'Evidence health check degraded', govEvidenceState.health.status === 'ok' ? 'success' : 'warning');
  } catch (err) {
    govEvidenceState.health = { status: 'error', database: { connected: false, error: err.message } };
    showToast(`Evidence health check failed: ${err.message}`, 'error');
  } finally {
    govEvidenceState.healthLoading = false;
    rerenderGovEvidenceOnly();
  }
}
function buildGovEvidenceSummary(review) {
  const bits = [];
  const address = pickGovEvidenceValue(review.property?.address, review.property?.property_name);
  const owner = pickGovEvidenceValue(review.ownership?.true_owner, review.ownership?.current_owner, review.property?.owner_name);
  const lender = pickGovEvidenceValue(review.loan?.lender, review.loan?.index_name);
  const avail = pickGovEvidenceValue(review.property?.available_sf, review.building?.available_sf);
  if (address) bits.push(address);
  if (owner) bits.push(`owner: ${owner}`);
  if (lender) bits.push(`lender: ${lender}`);
  if (avail) bits.push(`available: ${avail}`);
  const tenantCount = Array.isArray(review.tenants) ? review.tenants.length : 0;
  const leaseCount = Array.isArray(review.lease_activity) ? review.lease_activity.length : 0;
  if (tenantCount) bits.push(`${tenantCount} tenant row${tenantCount === 1 ? '' : 's'}`);
  if (leaseCount) bits.push(`${leaseCount} lease row${leaseCount === 1 ? '' : 's'}`);
  return bits.join(' | ') || 'Evidence extracted. Review and save if it looks correct.';
}

async function govEvidenceApi(endpoint, options = {}) {
  const query = new URLSearchParams({ endpoint });
  if (options.query && typeof options.query === 'object') {
    Object.entries(options.query).forEach(([key, value]) => {
      if (value != null && value !== '') query.set(key, value);
    });
  }
  const response = await fetch(`/api/gov-evidence?${query.toString()}`, {
    method: options.method || 'GET',
    headers: { 'Content-Type': 'application/json' },
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  const payload = await response.json().catch(e => { console.warn('[govEvidenceApi] JSON parse failed:', e.message); return {}; });
  if (!response.ok) {
    const detail = payload?.detail?.detail || payload?.detail?.error || payload?.error || 'Request failed';
    throw new Error(detail);
  }
  return payload;
}

async function ensureGovEvidenceArtifactSaved() {
  if (govEvidenceState.artifactId) return govEvidenceState.artifactId;
  const rec = getGovEvidenceContextRecord();
  if (!rec || !govEvidenceState.review) throw new Error('No evidence review payload to save');
  const binding = getGovEvidenceBinding(rec);
  const result = await govEvidenceApi('research-artifacts', {
    method: 'POST',
    body: {
      artifact_type: 'costar_screenshot',
      source_platform: 'costar',
      payload: govEvidenceState.review,
      file_name: getGovEvidenceSourceAttachment()?.name || 'lcc-screenshot.png',
      lead_id: binding.lead_id,
      property_id: binding.property_id,
      ownership_id: binding.ownership_id,
      actor: getGovEvidenceActor()
    }
  });
  govEvidenceState.artifactId = result?.id || null;
  return result?.id;
}

function buildGovBrokerFeedbackSummary(summary) {
  if (!summary || typeof summary !== 'object') return 'No broker feedback yet.';
  const statusCounts = summary.status_counts || {};
  const dismissCounts = summary.dismiss_reason_counts || {};
  const parts = [];
  if (typeof summary.total_rows === 'number') parts.push(`Rows ${summary.total_rows}`);
  if (statusCounts.promoted) parts.push(`Promoted ${statusCounts.promoted}`);
  if (statusCounts.dismissed) parts.push(`Dismissed ${statusCounts.dismissed}`);
  const topDismiss = Object.entries(dismissCounts).sort((a, b) => b[1] - a[1]).slice(0, 3);
  if (topDismiss.length) {
    parts.push(`Top dismiss reasons: ${topDismiss.map(([reason, count]) => `${reason} (${count})`).join(', ')}`);
  }
  return parts.join(' | ') || 'No broker feedback yet.';
}

async function loadGovEvidenceObservations(force = false) {
  // Evidence workbench disabled until GovernmentProject FastAPI is deployed
  return;
  const rec = syncGovEvidenceContext();
  if (!rec) return;
  if (govEvidenceState.queueLoaded && !force) return;
  govEvidenceState.queueLoading = true;
  govEvidenceState.brokerFeedbackLoading = true;
  govEvidenceState.queueError = '';
  rerenderGovEvidenceOnly();
  try {
    const binding = getGovEvidenceBinding(rec);
    const [result, feedbackResult] = await Promise.all([
      govEvidenceApi('research-observations', {
        query: {
          status: 'pending_review',
          lead_id: binding.lead_id,
          property_id: binding.property_id,
          ownership_id: binding.ownership_id
        }
      }),
      govEvidenceApi('broker-feedback', {
        query: {
          lead_id: binding.lead_id,
          property_id: binding.property_id,
          ownership_id: binding.ownership_id
        }
      })
    ]);
    const observations = Array.isArray(result?.observations) ? result.observations : (Array.isArray(result?.items) ? result.items : []);
    govEvidenceState.queue = observations;
    govEvidenceState.brokerFeedback = feedbackResult?.summary || null;
    govEvidenceState.queueLoaded = true;
  } catch (err) {
    govEvidenceState.queueError = err.message || 'Could not load evidence queue';
    govEvidenceState.queueLoaded = true; // Prevent retry loop on config errors
    if (!govEvidenceState._toastShown) {
      showToast('Evidence queue load failed: ' + govEvidenceState.queueError, 'error');
      govEvidenceState._toastShown = true;
    }
  } finally {
    govEvidenceState.queueLoading = false;
    govEvidenceState.brokerFeedbackLoading = false;
    rerenderGovEvidenceOnly();
  }
}

function rerenderGovEvidenceOnly() {
  // Guard: only re-render if user is still on the government tab
  // Async callbacks (evidence queue, extraction) can fire after tab switch
  if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'government') return;
  renderGovTab();
}

async function govEvidenceExtractScreenshot(rec) {
  const attachment = getGovEvidenceSourceAttachment();
  if (!rec || !attachment?.data_url) return;
  govEvidenceState.loading = true;
  rerenderGovEvidenceOnly();
  try {
    const context = [rec.address, rec.city, rec.state, rec.lease_number].filter(Boolean).join(' | ');
    const result = await govEvidenceApi('extract-screenshot-json', {
      method: 'POST',
      body: {
        image_data_url: attachment.data_url,
        file_name: attachment.name || 'lcc-screenshot.png',
        source: 'auto',
        extra_context: context
      }
    });
    govEvidenceState.review = result?.data || null;
    govEvidenceState.artifactId = null;
    govEvidenceState.detectedSource = result?.detected_source || { platform: result?.source || 'unknown', confidence: '' };
    govEvidenceState.conflicts = buildGovEvidenceConflictList(govEvidenceState.review, rec);
    applyGovEvidenceReviewToForm(govEvidenceState.review);
    appendGovEvidenceNote(`Extracted screenshot evidence from ${attachment.name || 'shared intake screenshot'}.`);
    showToast('Screenshot evidence extracted', 'success');
  } catch (err) {
    showToast(`Evidence extraction failed: ${err.message}`, 'error');
  } finally {
    govEvidenceState.loading = false;
    rerenderGovEvidenceOnly();
  }
}

async function applyGovEvidenceSafeBundle() {
  if (!govEvidenceState.review) return;
  govEvidenceState.loading = true;
  rerenderGovEvidenceOnly();
  const applied = [];
  const skipped = [];
  const endpoints = [
    ['apply-ownership', 'owner'],
    ['apply-listing', 'listing'],
    ['apply-activity-note', 'activity'],
    ['apply-loan', 'loan']
  ];
  try {
    for (const [endpoint, label] of endpoints) {
      try {
        await govEvidenceApi(endpoint, {
          method: 'POST',
          query: { artifact_id: govEvidenceState.artifactId, actor: getGovEvidenceActor() },
          body: { actor: getGovEvidenceActor() }
        });
        applied.push(label);
      } catch (err) {
        skipped.push(`${label}: ${err.message}`);
      }
    }
    applyGovEvidenceReviewToForm(govEvidenceState.review);
    appendGovEvidenceNote(`Safe evidence applied. Applied: ${applied.join(', ') || 'none'}. ${skipped.length ? `Skipped: ${skipped.join(' | ')}` : ''}`.trim());
    showToast(`Safe evidence applied: ${applied.join(', ') || 'none'}`, applied.length ? 'success' : 'warning');
  } catch (err) {
    showToast(`Safe evidence apply failed: ${err.message}`, 'error');
  } finally {
    govEvidenceState.loading = false;
    rerenderGovEvidenceOnly();
  }
}

async function promoteGovEvidenceRows() {
  if (!govEvidenceState.review) return;
  govEvidenceState.loading = true;
  rerenderGovEvidenceOnly();
  try {
    const artifactId = await ensureGovEvidenceArtifactSaved();
    const result = await govEvidenceApi('promote-observations', {
      method: 'POST',
      query: { artifact_id: artifactId, actor: getGovEvidenceActor() },
      body: { actor: getGovEvidenceActor() }
    });
    const count = result?.promoted_count || 0;
    appendGovEvidenceNote(`Promoted ${count} evidence row${count === 1 ? '' : 's'} into the review queue.`);
    showToast(`Promoted ${count} evidence row${count === 1 ? '' : 's'}`, 'success');
    govEvidenceState.queueLoaded = false;
    await loadGovEvidenceObservations(true);
  } catch (err) {
    showToast(`Promote rows failed: ${err.message}`, 'error');
  } finally {
    govEvidenceState.loading = false;
    rerenderGovEvidenceOnly();
  }
}

async function reviewGovEvidenceObservation(idx, action, resolutionNote = null) {
  const row = govEvidenceState.queue[idx];
  if (!row) return;
  try {
    await govEvidenceApi('review-observation', {
      method: 'POST',
      query: { observation_id: row.observation_id, actor: getGovEvidenceActor() },
      body: { action, actor: getGovEvidenceActor(), resolution_note: resolutionNote || `LCC ${action}` }
    });
    showToast(`Observation ${action}`, 'success');
    await loadGovEvidenceObservations(true);
  } catch (err) {
    showToast(`Observation update failed: ${err.message}`, 'error');
  }
}

async function promoteGovEvidenceObservation(idx) {
  const row = govEvidenceState.queue[idx];
  if (!row) return;
  if (row.promotion_guard?.message) {
    const confirmed = await lccConfirm(row.promotion_guard.message + '\n\nContinue with promotion?', 'Promote');
    if (!confirmed) return;
  }
  try {
    await govEvidenceApi('promote-observation', {
      method: 'POST',
      query: { observation_id: row.observation_id, actor: getGovEvidenceActor() },
      body: { actor: getGovEvidenceActor(), resolution_note: row.promotion_guard?.message || 'Promoted from LCC evidence queue' }
    });
    appendGovEvidenceNote(`Promoted evidence row: ${row.summary || row.observation_value || row.observation_type || 'observation'}`);
    showToast('Observation promoted', 'success');
    await loadGovEvidenceObservations(true);
  } catch (err) {
    showToast(`Observation promotion failed: ${err.message}`, 'error');
  }
}

function bindGovEvidenceWorkbench() {
  syncGovEvidenceContext();
  document.querySelector('[data-gov-evidence-extract]')?.addEventListener('click', () => govEvidenceExtractScreenshot(researchQueue[researchIdx]));
  document.querySelector('[data-gov-evidence-clear]')?.addEventListener('click', () => {
    govEvidenceState.review = null;
    govEvidenceState.artifactId = null;
    govEvidenceState.conflicts = [];
    govEvidenceState.detectedSource = null;
    rerenderGovEvidenceOnly();
  });
  document.querySelector('[data-gov-evidence-broker]')?.addEventListener('click', async () => {
    try {
      govEvidenceState.loading = true;
      rerenderGovEvidenceOnly();
      const artifactId = await ensureGovEvidenceArtifactSaved();
      const result = await govEvidenceApi('apply-broker-contact', {
        method: 'POST',
        query: { artifact_id: artifactId, actor: getGovEvidenceActor() },
        body: { actor: getGovEvidenceActor() }
      });
      const brokerName = result?.contact?.name || result?.lead_result?.contact_name || 'broker';
      appendGovEvidenceNote(`Applied broker contact from evidence: ${brokerName}`);
      showToast('Broker contact applied', 'success');
    } catch (err) {
      showToast(`Broker apply failed: ${err.message}`, 'error');
    } finally {
      govEvidenceState.loading = false;
      rerenderGovEvidenceOnly();
    }
  });
  document.querySelector('[data-gov-evidence-save]')?.addEventListener('click', async () => {
    try {
      govEvidenceState.loading = true;
      rerenderGovEvidenceOnly();
      await ensureGovEvidenceArtifactSaved();
      appendGovEvidenceNote(`Saved evidence artifact ${govEvidenceState.artifactId}.`);
      showToast('Evidence artifact saved', 'success');
    } catch (err) {
      showToast(`Artifact save failed: ${err.message}`, 'error');
    } finally {
      govEvidenceState.loading = false;
      rerenderGovEvidenceOnly();
    }
  });
  document.querySelector('[data-gov-evidence-safe]')?.addEventListener('click', () => applyGovEvidenceSafeBundle());
  document.querySelector('[data-gov-evidence-promote-rows]')?.addEventListener('click', () => promoteGovEvidenceRows());
  document.querySelector('[data-gov-evidence-refresh-queue]')?.addEventListener('click', () => loadGovEvidenceObservations(true));
  document.querySelector('[data-gov-evidence-health]')?.addEventListener('click', () => checkGovEvidenceHealth());
  document.querySelectorAll('[data-gov-evidence-conflict]').forEach((button) => {
    button.onclick = () => {
      const raw = button.dataset.govEvidenceConflict || '';
      const splitAt = raw.lastIndexOf(':');
      if (splitAt <= 0) return;
      const conflictId = raw.slice(0, splitAt);
      const resolution = raw.slice(splitAt + 1);
      applyGovEvidenceConflictResolution(conflictId, resolution);
      if (resolution === 'keep_current') {
        applyGovEvidenceReviewToForm(govEvidenceState.review);
      }
      appendGovEvidenceNote(`[SAFE EVIDENCE CONFLICT] ${conflictId} -> ${resolution}`);
      rerenderGovEvidenceOnly();
    };
  });
  document.querySelectorAll('[data-gov-evidence-note]').forEach((button) => {
    button.onclick = () => {
      const idx = Number(button.dataset.govEvidenceNote);
      const row = govEvidenceState.queue[idx];
      if (!row) return;
      appendGovEvidenceNote(`Evidence row: ${row.summary || row.observation_value || row.observation_type || 'observation'}`);
      showToast('Evidence row appended to notes', 'success');
    };
  });
  document.querySelectorAll('[data-gov-evidence-review]').forEach((button) => {
    button.onclick = () => reviewGovEvidenceObservation(Number(button.dataset.govEvidenceReview), 'reviewed');
  });
  document.querySelectorAll('[data-gov-evidence-dismiss]').forEach((button) => {
    button.onclick = async () => {
      if (!(await lccConfirm('Dismiss this evidence observation?', 'Dismiss'))) return;
      reviewGovEvidenceObservation(Number(button.dataset.govEvidenceDismiss), 'dismissed');
    };
  });
  document.querySelectorAll('[data-gov-evidence-dismiss-reason]').forEach((button) => {
    button.onclick = async () => {
      const raw = button.dataset.govEvidenceDismissReason || '';
      const splitAt = raw.indexOf('::');
      if (splitAt <= 0) return;
      const idx = Number(raw.slice(0, splitAt));
      const reason = raw.slice(splitAt + 2);
      if (!(await lccConfirm('Dismiss this observation with reason: "' + reason + '"?', 'Dismiss'))) return;
      reviewGovEvidenceObservation(idx, 'dismissed', `Broker dismiss reason: ${reason}`);
    };
  });
  document.querySelectorAll('[data-gov-evidence-promote]').forEach((button) => {
    button.onclick = () => promoteGovEvidenceObservation(Number(button.dataset.govEvidencePromote));
  });
  if (!govEvidenceState.queueLoaded && !govEvidenceState.queueLoading && getGovEvidenceContextRecord()) {
    loadGovEvidenceObservations(false);
  }
}


// ============================================================================
// TAB RENDERERS
// ============================================================================

// ── Shared Gov-overview helpers (used by renderGovOutreachInner & renderGovOverview) ──
const _colors = { blue: '#60a5fa', green: '#34d399', cyan: '#22d3ee', purple: '#a78bfa', yellow: '#fbbf24', orange: '#fb923c', red: '#f87171' };
function govCard(opts) {
  const c = _colors[opts.color] || _colors.blue;
  const clickAttr = opts.tab ? ` onclick="goToGovTab('${opts.tab}')"` : '';
  return `<div class="gov-info-card"${clickAttr}>
    <div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:6px">${opts.title}</div>
    <div style="font-size:24px;font-weight:800;color:${c};margin-bottom:4px">${opts.value}</div>
    ${opts.sub ? `<div style="font-size:11px;color:var(--text2)">${opts.sub}</div>` : ''}
  </div>`;
}
function govSectionHeader(title, icon, tab) {
  const viewLink = tab ? `<span onclick="goToGovTab('${tab}')" style="cursor:pointer;font-size:11px;color:var(--accent);font-weight:500">View Details →</span>` : '';
  return `<div style="display:flex;align-items:center;justify-content:space-between;margin:20px 0 10px;padding-bottom:6px;border-bottom:1px solid var(--border)">
    <div style="font-size:13px;font-weight:700;color:var(--text1)">${icon} ${title}</div>${viewLink}</div>`;
}
function inlineBar(items, maxVal) {
  let out = '';
  items.forEach(item => {
    const barW = maxVal > 0 ? Math.round((item.value / maxVal) * 100) : 0;
    out += `<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
      <div title="${esc(item.label)}" style="width:${item.labelWidth || 100}px;font-size:11px;color:var(--text2);text-align:right;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(item.label)}</div>
      <div style="flex:1;height:8px;background:var(--s3);border-radius:4px;overflow:hidden"><div style="width:${barW}%;height:100%;background:${item.barColor || '#60a5fa'};border-radius:4px"></div></div>
      <div style="width:${item.valueWidth || 50}px;font-size:10px;color:var(--text2);text-align:right">${item.display}</div>
    </div>`;
  });
  return out;
}

function renderGovOutreachInner() {
  const now = new Date();
  const yearStart = new Date(now.getFullYear(), 0, 1);
  const allActivities = (typeof activities !== 'undefined' ? activities : []);
  // Match by computed_category OR by subject/company containing government agency keywords
  const govCategoryTokens = ['government', 'gsa', 'va ', 'ssa', 'usps', 'federal', 'state/local'];
  const govSubjectTokens = /\b(gsa|general services|social security admin|veterans affairs|usps|postal service|irs|internal revenue|department of|bureau of|u\.?s\.? marshal|fbi|dhs|ice |cbp|fema|hud|dot |epa|usda|doj|dod)\b/i;
  const govActivities = allActivities.filter(a => {
    const cat = (a.computed_category || '').toLowerCase();
    if (govCategoryTokens.some(c => cat.includes(c))) return true;
    if (govSubjectTokens.test(a.subject || '')) return true;
    if (govSubjectTokens.test(a.company_name || '')) return true;
    return false;
  });

  if (allActivities.length === 0) {
    return '<div class="gov-info-card" style="padding:14px 16px;text-align:center;color:var(--text3)">'
      + 'Loading activity data...'
      + '</div>';
  }

  const touchpointsYTD = govActivities.filter(a => a.activity_date && new Date(a.activity_date) >= yearStart).length;
  const sixMonthsAgo = new Date(now); sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
  const touchpoints6mo = govActivities.filter(a => a.activity_date && new Date(a.activity_date) >= sixMonthsAgo).length;
  const oneMonthAgo = new Date(now); oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
  const touchpoints1mo = govActivities.filter(a => a.activity_date && new Date(a.activity_date) >= oneMonthAgo).length;
  const uniqueGovAccounts = new Set(govActivities.map(a => a.company_name).filter(Boolean)).size;

  let h = '<div class="gov-grid gov-grid-4">';
  h += govCard({ title: 'Touchpoints YTD', value: fmtN(touchpointsYTD), sub: now.getFullYear() + ' year to date', color: 'blue' });
  h += govCard({ title: 'Last 6 Months', value: fmtN(touchpoints6mo), sub: 'gov contacts', color: 'green' });
  h += govCard({ title: 'Last 30 Days', value: fmtN(touchpoints1mo), sub: 'recent contacts', color: 'cyan' });
  h += govCard({ title: 'Unique Accounts', value: fmtN(uniqueGovAccounts), sub: 'gov entities touched', color: 'purple' });
  h += '</div>';

  // Per-category breakdown
  if (govActivities.length > 0) {
    const catCounts = {};
    govActivities.forEach(a => { const c = a.computed_category || 'Uncategorized'; catCounts[c] = (catCounts[c] || 0) + 1; });
    if (Object.keys(catCounts).length >= 1) {
      h += '<div class="gov-info-card" style="padding:14px 16px;margin-top:10px">';
      h += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">Touchpoints by Category</div>';
      const maxCat = Math.max(...Object.values(catCounts));
      h += inlineBar(Object.entries(catCounts).sort((a,b) => b[1] - a[1]).map(([cat, count]) => ({
        label: cat, value: count, display: fmtN(count), barColor: '#60a5fa', labelWidth: 120, valueWidth: 35
      })), maxCat);
      h += '</div>';
    }
  } else {
    h += '<div class="gov-info-card" style="padding:14px 16px;margin-top:10px;color:var(--text3);font-size:12px">'
      + 'No government-categorized touchpoints found in Salesforce activities. '
      + 'Tag activities with a Government category in Salesforce to populate this section.'
      + '</div>';
  }
  return h;
}

function renderGovOverview() {
  // ── Kick off lazy-loading sales comps for overview metrics ──
  if (!govSalesComps && !govSalesLoading) {
    govSalesLoading = true;
    (async () => {
      try {
        let all = [], offset = 0;
        while (true) {
          const res = await govQuery('v_sales_comps', '*', { order: 'sale_date.desc.nullslast', limit: 1000, offset });
          const rows = res.data || [];
          all = all.concat(rows);
          if (rows.length < 1000) break;
          offset += 1000;
        }
        govSalesComps = all;
      } catch(e) { console.warn('Gov sales comps load failed:', e.message); govSalesComps = []; }
      govSalesLoading = false;
      const el = document.getElementById('govOverviewSales');
      if (el) el.innerHTML = renderGovSalesMetrics();
      const nmEl = document.getElementById('govOverviewNM');
      if (nmEl) nmEl.innerHTML = renderGovNorthmarqMetrics();
    })();
  }

  // Listings-confirm / LLC / Ownership Coverage count tiles now render
  // SYNCHRONOUSLY from the caches loaded in the main Promise.all (mirrors dia),
  // so the re-render can't strand them on "loading…". Fill the resolve LISTS
  // once the Overview HTML is in the DOM — re-render safe (getElementById
  // no-ops if the Overview isn't mounted).
  setTimeout(function() { try { renderGovListingConfirm(); } catch (e) {} }, 0);

  // LLC per-owner resolve list — a separate endpoint; lazy, gated on cache-null
  // (not a once-flag). The count tiles do NOT depend on it.
  if (window._govLlcQueueItems == null && !window.__govLlcQueueLoading) {
    window.__govLlcQueueLoading = true;
    (async () => {
      try {
        const ctl = new AbortController();
        const to = setTimeout(() => ctl.abort(), 12000);
        let resp;
        try { resp = await fetch('/api/llc-research-queue?domain=government&limit=25', { signal: ctl.signal }); }
        finally { clearTimeout(to); }
        const j = resp && resp.ok ? await resp.json() : {};
        window._govLlcQueueItems = (j && j.items) || [];
      } catch (e) {
        console.warn('gov llc list load failed', e && e.message);
        window._govLlcQueueItems = window._govLlcQueueItems || [];
      }
      window.__govLlcQueueLoading = false;
      try { renderGovLlcQueue(); } catch (e) {}
    })();
  }
  setTimeout(function() { try { renderGovLlcQueue(); } catch (e) {} }, 0);

  let html = '<div style="padding:4px 0">';

  // ── Early MV check (needed before style/helper blocks) ──
  const portfolio = govData.portfolioProperties || [];
  const mv = govOverviewStats;
  const useMV = mv && portfolio.length === 0; // Use MV when full data hasn't loaded yet

  // Show background loading indicator when using MV fast path
  if (useMV && !govDataLoaded) {
    html += '<div style="display:flex;align-items:center;gap:8px;padding:8px 12px;margin-bottom:8px;background:var(--bg2);border-radius:8px;font-size:12px;color:var(--text2)"><span class="spinner" style="width:14px;height:14px"></span> Loading detailed data in background...</div>';
  }

  // ── STYLE ──
  html += `<style>
    .gov-info-card { background: var(--s2); border: 1px solid var(--border); border-radius: 12px; padding: 16px 18px; transition: all 0.15s; position: relative; overflow: hidden; }
    .gov-info-card:hover { border-color: var(--accent); transform: translateY(-1px); box-shadow: 0 4px 20px rgba(0,0,0,0.15); }
    .gov-info-card[onclick] { cursor: pointer; }
    .gov-info-card[onclick]::after { content: '→'; position: absolute; top: 12px; right: 14px; font-size: 14px; color: var(--text3); opacity: 0; transition: opacity 0.15s; }
    .gov-info-card[onclick]:hover::after { opacity: 1; color: var(--accent); }
    .gov-grid { display: grid; gap: 10px; }
    .gov-grid-3 { grid-template-columns: repeat(3, 1fr); }
    .gov-grid-4 { grid-template-columns: repeat(4, 1fr); }
    .gov-grid-5 { grid-template-columns: repeat(5, 1fr); }
    @media (max-width: 700px) {
      .gov-grid-3, .gov-grid-4, .gov-grid-5 { grid-template-columns: repeat(2, 1fr); }
    }
  </style>`;

  // ── Helpers (now at module scope — see above renderGovOutreachInner) ──

  // ──────────────────────────────────────
  // DATA COMPUTATIONS (portfolio, mv, useMV declared above)
  // ──────────────────────────────────────
  const propCount = govData.properties[0]?.count || portfolio.length;
  const ownership = govData.ownership || [];
  const leads = govData.leads || [];
  const contacts = govData.contacts || [];
  const listings = govData.listings || [];
  const gsaEvents = govData.gsaEvents || [];
  const gsaSnapshots = govData.gsaSnapshots || [];
  const frpp = govData.frppRecords || [];
  const loans = govData.loans || [];
  const now = new Date();
  const yearStart = new Date(now.getFullYear(), 0, 1);

  // Portfolio aggregates
  const withSF = useMV ? [] : portfolio.filter(p => p.sf_leased > 0);
  const totalSF = useMV ? (mv.total_sf || mv.total_sf_leased || 0) : withSF.reduce((s, p) => s + (p.sf_leased || 0), 0);
  const totalGrossRent = useMV ? (mv.total_gross_rent || 0) : portfolio.reduce((s, p) => s + (p.gross_rent || 0), 0);
  const withRentPSF = useMV ? [] : portfolio.filter(p => p.gross_rent_psf > 0);
  const avgRentPSF = useMV ? (mv.avg_rent_psf ? Number(mv.avg_rent_psf).toFixed(2) : '—') : (withRentPSF.length > 0 ? (withRentPSF.reduce((s,p) => s + p.gross_rent_psf, 0) / withRentPSF.length).toFixed(2) : '—');
  const totalNOI = useMV ? (mv.total_noi || 0) : portfolio.reduce((s, p) => s + (p.noi || 0), 0);
  // QA-24 (2026-05-18): prefer agency_canonical so the count isn't inflated
  // by raw-string variants ("US Department of Veteran Affairs" vs
  // "US Department of Veterans Affairs - 1" etc). Falls back to raw agency
  // for rows that don't match the canonicalizer.
  // QA-28 (2026-05-18): also exclude private businesses with "Federal" in
  // the name (credit unions, self-storage, banks) that the canonicalizer
  // correctly returned NULL for. These were polluting the distinct-agency
  // count and the Agency Breakdown chart.
  const distinctAgencies = useMV ? (mv.agencies_tracked || mv.distinct_agencies || mv.agency_count || 0) : new Set(portfolio.map(p => p.agency_canonical || (p.agency && !_govIsPrivateFederalNamedEntity(p.agency) ? p.agency : null)).filter(Boolean)).size;
  // UI Phase 2 Unit 3 — honest denominator: the headline is the ACTIVE portfolio
  // (mv.total_properties excludes archived). Prefer the MV's active count whenever
  // the MV is loaded — not only on the fast path — so the headline doesn't flip to
  // the all-status count (~19,960) once the full portfolio finishes loading.
  const totalPropCount = mv ? (mv.total_properties || mv.property_count || 0) : propCount;
  const totalSFCount = useMV ? (mv.properties_with_sf || withSF.length) : withSF.length;
  const totalRentPSFCount = useMV ? (mv.properties_with_rent_psf || withRentPSF.length) : withRentPSF.length;

  // Lease expiration analysis
  const withTerm = useMV ? [] : portfolio.filter(p => p.firm_term_remaining !== null && p.firm_term_remaining !== undefined);
  const expiring1yr = useMV ? (mv.expiring_lt_1yr || mv.expiring_1yr || 0) : withTerm.filter(p => p.firm_term_remaining <= 1).length;
  const expiring2yr = useMV ? (mv.expiring_lt_2yr || mv.expiring_2yr || 0) : withTerm.filter(p => p.firm_term_remaining <= 2).length;
  const expiring5yr = useMV ? (mv.term_2_5yr || mv.expiring_2_5yr || 0) : withTerm.filter(p => p.firm_term_remaining > 2 && p.firm_term_remaining <= 5).length;
  const longTerm = useMV ? (mv.term_5plus || mv.long_term_5plus || 0) : withTerm.filter(p => p.firm_term_remaining > 5).length;
  const avgFirmTerm = useMV ? (mv.avg_firm_term ? Number(mv.avg_firm_term).toFixed(1) : '—') : (withTerm.length > 0 ? (withTerm.reduce((s,p) => s + p.firm_term_remaining, 0) / withTerm.length).toFixed(1) : '—');
  const withTermCount = useMV ? (mv.properties_with_term || withTerm.length) : withTerm.length;

  // ── Lease-expiration risk by ACTUAL lease_expiration date (R4-B forensic) ──
  // firm_term_remaining clamps to 0 once the FIRM term elapses, so seasoned
  // leases (a 5yr firm term inside a 15yr lease) pile into the 0-1yr firm
  // bucket even though the lease itself runs years more. "Lease expiration
  // risk" must be measured off lease_expiration, not firm_term_remaining.
  // Prefer the MV's server-side aggregate; fall back to a client-side pass over
  // the full (paginated) portfolio when the MV isn't loaded.
  const _msYr = 365.25 * 24 * 3600 * 1000;
  const _leaseExpYrs = (p) => {
    if (!p || !p.lease_expiration) return null;
    const d = new Date(p.lease_expiration);
    if (isNaN(d.getTime())) return null;
    return (d.getTime() - Date.now()) / _msYr;
  };
  const _withLeaseExp = portfolio.filter(p => _leaseExpYrs(p) !== null);
  const leaseExpiredCount   = mv ? (mv.lease_expired_count || 0)  : _withLeaseExp.filter(p => _leaseExpYrs(p) < 0).length;
  const leaseExpiredStale   = mv ? (mv.lease_expired_stale || 0)  : _withLeaseExp.filter(p => _leaseExpYrs(p) < -1).length;
  const expLease6mo  = mv ? (mv.exp_lease_lt_6mo  || 0) : _withLeaseExp.filter(p => { const y=_leaseExpYrs(p); return y>=0 && y<0.5; }).length;
  const expLease1yr  = mv ? (mv.exp_lease_lt_1yr  || 0) : _withLeaseExp.filter(p => { const y=_leaseExpYrs(p); return y>=0 && y<1; }).length;
  const expLease2_5  = mv ? (mv.exp_lease_2_5yr   || 0) : _withLeaseExp.filter(p => { const y=_leaseExpYrs(p); return y>=2 && y<5; }).length;
  const expLease5plus= mv ? (mv.exp_lease_5plus   || 0) : _withLeaseExp.filter(p => _leaseExpYrs(p) >= 5).length;
  const withLeaseExpCount = mv ? (mv.properties_with_lease_exp || _withLeaseExp.length) : _withLeaseExp.length;
  const leaseExpDistribution = (mv && mv.lease_distribution_by_expiry) ? mv.lease_distribution_by_expiry : (_withLeaseExp.length ? [
    { label: 'Expired / holdover', count: leaseExpiredCount, color: '#ef4444' },
    { label: '< 6 months', count: expLease6mo, color: '#f87171' },
    { label: '6 – 12 months', count: expLease1yr - expLease6mo, color: '#fb923c' },
    { label: '1 – 2 years', count: _withLeaseExp.filter(p => { const y=_leaseExpYrs(p); return y>=1 && y<2; }).length, color: '#fbbf24' },
    { label: '2 – 5 years', count: expLease2_5, color: '#34d399' },
    { label: '5+ years', count: expLease5plus, color: '#60a5fa' },
  ] : null);

  // Agency breakdown (top 10 by count) — only available with full data
  const agencyMap = {};
  let unknownAgencyStats = { count: 0, rent: 0, sf: 0, termSum: 0, termCount: 0 };
  if (!useMV) {
    portfolio.forEach(p => {
      // QA-24 (2026-05-18): group by agency_canonical so "US Department of
      // Veteran Affairs" / "US Department of Veterans Affairs - 1" / "VA"
      // all collapse into the canonical "VA" bucket. Falls back to raw
      // agency for rows that don't match the canonicalizer (state/local
      // tenants, etc.). Previously these split into separate top-agency
      // entries, fragmenting the chart and underreporting biggest tenants.
      // QA-28 (2026-05-18): skip private businesses with "Federal" in the
      // name (credit unions, self-storage, banks) — they aren't federal
      // tenants and were polluting the breakdown's bottom rows. Roll them
      // into the Unknown bucket instead so the chart stays focused on
      // real federal/state/local government tenants.
      let a;
      // R4-B: USPS facility "* SERVICES DIVISION" names (POTOMAC / METROPOLITAN
      // / TRIANGLE / DC SERVICES DIVISION) are vendor/division labels, not
      // leasing agencies — keep them out of the agency rollup.
      if (p.agency && /SERVICES DIVISION$/i.test(p.agency.trim())) {
        a = 'Unknown';
      } else if (p.agency_canonical) {
        a = p.agency_canonical;                             // canonical federal agency
      } else if (p.agency && _govIsPrivateFederalNamedEntity(p.agency)) {
        a = 'Unknown';                                      // QA-28: private "Federal" name → Unknown
      } else {
        a = p.agency || 'Unknown';                          // state/local govt fallback
      }
      if (a === 'Unknown') {
        // Separate tracking for Unknown agencies (Issue #5)
        unknownAgencyStats.count++;
        unknownAgencyStats.rent += (p.gross_rent || 0);
        unknownAgencyStats.sf += (p.sf_leased || 0);
        if (p.firm_term_remaining !== null) { unknownAgencyStats.termSum += p.firm_term_remaining; unknownAgencyStats.termCount++; }
      } else {
        if (!agencyMap[a]) agencyMap[a] = { count: 0, rent: 0, sf: 0, termSum: 0, termCount: 0 };
        agencyMap[a].count++;
        agencyMap[a].rent += (p.gross_rent || 0);
        agencyMap[a].sf += (p.sf_leased || 0);
        if (p.firm_term_remaining !== null) { agencyMap[a].termSum += p.firm_term_remaining; agencyMap[a].termCount++; }
      }
    });
  }
  // Try to use MV agency breakdown if available (JSON columns)
  let topAgencies, topAgenciesByRent;
  if (useMV && (mv.top_agencies_by_count || mv.top_agencies_json)) {
    try {
      const raw = mv.top_agencies_by_count || mv.top_agencies_json;
      const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
      topAgencies = (parsed || []).filter(a => (a.agency || a.name) !== 'Unknown').map(a => [a.agency || a.name, { count: a.count || 0, rent: a.rent || 0, sf: a.sf || 0, termSum: a.term_sum || 0, termCount: a.term_count || 0 }]);
      topAgenciesByRent = [...topAgencies].sort((a,b) => b[1].rent - a[1].rent).slice(0, 10);
      topAgencies = topAgencies.slice(0, 12);
      // Capture Unknown stats from parsed data if available
      const unknownInParsed = (parsed || []).find(a => (a.agency || a.name) === 'Unknown');
      if (unknownInParsed) {
        unknownAgencyStats = { count: unknownInParsed.count || 0, rent: unknownInParsed.rent || 0, sf: unknownInParsed.sf || 0, termSum: unknownInParsed.term_sum || 0, termCount: unknownInParsed.term_count || 0 };
      }
    } catch (e) { console.warn('Top agencies parse error:', e.message); topAgencies = []; topAgenciesByRent = []; }
  } else {
    topAgencies = Object.entries(agencyMap).sort((a,b) => b[1].count - a[1].count).slice(0, 12);
    topAgenciesByRent = Object.entries(agencyMap).sort((a,b) => b[1].rent - a[1].rent).slice(0, 10);
  }

  // State breakdown — only available with full data or MV JSON
  const stateMap = {};
  if (!useMV) {
    portfolio.forEach(p => {
      const s = p.state || 'UNK';
      if (!stateMap[s]) stateMap[s] = { count: 0, rent: 0, sf: 0 };
      stateMap[s].count++;
      stateMap[s].rent += (p.gross_rent || 0);
      stateMap[s].sf += (p.sf_leased || 0);
    });
  }
  let topStates;
  if (useMV && (mv.top_states_by_count || mv.top_states_json)) {
    try {
      const raw = mv.top_states_by_count || mv.top_states_json;
      const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
      topStates = (parsed || []).map(s => [s.state || s.name, { count: s.count || 0, rent: s.rent || 0, sf: s.sf || 0 }]);
    } catch (e) { console.warn('Top states parse error:', e.message); topStates = []; }
  } else {
    topStates = Object.entries(stateMap).sort((a,b) => b[1].count - a[1].count).slice(0, 10);
  }

  // ═══════════════════════════════════════════════
  // SECTION 0: ACTIONABLE HIGHLIGHTS (Round 51)
  // Auto-populated from live portfolio + pipeline data
  // ═══════════════════════════════════════════════
  const highlights = [];

  // Highlight 1: Leases expiring within 6 months
  // R4-D #6 (2026-06-05): bucket by ACTUAL lease_expiration date, matching the
  // R4-B Lease Expiration Risk section above (expLease6mo). The old predicate
  // counted firm_term_remaining <= 0.5, but firm_term_remaining clamps to 0
  // once the firm term elapses, so every long-expired lease piled into this
  // "expiring within 6 months" bucket (7,589 vs the section's 407). Use the
  // same [now, now+6mo) window — expLease6mo already resolves from the MV or
  // the client-side _withLeaseExp pass, so this works for both paths.
  if (expLease6mo > 0) {
    // Soonest property for the detail line — only available when we have the
    // per-property rows (non-MV pass, or portfolio otherwise loaded). Under the
    // MV path portfolio may be empty; the count is still correct from the MV.
    const sixMoLeases = _withLeaseExp
      .filter(p => { const y = _leaseExpYrs(p); return y >= 0 && y < 0.5; })
      .sort((a, b) => new Date(a.lease_expiration) - new Date(b.lease_expiration));
    const topLease = sixMoLeases[0];
    highlights.push({
      icon: '⏰', color: '#f87171', urgency: 'urgent',
      title: expLease6mo.toLocaleString() + ' lease' + (expLease6mo !== 1 ? 's' : '') + ' expiring within 6 months',
      detail: topLease
        ? 'Soonest: ' + (topLease.address || 'Unknown') + ' — ' + (topLease.agency || topLease.agency_full_name || 'Unknown agency')
        : 'Bucketed by actual lease_expiration date',
      action: 'Review Leases', tab: 'leases'
    });
  }

  // Highlight 2: Hot leads needing follow-up (>14 days since last contact)
  const hotLeadsStale = leads.filter(l => l.lead_temperature === 'hot' && l.last_contact_date
    && (Date.now() - new Date(l.last_contact_date).getTime()) > 14 * 86400000);
  if (hotLeadsStale.length > 0) {
    highlights.push({
      icon: '🔥', color: '#fb923c', urgency: 'warning',
      title: hotLeadsStale.length + ' hot lead' + (hotLeadsStale.length > 1 ? 's' : '') + ' overdue for follow-up',
      detail: 'Last contact >14 days ago — risk of going cold',
      action: 'View Pipeline', tab: 'pipeline'
    });
  }

  // Highlight 3: Loans maturing within 12 months
  if (loans.length > 0) {
    const oneYrFromNow = new Date();
    oneYrFromNow.setFullYear(oneYrFromNow.getFullYear() + 1);
    const maturingSoon = loans.filter(l => l.maturity_date && new Date(l.maturity_date) <= oneYrFromNow && new Date(l.maturity_date) >= now);
    if (maturingSoon.length > 0) {
      highlights.push({
        icon: '🏦', color: '#a78bfa', urgency: 'info',
        title: maturingSoon.length + ' loan' + (maturingSoon.length > 1 ? 's' : '') + ' maturing within 12 months',
        detail: 'Potential refinance or disposition opportunities',
        action: 'View Loans', tab: 'loans'
      });
    }
  }

  // Highlight 4: New pipeline leads (added in last 7 days)
  const recentLeads = leads.filter(l => l.created_at && (Date.now() - new Date(l.created_at).getTime()) < 7 * 86400000);
  if (recentLeads.length > 0) {
    highlights.push({
      icon: '🎯', color: '#34d399', urgency: 'info',
      title: recentLeads.length + ' new lead' + (recentLeads.length > 1 ? 's' : '') + ' added this week',
      detail: 'Review and assign temperatures',
      action: 'Triage Leads', tab: 'pipeline'
    });
  }

  // Highlight 5: Active listings on market
  const hlActiveListings = listings.filter(l => lccIsListingActive(l));
  if (hlActiveListings.length > 0) {
    highlights.push({
      icon: '📋', color: '#22d3ee', urgency: 'info',
      title: hlActiveListings.length + ' active listing' + (hlActiveListings.length > 1 ? 's' : '') + ' on market',
      detail: 'Monitor for competitive intel or acquisition targets',
      action: 'View Listings', tab: 'listings'
    });
  }

  // ── Data-quality (shared taxonomy: BD signals above, DQ here — mirrors dia) ──
  // Owner-research backlog: ownership changes still pending investigation.
  // Surfaces once govData.ownership has loaded (same async posture as dia's BD
  // signals); shows only when there's a count.
  const govNeedsResearch = (govData && Array.isArray(govData.ownership))
    ? govData.ownership.filter(o => !o.research_status || o.research_status === 'pending').length : 0;
  if (govNeedsResearch > 10) {
    highlights.push({
      icon: '🔎', color: '#a78bfa', urgency: 'info',
      title: fmtN(govNeedsResearch) + ' ownership change' + (govNeedsResearch > 1 ? 's' : '') + ' need research',
      detail: 'Pending owner investigation — resolve to connect the ownership + BD data',
      action: 'Research owners', tab: 'research'
    });
  }

  if (highlights.length > 0) {
    html += '<div style="margin-bottom:20px">';
    html += '<div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--text3);margin-bottom:10px;padding-left:2px">Action Items</div>';
    for (const h of highlights.slice(0, 6)) {
      const borderColor = h.urgency === 'urgent' ? h.color : h.urgency === 'warning' ? h.color : 'var(--border)';
      html += `<div style="display:flex;align-items:center;gap:12px;padding:10px 14px;margin-bottom:6px;background:var(--s2);border-radius:10px;border-left:3px solid ${borderColor};cursor:pointer" onclick="goToGovTab('${h.tab}')">`;
      html += `<span style="font-size:20px;flex-shrink:0">${h.icon}</span>`;
      html += `<div style="flex:1;min-width:0">`;
      html += `<div style="font-size:13px;font-weight:600;color:var(--text)">${esc(h.title)}</div>`;
      html += `<div style="font-size:12px;color:var(--text3);margin-top:2px">${esc(h.detail)}</div>`;
      html += `</div>`;
      html += `<button class="gov-row-action accent" onclick="event.stopPropagation();goToGovTab('${h.tab}')" style="flex-shrink:0">${esc(h.action)}</button>`;
      html += `</div>`;
    }
    html += '</div>';
  }

  // ═══════════════════════════════════════════════
  // SECTION 1: PORTFOLIO AT A GLANCE
  // ═══════════════════════════════════════════════
  html += govSectionHeader('Portfolio at a Glance', '🏛️', 'search');
  html += '<div class="gov-grid gov-grid-5">';
  html += govCard({ title: 'Total Properties', value: fmtN(totalPropCount), sub: 'active government-leased (archived excluded)', color: 'blue', tab: 'search' });
  html += govCard({ title: 'Total SF Leased', value: fmtN(Math.round(totalSF / 1e6)) + 'M', sub: fmtN(totalSFCount) + ' properties with data', color: 'green', tab: 'search' });
  html += govCard({ title: 'Total Gross Rent', value: '$' + fmtN(Math.round(totalGrossRent / 1e9)) + 'B', sub: 'annual government rent', color: 'cyan', tab: 'search' });
  html += govCard({ title: 'Avg Rent / SF', value: '$' + avgRentPSF, sub: fmtN(totalRentPSFCount) + ' properties', color: 'purple', tab: 'search' });
  html += govCard({ title: 'Agencies Tracked', value: fmtN(distinctAgencies), sub: 'distinct tenants', color: 'yellow', tab: 'search' });
  html += '</div>';

  // Total NOI row
  if (totalNOI > 0) {
    html += '<div class="gov-grid gov-grid-3" style="margin-top:10px">';
    html += govCard({ title: 'Total NOI', value: '$' + fmtN(Math.round(totalNOI / 1e6)) + 'M', sub: 'net operating income', color: 'green', tab: 'search' });
    const noiDenom = useMV ? (mv.properties_with_sf || totalPropCount) : withSF.length;
    const avgNOI = noiDenom > 0 ? totalNOI / noiDenom : 0;
    html += govCard({ title: 'Avg NOI / Property', value: avgNOI > 0 ? '$' + fmtN(Math.round(avgNOI / 1000)) + 'K' : '—', sub: 'across portfolio', color: 'blue', tab: 'search' });
    const contactCount = useMV ? (mv.total_contacts || contacts.length) : contacts.length;
    // R4-D #8: contacts is a Phase-2 array (govData.contacts, loaded after the
    // overview first paints). Until it resolves (and the MV didn't supply a
    // total), skeleton instead of painting a literal 0 the user can't tell from
    // a real "no contacts" — this is the "CONTACTS 0 → 10,520" flash.
    const _contactsLoading = !govData._phase2Loaded && contacts.length === 0 && !(useMV && mv.total_contacts);
    html += govCard({ title: 'Contacts', value: _contactsLoading ? '…' : fmtN(contactCount), sub: _contactsLoading ? 'loading…' : 'owners & principals', color: 'purple', tab: 'search' });
    html += '</div>';
  }

  // ═══════════════════════════════════════════════
  // SECTION 2: LEASE EXPIRATION RISK
  // ═══════════════════════════════════════════════
  html += govSectionHeader('Lease Expiration Risk', '⏰', 'pipeline');
  // Risk denominator is properties with a known lease_expiration date.
  const _expPct = (n) => withLeaseExpCount > 0 ? (n / withLeaseExpCount * 100).toFixed(1) + '% of dated leases' : '';
  html += '<div class="gov-grid gov-grid-5">';
  html += govCard({ title: 'Expiring < 6 Months', value: fmtN(expLease6mo), sub: _expPct(expLease6mo), color: 'red', tab: 'pipeline' });
  html += govCard({ title: 'Expiring < 1 Year', value: fmtN(expLease1yr), sub: _expPct(expLease1yr), color: 'orange', tab: 'pipeline' });
  html += govCard({ title: 'Expired / Holdover', value: fmtN(leaseExpiredCount), sub: fmtN(leaseExpiredStale) + ' expired >1yr (stale)', color: 'red', tab: 'pipeline' });
  html += govCard({ title: '2–5 Year Term', value: fmtN(expLease2_5), sub: 'mid-range leases', color: 'yellow', tab: 'search' });
  html += govCard({ title: '5+ Year Term', value: fmtN(expLease5plus), sub: 'long-term secured', color: 'green', tab: 'search' });
  html += '</div>';
  html += '<div style="font-size:11px;color:var(--text3);margin-top:6px">Bucketed by actual <b>lease_expiration</b> date over ' + fmtN(withLeaseExpCount) + ' dated leases. Avg firm term ' + avgFirmTerm + ' yrs.</div>';

  // Expiration timeline bar — from MV server-side aggregate (or full portfolio)
  if (leaseExpDistribution && leaseExpDistribution.length) {
    html += '<div class="gov-info-card" style="padding:14px 16px;margin-top:10px">';
    html += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">Lease Expiration Distribution</div>';
    const buckets = leaseExpDistribution.map(b => ({ label: b.label, count: Number(b.count) || 0, color: b.color }));
    const maxBucket = Math.max(1, ...buckets.map(b => b.count));
    html += inlineBar(buckets.map(b => ({
      label: b.label, value: b.count, display: fmtN(b.count), barColor: b.color, labelWidth: 110, valueWidth: 40
    })), maxBucket);
    html += '</div>';
  }

  // ═══════════════════════════════════════════════
  // SECTION 3: AGENCY BREAKDOWN
  // ═══════════════════════════════════════════════
  html += govSectionHeader('Agency Breakdown', '🏢', 'search');

  if (topAgencies.length > 0) {
    // Top agencies by property count
    html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">';
    html += '<div class="gov-info-card" onclick="goToGovTab(\'search\')" style="cursor:pointer;padding:14px 16px">';
    html += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">Top Agencies by Property Count</div>';
    const maxAgCount = topAgencies[0] && topAgencies[0][1] ? topAgencies[0][1].count : 1;
    html += inlineBar(topAgencies.map(([name, d]) => ({
      label: name, value: d.count, display: fmtN(d.count), barColor: '#60a5fa', labelWidth: 140, valueWidth: 40
    })), maxAgCount);
    html += '</div>';

    // Top agencies by rent
    html += '<div class="gov-info-card" onclick="goToGovTab(\'search\')" style="cursor:pointer;padding:14px 16px">';
    html += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">Top Agencies by Annual Rent</div>';
    const maxAgRent = topAgenciesByRent[0] && topAgenciesByRent[0][1] ? topAgenciesByRent[0][1].rent : 1;
    html += inlineBar(topAgenciesByRent.map(([name, d]) => ({
      label: name, value: d.rent, display: '$' + fmtN(Math.round(d.rent / 1e6)) + 'M', barColor: '#34d399', labelWidth: 140, valueWidth: 56
    })), maxAgRent);
    html += '</div>';
    html += '</div>';

    // Agency avg term remaining
    html += '<div class="gov-info-card" style="padding:14px 16px;margin-top:10px">';
    html += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">Avg Firm Term Remaining by Major Agency</div>';
    const agencyTerms = topAgencies.filter(([, d]) => d.termCount > 0).map(([name, d]) => ({
      name, avgTerm: d.termSum / d.termCount, count: d.count
    })).sort((a,b) => a.avgTerm - b.avgTerm);
    const maxTerm = Math.max(...agencyTerms.map(a => Math.max(a.avgTerm, 0)), 1);
    html += inlineBar(agencyTerms.map(a => ({
      label: a.name,
      value: Math.max(a.avgTerm, 0),
      display: a.avgTerm.toFixed(1) + ' yrs',
      barColor: a.avgTerm < 1 ? '#f87171' : a.avgTerm < 2 ? '#fb923c' : a.avgTerm < 5 ? '#fbbf24' : '#34d399',
      labelWidth: 140, valueWidth: 50
    })), maxTerm);
    html += '</div>';

    // Footnote for Unknown agency dominance (Issue #5)
    if (unknownAgencyStats.count > 0) {
      const unknownPct = portfolio.length > 0 ? ((unknownAgencyStats.count / portfolio.length) * 100).toFixed(1) : '0';
      const unknownRentM = Math.round(unknownAgencyStats.rent / 1e6);
      html += '<div class="gov-info-card" style="padding:12px 16px;margin-top:10px;background:rgba(100,100,100,0.1);border-left:3px solid rgba(100,100,100,0.3)">';
      html += '<div style="font-size:10px;color:var(--text3);line-height:1.4">';
      html += `<strong>${fmtN(unknownAgencyStats.count)} properties</strong> (${unknownPct}%) are tagged as "Unknown" agency, representing <strong>$${fmtN(unknownRentM)}M</strong> in annual rent. These may be inferrable from lease data or require enrichment.`;
      html += '</div></div>';
    }
  }

  // ═══════════════════════════════════════════════
  // SECTION 4: GEOGRAPHIC DISTRIBUTION
  // ═══════════════════════════════════════════════
  if (topStates.length > 0) {
    html += govSectionHeader('Geographic Distribution', '🗺️', 'search');
    html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">';

    // By count
    html += '<div class="gov-info-card" style="padding:14px 16px">';
    html += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">Top States by Property Count</div>';
    const maxStCount = topStates[0] && topStates[0][1] ? topStates[0][1].count : 1;
    html += inlineBar(topStates.map(([st, d]) => ({
      label: STATE_FULL[st] || st, value: d.count, display: fmtN(d.count), barColor: '#a78bfa', labelWidth: 110, valueWidth: 40
    })), maxStCount);
    html += '</div>';

    // By rent
    const topStatesByRent = Object.entries(stateMap).sort((a,b) => b[1].rent - a[1].rent).slice(0, 10);
    html += '<div class="gov-info-card" style="padding:14px 16px">';
    html += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">Top States by Annual Rent</div>';
    const maxStRent = topStatesByRent.length > 0 && topStatesByRent[0][1] ? topStatesByRent[0][1].rent : 1;
    html += inlineBar(topStatesByRent.map(([st, d]) => ({
      label: STATE_FULL[st] || st, value: d.rent, display: '$' + fmtN(Math.round(d.rent / 1e6)) + 'M', barColor: '#22d3ee', labelWidth: 110, valueWidth: 56
    })), maxStRent);
    html += '</div>';
    html += '</div>';
  }

  // ═══════════════════════════════════════════════
  // SECTION 5: OWNERSHIP INTELLIGENCE
  // ═══════════════════════════════════════════════
  const totalOwnershipChanges = ownership.length;
  const withSalePrice = ownership.filter(o => o.sale_price > 0);
  const confirmedValue = withSalePrice.reduce((s, o) => s + (o.sale_price || 0), 0);
  const needsResearch = ownership.filter(o => !o.research_status || o.research_status === 'pending').length;
  const ownershipCaps = withSalePrice.filter(o => o.cap_rate > 0.01 && o.cap_rate < 0.25).map(o => parseFloat(o.cap_rate)).sort((a,b) => a - b);
  const avgOwnershipCap = ownershipCaps.length > 0 ? (ownershipCaps.reduce((s,v) => s+v, 0) / ownershipCaps.length * 100).toFixed(2) + '%' : '—';

  html += govSectionHeader('Ownership Intelligence', '🔍', 'ownership');
  html += '<div class="gov-grid gov-grid-5">';
  // R4-C §5: while Phase-2 ownership data is still loading, show an honest
  // skeleton ('…') rather than computed zeros the user can't tell from real
  // data. Once loaded (or genuinely empty after load), show the real figures.
  const _ownLoading = !govData._phase2Loaded && totalOwnershipChanges === 0;
  const _sk = '…';
  html += govCard({ title: 'Ownership Changes', value: _ownLoading ? _sk : fmtN(totalOwnershipChanges), sub: _ownLoading ? 'loading…' : 'transfers tracked', color: 'blue', tab: 'ownership' });
  html += govCard({ title: 'Confirmed Sales', value: _ownLoading ? _sk : fmtN(withSalePrice.length), sub: _ownLoading ? 'loading…' : '$' + fmtN(Math.round(confirmedValue / 1e6)) + 'M total value', color: 'green', tab: 'ownership' });
  html += govCard({ title: 'Avg Sale Cap Rate', value: _ownLoading ? _sk : avgOwnershipCap, sub: _ownLoading ? 'loading…' : fmtN(ownershipCaps.length) + ' with cap data', color: 'cyan', tab: 'ownership' });
  html += govCard({ title: 'Needs Research', value: _ownLoading ? _sk : fmtN(needsResearch), sub: _ownLoading ? 'loading…' : 'pending investigation', color: 'yellow', tab: 'research' });
  html += govCard({ title: 'Research Coverage', value: _ownLoading ? _sk : (totalOwnershipChanges > 0 ? ((totalOwnershipChanges - needsResearch) / totalOwnershipChanges * 100).toFixed(1) + '%' : '—'), sub: _ownLoading ? 'loading…' : 'changes researched', color: 'purple', tab: 'research' });
  html += '</div>';

  // ═══════════════════════════════════════════════
  // SECTION 6: PROSPECT PIPELINE
  // ═══════════════════════════════════════════════
  // R4-B: totals/averages come from the server-side MV aggregate over ALL
  // leads, never from the page-limited (top-1,000-by-priority) `leads` array.
  // The capped array is high-value-biased, so avg-over-1000 was ~$28M/lead;
  // the true avg over the full book is ~$5-8M.
  const totalLeadsCount  = mv ? (mv.total_leads || leads.length) : leads.length;
  const hotLeads  = mv ? (mv.hot_leads  != null ? mv.hot_leads  : leads.filter(l => l.lead_temperature === 'hot').length)  : leads.filter(l => l.lead_temperature === 'hot').length;
  const warmLeads = mv ? (mv.warm_leads != null ? mv.warm_leads : leads.filter(l => l.lead_temperature === 'warm').length) : leads.filter(l => l.lead_temperature === 'warm').length;
  const pipelineValue   = mv ? Number(mv.pipeline_value_total || 0) : leads.reduce((s, l) => s + (l.estimated_value || 0), 0);
  const leadsWithValue  = mv ? (mv.leads_with_value || 0) : leads.filter(l => l.estimated_value > 0).length;
  // Avg over leads that actually carry an estimated value (avoids /total dilution).
  const avgLeadValue    = mv ? Number(mv.avg_lead_value || 0) : (leadsWithValue > 0 ? leads.reduce((s,l)=>s+(l.estimated_value||0),0)/leadsWithValue : 0);

  html += govSectionHeader('Prospect Pipeline', '🎯', 'pipeline');
  html += '<div class="gov-grid gov-grid-5">';
  const _capped = !mv && leads.length >= 1000;          // only "+" when we truly only saw a page
  const capSuffix = _capped ? '+' : '';
  html += govCard({ title: 'Total Leads', value: fmtN(totalLeadsCount) + capSuffix, sub: 'in pipeline', color: 'blue', tab: 'pipeline' });
  html += govCard({ title: 'Hot Leads', value: fmtN(hotLeads), sub: 'high priority', color: 'red', tab: 'pipeline' });
  html += govCard({ title: 'Warm Leads', value: fmtN(warmLeads), sub: 'active prospects', color: 'orange', tab: 'pipeline' });
  html += govCard({ title: 'Pipeline Value', value: '$' + fmtN(Math.round(pipelineValue / 1e6)) + 'M', sub: fmtN(leadsWithValue) + ' valued leads', color: 'green', tab: 'pipeline' });
  html += govCard({ title: 'Avg Lead Value', value: avgLeadValue > 0 ? '$' + fmtN(Math.round(avgLeadValue / 1000)) + 'K' : '—', sub: 'per valued prospect', color: 'purple', tab: 'pipeline' });
  html += '</div>';

  // Pipeline by agency
  const leadsByAgency = {};
  leads.forEach(l => { const a = l.tenant_agency || l.agency_full_name || 'Unknown'; leadsByAgency[a] = (leadsByAgency[a] || 0) + 1; });
  const topLeadAgencies = Object.entries(leadsByAgency).sort((a,b) => b[1] - a[1]).slice(0, 8);
  if (topLeadAgencies.length > 1) {
    html += '<div class="gov-info-card" onclick="goToGovTab(\'pipeline\')" style="cursor:pointer;padding:14px 16px;margin-top:10px">';
    html += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">Leads by Tenant Agency</div>';
    const maxLead = topLeadAgencies[0][1];
    html += inlineBar(topLeadAgencies.map(([name, cnt]) => ({
      label: name.length > 20 ? name.substring(0,18) + '…' : name,
      value: cnt, display: fmtN(cnt), barColor: '#fb923c', labelWidth: 130, valueWidth: 35
    })), maxLead);
    html += '</div>';
  }

  // Deal grade breakdown
  const gradeMap = {};
  leads.forEach(l => { if (l.deal_grade) gradeMap[l.deal_grade] = (gradeMap[l.deal_grade] || 0) + 1; });
  if (Object.keys(gradeMap).length > 0) {
    const gradeColors = { A: '#34d399', B: '#60a5fa', C: '#fbbf24', D: '#fb923c', F: '#f87171' };
    html += '<div class="gov-grid gov-grid-' + Math.min(Object.keys(gradeMap).length, 5) + '" style="margin-top:10px">';
    Object.entries(gradeMap).sort((a,b) => a[0].localeCompare(b[0])).forEach(([grade, cnt]) => {
      html += govCard({ title: 'Grade ' + grade, value: fmtN(cnt), sub: 'leads', color: grade === 'A' ? 'green' : grade === 'B' ? 'blue' : grade === 'C' ? 'yellow' : 'orange', tab: 'pipeline' });
    });
    html += '</div>';
  }

  // ═══════════════════════════════════════════════
  // SECTION 7: OUTREACH & TOUCHPOINTS
  // Rendered in a deferred div so it can refresh when activities load
  // ═══════════════════════════════════════════════
  html += govSectionHeader('Government Outreach', '📞', 'search');
  html += '<div id="govOutreachInner">' + renderGovOutreachInner() + '</div>';

  // ═══════════════════════════════════════════════
  // SECTION 8: TTM SALES
  // ═══════════════════════════════════════════════
  html += govSectionHeader('TTM Sales Activity', '💰', 'sales');
  html += '<div id="govOverviewSales">' + renderGovSalesMetrics() + '</div>';

  // ═══════════════════════════════════════════════
  // SECTION 9: NORTHMARQ PERFORMANCE
  // ═══════════════════════════════════════════════
  html += govSectionHeader('Northmarq Performance', '🏆', 'sales');
  html += '<div id="govOverviewNM">' + renderGovNorthmarqMetrics() + '</div>';

  // ═══════════════════════════════════════════════
  // SECTION 10: ON MARKET
  // ═══════════════════════════════════════════════
  // Canonical CURRENT on-market set (v_gov_on_market membership) — the ONE
  // definition, shared with the Listings tab + the CM available count.
  //
  // HEADLINE COUNT reads the canonical view membership DIRECTLY
  // (govData.onMarketIds.size) — it does NOT need the heavy `listings` array,
  // so it never blanks to 0 while that pull is empty/slow. Only when the view
  // load itself failed (null) do we fall back to the legacy status filter over
  // the client rows. The detail SUB-tiles (Total Asking / Avg Cap / Avg DOM /
  // Under Contract) genuinely need row fields, so they derive from the
  // intersected rows when `listings` is loaded and honestly show '—' when it
  // isn't — decoupled from the headline so a slow/failed listings pull can't
  // zero the count. Mirrors the dia v_dia_on_market pattern.
  const activeListingRows = govData.onMarketIds
    ? listings.filter(l => govData.onMarketIds.has(l.listing_id))
    : listings.filter(l => lccIsListingActive(l));
  const onMarketCount = govData.onMarketIds
    ? govData.onMarketIds.size
    : activeListingRows.length;
  const listingsLoaded = listings.length > 0;
  const underContract = listings.filter(l => (l.listing_status || '').toLowerCase() === 'under_contract');
  const totalAsking = activeListingRows.reduce((s, l) => s + (l.asking_price || 0), 0);
  const listingCaps = activeListingRows.filter(l => l.asking_cap_rate > 0.01 && l.asking_cap_rate < 0.25).map(l => parseFloat(l.asking_cap_rate)).sort((a,b) => a-b);
  const avgAskingCap = listingCaps.length > 0 ? (listingCaps.reduce((s,v)=>s+v,0)/listingCaps.length*100).toFixed(2)+'%' : '—';
  const avgDom = activeListingRows.filter(l => l.days_on_market > 0);
  const avgDomVal = avgDom.length > 0 ? Math.round(avgDom.reduce((s,l) => s + l.days_on_market, 0) / avgDom.length) : '—';
  // Sub-tile values fall back to '—' ("detail loading") when the row detail
  // isn't available yet, so they never mislead — but the headline count stands.
  const totalAskingVal = !listingsLoaded ? '—' : (totalAsking > 0 ? '$' + fmtN(Math.round(totalAsking / 1e6)) + 'M' : '—');
  const underContractVal = listingsLoaded ? fmtN(underContract.length) : '—';

  html += govSectionHeader('On Market', '🏢', 'listings');
  html += '<div class="gov-grid gov-grid-5">';
  html += govCard({ title: 'Active Listings', value: fmtN(onMarketCount), sub: 'currently on market', color: 'blue', tab: 'listings' });
  html += govCard({ title: 'Under Contract', value: underContractVal, sub: 'pending close', color: 'green', tab: 'listings' });
  html += govCard({ title: 'Total Asking', value: totalAskingVal, sub: 'active asking value', color: 'cyan', tab: 'listings' });
  html += govCard({ title: 'Avg Ask Cap', value: avgAskingCap, sub: fmtN(listingCaps.length) + ' with cap data', color: 'purple', tab: 'listings' });
  html += govCard({ title: 'Avg DOM', value: avgDomVal, sub: 'days on market', color: 'yellow', tab: 'listings' });
  html += '</div>';

  // ═══════════════════════════════════════════════
  // SECTION 11: GSA LEASE INTEL
  // ═══════════════════════════════════════════════
  // R4-B: GSA/FRPP headline totals come from the server-side MV. gsa_lease_events
  // (261K rows), gsa_snapshots (1.2M) and frpp_records (22K) are all loaded
  // page-capped (500/500/5000), so the old gsaEvents/gsaSnapshots/frpp arrays
  // are NOT the totals. GSA rent = sum over current gsa_leases (not the 1.2M
  // monthly snapshot rows, which would massively overcount).
  const gsaEventsYTD = mv ? (mv.gsa_events_ytd || 0) : gsaEvents.filter(e => e.event_date && new Date(e.event_date) >= yearStart).length;
  const gsaEventsTotal = mv ? (mv.gsa_events_total || 0) : gsaEvents.length;
  const gsaEventTypes = {};
  gsaEvents.forEach(e => { gsaEventTypes[e.event_type] = (gsaEventTypes[e.event_type] || 0) + 1; });
  const totalGsaRent = mv ? Number(mv.gsa_current_annual_rent || 0) : gsaSnapshots.reduce((s, s2) => s + (s2.annual_rent || 0), 0);
  const gsaLeasesTracked = mv ? (mv.gsa_leases_tracked || gsaSnapshots.length) : gsaSnapshots.length;
  const frppCountTotal = mv ? (mv.frpp_total || govData.frppCount || frpp.length) : (govData.frppCount || frpp.length);
  const frppTotalSF = mv ? Number(mv.frpp_total_sf || 0) : frpp.reduce((s, r) => s + (r.square_feet || 0), 0);
  const frppTotalRent = mv ? Number(mv.frpp_total_rent || 0) : frpp.reduce((s, r) => s + (r.annual_rent_to_lessor || 0), 0);
  const frppAgencies = mv ? (mv.frpp_distinct_agencies || 0) : new Set(frpp.map(r => r.using_agency).filter(Boolean)).size;

  html += govSectionHeader('GSA Lease Intelligence', '📋', 'search');
  html += '<div class="gov-grid gov-grid-4">';
  // R4-D #8: without the MV these four cards derive from the Phase-2 gsaEvents /
  // gsaSnapshots / frpp arrays, which are empty until the background load
  // finishes — so they painted literal 0 / $0M. Skeleton while pending. (When
  // the MV is present the totals are real immediately, so no skeleton.)
  const _gsaLoading = !mv && !govData._phase2Loaded;
  const _gsaSk = '…';
  html += govCard({ title: 'GSA Events YTD', value: _gsaLoading ? _gsaSk : fmtN(gsaEventsYTD), sub: _gsaLoading ? 'loading…' : (now.getFullYear() + ' of ' + fmtN(gsaEventsTotal) + ' tracked'), color: 'blue' });
  html += govCard({ title: 'GSA Total Rent', value: _gsaLoading ? _gsaSk : ('$' + fmtN(Math.round(totalGsaRent / 1e6)) + 'M'), sub: _gsaLoading ? 'loading…' : (fmtN(gsaLeasesTracked) + ' leases tracked'), color: 'green' });
  html += govCard({ title: 'FRPP Square Feet', value: _gsaLoading ? _gsaSk : (fmtN(Math.round(frppTotalSF / 1e6)) + 'M'), sub: _gsaLoading ? 'loading…' : (fmtN(frppCountTotal) + ' federal properties'), color: 'cyan' });
  html += govCard({ title: 'FRPP Agencies', value: _gsaLoading ? _gsaSk : fmtN(frppAgencies), sub: _gsaLoading ? 'loading…' : ('$' + fmtN(Math.round(frppTotalRent / 1e6)) + 'M annual rent'), color: 'purple' });
  html += '</div>';

  // GSA event type breakdown
  if (Object.keys(gsaEventTypes).length > 0) {
    html += '<div class="gov-info-card" style="padding:14px 16px;margin-top:10px">';
    html += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">GSA Event Types</div>';
    const maxEvt = Math.max(...Object.values(gsaEventTypes));
    html += inlineBar(Object.entries(gsaEventTypes).sort((a,b) => b[1] - a[1]).map(([type, count]) => ({
      label: type, value: count, display: fmtN(count), barColor: '#22d3ee', labelWidth: 120, valueWidth: 35
    })), maxEvt);
    html += '</div>';
  }

  // ═══════════════════════════════════════════════
  // SECTION 12: DATA HEALTH & COVERAGE (ops — at the bottom; mirrors dia)
  // Groups the data-quality / coverage blocks (Listings confirmation, LLC
  // research queue, Ownership coverage) under one labelled footer so the dia
  // and gov Overviews end the same way (UI Phase 2 Unit 2).
  // ═══════════════════════════════════════════════
  html += '<div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:1.5px;color:var(--text3);margin:30px 0 0;padding:0 2px 6px;border-bottom:2px solid var(--border)">Data Health &amp; Coverage</div>';

  // ── Listings Needing Confirmation (manual follow-up) — counts render
  // SYNCHRONOUSLY from window._govLcConfirmRows (main-loaded); list fills via the
  // scheduled renderGovListingConfirm() above. ──
  html += govSectionHeader('Listings Needing Confirmation', '🔎', 'listings');
  html += '<div id="govListingConfirm">' + _govListingConfirmTiles() + '<div id="govLcConfirmList" style="margin-top:10px"></div></div>';

  // ── LLC Research Queue — counts render SYNCHRONOUSLY from the main-loaded
  // health globals; list fills via the scheduled renderGovLlcQueue() above. ──
  html += govSectionHeader('LLC Research Queue', '🏛️', 'research');
  html += '<div id="govLlcQueue">' + _govLlcTiles() + '<div id="govLlcQueueList" style="margin-top:10px"></div></div>';

  // ── Ownership Coverage — rendered SYNCHRONOUSLY from window._govOwnershipCoverage
  // + window._govUnprospectedTotal (main-loaded). No hanging async / once-flag. ──
  html += govSectionHeader('Ownership Coverage', '🏛️', 'ownership');
  html += '<div id="govOwnershipCoverage">' + _govOwnershipCoverageCards() + '</div>';

  html += '</div>'; // end wrapper
  return html;
}

// ── Gov Overview inner renderers (lazy-loaded sections) ──

function renderGovSalesMetrics() {
  const sales = govSalesComps || govData.salesComps || [];
  if (!govSalesComps && govSalesLoading) {
    return '<div class="gov-grid gov-grid-5"><div class="gov-info-card" style="grid-column:span 5;text-align:center;padding:24px"><span class="spinner"></span><div style="margin-top:8px;font-size:12px;color:var(--text2)">Loading sales data...</div></div></div>';
  }
  const _c = { blue: '#60a5fa', green: '#34d399', cyan: '#22d3ee', purple: '#a78bfa', yellow: '#fbbf24' };
  function card(opts) {
    const c = _c[opts.color] || _c.blue;
    const clickAttr = opts.tab ? ` onclick="goToGovTab('${opts.tab}')"` : '';
    return `<div class="gov-info-card"${clickAttr}><div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:6px">${opts.title}</div><div style="font-size:24px;font-weight:800;color:${c};margin-bottom:4px">${opts.value}</div>${opts.sub ? `<div style="font-size:11px;color:var(--text2)">${opts.sub}</div>` : ''}</div>`;
  }

  // R4-B: headline counts/volumes come from the server-side MV (full
  // sales_transactions table), never from the loaded comps array (`sales` is
  // value-sorted and may be a partial/first page — the old code labeled its
  // .length as the database total). Cap-rate quartiles stay row-level (the MV
  // can't express percentiles cheaply) and are explicitly a sample of loaded
  // comps.
  const mv = (typeof govOverviewStats !== 'undefined') ? govOverviewStats : null;
  const now = new Date();
  const ttmStart = new Date(now); ttmStart.setFullYear(ttmStart.getFullYear() - 1);
  const ttmSales = sales.filter(r => r.sale_date && new Date(r.sale_date) >= ttmStart);
  const ttmWithPrice = ttmSales.filter(r => (r.sold_price || r.sale_price) > 0);
  const ttmVolumeLoaded = ttmWithPrice.reduce((s, r) => s + parseFloat(r.sold_price || r.sale_price || 0), 0);
  const ttmVolume = mv ? Number(mv.sales_ttm_volume || ttmVolumeLoaded) : ttmVolumeLoaded;
  const ttmCount = mv ? (mv.sales_ttm_count != null ? mv.sales_ttm_count : ttmSales.length) : ttmSales.length;
  // Normalize mixed cap rate formats (0.07 decimal vs 7.15 percentage) to decimal
  const validCaps = ttmSales.map(r => { const v = parseFloat(r.sold_cap_rate || r.cap_rate); return v > 0 ? (v < 1 ? v : v / 100) : null; }).filter(v => v && v > 0.01 && v < 0.25).sort((a,b) => a - b);
  const avgCap = validCaps.length > 0 ? (validCaps.reduce((s,v) => s+v, 0) / validCaps.length * 100).toFixed(2) + '%' : '—';
  const q1 = validCaps.length > 4 ? (validCaps[Math.floor(validCaps.length * 0.25)] * 100).toFixed(2) + '%' : '—';
  const q3 = validCaps.length > 4 ? (validCaps[Math.floor(validCaps.length * 0.75)] * 100).toFixed(2) + '%' : '—';

  let h = '<div class="gov-grid gov-grid-5">';
  h += card({ title: 'TTM Volume', value: '$' + fmtN(Math.round(ttmVolume / 1e6)) + 'M', sub: 'trailing 12 months', color: 'green', tab: 'sales' });
  h += card({ title: 'TTM Transactions', value: fmtN(ttmCount), sub: 'trailing 12 months', color: 'blue', tab: 'sales' });
  h += card({ title: 'Avg Cap Rate', value: avgCap, sub: fmtN(validCaps.length) + ' loaded comps', color: 'cyan', tab: 'sales' });
  h += card({ title: 'Lower Quartile', value: q1, sub: '25th pctile (sample)', color: 'purple', tab: 'sales' });
  h += card({ title: 'Upper Quartile', value: q3, sub: '75th pctile (sample)', color: 'yellow', tab: 'sales' });
  h += '</div>';

  // All-time — server-side totals from the MV (fall back to loaded array)
  const allWithPriceLoaded = sales.filter(r => (r.sold_price || r.sale_price) > 0);
  const totalVolumeLoaded = allWithPriceLoaded.reduce((s,r) => s + parseFloat(r.sold_price || r.sale_price || 0), 0);
  const allComps   = mv ? (mv.total_sales || sales.length) : sales.length;
  const pricedCnt  = mv ? (mv.sales_priced_count || allWithPriceLoaded.length) : allWithPriceLoaded.length;
  const totalVolume = mv ? Number(mv.sales_total_volume || totalVolumeLoaded) : totalVolumeLoaded;
  const avgSale    = mv ? Number(mv.sales_avg_price || 0) : (allWithPriceLoaded.length > 0 ? totalVolumeLoaded / allWithPriceLoaded.length : 0);
  h += '<div class="gov-grid gov-grid-3" style="margin-top:10px">';
  h += card({ title: 'All-Time Comps', value: fmtN(allComps), sub: 'total in database', color: 'blue', tab: 'sales' });
  h += card({ title: 'All-Time Volume', value: '$' + fmtN(Math.round(totalVolume / 1e6)) + 'M', sub: fmtN(pricedCnt) + ' priced sales', color: 'green', tab: 'sales' });
  h += card({ title: 'Avg Sale Price', value: avgSale > 0 ? '$' + fmtN(Math.round(avgSale)) : '—', sub: 'priced comps', color: 'purple', tab: 'sales' });
  h += '</div>';
  return h;
}

function renderGovNorthmarqMetrics() {
  const sales = govSalesComps || govData.salesComps || [];
  if (!govSalesComps && govSalesLoading) {
    return '<div class="gov-grid gov-grid-4"><div class="gov-info-card" style="grid-column:span 4;text-align:center;padding:24px"><span class="spinner"></span><div style="margin-top:8px;font-size:12px;color:var(--text2)">Loading...</div></div></div>';
  }
  const _c = { blue: '#60a5fa', green: '#34d399', cyan: '#22d3ee', yellow: '#fbbf24' };
  function card(opts) {
    const c = _c[opts.color] || _c.blue;
    const clickAttr = opts.tab ? ` onclick="goToGovTab('${opts.tab}')"` : '';
    return `<div class="gov-info-card"${clickAttr}><div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:6px">${opts.title}</div><div style="font-size:24px;font-weight:800;color:${c};margin-bottom:4px">${opts.value}</div>${opts.sub ? `<div style="font-size:11px;color:var(--text2)">${opts.sub}</div>` : ''}</div>`;
  }

  const now = new Date();
  const ttmStart = new Date(now); ttmStart.setFullYear(ttmStart.getFullYear() - 1);
  const ttmSales = sales.filter(r => r.sale_date && new Date(r.sale_date) >= ttmStart);
  // Canonical NM attribution = the is_northmarq flag (app.js lccIsNorthmarq) —
  // identical to dia, the CM views, and detail.js so "% NM" reconciles across
  // surfaces. The flag is a complete superset of broker-name matching here too
  // (2026-05-29 audit: 0 name-matches were unflagged).
  const isNM = r => lccIsNorthmarq(r);
  const nmSales = ttmSales.filter(isNM);
  const nmWithPrice = nmSales.filter(r => (r.sold_price || r.sale_price) > 0);
  const nmVolume = nmWithPrice.reduce((s,r) => s + parseFloat(r.sold_price || r.sale_price || 0), 0);
  const marketShareTxn = ttmSales.length > 0 ? (nmSales.length / ttmSales.length * 100).toFixed(1) + '%' : '—';
  const nmCaps = nmSales.filter(r => { const v = parseFloat(r.sold_cap_rate || r.cap_rate); return v > 0.01 && v < 0.25; }).map(r => parseFloat(r.sold_cap_rate || r.cap_rate));
  const mktCaps = ttmSales.filter(r => { const v = parseFloat(r.sold_cap_rate || r.cap_rate); return v > 0.01 && v < 0.25; }).map(r => parseFloat(r.sold_cap_rate || r.cap_rate));
  const nmAvgCap = nmCaps.length > 0 ? (nmCaps.reduce((s,v)=>s+v,0)/nmCaps.length*100).toFixed(2) + '%' : '—';
  const mktAvgCap = mktCaps.length > 0 ? (mktCaps.reduce((s,v)=>s+v,0)/mktCaps.length*100).toFixed(2) + '%' : '—';
  const capAdv = (nmCaps.length > 0 && mktCaps.length > 0) ?
    ((mktCaps.reduce((s,v)=>s+v,0)/mktCaps.length - nmCaps.reduce((s,v)=>s+v,0)/nmCaps.length) * 10000).toFixed(0) : null;

  let h = '<div class="gov-grid gov-grid-4">';
  h += card({ title: 'NM TTM Sales', value: fmtN(nmSales.length), sub: '$' + fmtN(Math.round(nmVolume / 1e6)) + 'M volume', color: 'green', tab: 'sales' });
  h += card({ title: 'Market Share', value: marketShareTxn, sub: fmtN(nmSales.length) + ' of ' + fmtN(ttmSales.length) + ' TTM deals', color: 'blue', tab: 'sales' });
  h += card({ title: 'NM Avg Cap Rate', value: nmAvgCap, sub: 'vs ' + mktAvgCap + ' market avg', color: 'cyan', tab: 'sales' });
  h += card({ title: 'Seller Value Add', value: capAdv ? capAdv + ' bps tighter' : '—', sub: capAdv && parseInt(capAdv, 10) > 0 ? 'tighter caps = higher proceeds' : 'vs market average', color: parseInt(capAdv, 10) > 0 ? 'green' : 'yellow', tab: 'sales' });
  h += '</div>';
  return h;
}

function renderGovOwnership() {
  const totalChanges = govData.ownership.length;
  const withSalePrice = govData.ownership.filter(o => o.sale_price).length;
  const needsResearch = govData.ownership.filter(o => !o.research_status || o.research_status === 'pending').length;
  const confirmedValue = govData.ownership.filter(o => o.sale_price).reduce((sum, o) => sum + (o.sale_price || 0), 0);
  
  // Value by year
  const valByYear = {};
  govData.ownership.forEach(o => {
    if (o.transfer_date && o.sale_price) {
      const year = o.transfer_date.substring(0, 4);
      valByYear[year] = (valByYear[year] || 0) + o.sale_price;
    }
  });
  
  const yearLabels = Object.keys(valByYear).sort();
  const yearData = yearLabels.map(y => valByYear[y]);
  
  // === Action guidance banner ===
  let html = '<div style="padding:10px 14px;background:rgba(251,191,36,0.08);border-radius:8px;border-left:3px solid #fbbf24;margin-bottom:16px;display:flex;align-items:center;gap:10px;">';
  html += '<div style="font-size:13px;color:var(--text);line-height:1.4"><strong>Ownership Transfers</strong> — Review recent property ownership changes. Click any row to view transfer details, update research status, and verify sale information. Records marked "Needs Research" require ownership verification in the <em>Research</em> tab.</div>';
  html += '</div>';

  html += '<div class="gov-metrics">';
  html += metricHTML('Total Changes', fmtN(totalChanges), 'Ownership transfers', 'blue');
  html += metricHTML('With Sale Price', fmtN(withSalePrice), 'Confirmed value', 'green');
  html += metricHTML('Needs Research', fmtN(needsResearch), 'Pending', 'yellow');
  html += metricHTML('Confirmed Value', fmt(confirmedValue), 'Total', 'purple');
  html += '</div>';
  
  if (yearLabels.length > 0) {
    html += `<div class="chart-container">
      <h3>Value by Year</h3>
      <canvas id="chart-own-year" height="80"></canvas>
    </div>`;
  }
  
  html += '<div class="table-section">';
  html += '<h3>Ownership History</h3>';
  html += ownershipTable(govData.ownership.slice(0, 100));
  html += '</div>';
  
  setTimeout(() => {
    if (yearLabels.length > 0) {
      renderBarChart('chart-own-year', yearLabels, [{ label: 'Sale Value', data: yearData }], true);
    }
  }, 100);
  
  return html;
}

function renderGovPipeline() {
  // Deduplicate leads by lead_id (data may contain duplicate rows from JOINs)
  const seenIds = new Set();
  const dedupedLeads = govData.leads.filter(l => {
    const key = l.lead_id || (l.address + '|' + l.city + '|' + l.tenant_agency);
    if (seenIds.has(key)) return false;
    seenIds.add(key);
    return true;
  });
  // R4-B: headline KPIs come from the server-side MV (true totals over the full
  // prospect_leads table). dedupedLeads stays the working set for the table /
  // charts below, but it's the top-1,000-by-priority page — its .length and
  // value-sum are NOT the pipeline totals.
  const _ovMv = (typeof govOverviewStats !== 'undefined') ? govOverviewStats : null;
  const totalLeads = _ovMv ? (_ovMv.total_leads || dedupedLeads.length) : dedupedLeads.length;
  const atCap = !_ovMv && govData.leads.length >= 1000;   // only a "+" when we truly only have a page
  const hotCount = _ovMv ? (_ovMv.hot_leads != null ? _ovMv.hot_leads : dedupedLeads.filter(l => l.lead_temperature === 'hot').length) : dedupedLeads.filter(l => l.lead_temperature === 'hot').length;
  const warmCount = _ovMv ? (_ovMv.warm_leads != null ? _ovMv.warm_leads : dedupedLeads.filter(l => l.lead_temperature === 'warm').length) : dedupedLeads.filter(l => l.lead_temperature === 'warm').length;
  const coolCount = _ovMv ? Math.max(0, (_ovMv.total_leads || 0) - hotCount - warmCount) : (dedupedLeads.length - dedupedLeads.filter(l => l.lead_temperature === 'hot').length - dedupedLeads.filter(l => l.lead_temperature === 'warm').length);

  const pipelineValue = _ovMv ? Number(_ovMv.pipeline_value_total || 0) : dedupedLeads.reduce((sum, l) => sum + (l.estimated_value || 0), 0);

  // Leads by source
  const bySource = {};
  dedupedLeads.forEach(l => {
    const source = cleanLabel(l.lead_source || 'Unknown');
    bySource[source] = (bySource[source] || 0) + 1;
  });

  const sourceLabels = Object.keys(bySource).sort((a, b) => bySource[b] - bySource[a]).slice(0, 8);
  const sourceData = sourceLabels.map(s => bySource[s]);

  // Temperature breakdown
  const tempLabels = ['Hot', 'Warm', 'Cool'];
  const tempData = [hotCount, warmCount, coolCount];
  const tempColors = ['#f87171', '#fbbf24', '#6c8cff'];

  // === Action guidance banner ===
  let html = '<div style="padding:10px 14px;background:rgba(96,165,250,0.08);border-radius:8px;border-left:3px solid #60a5fa;margin-bottom:16px;display:flex;align-items:center;gap:10px;">';
  html += '<div style="font-size:13px;color:var(--text);line-height:1.4"><strong>Prospect Pipeline</strong> — Review and prioritize leads by temperature and score. Click any row to open property detail. Use temperature filters and sort to triage your pipeline on a call.</div>';
  html += '</div>';

  // ── KPI cards (clickable = temperature filter) ──
  html += '<div class="gov-metrics">';
  const tfAll = govPipelineTempFilter === 'all';
  const tfHot = govPipelineTempFilter === 'hot';
  const tfWarm = govPipelineTempFilter === 'warm';
  const tfCool = govPipelineTempFilter === 'cool';
  html += metricHTML('Total Leads', fmtN(totalLeads) + (atCap ? '+' : ''), 'in pipeline' + (atCap ? ' (first 1,000)' : ''), 'blue',
    `onclick="govPipelineTempFilter='all';renderGovTab()" style="cursor:pointer;${tfAll ? 'outline:2px solid var(--accent);outline-offset:-2px;' : ''}"`);
  html += metricHTML('Hot', fmtN(hotCount) + (atCap ? '+' : ''), 'high priority', 'red',
    `onclick="govPipelineTempFilter='hot';renderGovTab()" style="cursor:pointer;${tfHot ? 'outline:2px solid #f87171;outline-offset:-2px;' : ''}"`);
  html += metricHTML('Warm', fmtN(warmCount) + (atCap ? '+' : ''), 'active prospects', 'yellow',
    `onclick="govPipelineTempFilter='warm';renderGovTab()" style="cursor:pointer;${tfWarm ? 'outline:2px solid #fbbf24;outline-offset:-2px;' : ''}"`);
  html += metricHTML('Pipeline Value', fmt(pipelineValue) + (atCap ? '+' : ''), 'estimated total', 'purple');
  html += '</div>';

  html += `<div class="charts-row">`;

  if (sourceLabels.length > 0) {
    html += `<div class="chart-container half">
      <h3>Leads by Source</h3>
      <canvas id="chart-leads-source" height="200"></canvas>
    </div>`;
  }

  html += `<div class="chart-container half">
    <h3>Temperature</h3>
    <canvas id="chart-leads-temp" height="200"></canvas>
  </div>`;

  html += '</div>';

  // ── Filter / Sort / Search toolbar (Round 50) ──
  html += '<div class="widget" style="margin-bottom:16px;padding:12px 14px">';
  html += '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">';
  // Search
  html += '<input type="text" placeholder="Search address, agency, city..." value="' + esc(govPipelineSearch) + '" '
    + 'oninput="govPipelineSearch=this.value;govRenderPipelineTable()" '
    + 'style="flex:1;min-width:180px;padding:7px 10px;font-size:12px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text)">';
  // Sort
  html += '<select onchange="govPipelineSort=this.value;govRenderPipelineTable()" style="padding:7px 8px;font-size:12px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text)">';
  html += '<option value="score"' + (govPipelineSort === 'score' ? ' selected' : '') + '>Sort: Score (High→Low)</option>';
  html += '<option value="value"' + (govPipelineSort === 'value' ? ' selected' : '') + '>Sort: Value (High→Low)</option>';
  html += '<option value="contact"' + (govPipelineSort === 'contact' ? ' selected' : '') + '>Sort: Last Contact (Recent)</option>';
  html += '<option value="address"' + (govPipelineSort === 'address' ? ' selected' : '') + '>Sort: Address (A→Z)</option>';
  html += '</select>';
  // Temperature filter pills (alternative to KPI cards)
  html += '<div style="display:flex;gap:4px">';
  const tFilters = [
    { key: 'all', label: 'All', count: totalLeads },
    { key: 'hot', label: 'Hot', count: hotCount, color: '#f87171' },
    { key: 'warm', label: 'Warm', count: warmCount, color: '#fbbf24' },
    { key: 'cool', label: 'Cool', count: coolCount, color: '#6c8cff' }
  ];
  for (const tf of tFilters) {
    const active = govPipelineTempFilter === tf.key;
    html += `<button onclick="govPipelineTempFilter='${tf.key}';renderGovTab()" style="padding:4px 10px;font-size:11px;font-weight:600;border:1px solid ${active ? (tf.color || 'var(--accent)') : 'var(--border)'};border-radius:20px;background:${active ? (tf.color ? tf.color + '18' : 'rgba(96,165,250,0.1)') : 'transparent'};color:${active ? (tf.color || 'var(--accent)') : 'var(--text3)'};cursor:pointer">${tf.label} (${fmtN(tf.count)})</button>`;
  }
  html += '</div>';
  html += '</div></div>';

  // ── Filtered + sorted leads table ──
  html += '<div id="govPipelineTableContainer">';
  html += buildGovPipelineTable(dedupedLeads);
  html += '</div>';

  setTimeout(() => {
    if (sourceLabels.length > 0) {
      renderPieChart('chart-leads-source', sourceLabels, sourceData);
    }
    renderHBarChart('chart-leads-temp', tempLabels, tempData, tempColors);
  }, 100);

  return html;
}

/**
 * Build the filtered + sorted pipeline table (called on search/sort change too).
 */
function buildGovPipelineTable(allLeads) {
  // Apply temperature filter
  let filtered = allLeads;
  if (govPipelineTempFilter !== 'all') {
    filtered = filtered.filter(l => (l.lead_temperature || 'cool') === govPipelineTempFilter);
  }

  // Apply search
  if (govPipelineSearch.trim()) {
    const q = govPipelineSearch.trim().toLowerCase();
    filtered = filtered.filter(l =>
      (l.address || '').toLowerCase().includes(q) ||
      (l.tenant_agency || l.agency_full_name || '').toLowerCase().includes(q) ||
      (l.city || '').toLowerCase().includes(q) ||
      (l.state || '').toLowerCase().includes(q) ||
      (l.lessor_name || '').toLowerCase().includes(q)
    );
  }

  // Apply sort
  switch (govPipelineSort) {
    case 'score':
      filtered.sort((a, b) => (b.priority_score || 0) - (a.priority_score || 0));
      break;
    case 'value':
      filtered.sort((a, b) => (b.estimated_value || 0) - (a.estimated_value || 0));
      break;
    case 'contact':
      filtered.sort((a, b) => (b.last_contact_date || '').localeCompare(a.last_contact_date || ''));
      break;
    case 'address':
      filtered.sort((a, b) => (a.address || '').localeCompare(b.address || ''));
      break;
  }

  if (filtered.length === 0) {
    return '<div style="text-align:center;padding:24px;color:var(--text3);font-size:13px">'
      + (govPipelineSearch ? 'No leads match "' + esc(govPipelineSearch) + '"' : 'No leads in this filter')
      + '</div>';
  }

  let html = '<div class="widget"><div class="widget-title">Prospects <span style="font-size:12px;font-weight:400;color:var(--text3)">(' + fmtN(filtered.length) + ' showing)</span></div>';
  html += '<div class="gov-table-card"><table class="gov-table"><thead><tr>';
  html += '<th>Score</th><th>Temp</th><th>Address</th><th>City, State</th><th>Tenant</th><th style="text-align:right">Value</th><th>Pipeline</th><th>Last Contact</th><th style="text-align:center;min-width:90px">Actions</th>';
  html += '</tr></thead><tbody>';

  for (const r of filtered.slice(0, 75)) {
    const tempColor = { hot: '#f87171', warm: '#fbbf24', cool: '#6c8cff' }[r.lead_temperature] || '#9498a8';
    const pipelineStatus = r.pipeline_status || 'new';
    const lastContact = r.last_contact_date ? new Date(r.last_contact_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '—';
    const daysSince = r.last_contact_date ? Math.floor((Date.now() - new Date(r.last_contact_date).getTime()) / 86400000) : null;
    const contactColor = daysSince === null ? 'var(--text3)' : daysSince > 30 ? 'var(--red)' : daysSince > 14 ? '#fb923c' : 'var(--text2)';

    html += `<tr class="clickable-row" onclick='showDetail(${safeJSON(r)}, "gov-lead")'>`;
    html += `<td style="font-weight:700">${r.priority_score || 0}</td>`;
    html += `<td><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${tempColor};margin-right:4px"></span><span style="color:${tempColor};font-size:12px;font-weight:600">${esc((r.lead_temperature || 'cool').toUpperCase())}</span></td>`;
    html += `<td style="font-weight:500">${esc(norm(r.address) || '—')}</td>`;
    html += `<td>${esc(norm(r.city) || '')}${r.state ? ', ' + esc(r.state) : ''}</td>`;
    html += `<td style="font-size:12px">${esc(norm(r.tenant_agency || r.agency_full_name) || '—')}</td>`;
    html += `<td style="text-align:right;font-weight:600">${r.estimated_value ? fmt(r.estimated_value) : '—'}</td>`;
    html += `<td><span style="font-size:11px;padding:2px 8px;border-radius:10px;background:var(--s2);border:1px solid var(--border);color:var(--text2)">${cleanLabel(pipelineStatus)}</span></td>`;
    html += `<td style="color:${contactColor};font-size:12px">${lastContact}${daysSince != null && daysSince > 14 ? ' <span style="font-size:10px">(' + daysSince + 'd ago)</span>' : ''}</td>`;
    // Actions column
    html += '<td style="text-align:center" onclick="event.stopPropagation()">';
    html += '<div style="display:flex;gap:3px;justify-content:center">';
    html += `<button class="gov-row-action" onclick="showDetail(${safeJSON(r)}, 'gov-lead', 'Ownership')" title="View owner details & contacts">📞</button>`;
    html += `<button class="gov-row-action accent" onclick="showDetail(${safeJSON(r)}, 'gov-lead', 'Intel')" title="Research & intel">🔍</button>`;
    html += '</div></td>';
    html += '</tr>';
  }

  html += '</tbody></table></div>';
  if (filtered.length > 75) {
    html += `<div style="text-align:center;padding:8px;font-size:12px;color:var(--text3)">Showing 75 of ${fmtN(filtered.length)} leads</div>`;
  }
  html += '</div>';
  return html;
}

// openIntakeArtifact lives in app.js now so it's available on every dashboard
// (gov, dialysis, entity hub). Kept here as a stub reference for searchability;
// see app.js for the implementation.

/**
 * Re-render just the pipeline table (on search/sort change without full re-render).
 */
// QA-25 (2026-05-18): show top unprospected owners modal. Opens when user
// clicks the reframed "Unprospected Owners" card on the gov home dashboard.
// Data was prefetched by the ownership-coverage block and stashed at
// window._govTopUnprospected (rows from v_prospect_targets).
window._govShowProspectTargets = function() {
  const rows = window._govTopUnprospected || [];
  // QA-29 (2026-05-18): footer uses the true total (not rows.length, which
  // is capped at the query limit).
  const trueTotal = window._govUnprospectedTotal || rows.length;
  if (!rows.length) {
    alert('Loading prospect targets — try again in a moment.');
    return;
  }
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let modal = document.getElementById('govProspectModal');
  if (modal) modal.remove();
  modal = document.createElement('div');
  modal.id = 'govProspectModal';
  modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.65);z-index:9999;display:flex;align-items:center;justify-content:center;padding:24px';
  modal.onclick = (e) => { if (e.target === modal) modal.remove(); };
  const top = rows.slice(0, 100);
  const tableRows = top.map((r, i) => `
    <tr style="border-bottom:1px solid var(--border)">
      <td style="padding:8px 10px;color:var(--text3);font-variant-numeric:tabular-nums">${i + 1}</td>
      <td style="padding:8px 10px;font-weight:600">${esc(r.name || '(unnamed)')}</td>
      <td style="padding:8px 10px;text-align:right;font-variant-numeric:tabular-nums;color:#6c8cff;font-weight:700">${r.prop_count || 0}</td>
      <td style="padding:8px 10px;color:var(--text2)">${esc(r.state || '—')}</td>
      <td style="padding:8px 10px;color:var(--text3);font-size:11px">${esc(r.entity_type || '—')}</td>
    </tr>`).join('');
  modal.innerHTML = `
    <div style="background:var(--s1);border:1px solid var(--border);border-radius:14px;max-width:900px;width:100%;max-height:85vh;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 24px 80px rgba(0,0,0,0.5)">
      <div style="padding:18px 24px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;background:var(--s2)">
        <div>
          <div style="font-size:18px;font-weight:800;color:var(--text1)">Unprospected Owners — Top BD Targets</div>
          <div style="font-size:12px;color:var(--text2);margin-top:4px">Owners with property holdings but no SF account link. Ordered by property count.</div>
        </div>
        <button onclick="document.getElementById('govProspectModal').remove()" style="background:transparent;border:1px solid var(--border);color:var(--text1);padding:8px 14px;border-radius:8px;cursor:pointer;font-size:13px">Close</button>
      </div>
      <div style="overflow-y:auto;flex:1">
        <table style="width:100%;border-collapse:collapse;font-size:13px">
          <thead style="position:sticky;top:0;background:var(--s2);z-index:1">
            <tr style="border-bottom:2px solid var(--border)">
              <th style="padding:10px;text-align:left;font-size:10px;text-transform:uppercase;color:var(--text3);letter-spacing:0.6px">#</th>
              <th style="padding:10px;text-align:left;font-size:10px;text-transform:uppercase;color:var(--text3);letter-spacing:0.6px">Owner</th>
              <th style="padding:10px;text-align:right;font-size:10px;text-transform:uppercase;color:var(--text3);letter-spacing:0.6px">Properties</th>
              <th style="padding:10px;text-align:left;font-size:10px;text-transform:uppercase;color:var(--text3);letter-spacing:0.6px">State</th>
              <th style="padding:10px;text-align:left;font-size:10px;text-transform:uppercase;color:var(--text3);letter-spacing:0.6px">Type</th>
            </tr>
          </thead>
          <tbody>${tableRows}</tbody>
        </table>
      </div>
      <div style="padding:12px 24px;border-top:1px solid var(--border);font-size:11px;color:var(--text3);background:var(--s2)">Showing top ${top.length} of ${trueTotal} unprospected owners${rows.length < trueTotal ? ' (' + rows.length + ' fetched)' : ''}. To add an owner to your SF prospecting list, look them up in Salesforce and link the account ID via the owner detail panel.</div>
    </div>`;
  document.body.appendChild(modal);
};

window.govRenderPipelineTable = function() {
  const container = document.getElementById('govPipelineTableContainer');
  if (!container || !govData || !govData.leads) return;
  const seenIds = new Set();
  const dedupedLeads = govData.leads.filter(l => {
    const key = l.lead_id || (l.address + '|' + l.city + '|' + l.tenant_agency);
    if (seenIds.has(key)) return false;
    seenIds.add(key);
    return true;
  });
  container.innerHTML = buildGovPipelineTable(dedupedLeads);
};

// Shared NM/Northmarq/Briggs-team detector. Mirrors the logic
// renderGovNorthmarqMetrics uses for comps so market-share counts stay
// consistent across dashboard sections. Returns true when a listing was
// worked by Northmarq / the Briggs team based on broker/firm strings or
// the is_northmarq flag set by enrichment jobs.
function _govIsNorthmarqListing(r) {
  if (!r) return false;
  if (r.is_northmarq) return true;
  const haystack = (
    (r.listing_broker || '') + ' ' +
    (r.listing_firm   || '') + ' ' +
    (r.broker_phone   || '') + ' ' +
    (r.broker_email   || '') + ' ' +
    (r.seller_name    || '')
  ).toLowerCase();
  return /northmarq|north\s*marq|nm\s+capital|briggs|hellwig|corriston|sjc[;:]|sbriggs/i.test(haystack);
}

// Filter state for the listings tab. Toggles between:
//   'all'  — every active listing (prior default)
//   'mine' — only listings where the NM/Briggs team has a role
// Persisted in-memory per session.
let govListingOwnership = 'all';
window.setGovListingOwnership = function(view) {
  govListingOwnership = view;
  renderGovTab();
};

// ── Gov Data-Health tile inner-renderers (synchronous, cache-fed) ────────────
// Each reads a value loaded once in the main gov Promise.all so a re-render
// always paints the real number instead of stranding the tile on "loading…".

function _govOwnershipCoverageCards() {
  const cov = window._govOwnershipCoverage;
  const unpros = window._govUnprospectedTotal;
  const loaded = window._govOwnershipCoverageLoadedFlag === true;
  const _c = { blue: '#6c8cff', green: '#34d399', red: '#f87171' };
  const pct = (v) => (v == null ? '—' : Math.round(Number(v)) + '%');
  const cardHTML = (title, val, sub, color, onclick, cursor) =>
    `<div class="gov-info-card"${onclick ? ' onclick="' + onclick + '" style="cursor:pointer" title="Click to see top unprospected owners by property count"' : ''}>
       <div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:6px">${title}</div>
       <div style="font-size:24px;font-weight:800;color:${color};margin-bottom:4px">${val}</div>
       <div style="font-size:11px;color:var(--text2)">${sub}</div>
     </div>`;
  if (!loaded) {
    return '<div class="gov-grid gov-grid-3">'
      + cardHTML('Ownership Depth', '…', 'loading', _c.blue)
      + cardHTML('SF Prospecting', '…', 'loading', _c.green)
      + cardHTML('Unprospected Owners', '…', 'loading', _c.red)
      + '</div>';
  }
  if (!cov) {
    return '<div class="gov-info-card" style="padding:16px;color:var(--text3);font-size:12px">Ownership coverage unavailable</div>';
  }
  const sfPct = (cov.pct_unified_owner_has_salesforce != null ? cov.pct_unified_owner_has_salesforce : cov.pct_true_owner_has_salesforce);
  const unpTile = (unpros != null)
    ? cardHTML('Unprospected Owners', fmtN(unpros), 'owners with property, no SF link — click to view BD targets', _c.red, '_govShowProspectTargets()')
    : cardHTML('Unprospected Owners', '—', 'unavailable', 'var(--text3)');
  return '<div class="gov-grid gov-grid-3">'
    + cardHTML('Ownership Depth', pct(cov.pct_property_has_true_owner),
        'of ' + fmtN(cov.properties) + ' properties resolved to a true owner · ' + pct(cov.pct_property_has_recorded_owner) + ' recorded', _c.blue)
    + cardHTML('SF Prospecting', pct(sfPct), 'of owners linked to Salesforce', _c.green)
    + unpTile
    + '</div>';
}

function _govListingConfirmTiles() {
  const rows = window._govLcConfirmRows;
  const loaded = Array.isArray(rows);
  const matchReady = loaded ? rows.filter(r => r.confirmation_state === 'sale_match_promote') : [];
  const aged = loaded ? rows.filter(r => r.confirmation_state === 'aged_needs_research') : [];
  const v = (n) => loaded ? fmtN(n) : '…';
  let h = '<div class="gov-grid gov-grid-3">';
  h += govCard({ title: 'Need Confirmation', value: v(loaded ? rows.length : 0), sub: 'unverified_assumed_off', color: 'orange', id: 'govLcNeed', subId: 'govLcNeedSub' });
  h += govCard({ title: 'Sale Match Ready', value: v(matchReady.length), sub: 'deed match — confirm sold', color: 'green', id: 'govLcMatch', subId: 'govLcMatchSub' });
  h += govCard({ title: 'Aged > 90d', value: v(aged.length), sub: 'no deed match, aged', color: 'red', id: 'govLcAged', subId: 'govLcAgedSub' });
  return h + '</div>';
}

function _govLlcTiles() {
  const loaded = window._govLlcHealthLoaded;
  const pending = loaded ? window._govLlcPending : null;
  const done = loaded ? window._govLlcDone : null;
  let h = '<div class="gov-grid gov-grid-3">';
  h += govCard({ title: 'Queued Owners', value: (pending == null ? '…' : fmtN(pending)), sub: 'awaiting research', color: 'purple', id: 'govLlcTotal', subId: 'govLlcTotalSub' });
  h += govCard({ title: 'Resolved', value: (done == null ? '…' : fmtN(done)), sub: 'resolved to date', color: 'blue', id: 'govLlcShown', subId: 'govLlcShownSub' });
  h += govCard({ title: 'Resolve', value: 'manual', sub: 'SOS lookup + mark done', color: 'cyan', tab: 'research' });
  return h + '</div>';
}

// ── Gov: Listings Needing Confirmation panel (mirror of dia) ──
function renderGovListingConfirm() {
  const rows = window._govLcConfirmRows || [];
  const matchReady = rows.filter(r => r.confirmation_state === 'sale_match_promote');
  const aged = rows.filter(r => r.confirmation_state === 'aged_needs_research');
  const setTxt = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  setTxt('govLcNeed', fmtN(rows.length)); setTxt('govLcNeedSub', 'unverified_assumed_off');
  setTxt('govLcMatch', fmtN(matchReady.length)); setTxt('govLcMatchSub', 'deed match — confirm sold');
  setTxt('govLcAged', fmtN(aged.length)); setTxt('govLcAgedSub', 'no deed match, aged');
  const show = matchReady.concat(aged).concat(rows.filter(r => r.confirmation_state === 'awaiting_sweep')).slice(0, 25);
  const wrap = document.getElementById('govLcConfirmList');
  if (!wrap) return;
  if (!show.length) { wrap.innerHTML = '<div style="font-size:12px;color:var(--text3);padding:8px">Nothing awaiting confirmation 🎉</div>'; return; }
  let t = '<table style="width:100%;border-collapse:collapse;font-size:12px"><thead><tr style="text-align:left;color:var(--text3)">'
    + '<th style="padding:4px 8px">Property</th><th style="padding:4px 8px">Off-Mkt</th>'
    + '<th style="padding:4px 8px">Sale Match</th><th style="padding:4px 8px">Actions</th></tr></thead><tbody>';
  show.forEach(r => {
    const addr = esc([r.address, r.city, r.state].filter(Boolean).join(', ') || ('#' + r.property_id));
    const url = r.listing_url ? '<a href="' + esc(r.listing_url) + '" target="_blank" rel="noopener">' + esc(r.tenant_operator || 'listing') + '</a>' : esc(r.tenant_operator || '');
    const match = r.candidate_sale_id
      ? '$' + fmtN(Math.round((Number(r.candidate_sold_price) || 0) / 1e6 * 10) / 10) + 'M · ' + esc(r.candidate_sale_date || '')
      : '<span style="color:var(--text3)">none</span>';
    const lid = JSON.stringify(r.listing_id);
    const sd = r.candidate_sale_date ? JSON.stringify(r.candidate_sale_date) : 'null';
    let actions = '<button onclick=\'govResolveListing(' + lid + ',"confirm_sold",' + sd + ')\' style="font-size:11px;padding:3px 8px;margin-right:4px;border:1px solid ' + (r.candidate_sale_id ? 'var(--green,#34d399);background:rgba(52,211,153,.12);color:var(--green,#34d399)' : 'var(--border);background:var(--s2);color:var(--text)') + ';border-radius:4px;cursor:pointer">Confirm Sold</button>';
    actions += '<button onclick=\'govResolveListing(' + lid + ',"mark_withdrawn",null)\' style="font-size:11px;padding:3px 8px;margin-right:4px;border:1px solid var(--border);background:var(--s2);color:var(--text);border-radius:4px;cursor:pointer">Withdrawn</button>';
    actions += '<button onclick=\'govResolveListing(' + lid + ',"still_active",null)\' style="font-size:11px;padding:3px 8px;border:1px solid var(--border);background:var(--s2);color:var(--text);border-radius:4px;cursor:pointer">Still Active</button>';
    t += '<tr style="border-top:1px solid var(--border)" id="govLcRow-' + esc(String(r.listing_id)) + '">'
      + '<td style="padding:4px 8px">' + addr + (r.tenant_operator ? '<br><span style="color:var(--text3);font-size:11px">' + url + '</span>' : '') + '</td>'
      + '<td style="padding:4px 8px;color:var(--text3)">' + esc(r.off_market_date || '') + '<br><span style="font-size:11px">' + esc(r.confirmation_state) + '</span></td>'
      + '<td style="padding:4px 8px">' + match + '</td>'
      + '<td style="padding:4px 8px">' + actions + '</td></tr>';
  });
  t += '</tbody></table>';
  wrap.innerHTML = t;
}

async function govResolveListing(listingId, action, saleDate) {
  const labels = { confirm_sold: 'Confirm as SOLD', mark_withdrawn: 'Mark WITHDRAWN', still_active: 'Mark STILL ACTIVE' };
  if (!confirm(labels[action] + ' for this listing?')) return;
  const rowEl = document.getElementById('govLcRow-' + listingId);
  if (rowEl) rowEl.style.opacity = '0.5';
  try {
    const resp = await fetch('/api/resolve-listing-confirmation', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain: 'gov', listing_id: listingId, action, sale_date: saleDate }),
    });
    if (!resp.ok) { const e = await resp.text(); throw new Error('HTTP ' + resp.status + ' ' + e); }
    window._govLcConfirmRows = (window._govLcConfirmRows || []).filter(r => String(r.listing_id) !== String(listingId));
    renderGovListingConfirm();
  } catch (err) {
    console.error('gov resolve listing failed:', err);
    if (rowEl) rowEl.style.opacity = '1';
    alert('Could not resolve listing: ' + err.message);
  }
}

// ── Gov: LLC Research Queue panel (mirror of dia) ──
function renderGovLlcQueue() {
  const items = window._govLlcQueueItems || [];
  const setTxt = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  // Canonical counts from v_llc_research_queue_health; '—' until it loads (never a spinner).
  const pending = window._govLlcHealthLoaded ? window._govLlcPending : null;
  const done = window._govLlcHealthLoaded ? window._govLlcDone : null;
  setTxt('govLlcTotal', pending == null ? '—' : fmtN(pending)); setTxt('govLlcTotalSub', 'awaiting research');
  setTxt('govLlcShown', done == null ? '—' : fmtN(done)); setTxt('govLlcShownSub', 'resolved to date');
  const wrap = document.getElementById('govLlcQueueList');
  if (!wrap) return;
  if (!items.length) { wrap.innerHTML = '<div style="font-size:12px;color:var(--text3);padding:8px">' + (window._govLlcHealthLoaded && !pending ? 'No owners awaiting research 🎉' : 'No owner list to show') + '</div>'; return; }
  let t = '<table style="width:100%;border-collapse:collapse;font-size:12px"><thead><tr style="text-align:left;color:var(--text3)">'
    + '<th style="padding:4px 8px">Owner</th><th style="padding:4px 8px">Property</th>'
    + '<th style="padding:4px 8px">State</th><th style="padding:4px 8px">Actions</th></tr></thead><tbody>';
  items.forEach(it => {
    const nm = esc(it.search_name || '');
    const st = esc(it.guessed_state || it.property_state || '');
    const prop = esc([it.property_address, it.property_city, it.property_state].filter(Boolean).join(', ') || ('#' + (it.property_id || '')));
    const sosUrl = 'https://www.google.com/search?q=' + encodeURIComponent((st ? st + ' ' : '') + 'secretary of state business search ' + (it.search_name || ''));
    const qid = JSON.stringify(it.queue_id);
    let actions = '<a href="' + sosUrl + '" target="_blank" rel="noopener" style="font-size:11px;padding:3px 8px;margin-right:4px;border:1px solid var(--border);background:var(--s2);color:var(--text);border-radius:4px;text-decoration:none">SOS Lookup</a>';
    actions += '<button onclick=\'govResolveLlc(' + qid + ',"completed")\' style="font-size:11px;padding:3px 8px;margin-right:4px;border:1px solid var(--green,#34d399);background:rgba(52,211,153,.12);color:var(--green,#34d399);border-radius:4px;cursor:pointer">Completed</button>';
    actions += '<button onclick=\'govResolveLlc(' + qid + ',"no_match")\' style="font-size:11px;padding:3px 8px;border:1px solid var(--border);background:var(--s2);color:var(--text);border-radius:4px;cursor:pointer">No Match</button>';
    t += '<tr style="border-top:1px solid var(--border)" id="govLlcRow-' + esc(String(it.queue_id)) + '">'
      + '<td style="padding:4px 8px">' + nm + (it.tenant ? '<br><span style="color:var(--text3);font-size:11px">' + esc(it.tenant) + '</span>' : '') + '</td>'
      + '<td style="padding:4px 8px;color:var(--text3)">' + prop + '</td>'
      + '<td style="padding:4px 8px">' + st + '</td>'
      + '<td style="padding:4px 8px">' + actions + '</td></tr>';
  });
  t += '</tbody></table>';
  wrap.innerHTML = t;
}

async function govResolveLlc(queueId, status) {
  const label = status === 'completed' ? 'Mark this owner research COMPLETED' : 'Mark NO MATCH';
  let foundFilingId = null;
  if (status === 'completed') {
    foundFilingId = prompt(label + '.\nOptional: enter the SOS filing/entity number (or leave blank):', '');
    if (foundFilingId === null) return;
  } else if (!confirm(label + ' for this owner?')) { return; }
  const rowEl = document.getElementById('govLlcRow-' + queueId);
  if (rowEl) rowEl.style.opacity = '0.5';
  try {
    const body = { domain: 'government', queue_id: queueId, status };
    if (foundFilingId) body.found_filing_id = foundFilingId;
    const resp = await fetch('/api/resolve-llc-research', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    });
    if (!resp.ok) { const e = await resp.text(); throw new Error('HTTP ' + resp.status + ' ' + e); }
    window._govLlcQueueItems = (window._govLlcQueueItems || []).filter(it => String(it.queue_id) !== String(queueId));
    window._govLlcQueueTotal = Math.max(0, (window._govLlcQueueTotal || 1) - 1);
    renderGovLlcQueue();
  } catch (err) {
    console.error('gov resolve llc failed:', err);
    if (rowEl) rowEl.style.opacity = '1';
    alert('Could not resolve: ' + err.message);
  }
}

function renderGovListings() {
  // Active-listing filter is normalized case-insensitively — older rows use
  // 'Active' / 'active' / 'For Sale' interchangeably.
  // Canonical predicate (app.js) — single source of truth; see
  // SALES_AND_AVAILABLE_COMPS_DEFINITION_AUDIT_2026-05-29.md.
  // Canonical CURRENT on-market set — v_gov_on_market membership (the SAME
  // definition the Overview tile + CM available count use). Falls back to the
  // legacy status predicate only if the view load failed (onMarketIds null).
  const isActive = (l) => govData.onMarketIds ? govData.onMarketIds.has(l.listing_id) : lccIsListingActive(l);
  const activeRows  = govData.listings.filter(isActive);
  const activeCount = activeRows.length;
  const totalAsking = activeRows.reduce((sum, l) => sum + (l.asking_price || 0), 0);
  const underContract = govData.listings.filter(l =>
    (l.listing_status || '').toLowerCase() === 'under_contract'
  ).length;
  const myActiveRows = activeRows.filter(_govIsNorthmarqListing);
  const myCount = myActiveRows.length;

  // === Action guidance banner ===
  let html = '<div style="padding:10px 14px;background:rgba(52,211,153,0.08);border-radius:8px;border-left:3px solid #34d399;margin-bottom:16px;display:flex;align-items:center;gap:10px;">';
  html += '<div style="font-size:13px;color:var(--text);line-height:1.4"><strong>Active Listings</strong> — Monitor government-leased properties currently on market. Click any listing to view asking price, lease details, and market comps. Identify acquisition opportunities or competitive intelligence for your pipeline.</div>';
  html += '</div>';

  html += '<div class="gov-metrics">';
  html += metricHTML('Active Listings', fmtN(activeCount), 'Currently on market', 'blue');
  html += metricHTML('Total Asking', fmt(totalAsking), 'Combined value', 'green');
  html += metricHTML('All Listings', fmtN(govData.listings.length), 'All statuses', 'yellow');
  html += metricHTML('Under Contract', fmtN(underContract), 'Pending', 'purple');
  html += '</div>';

  // === Ownership filter toggle ===
  // Lets the broker flip between all active listings and just the ones
  // that are worked by Northmarq / the Briggs team. "Mine" uses the same
  // detector the market-share metric uses, so the counts reconcile.
  const selectedRows = govListingOwnership === 'mine' ? myActiveRows : activeRows;
  html += '<div style="display:flex;gap:8px;align-items:center;margin:14px 0 6px 0;flex-wrap:wrap">';
  html += `<button class="pill${govListingOwnership === 'all'  ? ' active' : ''}" onclick="setGovListingOwnership('all')">All (${fmtN(activeCount)})</button>`;
  html += `<button class="pill${govListingOwnership === 'mine' ? ' active' : ''}" onclick="setGovListingOwnership('mine')" title="Northmarq / Briggs team listings only">My Listings (${fmtN(myCount)})</button>`;
  html += '</div>';

  html += '<div class="table-section">';
  html += '<h3>' + (govListingOwnership === 'mine' ? 'My Listings' : 'Available Listings') + '</h3>';
  html += listingsTable(selectedRows.slice(0, 100));
  html += '</div>';

  return html;
}

// ══════════════════════════════════════════════════════════════════════════════
// PIPELINE OPS SECTION - PENDING UPDATES
// ══════════════════════════════════════════════════════════════════════════════

window.setGovResearchSection = function(section) {
  // Legacy — section toggle removed in R43 (unified pipeline tabs).
  // Kept as no-op so any stale onclick references don't throw.
  govResearchSection = section;
  renderGovTab();
};

window.setGovPendingFilter = function(category) {
  govPendingFilter = category;
  govPendingSubtypeFilter = 'all';
  govPendingUpdatesIdx = 0;
  renderGovTab();
};

window.setGovPendingSubtype = function(reason) {
  govPendingSubtypeFilter = reason;
  govPendingUpdatesIdx = 0;
  renderGovTab();
};

// ── Reason taxonomy ──────────────────────────────────────────────────────────
// Friendly labels and decision guidance for each pending-update reason. Anything
// not in this map falls through `govPendingFriendlyReason()` for a sensible
// default (snake_case → Title Case) so new reason codes don't break the UI.
const GOV_PENDING_REASON_TAXONOMY = {
  ownership_discrepancy: {
    label: 'Ownership Discrepancy',
    category: 'ownership',
    guidance: 'The recorded owner on file disagrees with a newer source. Approve when the proposed value is from a more authoritative record (deed/county); reject if the existing value was manually curated.'
  },
  low_confidence_match: {
    label: 'Low-Confidence Match',
    category: 'confidence',
    guidance: 'The matcher linked two records but is not certain. Verify the names/addresses align and approve, or reject to keep them separate.'
  },
  intake_attachment_review: {
    label: 'Attachment Review',
    category: 'intake',
    guidance: 'An intake email had an attachment that needs human triage (was it an OM, a tax bill, junk?). Approve to accept the system\'s classification; reject to discard.'
  },
  intake_unmatched_property: {
    label: 'Unmatched Intake Property',
    category: 'intake',
    kind: 'link_pick',
    guidance: 'An intake landed but we couldn\'t auto-link it to a property in inventory. The source_context.match_details.candidates array carries pre-ranked options for the link-pick UI; for now use Reject if out-of-scope, or Skip.'
  },
  unmatched_property: {
    label: 'Unmatched Property',
    category: 'intake',
    kind: 'link_pick',
    guidance: 'A lead references a property we either do not have in inventory yet, or a previously-linked match was unlinked by an audit (check Source Context for previously_linked_property_id). Pick the right property when the link-pick UI lands; for now use Reject if the lead is out of scope, or Skip.'
  },
  unmatched_contact: {
    label: 'Unmatched Contact',
    category: 'intake',
    kind: 'link_pick',
    guidance: 'A new contact appeared that doesn\'t match anyone in our directory. (No auto-create flow exists today — approving here only marks the queue row resolved without creating the contact. Use Reject for now or wait for the link-pick UI.)'
  },
  gsa_property_link_review: {
    label: 'GSA → Property Link Review',
    category: 'link_review',
    kind: 'link_pick',
    guidance: 'The auto-matcher linked this GSA lease to a property whose address and/or lease number disagree. Compare the two sides below and decide: same physical building (Confirm) or wrong match (Break).'
  },
  // sale_property_link_* — all variants describe linking a sales_transaction to
  // a property when the public inventory doesn't cleanly cover it.
  sale_property_link_ambiguous_city_match: {
    label: 'Sale → Property: Ambiguous City',
    category: 'sale_link',
    guidance: 'A sale matches multiple properties in the same city. Pick the right one, or reject if none of them is correct.'
  },
  sale_property_link_frpp_city_inventory_gap: {
    label: 'Sale → Property: FRPP Gap',
    category: 'sale_link',
    guidance: 'FRPP shows the city has government inventory but the specific address is missing. Approve to create the link to the closest match, or reject to wait for better data.'
  },
  sale_property_link_frpp_city_presence_multi_facility: {
    label: 'Sale → Property: Multi-Facility City',
    category: 'sale_link',
    guidance: 'FRPP shows multiple government facilities in this city. Confirm which one this sale belongs to before approving.'
  },
  sale_property_link_frpp_city_presence_single_facility: {
    label: 'Sale → Property: Single-Facility City',
    category: 'sale_link',
    guidance: 'FRPP shows exactly one government facility in this city — high-confidence link. Verify the address matches and approve.'
  },
  sale_property_link_gsa_address_bridge_candidate: {
    label: 'Sale → Property: GSA Bridge Candidate',
    category: 'sale_link',
    guidance: 'A GSA lease address looks like the bridge between this sale and a property. Approve if the address normalisation looks right.'
  },
  sale_property_link_multi_property_street_conflict: {
    label: 'Sale → Property: Street Conflict',
    category: 'sale_link',
    guidance: 'Multiple properties share this street — pick the correct property number, or reject if none match.'
  },
  sale_property_link_named_site_or_partial_address: {
    label: 'Sale → Property: Named Site',
    category: 'sale_link',
    guidance: 'The sale references a named site (e.g. "Oklahoma City VA Clinic") rather than a clean street address. Match by name + city, or reject if ambiguous.'
  },
  sale_property_link_no_public_inventory: {
    label: 'Sale → Property: No Public Inventory',
    category: 'sale_link',
    guidance: 'Public inventory doesn\'t cover this address. Approve to record the sale against a derived property record, or reject if the deal isn\'t government-leased.'
  },
  sale_property_link_no_public_inventory_portfolio: {
    label: 'Sale → Property: Portfolio (No Inventory)',
    category: 'sale_link',
    guidance: 'A portfolio sale where none of the addresses are in public inventory. Confirm this isn\'t a non-gov portfolio before approving.'
  },
  sale_property_link_no_public_inventory_route: {
    label: 'Sale → Property: Route Only',
    category: 'sale_link',
    guidance: 'Only a rural route / PO-box style address is available. Approve only if you can confirm the property and tenant.'
  },
  sale_property_link_portfolio_address_gap: {
    label: 'Sale → Property: Portfolio Address Gap',
    category: 'sale_link',
    guidance: 'A multi-property sale where some addresses match inventory and some don\'t. Approve the link for the matched address; the remaining gaps will surface as their own updates.'
  },
  sale_property_link_unknown_lease_number: {
    label: 'Sale → Property: Unknown Lease #',
    category: 'sale_link',
    guidance: 'The sale references a lease number we don\'t have on file. Approve to record the sale anyway; reject if the lease number looks invalid.'
  },
  sale_property_link_unrepresented_street_no_public_inventory: {
    label: 'Sale → Property: Unknown Street (No Inventory)',
    category: 'sale_link',
    guidance: 'A street we\'ve never seen, with no public inventory backing. Approve only if you can independently verify the property.'
  },
  sale_property_link_unrepresented_street_public_inventory: {
    label: 'Sale → Property: Unknown Street (Has Inventory)',
    category: 'sale_link',
    guidance: 'A street we\'ve never seen, but the city has government inventory. Verify against FRPP/GSA and approve the link.'
  }
};

const GOV_PENDING_CATEGORIES = [
  { id: 'sale_link',    label: 'Property Linking', icon: '🔗', desc: 'Linking sales transactions to properties' },
  { id: 'ownership',    label: 'Ownership',        icon: '🏛',  desc: 'Owner-of-record disagreements' },
  { id: 'confidence',   label: 'Match Confidence', icon: '⚖',  desc: 'Low-confidence record matches awaiting confirmation' },
  { id: 'link_review',  label: 'Link Review',      icon: '🔍', desc: 'Auto-flagged record↔property links that need human confirmation' },
  { id: 'intake',       label: 'Intake Review',    icon: '📥', desc: 'Inbound emails / unmatched properties / contacts' },
  { id: 'other',        label: 'Other',            icon: '•',  desc: 'Uncategorised reason codes' }
];

// Reasons emitted by writers that don't match a taxonomy key 1:1.
// Map them to the canonical entry so we don't have to keep two strings in sync.
const GOV_PENDING_REASON_ALIASES = {
  // Writer emits the *_gap suffix; taxonomy entry omits it.
  'sale_property_link_unrepresented_street_public_inventory_gap':
    'sale_property_link_unrepresented_street_public_inventory'
};

function govPendingTaxonomy(reason) {
  const canonical = (reason && GOV_PENDING_REASON_ALIASES[reason]) || reason;
  const entry = canonical && GOV_PENDING_REASON_TAXONOMY[canonical];
  if (entry) {
    // Backfill kind for entries that don't specify one. sale_link entries
    // route through their own resolver; everything else is a field_change
    // (old_value -> new_value diff). Explicit `kind` on an entry wins.
    const defaultKind = entry.category === 'sale_link' ? 'sale_link' : 'field_change';
    return Object.assign({ kind: defaultKind }, entry);
  }
  // Fallback for unknown reasons: best-effort label, "other" category.
  const r = String(canonical || 'other');
  const label = r.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  return { label, category: 'other', kind: 'field_change', guidance: 'No guidance defined for this reason yet — review the source context and use your judgment.' };
}

function govPendingRelativeAge(iso) {
  if (!iso) return '';
  const t = new Date(iso).getTime();
  if (!t) return '';
  const sec = Math.max(1, Math.round((Date.now() - t) / 1000));
  if (sec < 60) return sec + 's ago';
  const min = Math.round(sec / 60); if (min < 60) return min + 'm ago';
  const hr  = Math.round(min / 60); if (hr < 24)  return hr  + 'h ago';
  const day = Math.round(hr / 24);  if (day < 30) return day + 'd ago';
  const mo  = Math.round(day / 30); return mo + 'mo ago';
}

function govPendingConfidenceMeta(c) {
  const conf = Number(c) || 0;
  if (conf >= 0.8) return { color: '#22c55e', label: 'High',   pct: Math.round(conf * 100) };
  if (conf >= 0.5) return { color: '#f59e0b', label: 'Medium', pct: Math.round(conf * 100) };
  return                   { color: '#ef4444', label: 'Low',    pct: Math.round(conf * 100) };
}

function govPendingSourceSummary(ctx) {
  if (!ctx || typeof ctx !== 'object') return [];
  const pick = (keys) => {
    for (const k of keys) {
      if (ctx[k] != null && ctx[k] !== '') return { key: k, value: ctx[k] };
    }
    return null;
  };
  const out = [];
  const entries = [
    ['Subject',         ['subject']],
    ['Address',         ['address', 'property_address', 'street_address']],
    ['Tenant',          ['tenant', 'tenant_name', 'occupant']],
    ['Asking / Price',  ['asking_price', 'sale_price', 'price']],
    ['Lease #',         ['lease_number', 'gsa_lease_number']],
    ['Prev. property',  ['previously_linked_property_id']],
    ['Prev. address',   ['previously_linked_address']],
    ['Prev. lease #',   ['previously_linked_lease']],
    ['Unlink reason',   ['unlinked_reason']],
    ['Provenance',      ['discrepancy_source']],
    ['Summary',         ['summary', 'description']],
    ['Source',          ['source', 'data_source', 'origin']]
  ];
  for (const [label, keys] of entries) {
    const hit = pick(keys);
    if (hit) out.push({ label, value: hit.value });
  }
  return out;
}

// ── GSA Property Link Review ──────────────────────────────────────────────────
// The auto-matcher linked a gsa_leases row to a properties row whose street
// number AND lease number both disagree. The pending row carries a pre-baked
// comparison in source_context (gsa_* / linked_* keys); we render it as a
// side-by-side table so the reviewer can see what's being compared, and offer
// two write actions:
//   Approve link  → gsa_leases.match_status = 'human_confirmed'  (keep property_id)
//   Reject link   → gsa_leases.match_status = 'human_rejected', property_id = NULL
// Both also resolve the pending row.

function govGsaLinkReviewFields(ctx) {
  if (!ctx || typeof ctx !== 'object') return null;
  const has = ['gsa_address','linked_address','gsa_lease_number','linked_lease_number']
    .some(k => ctx[k] != null && ctx[k] !== '');
  if (!has) return null;
  const norm = (v) => v == null ? '' : String(v).trim();
  const ci = (a, b) => norm(a).toLowerCase() === norm(b).toLowerCase();
  const cmp = (a, b) => {
    const A = norm(a), B = norm(b);
    if (!A && !B) return 'both-empty';
    if (A && B && ci(A, B)) return 'match';
    return 'differ';
  };
  return {
    flagReason:     ctx.flag_reason || '',
    reviewGuidance: ctx.review_guidance || '',
    rows: [
      { label: 'Address', gsa: ctx.gsa_address, linked: ctx.linked_address,
        state: cmp(ctx.gsa_address, ctx.linked_address) },
      { label: 'City',    gsa: ctx.gsa_city,    linked: ctx.linked_city,
        state: cmp(ctx.gsa_city,    ctx.linked_city) },
      { label: 'State',   gsa: ctx.gsa_state,   linked: ctx.linked_state,
        state: cmp(ctx.gsa_state,   ctx.linked_state) },
      { label: 'Lease #', gsa: ctx.gsa_lease_number, linked: ctx.linked_lease_number,
        state: cmp(ctx.gsa_lease_number, ctx.linked_lease_number), code: true }
    ],
    linkedPropertyId: ctx.linked_property_id != null ? String(ctx.linked_property_id) : ''
  };
}

function renderGovGsaLinkReview(selected) {
  const data = govGsaLinkReviewFields(selected.source_context);
  if (!data) {
    // Fallback: source_context didn't carry the comparison keys.
    return `<div class="pu-link-pick-placeholder">
      <div class="pu-lpp-title">GSA → Property Link Review</div>
      <div class="pu-lpp-body">
        This row is missing the gsa_* / linked_* comparison keys in source_context.
        Inspect the Raw JSON below, then use <kbd>R</kbd> to reject the link or
        <kbd>S</kbd> to skip.
      </div>
    </div>`;
  }
  let html = '<div class="pu-glr">';

  // Banner — what the matcher flagged
  if (data.flagReason) {
    html += `<div class="pu-glr-banner">
      <span class="pu-glr-banner-label">Flagged:</span>
      <code class="pu-glr-banner-flag">${esc(data.flagReason)}</code>
      ${data.reviewGuidance ? '<details class="pu-glr-why"><summary>Why</summary><div class="pu-glr-why-body">' + esc(data.reviewGuidance) + '</div></details>' : ''}
    </div>`;
  }

  // The question
  html += `<div class="pu-glr-question">Are these the same physical building?</div>`;

  // Two-column comparison
  html += '<div class="pu-glr-grid">';
  html += `<div class="pu-glr-col-head pu-glr-col-gsa">GSA inventory <span class="pu-glr-col-sub">(authoritative)</span></div>`;
  html += `<div class="pu-glr-col-head pu-glr-col-linked">Currently linked property${data.linkedPropertyId ? ' <span class="pu-glr-col-sub">#' + esc(data.linkedPropertyId) + '</span>' : ''}</div>`;
  data.rows.forEach(row => {
    const cls = 'pu-glr-row pu-glr-row-' + row.state;
    const fmt = (v) => {
      const s = v == null || v === '' ? '—' : String(v);
      return row.code ? '<code>' + esc(s) + '</code>' : esc(s);
    };
    html += `<div class="pu-glr-label ${cls}">${esc(row.label)}</div>`;
    html += `<div class="pu-glr-val pu-glr-val-gsa ${cls}">${fmt(row.gsa)}</div>`;
    html += `<div class="pu-glr-val pu-glr-val-linked ${cls}">
      ${fmt(row.linked)}
      ${row.state === 'differ' ? '<span class="pu-glr-diff-flag" title="Disagrees with GSA">≠</span>' : ''}
      ${row.state === 'match'  ? '<span class="pu-glr-same-flag" title="Matches GSA">=</span>' : ''}
    </div>`;
  });
  html += '</div>';

  // Pivot — copy the linked property_id so the reviewer can paste it into the
  // inventory search and see other leases/sales at that record before deciding.
  if (data.linkedPropertyId) {
    const pidEsc = esc(data.linkedPropertyId).replace(/'/g, "\\'");
    html += `<div class="pu-glr-pivot">
      <button class="pu-glr-pivot-btn" onclick="navigator.clipboard.writeText('${pidEsc}'); showToast('property_id ${pidEsc} copied — paste into Inventory search', 'success')" title="Copy property_id to paste into Inventory search">
        Copy property_id #${esc(data.linkedPropertyId)}
      </button>
      <span class="pu-glr-pivot-help">paste into Inventory search to see other leases / sales at this record before deciding</span>
    </div>`;
  }

  html += '</div>'; // pu-glr
  return html;
}

window.govResolveGsaLink = async function(pendingId, decision) {
  const item = (govPendingUpdates || []).find(u => u.id === pendingId);
  if (!item) {
    showToast('Pending row not found in cache — refresh and retry', 'error');
    return;
  }
  if (!item.record_id) {
    showToast('Missing gsa_lease_id (record_id) on this row — cannot patch', 'error');
    return;
  }
  const ctx = item.source_context || {};
  const linkedPid = ctx.linked_property_id != null ? String(ctx.linked_property_id) : '';

  let confirmMsg, toastSuccess;
  if (decision === 'approved') {
    confirmMsg = 'Confirm this GSA lease and property #' + (linkedPid || '?') +
      ' describe the same building? gsa_leases.match_status will become human_confirmed and the pending row will resolve as approved.';
    toastSuccess = 'Link confirmed — gsa_leases.match_status = human_confirmed';
  } else if (decision === 'rejected') {
    confirmMsg = 'Reject the link to property #' + (linkedPid || '?') +
      '? gsa_leases.property_id will be cleared and match_status set to human_rejected. The matcher will retry on the next pass.';
    toastSuccess = 'Link cleared — gsa_leases.match_status = human_rejected';
  } else {
    return;
  }

  const btn = document.activeElement && document.activeElement.tagName === 'BUTTON' ? document.activeElement : null;
  const origText = btn?.textContent;
  if (btn) { btn.disabled = true; btn.textContent = decision === 'approved' ? 'Confirming…' : 'Rejecting…'; }

  try {
    if (!(await lccConfirm(confirmMsg, decision === 'approved' ? 'Confirm link' : 'Reject link'))) {
      if (btn) { btn.disabled = false; btn.textContent = origText; }
      return;
    }
    const notes = document.getElementById('pu-notes')?.value || null;
    // Single atomic RPC — the dashboard role doesn't have direct UPDATE
    // rights on gsa_leases (PATCH returns 403); gov_resolve_gsa_link_review
    // is security definer and updates gsa_leases + pending_updates inside
    // one transaction.
    await govRpc('gov_resolve_gsa_link_review', {
      p_pending_id: item.id,
      p_decision: decision,
      p_notes: notes,
      p_resolved_by: 'dashboard:gsa_link_review'
    });
    govPendingUpdates = govPendingUpdates.filter(r => r.id !== item.id);
    govPendingUpdatesIdx = Math.min(govPendingUpdatesIdx, Math.max(0, govPendingUpdates.length - 1));
    showToast(toastSuccess, 'success');
    renderGovTab();
  } catch (err) {
    console.error('govResolveGsaLink failed:', err);
    const verb = decision === 'approved' ? 'confirm' : 'reject';
    const msg = (err && err.message) || String(err);
    // Surface the most useful hint when the RPC isn't yet deployed.
    const friendly = /could not find the function|function .* does not exist|404/i.test(msg)
      ? 'RPC gov_resolve_gsa_link_review not deployed yet — apply sql/20260507_gov_rpc_gsa_link_review_resolver.sql on the gov DB'
      : msg;
    showToast('Failed to ' + verb + ' link: ' + friendly, 'error');
    if (btn) { btn.disabled = false; btn.textContent = origText; }
  }
};

window.bulkApproveGovPending = async function() {
  const view = window._govPendingCurrentView || [];
  // Only field_change rows are bulk-approvable. sale_link and link_pick
  // rows have no meaningful old/new diff — approve on them is either a
  // resolver-required action (sale_link) or a silent no-op that would
  // cement a flagged-as-suspect link / leave a lead un-relinked
  // (link_pick). Exclude both.
  const eligible = view.filter(r => {
    if (Number(r.confidence || 0) < 0.8) return false;
    const tax = govPendingTaxonomy(r.reason);
    return tax.kind === 'field_change';
  });
  if (eligible.length === 0) {
    showToast('No items in this view meet the high-confidence (≥80%) bar', 'info');
    return;
  }
  const ok = await lccConfirm('Bulk-approve ' + eligible.length + ' high-confidence update' + (eligible.length === 1 ? '' : 's') + ' in this view? Items below 80% confidence will be skipped.', 'Approve all');
  if (!ok) return;
  const approved = new Set();
  let failed = 0;
  for (const item of eligible) {
    try {
      await govPatch('pending_updates', 'id=eq.' + item.id, {
        status: 'approved',
        resolved_by: 'dashboard_bulk',
        resolved_at: new Date().toISOString()
      });
      approved.add(item.id);
    } catch (_) { failed++; }
  }
  govPendingUpdates = govPendingUpdates.filter(r => !approved.has(r.id));
  govPendingUpdatesIdx = 0;
  showToast('Bulk approved ' + approved.size + (failed ? ' (' + failed + ' failed)' : ''), failed ? 'warning' : 'success');
  renderGovTab();
};

function ensureGovPendingKeybinds() {
  if (govPendingKeysBound) return;
  govPendingKeysBound = true;
  document.addEventListener('keydown', (e) => {
    // Only handle when on the Pending Updates view and not typing in a field.
    if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'government') return;
    if (typeof researchMode !== 'undefined' && researchMode !== 'pending_updates') return;
    const tag = (e.target && e.target.tagName) || '';
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || (e.target && e.target.isContentEditable)) return;
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    const view = window._govPendingCurrentView || [];
    if (view.length === 0) return;
    const sel = view[govPendingUpdatesIdx] || view[0];
    const k = e.key.toLowerCase();
    if (k === 'j' || e.key === 'ArrowDown') {
      govPendingUpdatesIdx = Math.min(view.length - 1, govPendingUpdatesIdx + 1);
      e.preventDefault(); renderGovTab();
    } else if (k === 'k' || e.key === 'ArrowUp') {
      govPendingUpdatesIdx = Math.max(0, govPendingUpdatesIdx - 1);
      e.preventDefault(); renderGovTab();
    } else if (k === 'a' && sel) {
      // Approve only writes through for true field_change rows and
      // gsa_property_link_review (where Approve = "confirm the auto-link").
      // sale_link needs the resolver; other link_pick reasons need the
      // (forthcoming) candidate picker.
      const tax = govPendingTaxonomy(sel.reason);
      if (sel.reason === 'gsa_property_link_review') {
        e.preventDefault();
        window.govResolveGsaLink(sel.id, 'approved');
        return;
      }
      if (tax.kind !== 'field_change') {
        showToast(
          tax.kind === 'sale_link'
            ? 'Use Link → on a candidate, or expand "Create new property"'
            : 'No proposed value yet — press R to reject, or S to skip',
          'info'
        );
        return;
      }
      e.preventDefault();
      window.resolveGovPendingUpdate(sel.id, 'approved');
    } else if (k === 'r' && sel) {
      e.preventDefault();
      if (sel.reason === 'gsa_property_link_review') {
        window.govResolveGsaLink(sel.id, 'rejected');
      } else {
        window.resolveGovPendingUpdate(sel.id, 'rejected');
      }
    } else if (k === 's') {
      govPendingUpdatesIdx = (govPendingUpdatesIdx + 1) % view.length;
      e.preventDefault(); renderGovTab();
    }
  });
}

// Drop pending rows that are obviously seed/test fixtures (e.g. an intake
// email whose subject starts with "Test" and has no old/new value to
// review). Matched at the strictest possible boundary so a real intake
// like "Test Pilot Air Base" can never be hidden.
function govIsLikelyTestRow(r) {
  if (!r || !r.source_context || typeof r.source_context !== 'object') return false;
  // Only filter empty-shell rows (no value to approve/reject anyway).
  if (r.old_value != null || r.new_value != null) return false;
  const subj = typeof r.source_context.subject === 'string' ? r.source_context.subject.trim() : '';
  if (!subj) return false;
  return /^(?:(?:re|fwd?):\s*)?test\b/i.test(subj);
}

let govPendingUpdatesRefreshedAt = null;
window.loadGovPendingUpdates = async function() {
  if (govPendingUpdatesLoading) return;
  govPendingUpdatesLoading = true;
  try {
    const result = await govQuery('pending_updates', '*', {
      filter: 'status=eq.pending',
      order: 'priority_score.desc'
    });
    govPendingUpdates = (result.data || []).filter(r => !govIsLikelyTestRow(r));
    govPendingUpdatesRefreshedAt = new Date();

    // Also fetch recently auto-resolved items so the trends strip can
    // show the system's silent work (orphan sweeps, etc).
    try {
      const cutoff = new Date(Date.now() - 14 * 86400000).toISOString();
      const auto = await govQuery('pending_updates',
        'id,reason,resolved_by,resolved_at,table_name', {
          filter: 'status=eq.auto_resolved&resolved_at=gte.' + cutoff,
          order: 'resolved_at.desc',
          limit: 500
        });
      govPendingAutoResolved = auto.data || [];
    } catch (_) { govPendingAutoResolved = []; }
  } catch(e) {
    console.error('loadGovPendingUpdates exception:', e);
    govPendingUpdates = [];
  }
  govPendingUpdatesLoading = false;
  if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'government') return;
  renderGovTab();
};

// Helper for PATCH operations via /api/gov-query proxy
async function govPatch(table, filterStr, data) {
  const url = new URL('/api/gov-query', window.location.origin);
  url.searchParams.set('table', table);
  url.searchParams.set('filter', filterStr);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const resp = await fetch(url.toString(), {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
      signal: controller.signal
    });
    clearTimeout(timeout);
    if (!resp.ok) throw new Error('PATCH ' + table + ' failed: HTTP ' + resp.status);
    return true;
  } catch (err) {
    clearTimeout(timeout);
    if (err.name === 'AbortError') throw new Error('PATCH ' + table + ' timed out (15s) — please retry');
    throw err;
  }
}

window.resolveGovPendingUpdate = async function(id, resolution) {
  // Find the clicked button and manage its state
  const clickedBtn = document.activeElement && document.activeElement.tagName === 'BUTTON' ? document.activeElement : null;
  const origBtnText = clickedBtn?.textContent;
  const actionTexts = {
    'approved': 'Approving…',
    'rejected': 'Rejecting…',
    'expired': 'Expiring…'
  };

  if (clickedBtn) {
    clickedBtn.disabled = true;
    clickedBtn.textContent = actionTexts[resolution] || 'Processing…';
  }

  try {
    if (resolution === 'rejected' && !(await lccConfirm('Reject this pending update? The proposed change will be discarded.', 'Reject'))) {
      if (clickedBtn) {
        clickedBtn.disabled = false;
        clickedBtn.textContent = origBtnText;
      }
      return;
    }
    if (resolution === 'expired' && !(await lccConfirm('Expire this update? It will no longer be actionable.', 'Expire'))) {
      if (clickedBtn) {
        clickedBtn.disabled = false;
        clickedBtn.textContent = origBtnText;
      }
      return;
    }

    const notes = document.getElementById('pu-notes')?.value || '';
    await govPatch('pending_updates', 'id=eq.' + id, {
      status: resolution,
      resolved_by: 'dashboard',
      resolved_at: new Date().toISOString(),
      resolution_notes: notes || null
    });
    govPendingUpdates = govPendingUpdates.filter(r => r.id !== id);
    govPendingUpdatesIdx = Math.min(govPendingUpdatesIdx, Math.max(0, govPendingUpdates.length - 1));
    const label = resolution === 'approved' ? 'Approved' : resolution === 'rejected' ? 'Rejected' : 'Expired';
    showToast('Update ' + label.toLowerCase(), 'success');
    renderGovTab();
  } catch(e) {
    console.error('resolveGovPendingUpdate error:', e);
    showToast('Failed to resolve update: ' + e.message, 'error');
  } finally {
    if (clickedBtn) {
      clickedBtn.disabled = false;
      clickedBtn.textContent = origBtnText;
    }
  }
};

// ── Sale-Link Resolver ──────────────────────────────────────────────────────
// Drives the Mode A (pick from candidates) / Mode C (create new property)
// flow for sale_property_link_* pending updates. Backed by the gov-side RPCs
// `gov_resolve_sale_link` and `gov_create_property_from_pending` (defined in
// government-lease/sql/20260429_gov_rpc_sale_link_resolver.sql).
//
// Cache shape (keyed by pending_id):
//   { loading, error, sale, candidates, candidatesQuery }
const govResolverCache = {};
const govResolverShowCreate = {};   // pending_id → bool (form expanded?)
const govResolverNewProp   = {};    // pending_id → form draft
const govResolverPortfolioSelected = {}; // pending_id → Set<property_id> (portfolio picker)
const govResolverPortfolioFilter   = {}; // pending_id → search string (portfolio picker)

const GOV_PORTFOLIO_REASONS = new Set([
  'sale_property_link_portfolio_address_gap',
  'sale_property_link_portfolio_high_confidence_candidate',
]);

async function govRpc(rpcName, args) {
  const url = new URL('/api/gov-query', window.location.origin);
  url.searchParams.set('table', 'rpc/' + rpcName);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20000);
  try {
    const resp = await fetch(url.toString(), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Prefer': 'return=representation' },
      body: JSON.stringify(args || {}),
      signal: controller.signal
    });
    clearTimeout(timeout);
    const text = await resp.text();
    let data; try { data = JSON.parse(text); } catch (_) { data = text; }
    if (!resp.ok) {
      const detail = (data && data.error) || (typeof data === 'string' ? data : ('HTTP ' + resp.status));
      throw new Error(detail);
    }
    return Array.isArray(data) ? data[0] : data;
  } catch (err) {
    clearTimeout(timeout);
    if (err.name === 'AbortError') throw new Error('RPC ' + rpcName + ' timed out');
    throw err;
  }
}

function govResolverContextOf(item) {
  const ctx = (item && item.source_context) || {};
  return {
    address:      ctx.address || ctx.property_address || ctx.street_address || '',
    city:         ctx.city || ctx.property_city || '',
    state:        ctx.state || ctx.property_state || '',
    leaseNumber:  ctx.lease_number || ctx.gsa_lease_number || '',
    agency:       ctx.agency || '',
    governmentType: ctx.government_type || ctx.gov_type || '',
    buyer:        ctx.buyer || ctx.buyer_name || '',
    seller:       ctx.seller || ctx.seller_name || '',
    rawCity:      ctx.address || ''   // sometimes "PORT CHARLOTTE" lands in address only
  };
}

window.loadGovSaleLinkContext = async function(pendingId) {
  const item = (govPendingUpdates || []).find(u => u.id === pendingId);
  if (!item) return;
  const cache = govResolverCache[pendingId] || {};
  if (cache.loading) return;
  govResolverCache[pendingId] = { ...cache, loading: true, error: null };
  renderGovTab();

  try {
    const ctx = govResolverContextOf(item);
    // 1) Fetch the sale row by record_id (sale_id)
    let sale = null;
    if (item.record_id) {
      const saleRes = await govQuery('sales_transactions',
        'sale_id,sale_date,sold_price,sold_cap_rate,buyer,seller,address,city,state,lease_number,property_id', {
          filter: 'sale_id=eq.' + item.record_id,
          limit: 1, count: false
        });
      sale = (saleRes.data && saleRes.data[0]) || null;
    }

    // 2) Build candidate query from any signal we have:
    //    a) lease_number exact
    //    b) city (+ state) ilike
    //    c) fall back to the sale's own city/state
    const filters = [];
    const lease = ctx.leaseNumber || (sale && sale.lease_number);
    const city  = ctx.city  || (sale && sale.city);
    const state = ctx.state || (sale && sale.state);

    let candidates = [];
    let candidatesQuery = '';
    if (lease) {
      const r = await govQuery('properties',
        'property_id,address,city,state,lease_number,agency,government_type,sf_leased,lease_expiration', {
          filter: 'lease_number=eq.' + encodeURIComponent(lease),
          limit: 25, count: false
        });
      candidates = r.data || [];
      candidatesQuery = 'lease_number=' + lease;
    }
    if (candidates.length === 0 && (city || state)) {
      const parts = [];
      if (city)  parts.push('city=ilike.' + encodeURIComponent(city.trim() + '%'));
      if (state) parts.push('state=eq.'   + encodeURIComponent(state.trim().toUpperCase()));
      const r = await govQuery('properties',
        'property_id,address,city,state,lease_number,agency,government_type,sf_leased,lease_expiration', {
          filter: parts.join('&'),
          order: 'city.asc,address.asc',
          limit: 25, count: false
        });
      candidates = r.data || [];
      candidatesQuery = parts.join(' AND ');
    }
    if (candidates.length === 0 && ctx.rawCity) {
      // Last resort: address field sometimes has a city-only value
      const r = await govQuery('properties',
        'property_id,address,city,state,lease_number,agency,government_type,sf_leased,lease_expiration', {
          filter: 'city=ilike.' + encodeURIComponent(ctx.rawCity.trim() + '%'),
          order: 'city.asc,address.asc',
          limit: 25, count: false
        });
      candidates = r.data || [];
      candidatesQuery = 'city~' + ctx.rawCity;
    }

    // 3) GSA inventory hits — these are the gold standard for sale-link
    //    resolution. Even if the matcher pipeline missed it, the lease
    //    number is the natural key and gsa_leases has the canonical
    //    address/agency/sf. If a GSA row already has property_id set,
    //    that's a one-click link. If not, it's a one-click create.
    let gsaHits = [];
    let gsaQuery = '';
    if (lease) {
      const r = await govQuery('gsa_leases',
        'gsa_lease_id,lease_number,address,city,state,zip_code,field_office_name,annual_rent,lease_rsf,lease_effective,lease_expiration,lessor_name,property_id,match_status,snapshot_date', {
          filter: 'lease_number=eq.' + encodeURIComponent(lease),
          order: 'snapshot_date.desc.nullslast',
          limit: 5, count: false
        });
      gsaHits = r.data || [];
      gsaQuery = 'lease_number=' + lease;
    }
    if (gsaHits.length === 0 && (city || state)) {
      const parts = [];
      if (city)  parts.push('city=ilike.' + encodeURIComponent(city.trim() + '%'));
      if (state) parts.push('state=eq.'   + encodeURIComponent(state.trim().toUpperCase()));
      const r = await govQuery('gsa_leases',
        'gsa_lease_id,lease_number,address,city,state,zip_code,field_office_name,annual_rent,lease_rsf,lease_effective,lease_expiration,lessor_name,property_id,match_status,snapshot_date', {
          filter: parts.join('&'),
          order: 'city.asc,address.asc',
          limit: 25, count: false
        });
      gsaHits = r.data || [];
      gsaQuery = parts.join(' AND ');
    }
    // Dedup gsaHits by lease_number — gsa_leases has one row per
    // (lease_number, snapshot_date), and we want the latest snapshot.
    if (gsaHits.length > 1) {
      const seen = new Set();
      gsaHits = gsaHits.filter(h => {
        const k = h.lease_number || h.gsa_lease_id;
        if (seen.has(k)) return false;
        seen.add(k); return true;
      });
    }

    govResolverCache[pendingId] = {
      loading: false, error: null,
      sale, candidates, candidatesQuery,
      gsaHits, gsaQuery
    };
  } catch (err) {
    console.error('loadGovSaleLinkContext:', err);
    govResolverCache[pendingId] = { loading: false, error: err.message || 'Failed to load context' };
  }
  renderGovTab();
};

window.govResolverLink = async function(pendingId, propertyId) {
  if (!(await lccConfirm('Link this sale to property #' + propertyId + '? sales_transactions.property_id will be updated and the pending row approved.', 'Link'))) return;
  const notes = document.getElementById('pu-notes')?.value || null;
  try {
    await govRpc('gov_resolve_sale_link', {
      p_pending_id: pendingId,
      p_property_id: Number(propertyId),
      p_notes: notes,
      p_resolved_by: 'dashboard:resolver'
    });
    govPendingUpdates = govPendingUpdates.filter(r => r.id !== pendingId);
    delete govResolverCache[pendingId];
    delete govResolverShowCreate[pendingId];
    delete govResolverNewProp[pendingId];
    govPendingUpdatesIdx = 0;
    showToast('Sale linked to property #' + propertyId, 'success');
    renderGovTab();
  } catch (err) {
    showToast('Link failed: ' + err.message, 'error');
  }
};

window.govResolverUseGsa = async function(pendingId, gsaLeaseId) {
  const cache = govResolverCache[pendingId];
  const hit = (cache && cache.gsaHits || []).find(g => g.gsa_lease_id === gsaLeaseId);
  if (!hit) return;

  // If the GSA row is already linked to a property in our inventory, this is a
  // straight Mode A link — just call gov_resolve_sale_link with that property_id.
  if (hit.property_id) {
    return window.govResolverLink(pendingId, hit.property_id);
  }

  // Otherwise, prefill the create form with GSA inventory data and call Mode C.
  if (!(await lccConfirm('Create a new property from GSA inventory:\n\n' + (hit.address || '') + ', ' + (hit.city || '') + ', ' + (hit.state || '') + '\nLease # ' + (hit.lease_number || '') + '\n\nThis will insert into properties and link the sale atomically.', 'Create from GSA'))) return;
  const notes = document.getElementById('pu-notes')?.value || null;
  try {
    const overrides = {
      address:      hit.address || '',
      city:         hit.city || '',
      state:        hit.state || '',
      lease_number: hit.lease_number || '',
      data_source:  'gsa_leases'
    };
    const res = await govRpc('gov_create_property_from_pending', {
      p_pending_id: pendingId,
      p_overrides: overrides,
      p_notes: notes,
      p_resolved_by: 'dashboard:resolver:gsa'
    });
    govPendingUpdates = govPendingUpdates.filter(r => r.id !== pendingId);
    delete govResolverCache[pendingId];
    delete govResolverShowCreate[pendingId];
    delete govResolverNewProp[pendingId];
    govPendingUpdatesIdx = 0;
    const action = (res && res.was_created === false) ? 'reused existing property' : 'property created from GSA';
    showToast('Sale linked — ' + action + (res && res.property_id ? ' (#' + res.property_id + ')' : ''), 'success');
    renderGovTab();
  } catch (err) {
    showToast('GSA-link failed: ' + err.message, 'error');
  }
};

window.govResolverToggleCreate = function(pendingId) {
  govResolverShowCreate[pendingId] = !govResolverShowCreate[pendingId];
  if (govResolverShowCreate[pendingId] && !govResolverNewProp[pendingId]) {
    const item = (govPendingUpdates || []).find(u => u.id === pendingId);
    const ctx = govResolverContextOf(item);
    const sale = (govResolverCache[pendingId] && govResolverCache[pendingId].sale) || {};
    govResolverNewProp[pendingId] = {
      address:        ctx.address || sale.address || '',
      city:           ctx.city    || sale.city    || '',
      state:          ctx.state   || sale.state   || '',
      lease_number:   ctx.leaseNumber || sale.lease_number || '',
      agency:         ctx.agency  || '',
      government_type:ctx.governmentType || ''
    };
  }
  renderGovTab();
};

window.govResolverNewPropChange = function(pendingId, field, value) {
  govResolverNewProp[pendingId] = govResolverNewProp[pendingId] || {};
  govResolverNewProp[pendingId][field] = value;
};

// Portfolio sale-link resolver (Mode D — one sale, N properties).
// Backed by gov_resolve_portfolio_sale_link in
// government-lease/sql/20260506_gov_rpc_portfolio_sale_link.sql.
window.govResolverTogglePortfolioPick = function(pendingId, propertyId) {
  if (!govResolverPortfolioSelected[pendingId]) {
    govResolverPortfolioSelected[pendingId] = new Set();
  }
  const set = govResolverPortfolioSelected[pendingId];
  const pid = Number(propertyId);
  if (set.has(pid)) set.delete(pid); else set.add(pid);
  renderGovTab();
};

window.govResolverPortfolioFilterChange = function(pendingId, value) {
  govResolverPortfolioFilter[pendingId] = value || '';
  renderGovTab();
};

window.govResolverLinkPortfolio = async function(pendingId) {
  const set = govResolverPortfolioSelected[pendingId] || new Set();
  const ids = Array.from(set);
  if (ids.length === 0) {
    showToast('Pick at least one property to link', 'warning');
    return;
  }
  if (!(await lccConfirm(
    'Link this sale to ' + ids.length + ' propert' + (ids.length === 1 ? 'y' : 'ies') +
    ' (#' + ids.join(', #') + ')? sales_transactions.property_id will stay NULL — ' +
    'the join lives in sales_transactions_properties.',
    'Link ' + ids.length + ' propert' + (ids.length === 1 ? 'y' : 'ies')
  ))) return;
  const notes = document.getElementById('pu-notes')?.value || null;
  try {
    const res = await govRpc('gov_resolve_portfolio_sale_link', {
      p_pending_id: pendingId,
      p_property_ids: ids,
      p_notes: notes,
      p_resolved_by: 'dashboard:resolver:portfolio'
    });
    govPendingUpdates = govPendingUpdates.filter(r => r.id !== pendingId);
    delete govResolverCache[pendingId];
    delete govResolverShowCreate[pendingId];
    delete govResolverNewProp[pendingId];
    delete govResolverPortfolioSelected[pendingId];
    delete govResolverPortfolioFilter[pendingId];
    govPendingUpdatesIdx = 0;
    const linked = (res && res.link_count != null) ? res.link_count : ids.length;
    showToast('Sale linked to ' + linked + ' propert' + (linked === 1 ? 'y' : 'ies'), 'success');
    renderGovTab();
  } catch (err) {
    showToast('Portfolio link failed: ' + err.message, 'error');
  }
};

window.govResolverCreate = async function(pendingId) {
  const draft = govResolverNewProp[pendingId] || {};
  if (!draft.address || !draft.city || !draft.state) {
    showToast('Address, city, and state are required to create a property', 'warning');
    return;
  }
  if (!(await lccConfirm('Create a new property at "' + draft.address + ', ' + draft.city + ', ' + draft.state + '" and link this sale to it?', 'Create & link'))) return;
  const notes = document.getElementById('pu-notes')?.value || null;
  try {
    const res = await govRpc('gov_create_property_from_pending', {
      p_pending_id: pendingId,
      p_overrides: draft,
      p_notes: notes,
      p_resolved_by: 'dashboard:resolver'
    });
    govPendingUpdates = govPendingUpdates.filter(r => r.id !== pendingId);
    delete govResolverCache[pendingId];
    delete govResolverShowCreate[pendingId];
    delete govResolverNewProp[pendingId];
    govPendingUpdatesIdx = 0;
    const action = (res && res.was_created === false) ? 'reused existing property' : 'property created';
    showToast('Sale linked — ' + action + (res && res.property_id ? ' (#' + res.property_id + ')' : ''), 'success');
    renderGovTab();
  } catch (err) {
    showToast('Create failed: ' + err.message, 'error');
  }
};

function renderGovSaleLinkResolver(selected) {
  const id = selected.id;
  const cache = govResolverCache[id];
  let html = '<div class="pu-resolver">';

  // Header
  html += '<div class="pu-resolver-head">';
  html += '<div class="pu-resolver-title">Sale-Link Resolver</div>';
  html += '<button class="pu-resolver-refresh" onclick="window.loadGovSaleLinkContext(decodeURIComponent(\'' + encodeURIComponent(id) + '\'))" title="Reload context">↻</button>';
  html += '</div>';

  // Auto-load on first render
  if (!cache) {
    setTimeout(() => window.loadGovSaleLinkContext(id), 0);
    html += '<div class="pu-resolver-loading"><div class="spinner"></div> Loading sale + candidates…</div>';
    html += '</div>';
    return html;
  }
  if (cache.loading) {
    html += '<div class="pu-resolver-loading"><div class="spinner"></div> Loading sale + candidates…</div>';
    html += '</div>';
    return html;
  }
  if (cache.error) {
    html += '<div class="pu-resolver-error">Couldn\'t load context: ' + esc(cache.error) + '</div>';
    html += '</div>';
    return html;
  }

  // Sale record summary
  const sale = cache.sale;
  html += '<div class="pu-resolver-section">';
  html += '<div class="pu-resolver-section-title">Sale Record</div>';
  if (sale) {
    const fmtMoney = (n) => n == null ? '—' : '$' + Number(n).toLocaleString();
    const fmtCap = (n) => n == null ? '' : (Number(n) * 100).toFixed(2) + '%';
    html += '<dl class="pu-resolver-dl">';
    html += '<dt>Sale date</dt><dd>' + esc(sale.sale_date || '—') + '</dd>';
    html += '<dt>Sold price</dt><dd>' + esc(fmtMoney(sale.sold_price)) + (sale.sold_cap_rate ? ' <span class="pu-resolver-muted">@ ' + esc(fmtCap(sale.sold_cap_rate)) + ' cap</span>' : '') + '</dd>';
    html += '<dt>Address</dt><dd>' + esc([sale.address, sale.city, sale.state].filter(Boolean).join(', ') || '—') + '</dd>';
    if (sale.lease_number) html += '<dt>Lease #</dt><dd><code>' + esc(sale.lease_number) + '</code></dd>';
    html += '<dt>Buyer</dt><dd>' + esc(sale.buyer || '—') + '</dd>';
    html += '<dt>Seller</dt><dd>' + esc(sale.seller || '—') + '</dd>';
    if (sale.property_id) {
      html += '<dt>Currently linked to</dt><dd class="pu-resolver-warn">⚠ property #' + esc(sale.property_id) + ' (already linked — approve will overwrite)</dd>';
    }
    html += '</dl>';
  } else {
    html += '<div class="pu-resolver-muted">Sale row not found (record_id=' + esc(selected.record_id || '') + ')</div>';
  }
  html += '</div>';

  // GSA Inventory hits (highest-priority — gold standard for sale-link resolution)
  const gsaHits = cache.gsaHits || [];
  if (gsaHits.length > 0) {
    html += '<div class="pu-resolver-section pu-resolver-gsa">';
    html += '<div class="pu-resolver-section-title">';
    html += '<span class="pu-gsa-badge">GSA INVENTORY</span> ';
    html += 'Lease found in public inventory <span class="pu-resolver-muted">(' + gsaHits.length + (cache.gsaQuery ? ' · ' + esc(cache.gsaQuery) : '') + ')</span>';
    html += '</div>';
    html += '<div class="pu-cand-list">';
    gsaHits.forEach(g => {
      const linked = !!g.property_id;
      const action = linked ? 'Link to property #' + g.property_id : 'Create & link';
      const fmtMoney = (n) => n == null ? '' : '$' + Number(n).toLocaleString();
      html += `<div class="pu-cand pu-cand-gsa">
        <div class="pu-cand-main">
          <div class="pu-cand-addr">${esc(g.address || '(no address)')}</div>
          <div class="pu-cand-meta">
            <span>${esc([g.city, g.state, g.zip_code].filter(Boolean).join(', '))}</span>
            ${g.lease_number ? '· <code>' + esc(g.lease_number) + '</code>' : ''}
            ${g.field_office_name ? '· ' + esc(g.field_office_name) : ''}
            ${g.lease_rsf ? '· ' + Number(g.lease_rsf).toLocaleString() + ' RSF' : ''}
            ${g.annual_rent ? '· ' + esc(fmtMoney(g.annual_rent)) + '/yr' : ''}
            ${g.lease_expiration ? '· exp ' + esc(g.lease_expiration) : ''}
          </div>
          ${linked ? '<div class="pu-cand-meta pu-resolver-warn">✓ Already linked to property #' + esc(g.property_id) + '</div>' : ''}
        </div>
        <button class="pu-cand-link pu-cand-gsa-btn" onclick="window.govResolverUseGsa(decodeURIComponent('${encodeURIComponent(id)}'), decodeURIComponent('${encodeURIComponent(g.gsa_lease_id)}'))">${esc(action)} →</button>
      </div>`;
    });
    html += '</div>';
    html += '</div>';
  }

  // Candidates from properties table
  const candidates = cache.candidates || [];
  const isPortfolio = GOV_PORTFOLIO_REASONS.has(selected.reason);
  const selectedSet = govResolverPortfolioSelected[id] || new Set();
  const filterStr = (govResolverPortfolioFilter[id] || '').toLowerCase().trim();
  const filteredCandidates = (isPortfolio && filterStr)
    ? candidates.filter(p => {
        const blob = [p.address, p.city, p.state, p.lease_number, p.agency].filter(Boolean).join(' ').toLowerCase();
        return blob.includes(filterStr);
      })
    : candidates;
  html += '<div class="pu-resolver-section">';
  html += '<div class="pu-resolver-section-title">Candidate Properties <span class="pu-resolver-muted">(' + candidates.length + (cache.candidatesQuery ? ' · ' + esc(cache.candidatesQuery) : '') + ')</span></div>';
  if (isPortfolio) {
    html += '<div class="pu-resolver-portfolio-banner">';
    html += '<strong>Portfolio sale.</strong> One sales_transactions row covers multiple properties — tick every property included in this deal, then confirm. ';
    html += 'Single-property "Link →" still works if the address turned out not to be a portfolio after all.';
    html += '</div>';
    if (candidates.length > 8) {
      const filterVal = govResolverPortfolioFilter[id] || '';
      html += '<div class="pu-resolver-portfolio-filter">';
      html += '<input type="text" placeholder="Filter by address, city, lease #, agency…" value="' + esc(filterVal) + '" ';
      html += 'oninput="window.govResolverPortfolioFilterChange(decodeURIComponent(\'' + encodeURIComponent(id) + '\'), this.value)" />';
      if (filterStr) {
        html += '<span class="pu-resolver-muted"> ' + filteredCandidates.length + ' / ' + candidates.length + '</span>';
      }
      html += '</div>';
    }
  }
  if (candidates.length === 0) {
    html += '<div class="pu-resolver-empty">' + (gsaHits.length > 0
      ? 'No additional candidates in the properties table. Use the GSA Inventory match above, or create a new property.'
      : 'No candidates found in inventory. Use "Create new property" below.'
    ) + '</div>';
  } else {
    html += '<div class="pu-cand-list">';
    filteredCandidates.forEach(p => {
      const exp = p.lease_expiration ? ' · exp ' + esc(p.lease_expiration) : '';
      const checked = selectedSet.has(Number(p.property_id));
      const checkbox = isPortfolio
        ? `<label class="pu-cand-pick" title="Include in portfolio link"><input type="checkbox" ${checked ? 'checked' : ''} onchange="window.govResolverTogglePortfolioPick(decodeURIComponent('${encodeURIComponent(id)}'), ${p.property_id})" /></label>`
        : '';
      html += `<div class="pu-cand${checked ? ' pu-cand-picked' : ''}">
        ${checkbox}
        <div class="pu-cand-main">
          <div class="pu-cand-addr">${esc(p.address || '(no address)')}</div>
          <div class="pu-cand-meta">
            <span>${esc([p.city, p.state].filter(Boolean).join(', '))}</span>
            ${p.lease_number ? '· <code>' + esc(p.lease_number) + '</code>' : ''}
            ${p.agency ? '· ' + esc(p.agency) : ''}
            ${exp}
          </div>
        </div>
        <button class="pu-cand-link" onclick="window.govResolverLink(decodeURIComponent('${encodeURIComponent(id)}'), ${p.property_id})">Link →</button>
      </div>`;
    });
    if (isPortfolio && filteredCandidates.length === 0 && filterStr) {
      html += '<div class="pu-resolver-empty">No candidates match "' + esc(filterStr) + '"</div>';
    }
    html += '</div>';
    if (isPortfolio) {
      const pickCount = selectedSet.size;
      const disabled = pickCount === 0 ? ' disabled' : '';
      html += '<div class="pu-resolver-portfolio-confirm">';
      html += '<button class="pu-resolver-portfolio-confirm-btn"' + disabled + ' onclick="window.govResolverLinkPortfolio(decodeURIComponent(\'' + encodeURIComponent(id) + '\'))">';
      html += pickCount === 0
        ? 'Pick properties to enable portfolio link'
        : 'Confirm ' + pickCount + '-property portfolio link →';
      html += '</button>';
      html += '</div>';
    }
  }
  html += '</div>';

  // Create new property
  const showCreate = !!govResolverShowCreate[id];
  html += '<div class="pu-resolver-section">';
  html += '<div class="pu-resolver-section-title">';
  html += '<button class="pu-resolver-toggle" onclick="window.govResolverToggleCreate(decodeURIComponent(\'' + encodeURIComponent(id) + '\'))">' + (showCreate ? '▾' : '▸') + ' Create new property from this sale</button>';
  html += '</div>';
  if (showCreate) {
    const draft = govResolverNewProp[id] || {};
    const f = (name, label, req) => {
      const v = draft[name] || '';
      return `<label class="pu-newprop-field">
        <span>${esc(label)}${req ? ' <span class="pu-resolver-warn">*</span>' : ''}</span>
        <input type="text" value="${esc(v)}" oninput="window.govResolverNewPropChange(decodeURIComponent('${encodeURIComponent(id)}'), '${name}', this.value)" />
      </label>`;
    };
    html += '<div class="pu-newprop-form">';
    html += f('address', 'Address', true);
    html += f('city',    'City',    true);
    html += f('state',   'State',   true);
    html += f('lease_number',    'Lease #', false);
    html += f('agency',          'Agency', false);
    html += f('government_type', 'Gov type', false);
    html += '</div>';
    html += '<div class="pu-newprop-help">If a property with the same lease # already exists, it will be reused (no duplicate).</div>';
    html += `<button class="btn-action primary" onclick="window.govResolverCreate(decodeURIComponent('${encodeURIComponent(id)}'))">Create & link sale</button>`;
  }
  html += '</div>';

  html += '</div>'; // pu-resolver
  return html;
}

function renderGovPendingUpdates() {
  if (!govPendingUpdates && !govPendingUpdatesLoading) {
    window.loadGovPendingUpdates();
    return '<div class="gov-loading"><div class="spinner"></div> Loading pending updates...</div>';
  }

  ensureGovPendingKeybinds();

  let html = '<div class="pipeline-ops-panel pu-panel">';

  // ── Header ────────────────────────────────────────────────────────────────
  const totalPending = govPendingUpdates?.length || 0;
  html += `<div class="pipeline-header">
    <div class="header-title">Pending Updates</div>
    <div class="header-subtitle">
      ${totalPending} update${totalPending === 1 ? '' : 's'} awaiting review${govPendingUpdatesRefreshedAt ? ' <span style="font-weight:400;opacity:0.7">(refreshed ' + govPendingUpdatesRefreshedAt.toLocaleTimeString() + ')</span>' : ''}
      <span class="pu-kbd-hint" title="Keyboard shortcuts">
        <kbd>J</kbd>/<kbd>K</kbd> next/prev · <kbd>A</kbd> approve · <kbd>R</kbd> reject · <kbd>S</kbd> skip
      </span>
    </div>
  </div>`;

  // Auto-resolved trends strip
  if (typeof govPendingAutoResolved !== 'undefined' && govPendingAutoResolved && govPendingAutoResolved.length > 0) {
    const sevenDaysAgo = new Date(Date.now() - 7 * 86400000).toISOString();
    const recent = govPendingAutoResolved.filter(o => (o.resolved_at || '') >= sevenDaysAgo);
    const bySolver = {};
    recent.forEach(o => {
      const k = o.resolved_by || 'unknown';
      bySolver[k] = (bySolver[k] || 0) + 1;
    });
    const total7d = recent.length;
    if (total7d > 0) {
      const breakdown = Object.keys(bySolver).sort((a,b) => bySolver[b]-bySolver[a])
        .map(k => bySolver[k] + ' ' + k).join(' · ');
      html += '<div class="pu-auto-strip">';
      html += '<span class="pu-auto-label">AUTO-RESOLVED (7d)</span>';
      html += ' · ' + total7d + ' items cleared without manual review · ' + breakdown;
      html += '</div>';
    }
  }

  if (!govPendingUpdates || govPendingUpdates.length === 0) {
    html += '<div class="empty-state"><div class="empty-icon">✓</div><div class="empty-title">All caught up!</div><div class="empty-desc">No pending updates to review</div></div>';
    html += '</div>';
    return html;
  }

  // ── Bucket items by category & by reason ──────────────────────────────────
  const byCategory = {};       // category id → items[]
  const reasonGroups = {};     // reason → items[]
  GOV_PENDING_CATEGORIES.forEach(c => { byCategory[c.id] = []; });
  govPendingUpdates.forEach(u => {
    const tax = govPendingTaxonomy(u.reason);
    (byCategory[tax.category] = byCategory[tax.category] || []).push(u);
    const r = u.reason || 'other';
    (reasonGroups[r] = reasonGroups[r] || []).push(u);
  });

  // ── Category chips ────────────────────────────────────────────────────────
  html += '<div class="pu-cat-bar">';
  html += `<button class="pu-cat ${govPendingFilter === 'all' ? 'active' : ''}" onclick="window.setGovPendingFilter('all')">
    <span class="pu-cat-icon">▣</span><span class="pu-cat-label">All</span><span class="pu-cat-count">${totalPending}</span>
  </button>`;
  GOV_PENDING_CATEGORIES.forEach(cat => {
    const count = byCategory[cat.id]?.length || 0;
    if (count === 0) return;
    const active = govPendingFilter === cat.id;
    html += `<button class="pu-cat ${active ? 'active' : ''}" title="${esc(cat.desc)}" onclick="window.setGovPendingFilter('${cat.id}')">
      <span class="pu-cat-icon">${cat.icon}</span><span class="pu-cat-label">${esc(cat.label)}</span><span class="pu-cat-count">${count}</span>
    </button>`;
  });
  html += '</div>';

  // ── Selected category items ───────────────────────────────────────────────
  let categoryItems;
  if (govPendingFilter === 'all') {
    categoryItems = govPendingUpdates.slice();
  } else {
    categoryItems = (byCategory[govPendingFilter] || []).slice();
  }

  // ── Subtype dropdown (only when this category has >1 reason) ─────────────
  const subtypeCounts = {};
  categoryItems.forEach(u => {
    const r = u.reason || 'other';
    subtypeCounts[r] = (subtypeCounts[r] || 0) + 1;
  });
  const subtypes = Object.keys(subtypeCounts).sort((a, b) => subtypeCounts[b] - subtypeCounts[a]);

  if (subtypes.length > 1) {
    html += '<div class="pu-subtype-row">';
    html += '<label class="pu-subtype-label">Subtype</label>';
    html += `<select class="pu-subtype-select" onchange="window.setGovPendingSubtype(this.value)">`;
    html += `<option value="all" ${govPendingSubtypeFilter === 'all' ? 'selected' : ''}>All subtypes (${categoryItems.length})</option>`;
    subtypes.forEach(r => {
      const tax = govPendingTaxonomy(r);
      const sel = govPendingSubtypeFilter === r ? 'selected' : '';
      html += `<option value="${esc(r)}" ${sel}>${esc(tax.label)} — ${subtypeCounts[r]}</option>`;
    });
    html += '</select>';
    html += '</div>';
  }

  // Apply subtype filter
  let filteredItems = govPendingSubtypeFilter === 'all'
    ? categoryItems
    : categoryItems.filter(u => (u.reason || 'other') === govPendingSubtypeFilter);

  // Sort: priority_score desc, then confidence desc, then created_at desc
  filteredItems.sort((a, b) => {
    const pa = Number(a.priority_score) || 0;
    const pb = Number(b.priority_score) || 0;
    if (pa !== pb) return pb - pa;
    const ca = Number(a.confidence) || 0;
    const cb = Number(b.confidence) || 0;
    if (ca !== cb) return cb - ca;
    return String(b.created_at || '').localeCompare(String(a.created_at || ''));
  });
  // Expose to keybinds + bulk action
  window._govPendingCurrentView = filteredItems;

  // Clamp idx
  if (govPendingUpdatesIdx >= filteredItems.length) govPendingUpdatesIdx = 0;

  // ── Bulk action bar ───────────────────────────────────────────────────────
  const highConfCount = filteredItems.filter(r => Number(r.confidence || 0) >= 0.8).length;
  html += '<div class="pu-bulk-bar">';
  html += `<span class="pu-bulk-summary">Showing <strong>${filteredItems.length}</strong> · <span style="color:#22c55e">${highConfCount}</span> at ≥80% confidence</span>`;
  if (highConfCount > 0) {
    html += `<button class="pu-bulk-btn" onclick="window.bulkApproveGovPending()" title="Approve every item in the current view at ≥80% confidence">
      ✓ Bulk approve high-confidence (${highConfCount})
    </button>`;
  }
  html += '</div>';

  if (filteredItems.length === 0) {
    html += '<div class="empty-state" style="padding:32px"><div class="empty-icon">✓</div><div class="empty-title">Nothing in this view</div><div class="empty-desc">Pick a different category or clear the subtype filter.</div></div>';
    html += '</div>';
    return html;
  }

  // ── Two-column layout ─────────────────────────────────────────────────────
  html += '<div class="pu-grid">';

  // LEFT: list
  html += '<div class="pu-list">';
  filteredItems.forEach((item, idx) => {
    const isActive = idx === govPendingUpdatesIdx;
    const tax = govPendingTaxonomy(item.reason);
    const conf = govPendingConfidenceMeta(item.confidence);
    const age = govPendingRelativeAge(item.created_at);
    html += `<div class="pu-list-item ${isActive ? 'active' : ''}" onclick="govPendingUpdatesIdx = ${idx}; renderGovTab();">
      <div class="pu-list-row1">
        <span class="pu-list-title">${esc(tax.label)}</span>
        <span class="pu-conf-pill" style="background:${conf.color}1a;color:${conf.color};border-color:${conf.color}55">${conf.pct}%</span>
      </div>
      <div class="pu-list-row2">
        <code>${esc(item.table_name)}</code>·<span>${esc(item.field_name || '')}</span>
      </div>
      <div class="pu-list-row3">
        ${age ? '<span class="pu-list-age">' + esc(age) + '</span>' : ''}
      </div>
    </div>`;
  });
  html += '</div>';

  // RIGHT: detail
  const selected = filteredItems[govPendingUpdatesIdx] || filteredItems[0];
  const oldVal = selected.old_value !== null && selected.old_value !== undefined ? String(selected.old_value) : '(empty)';
  const newVal = selected.new_value !== null && selected.new_value !== undefined ? String(selected.new_value) : '(empty)';
  const sourceCtx = selected.source_context || {};
  const tax = govPendingTaxonomy(selected.reason);
  const conf = govPendingConfidenceMeta(selected.confidence);
  const summary = govPendingSourceSummary(sourceCtx);
  const age = govPendingRelativeAge(selected.created_at);

  html += '<div class="pu-detail">';

  // Detail header
  html += '<div class="pu-detail-head">';
  html += `<div class="pu-detail-title">${esc(tax.label)}</div>`;
  const recIdStr = selected.record_id != null ? String(selected.record_id) : '';
  html += `<div class="pu-detail-meta">
    <span class="pu-conf-pill" style="background:${conf.color}1a;color:${conf.color};border-color:${conf.color}55">${conf.pct}% ${conf.label}</span>
    ${age ? '<span class="pu-detail-age">' + esc(age) + '</span>' : ''}
    <code class="pu-detail-table">${esc(selected.table_name)}.${esc(selected.field_name || '')}</code>
    ${recIdStr ? `<code class="pu-detail-recid" title="record_id (click to copy)" onclick="navigator.clipboard.writeText('${esc(recIdStr).replace(/'/g, "\\'")}'); showToast('record_id copied', 'success')">#${esc(recIdStr)}</code>` : ''}
  </div>`;
  html += '</div>';

  // Guidance banner
  html += `<div class="pu-guidance">
    <div class="pu-guidance-label">What you're approving</div>
    <div class="pu-guidance-body">${esc(tax.guidance)}</div>
  </div>`;

  // Three rendering modes, keyed off taxonomy.kind:
  //   field_change — old_value -> new_value diff (Approve writes the field)
  //   sale_link    — full resolver (sale record + candidates + create form)
  //   link_pick    — placeholder until the link-pick UI lands; no Approve
  const isFieldChange = tax.kind === 'field_change';
  const isSaleLink    = tax.kind === 'sale_link';
  const isLinkPick    = tax.kind === 'link_pick';

  if (isFieldChange) {
    // Standard value-change diff
    html += '<div class="pu-diff">';
    html += `<div class="pu-diff-cell pu-diff-old">
      <div class="pu-diff-label">Current</div>
      <div class="pu-diff-value">${esc(oldVal)}</div>
    </div>`;
    html += `<div class="pu-diff-arrow">→</div>`;
    html += `<div class="pu-diff-cell pu-diff-new">
      <div class="pu-diff-label">Proposed</div>
      <div class="pu-diff-value">${esc(newVal)}</div>
    </div>`;
    html += '</div>';
  } else if (isSaleLink) {
    html += renderGovSaleLinkResolver(selected);
  } else if (isLinkPick) {
    // gsa_property_link_review carries a pre-baked side-by-side comparison
    // in source_context (gsa_* / linked_*) — render it inline so the
    // reviewer sees what's being compared without expanding Raw JSON.
    if (selected.reason === 'gsa_property_link_review') {
      html += renderGovGsaLinkReview(selected);
    } else {
      // Other link_pick reasons (unmatched_property / unmatched_contact /
      // intake_unmatched_property) still need their dedicated picker UI;
      // until then, steer the reviewer to Reject / Skip.
      html += `<div class="pu-link-pick-placeholder">
        <div class="pu-lpp-title">${esc(tax.label)}</div>
        <div class="pu-lpp-body">
          This row needs a property selection that the link-pick UI doesn\'t render yet.
          Use <kbd>R</kbd> to reject if it\'s out of scope, or <kbd>S</kbd> to skip.
          See Source Context below for the relevant fields.
        </div>
      </div>`;
    }
  }

  // Source context summary (parsed) + collapsible raw — useful for both modes
  if (summary.length > 0 || Object.keys(sourceCtx).length > 0) {
    html += '<div class="context-block">';
    html += '<div class="context-label">Source Context</div>';
    if (summary.length > 0) {
      html += '<dl class="pu-ctx-summary">';
      summary.forEach(row => {
        const v = typeof row.value === 'object' ? JSON.stringify(row.value) : String(row.value);
        html += `<dt>${esc(row.label)}</dt><dd>${esc(v)}</dd>`;
      });
      html += '</dl>';
    }
    if (Object.keys(sourceCtx).length > 0) {
      html += `<details class="pu-ctx-raw"><summary>Raw JSON</summary><pre>${esc(JSON.stringify(sourceCtx, null, 2))}</pre></details>`;
    }
    html += '</div>';
  }

  html += guidedField('pu-notes', 'Resolution Notes', selected.resolution_notes || '', {type: 'textarea', rows: 2, placeholder: 'Optional — why you approved/rejected'});

  html += '<div class="action-row pu-action-row">';
  const isGsaLinkReview = isLinkPick && selected.reason === 'gsa_property_link_review';
  if (isFieldChange) {
    html += `<button class="btn-action primary" title="Approve (A)" onclick="_udBtnGuard(this, window.resolveGovPendingUpdate, decodeURIComponent('${encodeURIComponent(selected.id)}'), 'approved')">✓ Approve <span class="pu-kbd">A</span></button>`;
  } else if (isGsaLinkReview) {
    // Two real actions for GSA Link Review: confirm or break the auto-link.
    html += `<button class="btn-action primary" title="Same building — confirm the link (A)" onclick="_udBtnGuard(this, window.govResolveGsaLink, decodeURIComponent('${encodeURIComponent(selected.id)}'), 'approved')">✓ Same building — confirm link <span class="pu-kbd">A</span></button>`;
    html += `<button class="btn-action danger" title="Different buildings — break the link (R)" onclick="_udBtnGuard(this, window.govResolveGsaLink, decodeURIComponent('${encodeURIComponent(selected.id)}'), 'rejected')">⛓ Different — break link <span class="pu-kbd">R</span></button>`;
  } else {
    // sale_link rows have their own Link/Create buttons inside the resolver.
    // Other link_pick rows still need a generic Reject until their picker lands.
    html += `<button class="btn-action danger" title="Reject (R)" onclick="_udBtnGuard(this, window.resolveGovPendingUpdate, decodeURIComponent('${encodeURIComponent(selected.id)}'), 'rejected')">✗ Reject <span class="pu-kbd">R</span></button>`;
  }
  html += `<button class="btn-action" title="Skip to next (S)" onclick="govPendingUpdatesIdx = (govPendingUpdatesIdx + 1) % (window._govPendingCurrentView||[]).length; renderGovTab();">→ Skip <span class="pu-kbd">S</span></button>`;
  html += `<button class="btn-action" style="margin-left:auto;background:#fb923c1a;color:#fb923c;border-color:#fb923c55" title="Mark as expired" onclick="_udBtnGuard(this, window.resolveGovPendingUpdate, decodeURIComponent('${encodeURIComponent(selected.id)}'), 'expired')">⏱ Expire</button>`;
  html += '</div>';

  html += '</div>'; // pu-detail
  html += '</div>'; // pu-grid
  html += '</div>'; // pu-panel

  return html;
}

// ══════════════════════════════════════════════════════════════════════════════
// PIPELINE OPS SECTION - FINANCIAL OVERRIDES
// ══════════════════════════════════════════════════════════════════════════════

function renderGovFinancialOverrides() {
  let html = '<div class="pipeline-ops-panel">';

  html += `<div class="pipeline-header">
    <div class="header-title">Financial Overrides</div>
    <div class="header-subtitle">Manually override property financial metrics</div>
  </div>`;

  html += `<div style="padding: 16px; border: 1px solid var(--border); border-radius: 6px; background: var(--s1);">`;
  html += guidedField('fo-property-search', 'Search Property', '', {placeholder: 'Address, ID, or lease number...'});
  html += `<button class="btn-primary" style="margin-top: 8px;" onclick="window.searchFinancialProperty()">Search</button>`;
  html += '</div>';

  if (govFinOverrideRec) {
    const prop = govFinOverrideRec;
    html += '<div style="margin-top: 16px; border: 1px solid var(--border); border-radius: 6px; padding: 16px;">';

    // Property header
    html += '<div class="task-header">';
    html += `<div>${esc(prop.address || 'Property')}</div>`;
    html += '<span class="task-badge ready">Selected</span>';
    html += '</div>';

    html += '<div class="context-block">';
    html += '<div class="context-label">Location</div>';
    html += `<div class="context-value">${esc(prop.city || '')}, ${esc(prop.state || '')}</div>`;
    html += '</div>';

    // Financial fields
    const financials = [
      {field: 'gross_rent', label: 'Gross Rent', type: 'number', source: 'feed'},
      {field: 'noi', label: 'NOI', type: 'number', source: 'manual'},
      {field: 'expense_ratio', label: 'Expense Ratio (%)', type: 'number', step: '0.1', source: 'estimated'},
      {field: 'cap_rate', label: 'Cap Rate (%)', type: 'number', step: '0.1', source: 'manual'}
    ];

    financials.forEach(fin => {
      const val = prop[fin.field] || '';
      html += '<div class="context-block">';
      html += `<div class="context-label">${fin.label}</div>`;
      html += `<div style="display: flex; gap: 8px; align-items: center;">
        <div style="flex: 1; padding: 6px; background: var(--s2); border-radius: 4px; font-family: monospace; color: var(--text);">${esc(val || '(not set)')}</div>
        <span style="font-size: 11px; color: var(--text3);">Source: ${esc(fin.source)}</span>
      </div>`;
      html += '</div>';
    });

    html += '<div style="border-top: 1px solid var(--border); margin-top: 12px; padding-top: 12px;">';
    html += '<div style="font-weight: 600; margin-bottom: 12px;">Override Values</div>';
    financials.forEach(fin => {
      html += guidedField(`override-${fin.field}`, `Override ${fin.label}`, '', {type: fin.type, step: fin.step, placeholder: `Enter ${fin.label.toLowerCase()}...`});
    });

    html += guidedField('override-source-notes', 'Approval Notes', '', {type: 'textarea', rows: 3, placeholder: 'Reason for override, source of data...'});

    html += '<div class="action-row">';
    html += `<button class="btn-action primary" onclick="window.applyFinancialOverride()">Apply Override</button>`;
    html += `<button class="btn-action" onclick="govFinOverrideRec = null; renderGovTab();">Cancel</button>`;
    html += '</div>';
    html += '</div>';
    html += '</div>';
  } else {
    html += '<div class="empty-state"><div class="empty-icon">🔍</div><div class="empty-title">Search a property</div><div class="empty-desc">Enter address or ID above to find and override financial data</div></div>';
  }

  html += '</div>';
  return html;
}

window.searchFinancialProperty = async function() {
  const searchTerm = document.getElementById('fo-property-search')?.value || '';
  if (!searchTerm) return;
  const btn = document.querySelector('[onclick*="searchFinancialProperty"]');
  if (btn) { btn.disabled = true; btn.textContent = 'Searching\u2026'; btn.style.opacity = '0.6'; }
  try {
    const filterStr = `or(address.ilike.*${searchTerm}*,lease_number.ilike.*${searchTerm}*)`;
    const result = await govQuery('properties', 'id,address,city,state,lease_number', {
      filter: filterStr,
      limit: 1
    });
    const data = result.data || [];
    if (data && data.length > 0) {
      govFinOverrideRec = data[0];
      showToast('Property found: ' + (data[0].address || data[0].lease_number || 'ID ' + data[0].id), 'success');
      renderGovTab();
    } else {
      showToast('No property found matching that search', 'error');
    }
  } catch(e) {
    console.error('searchFinancialProperty error:', e);
    showToast('Search failed: ' + e.message, 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Search'; btn.style.opacity = ''; }
  }
};

window.applyFinancialOverride = async function() {
  if (!govFinOverrideRec) return;
  const notes = document.getElementById('override-source-notes')?.value || '';
  const updates = {};

  ['gross_rent', 'noi', 'expense_ratio', 'cap_rate'].forEach(field => {
    const val = document.getElementById(`override-${field}`)?.value;
    if (val !== undefined && val !== '') {
      updates[field] = parseFloat(val);
    }
  });

  if (Object.keys(updates).length === 0) {
    showToast('Please enter at least one override value', 'error');
    return;
  }

  if (!(await lccConfirm('Apply financial override to ' + (govFinOverrideRec.address || 'this property') + '? This will overwrite existing values.', 'Apply Override'))) return;

  const applyBtn = document.querySelector('[onclick*="applyFinancialOverride"]');
  if (applyBtn) { applyBtn.disabled = true; applyBtn.textContent = 'Applying...'; }

  try {
    await govPatch('properties', 'id=eq.' + govFinOverrideRec.id, {
      ...updates,
      override_notes: notes,
      authority_rank: 100
    });

    showToast('Financial override applied successfully', 'success');
    govFinOverrideRec = null;
    renderGovTab();
  } catch(e) {
    console.error('applyFinancialOverride error:', e);
    showToast('Error applying override: ' + e.message, 'error');
  } finally {
    if (applyBtn) { applyBtn.disabled = false; applyBtn.textContent = 'Apply Override'; applyBtn.style.opacity = ''; }
  }
};

// ══════════════════════════════════════════════════════════════════════════════
// PIPELINE OPS SECTION - PIPELINE CONTROL
// ══════════════════════════════════════════════════════════════════════════════

let govPipelineError = null;
window.loadGovPipelineRuns = async function() {
  if (govPipelineLoading) return;
  govPipelineLoading = true;
  govPipelineError = null;
  try {
    const result = await govQuery('ingestion_tracker', '*', {
      order: 'started_at.desc',
      limit: 50
    });
    govPipelineRuns = result.data || [];
  } catch(e) {
    console.error('loadGovPipelineRuns error:', e);
    govPipelineError = e.message || 'Failed to load pipeline runs';
    govPipelineRuns = [];
    showToast('Pipeline load error: ' + govPipelineError, 'error');
  }
  govPipelineLoading = false;
  if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'government') return;
  renderGovTab();
};

function renderGovPipelineControl() {
  if (!govPipelineRuns && !govPipelineLoading) {
    window.loadGovPipelineRuns();
    return '<div class="gov-loading"><div class="spinner"></div> Loading pipeline runs...</div>';
  }

  let html = '<div class="pipeline-ops-panel">';

  html += `<div class="pipeline-header">
    <div class="header-title">Pipeline Control</div>
    <div class="header-subtitle">${govPipelineError ? '⚠ Load error — showing cached data' : 'Monitor and manage data ingestion runs'}</div>
  </div>`;
  if (govPipelineError) {
    html += `<div style="padding:10px 14px;margin-bottom:12px;background:rgba(248,113,113,0.1);border:1px solid rgba(248,113,113,0.3);border-radius:6px;font-size:12px;color:var(--text2);display:flex;align-items:center;gap:10px;">
      <span style="flex:1">${esc(govPipelineError)}</span>
      <button onclick="govPipelineError=null;govPipelineRuns=null;loadGovPipelineRuns().then(renderGovTab)" style="padding:4px 12px;border:1px solid rgba(248,113,113,0.4);border-radius:6px;background:transparent;color:var(--text);font-size:11px;cursor:pointer;white-space:nowrap">Retry</button>
    </div>`;
  }

  const runs = govPipelineRuns || [];

  if (runs.length === 0) {
    html += '<div class="empty-state"><div class="empty-icon">📊</div><div class="empty-title">No runs recorded</div><div class="empty-desc">Pipeline run history will appear here</div></div>';
    html += '</div>';
    return html;
  }

  // Summary metrics
  const lastRun = runs[0];
  const completedRuns = runs.filter(r => r.run_status === 'completed').length;
  const successRate = runs.length > 0 ? Math.round((completedRuns / runs.length) * 100) : 0;
  const failedRuns = runs.filter(r => r.run_status === 'failed').length;

  html += '<div class="gov-metrics">';
  html += metricHTML('Last Run', lastRun.finished_at ? new Date(lastRun.finished_at).toLocaleDateString() : 'Pending', 'most recent', 'blue');
  html += metricHTML('Success Rate', successRate + '%', 'completed successfully', 'green');
  html += metricHTML('Active Errors', fmtN(failedRuns), 'failed runs', failedRuns > 0 ? 'red' : 'green');
  html += '</div>';

  html += '<div style="background: rgba(251,191,36,0.1); border: 1px solid rgba(251,191,36,0.3); border-radius: 6px; padding: 12px; margin-bottom: 16px; font-size: 13px; color: #fbbf24;">';
  html += '📌 Pipeline runs are triggered via CLI. Contact your administrator to schedule automated runs.';
  html += '</div>';

  // Runs table
  html += '<div class="table-section">';
  html += '<h3 style="margin-bottom: 12px;">Recent Runs</h3>';
  html += '<div style="overflow-x: auto;">';
  html += '<table style="width: 100%; border-collapse: collapse; font-size: 13px;">';
  html += '<thead><tr style="background: var(--s2); border-bottom: 2px solid var(--border);">';
  html += '<th style="padding: 8px; text-align: left; font-weight: 600;">Source</th>';
  html += '<th style="padding: 8px; text-align: left; font-weight: 600;">Task</th>';
  html += '<th style="padding: 8px; text-align: center; font-weight: 600;">Status</th>';
  html += '<th style="padding: 8px; text-align: left; font-weight: 600;">Started</th>';
  html += '<th style="padding: 8px; text-align: left; font-weight: 600;">Duration</th>';
  html += '<th style="padding: 8px; text-align: center; font-weight: 600;">Rows</th>';
  html += '</tr></thead>';
  html += '<tbody>';

  runs.slice(0, 20).forEach(run => {
    const statusColor = run.run_status === 'completed' ? '#10b981' : run.run_status === 'failed' ? '#ef4444' : '#f59e0b';
    const statusText = run.run_status === 'completed' ? '✓ Completed' : run.run_status === 'failed' ? '✗ Failed' : '⟳ Running';
    const startDate = run.started_at ? new Date(run.started_at).toLocaleString() : '—';
    const duration = run.finished_at && run.started_at ? Math.round((new Date(run.finished_at) - new Date(run.started_at)) / 1000) + 's' : '—';
    const rowStr = run.rows_inserted || 0;

    html += `<tr style="border-bottom: 1px solid var(--border);">
      <td style="padding: 8px;">${esc(run.source || '—')}</td>
      <td style="padding: 8px;">${esc(run.task_name || '—')}</td>
      <td style="padding: 8px; text-align: center;"><span style="background: ${statusColor}; color: white; padding: 2px 8px; border-radius: 3px; font-size: 11px; font-weight: 600;">${statusText}</span></td>
      <td style="padding: 8px; font-size: 12px; color: var(--text3);">${startDate}</td>
      <td style="padding: 8px; font-size: 12px; color: var(--text3);">${duration}</td>
      <td style="padding: 8px; text-align: center; font-size: 12px;">${rowStr}</td>
    </tr>`;

    if (run.error_summary && run.run_status === 'failed') {
      html += `<tr style="background: rgba(239,68,68,0.1); border-bottom: 1px solid var(--border);">
        <td colspan="6" style="padding: 8px; font-size: 12px; color: var(--text3);">
          <strong style="color: #ef4444;">Error:</strong> ${esc(run.error_summary)}
        </td>
      </tr>`;
    }
  });

  html += '</tbody>';
  html += '</table>';
  html += '</div>';
  html += '</div>';

  html += '</div>';

  return html;
}

// ══════════════════════════════════════════════════════════════════════════════
// PIPELINE OPS SECTION - MONITOR DASHBOARD
// ══════════════════════════════════════════════════════════════════════════════

async function loadGovMonitorData() {
  if (govMonitorLoading) return;
  govMonitorLoading = true;
  try {
    // Lead gaps from prospect_leads. PERF (2026-05-31): govData.leads is now a
    // top-1,000 working set, so counting gaps off it would understate the true
    // population. Pull authoritative gap counts server-side via count=exact
    // (limit:1 + the count header), falling back to the working set if a count
    // query fails so the monitor still renders.
    const leads = govData.leads || [];
    const _gapCount = async (filter) => {
      try { const r = await govQuery('prospect_leads', 'lead_id', { filter, limit: 1 }); return (typeof r.count === 'number') ? r.count : null; }
      catch (_e) { return null; }
    };
    const [_nm, _nc, _nr] = await Promise.all([
      _gapCount('matched_property_id=is.null'),
      _gapCount('contact_email=is.null&contact_phone=is.null'),
      _gapCount('or=(research_status.is.null,research_status.eq.pending)'),
    ]);
    const noMatch = (_nm != null) ? _nm : leads.filter(l => !l.matched_property_id).length;
    const noContact = (_nc != null) ? _nc : leads.filter(l => !l.contact_email && !l.contact_phone).length;
    const noResearch = (_nr != null) ? _nr : leads.filter(l => !l.research_status || l.research_status === 'pending').length;

    // Load data freshness from ingestion metadata if available
    let freshness = [];
    try {
      const fResult = await govQuery('ingestion_log', 'source,max_ingested_at', { order: 'max_ingested_at.desc', limit: 10 });
      freshness = (fResult.data || []).map(row => {
        const daysOld = row.max_ingested_at ? Math.floor((Date.now() - new Date(row.max_ingested_at).getTime()) / 86400000) : null;
        return { source: row.source, daysOld: daysOld };
      });
    } catch(e) {
      // Fallback: use known data sources with property timestamps
      const props = govData.properties || [];
      const latestProp = props.length > 0 && props[0].updated_at ? Math.floor((Date.now() - new Date(props[0].updated_at).getTime()) / 86400000) : null;
      freshness = [
        { source: 'Properties DB', daysOld: latestProp }
      ];
    }

    // Research completion stats
    const ownership = govData.ownership || [];
    const completed = ownership.filter(o => o.research_status === 'completed').length;
    const total = ownership.length;

    govMonitorData = { noMatch, noContact, noResearch, freshness, researchCompleted: completed, researchTotal: total };
  } catch(e) {
    console.error('loadGovMonitorData error:', e);
    govMonitorData = { noMatch: 0, noContact: 0, noResearch: 0, freshness: [], researchCompleted: 0, researchTotal: 0 };
  }
  govMonitorLoading = false;
  if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'government') return;
  renderGovTab();
}

function renderGovMonitorDashboard() {
  if (!govMonitorData && !govMonitorLoading) {
    loadGovMonitorData();
    return '<div class="gov-loading"><div class="spinner"></div> Loading monitor data...</div>';
  }
  if (govMonitorLoading) {
    return '<div class="gov-loading"><div class="spinner"></div> Loading monitor data...</div>';
  }

  const d = govMonitorData;
  let html = '<div class="pipeline-ops-panel">';

  html += `<div class="pipeline-header">
    <div class="header-title">Monitor Dashboard</div>
    <div class="header-subtitle">Data health, freshness, and quality metrics</div>
    <button class="btn-action default" onclick="if(!govMonitorLoading){var _b=this;_b.disabled=true;_b.textContent='Refreshing\u2026';_b.style.opacity='0.6';govMonitorData=null;loadGovMonitorData().then(function(){_b.disabled=false;_b.textContent='Refresh';_b.style.opacity='';}).catch(function(){_b.disabled=false;_b.textContent='Refresh';_b.style.opacity='';});}" style="margin-left:auto;padding:4px 10px;font-size:11px;">${govMonitorLoading ? 'Refreshing\u2026' : 'Refresh'}</button>
  </div>`;

  // Panel 1: Lead Gap Report (live data)
  html += '<div style="margin-bottom: 20px; border: 1px solid var(--border); border-radius: 6px; padding: 16px; background: var(--s1);">';
  html += '<h3 style="margin-bottom: 12px; font-size: 14px; font-weight: 600;">Lead Gap Report</h3>';
  html += '<div style="font-size: 13px; color: var(--text3); margin-bottom: 12px;">Counts of leads with missing critical data</div>';

  html += '<div style="display: grid; gap: 12px;">';
  const gapMetrics = [
    {label: 'No Property Match', value: d.noMatch},
    {label: 'No Contact Info', value: d.noContact},
    {label: 'No Research', value: d.noResearch}
  ];

  const maxVal = Math.max(...gapMetrics.map(m => m.value), 1);
  gapMetrics.forEach(metric => {
    const pct = (metric.value / maxVal) * 100;
    html += `<div>
      <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
        <span style="font-size: 12px; font-weight: 500;">${metric.label}</span>
        <span style="font-size: 12px; color: var(--text3);">${metric.value}</span>
      </div>
      <div style="height: 20px; background: var(--s3); border-radius: 3px; overflow: hidden;">
        <div style="height: 100%; width: ${pct}%; background: linear-gradient(90deg, #3b82f6, #60a5fa); border-radius: 3px;"></div>
      </div>
    </div>`;
  });
  html += '</div>';
  html += '</div>';

  // Panel 2: Data Freshness (live data)
  html += '<div style="margin-bottom: 20px; border: 1px solid var(--border); border-radius: 6px; padding: 16px; background: var(--s1);">';
  html += '<h3 style="margin-bottom: 12px; font-size: 14px; font-weight: 600;">Data Freshness by Source</h3>';
  html += '<div style="font-size: 13px; color: var(--text3); margin-bottom: 12px;">Days since last data update</div>';

  html += '<div style="display: grid; gap: 8px;">';
  if (d.freshness.length === 0) {
    html += '<div style="padding: 12px; text-align: center; color: var(--text3); font-size: 12px;">No ingestion log data available</div>';
  } else {
    d.freshness.forEach(item => {
      const statusColor = item.daysOld === null ? '#6b7280' : item.daysOld < 7 ? '#10b981' : item.daysOld < 30 ? '#f59e0b' : '#ef4444';
      const daysLabel = item.daysOld !== null ? item.daysOld + ' days old' : 'Unknown';
      html += `<div style="display: flex; align-items: center; justify-content: space-between; padding: 8px; background: var(--s2); border-radius: 4px; border: 1px solid var(--border);">
        <span style="font-size: 12px; font-weight: 500;">${esc(item.source)}</span>
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 12px; color: var(--text3);">${daysLabel}</span>
          <div style="width: 12px; height: 12px; border-radius: 50%; background: ${statusColor};"></div>
        </div>
      </div>`;
    });
  }
  html += '</div>';
  html += '</div>';

  // Panel 3: Research Progress (live data)
  html += '<div style="margin-bottom: 20px; border: 1px solid var(--border); border-radius: 6px; padding: 16px; background: var(--s1);">';
  html += '<h3 style="margin-bottom: 12px; font-size: 14px; font-weight: 600;">Research Progress</h3>';
  html += '<div style="font-size: 13px; color: var(--text3); margin-bottom: 12px;">Ownership changes with completed research</div>';

  const resPct = d.researchTotal > 0 ? Math.round((d.researchCompleted / d.researchTotal) * 100) : 0;
  html += `<div style="margin-bottom: 8px; display: flex; justify-content: space-between;">
    <span style="font-size: 12px; font-weight: 500;">${d.researchCompleted} of ${d.researchTotal} completed</span>
    <span style="font-size: 12px; color: var(--text3);">${resPct}%</span>
  </div>`;
  html += `<div style="height: 24px; background: var(--s3); border-radius: 3px; overflow: hidden;">
    <div style="height: 100%; width: ${resPct}%; background: linear-gradient(90deg, #10b981, #34d399); border-radius: 3px; transition: width 0.3s;"></div>
  </div>`;
  html += '</div>';

  html += '</div>';

  return html;
}

function renderGovResearch() {
  let html = '<div class="research-workbench">';

  // Queue counts for badges
  const puCount = govPendingUpdates ? govPendingUpdates.length : null;
  const inCount = govIntakeQueue ? govIntakeQueue.length : null;
  const owCount = govData.ownership ? govData.ownership.filter(o => !o.sale_price && (!o.research_status || o.research_status === 'pending')).length : 0;
  const ldCount = govData.leads ? govData.leads.filter(l => !l.research_status || l.research_status === 'pending').length : 0;
  const portfolio = govData.portfolioProperties || [];
  const intelCount = portfolio.filter(p => !p.intel_status || p.intel_status === 'pending').length;

  // Pipeline step definitions — ordered from data quality to prospecting to monitoring
  const pipelineSteps = [
    { key: 'pending_updates',    num: '1', label: 'Pending Updates',   count: puCount,    phase: 'quality',     desc: 'Approve or reject AI-proposed data changes' },
    { key: 'pipeline_control',   num: '2', label: 'Pipeline Control',  count: null,       phase: 'quality',     desc: 'Monitor ingestion runs and error rates' },
    { key: 'intake',             num: '3', label: 'Intake',            count: inCount,    phase: 'quality',     desc: 'Review email intake documents before DB promotion' },
    { key: 'ownership',          num: '4', label: 'Ownership',         count: owCount,    phase: 'enrichment',  desc: 'Research sale details, entity, and true owner' },
    { key: 'leads',              num: '5', label: 'Leads',             count: ldCount,    phase: 'enrichment',  desc: 'Complete lead profiles with ownership and contact data' },
    { key: 'intel',              num: '6', label: 'Intel',             count: intelCount, phase: 'enrichment',  desc: 'Fill property intelligence gaps (value, rent, condition)' },
    { key: 'financial_overrides',num: '7', label: 'Financials',        count: null,       phase: 'prospecting', desc: 'Override financial metrics for pipeline properties' },
    { key: 'monitor',            num: '',  label: 'Monitor',           count: null,       phase: 'monitoring',  desc: 'Dashboard: lead gaps, data freshness, research progress' },
  ];

  // Phase labels for visual grouping
  const phases = [
    { key: 'quality',     label: 'DATA QUALITY',  color: '#f87171', icon: '🛡️' },
    { key: 'enrichment',  label: 'ENRICHMENT',    color: '#fbbf24', icon: '🔍' },
    { key: 'prospecting', label: 'PROSPECTING',   color: '#34d399', icon: '🎯' },
    { key: 'monitoring',  label: 'MONITORING',    color: '#60a5fa', icon: '📊' },
  ];

  // Current step's phase
  const currentStep = pipelineSteps.find(s => s.key === researchMode) || pipelineSteps[0];
  const currentPhase = phases.find(p => p.key === currentStep.phase) || phases[0];

  // === Pipeline progress bar ===
  html += '<div style="display:flex;gap:0;margin-bottom:16px;border-radius:8px;overflow:hidden;border:1px solid var(--border);background:var(--s2);height:4px">';
  phases.forEach(ph => {
    const stepsInPhase = pipelineSteps.filter(s => s.phase === ph.key);
    const isActive = ph.key === currentStep.phase;
    const isPast = phases.indexOf(ph) < phases.indexOf(currentPhase);
    html += `<div style="flex:${stepsInPhase.length};height:100%;background:${isActive ? ph.color : isPast ? ph.color + '60' : 'transparent'};transition:background 0.3s"></div>`;
  });
  html += '</div>';

  // === Tab strip — unified pipeline order ===
  html += '<div style="display:flex;gap:0;margin-bottom:20px;border:1px solid var(--border);border-radius:10px;overflow:hidden;background:var(--s2)">';

  let lastPhase = '';
  pipelineSteps.forEach((step, i) => {
    const isActive = researchMode === step.key;
    const phase = phases.find(p => p.key === step.phase);
    const showSeparator = step.phase !== lastPhase && i > 0;
    lastPhase = step.phase;

    if (showSeparator) {
      html += '<div style="width:1px;background:var(--border);flex-shrink:0"></div>';
    }

    const activeBg = isActive ? phase.color + '18' : 'transparent';
    const activeBorder = isActive ? 'border-bottom:2px solid ' + phase.color + ';' : '';
    const activeColor = isActive ? phase.color : 'var(--text2)';
    const fontWeight = isActive ? '700' : '500';
    const badge = step.count != null && step.count > 0
      ? `<span style="display:inline-block;min-width:18px;text-align:center;padding:1px 5px;border-radius:10px;font-size:9px;font-weight:700;background:${phase.color}20;color:${phase.color};margin-left:4px">${step.count > 999 ? '999+' : step.count}</span>`
      : step.count === 0 ? '<span style="display:inline-block;min-width:18px;text-align:center;padding:1px 5px;border-radius:10px;font-size:9px;font-weight:700;background:var(--s3);color:var(--text3);margin-left:4px">0</span>' : '';
    const numBadge = step.num ? `<span style="display:inline-block;width:16px;height:16px;line-height:16px;text-align:center;border-radius:50%;font-size:9px;font-weight:700;background:${isActive ? phase.color : 'var(--s3)'};color:${isActive ? '#fff' : 'var(--text3)'};margin-right:4px">${step.num}</span>` : '';

    html += `<button class="gov-research-tab" data-gov-mode="${step.key}" style="flex:1;padding:10px 6px;font-size:11px;font-weight:${fontWeight};color:${activeColor};background:${activeBg};border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:2px;white-space:nowrap;${activeBorder}transition:all 0.2s" title="${step.desc}">`;
    html += numBadge;
    html += `<span>${step.label}</span>`;
    html += badge;
    html += '</button>';
  });

  html += '</div>';

  // === Phase context header ===
  html += `<div style="padding:10px 14px;background:${currentPhase.color}10;border-radius:8px;border-left:3px solid ${currentPhase.color};margin-bottom:16px;display:flex;align-items:center;gap:10px;">`;
  html += `<span style="font-size:18px">${currentPhase.icon}</span>`;
  html += `<div>`;
  html += `<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:${currentPhase.color};margin-bottom:2px">${currentPhase.label}${currentStep.num ? ' — Step ' + currentStep.num + ' of 7' : ''}</div>`;
  html += `<div style="font-size:13px;color:var(--text);line-height:1.4"><strong>${currentStep.label}:</strong> ${currentStep.desc}</div>`;
  html += '</div></div>';

  // === Research modes: show Live Intake + Evidence + filter + queue ===
  const isResearchMode = ['ownership', 'leads', 'intel'].includes(researchMode);

  if (isResearchMode) {
    html += renderLiveIngestWorkbench('government');
    html += renderGovEvidenceWorkbench();

    // Filter toggle — pending vs all
    let totalRecords, pendingCount;
    if (researchMode === 'ownership') {
      totalRecords = govData.ownership.length;
      pendingCount = owCount;
    } else if (researchMode === 'intel') {
      totalRecords = portfolio.length;
      pendingCount = intelCount;
    } else {
      totalRecords = govData.leadsTotal || govData.leads.length;
      pendingCount = ldCount;
    }

    html += `<div class="research-mode-toggle" style="margin-top:4px">
      <button class="mode-btn ${researchFilter === 'pending' ? 'active' : ''}" onclick="setResearchFilter('pending')">Pending (${pendingCount})</button>
      <button class="mode-btn ${researchFilter === 'all' ? 'active' : ''}" onclick="setResearchFilter('all')">All (${totalRecords})</button>
    </div>`;

    // Sweep button — only on the ownership queue, only when there are
    // pending rows. Calls gov_auto_resolve_ownership(p_dry_run=true) for
    // a count preview, then a confirm + p_dry_run=false on apply.
    if (researchMode === 'ownership' && pendingCount > 0) {
      html += `<div class="own-sweep-bar" style="margin-top:8px">
        <button class="btn-secondary" onclick="window.govOwnershipSweepPreview()" title="Preview rows the system can auto-resolve (empty shells, placeholder priors, comp-on-file)">
          🧹 Sweep auto-resolvable (preview)
        </button>
        <span class="own-sweep-bar-help">Resolves rows with no research handle, bot-generated placeholder priors, and comps already on file.</span>
      </div>`;
    }
    if (researchMode === 'intel' && pendingCount > 0) {
      // Tier count strip — gives the reviewer the priority distribution at
      // a glance so they know "how much of this is hot vs. backfill"
      // before scrolling. govData.portfolioProperties was just annotated
      // by the loader, so we can summarise it directly.
      const portfolio = govData.portfolioProperties || [];
      const _pendOnly = portfolio.filter(p => !p.intel_status || p.intel_status === 'pending');
      const tierCounts = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
      _pendOnly.forEach(p => { tierCounts[p._priority || 9]++; });
      const tierMeta = [
        { id: 1, cls: 'urgent',      label: 'Hot research', icon: '🔥' },
        { id: 2, cls: 'urgent',      label: 'Hot verify',   icon: '✓' },
        { id: 3, cls: 'needs-input', label: 'Warm',         icon: '◐' },
        { id: 4, cls: 'ready',       label: 'Backfill',     icon: '·' },
        { id: 5, cls: 'ready',       label: 'Low value',    icon: '↓' }
      ];
      html += '<div class="own-tier-strip">';
      tierMeta.forEach(t => {
        const n = tierCounts[t.id] || 0;
        if (n === 0) return;
        html += `<span class="own-tier-pill own-tier-${t.cls}" title="${esc(t.label)}">
          <span class="own-tier-pill-icon">${t.icon}</span>
          <span class="own-tier-pill-label">${esc(t.label)}</span>
          <span class="own-tier-pill-n">${n.toLocaleString()}</span>
        </span>`;
      });
      // Quick "Start with Hot Verify" jump button — Tier 2 is highest-leverage
      // (full intel, just needs a click). Surface it when present.
      if (tierCounts[2] > 0) {
        html += `<button class="own-tier-jump" onclick="window.govIntelJumpToTier(2)" title="Jump to Tier 2 — A/B grade, sell-side window, intel ready to confirm">
          → Start with Hot verify (${tierCounts[2]})
        </button>`;
      }
      html += '</div>';

      html += `<div class="own-sweep-bar" style="margin-top:8px">
        <button class="btn-secondary" onclick="window.govIntelSweepPreview()" title="Preview properties the system can auto-resolve (junk stubs, tier-2 ready-to-approve, FRPP backfills, sale syncs)">
          🧹 Sweep auto-resolvable (preview)
        </button>
        <span class="own-sweep-bar-help">Marks stubs + tier-2-complete; backfills year_built / RBA from FRPP and recent sale from sales_transactions.</span>
      </div>`;
    }

    // Load queue if empty
    if (researchQueue.length === 0) {
      loadResearchQueue();
    }

    if (researchQueue.length === 0) {
      html += `<div class="research-empty">
        <div class="empty-icon">${researchFilter === 'pending' ? '✓' : '∅'}</div>
        <div class="empty-title">${researchFilter === 'pending' ? 'No pending ' + researchMode + ' items' : 'No ' + researchMode + ' records loaded'}</div>
        <div class="empty-desc">${totalRecords} total records · ${pendingCount} pending</div>
        ${researchFilter === 'pending' && totalRecords > 0 ? `<button class="btn-primary" onclick="setResearchFilter('all')">Show All ${totalRecords} Records</button>` : ''}
        <button class="btn-secondary" style="margin-top:8px" onclick="researchQueue=[];loadResearchQueue();renderGovTab()">Refresh Queue</button>
      </div>`;
      html += '</div>';
      setTimeout(() => bindLiveIngestWorkbench('government'), 0);
      setTimeout(() => bindGovEvidenceWorkbench(), 0);
      setTimeout(() => { document.querySelectorAll('[data-gov-mode]').forEach(btn => { btn.addEventListener('click', () => { setResearchMode(btn.dataset.govMode); }); }); }, 0);
      return html;
    }

    // Render the research card (progress + card)
    html += renderResearchInner();

  } else if (researchMode === 'pending_updates') {
    html += renderGovPendingUpdates();
  } else if (researchMode === 'intake') {
    if (!govIntakeQueue) loadGovIntakeQueue();
    html += renderGovIntakeQueue();
  } else if (researchMode === 'financial_overrides') {
    html += renderGovFinancialOverrides();
  } else if (researchMode === 'pipeline_control') {
    html += renderGovPipelineControl();
  } else if (researchMode === 'monitor') {
    html += renderGovMonitorDashboard();
  }

  html += '</div>';
  setTimeout(() => bindLiveIngestWorkbench('government'), 0);
  setTimeout(() => bindGovEvidenceWorkbench(), 0);
  // Attach tab click handlers
  setTimeout(() => {
    document.querySelectorAll('[data-gov-mode]').forEach(btn => {
      btn.addEventListener('click', () => {
        setResearchMode(btn.dataset.govMode);
      });
    });
  }, 0);
  return html;
}

// ============================================================================
// UI Phase 3 — GSA / FRPP Intel standalone tab (promoted from Overview §11)
// Recomputes its values from the same globals renderGovOverview uses
// (govOverviewStats MV + govData.* page-capped arrays) so it stays in sync with
// the Overview section without coupling to that function's locals.
// ============================================================================
function renderGovGsaIntel() {
  const mv = (typeof govOverviewStats !== 'undefined') ? govOverviewStats : null;
  const gsaEvents = (typeof govData !== 'undefined' && govData.gsaEvents) || [];
  const gsaSnapshots = (typeof govData !== 'undefined' && govData.gsaSnapshots) || [];
  const frpp = (typeof govData !== 'undefined' && govData.frppRecords) || [];
  const now = new Date();
  const yearStart = new Date(now.getFullYear(), 0, 1);

  const gsaEventsYTD = mv ? (mv.gsa_events_ytd || 0) : gsaEvents.filter(e => e.event_date && new Date(e.event_date) >= yearStart).length;
  const gsaEventsTotal = mv ? (mv.gsa_events_total || 0) : gsaEvents.length;
  const gsaEventTypes = {};
  gsaEvents.forEach(e => { gsaEventTypes[e.event_type] = (gsaEventTypes[e.event_type] || 0) + 1; });
  const totalGsaRent = mv ? Number(mv.gsa_current_annual_rent || 0) : gsaSnapshots.reduce((s, s2) => s + (s2.annual_rent || 0), 0);
  const gsaLeasesTracked = mv ? (mv.gsa_leases_tracked || gsaSnapshots.length) : gsaSnapshots.length;
  const frppCountTotal = mv ? (mv.frpp_total || (govData && govData.frppCount) || frpp.length) : ((govData && govData.frppCount) || frpp.length);
  const frppTotalSF = mv ? Number(mv.frpp_total_sf || 0) : frpp.reduce((s, r) => s + (r.square_feet || 0), 0);
  const frppTotalRent = mv ? Number(mv.frpp_total_rent || 0) : frpp.reduce((s, r) => s + (r.annual_rent_to_lessor || 0), 0);
  const frppAgencies = mv ? (mv.frpp_distinct_agencies || 0) : new Set(frpp.map(r => r.using_agency).filter(Boolean)).size;

  let html = '<div class="biz-section">';
  html += govSectionHeader('GSA Lease Intelligence', '📋', 'search');
  html += '<div class="gov-grid gov-grid-4">';
  const _gsaLoading = !mv && !(govData && govData._phase2Loaded);
  const _gsaSk = '…';
  html += govCard({ title: 'GSA Events YTD', value: _gsaLoading ? _gsaSk : fmtN(gsaEventsYTD), sub: _gsaLoading ? 'loading…' : (now.getFullYear() + ' of ' + fmtN(gsaEventsTotal) + ' tracked'), color: 'blue' });
  html += govCard({ title: 'GSA Total Rent', value: _gsaLoading ? _gsaSk : ('$' + fmtN(Math.round(totalGsaRent / 1e6)) + 'M'), sub: _gsaLoading ? 'loading…' : (fmtN(gsaLeasesTracked) + ' leases tracked'), color: 'green' });
  html += govCard({ title: 'FRPP Square Feet', value: _gsaLoading ? _gsaSk : (fmtN(Math.round(frppTotalSF / 1e6)) + 'M'), sub: _gsaLoading ? 'loading…' : (fmtN(frppCountTotal) + ' federal properties'), color: 'cyan' });
  html += govCard({ title: 'FRPP Agencies', value: _gsaLoading ? _gsaSk : fmtN(frppAgencies), sub: _gsaLoading ? 'loading…' : ('$' + fmtN(Math.round(frppTotalRent / 1e6)) + 'M annual rent'), color: 'purple' });
  html += '</div>';

  if (Object.keys(gsaEventTypes).length > 0) {
    html += '<div class="gov-info-card" style="padding:14px 16px;margin-top:10px">';
    html += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">GSA Event Types</div>';
    const maxEvt = Math.max(...Object.values(gsaEventTypes));
    html += inlineBar(Object.entries(gsaEventTypes).sort((a,b) => b[1] - a[1]).map(([type, count]) => ({
      label: type, value: count, display: fmtN(count), barColor: '#22d3ee', labelWidth: 120, valueWidth: 35
    })), maxEvt);
    html += '</div>';
  }
  html += '</div>';
  return html;
}

// ============================================================================
// UI Phase 3 — gov Properties inventory tab (INVENTORY group). Mirrors the dia
// Properties pattern (paginated, value-first) against gov data via govQuery.
// Value-first default order = gross_rent DESC (the consumption-layer doctrine).
// ============================================================================
var GOV_PROPERTIES_PAGE_SIZE = 25;
var govPropertiesPage = 0;
var govPropertiesSearch = '';
var govPropertiesSort = { col: 'gross_rent', dir: 'desc' };
var govPropertiesData = null;
var govPropertiesTotalCount = 0;
var govPropertiesRequestId = 0;

function _govPropsOrder() {
  var col = govPropertiesSort.col || 'gross_rent';
  var dir = govPropertiesSort.dir || 'desc';
  var textCol = (col === 'address' || col === 'city' || col === 'state' || col === 'agency');
  return col + '.' + dir + (textCol ? '' : '.nullslast');
}

function _govPropsFilters() {
  // Base: exclude archived so the inventory matches the Overview "active" headline
  // (gov has essentially no null-status rows, per R23 grounding).
  var filter = 'status=neq.archived', filter2 = null;
  if (govPropertiesSearch) {
    var sq = govPropertiesSearch.replace(/%/g, '').replace(/\\/g, '');
    filter2 = 'or(address.ilike.*' + sq + '*,city.ilike.*' + sq + '*,state.ilike.*' + sq + '*,agency.ilike.*' + sq + '*)';
  }
  return { filter: filter, filter2: filter2 };
}

async function renderGovProperties() {
  var inner = document.getElementById('bizPageInner');
  if (!inner) return;

  if (govPropertiesData === null) {
    inner.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading properties...</p></div>';
  }

  var order = _govPropsOrder();
  var filters = _govPropsFilters();
  var offset = govPropertiesPage * GOV_PROPERTIES_PAGE_SIZE;
  var requestId = ++govPropertiesRequestId;

  try {
    var result = await govQuery('properties',
      'property_id,address,city,state,agency,sf_leased,gross_rent,year_built,status', {
        order: order, filter: filters.filter, filter2: filters.filter2,
        limit: GOV_PROPERTIES_PAGE_SIZE, offset: offset
      });
    if (requestId !== govPropertiesRequestId) return; // stale
    govPropertiesData = result.data || [];
    govPropertiesTotalCount = result.count || 0;
  } catch (e) {
    if (requestId !== govPropertiesRequestId) return;
    console.error('Gov properties load error:', e);
    govPropertiesData = [];
    govPropertiesTotalCount = 0;
  }

  var pageRows = govPropertiesData;
  var totalCount = govPropertiesTotalCount;
  var totalPages = Math.max(1, Math.ceil(totalCount / GOV_PROPERTIES_PAGE_SIZE));

  var html = '<div class="biz-section">';
  html += '<div style="padding:10px 14px;background:rgba(108,140,255,0.08);border-radius:8px;border-left:3px solid #6c8cff;margin-bottom:16px;font-size:13px;color:var(--text);line-height:1.4"><strong>Properties</strong> — Browse the active government-leased property inventory, value-ranked by annual rent. Click any row to view property detail, ownership, and lease terms.</div>';

  html += '<div class="gov-grid gov-grid-3" style="margin-bottom:16px;">';
  html += govCard({ title: 'Active Properties', value: fmtN(totalCount), sub: 'archived excluded', color: 'blue' });
  html += '</div>';

  // Search bar
  html += '<div style="margin:16px 0;display:flex;gap:8px;align-items:center;flex-wrap:wrap;">';
  html += '<input type="text" id="govPropsSearchInput" placeholder="Search address, city, state, agency..." value="' + esc(govPropertiesSearch) + '" style="flex:1;min-width:200px;padding:8px 12px;border-radius:8px;border:1px solid var(--border);background:var(--s2);color:var(--text);font-size:13px;" />';
  html += '<span style="font-size:12px;color:var(--text3);">' + fmtN(totalCount) + ' results</span>';
  html += '</div>';

  // Sort toolbar — value (gross_rent) is the default/primary sort
  var SORT_COLS = [
    { col: 'gross_rent', label: 'Rent' },
    { col: 'address', label: 'Address' },
    { col: 'city', label: 'City' },
    { col: 'state', label: 'State' },
    { col: 'agency', label: 'Agency' },
    { col: 'sf_leased', label: 'SF' },
    { col: 'year_built', label: 'Year Built' }
  ];
  var sortArrow = function(col) {
    if (govPropertiesSort.col !== col) return '';
    return govPropertiesSort.dir === 'asc' ? ' ▲' : ' ▼';
  };
  html += '<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-bottom:10px;">';
  html += '<span style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:0.4px;margin-right:4px;">Sort:</span>';
  SORT_COLS.forEach(function(s) {
    var active = govPropertiesSort.col === s.col;
    html += '<button class="pill' + (active ? ' active' : '') + '" data-gov-prop-sort-col="' + s.col + '" style="font-size:11px;padding:4px 10px;">' + s.label + sortArrow(s.col) + '</button>';
  });
  html += '</div>';

  // Card grid
  html += '<div style="overflow-y:auto;-webkit-overflow-scrolling:touch;border:1px solid var(--border);border-radius:10px;max-height:70vh;padding:10px;display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px;">';
  pageRows.forEach(function(r, _ri) {
    var title = r.address || '—';
    var locParts = [];
    if (r.city) locParts.push(r.city);
    if (r.state) locParts.push(r.state);
    var locLine = locParts.join(', ');
    var metaParts = [];
    if (r.sf_leased && parseFloat(r.sf_leased) > 0) metaParts.push(fmtN(Math.round(parseFloat(r.sf_leased))) + ' SF');
    if (r.year_built) metaParts.push('Built ' + r.year_built);
    var rentVal = r.gross_rent && parseFloat(r.gross_rent) > 0 ? '$' + fmtN(Math.round(parseFloat(r.gross_rent))) + ' rent' : '';
    html += '<div class="prop-card clickable-row" data-gov-prop-idx="' + _ri + '" style="cursor:pointer;padding:12px 14px;border:1px solid var(--border);border-radius:10px;background:var(--s2);display:flex;flex-direction:column;gap:3px;">';
    html += '<div class="prop-card-title" style="font-size:14px;font-weight:700;color:var(--text);line-height:1.3;overflow:hidden;text-overflow:ellipsis;">' + esc(title) + '</div>';
    if (locLine) html += '<div class="prop-card-sub" style="font-size:12px;color:var(--text2);">' + esc(locLine) + '</div>';
    if (r.agency) html += '<div class="prop-card-tenant" style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:0.4px;margin-top:3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + esc(r.agency) + '</div>';
    if (rentVal || metaParts.length) {
      var line = [rentVal].concat(metaParts).filter(Boolean).join(' | ');
      html += '<div class="prop-card-meta" style="font-size:11px;color:var(--text2);font-family:\'JetBrains Mono\',monospace;margin-top:4px;">' + esc(line) + '</div>';
    }
    html += '</div>';
  });
  if (pageRows.length === 0) {
    html += '<div style="grid-column:1/-1;text-align:center;padding:32px;color:var(--text3);">No properties to display</div>';
  }
  html += '</div>';

  // Pagination
  if (totalPages > 1) {
    html += '<div style="display:flex;justify-content:space-between;align-items:center;margin-top:12px;font-size:13px;color:var(--text2);">';
    html += '<span>Page ' + (govPropertiesPage + 1) + ' of ' + fmtN(totalPages) + ' (' + fmtN(totalCount) + ' total)</span>';
    html += '<div style="display:flex;gap:6px;">';
    html += '<button class="pill' + (govPropertiesPage === 0 ? '' : ' active') + '" data-gov-props-page="prev"' + (govPropertiesPage === 0 ? ' disabled style="opacity:0.4;pointer-events:none"' : '') + '>&laquo; Prev</button>';
    html += '<button class="pill' + (govPropertiesPage >= totalPages - 1 ? '' : ' active') + '" data-gov-props-page="next"' + (govPropertiesPage >= totalPages - 1 ? ' disabled style="opacity:0.4;pointer-events:none"' : '') + '>Next &raquo;</button>';
    html += '</div></div>';
  }
  html += '</div>';

  inner.innerHTML = html;

  // Row click → unified detail
  document.querySelectorAll('[data-gov-prop-idx]').forEach(function(card) {
    card.addEventListener('click', function() {
      var idx = parseInt(this.dataset.govPropIdx, 10);
      var row = pageRows[idx];
      if (row && row.property_id && typeof openUnifiedDetail === 'function') {
        openUnifiedDetail('gov', { property_id: Number(row.property_id) }, row);
      }
    });
  });
  // Pagination
  document.querySelectorAll('[data-gov-props-page]').forEach(function(btn) {
    btn.addEventListener('click', function() {
      if (this.dataset.govPropsPage === 'prev' && govPropertiesPage > 0) govPropertiesPage--;
      else if (this.dataset.govPropsPage === 'next') govPropertiesPage++;
      renderGovProperties();
    });
  });
  // Sort pills
  document.querySelectorAll('[data-gov-prop-sort-col]').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var col = this.dataset.govPropSortCol;
      if (govPropertiesSort.col === col) {
        govPropertiesSort.dir = govPropertiesSort.dir === 'asc' ? 'desc' : 'asc';
      } else {
        govPropertiesSort = { col: col, dir: (col === 'address' || col === 'city' || col === 'state' || col === 'agency') ? 'asc' : 'desc' };
      }
      govPropertiesPage = 0;
      renderGovProperties();
    });
  });
  // Search (debounced)
  var searchInput = document.getElementById('govPropsSearchInput');
  if (searchInput) {
    var debounce;
    searchInput.addEventListener('input', function(e) {
      clearTimeout(debounce);
      debounce = setTimeout(function() {
        govPropertiesSearch = e.target.value.trim();
        govPropertiesPage = 0;
        renderGovProperties();
        var restored = document.getElementById('govPropsSearchInput');
        if (restored) { restored.focus(); restored.setSelectionRange(restored.value.length, restored.value.length); }
      }, 400);
    });
  }
}

function renderGovTab() {
  const el = document.getElementById('bizPageInner');
  if (!el) return;

  let html = '';
  const isResearchTab = currentGovTab === 'research';

  switch (currentGovTab) {
    case 'overview':
      html = renderGovOverview();
      break;
    case 'search':
      html = renderGovSearch();
      break;
    case 'ownership':
      html = renderGovOwnership();
      break;
    case 'pipeline':
      html = renderGovPipeline();
      break;
    case 'listings':
      html = renderGovListings();
      break;
    case 'sales':
      renderGovSales(); // async — renders directly to DOM
      return;
    case 'leases':
      renderGovLeases(); // async — renders directly to DOM
      return;
    case 'loans':
      renderGovLoans(); // async — renders directly to DOM
      return;
    case 'players':
      html = renderGovPlayers();
      break;
    case 'properties':
      renderGovProperties(); // async — renders directly to DOM (UI Phase 3 INVENTORY tab)
      return;
    case 'activity':
      // UI Phase 3 — gov Activity promoted to a first-class RESEARCH tab.
      // Reuses the existing Government-Outreach block (renderGovOutreachInner).
      html = renderGovOutreachInner();
      break;
    case 'gsaintel':
      // UI Phase 3 — GSA / FRPP Intel promoted from an Overview section to a
      // standalone REFERENCE tab.
      html = renderGovGsaIntel();
      break;
    case 'research':
      html = renderGovResearch();
      break;
    case 'capital-markets':
      // Renders directly to DOM (async); see capital-markets.js
      if (typeof renderGovCapitalMarkets === 'function') {
        renderGovCapitalMarkets();
      } else {
        const elCm = document.getElementById('bizPageInner');
        if (elCm) elCm.innerHTML = '<div style="padding:24px;color:#666">capital-markets.js not loaded</div>';
      }
      return;
  }

  // Use smoothDOMUpdate for research tab to prevent flickering on record selection
  if (isResearchTab && typeof smoothDOMUpdate === 'function') {
    smoothDOMUpdate(el, html);
  } else {
    el.innerHTML = html;
  }

  // Attach autocomplete and event listeners
  setTimeout(() => {
    if (currentGovTab === 'research') {
      attachAutocomplete();
    }
    renderGovCharts();
  }, 100);
}


// ============================================================================
// DETAIL PANEL RENDERER
// ============================================================================

/**
 * Main detail panel renderer - handles all three source types
 * Called from index.html via showDetail(record, source)
 */
function renderGovDetailBody(record, source, tab) {
  switch (source) {
    case 'gov-ownership':
      return renderOwnershipDetail(record, tab || 'Overview');
    case 'gov-lead':
      return renderLeadDetail(record, tab || 'Overview');
    case 'gov-listing':
      return renderListingDetail(record, tab || 'Overview');
    default:
      return '<div class="detail-empty">Unknown detail source</div>';
  }
}

// ============================================================================
// GOV-OWNERSHIP DETAIL PANEL
// ============================================================================

function renderOwnershipDetail(record, tab) {
  let html = '';
  
  switch (tab) {
    case 'Overview':
      html = renderOwnershipOverview(record);
      break;
    case 'Lease':
      html = renderOwnershipLease(record);
      break;
    case 'Ownership':
      html = renderOwnershipOwnership(record);
      break;
    case 'Activity':
      html = renderOwnershipActivity(record);
      break;
  }
  
  return html;
}

function renderOwnershipOverview(record) {
  const value = fmt(record.estimated_value);
  const salePrice = fmt(record.sale_price);
  const capRate = record.cap_rate ? pct(record.cap_rate / 100) : '—';
  const sqft = record.square_feet ? fmtN(record.square_feet) : '—';
  const rent = fmt(record.annual_rent);
  
  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">Key Information</div>';
  html += '<div class="detail-grid">';
  
  html += createDetailRow('Lease Number', esc(record.lease_number || '—'));
  if (record.location_code) html += createDetailRow('Location Code', esc(record.location_code));
  html += createDetailRow('Address', esc(norm(record.address) || '—'));
  html += createDetailRow('City / State',
    esc((norm(record.city) || '') + (record.state ? ', ' + record.state : '') || '—'));
  html += createDetailRow('Estimated Value', `<span class="detail-val money">${value}</span>`);
  html += createDetailRow('Sale Price', `<span class="detail-val money">${salePrice}</span>`);
  html += createDetailRow('Cap Rate', capRate);
  html += createDetailRow('Square Feet', sqft);
  html += createDetailRow('Annual Rent', `<span class="detail-val money">${rent}</span>`);
  html += createDetailRow('Transfer Date', esc(record.transfer_date || '—'));
  html += createDetailRow('Research Status',
    `<span class="detail-badge">${esc(cleanLabel(record.research_status || 'pending'))}</span>`);
  
  html += '</div>';
  html += '</div>';
  
  html += '<div class="detail-actions" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;">';
  // Edit Status — inline dropdown
  html += '<div style="display:flex;gap:6px;align-items:center;">';
  html += '<select id="govOwnerStatus" style="font-size:12px;padding:5px 8px;border:1px solid var(--border);border-radius:4px;background:var(--s2);color:var(--text);">';
  ['pending', 'researching', 'verified', 'needs_review', 'escalated', 'dismissed'].forEach(s => {
    const sel = (record.research_status || 'pending') === s ? ' selected' : '';
    html += '<option value="' + s + '"' + sel + '>' + cleanLabel(s) + '</option>';
  });
  html += '</select>';
  html += '<button class="gov-btn" onclick="govUpdateOwnershipStatus(' + (record.id || record.ownership_id || 'null') + ')">Save Status</button>';
  html += '</div>';
  // View on Map
  const mapQ = encodeURIComponent((record.address || '') + ' ' + (record.city || '') + ' ' + (record.state || ''));
  html += '<button class="gov-btn" onclick="window.open(\'https://www.google.com/maps/search/' + mapQ + '\',\'_blank\')">View on Map</button>';
  html += '</div>';

  // R50 — geographic BD section (nearby owner cohort / nearby sales / geo
  // competitors). Filled async after render (the heavy haversine scan stays in
  // the gov DB). Additive; soft-fails to nothing.
  const _geoPid = record.property_id != null ? record.property_id
    : (record.matched_property_id != null ? record.matched_property_id : null);
  if (_geoPid != null && typeof _udLoadPropertyGeo === 'function') {
    html += '<div id="govGeoSection" data-pid="' + esc(String(_geoPid)) + '" style="margin-top:8px"></div>';
    setTimeout(function () { try { _govFillGeoSection(_geoPid); } catch (_e) { /* additive */ } }, 0);
  }

  return html;
}

// R50 — async filler for the gov detail geographic section. Renders the shared
// nearby owners + nearby sales tables (detail.js _udRenderGeoSection) plus a
// gov-specific nearest-competitors table (same_agency = concentration peer).
async function _govFillGeoSection(pid) {
  let el = document.getElementById('govGeoSection');
  if (!el || String(el.getAttribute('data-pid')) !== String(pid)) return;
  let geo = null;
  try { geo = await _udLoadPropertyGeo('gov', pid); } catch (_e) { geo = null; }
  el = document.getElementById('govGeoSection');
  if (!el || String(el.getAttribute('data-pid')) !== String(pid)) return; // detail changed while loading
  let html = '';
  try { if (typeof _udRenderGeoSection === 'function') html += _udRenderGeoSection(geo, 'gov'); } catch (_e) { /* additive */ }

  const comps = (geo && geo.subject_geocoded && Array.isArray(geo.nearby_competitors)) ? geo.nearby_competitors : [];
  if (comps.length > 0) {
    const sameAg = comps.filter(c => c.same_agency).length;
    html += '<div class="detail-section">';
    html += '<div class="detail-section-title">Competitive Landscape — nearest gov-leased within ' + ((geo.radius && geo.radius.competitors) || 10) + ' mi</div>';
    html += '<div style="font-size:12px;color:var(--text3);margin-bottom:8px">' + comps.length + ' nearest gov-leased assets · ' + sameAg + ' same agency (concentration / replacement-risk)</div>';
    html += '<div style="overflow-x:auto;max-height:300px;overflow-y:auto"><table style="width:100%;border-collapse:collapse;font-size:11px">';
    html += '<thead style="position:sticky;top:0;background:var(--bg)"><tr style="border-bottom:2px solid var(--s3)">';
    html += '<th style="text-align:left;padding:4px 8px;color:var(--text3);font-weight:700">Address</th>';
    html += '<th style="text-align:left;padding:4px 8px;color:var(--text3);font-weight:700">City</th>';
    html += '<th style="text-align:right;padding:4px 8px;color:var(--text3);font-weight:700">Dist</th>';
    html += '<th style="text-align:left;padding:4px 8px;color:var(--text3);font-weight:700">Agency</th>';
    html += '</tr></thead><tbody>';
    comps.forEach(c => {
      html += '<tr style="border-bottom:1px solid var(--s3)">';
      html += '<td style="padding:4px 8px;white-space:nowrap">' + esc(c.address || '—') + '</td>';
      html += '<td style="padding:4px 8px">' + esc((c.city || '') + (c.state ? ', ' + c.state : '')) + '</td>';
      html += '<td style="padding:4px 8px;text-align:right">' + (c.distance_miles != null ? Number(c.distance_miles).toFixed(2) + ' mi' : '—') + '</td>';
      html += '<td style="padding:4px 8px">' + esc(c.agency || '—') + (c.same_agency ? ' <span style="color:var(--orange);font-size:9px">●</span>' : '') + '</td>';
      html += '</tr>';
    });
    html += '</tbody></table></div></div>';
  }

  const el2 = document.getElementById('govGeoSection');
  if (el2 && String(el2.getAttribute('data-pid')) === String(pid)) el2.innerHTML = html;
}

function renderOwnershipLease(record) {
  // Find matching GSA snapshot by lease_number
  const snapshot = govData.gsaSnapshots && govData.gsaSnapshots.find(
    s => s.lease_number === record.lease_number
  );
  
  if (!snapshot) {
    return '<div class="detail-empty">No lease data available</div>';
  }
  
  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">Lease Details</div>';
  html += '<div class="detail-grid">';
  
  html += createDetailRow('Lease Effective', esc(snapshot.lease_effective || '—'));
  html += createDetailRow('Lease Expiration', esc(snapshot.lease_expiration || '—'));
  html += createDetailRow('RSF (Lease)', snapshot.lease_rsf ? fmtN(snapshot.lease_rsf) : '—');
  html += createDetailRow('Lessor Name', esc(norm(snapshot.lessor_name) || '—'));
  html += createDetailRow('Field Office', esc(snapshot.field_office_name || '—'));
  html += createDetailRow('Annual Rent', fmt(snapshot.annual_rent));
  
  html += '</div>';
  html += '</div>';
  
  return html;
}

function renderOwnershipOwnership(record) {
  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">Ownership Transfer</div>';
  html += '<div class="detail-grid">';
  
  html += createDetailRow('Prior Owner', esc(record.prior_owner || '—'));
  html += createDetailRow('New Owner', esc(record.new_owner || '—'));
  html += createDetailRow('Transfer Date', esc(record.transfer_date || '—'));
  
  html += '</div>';
  html += '</div>';
  
  html += '<div class="detail-section">';
  html += '<div class="detail-section-title">Legal Ownership</div>';
  html += '<div class="detail-grid">';
  
  html += createDetailRow('Recorded Owner', esc(record.recorded_owner_name || '—'));
  html += createDetailRow('True Owner', esc(record.true_owner_name || '—'));
  html += createDetailRow('State of Incorporation', esc(record.state_of_incorporation || '—'));
  
  if (record.principal_names) {
    html += createDetailRow('Principals', 
      `<span class="detail-val">${esc(record.principal_names)}</span>`);
  }
  
  html += '</div>';
  html += '</div>';
  
  return html;
}

function renderOwnershipActivity(record) {
  // Filter gsaEvents by lease_number
  const events = govData.gsaEvents && govData.gsaEvents.filter(
    e => e.lease_number === record.lease_number
  );
  
  if (!events || events.length === 0) {
    return '<div class="detail-empty">No activity recorded</div>';
  }
  
  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">Activity Timeline</div>';
  html += '<div class="detail-timeline">';
  
  events.forEach((event, idx) => {
    const statusClass = event.event_type === 'renewal' ? 'green' : 
                       event.event_type === 'termination' ? 'red' : 'yellow';
    
    html += `<div class="detail-timeline-item ${statusClass}">`;
    html += `<div class="detail-card-date">${esc(event.event_date || '—')}</div>`;
    html += `<div class="detail-card-title">${esc(event.event_type || 'Event')}</div>`;
    html += `<div class="detail-card-body">`;
    html += `<strong>${esc(event.lessor_name || '—')}</strong><br>`;
    html += `Annual Rent: ${fmt(event.annual_rent)}<br>`;
    html += `RSF: ${event.lease_rsf ? fmtN(event.lease_rsf) : '—'}`;
    if (event.changed_fields) {
      html += `<br><span class="detail-val muted">Changed: ${esc(event.changed_fields)}</span>`;
    }
    html += `</div>`;
    html += `</div>`;
  });
  
  html += '</div>';
  html += renderGovLiveIngestOutcomeTimeline(record);
  html += '</div>';
  
  return html;
}

// ============================================================================
// GOV-LEAD DETAIL PANEL
// ============================================================================

function renderLeadDetail(record, tab) {
  let html = '';
  
  switch (tab) {
    case 'Overview':
      html = renderLeadOverview(record);
      break;
    case 'Property':
      html = renderLeadProperty(record);
      break;
    case 'Pipeline':
      html = renderLeadPipeline(record);
      break;
    case 'Contacts':
      html = renderLeadContacts(record);
      break;
    case 'Activity':
      html = renderLeadActivity(record);
      break;
  }
  
  return html;
}

function renderLeadOverview(record) {
  const tempColor = record.lead_temperature === 'Hot' ? 'red' : 
                    record.lead_temperature === 'Warm' ? 'yellow' : 'cyan';
  
  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">Priority & Temperature</div>';
  html += '<div class="detail-grid">';
  
  html += createDetailRow('Priority Score', 
    `<span class="detail-badge" style="background: ${tempColor === 'red' ? '#f87171' : tempColor === 'yellow' ? '#fbbf24' : '#22d3ee'}">${record.priority_score || '—'}</span>`);
  html += createDetailRow('Lead Temperature', 
    `<span class="detail-badge">${esc(record.lead_temperature || 'Cold')}</span>`);
  html += createDetailRow('Lead Source', esc(cleanLabel(record.lead_source || '—')));
  
  html += '</div>';
  html += '</div>';
  
  html += '<div class="detail-section">';
  html += '<div class="detail-section-title">Key Metrics</div>';
  html += '<div class="detail-grid">';
  
  const value = fmt(record.estimated_value);
  const rent = fmt(record.annual_rent);
  const sqft = record.square_feet ? fmtN(record.square_feet) : '—';
  
  html += createDetailRow('Estimated Value', `<span class="detail-val money">${value}</span>`);
  html += createDetailRow('Annual Rent', `<span class="detail-val money">${rent}</span>`);
  html += createDetailRow('Square Feet', sqft);
  html += createDetailRow('Year Built', record.year_built || '—');
  html += createDetailRow('Firm Term Remaining', 
    record.firm_term_remaining ? fmtN(record.firm_term_remaining) + ' months' : '—');
  
  html += '</div>';
  html += '</div>';
  
  return html;
}

function renderLeadProperty(record) {
  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">Property Information</div>';
  html += '<div class="detail-grid">';
  
  html += createDetailRow('Address', esc(norm(record.address) || '—'));
  html += createDetailRow('City / State',
    esc((norm(record.city) || '') + (record.state ? ', ' + record.state : '') || '—'));
  if (record.location_code) html += createDetailRow('Location Code', esc(record.location_code));
  html += createDetailRow('Agency', esc(norm(record.agency_full_name) || '—'));
  html += createDetailRow('Tenant', esc(norm(record.tenant_agency) || '—'));
  html += createDetailRow('Lease Effective', esc(record.lease_effective || '—'));
  html += createDetailRow('Lease Expiration', esc(record.lease_expiration || '—'));
  html += createDetailRow('RBA', record.rba || '—');
  html += createDetailRow('Land Acres', record.land_acres ? fmtN(record.land_acres) : '—');
  html += createDetailRow('Year Renovated', record.year_renovated || '—');
  
  html += '</div>';
  html += '</div>';
  
  return html;
}

function renderLeadPipeline(record) {
  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">CRM Pipeline</div>';
  
  html += '<div class="detail-form">';
  
  html += '<div class="detail-row">';
  html += '<label class="detail-lbl">Pipeline Status</label>';
  html += '<select id="govDetailPipeline" class="detail-val">';
  html += '<option value="new" ' + (record.pipeline_status === 'new' ? 'selected' : '') + '>New</option>';
  html += '<option value="contacted" ' + (record.pipeline_status === 'contacted' ? 'selected' : '') + '>Contacted</option>';
  html += '<option value="qualified" ' + (record.pipeline_status === 'qualified' ? 'selected' : '') + '>Qualified</option>';
  html += '<option value="proposal" ' + (record.pipeline_status === 'proposal' ? 'selected' : '') + '>Proposal</option>';
  html += '<option value="closed-won" ' + (record.pipeline_status === 'closed-won' ? 'selected' : '') + '>Closed Won</option>';
  html += '<option value="closed-lost" ' + (record.pipeline_status === 'closed-lost' ? 'selected' : '') + '>Closed Lost</option>';
  html += '</select>';
  html += '</div>';
  
  html += '<div class="detail-row">';
  html += '<label class="detail-lbl">Research Status</label>';
  html += '<select id="govDetailResearch" class="detail-val">';
  html += '<option value="pending" ' + (record.research_status === 'pending' ? 'selected' : '') + '>Pending</option>';
  html += '<option value="in-progress" ' + (record.research_status === 'in-progress' ? 'selected' : '') + '>In Progress</option>';
  html += '<option value="complete" ' + (record.research_status === 'complete' ? 'selected' : '') + '>Complete</option>';
  html += '<option value="archived" ' + (record.research_status === 'archived' ? 'selected' : '') + '>Archived</option>';
  html += '</select>';
  html += '</div>';
  
  if (record.sf_sync_status) {
    html += '<div class="detail-row">';
    html += '<label class="detail-lbl">Salesforce Sync</label>';
    html += '<span class="detail-badge">' + esc(record.sf_sync_status) + '</span>';
    html += '</div>';
  }
  
  html += '<div class="detail-row">';
  html += '<label class="detail-lbl">Research Notes</label>';
  html += '<textarea id="govDetailNotes" class="detail-val" style="min-height: 100px; font-family: monospace; font-size: 12px; padding: 8px; border: 1px solid var(--border); border-radius: 4px; background: var(--s2); color: var(--text);">' + esc(record.research_notes || '') + '</textarea>';
  html += '</div>';
  
  html += '<div class="detail-row" style="margin-top: 16px;">';
  html += `<button class="act-btn primary" onclick="saveGovDetailLead(decodeURIComponent('${encodeURIComponent(record.lead_id)}'))">Save Changes</button>`;
  html += '</div>';
  
  html += '</div>';
  html += '</div>';
  
  return html;
}

function renderLeadContacts(record) {
  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">Contact Information</div>';
  html += '<div class="detail-grid">';
  
  html += createDetailRow('Name', esc(record.contact_name || '—'));
  html += createDetailRow('Title', esc(record.contact_title || '—'));
  html += createDetailRow('Company', esc(record.contact_company || '—'));
  html += createDetailRow('Phone', esc(record.contact_phone || '—'));
  html += createDetailRow('Email', esc(record.contact_email || '—'));
  
  if (record.phone_2) {
    html += createDetailRow('Phone 2', esc(record.phone_2));
  }
  
  if (record.mailing_address) {
    html += createDetailRow('Mailing Address', esc(record.mailing_address));
    if (record.mailing_address_2) {
      html += createDetailRow('Address 2', esc(record.mailing_address_2));
    }
  }
  
  html += '</div>';
  html += '</div>';
  
  html += '<div class="detail-actions" style="display:flex;gap:8px;margin-top:12px;">';
  html += '<button class="gov-btn" onclick="govLogCall(' + (record.id || 'null') + ')">Log Call</button>';
  html += '<button class="gov-btn" onclick="govSendEmail(' + safeJSON(record) + ')">Send Email</button>';
  html += '</div>';

  return html;
}

function renderLeadActivity(record) {
  if (!record) return '<div class="detail-empty">No activity recorded</div>';
  // Filter gsaEvents by lease_number
  const events = govData.gsaEvents && govData.gsaEvents.filter(
    e => e.lease_number === record.lease_number
  );
  
  if (!events || events.length === 0) {
    return '<div class="detail-empty">No activity recorded</div>';
  }
  
  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">Activity Timeline</div>';
  html += '<div class="detail-timeline">';
  
  events.forEach((event, idx) => {
    const statusClass = event.event_type === 'renewal' ? 'green' : 
                       event.event_type === 'termination' ? 'red' : 'yellow';
    
    html += `<div class="detail-timeline-item ${statusClass}">`;
    html += `<div class="detail-card-date">${esc(event.event_date || '—')}</div>`;
    html += `<div class="detail-card-title">${esc(event.event_type || 'Event')}</div>`;
    html += `<div class="detail-card-body">`;
    html += `<strong>${esc(event.lessor_name || '—')}</strong><br>`;
    html += `Annual Rent: ${fmt(event.annual_rent)}<br>`;
    html += `RSF: ${event.lease_rsf ? fmtN(event.lease_rsf) : '—'}`;
    if (event.changed_fields) {
      html += `<br><span class="detail-val muted">Changed: ${esc(event.changed_fields)}</span>`;
    }
    html += `</div>`;
    html += `</div>`;
  });
  
  html += '</div>';
  html += renderGovLiveIngestOutcomeTimeline(record);
  html += '</div>';
  
  return html;
}

function renderGovLiveIngestOutcomeTimeline(record) {
  const propertyId = record?.property_id || record?.matched_property_id || null;
  if (!propertyId) return '';
  const outcomes = (govData.researchOutcomes || []).filter((row) =>
    row
    && row.queue_type === 'live_ingest'
    && String(row.selected_property_id || '') === String(propertyId)
  );
  if (!outcomes.length) return '';
  let html = '<div class="detail-section" style="margin-top:12px">';
  html += '<div class="detail-section-title">Live Ingest Outcomes</div>';
  html += '<div class="detail-timeline">';
  outcomes.slice().reverse().slice(0, 12).forEach((outcome) => {
    const meta = window.parseLiveIngestOutcomeNotes ? window.parseLiveIngestOutcomeNotes(outcome.notes) : null;
    html += '<div class="detail-timeline-item">';
    html += '<div style="display:flex;justify-content:space-between;margin-bottom:8px">';
    html += '<div style="font-weight:600;">' + esc(outcome.queue_type || 'live_ingest') + '</div>';
    html += '<div style="color:var(--text2);font-size:12px;">' + fmt(outcome.assigned_at || outcome.created_at) + '</div>';
    html += '</div>';
    html += '<div style="display:flex;justify-content:space-between;align-items:center;">';
    html += '<div style="color:var(--text2);">' + esc(outcome.status || 'unknown') + '</div>';
    if (outcome.assigned_to) {
      html += '<div style="color:var(--text2);font-size:12px;">by ' + esc(outcome.assigned_to) + '</div>';
    }
    html += '</div>';
    if (meta && window.renderLiveIngestOutcomeProvenance) {
      html += window.renderLiveIngestOutcomeProvenance(meta, { limit: 4 });
    } else if (outcome.notes) {
      html += '<div style="margin-top:8px;color:var(--text2);font-size:12px;white-space:pre-wrap">' + esc(outcome.notes) + '</div>';
    }
    html += '</div>';
  });
  html += '</div>';
  html += '</div>';
  return html;
}

// ============================================================================
// GOV-LISTING DETAIL PANEL
// ============================================================================

function renderListingDetail(record, tab) {
  let html = '';
  
  switch (tab) {
    case 'Overview':
      html = renderListingOverview(record);
      break;
    case 'Property':
      html = renderListingProperty(record);
      break;
    case 'Market':
      html = renderListingMarket(record);
      break;
    case 'Activity':
      html = renderListingActivity(record);
      break;
  }
  
  return html;
}

function renderListingOverview(record) {
  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">Listing Details</div>';
  html += '<div class="detail-grid">';
  
  const price = fmt(record.asking_price);
  const capRate = record.asking_cap_rate ? pct(record.asking_cap_rate / 100) : '—';
  
  html += createDetailRow('Asking Price', `<span class="detail-val money">${price}</span>`);
  html += createDetailRow('Asking Cap Rate', capRate);
  html += createDetailRow('Listing Source', esc(cleanLabel(record.listing_source || '—')));
  html += createDetailRow('Listing Status',
    `<span class="detail-badge">${esc(cleanLabel(record.listing_status || 'active'))}</span>`);
  html += createDetailRow('Days on Market', record.days_on_market || '—');
  html += createDetailRow('URL Status', esc(cleanLabel(record.url_status || '—')));
  html += createDetailRow('Tenant Agency', esc(norm(record.tenant_agency) || '—'));
  
  html += '</div>';
  html += '</div>';
  
  return html;
}

function renderListingProperty(record) {
  // Find matching FRPP record by city
  const frpp = govData.frppRecords && govData.frppRecords.find(
    f => f.city_name === record.city && f.state_name === record.state
  );
  
  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">Property Information</div>';
  html += '<div class="detail-grid">';
  
  html += createDetailRow('Address', esc(record.address || '—'));
  html += createDetailRow('City / State', 
    esc((record.city || '') + (record.state ? ', ' + record.state : '') || '—'));
  
  if (frpp) {
    html += createDetailRow('Property Type', esc(frpp.property_type || '—'));
    html += createDetailRow('Square Feet', frpp.square_feet ? fmtN(frpp.square_feet) : '—');
    html += createDetailRow('Annual Rent', fmt(frpp.annual_rent_to_lessor));
    html += createDetailRow('Lease Expiration', esc(frpp.lease_expiration_date || '—'));
  }
  
  html += '</div>';
  html += '</div>';
  
  return html;
}

function renderListingMarket(record) {
  // Find comparable sales/ownership transfers in same city/state
  const comps = govData.ownership && govData.ownership.filter(
    o => o.city === record.city && o.state === record.state && o.sale_price
  );
  
  if (!comps || comps.length === 0) {
    return '<div class="detail-empty">No comparable sales found in this market</div>';
  }
  
  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">Comparable Sales</div>';
  
  html += '<div style="overflow-x: auto;">';
  html += '<table style="width: 100%; font-size: 12px; border-collapse: collapse;">';
  html += '<thead><tr style="border-bottom: 2px solid var(--border);">';
  html += '<th style="text-align: left; padding: 8px;">Address</th>';
  html += '<th style="text-align: right; padding: 8px;">Sale Price</th>';
  html += '<th style="text-align: right; padding: 8px;">Cap Rate</th>';
  html += '<th style="text-align: right; padding: 8px;">Sq Ft</th>';
  html += '<th style="text-align: center; padding: 8px;">Transfer Date</th>';
  html += '</tr></thead>';
  html += '<tbody>';
  
  comps.slice(0, 10).forEach(comp => {
    const price = fmt(comp.sale_price);
    const capRate = comp.cap_rate ? pct(comp.cap_rate / 100) : '—';
    const sqft = comp.square_feet ? fmtN(comp.square_feet) : '—';
    
    html += `<tr class="clickable-row" style="border-bottom: 1px solid var(--border);cursor:pointer" onclick='showDetail(${safeJSON(comp)}, "gov-ownership")'>`;
    html += `<td style="padding: 8px;">${esc(comp.address || '—')}</td>`;
    html += `<td style="text-align: right; padding: 8px; font-weight: 600;">${price}</td>`;
    html += `<td style="text-align: right; padding: 8px;">${capRate}</td>`;
    html += `<td style="text-align: right; padding: 8px;">${sqft}</td>`;
    html += `<td style="text-align: center; padding: 8px;">${esc(comp.transfer_date || '—')}</td>`;
    html += '</tr>';
  });
  
  html += '</tbody>';
  html += '</table>';
  html += '</div>';
  html += '</div>';
  
  return html;
}

function renderListingActivity(record) {
  if (!record) return '<div class="detail-empty">No activity data available</div>';

  // Try to find GSA events by lease_number or address match
  let events = [];
  if (record.lease_number && govData.gsaEvents) {
    events = govData.gsaEvents.filter(e => e.lease_number === record.lease_number);
  }
  if (events.length === 0 && record.address && govData.gsaEvents) {
    const addr = (record.address || '').toLowerCase().trim();
    events = govData.gsaEvents.filter(e => (e.address || '').toLowerCase().trim() === addr);
  }

  // Also pull research outcomes if available
  let outcomes = [];
  if (record.property_id && govData.researchOutcomes) {
    outcomes = govData.researchOutcomes.filter(o => String(o.property_id) === String(record.property_id));
  }

  if (events.length === 0 && outcomes.length === 0) {
    return '<div class="detail-empty">No activity recorded for this listing</div>';
  }

  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">Activity Timeline</div>';
  html += '<div class="detail-timeline">';

  // GSA lease events
  events.sort((a, b) => (b.event_date || '').localeCompare(a.event_date || '')).forEach(event => {
    const statusClass = event.event_type === 'renewal' ? 'green' :
                       event.event_type === 'termination' ? 'red' : 'yellow';
    html += '<div class="detail-timeline-item ' + statusClass + '">';
    html += '<div class="detail-card-date">' + esc(event.event_date || '—') + '</div>';
    html += '<div class="detail-card-title">' + esc(cleanLabel(event.event_type || 'Event')) + '</div>';
    html += '<div class="detail-card-body">';
    if (event.lessor_name) html += '<strong>' + esc(event.lessor_name) + '</strong><br>';
    if (event.annual_rent) html += 'Annual Rent: ' + fmt(event.annual_rent) + '<br>';
    if (event.lease_rsf) html += 'RSF: ' + fmtN(event.lease_rsf);
    if (event.changed_fields) html += '<br><span class="detail-val muted">Changed: ' + esc(event.changed_fields) + '</span>';
    html += '</div></div>';
  });

  // Research outcomes
  outcomes.sort((a, b) => (b.created_at || '').localeCompare(a.created_at || '')).forEach(o => {
    html += '<div class="detail-timeline-item blue">';
    html += '<div class="detail-card-date">' + esc((o.created_at || '').substring(0, 10)) + '</div>';
    html += '<div class="detail-card-title">Research: ' + esc(cleanLabel(o.outcome || 'completed')) + '</div>';
    if (o.notes) html += '<div class="detail-card-body">' + esc(o.notes) + '</div>';
    html += '</div>';
  });

  html += '</div></div>';
  return html;
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

function createDetailRow(label, value) {
  return `<div class="detail-row">
    <span class="detail-lbl">${esc(label)}</span>
    <span class="detail-val">${value}</span>
  </div>`;
}

/**
 * Save changes to a gov lead record
 * Updates pipeline_status, research_status, and research_notes via Gov write service
 */
function saveGovDetailLead(leadId) {
  const pipelineStatus = document.getElementById('govDetailPipeline')?.value;
  const researchStatus = document.getElementById('govDetailResearch')?.value;
  const researchNotes = document.getElementById('govDetailNotes')?.value;

  if (!pipelineStatus || !researchStatus) {
    showToast('Please select pipeline and research status');
    return;
  }

  const _saveBtn = document.querySelector('[onclick*="saveGovDetailLead"]');
  if (_saveBtn) { _saveBtn.disabled = true; _saveBtn.dataset.origText = _saveBtn.textContent; _saveBtn.textContent = 'Saving…'; _saveBtn.style.opacity = '0.6'; }

  // Use Gov write service instead of direct prospect_leads PATCH
  govWriteService('lead-research', {
    lead_id: leadId,
    pipeline_status: pipelineStatus,
    research_status: researchStatus,
    research_notes: researchNotes || null
  })
    .then((writeResult) => {
      showToast('Lead updated successfully', 'success');
      // Bridge with gov change metadata
      canonicalBridge('complete_research', {
        domain: 'government',
        research_type: 'ownership',
        external_id: String(leadId),
        source_system: 'gov',
        outcome: researchStatus === 'complete' ? 'completed' : researchStatus,
        notes: researchNotes,
        gov_change_event_id: writeResult?.change_event_id || null,
        gov_correlation_id: writeResult?.correlation_id || null,
        source_record_id: leadId,
        source_table: 'prospect_leads'
      });
    })
    .catch(err => {
      console.error('Error saving lead:', err);
      showToast('Error updating lead: ' + err.message, 'error');
    })
    .finally(() => {
      if (_saveBtn) { _saveBtn.disabled = false; _saveBtn.textContent = _saveBtn.dataset.origText || 'Save'; _saveBtn.style.opacity = ''; }
    });
}

// ============================================================================
// GOVERNMENT SALES (Comps + Available)
// ============================================================================

let govSalesView = 'comps'; // 'comps' | 'available'
let govSalesComps = null;   // lazy-loaded from v_sales_comps
let govAvailListings = null; // lazy-loaded from v_available_listings
let govSalesLoading = false;
let govSalesSearch = '';
let govSalesPage = 0;
let govSalesSort = { col: null, dir: 'desc' };
let govFilteredSalesData = [];
const GOV_SALES_PAGE_SIZE = 50;

// Round 76cx Phase 2 (gov parity): listing verification dashboard digest.
// Single-row view; renders alongside the Available-listings metrics so the
// user sees due/overdue counts at a glance. Mirrors the dia equivalent in
// dialysis.js — same view shape, same card layout.
let govVerificationSummary = null;
let govVerificationSummaryLoading = false;
// Round 76et-F: drill-down panel for recent gov verification rows. Same
// shape as the dia equivalent in dialysis.js.
let govRecentVerifications = null;
let govRecentVerificationsLoading = false;
let govRecentVerificationsFilter = 'all';

async function loadGovVerificationSummary() {
  if (govVerificationSummaryLoading) return;
  govVerificationSummaryLoading = true;
  try {
    // getRows() normalizes diaQuery/govQuery's divergent return shapes
    // (see app.js).
    const rows = getRows(await govQuery('v_listing_verification_summary', '*', { limit: 1 }));
    govVerificationSummary = rows[0] || null;
  } catch (e) {
    console.error('loadGovVerificationSummary error:', e);
    govVerificationSummary = null;
  }
  govVerificationSummaryLoading = false;
  // Re-render the gov sales view if we're still on it. This is a fire-and-
  // forget refresh; if the user already navigated away, we just leave the
  // data in memory for next visit.
  if (govSalesView === 'available' && document.getElementById('bizPageInner')) {
    renderGovSales();
  }
}

// Compact verification status card. Color reflects urgency:
//   blue   — nothing overdue
//   yellow — some listings due
//   red    — broken URLs or 90d+ overdue
function renderGovListingVerificationCard() {
  if (!govVerificationSummary) {
    return metricHTML('Verification Status', '…', 'Loading verification digest', 'blue');
  }
  const s = govVerificationSummary;
  const due       = Number(s.due_for_verification) || 0;
  const overdue30 = Number(s.overdue_30d) || 0;
  const overdue90 = Number(s.overdue_90d) || 0;
  const broken    = Number(s.broken_url_count) || 0;
  const recent    = Number(s.verifications_last_7d) || 0;
  const changes7d = Number(s.recent_status_changes_7d) || 0;
  // Round 76et-E breakout. Falls back to the monolithic 'recent' count
  // when running against a database that hasn't applied the migration yet.
  const evidence7d = (s.evidence_verifications_7d != null) ? Number(s.evidence_verifications_7d) : null;
  const cronOnly7d = (s.cron_timer_advances_7d   != null) ? Number(s.cron_timer_advances_7d)   : null;
  const checks7dPart = (evidence7d != null && cronOnly7d != null)
    ? evidence7d + ' evidence/7d · ' + cronOnly7d + ' cron-only/7d'
    : recent + ' checks/7d';

  let color = 'blue';
  if (overdue90 > 0 || broken > 0) color = 'red';
  else if (due > 0 || overdue30 > 0) color = 'yellow';

  const sub =
    overdue30 + ' 30d-overdue · ' +
    overdue90 + ' 90d · ' +
    broken    + ' broken-url · ' +
    checks7dPart + ' · ' +
    changes7d + ' status-changes/7d';

  return metricHTML('Verification Status', fmtN(due), sub, color);
}

// Round 76et-F: drill-down for the gov verification summary card. Mirror
// of the dia equivalent in dialysis.js. Pulls last ~50 rows from
// listing_verification_history (7d window, ordered desc), renders a
// filterable list (All | Evidence | Cron-only) below the metrics row.
async function loadRecentGovVerifications() {
  if (govRecentVerificationsLoading) return;
  govRecentVerificationsLoading = true;
  try {
    const sevenDaysAgo = new Date(Date.now() - 7 * 86400000).toISOString();
    // getRows() normalizes diaQuery/govQuery's divergent return shapes
    // (see app.js).
    govRecentVerifications = getRows(await govQuery(
      'listing_verification_history',
      'id,listing_id,verified_at,method,check_result,notes,source_url',
      { filter: 'verified_at=gte.' + sevenDaysAgo, order: 'verified_at.desc', limit: 50 }
    ));
  } catch (e) {
    console.error('loadRecentGovVerifications error:', e);
    govRecentVerifications = [];
  }
  govRecentVerificationsLoading = false;
  if (govSalesView === 'available' && document.getElementById('bizPageInner')) {
    renderGovSales();
  }
}

window.setGovRecentVerificationsFilter = function (f) {
  if (f !== 'all' && f !== 'evidence' && f !== 'cron') return;
  govRecentVerificationsFilter = f;
  if (typeof renderGovSales === 'function') renderGovSales();
};

function _govFmtTimeAgo(iso) {
  if (!iso) return '';
  const ms = Date.now() - Date.parse(iso);
  if (!Number.isFinite(ms) || ms < 0) return '';
  const m = Math.floor(ms / 60000);
  if (m < 1)  return 'just now';
  if (m < 60) return m + 'm ago';
  const h = Math.floor(m / 60);
  if (h < 24) return h + 'h ago';
  const d = Math.floor(h / 24);
  return d + 'd ago';
}

function renderRecentGovVerificationsPanel() {
  if (govRecentVerifications === null) {
    return '<div style="margin-top:14px;padding:14px 16px;border:1px solid var(--border);border-radius:8px;color:var(--text3);font-size:11px">Loading recent verifications…</div>';
  }
  const all = govRecentVerifications;
  const filter = govRecentVerificationsFilter;
  const isCron = (r) => r.method === 'auto_scrape' && r.check_result === 'inferred_active';
  const evidenceLen = all.filter(r => !isCron(r)).length;
  const cronLen     = all.filter(isCron).length;
  const filtered = filter === 'all'      ? all
                 : filter === 'cron'     ? all.filter(isCron)
                 :                          all.filter(r => !isCron(r));

  let h = '<div style="margin-top:14px;padding:14px 16px;border:1px solid var(--border);border-radius:8px;background:var(--s2)">';
  h += '<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap">';
  h += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3)">Recent Verifications (7d)</div>';
  h += '<div style="flex:1"></div>';
  h += '<button class="ops-filter ' + (filter === 'all'      ? 'active' : '') + '" onclick="setGovRecentVerificationsFilter(\'all\')">All ('      + all.length + ')</button>';
  h += '<button class="ops-filter ' + (filter === 'evidence' ? 'active' : '') + '" onclick="setGovRecentVerificationsFilter(\'evidence\')">Evidence (' + evidenceLen + ')</button>';
  h += '<button class="ops-filter ' + (filter === 'cron'     ? 'active' : '') + '" onclick="setGovRecentVerificationsFilter(\'cron\')">Cron-only ('  + cronLen + ')</button>';
  h += '</div>';

  if (filtered.length === 0) {
    h += '<div style="color:var(--text3);font-size:12px;padding:8px 0">No rows for this filter.</div>';
  } else {
    h += '<div style="max-height:280px;overflow-y:auto">';
    for (const r of filtered.slice(0, 50)) {
      const ago = _govFmtTimeAgo(r.verified_at);
      const noteSnip = String(r.notes || '').substring(0, 80);
      const url = r.source_url ? '<a href="' + esc(r.source_url) + '" target="_blank" rel="noopener" style="color:var(--accent);text-decoration:none">↗</a>' : '';
      h += '<div style="display:grid;grid-template-columns:80px 110px 130px 220px 1fr 20px;gap:10px;padding:6px 0;border-bottom:1px solid var(--border);font-size:12px;align-items:center">';
      h += '<span style="color:var(--text3)">' + esc(ago) + '</span>';
      h += '<span class="q-badge">' + esc(String(r.method || '')) + '</span>';
      h += '<span class="q-badge">' + esc(String(r.check_result || '')) + '</span>';
      h += '<span style="font-family:monospace;color:var(--text2);font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + esc(String(r.listing_id || '')) + '">' + esc(String(r.listing_id || '')) + '</span>';
      h += '<span style="color:var(--text2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + esc(noteSnip) + '">' + esc(noteSnip) + '</span>';
      h += '<span>' + url + '</span>';
      h += '</div>';
    }
    h += '</div>';
  }
  h += '</div>';
  return h;
}

window.govSalesSortBy = function(col) {
  if (govSalesSort.col === col) {
    govSalesSort.dir = govSalesSort.dir === 'desc' ? 'asc' : 'desc';
  } else {
    govSalesSort = { col: col, dir: 'desc' };
  }
  govSalesPage = 0;
  renderGovSales();
};

async function renderGovSales() {
  const inner = document.getElementById('bizPageInner');
  if (!inner) return;

  const isComps = govSalesView === 'comps';

  // Lazy-load data on first render
  if (isComps && govSalesComps === null && !govSalesLoading) {
    govSalesLoading = true;
    inner.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading sales comps...</p></div>';
    try {
      let all = [], offset = 0;
      while (true) {
        const res = await govQuery('v_sales_comps', '*', { order: 'sale_date.desc.nullslast', limit: 1000, offset });
        const rows = res.data || [];
        all = all.concat(rows);
        if (rows.length < 1000) break;
        offset += 1000;
      }
      govSalesComps = all;
    } catch (e) { console.error('Gov sales comps load error:', e); govSalesComps = []; }
    govSalesLoading = false;
  }
  if (!isComps && govAvailListings === null && !govSalesLoading) {
    govSalesLoading = true;
    inner.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading available listings...</p></div>';
    try {
      let all = [], offset = 0;
      while (true) {
        const res = await govQuery('v_available_listings', '*', { order: 'listing_date.desc.nullslast', limit: 1000, offset });
        const rows = res.data || [];
        all = all.concat(rows);
        if (rows.length < 1000) break;
        offset += 1000;
      }
      govAvailListings = all;
    } catch (e) { console.error('Gov available load error:', e); govAvailListings = []; }
    govSalesLoading = false;
  }

  const data = isComps ? (govSalesComps || []) : (govAvailListings || []);

  // Normalize for unified rendering
  const normalized = data.map(r => {
    if (isComps) {
      return {
        property_id: r.property_id,
        lease_number: r.lease_number,
        agency: r.agency || r.agency_full || '',
        address: r.address,
        city: r.city,
        state: r.state,
        land_acres: r.land_acres,
        year_built: r.year_built,
        rba: r.rba,
        noi: r.noi ? parseFloat(r.noi) : null,
        noi_psf: r.noi_psf ? parseFloat(r.noi_psf) : null,
        lease_expiration: r.lease_expiration,
        firm_term_remaining: r.firm_term_remaining != null ? parseFloat(r.firm_term_remaining) : null,
        term_remaining: r.term_remaining != null ? parseFloat(r.term_remaining) : null,
        expenses: r.expenses,
        bumps: r.bumps,
        price: r.sold_price ? parseFloat(r.sold_price) : null,
        price_psf: r.sold_price_psf ? parseFloat(r.sold_price_psf) : null,
        cap_rate: r.sold_cap_rate ? parseFloat(r.sold_cap_rate) : null,
        sold_date: r.sale_date,
        seller: r.seller,
        listing_broker: r.listing_broker,
        buyer: r.buyer,
        procuring_broker: r.purchasing_broker,
        bid_ask_spread: r.bid_ask_spread != null ? parseFloat(r.bid_ask_spread) : null,
        dom: r.days_on_market != null ? parseInt(r.days_on_market, 10) : null
      };
    } else {
      return {
        property_id: r.property_id,
        lease_number: r.lease_number,
        agency: r.agency || r.agency_full || '',
        address: r.address,
        city: r.city,
        state: r.state,
        land_acres: r.land_acres,
        year_built: r.year_built,
        rba: r.rba,
        noi: r.noi ? parseFloat(r.noi) : null,
        noi_psf: r.noi_psf ? parseFloat(r.noi_psf) : null,
        lease_expiration: r.lease_expiration,
        firm_term_remaining: r.firm_term_remaining != null ? parseFloat(r.firm_term_remaining) : null,
        term_remaining: r.term_remaining != null ? parseFloat(r.term_remaining) : null,
        expenses: r.expenses,
        bumps: r.bumps,
        ask_price: r.asking_price ? parseFloat(r.asking_price) : null,
        price_psf: r.asking_price_psf ? parseFloat(r.asking_price_psf) : null,
        ask_cap: r.asking_cap_rate ? parseFloat(r.asking_cap_rate) : null,
        seller: r.seller,
        listing_broker: r.listing_broker,
        dom: r.days_on_market != null ? parseInt(r.days_on_market, 10) : null,
        // Marketing collateral — passed through so the Actions cell can
        // render the same icon set the Listings table shows (2026-04-23).
        intake_artifact_path: r.intake_artifact_path || null,
        intake_artifact_type: r.intake_artifact_type || null,
        source_url:           r.source_url || null,
        tracked_urls:         r.tracked_urls || null
      };
    }
  });

  // Filter by search
  const q = govSalesSearch.toLowerCase();
  const filtered = q ? normalized.filter(r =>
    (r.agency || '').toLowerCase().includes(q) ||
    (r.address || '').toLowerCase().includes(q) ||
    (r.city || '').toLowerCase().includes(q) ||
    (r.state || '').toLowerCase().includes(q) ||
    (r.seller || '').toLowerCase().includes(q) ||
    (r.buyer || '').toLowerCase().includes(q) ||
    (r.listing_broker || '').toLowerCase().includes(q)
  ) : normalized;

  // Sort
  if (govSalesSort.col) {
    const _sc = govSalesSort.col, _sd = govSalesSort.dir === 'asc' ? 1 : -1;
    filtered.sort(function(a, b) {
      var av = a[_sc], bv = b[_sc];
      if (av == null && bv == null) return 0;
      if (av == null) return 1;
      if (bv == null) return -1;
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * _sd;
      return String(av).localeCompare(String(bv)) * _sd;
    });
  }

  // Store filtered data for export
  govFilteredSalesData = filtered;

  // Pagination
  const totalPages = Math.max(1, Math.ceil(filtered.length / GOV_SALES_PAGE_SIZE));
  if (govSalesPage >= totalPages) govSalesPage = totalPages - 1;
  const pageRows = filtered.slice(govSalesPage * GOV_SALES_PAGE_SIZE, (govSalesPage + 1) * GOV_SALES_PAGE_SIZE);

  // Cap rate helper — normalizes mixed formats (0.07 decimal vs 7.15 percentage)
  const avgCapRate = (arr, field) => {
    const normalized = [];
    arr.forEach(r => {
      const v = parseFloat(r[field]);
      if (!v || v <= 0) return;
      const dec = v < 1 ? v : v / 100;
      if (dec > 0.01 && dec < 0.25) normalized.push(dec);
    });
    if (normalized.length === 0) return { val: '—', n: 0 };
    return { val: (normalized.reduce((s, d) => s + d, 0) / normalized.length * 100).toFixed(2) + '%', n: normalized.length };
  };

  let html = '<div class="biz-section">';

  // Sub-tab toggle
  html += '<div class="pills" style="margin-bottom: 16px;">';
  html += '<button class="pill' + (isComps ? ' active' : '') + '" data-gov-sales-view="comps">Sales Comps (' + (govSalesComps ? fmtN(govSalesComps.length) : '…') + ')</button>';
  html += '<button class="pill' + (!isComps ? ' active' : '') + '" data-gov-sales-view="available">Available (' + (govAvailListings ? fmtN(govAvailListings.length) : '…') + ')</button>';
  html += '</div>';

  // Metrics
  html += '<div class="gov-metrics">';
  if (isComps) {
    const withPrice = filtered.filter(r => r.price > 0);
    const cap = avgCapRate(filtered, 'cap_rate');
    const avgPrice = withPrice.length > 0 ? '$' + fmtN(Math.round(withPrice.reduce((s, r) => s + r.price, 0) / withPrice.length)) : '—';
    html += metricHTML('Total Sales', fmtN(filtered.length), 'gov comps', 'blue');
    html += metricHTML('Avg Cap Rate', cap.val, cap.n + ' with cap data', 'green');
    html += metricHTML('Avg Sale Price', avgPrice, withPrice.length + ' with price data', 'purple');
    const curYear = new Date().getFullYear();
    let thisYear = filtered.filter(r => r.sold_date && r.sold_date >= curYear + '-01-01').length;
    let ytdLabel = 'sales YTD';
    if (thisYear === 0 && filtered.length > 0) {
      // Fallback to most recent year with data
      const prevYear = curYear - 1;
      thisYear = filtered.filter(r => r.sold_date && r.sold_date >= prevYear + '-01-01' && r.sold_date < curYear + '-01-01').length;
      ytdLabel = prevYear + ' sales';
    }
    html += metricHTML('This Year', fmtN(thisYear), ytdLabel, 'yellow');
  } else {
    const withPrice = filtered.filter(r => r.ask_price > 0);
    const cap = avgCapRate(filtered, 'ask_cap');
    const avgAsk = withPrice.length > 0 ? '$' + fmtN(Math.round(withPrice.reduce((s, r) => s + r.ask_price, 0) / withPrice.length)) : '—';
    html += metricHTML('Active Listings', fmtN(filtered.length), 'on market', 'blue');
    html += metricHTML('Avg Ask Cap', cap.val, cap.n + ' with cap data', 'green');
    html += metricHTML('Avg Ask Price', avgAsk, withPrice.length + ' priced', 'purple');
    const avgDom = filtered.filter(r => r.dom > 0);
    const avgDomVal = avgDom.length > 0 ? Math.round(avgDom.reduce((s, r) => s + r.dom, 0) / avgDom.length) : '—';
    html += metricHTML('Avg DOM', avgDomVal, avgDom.length + ' with dates', 'yellow');
    // Round 76cx Phase 2 (gov parity): verification status card. Lazy-loaded
    // on first available-tab render; re-renders fill in the counts.
    if (govVerificationSummary === null && !govVerificationSummaryLoading) {
      loadGovVerificationSummary();
    }
    html += renderGovListingVerificationCard();
    // Round 76et-F: also kick off the recent-verifications drill-down load.
    if (govRecentVerifications === null && !govRecentVerificationsLoading) {
      loadRecentGovVerifications();
    }
  }
  html += '</div>';

  // Round 76et-F: drill-down panel for the verification card. Only on the
  // Available sub-tab; Sales Comps doesn't have a verification surface.
  if (!isComps) {
    html += renderRecentGovVerificationsPanel();
  }

  // Search bar
  html += '<div style="margin: 16px 0; display: flex; gap: 8px; align-items: center;">';
  html += '<input type="text" id="govSalesSearchInput" placeholder="Search agency, address, city, broker..." value="' + esc(govSalesSearch) + '" style="flex:1; padding: 8px 12px; border-radius: 8px; border: 1px solid var(--border); background: var(--s2); color: var(--text); font-size: 13px;" />';
  html += '<span style="font-size: 12px; color: var(--text3);">' + fmtN(filtered.length) + ' results</span>';
  html += '<button onclick="exportCompsToXlsx(govFilteredSalesData, \'' + (isComps ? 'sales' : 'sales') + '\')" style="padding:6px 14px;border-radius:8px;border:1px solid var(--border);background:var(--s2);color:var(--accent);font-size:12px;font-weight:600;cursor:pointer;white-space:nowrap;display:flex;align-items:center;gap:4px;" title="Export all ' + fmtN(filtered.length) + ' filtered results to Excel">&#x1F4E5; Export</button>';
  html += '</div>';

  // Scrollable table
  html += '<div style="overflow-x: auto; -webkit-overflow-scrolling: touch; border: 1px solid var(--border); border-radius: 10px; max-height: 70vh;">';
  html += '<table style="width: max-content; min-width: 2200px; border-collapse: collapse; font-size: 12px;">';

  // Header
  html += '<thead><tr style="background: var(--s2); position: sticky; top: 0; z-index: 1;">';
  const _sortArrow = (col) => {
    if (govSalesSort.col !== col) return ' <span style="opacity:0.3;font-size:9px">&#x25B2;&#x25BC;</span>';
    return govSalesSort.dir === 'asc' ? ' <span style="color:var(--accent);font-size:9px">&#x25B2;</span>' : ' <span style="color:var(--accent);font-size:9px">&#x25BC;</span>';
  };
  const th = (label, w, col) => '<th onclick="govSalesSortBy(\'' + col + '\')" style="padding: 10px 8px; text-align: left; font-weight: 600; font-size: 11px; letter-spacing: 0.3px; text-transform: uppercase; color: var(--text2); border-bottom: 2px solid var(--border); white-space: nowrap; min-width: ' + w + 'px; cursor: pointer; user-select: none;">' + label + _sortArrow(col) + '</th>';
  const thr = (label, w, col) => '<th onclick="govSalesSortBy(\'' + col + '\')" style="padding: 10px 8px; text-align: right; font-weight: 600; font-size: 11px; letter-spacing: 0.3px; text-transform: uppercase; color: var(--text2); border-bottom: 2px solid var(--border); white-space: nowrap; min-width: ' + w + 'px; cursor: pointer; user-select: none;">' + label + _sortArrow(col) + '</th>';

  if (isComps) {
    html += th('Agency', 160, 'agency');
    html += th('Address', 140, 'address');
    html += th('City', 90, 'city');
    html += th('State', 40, 'state');
    html += thr('Land', 55, 'land_acres');
    html += thr('Built', 45, 'year_built');
    html += thr('RBA', 60, 'rba');
    html += thr('NOI', 75, 'noi');
    html += thr('NOI/SF', 60, 'noi_psf');
    html += th('Expiration', 85, 'lease_expiration');
    html += thr('Firm Term Rem', 80, 'firm_term_remaining');
    html += thr('Lease Term Rem', 80, 'term_remaining');
    html += th('Expenses', 70, 'expenses');
    html += th('Bumps', 90, 'bumps');
    html += thr('Price', 85, 'price');
    html += thr('Price/SF', 65, 'price_psf');
    html += thr('Cap', 55, 'cap_rate');
    html += th('Sold Date', 80, 'sold_date');
    html += th('Seller', 110, 'seller');
    html += th('Listing Broker', 100, 'listing_broker');
    html += th('Buyer', 110, 'buyer');
    html += th('Procuring Broker', 110, 'procuring_broker');
    html += thr('Bid-Ask', 55, 'bid_ask_spread');
    html += thr('DOM', 45, 'dom');
  } else {
    html += th('Agency', 160, 'agency');
    html += th('Address', 140, 'address');
    html += th('City', 90, 'city');
    html += th('State', 40, 'state');
    html += thr('Land', 55, 'land_acres');
    html += thr('Built', 45, 'year_built');
    html += thr('RBA', 60, 'rba');
    html += thr('NOI', 75, 'noi');
    html += thr('NOI/SF', 60, 'noi_psf');
    html += th('Expiration', 85, 'lease_expiration');
    html += thr('Firm Term Rem', 80, 'firm_term_remaining');
    html += thr('Lease Term Rem', 80, 'term_remaining');
    html += th('Expenses', 70, 'expenses');
    html += th('Bumps', 90, 'bumps');
    html += thr('Ask Price', 85, 'ask_price');
    html += thr('Price/SF', 65, 'price_psf');
    html += thr('Ask Cap', 55, 'ask_cap');
    html += th('Seller', 110, 'seller');
    html += th('Listing Broker', 100, 'listing_broker');
    html += thr('DOM', 45, 'dom');
  }
  html += '<th style="padding:10px 8px;text-align:center;font-weight:600;font-size:11px;letter-spacing:0.3px;text-transform:uppercase;color:var(--text2);border-bottom:2px solid var(--border);white-space:nowrap;min-width:80px;position:sticky;right:0;background:var(--s2);z-index:2">Actions</th>';
  html += '</tr></thead>';

  // Body
  html += '<tbody>';
  const td = (val, trunc) => '<td style="padding: 8px; border-bottom: 1px solid var(--border); white-space: nowrap;' + (trunc ? ' max-width: 180px; overflow: hidden; text-overflow: ellipsis;' : '') + '">' + esc(val || '—') + '</td>';
  const tdr = (val) => '<td style="padding: 8px; border-bottom: 1px solid var(--border); white-space: nowrap; text-align: right; font-family: \'JetBrains Mono\', monospace; font-size: 11px;">' + (val || '—') + '</td>';
  const fmtMoney = (v) => v != null && v > 0 ? '$' + Number(v).toLocaleString('en-US', { maximumFractionDigits: 0 }) : '—';
  const fmtCap = (v) => v != null && v > 0 ? (v < 1 ? (v * 100).toFixed(2) : parseFloat(v).toFixed(2)) + '%' : '—';
  const fmtPSF = (v) => v != null && v > 0 ? '$' + Number(v).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '—';
  const fmtAcres = (v) => v != null && v > 0 ? parseFloat(v).toFixed(2) + ' ac' : '—';
  const fmtSF = (v) => v != null && v > 0 ? Number(Math.round(v)).toLocaleString('en-US') + ' SF' : '—';
  const fmtTerm = (v) => v != null ? (parseFloat(v) < 0 ? 'Exp.' : parseFloat(v).toFixed(1) + ' yr') : '—';
  const fmtDate = (v) => v || '—';

  pageRows.forEach((r, _ri) => {
    const rowData = JSON.stringify({ property_id: r.property_id, lease_number: r.lease_number, agency: r.agency, address: r.address, city: r.city, state: r.state }).replace(/'/g, '&#39;');
    const _zebra = _ri % 2 === 0 ? '' : 'background:rgba(255,255,255,0.02);';
    html += '<tr class="clickable-row" onclick=\'showDetail(' + rowData + ', "gov-ownership")\' style="cursor: pointer;' + _zebra + '">';
    html += td(r.agency, true);
    html += td(r.address, true);
    html += td(r.city);
    html += td(r.state);
    html += tdr(fmtAcres(r.land_acres));
    html += tdr(r.year_built || '—');
    html += tdr(fmtSF(r.rba));
    html += tdr(fmtMoney(r.noi));
    html += tdr(fmtPSF(r.noi_psf));
    html += td(fmtDate(r.lease_expiration));
    html += tdr(fmtTerm(r.firm_term_remaining));
    html += tdr(fmtTerm(r.term_remaining));
    html += td(r.expenses);
    html += td(r.bumps, true);
    if (isComps) {
      html += tdr(fmtMoney(r.price));
      html += tdr(fmtPSF(r.price_psf));
      html += tdr(fmtCap(r.cap_rate));
      html += td(fmtDate(r.sold_date));
      html += td(r.seller, true);
      html += td(r.listing_broker, true);
      html += td(r.buyer, true);
      html += td(r.procuring_broker, true);
      html += tdr(r.bid_ask_spread != null ? r.bid_ask_spread + '%' : '—');
      html += tdr(r.dom != null ? r.dom + 'd' : '—');
    } else {
      html += tdr(fmtMoney(r.ask_price));
      html += tdr(fmtPSF(r.price_psf));
      html += tdr(fmtCap(r.ask_cap));
      html += td(r.seller, true);
      html += td(r.listing_broker, true);
      html += tdr(r.dom != null ? r.dom + 'd' : '—');
    }
    // Sticky actions column — Available rows additionally show the marketing
    // collateral icon strip (OM PDF, Crexi/LoopNet badges, brokerage site).
    // Sales Comps rows skip the collateral icons (sold comps rarely carry
    // a live OM/marketplace link anymore).
    html += '<td style="padding:8px;border-bottom:1px solid var(--border);text-align:center;position:sticky;right:0;background:var(--s1);z-index:1" onclick="event.stopPropagation()">';
    html += '<div style="display:flex;gap:3px;justify-content:center;flex-wrap:wrap">';
    if (!isComps && typeof buildCollateralIcons === 'function') {
      html += buildCollateralIcons(r, {
        pdf:         'intake_artifact_path',
        pdfType:     'intake_artifact_type',
        primaryUrl:  'source_url',
        trackedUrls: 'tracked_urls'
      });
    }
    html += '<button class="gov-row-action" onclick=\'showDetail(' + rowData + ', "gov-ownership", "Ownership")\' title="View owner & contacts">📞</button>';
    html += '<button class="gov-row-action accent" onclick=\'showDetail(' + rowData + ', "gov-ownership", "Intel")\' title="Research & intel">🔍</button>';
    html += '</div></td>';
    html += '</tr>';
  });

  if (pageRows.length === 0) {
    const colSpan = isComps ? 25 : 21;
    html += '<tr><td colspan="' + colSpan + '" style="text-align: center; padding: 32px; color: var(--text3);">No ' + (isComps ? 'sales comps' : 'available listings') + ' to display</td></tr>';
  }
  html += '</tbody></table></div>';

  // Pagination
  if (totalPages > 1) {
    html += '<div style="display: flex; justify-content: space-between; align-items: center; margin-top: 12px; font-size: 13px; color: var(--text2);">';
    html += '<span>Page ' + (govSalesPage + 1) + ' of ' + totalPages + ' (' + fmtN(filtered.length) + ' total)</span>';
    html += '<div style="display: flex; gap: 6px;">';
    html += '<button class="pill' + (govSalesPage === 0 ? '' : ' active') + '" data-gov-sales-page="prev"' + (govSalesPage === 0 ? ' disabled style="opacity:0.4;pointer-events:none"' : '') + '>&laquo; Prev</button>';
    html += '<button class="pill' + (govSalesPage >= totalPages - 1 ? '' : ' active') + '" data-gov-sales-page="next"' + (govSalesPage >= totalPages - 1 ? ' disabled style="opacity:0.4;pointer-events:none"' : '') + '>Next &raquo;</button>';
    html += '</div></div>';
  }

  html += '</div>';

  // Render to DOM
  inner.innerHTML = html;

  // Bind events
  document.querySelectorAll('[data-gov-sales-view]').forEach(btn => {
    btn.addEventListener('click', e => {
      govSalesView = e.target.dataset.govSalesView;
      govSalesPage = 0;
      govSalesSearch = '';
      renderGovSales();
    });
  });
  document.querySelectorAll('[data-gov-sales-page]').forEach(btn => {
    btn.addEventListener('click', e => {
      if (e.target.dataset.govSalesPage === 'prev' && govSalesPage > 0) govSalesPage--;
      else if (e.target.dataset.govSalesPage === 'next') govSalesPage++;
      renderGovSales();
    });
  });
  const searchInput = document.getElementById('govSalesSearchInput');
  if (searchInput) {
    let debounce;
    searchInput.addEventListener('input', e => {
      clearTimeout(debounce);
      debounce = setTimeout(() => {
        govSalesSearch = e.target.value.trim();
        govSalesPage = 0;
        renderGovSales();
      }, 300);
    });
    searchInput.focus();
    searchInput.selectionStart = searchInput.selectionEnd = searchInput.value.length;
  }
}


// ============================================================================
// GOVERNMENT LEASES TAB
// ============================================================================
let govLeasesData = null; // lazy-loaded

function renderGovLeases() {
  const el = document.getElementById('bizPageInner');
  if (!el) return '';

  // Show loading if data not yet available
  if (!govData.portfolioProperties || govData.portfolioProperties.length === 0) {
    el.innerHTML = '<div class="loading"><span class="spinner"></span> Loading lease data...</div>';
    // Trigger portfolio load if not done
    (async () => {
      try {
        let allProps = [], pg = 0;
        while (true) {
          const batch = await govQuery('properties',
            'property_id,agency,agency_full_name,address,city,state,firm_term_remaining,gross_rent,gross_rent_psf,sf_leased,noi,lease_expiration,lease_commencement,government_type',
            { limit: 2000, offset: pg * 2000 }
          );
          allProps = allProps.concat(batch.data || []);
          if (!batch.data || batch.data.length < 2000) break;
          pg++;
        }
        govData.portfolioProperties = allProps;
        el.innerHTML = buildGovLeasesHTML();
      } catch (e) {
        el.innerHTML = '<div class="widget-error"><div class="err-msg">Failed to load lease data</div><button class="retry-btn" onclick="renderGovLeases()">Retry</button></div>';
      }
    })();
    return '';
  }

  el.innerHTML = buildGovLeasesHTML();
  return '';
}

function buildGovLeasesHTML() {
  const props = govData.portfolioProperties || [];
  const now = new Date();
  const yearStart = new Date(now.getFullYear(), 0, 1);

  // Parse lease data
  const withLease = props.filter(p => p.lease_expiration || p.firm_term_remaining != null);
  const withTerm = props.filter(p => p.firm_term_remaining != null && p.firm_term_remaining !== undefined);

  // Expiration buckets
  const expired = withTerm.filter(p => p.firm_term_remaining < 0);
  const under1yr = withTerm.filter(p => p.firm_term_remaining >= 0 && p.firm_term_remaining <= 1);
  const yr1to2 = withTerm.filter(p => p.firm_term_remaining > 1 && p.firm_term_remaining <= 2);
  const yr2to5 = withTerm.filter(p => p.firm_term_remaining > 2 && p.firm_term_remaining <= 5);
  const yr5to10 = withTerm.filter(p => p.firm_term_remaining > 5 && p.firm_term_remaining <= 10);
  const over10 = withTerm.filter(p => p.firm_term_remaining > 10);
  const avgTerm = withTerm.length > 0 ? (withTerm.reduce((s, p) => s + (p.firm_term_remaining || 0), 0) / withTerm.length) : 0;
  const totalRent = props.reduce((s, p) => s + (p.gross_rent || 0), 0);

  let html = '<div style="margin-bottom:24px">';
  html += '<div style="font-size:16px;font-weight:700;margin-bottom:12px;display:flex;align-items:center;gap:8px"><span style="font-size:20px">📋</span> Lease Intelligence</div>';

  // === Action guidance banner ===
  html += '<div style="padding:10px 14px;background:rgba(248,113,113,0.08);border-radius:8px;border-left:3px solid #f87171;margin-bottom:16px;display:flex;align-items:center;gap:10px;">';
  html += '<div style="font-size:13px;color:var(--text);line-height:1.4"><strong>Action:</strong> Identify high-priority prospecting targets from expiring and recently executed leases. Click any row to view property details, ownership, and lease terms. Properties with short remaining terms are prime candidates for pipeline outreach.</div>';
  html += '</div>';

  // ── Summary Stats ──
  html += '<div class="dia-grid dia-grid-4" style="margin-bottom:20px">';
  html += metricHTML('Total Properties', fmtN(props.length), 'With lease data', 'blue');
  html += metricHTML('Avg Firm Term', avgTerm.toFixed(1) + ' yrs', withTerm.length + ' properties', 'cyan');
  html += metricHTML('Expiring < 2 Years', fmtN(expired.length + under1yr.length + yr1to2.length), 'High-priority targets', 'red');
  html += metricHTML('Total Gross Rent', fmt(totalRent), fmtN(props.filter(p => p.gross_rent).length) + ' properties', 'green');
  html += '</div>';

  // ── Expiration Distribution Chart ──
  html += '<div class="widget" style="margin-bottom:16px">';
  html += '<div class="widget-title">Lease Expiration Distribution</div>';
  const buckets = [
    { label: 'Expired', count: expired.length, color: '#ef4444', rent: expired.reduce((s, p) => s + (p.gross_rent || 0), 0) },
    { label: '0–1 Years', count: under1yr.length, color: '#f87171', rent: under1yr.reduce((s, p) => s + (p.gross_rent || 0), 0) },
    { label: '1–2 Years', count: yr1to2.length, color: '#fb923c', rent: yr1to2.reduce((s, p) => s + (p.gross_rent || 0), 0) },
    { label: '2–5 Years', count: yr2to5.length, color: '#fbbf24', rent: yr2to5.reduce((s, p) => s + (p.gross_rent || 0), 0) },
    { label: '5–10 Years', count: yr5to10.length, color: '#34d399', rent: yr5to10.reduce((s, p) => s + (p.gross_rent || 0), 0) },
    { label: '10+ Years', count: over10.length, color: '#60a5fa', rent: over10.reduce((s, p) => s + (p.gross_rent || 0), 0) },
  ];
  const maxBucket = Math.max(...buckets.map(b => b.count), 1);
  html += '<div style="display:flex;flex-direction:column;gap:6px">';
  for (const b of buckets) {
    const pct = ((b.count / maxBucket) * 100).toFixed(0);
    html += `<div style="display:flex;align-items:center;gap:8px">
      <div style="width:90px;font-size:12px;color:var(--text2);text-align:right;flex-shrink:0">${esc(b.label)}</div>
      <div style="flex:1;background:var(--s2);border-radius:4px;height:22px;overflow:hidden">
        <div style="width:${pct}%;background:${b.color};height:100%;border-radius:4px;min-width:${b.count > 0 ? '2px' : '0'}"></div>
      </div>
      <div style="width:40px;font-size:12px;font-weight:600;color:var(--text)">${fmtN(b.count)}</div>
      <div style="width:70px;font-size:11px;color:var(--text3)">${fmt(b.rent)}</div>
    </div>`;
  }
  html += '</div></div>';

  // ── Expiring Soon — Prospecting Targets ──
  // Sort: soonest-to-expire first (small positive values), then expired leases at the end
  const urgentLeases = [...under1yr, ...yr1to2, ...expired]
    .sort((a, b) => {
      const aT = a.firm_term_remaining ?? -999;
      const bT = b.firm_term_remaining ?? -999;
      // Positive terms first (ascending), then negative/expired last
      if (aT >= 0 && bT >= 0) return aT - bT;
      if (aT >= 0) return -1;
      if (bT >= 0) return 1;
      return bT - aT; // among expired, most recently expired first
    });

  html += '<div class="widget" style="margin-bottom:16px">';
  html += `<div class="widget-title">Expiring Soon — Prospecting Targets <span style="font-size:12px;font-weight:400;color:var(--text3)">(${urgentLeases.length} properties)</span></div>`;

  if (urgentLeases.length === 0) {
    html += '<div style="color:var(--text2);font-size:13px;padding:12px 0">No leases expiring within 2 years.</div>';
  } else {
    html += '<div class="gov-table-card"><table class="gov-table"><thead><tr>';
    html += '<th>Agency</th><th>Address</th><th>City</th><th>State</th><th style="text-align:right">Firm Term</th><th>Expiration</th><th style="text-align:right">Rent</th><th style="text-align:right">SF</th><th style="text-align:center;min-width:130px">Actions</th>';
    html += '</tr></thead><tbody>';
    for (const p of urgentLeases.slice(0, 50)) {
      const termColor = (p.firm_term_remaining || 0) < 0 ? 'var(--red)' : (p.firm_term_remaining || 0) <= 1 ? '#f87171' : '#fb923c';
      const termLabel = p.firm_term_remaining != null ? (p.firm_term_remaining < 0 ? 'Expired' : p.firm_term_remaining.toFixed(1) + ' yrs') : '—';
      const expDate = p.lease_expiration ? new Date(p.lease_expiration).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : '—';
      html += `<tr class="clickable-row" onclick='showDetail(${safeJSON(p)}, "gov-lead")'>`;
      html += `<td>${esc(p.agency || p.agency_full_name || '—')}</td>`;
      html += `<td>${esc(p.address || '—')}</td>`;
      html += `<td>${esc(p.city || '—')}</td>`;
      html += `<td>${esc(p.state || '—')}</td>`;
      html += `<td style="text-align:right;color:${termColor};font-weight:600">${termLabel}</td>`;
      html += `<td>${expDate}</td>`;
      html += `<td style="text-align:right">${p.gross_rent ? fmt(p.gross_rent) : '—'}</td>`;
      html += `<td style="text-align:right">${p.sf_leased ? fmtN(Math.round(p.sf_leased)) : '—'}</td>`;
      html += '<td style="text-align:center" onclick="event.stopPropagation()">';
      html += '<div style="display:flex;gap:4px;justify-content:center">';
      html += `<button class="gov-row-action" onclick="govQuickLogActivity(${safeJSON(p)}, 'lease')" title="Log a call or note for this property">📞 Log</button>`;
      html += `<button class="gov-row-action accent" onclick="govQuickAddToPipeline(${safeJSON(p)})" title="Add or update this property in the prospect pipeline">🎯 Pipeline</button>`;
      html += '</div></td>';
      html += '</tr>';
    }
    html += '</tbody></table></div>';
    if (urgentLeases.length > 50) {
      html += `<div style="text-align:center;font-size:12px;color:var(--text3);padding:8px">Showing 50 of ${urgentLeases.length} expiring leases</div>`;
    }
  }
  html += '</div>';

  // ── New Leases (Recent) ──
  const recentLeases = props.filter(p => p.lease_commencement).sort((a, b) => (b.lease_commencement || '').localeCompare(a.lease_commencement || '')).slice(0, 25);

  html += '<div class="widget" style="margin-bottom:16px">';
  html += `<div class="widget-title">Recent / New Leases <span style="font-size:12px;font-weight:400;color:var(--text3)">(by lease effective date)</span></div>`;
  if (recentLeases.length === 0) {
    html += '<div style="color:var(--text2);font-size:13px;padding:12px 0">No lease effective dates available.</div>';
  } else {
    html += '<div class="gov-table-card"><table class="gov-table"><thead><tr>';
    html += '<th>Agency</th><th>Address</th><th>State</th><th>Effective</th><th>Expiration</th><th style="text-align:right">Firm Term</th><th style="text-align:right">Rent</th>';
    html += '</tr></thead><tbody>';
    for (const p of recentLeases) {
      const eff = p.lease_commencement ? new Date(p.lease_commencement).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '—';
      const exp = p.lease_expiration ? new Date(p.lease_expiration).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : '—';
      const term = p.firm_term_remaining != null ? p.firm_term_remaining.toFixed(1) + ' yrs' : '—';
      html += `<tr class="clickable-row" onclick='showDetail(${safeJSON(p)}, "gov-lead")'>`;
      html += `<td>${esc(p.agency || '—')}</td><td>${esc(p.address || '—')}</td><td>${esc(p.state || '—')}</td>`;
      html += `<td>${eff}</td><td>${exp}</td><td style="text-align:right">${term}</td><td style="text-align:right">${p.gross_rent ? fmt(p.gross_rent) : '—'}</td>`;
      html += '</tr>';
    }
    html += '</tbody></table></div>';
  }
  html += '</div>';

  // ── Agency Lease Analysis ──
  html += '<div class="widget">';
  html += '<div class="widget-title">Lease Exposure by Agency</div>';
  const agencyMap = {};
  let unknownAgencyStatsLeases = { count: 0, rent: 0, termSum: 0, expiring: 0 };
  for (const p of withTerm) {
    const a = p.agency || p.agency_full_name || 'Unknown';
    if (a === 'Unknown') {
      // Separate tracking for Unknown agencies (Issue #5)
      unknownAgencyStatsLeases.count++;
      unknownAgencyStatsLeases.rent += (p.gross_rent || 0);
      unknownAgencyStatsLeases.termSum += (p.firm_term_remaining || 0);
      if (p.firm_term_remaining <= 2) unknownAgencyStatsLeases.expiring++;
    } else {
      if (!agencyMap[a]) agencyMap[a] = { count: 0, rent: 0, termSum: 0, expiring: 0 };
      agencyMap[a].count++;
      agencyMap[a].rent += (p.gross_rent || 0);
      agencyMap[a].termSum += (p.firm_term_remaining || 0);
      if (p.firm_term_remaining <= 2) agencyMap[a].expiring++;
    }
  }
  const topAgencies = Object.entries(agencyMap).sort((a, b) => b[1].count - a[1].count).slice(0, 15);
  if (topAgencies.length > 0) {
    html += '<div class="gov-table-card"><table class="gov-table"><thead><tr>';
    html += '<th>Agency</th><th style="text-align:right">Properties</th><th style="text-align:right">Total Rent</th><th style="text-align:right">Avg Term</th><th style="text-align:right">Expiring &lt;2yr</th>';
    html += '</tr></thead><tbody>';
    for (const [name, data] of topAgencies) {
      const avgT = data.count > 0 ? (data.termSum / data.count).toFixed(1) : '—';
      html += `<tr><td>${esc(name)}</td><td style="text-align:right">${fmtN(data.count)}</td><td style="text-align:right">${fmt(data.rent)}</td><td style="text-align:right">${avgT} yrs</td><td style="text-align:right;color:${data.expiring > 0 ? 'var(--red)' : 'var(--text2)'}">${fmtN(data.expiring)}</td></tr>`;
    }
    html += '</tbody></table></div>';
  }
  html += '</div>';

  html += '</div>';
  return html;
}

// ============================================================================
// GOVERNMENT LOANS TAB
// ============================================================================
let govLoansData = null; // lazy-loaded
let govLoanPropertyMap = {}; // property_id → {address, city, state, agency}
let govLoansMaturityFilter = 'all'; // 'all', '1yr', '2yr'

// ── Pipeline filter/sort state (Round 50) ──
let govPipelineTempFilter = 'all'; // 'all', 'hot', 'warm', 'cool'
let govPipelineSearch = '';
let govPipelineSort = 'score'; // 'score', 'value', 'contact', 'address'

function renderGovLoans() {
  const el = document.getElementById('bizPageInner');
  if (!el) return '';

  // Lazy-load loans + property address map
  if (!govLoansData) {
    el.innerHTML = '<div class="loading"><span class="spinner"></span> Loading loan data...</div>';
    (async () => {
      try {
        // Load loans (paginated)
        let allLoans = [], pg = 0;
        while (true) {
          const batch = await govQuery('loans',
            'loan_id,property_id,index_name,loan_amount,loan_type,status,maturity_date,interest_rate,origination_date,lender_id,rate_type,term_years,data_source',
            { limit: 2000, offset: pg * 2000 }
          );
          allLoans = allLoans.concat(batch.data || []);
          if (!batch.data || batch.data.length < 2000) break;
          pg++;
        }
        govLoansData = allLoans;

        // Build property address map from portfolioProperties if available,
        // otherwise load property addresses for loan property_ids
        govLoanPropertyMap = {};
        if (govData.portfolioProperties && govData.portfolioProperties.length > 0) {
          for (const p of govData.portfolioProperties) {
            if (p.property_id) govLoanPropertyMap[p.property_id] = p;
          }
        } else {
          // Load addresses for unique property_ids referenced by loans
          const propIds = [...new Set(allLoans.map(l => l.property_id).filter(Boolean))];
          if (propIds.length > 0) {
            let allProps = [], ppg = 0;
            while (true) {
              const pbatch = await govQuery('properties',
                'property_id,address,city,state,agency,agency_full_name',
                { limit: 2000, offset: ppg * 2000 }
              );
              allProps = allProps.concat(pbatch.data || []);
              if (!pbatch.data || pbatch.data.length < 2000) break;
              ppg++;
            }
            for (const p of allProps) {
              if (p.property_id) govLoanPropertyMap[p.property_id] = p;
            }
          }
        }

        if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'government') return;
        el.innerHTML = buildGovLoansHTML();
      } catch (e) {
        console.error('Loans load error:', e);
        el.innerHTML = '<div class="widget-error"><div class="err-msg">Failed to load loan data</div><button class="retry-btn" onclick="govLoansData=null;renderGovLoans()">Retry</button></div>';
      }
    })();
    return '';
  }

  el.innerHTML = buildGovLoansHTML();
  return '';
}

function buildGovLoansHTML() {
  const loans = govLoansData || [];
  const propMap = govLoanPropertyMap || {};

  let html = '<div style="margin-bottom:24px">';
  html += '<div style="font-size:16px;font-weight:700;margin-bottom:16px;display:flex;align-items:center;gap:8px"><span style="font-size:20px">🏦</span> Loan Intelligence</div>';

  if (loans.length === 0) {
    html += '<div class="widget" style="text-align:center;padding:40px 20px">';
    html += '<div style="font-size:48px;margin-bottom:12px;opacity:0.3">🏦</div>';
    html += '<div style="font-size:16px;font-weight:600;margin-bottom:8px;color:var(--text)">Loan Data Coming Soon</div>';
    html += '<div style="font-size:13px;color:var(--text2);max-width:400px;margin:0 auto;line-height:1.6">';
    html += 'This tab will show loan-level intelligence including maturity schedules, lender breakdown, LTV analysis, and refinancing opportunities once loan data is ingested into Supabase.';
    html += '</div>';
    html += '<div style="margin-top:20px;display:flex;gap:12px;justify-content:center;flex-wrap:wrap">';
    html += '<div class="stat-card" style="min-width:120px"><div class="stat-label">Total Loans</div><div class="stat-value" style="color:var(--text3)">0</div></div>';
    html += '<div class="stat-card" style="min-width:120px"><div class="stat-label">Total Volume</div><div class="stat-value" style="color:var(--text3)">$0</div></div>';
    html += '<div class="stat-card" style="min-width:120px"><div class="stat-label">Maturing &lt;1yr</div><div class="stat-value" style="color:var(--text3)">0</div></div>';
    html += '</div>';
    html += '</div>';
    html += '</div>';
    return html;
  }

  // Stats
  const totalVolume = loans.reduce((s, l) => s + (parseFloat(l.loan_amount) || 0), 0);
  const withMaturity = loans.filter(l => l.maturity_date);
  const now = new Date();
  const oneYr = new Date(now.getFullYear() + 1, now.getMonth(), now.getDate());
  const twoYr = new Date(now.getFullYear() + 2, now.getMonth(), now.getDate());
  const maturingUnder1 = withMaturity.filter(l => new Date(l.maturity_date) <= oneYr);
  const maturingUnder2 = withMaturity.filter(l => new Date(l.maturity_date) <= twoYr);

  // Type breakdown
  const typeMap = {};
  for (const l of loans) {
    const t = l.loan_type || 'Unknown';
    if (!typeMap[t]) typeMap[t] = { count: 0, volume: 0 };
    typeMap[t].count++;
    typeMap[t].volume += (parseFloat(l.loan_amount) || 0);
  }

  // KPI cards — clickable to filter maturity table
  const filterActive = govLoansMaturityFilter || 'all';
  html += '<div class="dia-grid dia-grid-4" style="margin-bottom:20px">';

  html += '<div class="stat-card' + (filterActive === 'all' ? ' stat-card-active' : '') + '" style="min-width:120px;cursor:pointer;' + (filterActive === 'all' ? 'outline:2px solid var(--accent);outline-offset:-2px;' : '') + '" onclick="govLoansMaturityFilter=\'all\';document.getElementById(\'bizPageInner\').innerHTML=buildGovLoansHTML()">';
  html += '<div class="stat-label" style="color:var(--blue)">Total Loans</div><div class="stat-value">' + fmtN(loans.length) + '</div><div class="stat-sub">In database</div></div>';

  html += '<div class="stat-card" style="min-width:120px"><div class="stat-label" style="color:var(--green)">Total Volume</div><div class="stat-value">' + fmt(totalVolume) + '</div><div class="stat-sub">' + fmtN(loans.length) + ' loans</div></div>';

  html += '<div class="stat-card' + (filterActive === '1yr' ? ' stat-card-active' : '') + '" style="min-width:120px;cursor:pointer;' + (filterActive === '1yr' ? 'outline:2px solid var(--red);outline-offset:-2px;' : '') + '" onclick="govLoansMaturityFilter=\'1yr\';document.getElementById(\'bizPageInner\').innerHTML=buildGovLoansHTML()">';
  html += '<div class="stat-label" style="color:var(--red)">Maturing &lt; 1yr</div><div class="stat-value">' + fmtN(maturingUnder1.length) + '</div><div class="stat-sub">Refi opportunities</div></div>';

  html += '<div class="stat-card' + (filterActive === '2yr' ? ' stat-card-active' : '') + '" style="min-width:120px;cursor:pointer;' + (filterActive === '2yr' ? 'outline:2px solid var(--orange);outline-offset:-2px;' : '') + '" onclick="govLoansMaturityFilter=\'2yr\';document.getElementById(\'bizPageInner\').innerHTML=buildGovLoansHTML()">';
  html += '<div class="stat-label" style="color:var(--orange)">Maturing &lt; 2yr</div><div class="stat-value">' + fmtN(maturingUnder2.length) + '</div><div class="stat-sub">Watch list</div></div>';

  html += '</div>';

  // CMBS Deal/Trust Breakdown (uses index_name populated by Prompt 2 backfill)
  const dealMap = {};
  for (const l of loans) {
    const deal = l.index_name || 'Unidentified';
    if (!dealMap[deal]) dealMap[deal] = { count: 0, volume: 0 };
    dealMap[deal].count++;
    dealMap[deal].volume += (parseFloat(l.loan_amount) || 0);
  }
  const topDeals = Object.entries(dealMap).sort((a, b) => b[1].volume - a[1].volume).slice(0, 15);
  const hasRealDealData = topDeals.some(([name]) => name !== 'Unidentified');

  if (hasRealDealData && topDeals.length > 0) {
    html += '<div class="widget" style="margin-bottom:16px">';
    html += '<div class="widget-title">CMBS Deal Breakdown</div>';
    html += '<div class="gov-table-card"><table class="gov-table"><thead><tr>';
    html += '<th>Deal / Trust</th><th style="text-align:right">Loans</th><th style="text-align:right">Volume</th><th style="text-align:right">Avg Loan</th>';
    html += '</tr></thead><tbody>';
    for (const [name, data] of topDeals) {
      const avg = data.count > 0 ? data.volume / data.count : 0;
      html += '<tr><td>' + esc(name) + '</td><td style="text-align:right">' + fmtN(data.count) + '</td><td style="text-align:right">' + fmt(data.volume) + '</td><td style="text-align:right">' + fmt(avg) + '</td></tr>';
    }
    html += '</tbody></table></div></div>';
  }

  // Loan Type Breakdown
  if (Object.keys(typeMap).length > 1) {
    html += '<div class="widget" style="margin-bottom:16px">';
    html += '<div class="widget-title">By Loan Type</div>';
    html += '<div style="display:flex;flex-wrap:wrap;gap:8px">';
    for (const [type, data] of Object.entries(typeMap).sort((a, b) => b[1].volume - a[1].volume)) {
      html += '<div class="stat-card" style="min-width:120px;flex:1"><div class="stat-label">' + esc(type) + '</div><div class="stat-value" style="font-size:18px">' + fmtN(data.count) + '</div><div class="stat-sub">' + fmt(data.volume) + '</div></div>';
    }
    html += '</div></div>';
  }

  // Maturity Schedule — filtered by KPI card selection
  let maturityLoans;
  let maturityLabel;
  if (filterActive === '1yr') {
    maturityLoans = maturingUnder1.sort((a, b) => (a.maturity_date || '').localeCompare(b.maturity_date || ''));
    maturityLabel = 'Maturing Within 1 Year';
  } else if (filterActive === '2yr') {
    maturityLoans = maturingUnder2.sort((a, b) => (a.maturity_date || '').localeCompare(b.maturity_date || ''));
    maturityLabel = 'Maturing Within 2 Years';
  } else {
    maturityLoans = withMaturity.sort((a, b) => (a.maturity_date || '').localeCompare(b.maturity_date || ''));
    maturityLabel = 'All Loans by Maturity';
  }

  if (maturityLoans.length > 0) {
    html += '<div class="widget">';
    html += '<div class="widget-title">' + maturityLabel + ' <span style="font-size:12px;font-weight:400;color:var(--text3)">(' + maturityLoans.length + ' loans)</span></div>';
    html += '<div class="gov-table-card"><table class="gov-table"><thead><tr>';
    html += '<th>Property</th><th>City</th><th>State</th><th>CMBS Deal</th><th style="text-align:right">Amount</th><th>Maturity</th><th>Status</th><th style="text-align:center;min-width:130px">Actions</th>';
    html += '</tr></thead><tbody>';
    for (const l of maturityLoans.slice(0, 75)) {
      const prop = propMap[l.property_id] || {};
      const mat = l.maturity_date ? new Date(l.maturity_date).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : '—';
      const isPastDue = l.maturity_date && new Date(l.maturity_date) < now;
      const matColor = isPastDue ? 'var(--red)' : (new Date(l.maturity_date) <= oneYr ? '#f87171' : 'var(--text)');
      // Build a detail object that combines loan + property data for showDetail
      const detailObj = Object.assign({}, prop, l, { address: prop.address, city: prop.city, state: prop.state, agency: prop.agency || prop.agency_full_name });
      html += '<tr class="clickable-row" onclick=\'showDetail(' + safeJSON(detailObj) + ', "gov-lead")\'>';
      html += '<td style="font-weight:500">' + esc(prop.address || '—') + '</td>';
      html += '<td>' + esc(prop.city || '—') + '</td>';
      html += '<td>' + esc(prop.state || '—') + '</td>';
      html += '<td style="font-size:12px;color:var(--text2)">' + esc(l.index_name || l.loan_type || '—') + '</td>';
      html += '<td style="text-align:right;font-weight:600">' + (l.loan_amount ? fmt(parseFloat(l.loan_amount)) : '—') + '</td>';
      html += '<td style="color:' + matColor + ';font-weight:600">' + mat + (isPastDue ? ' (past due)' : '') + '</td>';
      html += '<td>' + esc(l.status || '—') + '</td>';
      html += '<td style="text-align:center" onclick="event.stopPropagation()">';
      html += '<div style="display:flex;gap:4px;justify-content:center">';
      html += '<button class="gov-row-action" onclick=\'govQuickLogActivity(' + safeJSON(detailObj) + ', "loan")\' title="Log a call or note for this property">📞 Log</button>';
      html += '<button class="gov-row-action accent" onclick=\'govQuickAddToPipeline(' + safeJSON(detailObj) + ')\' title="Add or update this property in the prospect pipeline">🎯 Pipeline</button>';
      html += '</div></td>';
      html += '</tr>';
    }
    html += '</tbody></table></div>';
    if (maturityLoans.length > 75) {
      html += '<div style="text-align:center;padding:12px;color:var(--text3);font-size:13px">Showing 75 of ' + maturityLoans.length + ' loans</div>';
    }
    html += '</div>';
  } else {
    html += '<div class="widget"><div style="text-align:center;padding:24px;color:var(--text3)">No loans match this maturity filter</div></div>';
  }

  html += '</div>';
  return html;
}
// ============================================================================
// GOVERNMENT PLAYERS (Top Buyers, Sellers, Brokers)
// ============================================================================

let govPlayersView = 'buyers';

function renderGovPlayers() {
  let html = '<div class="biz-section">';

  // View toggle pills
  html += '<div class="pills" style="margin-bottom: 20px;">';
  ['buyers', 'sellers', 'brokers'].forEach(view => {
    const active = govPlayersView === view ? ' active' : '';
    html += '<button class="pill' + active + '" onclick="govPlayersView=\'' + view + '\';renderGovTab()">' + view.charAt(0).toUpperCase() + view.slice(1) + '</button>';
  });
  html += '</div>';

  // Normalize entity names to merge variants (e.g., "Boyd Watterson" + "Boyd Watterson Global")
  function normalizeEntity(name) {
    if (!name) return '';
    let n = name.trim().toUpperCase()
      .replace(/,?\s*(LLC|LP|INC\.?|CORP\.?|L\.?P\.?|L\.?L\.?C\.?|LTD\.?|CO\.?)$/i, '')
      .replace(/\s+/g, ' ').trim();
    // Merge known entity families
    if (n.startsWith('BOYD WATTERSON')) return 'BOYD WATTERSON';
    if (n.startsWith('EASTERLY')) return 'EASTERLY';
    if (n.startsWith('TANENBAUM') || n.startsWith('GARDNER-TANNENBAUM') || n.startsWith('GARDNER TANNENBAUM')) return 'TANENBAUM / GARDNER-TANNENBAUM';
    if (n.startsWith('NGP')) return 'NGP CAPITAL';
    if (n.startsWith('RMR')) return 'RMR';
    return n;
  }

  // Prefer the full lazy-loaded v_sales_comps (2155 rows) over govData.salesComps (500-row limit)
  const sales = (govSalesComps && govSalesComps.length > 0) ? govSalesComps : (govData.salesComps || []);
  const ownership = govData.ownership || [];
  const listings = govData.listings || [];

  if (govPlayersView === 'buyers') {
    // Aggregate buyers from sales + ownership transfers
    const buyerMap = {};
    sales.forEach(r => {
      const buyer = r.buyer || r.purchasing_broker;
      if (buyer) {
        const key = normalizeEntity(buyer);
        if (!buyerMap[key]) buyerMap[key] = { name: buyer, deals: 0, volume: 0, records: [] };
        buyerMap[key].deals++;
        buyerMap[key].volume += (r.sold_price || r.price || r.sold_price_psf || 0);
        buyerMap[key].records.push(r);
      }
    });
    ownership.forEach(r => {
      if (r.new_owner) {
        const key = normalizeEntity(r.new_owner);
        if (!buyerMap[key]) buyerMap[key] = { name: r.new_owner, deals: 0, volume: 0, records: [] };
        buyerMap[key].deals++;
        buyerMap[key].volume += (r.sale_price || r.estimated_value || 0);
        buyerMap[key].records.push(r);
      }
    });

    const topBuyers = Object.values(buyerMap).sort((a, b) => b.deals - a.deals).slice(0, 50);
    html += renderPlayersTable(topBuyers, 'Buyer', 'gov');

  } else if (govPlayersView === 'sellers') {
    const sellerMap = {};
    sales.forEach(r => {
      if (r.seller) {
        const key = normalizeEntity(r.seller);
        if (!sellerMap[key]) sellerMap[key] = { name: r.seller, deals: 0, volume: 0, records: [] };
        sellerMap[key].deals++;
        sellerMap[key].volume += (r.sold_price || r.price || 0);
        sellerMap[key].records.push(r);
      }
    });
    ownership.forEach(r => {
      if (r.prior_owner) {
        const key = normalizeEntity(r.prior_owner);
        if (!sellerMap[key]) sellerMap[key] = { name: r.prior_owner, deals: 0, volume: 0, records: [] };
        sellerMap[key].deals++;
        sellerMap[key].volume += (r.sale_price || r.estimated_value || 0);
        sellerMap[key].records.push(r);
      }
    });

    const topSellers = Object.values(sellerMap).sort((a, b) => b.deals - a.deals).slice(0, 50);
    html += renderPlayersTable(topSellers, 'Seller', 'gov');

  } else {
    // Brokers from sales + listings
    // Filter: skip non-brokered transactions (Direct, FORECLOSURE, etc.)
    const brokerMap = {};
    sales.forEach(r => {
      // Use transaction_type if available (from Prompt 1 migration); otherwise fall back to string check
      const txType = r.transaction_type;
      if (txType && txType !== 'brokered') return;
      // Prefer enriched broker name (e.g., "TRAVIS TRAUTVETTER — CUSHMAN & WAKEFIELD") over raw first-name-only
      const brokerRaw = r.listing_broker;
      const brokerEnriched = r.listing_broker_enriched;
      const broker = brokerEnriched || brokerRaw;
      if (!broker) return;
      // Skip known non-broker values (fallback for data not yet migrated)
      const bl = (brokerRaw || broker).trim().toUpperCase();
      if (['DIRECT', 'FORECLOSURE', 'AUCTION', 'REO', 'N/A', 'NONE', 'UNKNOWN'].includes(bl)) return;

      const key = normalizeEntity(broker);
      const nameQual = brokerEnriched ? 'full_name' : (r.listing_broker_name_quality || null);
      if (!brokerMap[key]) brokerMap[key] = { name: broker, deals: 0, volume: 0, records: [], nameQuality: nameQual };
      brokerMap[key].deals++;
      brokerMap[key].volume += (r.sold_price || r.price || 0);
      brokerMap[key].records.push(r);
      // Track name quality — enriched or full_name/company overrides first_only
      if (brokerEnriched || r.listing_broker_name_quality === 'full_name' || r.listing_broker_name_quality === 'company') {
        brokerMap[key].nameQuality = 'full_name';
      }
    });
    listings.forEach(r => {
      const broker = r.broker || r.listing_agent || r.source;
      if (broker) {
        const key = normalizeEntity(broker);
        if (!brokerMap[key]) brokerMap[key] = { name: broker, deals: 0, volume: 0, records: [], nameQuality: null };
        brokerMap[key].deals++;
        brokerMap[key].volume += (r.asking_price || 0);
        brokerMap[key].records.push(r);
      }
    });

    const topBrokers = Object.values(brokerMap).sort((a, b) => b.deals - a.deals).slice(0, 50);
    html += renderPlayersTable(topBrokers, 'Broker', 'gov');
  }

  html += '</div>';
  return html;
}

let govPlayersExpandedIdx = -1; // which player row is expanded (-1 = none)
let govPlayersSearch = ''; // search filter for players table

function renderPlayersTable(players, roleLabel, project) {
  let html = '<div class="gov-metrics">';
  html += metricHTML('Total ' + roleLabel + 's', fmtN(players.length), 'unique entities', 'blue');
  const topDealCount = players[0]?.deals || 0;
  const topVolume = players.reduce((s, p) => s + p.volume, 0);
  html += metricHTML('Top ' + roleLabel, players[0]?.name?.substring(0, 25) || '—', topDealCount + ' deals', 'green');
  html += metricHTML('Total Volume', fmt(topVolume), 'across all ' + roleLabel.toLowerCase() + 's', 'yellow');
  html += '</div>';

  // Search filter
  html += '<div style="margin-bottom:12px">';
  html += '<input type="text" id="playersSearchInput" placeholder="Filter ' + roleLabel.toLowerCase() + 's by name..." value="' + esc(govPlayersSearch) + '" style="width:100%;max-width:400px;padding:8px 12px;border:1px solid var(--border);border-radius:6px;background:var(--surface);color:var(--text);font-size:14px" oninput="govPlayersSearch=this.value;govPlayersExpandedIdx=-1;renderGovTab()" />';
  html += '</div>';

  // Apply search filter
  const searchTerm = (govPlayersSearch || '').toLowerCase();
  const filtered = searchTerm ? players.filter(p => (p.name || '').toLowerCase().includes(searchTerm)) : players;

  html += '<div class="table-wrapper"><div class="data-table">';
  html += '<div class="table-row" style="font-weight: 600; border-bottom: 2px solid var(--border);">';
  html += '<div style="flex: 3;">' + roleLabel + '</div>';
  html += '<div style="flex: 1; text-align: right;">Deals</div>';
  html += '<div style="flex: 2; text-align: right;">Total Volume</div>';
  html += '<div style="flex: 2;">Most Recent</div>';
  html += '</div>';

  filtered.forEach((p, idx) => {
    const isExpanded = govPlayersExpandedIdx === idx;
    const latestRecord = p.records[0] || {};

    // Main row — click to expand/collapse portfolio
    const nameQualityBadge = p.nameQuality === 'first_only' ? ' <span style="font-size:10px;background:#fbbf24;color:#000;padding:1px 5px;border-radius:3px;margin-left:4px" title="First name only — needs enrichment">PARTIAL</span>' : '';
    html += '<div class="table-row clickable-row" style="' + (isExpanded ? 'background:var(--surface2);border-left:3px solid var(--accent);' : '') + '" onclick="govPlayersExpandedIdx=' + (isExpanded ? '-1' : idx) + ';renderGovTab()">';
    html += '<div style="flex: 3;"><span style="color: var(--text2); margin-right: 8px;">' + (isExpanded ? '&#9660;' : '&#9654;') + '</span><span style="color: var(--text2); margin-right: 6px;">#' + (idx + 1) + '</span>' + esc(p.name) + nameQualityBadge + '</div>';
    html += '<div style="flex: 1; text-align: right; color: var(--accent);">' + p.deals + '</div>';
    html += '<div style="flex: 2; text-align: right;">' + fmt(p.volume) + '</div>';
    html += '<div style="flex: 2; color: var(--text2);">' + esc(latestRecord.address || latestRecord.facility_name || '—') + '</div>';
    html += '</div>';

    // Expanded portfolio panel
    if (isExpanded) {
      html += '<div style="background:var(--surface);border-left:3px solid var(--accent);padding:12px 16px;margin-bottom:4px">';
      html += '<div style="font-weight:600;margin-bottom:8px;font-size:14px">' + esc(p.name) + ' — Portfolio (' + p.records.length + ' deals)</div>';

      // Portfolio sub-table
      html += '<div class="gov-table-card" style="margin-bottom:8px"><table class="gov-table" style="font-size:13px"><thead><tr>';
      html += '<th>Address</th><th>City</th><th>State</th><th style="text-align:right">Price</th><th>Date</th>';
      html += '</tr></thead><tbody>';

      const sortedRecords = p.records.slice().sort((a, b) => {
        const dA = a.sale_date || a.sold_date || a.recording_date || '';
        const dB = b.sale_date || b.sold_date || b.recording_date || '';
        return dB.localeCompare(dA); // newest first
      });

      for (const r of sortedRecords.slice(0, 25)) {
        const addr = r.address || r.facility_name || '—';
        const city = r.city || '—';
        const state = r.state || '—';
        const price = r.sold_price || r.price || r.sale_price || r.estimated_value || 0;
        const date = r.sale_date || r.sold_date || r.recording_date || '—';
        const dateDisplay = date !== '—' ? new Date(date).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : '—';
        const source = project === 'gov' ? (r.lead_id ? 'gov-lead' : 'gov-ownership') : 'dia-clinic';

        html += '<tr class="clickable-row" onclick=\'event.stopPropagation();showDetail(' + safeJSON(r) + ', "' + source + '")\'>';
        html += '<td style="font-weight:500">' + esc(addr) + '</td>';
        html += '<td>' + esc(city) + '</td>';
        html += '<td>' + esc(state) + '</td>';
        html += '<td style="text-align:right">' + (price ? fmt(price) : '—') + '</td>';
        html += '<td>' + dateDisplay + '</td>';
        html += '</tr>';
      }
      if (sortedRecords.length > 25) {
        html += '<tr><td colspan="5" style="text-align:center;color:var(--text3);font-style:italic">Showing 25 of ' + sortedRecords.length + ' deals</td></tr>';
      }
      html += '</tbody></table></div>';
      html += '</div>';
    }
  });

  if (filtered.length === 0) {
    html += '<div class="table-empty">' + (searchTerm ? 'No ' + roleLabel.toLowerCase() + 's match "' + esc(searchTerm) + '"' : 'No ' + roleLabel.toLowerCase() + ' data available') + '</div>';
  }

  html += '</div></div>';
  return html;
}

// ============================================================================
// GOVERNMENT SEARCH
// ============================================================================

let govSearchTerm = '';
let govSearchResults = null;
let govSearching = false;

function renderGovSearch() {
  let html = '<div class="biz-section">';
  html += '<div class="search-bar">';
  html += '<input type="text" id="govSearchInput" placeholder="Search by address, tenant, city, state, lessor, contact..." value="' + esc(govSearchTerm) + '" />';
  html += '<button onclick="execGovSearch()">Search</button>';
  html += '</div>';

  if (govSearching) {
    html += '<div class="search-loading">Searching across all government records...</div>';
  } else if (govSearchResults === null) {
    html += '<div class="search-empty">';
    html += '<div class="search-empty-icon">&#128269;</div>';
    html += '<p>Search across ownership records, prospect leads, listings, contacts, and properties</p>';
    html += '</div>';
  } else {
    const { ownership, leads, listings, contacts, properties } = govSearchResults;
    const total = ownership.length + leads.length + listings.length + contacts.length + properties.length;

    if (total === 0) {
      html += '<div class="search-empty"><p>No results found for "' + esc(govSearchTerm) + '"</p></div>';
    } else {
      html += '<div style="color: var(--text2); font-size: 13px; margin-bottom: 16px;">' + total + ' result' + (total !== 1 ? 's' : '') + ' found</div>';

      // Store flat search results array for onclick references (avoids massive inline JSON in DOM)
      window._govSearchFlat = [];
      window._govSearchSources = [];
      function pushSearchRef(record, source) {
        var idx = window._govSearchFlat.length;
        window._govSearchFlat.push(record);
        window._govSearchSources.push(source);
        return idx;
      }

      if (leads.length > 0) {
        html += '<div class="search-results-section"><h4>Prospect Leads (' + leads.length + ')</h4>';
        leads.forEach(r => {
          var idx = pushSearchRef(r, 'gov-lead');
          html += '<div class="search-card" onclick="showDetail(window._govSearchFlat[' + idx + '], window._govSearchSources[' + idx + '])">';
          html += '<div class="search-card-header"><span class="search-card-title">' + esc(norm(r.address) || norm(r.tenant_agency) || '—') + '</span>';
          html += '<span class="search-card-badge" style="background: rgba(52,211,153,0.15); color: #34d399;">Lead</span></div>';
          html += '<div class="search-card-meta">';
          if (r.city || r.state) html += '<span>' + esc((norm(r.city) || '') + (r.city && r.state ? ', ' : '') + (r.state || '')) + '</span>';
          if (r.tenant_agency) html += '<span>Tenant: ' + esc(norm(r.tenant_agency)) + '</span>';
          if (r.lessor_name) html += '<span>Owner: ' + esc(norm(r.lessor_name)) + '</span>';
          if (r.recorded_owner) html += '<span>Recorded: ' + esc(norm(r.recorded_owner)) + '</span>';
          if (r.asking_price) html += '<span>Asking: ' + fmt(r.asking_price) + '</span>';
          if (r.pipeline_status) html += '<span>Stage: ' + esc(cleanLabel(r.pipeline_status)) + '</span>';
          html += '</div>';
          html += '<div style="display:flex;gap:4px;margin-top:6px" onclick="event.stopPropagation()">';
          html += '<button class="gov-row-action" onclick="showDetail(window._govSearchFlat[' + idx + '], \'gov-lead\', \'Ownership\')" title="View owner & contacts">📞 Contacts</button>';
          html += '<button class="gov-row-action accent" onclick="showDetail(window._govSearchFlat[' + idx + '], \'gov-lead\', \'Intel\')" title="Research & intel">🔍 Intel</button>';
          html += '</div></div>';
        });
        html += '</div>';
      }

      if (ownership.length > 0) {
        html += '<div class="search-results-section"><h4>Ownership Records (' + ownership.length + ')</h4>';
        ownership.forEach(r => {
          var idx = pushSearchRef(r, 'gov-ownership');
          html += '<div class="search-card" onclick="showDetail(window._govSearchFlat[' + idx + '], window._govSearchSources[' + idx + '])">';
          html += '<div class="search-card-header"><span class="search-card-title">' + esc(norm(r.address) || r.lease_number || '—') + '</span>';
          html += '<span class="search-card-badge" style="background: rgba(108,140,255,0.15); color: #6c8cff;">Ownership</span></div>';
          html += '<div class="search-card-meta">';
          if (r.city || r.state) html += '<span>' + esc((norm(r.city) || '') + (r.city && r.state ? ', ' : '') + (r.state || '')) + '</span>';
          if (r.prior_owner) html += '<span>From: ' + esc(norm(r.prior_owner)) + '</span>';
          if (r.new_owner) html += '<span>To: ' + esc(norm(r.new_owner)) + '</span>';
          if (r.estimated_value) html += '<span>Value: ' + fmt(r.estimated_value) + '</span>';
          html += '</div>';
          html += '<div style="display:flex;gap:4px;margin-top:6px" onclick="event.stopPropagation()">';
          html += '<button class="gov-row-action" onclick="showDetail(window._govSearchFlat[' + idx + '], \'gov-ownership\', \'Ownership\')" title="View owner & contacts">📞 Contacts</button>';
          html += '<button class="gov-row-action accent" onclick="showDetail(window._govSearchFlat[' + idx + '], \'gov-ownership\', \'Intel\')" title="Research & intel">🔍 Intel</button>';
          html += '</div></div>';
        });
        html += '</div>';
      }

      if (listings.length > 0) {
        html += '<div class="search-results-section"><h4>Listings (' + listings.length + ')</h4>';
        listings.forEach(r => {
          var idx = pushSearchRef(r, 'gov-listing');
          html += '<div class="search-card" onclick="showDetail(window._govSearchFlat[' + idx + '], window._govSearchSources[' + idx + '])">';
          html += '<div class="search-card-header"><span class="search-card-title">' + esc(norm(r.address) || norm(r.tenant_agency) || '—') + '</span>';
          html += '<span class="search-card-badge" style="background: rgba(251,191,36,0.15); color: #fbbf24;">Listing</span></div>';
          html += '<div class="search-card-meta">';
          if (r.city || r.state) html += '<span>' + esc((norm(r.city) || '') + (r.city && r.state ? ', ' : '') + (r.state || '')) + '</span>';
          if (r.tenant_agency) html += '<span>Tenant: ' + esc(norm(r.tenant_agency)) + '</span>';
          if (r.seller_name) html += '<span>Owner: ' + esc(norm(r.seller_name)) + '</span>';
          if (r.asking_price) html += '<span>Asking: ' + fmt(r.asking_price) + '</span>';
          if (r.listing_status) html += '<span>Status: ' + esc(cleanLabel(r.listing_status)) + '</span>';
          html += '</div>';
          html += '<div style="display:flex;gap:4px;margin-top:6px" onclick="event.stopPropagation()">';
          html += '<button class="gov-row-action" onclick="showDetail(window._govSearchFlat[' + idx + '], \'gov-listing\', \'Ownership\')" title="View owner & contacts">📞 Contacts</button>';
          html += '<button class="gov-row-action accent" onclick="showDetail(window._govSearchFlat[' + idx + '], \'gov-listing\', \'Intel\')" title="Research & intel">🔍 Intel</button>';
          html += '</div></div>';
        });
        html += '</div>';
      }

      if (contacts.length > 0) {
        html += '<div class="search-results-section"><h4>Contacts (' + contacts.length + ')</h4>';
        contacts.forEach(r => {
          var idx = pushSearchRef(r, 'gov-lead');
          html += '<div class="search-card" onclick="showDetail(window._govSearchFlat[' + idx + '], window._govSearchSources[' + idx + '])" style="cursor:pointer;">';
          html += '<div class="search-card-header"><span class="search-card-title">' + esc(norm(r.name) || '—') + '</span>';
          html += '<span class="search-card-badge" style="background: rgba(167,139,250,0.15); color: #a78bfa;">Contact</span></div>';
          html += '<div class="search-card-meta">';
          if (r.contact_type) html += '<span>' + esc(norm(r.contact_type)) + '</span>';
          if (r.total_volume) html += '<span>Volume: ' + fmt(r.total_volume) + '</span>';
          if (r.phone) html += '<span>' + esc(r.phone) + '</span>';
          if (r.email) html += '<span>' + esc(r.email) + '</span>';
          html += '</div>';
          html += '<div style="display:flex;gap:4px;margin-top:6px" onclick="event.stopPropagation()">';
          html += '<button class="gov-row-action" onclick="showDetail(window._govSearchFlat[' + idx + '], \'gov-lead\', \'Ownership\')" title="View owner & contacts">📞 Contacts</button>';
          html += '<button class="gov-row-action accent" onclick="showDetail(window._govSearchFlat[' + idx + '], \'gov-lead\', \'Intel\')" title="Research & intel">🔍 Intel</button>';
          html += '</div></div>';
        });
        html += '</div>';
      }

      if (properties.length > 0) {
        html += '<div class="search-results-section"><h4>Properties (' + properties.length + ')</h4>';
        properties.forEach(r => {
          var idx = pushSearchRef(r, 'gov-ownership');
          html += '<div class="search-card" onclick="showDetail(window._govSearchFlat[' + idx + '], window._govSearchSources[' + idx + '])">';
          html += '<div class="search-card-header"><span class="search-card-title">' + esc(norm(r.address) || norm(r.property_name) || '—') + '</span>';
          html += '<span class="search-card-badge" style="background: rgba(34,211,238,0.15); color: #22d3ee;">Property</span></div>';
          html += '<div class="search-card-meta">';
          if (r.city || r.state) html += '<span>' + esc((norm(r.city) || '') + (r.city && r.state ? ', ' : '') + (r.state || '')) + '</span>';
          if (r.property_type) html += '<span>Type: ' + esc(norm(r.property_type)) + '</span>';
          html += '</div>';
          html += '<div style="display:flex;gap:4px;margin-top:6px" onclick="event.stopPropagation()">';
          html += '<button class="gov-row-action" onclick="showDetail(window._govSearchFlat[' + idx + '], \'gov-ownership\', \'Ownership\')" title="View owner & contacts">📞 Contacts</button>';
          html += '<button class="gov-row-action accent" onclick="showDetail(window._govSearchFlat[' + idx + '], \'gov-ownership\', \'Intel\')" title="Research & intel">🔍 Intel</button>';
          html += '</div></div>';
        });
        html += '</div>';
      }
    }
  }

  html += '</div>';

  // Attach enter-key handler after render
  setTimeout(() => {
    const input = document.getElementById('govSearchInput');
    if (input) {
      input.onkeydown = e => { if (e.key === 'Enter') execGovSearch(); };
      input.focus();
    }
  }, 0);

  return html;
}

async function execGovSearch() {
  const input = document.getElementById('govSearchInput');
  if (!input) return;
  const term = input.value.trim();
  if (!term) return;

  govSearchTerm = term;
  govSearching = true;
  renderGovTab();

  // Sanitize for PostgREST ilike filter — strip syntax-breaking characters
  const safeTerm = term.replace(/[*()',\\]/g, '');
  if (!safeTerm) { govSearching = false; renderGovTab(); return; }
  const like = '*' + safeTerm + '*';
  try {
    const [ownership, leads, listings, contacts, properties] = await Promise.all([
      govQuery('ownership_history', '*', { filter: 'or=(address.ilike.' + like + ',city.ilike.' + like + ',state.ilike.' + like + ',new_owner.ilike.' + like + ',prior_owner.ilike.' + like + ',recorded_owner_name.ilike.' + like + ')', limit: 25 }).catch(e => { console.warn('[GovSearch] ownership query failed:', e.message); return { data: [] }; }),
      govQuery('prospect_leads', '*', { filter: 'or=(address.ilike.' + like + ',city.ilike.' + like + ',tenant_agency.ilike.' + like + ',lessor_name.ilike.' + like + ',recorded_owner.ilike.' + like + ',contact_name.ilike.' + like + ')', limit: 25 }).catch(e => { console.warn('[GovSearch] leads query failed:', e.message); return { data: [] }; }),
      govQuery('available_listings', '*', { filter: 'or=(address.ilike.' + like + ',city.ilike.' + like + ',tenant_agency.ilike.' + like + ')', limit: 25 }).catch(e => { console.warn('[GovSearch] listings query failed:', e.message); return { data: [] }; }),
      govQuery('contacts', '*', { filter: 'or=(name.ilike.' + like + ',contact_type.ilike.' + like + ',phone.ilike.' + like + ',email.ilike.' + like + ')', limit: 25 }).catch(e => { console.warn('[GovSearch] contacts query failed:', e.message); return { data: [] }; }),
      govQuery('properties', '*', { filter: 'or=(address.ilike.' + like + ',city.ilike.' + like + ',state.ilike.' + like + ',agency.ilike.' + like + ')', limit: 25 }).catch(e => { console.warn('[GovSearch] properties query failed:', e.message); return { data: [] }; })
    ]);

    govSearchResults = {
      ownership: ownership.data || [],
      leads: leads.data || [],
      listings: listings.data || [],
      contacts: contacts.data || [],
      properties: properties.data || []
    };
    govSearching = false;
    renderGovTab();
  } catch (err) {
    showToast('Search failed: ' + err.message, 'error');
    govSearching = false;
    renderGovTab();
  }
}

// ============================================================================
// OWNERSHIP DETAIL ACTIONS
// ============================================================================

/**
 * Update ownership research_status from the detail panel dropdown
 */
window.govUpdateOwnershipStatus = async function(ownershipId) {
  if (!ownershipId) { showToast('No record ID — cannot update', 'error'); return; }
  const sel = document.getElementById('govOwnerStatus');
  if (!sel) return;
  const newStatus = sel.value;
  try {
    await govPatch('ownership_history', 'id=eq.' + ownershipId, { research_status: newStatus });
    showToast('Status updated to ' + cleanLabel(newStatus), 'success');
  } catch (err) {
    showToast('Status update failed: ' + err.message, 'error');
  }
};

/**
 * Log a call activity on a lead/contact record
 */
window.govLogCall = async function(leadId) {
  if (!leadId) { showToast('No record ID', 'error'); return; }
  const notes = prompt('Call notes (optional):');
  if (notes === null) return; // user cancelled
  try {
    await govPatch('prospect_leads', 'id=eq.' + leadId, {
      last_contact_date: new Date().toISOString(),
      last_contact_notes: (notes || 'Call logged from dashboard'),
      last_contact_type: 'phone'
    });
    showToast('Call logged', 'success');
  } catch (err) {
    showToast('Log call failed: ' + err.message, 'error');
  }
};

/**
 * Open email client for a lead/contact
 */
window.govSendEmail = function(record) {
  const email = record.contact_email || record.email || '';
  if (!email) { showToast('No email address on record', 'warning'); return; }
  const subject = encodeURIComponent('Re: ' + (record.address || record.tenant_agency || 'Property Inquiry'));
  window.open('mailto:' + email + '?subject=' + subject, '_blank');
};

// ============================================================================
// ROUND 49: INLINE ROW ACTIONS — Quick Log Activity & Open Pipeline
// ============================================================================

/**
 * Open the detail panel directly to the Ownership tab for a record.
 * One click from the Leases or Loans table → see owner + contacts, ready to call.
 */
window.govQuickLogActivity = function(record, context) {
  const enriched = Object.assign({}, record, { _actionContext: context });
  showDetail(enriched, 'gov-lead', 'Ownership');
};

/**
 * Open the detail panel directly to the Intel tab for a record.
 * One click from the Leases or Loans table → research intake + pipeline management.
 */
window.govQuickAddToPipeline = function(record) {
  showDetail(record, 'gov-lead', 'Intel');
};
