// ============================================================================
// DIALYSIS DASHBOARD MODULE
// Vanilla JavaScript implementation of Dialysis dashboard
// Loaded after index.html, overrides placeholder functions
// ============================================================================

// ============================================================================
// MODULE STATE
// ============================================================================

let diaCharts = {};
let diaResearchMode = 'quarantine'; // pipeline order: quarantine → unmatched → clarification → property → lease → clinic_leads → staleness → run_health
let diaResearchIdx = 0;
let diaPropertyFilter = { review_type: null, state: null, selectedIdx: undefined };
let diaLeaseFilter = { priority: null, selectedIdx: undefined, parentOrg: null, hideReviewed: false, viewMode: 'portfolio' };
let diaLeaseBackfillStep = 0; // step counter for 5-step lease backfill workflow
let diaClinicLeadFilter = { category: null, tier: null, state: null, selectedIdx: undefined, hideResolved: true };
let diaClinicLeadStep = 0; // step counter for 5-step clinic lead workflow
let diaClinicLeadQueue = null; // lazy-loaded from v_clinic_research_priority
let diaClinicLeadLoading = false;
let diaChangeFilter = 'all'; // 'all' | 'added' | 'removed' | 'persistent'
let diaCmsData = null;  // lazy-loaded from v_cms_data
let diaCmsLoading = false;
let diaCmsSearch = '';
let diaCmsPage = 0;
let diaCmsSort = { col: 'est_in_center_patients', dir: 'desc' };
let diaCmsStateFilter = '';
let diaCmsOperatorFilter = '';
let diaCmsModalityFilter = '';
const DIA_CMS_PAGE_SIZE = 50;
let diaCmsSelectedIdx = undefined; // selected row in CMS table
let diaNpiFilter = null; // filter by signal_type
let diaNpiSelectedIdx = undefined; // selected row in NPI table
let diaNpiSeverityFilter = 'actionable'; // (legacy "All Signals" mode filter)
let diaNpiSelectedIds = new Set(); // bulk-select state, keyed by clinic_id
// Round 76eg: Inventory Changes tab — added/removed clinic BD card feed
let diaInventoryFilter = 'all';         // 'all' | 'added' | 'removed'
let diaInventoryDismissed = new Set();  // session-only dismiss state, keyed by clinic_id
// Round 76ef: 3-mode UI — BD events default, Cleanup queue for hygiene, All Signals = legacy
let diaNpiMode = 'bd';                  // 'bd' | 'cleanup' | 'all'
let diaNpiCleanupSubMode = 'missing';   // 'missing' | 'duplicate'
let diaNpiBdWindowDays = 7;             // 7 | 30 | 90 | 0 (all-time)
let diaNpiLookupCache = null;           // Map<clinic_id, latest npi_registry_lookups row>
let diaNpiRegistryCache = null;         // Map<npi, npi_registry row> for dup-cluster NPIs
let diaNpiCleanupLoading = false;
let diaSalesView = 'comps'; // 'comps' | 'available'
let diaOverviewStats = null;   // lazy-loaded single-row mv_dia_overview_stats (UI Phase 2)
let _diaOverviewStatsLoading = false;
let diaSalesComps = null;   // lazy-loaded from sales_transactions + properties + leases
let diaAvailListings = null; // lazy-loaded from available_listings (on-market only)
let diaOnMarketIds = null; // Set of listing_id from v_dia_on_market (T9d canonical CURRENT on-market set; ~184). null = not loaded.
let diaFinancialEstimates = null; // lazy-loaded from clinic_financial_estimates
let diaPatientCounts = null; // lazy-loaded from v_facility_patient_counts_latest
// Round 76eh (2026-04-29): in-flight sentinels prevent duplicate concurrent
// lazy-loads when renderDiaOverview() is called twice before the first loader
// resolves (tab switches, post-render re-mounts). Without these, two parallel
// pagination loops would each call `xxx = all` and trigger their own
// re-render, causing card values to visibly flicker / bounce.
let _diaFinancialEstimatesLoading = false;
let _diaPatientCountsLoading = false;
let _diaAvailListingsLoading = false;
let _diaOwnershipCoverageLoading = false;
let _diaSjcDealBookLoading = false;
// Cached SJC deal-book summary (tiles + by-year/teams/recent HTML). Lets a
// re-render of renderDiaOverview paint the 4 value tiles + tables from cache
// instead of leaving them stuck on the '...' placeholder once the one-shot
// async fetch has run (DIA_OVERVIEW_TILE_AUDIT Unit 1).
let diaSjcDealBook = null;
let _diaListingConfirmLoading = false;
let _diaLlcQueueLoading = false;
let diaSalesLoading = false;
let diaSalesSearch = '';
const NM_TEAM = ['kelly largent', 'sarah martin', 'scott briggs', 'nathanael berwaldt'];
let diaSalesPage = 0;
// Default sort: newest first. Sales Comps uses sold_date; Available uses
// listing_date. Users can click any column header to override; "Reset Sort"
// returns to this default.
function diaSalesDefaultSort(view) {
  return { col: view === 'available' ? 'listing_date' : 'sold_date', dir: 'desc' };
}
let diaSalesSort = diaSalesDefaultSort('comps'); // column sort state
let diaSalesStateFilter = ''; // state filter
let diaFilteredSalesData = [];
const DIA_SALES_PAGE_SIZE = 50;

// Properties tab state — server-side paginated
let diaPropertiesData = null;        // current page rows only
let diaPropertiesTotalCount = 0;     // server-side filtered count
let diaPropertiesLoading = false;
let diaPropertiesSearch = '';
let diaPropertiesPage = 0;
let diaPropertiesSort = { col: 'address', dir: 'asc' };
let diaPropertiesStateFilter = '';
let diaPropertiesSummary = null;     // { states, withSFCount, avgSF, total }
let diaPropertiesRequestId = 0;      // race-condition guard
const DIA_PROPERTIES_PAGE_SIZE = 25;

// Pipeline/Ops Research Modes
let diaUnmatchedQueue = null;
let diaUnmatchedLoading = false;
let diaUnmatchedIdx = 0;
let diaQuarantineQueue = null;
let diaQuarantineLoading = false;
let diaQuarantineIdx = 0;
let diaClarificationQueue = null;
let diaClarificationLoading = false;
let diaClarificationIdx = 0;
let diaStalenessData = null;
let diaStalenessLoading = false;
let diaRunHealthData = null;
let diaRunHealthLoading = false;
// Round 76cx Phase 2: listing verification dashboard digest (single-row view).
let diaVerificationSummary = null;
let diaVerificationSummaryLoading = false;
// Round 76et-F: drill-down panel for recent verification rows. Filterable
// by 'all' | 'evidence' | 'cron' to match the breakout in the summary card.
let diaRecentVerifications = null;
let diaRecentVerificationsLoading = false;
let diaRecentVerificationsFilter = 'all';
let diaIntakeQueue = null;
let diaIntakeLoading = false;
let diaIntakeIdx = 0;

// Ownership Research backlog (Layer H.1 view + H.2/H.3/H.4 canonical clusters).
// Lists the recorded_owner / canonical entity research worklist — resolve
// one canonical and you fix multiple properties.
let diaOwnershipBacklog       = null;   // array of cluster rows
let diaOwnershipBacklogLoading = false;
let diaOwnershipFilterState   = '';     // optional state filter (e.g. 'TX')
let diaOwnershipFilterText    = '';     // optional name-substring filter

// ============================================================================
// QUERY FUNCTION
// ============================================================================

/**
 * Query Dialysis Supabase via REST API
 * @param {string} table - view or table name
 * @param {string} select - columns to select (e.g., '*' or 'col1,col2')
 * @param {object} params - {filter, order, limit, offset}
 */
async function diaQuery(table, select, params = {}) {
  // Query via serverless proxy — keeps secret key server-side
  const { filter, filter2, order, limit = 1000, offset = 0, includeCount = false } = params;

  const url = new URL('/api/dia-query', window.location.origin);
  url.searchParams.set('table', table);
  url.searchParams.set('select', select);
  if (filter) url.searchParams.set('filter', filter);
  if (filter2) url.searchParams.set('filter2', filter2);
  if (order) url.searchParams.set('order', order);
  if (limit !== undefined) url.searchParams.set('limit', limit);
  if (offset !== undefined) url.searchParams.set('offset', offset);
  // QA-27 (2026-05-18): callers can opt-in to count=exact via includeCount.
  // Default remains count=false to keep view queries fast (the legacy comment
  // applies: views compute from 1M+ row tables, count doubles query cost).
  // When includeCount is true, the helper returns {data, count} instead of
  // just the rows array — used by the parallel-pagination path in
  // diaQueryAll to learn the total without separate count query.
  if (!includeCount) url.searchParams.set('count', 'false');

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000);
  try {
    const response = await fetch(url.toString(), { signal: controller.signal });
    clearTimeout(timeout);

    if (!response.ok) {
      const errBody = await response.text();
      console.error(`diaQuery ${table}: HTTP ${response.status}`, errBody);
      return includeCount ? { data: [], count: 0 } : [];
    }

    const result = await response.json();
    if (includeCount) return { data: result.data || [], count: result.count || 0 };
    return result.data || [];
  } catch (err) {
    clearTimeout(timeout);
    if (err.name === 'AbortError') { console.warn('diaQuery ' + table + ' timed out (30s)'); return includeCount ? { data: [], count: 0 } : []; }
    console.error('diaQuery error:', err);
    return includeCount ? { data: [], count: 0 } : [];
  }
}

// R2-W-6 (2026-05-19): reverted to serial pagination. QA-27's parallel fix
// (mirror of QA-26's govQueryAll) caused the same perf cliff that QA-33
// just rolled back on gov: ~N concurrent HTTP requests at page-load
// overwhelm Vercel/Supabase/browser. dia tables are smaller than gov
// (medicare_clinics 8.5k, true_owners 3.4k) so the regression is less
// dramatic, but the failure mode is identical when dashboards stack
// multiple diaQueryAll calls in Promise.all. Going back to one-at-a-time
// pagination — slower but predictable. A throttled-parallel approach
// (concurrency=4) is the better long-term fix; deferred for both gov + dia.
// Callers that need a true count (e.g. v_prospect_targets) keep using
// diaQuery directly with includeCount=true — that single call is fine.
async function diaQueryAll(table, select, params = {}) {
  let all = [];
  let offset = 0;
  const pageSize = 1000;  // PostgREST max-rows cap
  const maxTime = 120000; // 2-minute total timeout fuse
  const start = Date.now();
  while (true) {
    if (Date.now() - start > maxTime) {
      console.warn('diaQueryAll(' + table + ') total timeout after ' + Math.round((Date.now() - start) / 1000) + 's — returning ' + all.length + ' rows');
      break;
    }
    const rows = await diaQuery(table, select, { ...params, limit: pageSize, offset });
    all = all.concat(rows || []);
    if (!rows || rows.length < pageSize) break;
    offset += pageSize;
  }
  return all;
}

// Single-page fetch with count — for server-side pagination
async function diaQueryPage(table, select, params = {}) {
  const { filter, filter2, order, limit = 25, offset = 0 } = params;
  const url = new URL('/api/dia-query', window.location.origin);
  url.searchParams.set('table', table);
  url.searchParams.set('select', select);
  if (filter) url.searchParams.set('filter', filter);
  if (filter2) url.searchParams.set('filter2', filter2);
  if (order) url.searchParams.set('order', order);
  url.searchParams.set('limit', limit);
  url.searchParams.set('offset', offset);
  // Don't set count=false — backend will send Prefer: count=exact for total row count

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000);
  try {
    const response = await fetch(url.toString(), { signal: controller.signal });
    clearTimeout(timeout);
    if (!response.ok) {
      const errBody = await response.text();
      console.error('diaQueryPage ' + table + ': HTTP ' + response.status, errBody);
      return { data: [], count: 0 };
    }
    const result = await response.json();
    return { data: result.data || [], count: result.count || 0 };
  } catch (err) {
    clearTimeout(timeout);
    if (err.name === 'AbortError') console.warn('diaQueryPage ' + table + ' timed out (30s)');
    else console.error('diaQueryPage error:', err);
    return { data: [], count: 0 };
  }
}

// ============================================================================
// SALES COMPS LOADER
// ============================================================================
// The Sales Comps table queries EXCLUSIVELY from sales_transactions joined
// with properties (and leases). The legacy v_sales_comps view mixed in entity
// metadata sales_history, which produced duplicate rows (e.g. deed date vs
// CoStar recordation date), conflicting prices/cap rates, and stale RBA/land
// area values. sales_transactions is the authoritative source populated by the
// sidebar pipeline; this loader gates on exclude_from_market_metrics IS NOT TRUE
// which (post-20260529 invariant) means transaction_state='live' AND not
// stat-excluded — i.e. each unique real sale counted once. properties holds the canonical RBA/land
// area; leases holds the current rent/expiration data.
async function loadDiaSalesCompsFromTxns() {
  // Embed properties (1:1) and leases (1:many). Use !inner on properties so
  // orphan sales without a property drop out — v_sales_comps filtered those
  // too. Leases are a left-side embed so sales on vacant/land parcels still
  // show up.
  // Properties select now pulls operator + chain_canonical + medicare_id so
  // tenant fallback chain has more anchors when leases is empty and
  // properties.tenant is null (the legacy CSV import didn't populate it).
  // NOTE: sale_brokers loaded separately to avoid 3-level PostgREST embed
  // failures that silently return [] through the edge proxy.
  const select = [
    '*,',
    'properties!inner(property_id,address,city,state,zip_code,county,building_size,',
    'land_area,lot_sf,year_built,year_renovated,tenant,operator,chain_canonical,',
    'medicare_id,linked_medicare_facility_id,building_type,zoning,',
    'latitude,longitude,lease_bump_pct,lease_bump_interval_mo,',
    'anchor_rent,anchor_rent_source,',
    'leases(lease_id,tenant,leased_area,lease_start,lease_expiration,',
    'expense_structure,rent_per_sf,annual_rent,rent,renewal_options,is_active,',
    'status,data_source,source_confidence))',
  ].join('');

  // Sales + brokers + cross-source fallbacks (ownership_history, deed_records,
  // medicare_clinics) loaded in parallel. All are small relative to sales,
  // so the merge cost is negligible compared to the round-trip savings.
  const [salesPages, brokerMap, ohBySaleId, deedsByPropId, clinicByMedId, listingsByPropId] = await Promise.all([
    (async () => {
      let all = [];
      for (let pg = 0; pg <= 20; pg++) {
        const batch = await diaQuery('sales_transactions', select, {
          // Canonical comp gate (2026-05-29): exclude_from_market_metrics IS NOT
          // TRUE == transaction_state='live' AND not stat-excluded, because the
          // 20260529170000 migration enforces the invariant "non-live ⇒
          // excluded". This drops duplicate_superseded / ownership_stub /
          // needs_review rows that previously leaked into the comp counts and
          // TTM volume. See SALES_AND_AVAILABLE_COMPS_DEFINITION_AUDIT_2026-05-29.md.
          filter: 'exclude_from_market_metrics=not.is.true',
          // Value-weighted sort (Item #9 Phase A, 2026-05-17): biggest comps
          // surface first. Tiebreaker on sale_date keeps recency where prices
          // are equal/null.
          order: 'sold_price.desc.nullslast,sale_date.desc.nullslast',
          limit: 1000,
          offset: pg * 1000,
        });
        all = all.concat(batch || []);
        if (!batch || batch.length < 1000) break;
      }
      return all;
    })(),
    loadDiaSaleBrokers(),
    loadDiaOwnershipHistoryBySaleId(),
    loadDiaDeedRecordsByPropertyId(),
    loadDiaMedicareClinicsByMedId(),
    loadDiaAvailableListingsByPropertyId(),
  ]);

  // R4-D #7: reset the xref-conflict collector before the per-row pass so it
  // reflects this load only (normalizeSalesTxnRow appends to it).
  window._diaSalesCompXrefConflicts = [];
  const mapped = salesPages.map(r => {
    r.sale_brokers = brokerMap[r.sale_id] || [];
    return normalizeSalesTxnRow(r, {
      ohBySaleId,
      deedsByPropId,
      clinicByMedId,
      listingsByPropId,
    });
  });
  // R4-D #7: ONE summary line instead of N per-row warnings. The conflicts are
  // available on window._diaSalesCompXrefConflicts for the data-conflicts review
  // lane, and the canonical st↔ownership_history set is also surfaced in
  // dia v_data_quality_issues (issue_kind='sales_price_xref_conflict').
  const _xref = window._diaSalesCompXrefConflicts;
  if (_xref.length) {
    console.warn('[sales-comp xref] ' + _xref.length + ' price disagreement(s) this load — '
      + 'see window._diaSalesCompXrefConflicts / dia v_data_quality_issues (sales_price_xref_conflict).');
  }
  return mapped;
}

// -- Cross-source fallback loaders ------------------------------------------
//
// Each returns a lookup map. Failures degrade gracefully — if a secondary
// source is down or empty, we still produce comp rows from the primary
// sales_transactions + properties + leases join. We never replace a populated
// primary value with a secondary one; secondaries only fill nulls.

async function loadDiaSaleBrokers() {
  const sbSelect = 'sale_id,role,broker_id,brokers(broker_name,company)';
  const map = {};
  try {
    let sbAll = [];
    for (let pg = 0; pg <= 5; pg++) {
      const batch = await diaQuery('sale_brokers', sbSelect, { limit: 1000, offset: pg * 1000 });
      sbAll = sbAll.concat(batch || []);
      if (!batch || batch.length < 1000) break;
    }
    sbAll.forEach(sb => {
      if (!map[sb.sale_id]) map[sb.sale_id] = [];
      map[sb.sale_id].push(sb);
    });
  } catch(e) { console.warn('sale_brokers load failed:', e.message); }
  return map;
}

async function loadDiaOwnershipHistoryBySaleId() {
  // ownership_history has its own sold_price/cap_rate/recorded_owner_name —
  // a parallel record of the same transaction (sometimes populated when
  // sales_transactions is not, especially for legacy CSV imports).
  const map = {};
  try {
    // Only recorded_owner_id has a FK to recorded_owners (fk_ownership_recorded_owner).
    // true_owner_id is unenforced text, so we can't PostgREST-embed it — we
    // surface it as a raw uuid that the normalizer ignores. Buyer fallback
    // therefore goes through recorded_owners.name only.
    const ohSelect = 'sale_id,sold_price,cap_rate,rent,recorded_owner_id,true_owner_id,'
                   + 'recorded_owners(name)';
    let all = [];
    for (let pg = 0; pg <= 10; pg++) {
      const batch = await diaQuery('ownership_history', ohSelect, {
        filter: 'sale_id=not.is.null', limit: 1000, offset: pg * 1000,
      });
      all = all.concat(batch || []);
      if (!batch || batch.length < 1000) break;
    }
    all.forEach(oh => {
      if (oh.sale_id != null && !map[oh.sale_id]) map[oh.sale_id] = oh;
    });
  } catch(e) { console.warn('ownership_history fallback load failed:', e.message); }
  return map;
}

async function loadDiaDeedRecordsByPropertyId() {
  // Group deed_records by property_id. Each map entry is an array sorted
  // by recording_date desc so the per-row matcher can pick the deed closest
  // to the sale_date in O(n) scan.
  const map = {};
  try {
    const sel = 'property_id,recording_date,grantor,grantee,consideration,deed_type';
    let all = [];
    for (let pg = 0; pg <= 5; pg++) {
      const batch = await diaQuery('deed_records', sel, {
        filter: 'property_id=not.is.null', limit: 1000, offset: pg * 1000,
      });
      all = all.concat(batch || []);
      if (!batch || batch.length < 1000) break;
    }
    all.forEach(d => {
      const pid = d.property_id;
      if (!map[pid]) map[pid] = [];
      map[pid].push(d);
    });
    Object.keys(map).forEach(k => {
      map[k].sort((a, b) => String(b.recording_date || '').localeCompare(String(a.recording_date || '')));
    });
  } catch(e) { console.warn('deed_records fallback load failed:', e.message); }
  return map;
}

async function loadDiaMedicareClinicsByMedId() {
  // Tenant fallback of last resort: when properties.tenant + lease.tenant +
  // properties.operator + properties.chain_canonical are all null, the
  // linked CMS facility_name is the operator (e.g. "Davita Twin Falls
  // Dialysis Center").
  const map = {};
  try {
    const sel = 'medicare_id,facility_name';
    let all = [];
    for (let pg = 0; pg <= 20; pg++) {
      const batch = await diaQuery('medicare_clinics', sel, { limit: 1000, offset: pg * 1000 });
      all = all.concat(batch || []);
      if (!batch || batch.length < 1000) break;
    }
    all.forEach(m => { if (m.medicare_id) map[m.medicare_id] = m; });
  } catch(e) { console.warn('medicare_clinics fallback load failed:', e.message); }
  return map;
}

async function loadDiaAvailableListingsByPropertyId() {
  // available_listings is the HIGHEST-LEVERAGE cross-source — when a
  // property goes through CoStar listing capture, the listing carries the
  // broker / seller / asking cap that the deed-only sale row doesn't.
  // Audit on 2026-05-21 against dia found ~988 listing_broker fills, ~597
  // seller fills, ~335 cap_rate fills, and ~222 price fills available
  // from this source.
  const map = {};
  try {
    const sel = 'property_id,listing_date,off_market_date,sold_date,'
              + 'listing_broker,seller_name,sold_price,initial_price,last_price,'
              + 'cap_rate,initial_cap_rate,current_cap_rate,last_cap_rate';
    let all = [];
    for (let pg = 0; pg <= 10; pg++) {
      const batch = await diaQuery('available_listings', sel, {
        filter: 'property_id=not.is.null', limit: 1000, offset: pg * 1000,
      });
      all = all.concat(batch || []);
      if (!batch || batch.length < 1000) break;
    }
    all.forEach(l => {
      const pid = l.property_id;
      if (!map[pid]) map[pid] = [];
      map[pid].push(l);
    });
  } catch(e) { console.warn('available_listings fallback load failed:', e.message); }
  return map;
}

// Pick the listing whose listing_date / off_market_date / sold_date best
// straddles the sale_date. Falls back to the most recent listing on the
// property when no date overlap exists.
function pickListingMatch(listings, saleDate) {
  if (!Array.isArray(listings) || listings.length === 0) return null;
  if (!saleDate) return listings[0]; // best-effort: just return first
  const saleT = Date.parse(saleDate);
  if (isNaN(saleT)) return listings[0];
  let best = null, bestDelta = Infinity;
  for (const l of listings) {
    // Prefer a listing that "contains" the sale_date in its lifecycle.
    const listT = Date.parse(l.listing_date || '');
    const closeT = Date.parse(l.off_market_date || l.sold_date || '');
    let delta;
    if (!isNaN(listT) && !isNaN(closeT) && saleT >= listT && saleT <= closeT) {
      delta = 0; // exact lifecycle hit
    } else if (!isNaN(listT)) {
      delta = Math.abs(listT - saleT);
    } else {
      continue;
    }
    if (delta < bestDelta) { best = l; bestDelta = delta; }
  }
  return best || listings[0];
}

// Pick the first non-zero cap rate from an available_listings row, scanning
// the various cap_rate columns CoStar populates.
function listingCapRate(l) {
  if (!l) return null;
  const cols = ['cap_rate', 'current_cap_rate', 'last_cap_rate', 'initial_cap_rate'];
  for (const c of cols) {
    const v = l[c];
    if (v != null && Number(v) > 0) return Number(v);
  }
  return null;
}

// Find the deed_records row closest to sale_date within a tolerance window.
// Used to fill grantor/grantee/consideration when sales_transactions has
// nulls. Returns null if no candidate within the window.
function pickDeedMatch(deeds, saleDate, maxDays) {
  if (!Array.isArray(deeds) || deeds.length === 0 || !saleDate) return null;
  const saleT = Date.parse(saleDate);
  if (isNaN(saleT)) return null;
  const maxMs = (maxDays || 90) * 24 * 60 * 60 * 1000;
  let best = null, bestDelta = Infinity;
  for (const d of deeds) {
    const t = Date.parse(d.recording_date || '');
    if (isNaN(t)) continue;
    const delta = Math.abs(t - saleT);
    if (delta <= maxMs && delta < bestDelta) { best = d; bestDelta = delta; }
  }
  return best;
}

function pickCurrentLease(leases) {
  if (!Array.isArray(leases) || leases.length === 0) return null;
  const scored = leases.slice().sort((a, b) => {
    const aActive = (a.is_active === true || a.status === 'active') ? 1 : 0;
    const bActive = (b.is_active === true || b.status === 'active') ? 1 : 0;
    if (aActive !== bActive) return bActive - aActive;
    const aStart = a.lease_start || '';
    const bStart = b.lease_start || '';
    return bStart.localeCompare(aStart);
  });
  return scored[0] || null;
}

function extractBrokerCompanies(r) {
  // Extract broker company names from the sale_brokers embed
  const sbs = r.sale_brokers || [];
  const companies = [];
  sbs.forEach(sb => {
    if (sb.broker_companies && sb.broker_companies.name) companies.push(sb.broker_companies.name);
    else if (sb.brokers && sb.brokers.company) companies.push(sb.brokers.company);
  });
  return companies.join(', ');
}

// pickBest walks a list of [value, sourceLabel] candidates and returns the
// first non-empty value plus its source tag. Lets us record per-field
// provenance so the UI/devtools can see when a comp row was synthesized
// from secondary sources.
function pickBest(/* ...[value, source] pairs */) {
  for (let i = 0; i < arguments.length; i++) {
    const pair = arguments[i];
    if (!pair) continue;
    const v = pair[0];
    if (v == null) continue;
    if (typeof v === 'string' && !v.trim()) continue;
    if (typeof v === 'number' && !(v > 0 || v < 0)) continue; // skip 0 / NaN
    return { value: v, source: pair[1] };
  }
  return { value: null, source: null };
}

// Rent escalated from the lease anchor to a target date — 1:1 port of the SQL
// helper public.dia_project_rent_at_date (compounds bump_pct every
// bump_interval_mo). Used to show rent AT SALE DATE on sales comps (2026-05-29
// decision), matching v_sales_comps so the dashboard and detail panel agree.
function diaProjectRentAtDate(anchorRent, anchorDate, targetDate, bumpPct, bumpIntervalMo) {
  if (anchorRent == null || Number(anchorRent) <= 0) return null;
  const ar = Number(anchorRent);
  if (!anchorDate || !targetDate) return ar;
  const a = new Date(anchorDate), t = new Date(targetDate);
  if (isNaN(a.getTime()) || isNaN(t.getTime()) || t <= a) return ar;
  const interval = (bumpIntervalMo && Number(bumpIntervalMo) > 0) ? Number(bumpIntervalMo) : 12;
  const pct = (bumpPct == null || Number(bumpPct) === 0) ? 0 : Number(bumpPct);
  if (pct === 0) return ar;
  const monthsElapsed = (t.getFullYear() - a.getFullYear()) * 12 + (t.getMonth() - a.getMonth());
  const bumps = Math.max(0, Math.floor(monthsElapsed / interval));
  return Math.round(ar * Math.pow(1 + pct, bumps) * 100) / 100;
}

function normalizeSalesTxnRow(r, lookups) {
  const p = r.properties || {};
  const lease = pickCurrentLease(p.leases || r.leases);
  const oh = (lookups && lookups.ohBySaleId && lookups.ohBySaleId[r.sale_id]) || null;
  const propId = r.property_id || p.property_id;
  const deeds = (lookups && lookups.deedsByPropId && lookups.deedsByPropId[propId]) || null;
  const deed = deeds ? pickDeedMatch(deeds, r.sale_date, 90) : null;
  const clinic = (lookups && lookups.clinicByMedId && p.medicare_id) ? lookups.clinicByMedId[p.medicare_id] : null;
  const listings = (lookups && lookups.listingsByPropId && lookups.listingsByPropId[propId]) || null;
  const listing = listings ? pickListingMatch(listings, r.sale_date) : null;
  const listingCap = listingCapRate(listing);
  // Asking price proxy: listings can populate sold_price (post-close) or
  // initial_price/last_price (pre-close). Prefer sold_price > last > initial.
  const listingPrice = listing
    ? (Number(listing.sold_price) > 0 ? Number(listing.sold_price)
       : Number(listing.last_price) > 0 ? Number(listing.last_price)
       : Number(listing.initial_price) > 0 ? Number(listing.initial_price)
       : null)
    : null;

  // Provenance: track which source filled each field so we can audit and
  // surface a "Sources: deed_records, lease, ownership_history" tooltip
  // later. Primary source = 'sales_transactions' or 'properties' / 'leases'.
  const prov = {};

  const ohRecOwnerName = oh && oh.recorded_owners ? oh.recorded_owners.name : null;

  // -- Tenant / operator: lease → property.tenant → property.operator →
  //    chain_canonical → CMS chain_owner / facility_name
  const tenantPick = pickBest(
    [lease && lease.tenant, 'lease'],
    [p.tenant, 'properties.tenant'],
    [p.operator, 'properties.operator'],
    [p.chain_canonical, 'properties.chain_canonical'],
    [clinic && clinic.facility_name, 'medicare_clinics.facility_name'],
  );
  if (tenantPick.source && tenantPick.source !== 'lease' && tenantPick.source !== 'properties.tenant') {
    prov.tenant_operator = tenantPick.source;
  }

  // -- Buyer: sales_transactions → ownership_history (sale_id link) → deed grantee
  const buyerPick = pickBest(
    [r.buyer_name, 'sales_transactions'],
    [ohRecOwnerName, 'ownership_history.recorded_owner'],
    [deed && deed.grantee, 'deed_records.grantee'],
  );
  if (buyerPick.source && buyerPick.source !== 'sales_transactions') prov.buyer = buyerPick.source;

  // -- Seller: sales_transactions → available_listings.seller_name → deed grantor
  // Listings carry the seller because brokers list it; deed records have
  // grantor as the legal seller. Both are good evidence.
  const sellerPick = pickBest(
    [r.seller_name, 'sales_transactions'],
    [listing && listing.seller_name, 'available_listings.seller_name'],
    [deed && deed.grantor, 'deed_records.grantor'],
  );
  if (sellerPick.source && sellerPick.source !== 'sales_transactions') prov.seller = sellerPick.source;

  // -- Sold price: sales_transactions → ownership_history → listing
  //    sold_price → deed consideration. Listings outrank deed because the
  //    listing's sold_price is the broker-reported close price, while the
  //    deed consideration sometimes carries a nominal transfer value.
  const pricePick = pickBest(
    [r.sold_price, 'sales_transactions'],
    [oh && oh.sold_price, 'ownership_history'],
    [listingPrice, 'available_listings.sold_price'],
    [deed && deed.consideration, 'deed_records.consideration'],
  );
  if (pricePick.source && pricePick.source !== 'sales_transactions') prov.price = pricePick.source;
  const soldPrice = pricePick.value != null ? Number(pricePick.value) : null;

  // -- Cap rate: prefer the canonical cap-of-record (cap_rate_final) so the
  //    bypass loader agrees with the CM views (which read cap_rate_final) and
  //    the stored ledger. cap_rate_final is kept fresh by R42 — when rent/NOI is
  //    learned after a sale, the recompute refreshes the noi_derived of-record
  //    (the projecting view, this loader, and cap_rate_history then agree).
  //    Falls back to the legacy column ladder only where of-record is NULL, so a
  //    comp that shows a cap today never blanks.
  const capPick = pickBest(
    [r.cap_rate_final, 'sales_transactions.cap_rate_final'],
    [r.cap_rate, 'sales_transactions.cap_rate'],
    [r.calculated_cap_rate, 'sales_transactions.calculated_cap_rate'],
    [r.stated_cap_rate, 'sales_transactions.stated_cap_rate'],
    [oh && oh.cap_rate, 'ownership_history.cap_rate'],
    [listingCap, 'available_listings.cap_rate'],
  );
  if (capPick.source && !String(capPick.source).startsWith('sales_transactions')) prov.cap_rate = capPick.source;
  // Null implausible-tagged cap rates so they don't skew dashboard cap stats —
  // mirrors v_sales_comps (G6) so the dashboard, detail panel, and views agree
  // ("null the cap, keep the row"). 2026-05-29 cap-rate consistency audit.
  const capRate = (r.cap_rate_quality === 'implausible_unverified')
    ? null
    : (capPick.value != null ? Number(capPick.value) : null);

  // -- Brokers: sales_transactions.listing_broker / procuring_broker text
  // fields → sale_brokers row by role → brokers.broker_name → brokers.company.
  // Legacy CSV imports often have the text columns null while the
  // sale_brokers relation carries the data.
  const brokerByRole = role => {
    const sbs = r.sale_brokers || [];
    for (const sb of sbs) {
      if (sb && sb.role === role) {
        const b = sb.brokers || {};
        if (b.broker_name) return b.broker_name;
        if (b.company)     return b.company;
      }
    }
    return null;
  };
  const listingBrokerPick = pickBest(
    [r.listing_broker, 'sales_transactions.listing_broker'],
    [brokerByRole('listing'), 'sale_brokers.listing'],
    [listing && listing.listing_broker, 'available_listings.listing_broker'],
  );
  if (listingBrokerPick.source && listingBrokerPick.source !== 'sales_transactions.listing_broker') prov.listing_broker = listingBrokerPick.source;
  const procuringBrokerPick = pickBest(
    [r.procuring_broker, 'sales_transactions.procuring_broker'],
    [brokerByRole('procuring'), 'sale_brokers.procuring'],
  );
  if (procuringBrokerPick.source && procuringBrokerPick.source !== 'sales_transactions.procuring_broker') prov.procuring_broker = procuringBrokerPick.source;

  // Cross-validation: when both primary and fallback have a price and they
  // disagree by >5%, record it. R4-D #7 (2026-06-05): this used to console.warn
  // PER ROW on every dia load — 67+ lines of spam that everyone ignored. Now we
  // collect them into window._diaSalesCompXrefConflicts (the load wrapper emits
  // ONE summary line and the data-conflicts review lane reads the array), and
  // the canonical st↔ownership_history conflict is also surfaced server-side as
  // `sales_price_xref_conflict` in dia v_data_quality_issues so it gets
  // triaged + resolved instead of scrolling past in the console. (deed
  // consideration disagreements are expected — deeds often carry nominal
  // transfer values — so they're noted for the lane but not raised in the view.)
  if (r.sold_price != null && oh && oh.sold_price != null) {
    const a = Number(r.sold_price), b = Number(oh.sold_price);
    if (a > 0 && b > 0 && Math.abs(a - b) / a > 0.05) {
      (window._diaSalesCompXrefConflicts || (window._diaSalesCompXrefConflicts = []))
        .push({ sale_id: r.sale_id, source: 'ownership_history', sales_transactions: a, other: b });
    }
  }
  if (r.sold_price != null && deed && deed.consideration != null) {
    const a = Number(r.sold_price), b = Number(deed.consideration);
    if (a > 0 && b > 0 && Math.abs(a - b) / a > 0.05) {
      (window._diaSalesCompXrefConflicts || (window._diaSalesCompXrefConflicts = []))
        .push({ sale_id: r.sale_id, source: 'deed_records', sales_transactions: a, other: b });
    }
  }

  // -- Year built: properties.year_built → properties.year_renovated.
  // year_renovated isn't strictly the same thing, but for legacy CSV imports
  // where year_built was never populated, the renovated year is the only
  // anchor we have and it's closer to "vintage" than nothing. Auditing on
  // 2026-05-21 showed 102 sales properties with year_renovated populated
  // but year_built null.
  const yearPick = pickBest(
    [p.year_built, 'properties.year_built'],
    [p.year_renovated, 'properties.year_renovated'],
  );
  if (yearPick.source && yearPick.source !== 'properties.year_built') prov.year_built = yearPick.source;
  const yearBuilt = yearPick.value != null ? Number(yearPick.value) : null;

  // -- Building size (RBA): properties.building_size → max(leases.leased_area)
  // for the current/most-recent lease. Acts as a single-tenant proxy when
  // properties.building_size is null. Audit coverage is low (~1 row) but
  // costs nothing extra since the lease is already loaded.
  let leaseAreaMax = null;
  const leasesList = p.leases || r.leases || [];
  if (Array.isArray(leasesList)) {
    for (const l of leasesList) {
      if (l && l.leased_area != null && Number(l.leased_area) > 0) {
        const v = Number(l.leased_area);
        if (leaseAreaMax == null || v > leaseAreaMax) leaseAreaMax = v;
      }
    }
  }
  const rbaPick = pickBest(
    [p.building_size, 'properties.building_size'],
    [leaseAreaMax, 'leases.leased_area'],
  );
  if (rbaPick.source && rbaPick.source !== 'properties.building_size') prov.rba = rbaPick.source;
  const buildingSize = rbaPick.value != null ? Number(rbaPick.value) : null;

  // -- Land area: properties.land_area → properties.lot_sf (SF → acres at
  // 43,560 SF/ac). Legacy CSV import populated lot_sf on some properties
  // without populating land_area; this surfaces it.
  let lotAcresFromSf = null;
  if (p.lot_sf != null && Number(p.lot_sf) > 0) {
    lotAcresFromSf = Number(p.lot_sf) / 43560;
  }
  const landPick = pickBest(
    [p.land_area, 'properties.land_area'],
    [lotAcresFromSf, 'properties.lot_sf'],
  );
  if (landPick.source && landPick.source !== 'properties.land_area') prov.land_area = landPick.source;
  const landAreaAcres = landPick.value != null ? Number(landPick.value) : null;

  const pricePerSF   = (soldPrice && buildingSize && buildingSize > 0)
    ? soldPrice / buildingSize : null;

  let termYrs = null;
  if (lease && lease.lease_expiration) {
    const exp = new Date(lease.lease_expiration);
    if (!isNaN(exp.getTime())) {
      termYrs = (exp.getTime() - Date.now()) / (1000 * 60 * 60 * 24 * 365.25);
    }
  }

  let bumps = null;
  if (p.lease_bump_pct != null && p.lease_bump_interval_mo) {
    const pct = Number(p.lease_bump_pct) * 100;
    bumps = pct.toFixed(pct >= 10 ? 0 : 2) + '% / ' + p.lease_bump_interval_mo + 'mo';
  }

  // Rent AT SALE DATE (2026-05-29 decision) — escalate the lease anchor to the
  // sale date so the comp's rent matches the basis behind its cap rate, and
  // matches v_sales_comps. Anchor = confirmed property anchor_rent, else the
  // lease's Y1 annual_rent (fallback leases.rent); bumps from the property.
  const baseAnnual = lease
    ? (lease.annual_rent != null ? Number(lease.annual_rent)
       : (lease.rent != null ? Number(lease.rent) : null))
    : null;
  const anchorRent = ((p.anchor_rent_source === 'lease_confirmed' || p.anchor_rent_source === 'om_confirmed')
                       && p.anchor_rent != null)
    ? Number(p.anchor_rent) : baseAnnual;
  const bumpPct = p.lease_bump_pct != null ? Number(p.lease_bump_pct) : 0.02;
  const bumpInt = p.lease_bump_interval_mo != null ? Number(p.lease_bump_interval_mo) : 12;
  const annualRent = diaProjectRentAtDate(anchorRent, lease ? lease.lease_start : null, r.sale_date, bumpPct, bumpInt);
  const baseRentPsf = lease && lease.rent_per_sf != null ? Number(lease.rent_per_sf) : null;
  // Scale PSF by the same escalation ratio so it tracks the projected rent.
  const rentPsf = (baseRentPsf != null && anchorRent && anchorRent > 0 && annualRent != null)
    ? Math.round(baseRentPsf * (annualRent / anchorRent) * 100) / 100
    : baseRentPsf;

  return {
    sale_id:           r.sale_id,
    property_id:       r.property_id || p.property_id || null,
    tenant_operator:   tenantPick.value || null,
    address:           p.address || null,
    city:              p.city    || null,
    state:             p.state   || null,
    land_area:         landAreaAcres,
    year_built:        yearBuilt,
    rba:               buildingSize,
    rent:              annualRent,
    rent_per_sf:       rentPsf,
    lease_expiration:  lease ? lease.lease_expiration : null,
    term_remaining_yrs: termYrs,
    expenses:          lease ? lease.expense_structure : null,
    bumps:             bumps,
    price:             soldPrice,
    price_per_sf:      pricePerSF,
    cap_rate:          capRate,
    sold_date:         r.sale_date || null,
    recorded_date:     r.recorded_date || (deed ? deed.recording_date : null),
    seller:            sellerPick.value || null,
    buyer:             buyerPick.value  || null,
    listing_broker:    listingBrokerPick.value   || null,
    procuring_broker:  procuringBrokerPick.value || null,
    broker_companies:  extractBrokerCompanies(r),
    is_northmarq:      r.is_northmarq === true,
    bid_ask_spread:    null,
    dom:               null,
    transaction_type:  r.transaction_type || null,
    exclude_from_market_metrics: r.exclude_from_market_metrics === true,
    notes:             r.notes || null,
    data_source:       r.data_source || null,
    // _provenance: per-field map of secondary sources used to fill the row.
    // Only fields where a fallback fired appear here. UI can render this as
    // a small "ⓘ Sources" affordance per cell; for now it's observable in
    // the console via window.diaSalesComps[i]._provenance.
    _provenance:       Object.keys(prov).length ? prov : null,
  };
}

// ============================================================================
// HELPER FUNCTION: parseFloat without falsy coercion bug
// ============================================================================
/**
 * Safely parse float from element or string value, returning null for empty/zero values
 * Fixes the bug where parseFloat(val) || null converts valid 0 to null
 * @param {HTMLElement|string|any} el - Element with .value, string, or value to parse
 * @returns {number|null} - Parsed float or null if empty/NaN
 */
function _pf(el) { const v = (typeof el === 'string' ? el : el?.value)?.trim(); return v ? parseFloat(v) : null; }

/**
 * Safely parse a 4-digit year-built style value. Returns NULL for blank,
 * non-numeric, zero, negative, or out-of-range inputs so we never persist
 * year_built = 0 and never trip the DB CHECK constraint added in
 * sql/20260415_properties_year_built_null_zero.sql (valid range 1600–2100).
 * Mirrors parseYearSafe() in api/_handlers/sidebar-pipeline.js.
 * @param {HTMLElement|string|any} el
 * @returns {number|null}
 */
function _py(el) {
  const raw = (typeof el === 'string' ? el : el?.value);
  if (raw == null) return null;
  const str = String(raw).trim();
  if (!str) return null;
  const num = parseInt(str, 10);
  if (isNaN(num) || num <= 0) return null;
  if (num < 1600 || num > 2100) return null;
  return num;
}

// ============================================================================
// DATA LOADING
// ============================================================================

/**
 * Load all dialysis data
 */
let _diaDataLoading = false;
async function loadDiaData() {
  if (_diaDataLoading) return;  // Prevent concurrent loads
  _diaDataLoading = true;

  // Show loading indicator
  const inner = document.getElementById('bizPageInner');
  if (inner) {
    inner.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading dialysis data...</p></div>';
  }

  var _diaLoadStart = Date.now();
  try {
    diaData = {
      freshness: {},
      inventorySummary: {},
      inventoryChanges: [],
      npiSummary: {},
      npiSignals: [],
      moversUp: [],
      moversDown: [],
      propertyReviewQueue: [],
      leaseBackfillRows: [],
      leaseBackfillCount: null, // exact (un-capped) candidate count; null = not loaded
      researchOutcomes: [],
      sfActivities: [],
      reconciliation: {}
    };
    
    // ── FAST QUERIES: paint the Overview off the MV + summary views ────────
    // Unit 3 (2026-07-13): the two heavy DETAIL-array pulls
    // (v_clinic_inventory_latest_diff — full ~7.5k-row multi-page pull — and
    // v_npi_inventory_signals limit 5000) were the ~9.7s block. The Overview
    // reads mv_dia_overview_stats + the SUMMARY views (v_clinic_inventory_diff_
    // summary / v_npi_inventory_signal_summary), NOT the detail arrays, so those
    // two are DEFERRED to a background load (_loadDiaHeavyDetail) that re-renders
    // the current tab when it lands. Everything below is the fast set.
    var [freshness, invSummary, moversUpRaw, moversDownRaw,
         npiSignalSummary, propQueue, leaseQueue, leaseSummaryRows, outcomes, recon,
         sfActivities, patientAsOfRows, outcomesCountRes,
         onMarketRows, ownershipCovRows, llcHealthRows, listingConfirmRows, prospectCntRes
    ] = await Promise.all([
      diaQuery('v_counts_freshness', '*').catch(function(e) { console.warn('Freshness view timeout', e); return []; }),
      diaQuery('v_clinic_inventory_diff_summary', '*').catch(function(e) { console.warn('Inv summary timeout', e); return []; }),
      diaQuery('v_facility_patient_counts_mom', '*', { filter: 'delta_patients=gt.0', order: 'delta_patients.desc', limit: 10 }).catch(function() { return []; }),
      diaQuery('v_facility_patient_counts_mom', '*', { filter: 'delta_patients=lt.0', order: 'delta_patients.asc', limit: 10 }).catch(function() { return []; }),
      diaQuery('v_npi_inventory_signal_summary', '*').catch(function() { return []; }),
      diaQuery('v_clinic_property_link_review_queue', '*', { limit: 200 }).catch(function() { return []; }),
      diaQuery('v_clinic_lease_backfill_candidates', '*', { limit: 1000 }).catch(function() { return []; }),
      // Honest backlog size from the ONE canonical summary view (3 rows:
      // high/moderate/low → clinic_count). Cap-proof — the 1000-row candidate
      // page above can't report the true backlog (~3,039). Reads the summary,
      // not a capped page (the count=exact probe was returning null on the live
      // proxy → the tile fell back to 1,000).
      diaQuery('v_clinic_lease_backfill_summary', '*').catch(function() { return []; }),
      diaQuery('research_queue_outcomes', 'outcome_id,clinic_id,queue_type,status,assigned_to,assigned_at,created_at,source_name,selected_property_id,notes', { limit: 2000 }).catch(function() { return []; }),
      diaQuery('v_ingestion_reconciliation', '*', { limit: 1 }).catch(function() { return []; }),
      // Team touchpoints — query DIA Supabase directly so all team members are included
      diaQuery('salesforce_activities', 'assigned_to,activity_date,company_name', {
        filter: 'or(assigned_to.ilike.*largent*,assigned_to.ilike.*martin*,assigned_to.ilike.*briggs*,assigned_to.ilike.*berwaldt*)',
        order: 'activity_date.desc',
        limit: 5000
      }).catch(function() { return []; }),
      // The mom view's snapshot_date is the newest GENUINE CMS reporting period
      // (12-31 re-stamps excluded) — i.e. the honest "as of" date for the patient
      // tiles. Read it directly (the delta-filtered movers queries above return
      // nothing when there is no new period, so they can't carry the date).
      diaQuery('v_facility_patient_counts_mom', 'snapshot_date', { limit: 1 }).catch(function() { return []; }),
      // Completed Reviews — the TRUE count of research-queue outcomes (all rows
      // are terminal outcomes = completed reviews; ~1,166), via count=exact.
      // The `outcomes` page above is capped at 1,000, so its .length undercounts.
      diaQuery('research_queue_outcomes', 'outcome_id', { limit: 1, includeCount: true }).catch(function() { return { data: [], count: null }; }),
      // ── Data-Health & On-Market tiles: read the ONE canonical view per metric
      // on the Overview load (mirrors the Completed-Reviews / Property-Queue
      // pattern that works). Rendered SYNCHRONOUSLY from diaData so the
      // _loadDiaHeavyDetail re-render can't strand them on "loading…". All small
      // (aggregated / a bounded page) so they don't re-introduce a slow paint.
      diaQuery('v_dia_on_market', '*', { limit: 1000 }).catch(function() { return []; }),            // On Market (~184)
      diaQuery('v_ownership_coverage', '*', { limit: 1 }).catch(function() { return []; }),           // Ownership Coverage (1 row)
      diaQuery('v_llc_research_queue_health', '*', { limit: 50 }).catch(function() { return []; }),   // LLC queue counts (~5 rows)
      diaQuery('v_listings_needing_manual_confirmation', '*', { limit: 1000 }).catch(function() { return []; }), // Listings-confirm (~500)
      diaQuery('v_prospect_targets', 'true_owner_id', { limit: 1, includeCount: true }).catch(function() { return { data: [], count: null }; }) // Unprospected owners count
    ]);

    // Assign core data
    if (freshness && freshness.length > 0) diaData.freshness = freshness[0];
    if (invSummary && invSummary.length > 0) {
      invSummary.forEach(function(row) { diaData.inventorySummary[row.change_type] = row; });
    }
    // inventoryChanges (the heavy detail array) is loaded in the background
    // (_loadDiaHeavyDetail); leave it [] for the fast paint. The freshness
    // fallback below is gated on it being loaded, so it re-runs in the bg.

    _diaApplyFreshnessFallback();

    // Assign NPI + research data (npiSignals — the heavy array — loads in bg)
    if (npiSignalSummary && npiSignalSummary.length > 0) {
      npiSignalSummary.forEach(function(row) { diaData.npiSummary[row.signal_type] = row; });
    }
    diaData.propertyReviewQueue = propQueue || [];
    diaData.leaseBackfillRows = leaseQueue || [];
    // Honest backlog size = SUM of clinic_count across the summary view's
    // priority rows (high/moderate/low → ~3,039). Cap-proof. null when the
    // summary failed to load — never silently 0.
    diaData.leaseBackfillCount = (Array.isArray(leaseSummaryRows) && leaseSummaryRows.length)
      ? leaseSummaryRows.reduce(function(s, r) { return s + (Number(r.clinic_count) || 0); }, 0)
      : null;
    diaData.researchOutcomes = outcomes || [];
    // True completed-reviews count (count=exact; the outcomes page is capped at
    // 1,000). null when the probe failed → the tile falls back to page length.
    diaData.researchOutcomesCount = (outcomesCountRes && typeof outcomesCountRes.count === 'number')
      ? outcomesCountRes.count : null;
    diaData.sfActivities = sfActivities || [];

    // ── Canonical Data-Health / On-Market tile sources (rendered synchronously)
    // On Market — the T9d canonical set (~184). Read the rows DIRECTLY from
    // v_dia_on_market so the tile no longer depends on the flaky
    // v_available_listings client load (which, when it fails/empties, made the
    // filter yield "0 currently on market"). diaOnMarketIds still drives the
    // Listings-tab filter (below), now sourced from the same canonical rows.
    diaData.onMarketRows = Array.isArray(onMarketRows) ? onMarketRows : [];
    diaOnMarketIds = new Set(diaData.onMarketRows.map(function(r) { return r.listing_id; }));
    // Ownership Coverage — the ONE single-row summary view.
    diaData.ownershipCoverage = (Array.isArray(ownershipCovRows) && ownershipCovRows[0]) ? ownershipCovRows[0] : null;
    // LLC Research Queue counts — status → row_count from the ONE health view.
    (function() {
      var byStatus = {}, total = 0;
      (Array.isArray(llcHealthRows) ? llcHealthRows : []).forEach(function(r) {
        byStatus[r.status] = Number(r.row_count) || 0; total += Number(r.row_count) || 0;
      });
      window._diaLlcPending = byStatus.deferred || 0;   // awaiting research (parked)
      window._diaLlcDone = byStatus.done || 0;
      window._diaLlcTotalRows = total;
      window._diaLlcHealthLoaded = true;
    })();
    // Listings Needing Confirmation — the full (bounded) row set; drives the 3
    // count tiles AND the resolve list.
    window._lcConfirmRows = Array.isArray(listingConfirmRows) ? listingConfirmRows : [];
    diaData.listingConfirmLoaded = true;
    // Unprospected Owners — the actionable BD-target count (count=exact).
    diaData.unprospectedCount = (prospectCntRes && typeof prospectCntRes.count === 'number' && prospectCntRes.count > 0)
      ? prospectCntRes.count : ((prospectCntRes && Array.isArray(prospectCntRes.data)) ? prospectCntRes.data.length : null);

    // Honest "as of" period for the CMS patient-count tiles (the newest GENUINE
    // reporting period, not a year-end re-stamp). null when unavailable.
    diaData.patientAsOf = (patientAsOfRows && patientAsOfRows[0] && patientAsOfRows[0].snapshot_date)
      ? patientAsOfRows[0].snapshot_date : null;
    if (recon && recon.length > 0) {
      diaData.reconciliation = recon[0];
    }

    // Enrich movers with facility names.
    // Round 76eg (2026-04-29): v_facility_patient_counts_mom now inner-joins
    // medicare_clinics and exposes facility_name + city + state directly, so
    // the row already carries the name. We keep a secondary lookup as a
    // belt-and-suspenders fallback in case the view is rolled back, and we
    // also harvest names from inventoryChanges for any IDs the view missed.
    try {
      var nameMap = {};
      // Pre-seed from inventoryChanges (cheap — no extra round trip)
      (diaData.inventoryChanges || []).forEach(function(r) {
        if (r.clinic_id && r.facility_name) nameMap[r.clinic_id] = r.facility_name;
      });
      var allMovers = [].concat(moversUpRaw || [], moversDownRaw || []);
      // Take advantage of facility_name now riding along on the mom view rows.
      allMovers.forEach(function(r) {
        if (r && r.clinic_id && r.facility_name && !nameMap[r.clinic_id]) {
          nameMap[r.clinic_id] = r.facility_name;
        }
      });
      // Fallback: only look up the IDs we still don't have a name for.
      var unresolvedIds = allMovers
        .map(function(r) { return r && r.clinic_id; })
        .filter(function(id) { return id && !nameMap[id]; })
        .filter(function(v, i, a) { return a.indexOf(v) === i; });
      if (unresolvedIds.length > 0) {
        try {
          var nameRows = await diaQuery('medicare_clinics', 'medicare_id,facility_name', {
            filter: 'medicare_id=in.(' + unresolvedIds.join(',') + ')', limit: 50
          });
          (nameRows || []).forEach(function(r) { if (r.medicare_id) nameMap[r.medicare_id] = r.facility_name; });
        } catch (e) { console.warn('name lookup failed', e); }
      }
      var enrich = function(arr) {
        return (arr || []).map(function(r) {
          // Prefer the name already on the row (new view); fall back to map; only
          // synthesize "Clinic <id>" as a last resort. Round 76eg's view-side
          // INNER JOIN should make that fallback unreachable in practice.
          var name = (r && r.facility_name) || nameMap[r && r.clinic_id] || ('Clinic ' + (r && r.clinic_id));
          return Object.assign({}, r, { facility_name: name });
        });
      };
      diaData.moversUp = enrich(moversUpRaw);
      diaData.moversDown = enrich(moversDownRaw);
    } catch (e) {
      console.warn('Failed to enrich movers data', e);
      diaData.moversUp = [];
      diaData.moversDown = [];
    }
    
    diaDataLoaded = true;
    _diaDataLoading = false;
    console.debug('DIA DATA LOADED (fast):', {
      freshness: diaData.freshness,
      invSummaryKeys: Object.keys(diaData.inventorySummary),
      npiSummaryKeys: Object.keys(diaData.npiSummary),
      propertyQueue: diaData.propertyReviewQueue.length,
      leaseBackfill: diaData.leaseBackfillRows.length,
      outcomes: diaData.researchOutcomes.length,
      sfActivities: diaData.sfActivities.length,
      recon: diaData.reconciliation
    });
    var _diaLoadSec = ((Date.now() - _diaLoadStart) / 1000).toFixed(1);
    // The Overview paints off the MV + summary views; the detail arrays
    // (inventoryChanges / npiSignals) load in the background — reported honestly.
    showToast(`Dialysis: ${(diaData.freshness || {}).total_clinics || 0} clinics (${_diaLoadSec}s) · detail loading…`, 'success');
    // Only render if user is still viewing the dialysis tab
    if (typeof currentBizTab !== 'undefined' && currentBizTab === 'dialysis') renderDiaTab();
    // Unit 3: fetch the heavy detail arrays in the background, then re-render.
    _loadDiaHeavyDetail();
  } catch (err) {
    console.error('loadDiaData error:', err);
    _diaDataLoading = false;
    // Show error in the UI instead of just console
    const inner = document.getElementById('bizPageInner');
    if (inner) {
      inner.innerHTML = '<div style="text-align:center;padding:32px;color:var(--red)"><p style="font-size:16px;margin-bottom:8px">Failed to load dialysis data</p><p style="color:var(--text2);font-size:13px">' + esc(err.message || 'Unknown error') + '</p><button class="gov-btn" onclick="this.disabled=true;this.textContent=\'Loading\u2026\';loadDiaData()" style="margin-top:12px">Retry</button></div>';
    }
  }
}

/**
 * Freshness fallback \u2014 estimate clinic coverage from the inventoryChanges detail
 * array when v_counts_freshness returns empty. Gated on inventoryChanges being
 * LOADED (Unit 3: it loads in the background), so a no-op during the fast paint
 * and re-runs once _loadDiaHeavyDetail lands the array. Never clobbers a real
 * freshness row (only fills when total_clinics is missing).
 */
function _diaApplyFreshnessFallback() {
  if (!diaData) return;
  if (diaData.freshness && diaData.freshness.total_clinics) return; // real row present
  var ic = diaData.inventoryChanges || [];
  if (ic.length === 0) return; // detail array not loaded yet \u2014 defer to bg
  var withCounts = ic.filter(function(c) { return c.latest_total_patients > 0; });
  diaData.freshness = {
    total_clinics: ic.length,
    clinics_with_counts: withCounts.length,
    coverage_pct: ic.length > 0 ? Math.round(withCounts.length / ic.length * 1000) / 10 : 0,
    _fallback: true
  };
}

/**
 * Unit 3 (2026-07-13) \u2014 background load of the two heavy DETAIL arrays that used
 * to block the whole dia Overview (~9.7s): the full v_clinic_inventory_latest_diff
 * multi-page pull and v_npi_inventory_signals (limit 5000). The Overview does NOT
 * read these (it uses mv_dia_overview_stats + the summary views), so they load
 * AFTER the fast paint. When they land we re-run the freshness fallback + the
 * movers name pre-seed (belt-and-suspenders) and re-render the current tab so the
 * Inventory Changes / NPI Intel tabs and any name gaps fill in without a spinner.
 */
var _diaHeavyDetailLoading = false;
async function _loadDiaHeavyDetail() {
  if (_diaHeavyDetailLoading) return;
  _diaHeavyDetailLoading = true;
  try {
    var [invChanges, npiSignals] = await Promise.all([
      diaQueryAll('v_clinic_inventory_latest_diff', '*').catch(function(e) { console.warn('Inv changes timeout', e); return []; }),
      diaQuery('v_npi_inventory_signals', '*', { limit: 5000 }).catch(function() { return []; })
    ]);
    diaData.inventoryChanges = invChanges || [];
    diaData.npiSignals = npiSignals || [];

    // Re-run the freshness fallback now that the detail array is available.
    _diaApplyFreshnessFallback();

    // Belt-and-suspenders: harvest facility names from inventoryChanges for any
    // mover still showing "Clinic <id>" (the fast-path enrichment ran with an
    // empty array). No extra round trip \u2014 pure in-memory patch.
    try {
      var nameMap = {};
      diaData.inventoryChanges.forEach(function(r) {
        if (r && r.clinic_id && r.facility_name) nameMap[r.clinic_id] = r.facility_name;
      });
      var patch = function(arr) {
        return (arr || []).map(function(r) {
          if (r && r.clinic_id && /^Clinic\s/.test(String(r.facility_name || '')) && nameMap[r.clinic_id]) {
            return Object.assign({}, r, { facility_name: nameMap[r.clinic_id] });
          }
          return r;
        });
      };
      if (Array.isArray(diaData.moversUp)) diaData.moversUp = patch(diaData.moversUp);
      if (Array.isArray(diaData.moversDown)) diaData.moversDown = patch(diaData.moversDown);
    } catch (e) { console.warn('mover name backfill failed', e); }

    console.debug('DIA DETAIL LOADED (bg):', {
      inventoryChanges: diaData.inventoryChanges.length,
      npiSignals: diaData.npiSignals.length
    });
    // Re-render the current dia tab so the detail-backed sections fill in.
    if (typeof currentBizTab !== 'undefined' && currentBizTab === 'dialysis' &&
        typeof diaDataLoaded !== 'undefined' && diaDataLoaded) {
      renderDiaTab();
    }
  } catch (e) {
    console.warn('_loadDiaHeavyDetail error', e);
  } finally {
    _diaHeavyDetailLoading = false;
  }
}

// ============================================================================
// MAIN TAB ROUTER
// ============================================================================

/**
 * Route to correct tab renderer
 */
function renderDiaTab() {
  const inner = q('#bizPageInner');
  if (!inner) return;

  // Track tabs that benefit from anti-flicker rendering
  const useFlickerFix = currentDiaTab === 'research' || currentDiaTab === 'changes';

  switch (currentDiaTab) {
    case 'overview':
      inner.innerHTML = renderDiaOverview();
      break;
    case 'search':
      inner.innerHTML = renderDiaSearch();
      break;
    case 'changes':
      if (useFlickerFix && typeof smoothDOMUpdate === 'function') {
        smoothDOMUpdate(inner, renderDiaChanges());
      } else {
        inner.innerHTML = renderDiaChanges();
      }
      break;
    case 'inventory':
      inner.innerHTML = renderDiaInventoryChanges();
      break;
    case 'npi':
      inner.innerHTML = renderDiaNpi();
      break;
    case 'properties':
      renderDiaProperties(); // async — renders directly to DOM
      return;
    case 'sales':
      renderDiaSales(); // async — renders directly to DOM
      return;
    case 'leases':
      renderDiaLeases(); // async — renders directly to DOM
      return;
    case 'loans':
      renderDiaLoans(); // async — renders directly to DOM
      return;
    case 'players':
      inner.innerHTML = renderDiaPlayers();
      break;
    case 'research':
      if (useFlickerFix && typeof smoothDOMUpdate === 'function') {
        smoothDOMUpdate(inner, renderDiaResearch());
      } else {
        inner.innerHTML = renderDiaResearch();
      }
      break;
    case 'ownership':
      // UI Phase 3 — Ownership promoted to a first-class DEALS tab. Reuses the
      // existing ownership research panel (was buried as a Research-workbench
      // mode); the panel self-binds + re-renders via renderDiaTab(), so it works
      // standalone. The Research-mode entry (diaResearchMode='ownership') still
      // works unchanged.
      if (diaOwnershipBacklog === null && !diaOwnershipBacklogLoading) loadDiaOwnershipBacklog();
      inner.innerHTML = renderDiaOwnershipResearch();
      break;
    case 'prospects':
      // Render dialysis-domain prospects from domain-classified opportunities
      if (typeof renderDomainProspects === 'function' && window._mktOpportunities) {
        renderDomainProspects('dialysis');
      } else {
        inner.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading prospects...</p></div>';
        // Trigger marketing load if not done
        if (typeof loadMarketing === 'function') loadMarketing().then(() => renderDomainProspects('dialysis'));
      }
      return;
    case 'activity':
      inner.innerHTML = renderDiaActivity();
      break;
    case 'capital-markets':
      // Renders directly to DOM (async); see capital-markets.js
      if (typeof renderDiaCapitalMarkets === 'function') {
        const result = renderDiaCapitalMarkets();
        // Phase 2 placeholder returns a string; Phase 1+ returns void after rendering directly
        if (typeof result === 'string') inner.innerHTML = result;
      } else {
        inner.innerHTML = '<div style="padding:24px;color:#666">capital-markets.js not loaded</div>';
      }
      return;
    default:
      inner.innerHTML = '<p style="color: var(--text2);">Unknown tab</p>';
  }
}

// ============================================================================
// OVERVIEW TAB — Infographic-Style Command Center
// ============================================================================

// Helper: navigate to a dia sub-tab with optional pre-filter
function goToDiaTab(tabName, preFilter) {
  // Apply pre-filter if provided (e.g. searching CMS tab for "added" clinics)
  if (preFilter && tabName === 'changes') {
    diaCmsSearch = preFilter;
    diaCmsPage = 0;
  }
  // Inventory Changes tab supports pre-filter by change_type ('added' / 'removed')
  if (preFilter && tabName === 'inventory') {
    diaInventoryFilter = preFilter;
  }
  currentDiaTab = tabName;
  if (typeof window.syncDomainTabGroup === 'function') {
    window.syncDomainTabGroup('dialysis', tabName);
  } else {
    document.querySelectorAll('#diaInnerTabs .gov-inner-tab').forEach(t => t.classList.remove('active'));
    const btn = document.querySelector('[data-dia-tab="' + tabName + '"]');
    if (btn) btn.classList.add('active');
  }
  if (tabName === 'activity') { renderBizContent(); }
  else if (typeof diaDataLoaded !== 'undefined' && diaDataLoaded) { renderDiaTab(); }
}

// Helper: build a clickable infographic card
function infoCard(opts) {
  const { title, value, sub, trend, trendLabel, color, icon, tab, span, id, subId, onclick } = opts;
  const colors = { blue:'#6c8cff', green:'#34d399', yellow:'#fbbf24', red:'#f87171', purple:'#a78bfa', cyan:'#22d3ee', white:'var(--text1)', orange:'#fb923c' };
  const c = colors[color] || colors.blue;
  const trendColor = trend > 0 ? '#34d399' : trend < 0 ? '#f87171' : 'var(--text3)';
  const trendArrow = trend > 0 ? '▲' : trend < 0 ? '▼' : '—';
  const trendStr = trend != null ? `<div style="font-size:11px;color:${trendColor};margin-top:4px">${trendArrow} ${trendLabel || ''}</div>` : '';
  // onclick (a raw JS call) takes precedence over the tab shortcut so a tile can
  // open a modal instead of navigating (e.g. the Unprospected Owners card).
  const click = onclick ? ` onclick="${onclick}" style="cursor:pointer"` : (tab ? ` onclick="goToDiaTab('${tab}')" style="cursor:pointer"` : '');
  const spanStyle = span ? `grid-column: span ${span};` : '';
  return `<div class="dia-info-card"${click} style="${spanStyle}">
    ${icon ? `<div style="font-size:20px;margin-bottom:4px">${icon}</div>` : ''}
    <div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:6px">${title}</div>
    <div${id ? ' id="' + id + '"' : ''} style="font-size:28px;font-weight:800;color:${c};line-height:1">${value}</div>
    ${sub != null ? `<div${subId ? ' id="' + subId + '"' : ''} style="font-size:11px;color:var(--text2);margin-top:4px">${sub}</div>` : ''}
    ${trendStr}
  </div>`;
}

// Helper: section header
function sectionHeader(title, icon, tab) {
  const click = tab ? ` onclick="goToDiaTab('${tab}')" style="cursor:pointer"` : '';
  return `<div${click} style="display:flex;align-items:center;gap:8px;margin:28px 0 12px;padding:0 2px">
    <span style="font-size:16px">${icon}</span>
    <span style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--text2)">${title}</span>
    ${tab ? '<span style="font-size:11px;color:var(--accent);margin-left:auto">View Details →</span>' : ''}
  </div>`;
}

// Helper: horizontal labelled bar list (mirror of gov.js inlineBar so the
// dia/gov Overview breakdown blocks share one card grammar — UI Phase 2).
function diaInlineBar(items, maxVal) {
  let out = '';
  items.forEach(item => {
    const barW = maxVal > 0 ? Math.round((item.value / maxVal) * 100) : 0;
    out += `<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
      <div title="${esc(item.label)}" style="width:${item.labelWidth || 100}px;font-size:11px;color:var(--text2);text-align:right;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(item.label)}</div>
      <div style="flex:1;height:8px;background:var(--s3);border-radius:4px;overflow:hidden"><div style="width:${barW}%;height:100%;background:${item.barColor || '#60a5fa'};border-radius:4px"></div></div>
      <div style="width:${item.valueWidth || 50}px;font-size:10px;color:var(--text2);text-align:right">${item.display}</div>
    </div>`;
  });
  return out;
}

// Parse a jsonb column that PostgREST may return as an array OR a string.
function _diaParseJ(raw) {
  if (!raw) return [];
  try { return typeof raw === 'string' ? JSON.parse(raw) : raw; } catch (e) { return []; }
}

// ── UI Phase 2: value-first Overview blocks (driven by mv_dia_overview_stats) ──
// Portfolio at a Glance — mirrors gov's section 1. Honest denominators: headline
// is ACTIVE properties (dia has no archived class), NOT the CMS-clinic count
// (shown as a secondary metric); rent is projected to CURRENT_DATE; dia is NNN
// so net rent ≈ NOI (labelled honestly).
function renderDiaPortfolioGlanceInner() {
  const mv = diaOverviewStats;
  if (!mv || mv._error || mv._empty) {
    if (_diaOverviewStatsLoading || !mv) {
      return '<div class="dia-grid dia-grid-5"><div class="dia-info-card" style="grid-column:span 5;text-align:center;padding:24px"><span class="spinner"></span><div style="margin-top:8px;font-size:12px;color:var(--text2)">Loading portfolio…</div></div></div>';
    }
    return '<div class="dia-info-card" style="padding:16px;color:var(--text3);font-size:12px">Portfolio summary unavailable</div>';
  }
  const n = v => Number(v) || 0;
  let h = '<div class="dia-grid dia-grid-5">';
  h += infoCard({ title: 'Total Properties', value: fmtN(n(mv.total_properties)), sub: 'dialysis facilities tracked', color: 'blue', tab: 'search' });
  h += infoCard({ title: 'Total SF', value: fmtN(Math.round(n(mv.total_sf) / 1e6)) + 'M', sub: fmtN(n(mv.properties_with_sf)) + ' with size data', color: 'green', tab: 'search' });
  h += infoCard({ title: 'Projected Annual Rent', value: '$' + fmtN(Math.round(n(mv.total_rent) / 1e6)) + 'M', sub: fmtN(n(mv.properties_with_rent)) + ' with lease rent', color: 'cyan', tab: 'sales' });
  h += infoCard({ title: 'Avg Rent / SF', value: mv.avg_rent_psf ? '$' + Number(mv.avg_rent_psf).toFixed(2) : '—', sub: fmtN(n(mv.properties_with_rent)) + ' properties', color: 'purple', tab: 'sales' });
  h += infoCard({ title: 'Operators Tracked', value: fmtN(n(mv.operators_tracked)), sub: 'distinct operators', color: 'yellow', tab: 'search' });
  h += '</div>';
  // Second row mirrors gov's NOI row (Total NOI · Avg NOI/Property · Contacts).
  // dia is NNN so net rent ≈ NOI; the Avg tile is total net rent / active property.
  const avgNoi = n(mv.total_properties) > 0 ? n(mv.total_noi) / n(mv.total_properties) : 0;
  h += '<div class="dia-grid dia-grid-4" style="margin-top:10px">';
  h += infoCard({ title: 'Net Rent ≈ NOI', value: '$' + fmtN(Math.round(n(mv.total_noi) / 1e6)) + 'M', sub: 'NNN net lease — rent ≈ NOI', color: 'green', tab: 'sales' });
  h += infoCard({ title: 'Avg Net Rent / Property', value: avgNoi > 0 ? '$' + fmtN(Math.round(avgNoi / 1000)) + 'K' : '—', sub: 'across active portfolio (≈ NOI)', color: 'blue', tab: 'sales' });
  h += infoCard({ title: 'CMS Clinics', value: fmtN(n(mv.cms_clinics)), sub: 'Medicare-certified facilities', color: 'blue', tab: 'search' });
  h += infoCard({ title: 'Contacts', value: fmtN(n(mv.total_contacts)), sub: 'owners & principals', color: 'purple', tab: 'research' });
  h += '</div>';
  return h;
}

// Lease Expiration Risk — mirrors gov's section 2 (bucketed off lease_expiration).
function renderDiaLeaseExpRiskInner() {
  const mv = diaOverviewStats;
  if (!mv || mv._error || mv._empty) {
    if (_diaOverviewStatsLoading || !mv) {
      return '<div class="dia-grid dia-grid-5"><div class="dia-info-card" style="grid-column:span 5;text-align:center;padding:24px"><span class="spinner"></span><div style="margin-top:8px;font-size:12px;color:var(--text2)">Loading lease risk…</div></div></div>';
    }
    return '<div class="dia-info-card" style="padding:16px;color:var(--text3);font-size:12px">Lease expiration data unavailable</div>';
  }
  const n = v => Number(v) || 0;
  const dated = n(mv.properties_with_lease_exp);
  const pct = v => dated > 0 ? (v / dated * 100).toFixed(1) + '% of dated leases' : '';
  let h = '<div class="dia-grid dia-grid-5">';
  h += infoCard({ title: 'Expiring < 6 Months', value: fmtN(n(mv.exp_lease_lt_6mo)), sub: pct(n(mv.exp_lease_lt_6mo)), color: 'red', tab: 'sales' });
  h += infoCard({ title: 'Expiring < 1 Year', value: fmtN(n(mv.exp_lease_lt_1yr)), sub: pct(n(mv.exp_lease_lt_1yr)), color: 'orange', tab: 'sales' });
  h += infoCard({ title: 'Expired / Holdover', value: fmtN(n(mv.lease_expired_count)), sub: fmtN(n(mv.lease_expired_stale)) + ' expired >1yr (stale)', color: 'red', tab: 'sales' });
  h += infoCard({ title: '2–5 Year Term', value: fmtN(n(mv.exp_lease_2_5yr)), sub: 'mid-range leases', color: 'yellow', tab: 'sales' });
  h += infoCard({ title: '5+ Year Term', value: fmtN(n(mv.exp_lease_5plus)), sub: 'long-term secured', color: 'green', tab: 'sales' });
  h += '</div>';
  h += '<div style="font-size:11px;color:var(--text3);margin-top:6px">Bucketed by actual <b>lease_expiration</b> over ' + fmtN(dated) + ' dated leases. Avg term remaining ' + (mv.avg_term_remaining != null ? Number(mv.avg_term_remaining).toFixed(1) : '—') + ' yrs.</div>';
  const dist = _diaParseJ(mv.lease_distribution_by_expiry).map(b => ({ label: b.label, count: Number(b.count) || 0, color: b.color }));
  if (dist.length) {
    h += '<div class="dia-info-card" style="padding:14px 16px;margin-top:10px">';
    h += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">Lease Expiration Distribution</div>';
    const maxB = Math.max(1, ...dist.map(b => b.count));
    h += diaInlineBar(dist.map(b => ({ label: b.label, value: b.count, display: fmtN(b.count), barColor: b.color, labelWidth: 110, valueWidth: 40 })), maxB);
    h += '</div>';
  }
  return h;
}

// Operator + Geographic breakdown — the dia mirror of gov's Agency Breakdown +
// Geographic Distribution sections.
function renderDiaBreakdownInner() {
  const mv = diaOverviewStats;
  if (!mv || mv._error || mv._empty) {
    if (_diaOverviewStatsLoading || !mv) {
      return '<div class="dia-info-card" style="text-align:center;padding:24px"><span class="spinner"></span><div style="margin-top:8px;font-size:12px;color:var(--text2)">Loading breakdown…</div></div>';
    }
    return '<div class="dia-info-card" style="padding:16px;color:var(--text3);font-size:12px">Breakdown data unavailable</div>';
  }
  const stateName = st => (typeof STATE_FULL !== 'undefined' && STATE_FULL[st]) ? STATE_FULL[st] : st;
  const opCount = _diaParseJ(mv.top_operators_by_count);
  const opRent = _diaParseJ(mv.top_operators_by_rent);
  let h = '';
  if (opCount.length) {
    h += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">';
    h += '<div class="dia-info-card" onclick="goToDiaTab(\'search\')" style="cursor:pointer;padding:14px 16px">';
    h += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">Top Operators by Property Count</div>';
    const maxC = opCount[0] ? Number(opCount[0].count) || 1 : 1;
    h += diaInlineBar(opCount.map(d => ({ label: d.name, value: Number(d.count) || 0, display: fmtN(Number(d.count) || 0), barColor: '#60a5fa', labelWidth: 140, valueWidth: 40 })), maxC);
    h += '</div>';
    h += '<div class="dia-info-card" onclick="goToDiaTab(\'sales\')" style="cursor:pointer;padding:14px 16px">';
    h += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">Top Operators by Projected Rent</div>';
    const maxR = opRent[0] ? Number(opRent[0].rent) || 1 : 1;
    h += diaInlineBar(opRent.map(d => ({ label: d.name, value: Number(d.rent) || 0, display: '$' + fmtN(Math.round((Number(d.rent) || 0) / 1e6)) + 'M', barColor: '#34d399', labelWidth: 140, valueWidth: 56 })), maxR);
    h += '</div>';
    h += '</div>';
  }
  const stCount = _diaParseJ(mv.top_states_by_count);
  const stRent = _diaParseJ(mv.top_states_by_rent);
  if (stCount.length) {
    h += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px">';
    h += '<div class="dia-info-card" style="padding:14px 16px">';
    h += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">Top States by Property Count</div>';
    const maxSc = stCount[0] ? Number(stCount[0].count) || 1 : 1;
    h += diaInlineBar(stCount.map(d => ({ label: stateName(d.name), value: Number(d.count) || 0, display: fmtN(Number(d.count) || 0), barColor: '#a78bfa', labelWidth: 110, valueWidth: 40 })), maxSc);
    h += '</div>';
    h += '<div class="dia-info-card" style="padding:14px 16px">';
    h += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">Top States by Projected Rent</div>';
    const maxSr = stRent[0] ? Number(stRent[0].rent) || 1 : 1;
    h += diaInlineBar(stRent.map(d => ({ label: stateName(d.name), value: Number(d.rent) || 0, display: '$' + fmtN(Math.round((Number(d.rent) || 0) / 1e6)) + 'M', barColor: '#22d3ee', labelWidth: 110, valueWidth: 56 })), maxSr);
    h += '</div>';
    h += '</div>';
  }
  return h || '<div class="dia-info-card" style="padding:16px;color:var(--text3);font-size:12px">No breakdown data yet</div>';
}

// DIA_OVERVIEW_TILE_AUDIT Unit 3: Lease Coverage derived from server-side
// aggregates, never a capped page length. Headline = rent coverage from the MV
// (properties_with_rent / total_properties — aligns with Portfolio "with lease
// rent"); sub = the un-capped backfill backlog from the count=exact probe. A
// missing/failed MV → '—' (never a false 100%); a missing count → the capped
// floor, labelled honestly.
function _diaLeaseCoverage() {
  const mv = (typeof diaOverviewStats !== 'undefined') ? diaOverviewStats : null;
  const ok = mv && !mv._error && !mv._empty && Number(mv.total_properties) > 0;
  const pct = ok
    ? (Number(mv.properties_with_rent) / Number(mv.total_properties) * 100).toFixed(1) + '%'
    : '—';
  const cnt = (typeof diaData !== 'undefined' && diaData.leaseBackfillCount != null)
    ? diaData.leaseBackfillCount : null;
  const capped = (typeof diaData !== 'undefined' && diaData.leaseBackfillRows)
    ? diaData.leaseBackfillRows.length : 0;
  // UI Phase 3 Unit 0a — use the count=exact backlog (v_clinic_lease_backfill_
  // candidates, ~3,035) when it loaded with a positive value; a 0/null probe
  // result falls back to the capped page so the sub never reads a misleading "0".
  const sub = (cnt != null && cnt > 0)
    ? fmtN(cnt) + ' clinics need lease backfill'
    : (capped >= 1000 ? '1,000+ need backfill' : fmtN(capped) + ' need backfill');
  return { pct, sub };
}

// UI Phase 2/3 — Action Items with ONE shared taxonomy across dia ↔ gov:
// BD signals FIRST (leases expiring < 6mo, active on-market listings), THEN
// data-quality (property review, lease backfill, inventory changes / NPI). Only
// categories that have counts render. BD counts come from async sources
// (mv_dia_overview_stats, diaAvailListings) so this is rendered into the
// #diaActionItems placeholder and refreshed when those loads land.
function renderDiaActionItemsInner() {
  const n = v => Number(v) || 0;
  const mv = (typeof diaOverviewStats !== 'undefined') ? diaOverviewStats : null;
  const mvOk = mv && !mv._error && !mv._empty;
  const bd = [], dq = [];

  // ── BD signals ──────────────────────────────────────────────
  const expLt6 = mvOk ? n(mv.exp_lease_lt_6mo) : 0;
  if (expLt6 > 0) {
    bd.push({ icon: '⏳', color: '#f87171', urgency: 'warning',
      title: fmtN(expLt6) + ' lease' + (expLt6 > 1 ? 's' : '') + ' expiring within 6 months',
      detail: 'Renewal / sale-leaseback windows opening — prioritize outreach on these owners',
      action: 'Review leases', tab: 'leases' });
  }
  const onMarket = (typeof diaAvailListings !== 'undefined' && Array.isArray(diaAvailListings)) ? diaAvailListings.length : 0;
  if (onMarket > 0) {
    bd.push({ icon: '🏷️', color: '#34d399', urgency: 'info',
      title: fmtN(onMarket) + ' dialysis propert' + (onMarket > 1 ? 'ies' : 'y') + ' on market',
      detail: 'Active listings — acquisition targets / competitive positioning for your pipeline',
      action: 'View listings', tab: 'sales' });
  }

  // ── Data-quality ────────────────────────────────────────────
  const removedCount = (typeof diaData !== 'undefined' && diaData.inventorySummary) ? (diaData.inventorySummary.removed?.clinic_count || 0) : 0;
  if (removedCount > 0) {
    dq.push({ icon: '🚨', color: '#f87171', urgency: 'urgent',
      title: removedCount + ' clinic' + (removedCount > 1 ? 's' : '') + ' removed from CMS inventory',
      detail: 'Potential closures — check for acquisition or disposition opportunities',
      action: 'Review closures', tab: 'inventory', preFilter: 'removed' });
  }
  const npiSignalCount = (typeof diaData !== 'undefined' && diaData.npiSummary) ? Object.values(diaData.npiSummary).reduce((s, r) => s + (r.signal_count || 0), 0) : 0;
  const npiAutoResolvable = (typeof diaData !== 'undefined' && diaData.npiSummary) ? Object.values(diaData.npiSummary).reduce((s, r) => s + (r.auto_resolvable_count || 0), 0) : 0;
  const npiActionableCount = Math.max(0, npiSignalCount - npiAutoResolvable);
  if (npiActionableCount > 0) {
    dq.push({ icon: '📡', color: '#fb923c', urgency: 'warning',
      title: npiActionableCount + ' NPI signal' + (npiActionableCount > 1 ? 's' : '') + ' need review',
      detail: 'Clinics with missing or duplicate NPIs — fix data quality issues that block ownership matching',
      action: 'Review Signals', tab: 'npi' });
  }
  const propQueueLen = (typeof diaData !== 'undefined' && diaData.propertyReviewQueue) ? diaData.propertyReviewQueue.length : 0;
  if (propQueueLen > 10) {
    dq.push({ icon: '🔗', color: '#a78bfa', urgency: 'info',
      title: propQueueLen + ' clinic' + (propQueueLen > 1 ? 's' : '') + ' in property review queue',
      detail: 'Unlinked clinics need property matching for lease + ownership data',
      action: 'Start Review', tab: 'research' });
  }
  const leaseBackfillLen = (typeof diaData !== 'undefined' && diaData.leaseBackfillRows) ? diaData.leaseBackfillRows.length : 0;
  const leaseBackfillExact = (typeof diaData !== 'undefined' && diaData.leaseBackfillCount != null && diaData.leaseBackfillCount > 0)
    ? diaData.leaseBackfillCount : leaseBackfillLen;
  if (leaseBackfillExact > 20) {
    dq.push({ icon: '📋', color: '#22d3ee', urgency: 'info',
      title: fmtN(leaseBackfillExact) + ' clinic' + (leaseBackfillExact > 1 ? 's' : '') + ' need lease backfill',
      detail: 'Missing lease data — prioritize high-value clinics',
      action: 'Backfill Leases', tab: 'research' });
  }
  const addedCount = (typeof diaData !== 'undefined' && diaData.inventorySummary) ? (diaData.inventorySummary.added?.clinic_count || 0) : 0;
  if (addedCount > 0) {
    dq.push({ icon: '🆕', color: '#34d399', urgency: 'info',
      title: addedCount + ' new clinic' + (addedCount > 1 ? 's' : '') + ' added to CMS inventory',
      detail: 'New facilities — may need property linking and operator research',
      action: 'Review new clinics', tab: 'inventory', preFilter: 'added' });
  }

  const items = bd.concat(dq);
  if (!items.length) return '';
  let html = '<div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--text3);margin-bottom:10px;padding-left:2px">Action Items</div>';
  for (const h of items.slice(0, 6)) {
    const borderColor = h.urgency === 'urgent' ? h.color : h.urgency === 'warning' ? h.color : 'var(--border)';
    const _pf = h.preFilter ? ",'" + h.preFilter + "'" : '';
    html += '<div style="display:flex;align-items:center;gap:12px;padding:10px 14px;margin-bottom:6px;background:var(--s2);border-radius:10px;border-left:3px solid ' + borderColor + ';cursor:pointer" onclick="goToDiaTab(\'' + h.tab + '\'' + _pf + ')">';
    html += '<span style="font-size:20px;flex-shrink:0">' + h.icon + '</span>';
    html += '<div style="flex:1;min-width:0">';
    html += '<div style="font-size:13px;font-weight:600;color:var(--text)">' + esc(h.title) + '</div>';
    html += '<div style="font-size:12px;color:var(--text3);margin-top:2px">' + esc(h.detail) + '</div>';
    html += '</div>';
    html += '<button class="gov-row-action accent" onclick="event.stopPropagation();goToDiaTab(\'' + h.tab + '\'' + _pf + ')" style="flex-shrink:0">' + esc(h.action) + '</button>';
    html += '</div>';
  }
  return html;
}

/**
 * Render overview — infographic-style command center homepage
 */
function renderDiaOverview() {
  // UI Phase 2: load the single-row overview-stats MV (Portfolio at a Glance,
  // Lease Expiration Risk, Operator/Geographic Breakdown). Fast (~100ms); fills
  // the value-first placeholder divs when it resolves. Mirrors gov's
  // mv_gov_overview_stats fast-path.
  if (!diaOverviewStats && !_diaOverviewStatsLoading) {
    _diaOverviewStatsLoading = true;
    (async () => {
      try {
        const res = await diaQuery('mv_dia_overview_stats', '*', { limit: 1 });
        const row = (Array.isArray(res) ? res : (res && res.data) || [])[0];
        diaOverviewStats = row ? row : { _empty: true };
      } catch (e) {
        console.warn('dia overview stats load failed:', e.message);
        diaOverviewStats = { _error: e.message || 'load failed' };
      }
      _diaOverviewStatsLoading = false;
      const g = document.getElementById('diaPortfolioGlance'); if (g) g.innerHTML = renderDiaPortfolioGlanceInner();
      const r = document.getElementById('diaLeaseExpRisk'); if (r) r.innerHTML = renderDiaLeaseExpRiskInner();
      const b = document.getElementById('diaBreakdown'); if (b) b.innerHTML = renderDiaBreakdownInner();
      // BD-signal Action Items (leases expiring < 6mo) key on the MV — refresh
      // the placeholder so they surface once the MV lands (BD-first taxonomy).
      const ai = document.getElementById('diaActionItems'); if (ai) ai.innerHTML = renderDiaActionItemsInner();
      // Lease Coverage (Data Health) keys on the same MV — refresh it once the
      // MV lands so it isn't stuck on the '—' first-paint placeholder (Unit 3).
      const lc = _diaLeaseCoverage();
      const lcv = document.getElementById('diaLeaseCoverageVal'); if (lcv) lcv.textContent = lc.pct;
      const lcs = document.getElementById('diaLeaseCoverageSub'); if (lcs) lcs.textContent = lc.sub;
    })();
  }
  // Kick off lazy-loading sales comps and listings in background if not cached
  if (!diaSalesComps && !diaSalesLoading) {
    diaSalesLoading = true;
    (async () => {
      try {
        diaSalesComps = await loadDiaSalesCompsFromTxns();
      } catch(e) { diaSalesComps = []; console.warn('Sales comps load failed:', e.message); }
      diaSalesLoading = false;
      // Re-render sales sections once loaded (check for DOM elements)
      var salesEl = document.getElementById('diaOverviewSales');
      if (salesEl) salesEl.innerHTML = renderSalesMetricsInner();
      var nmEl = document.getElementById('diaOverviewNM');
      if (nmEl) nmEl.innerHTML = renderNorthmarqInner();
    })();
  }
  if (!diaAvailListings && !_diaAvailListingsLoading) {
    _diaAvailListingsLoading = true;
    (async () => {
      try {
        // v_available_listings is now gated on the authoritative lifecycle flag
        // (is_active AND no sale; synthetic imports excluded) at the DB level —
        // see SALES_AND_AVAILABLE_COMPS_DEFINITION_AUDIT_2026-05-29.md. No
        // client-side status filter needed (it would only risk re-dropping
        // genuine re-listings whose status text lags). Trust the view.
        let all = [], pg = 0;
        while (true) {
          const batch = await diaQuery('v_available_listings', '*', {
            order: 'listing_date.desc.nullslast',
            limit: 1000, offset: pg * 1000,
          });
          all = all.concat(batch || []);
          if (!batch || batch.length < 1000) break;
          pg++;
        }
        // Filter out blank records — require at least an address or operator
        diaAvailListings = all.filter(r =>
          (r.address && r.address.trim()) ||
          (r.tenant_operator && r.tenant_operator.trim()) ||
          (r.operator && r.operator.trim())
        );
        console.debug('Available listings loaded:', diaAvailListings.length, 'of', all.length, 'raw');
      } catch(e) { console.warn('Available listings load failed:', e.message); diaAvailListings = []; }
      // Canonical CURRENT on-market membership (v_dia_on_market = T9d set, ~184)
      // drives the Listings-tab filter. Normally loaded in the main Promise.all
      // (diaData.onMarketRows → diaOnMarketIds); only fetch here as a fallback if
      // the main load hasn't populated it (e.g. Listings tab opened first).
      if (!diaOnMarketIds || diaOnMarketIds.size === 0) {
        try {
          const om = await diaQuery('v_dia_on_market', 'listing_id', { limit: 1000 });
          const omRows = Array.isArray(om) ? om : (om && om.data) || [];
          diaOnMarketIds = new Set(omRows.map(r => r.listing_id));
        } catch (e) { console.warn('v_dia_on_market load failed:', e.message); }
      }
      _diaAvailListingsLoading = false;
      const mktEl = document.getElementById('diaOverviewMarket');
      if (mktEl) mktEl.innerHTML = renderOnMarketInner();
    })();
  }

  // Lazy-load clinic financial estimates (paginated — ~20K rows with is_latest)
  // PostgREST max-rows caps at 1000 per request, so paginate at 1000
  if (!diaFinancialEstimates && !_diaFinancialEstimatesLoading) {
    _diaFinancialEstimatesLoading = true;
    (async () => {
      try {
        // R4-B: read the server-side summary (v_clinic_financial_overview, ONE
        // row) instead of paging ~36K is_latest estimate rows client-side. The
        // old keyset loop made 37 round trips through the edge function and
        // routinely never finished inside a session ("Loading full patient
        // data..." forever). The view pre-aggregates best-per-clinic exactly
        // like the renderer did.
        const res = await diaQuery('v_clinic_financial_overview', '*', { limit: 1, count: 'false' });
        // Tolerate both diaQuery return shapes (bare array OR {data:[]}) — same
        // defensiveness as the SJC loader (DIA_OVERVIEW_TILE_AUDIT Unit 2).
        const row = (Array.isArray(res) ? res : (res && res.data) || [])[0];
        diaFinancialEstimates = row ? row : { _empty: true };
      } catch(e) {
        console.warn('Financial estimates summary load failed:', e.message);
        // Fail visibly, not an eternal spinner.
        diaFinancialEstimates = { _error: e.message || 'load failed' };
      }
      _diaFinancialEstimatesLoading = false;
      const finEl = document.getElementById('diaOverviewFinancials');
      if (finEl) finEl.innerHTML = renderFinancialMetricsInner();
    })();
  }

  // Lazy-load patient counts from v_facility_patient_counts_latest (8K+ clinics)
  // PostgREST max-rows caps at 1000, paginate accordingly
  if (!diaPatientCounts && !_diaPatientCountsLoading) {
    _diaPatientCountsLoading = true;
    (async () => {
      try {
        const PAGE = 1000;
        let all = [], pg = 0;
        while (true) {
          const batch = await diaQuery('v_facility_patient_counts_latest', 'clinic_id,total_patients,state', {
            limit: PAGE, offset: pg * PAGE,
          });
          all = all.concat(batch || []);
          if (!batch || batch.length < PAGE) break;
          pg++;
        }
        // Deduplicate by normalized clinic_id (some appear with/without leading zeros)
        const seen = {};
        diaPatientCounts = all.filter(r => {
          if (!r.total_patients || r.total_patients <= 0) return false;
          const normId = r.clinic_id ? r.clinic_id.replace(/^0+/, '') : r.clinic_id;
          if (seen[normId]) return false;
          seen[normId] = true;
          return true;
        });
      } catch(e) { diaPatientCounts = []; }
      _diaPatientCountsLoading = false;
      // Re-render the patient metrics section
      const ptEl = document.getElementById('diaOverviewPatientMetrics');
      if (ptEl) ptEl.innerHTML = renderPatientMetricsInner();
    })();
  }

  // Ownership Coverage tiles now render SYNCHRONOUSLY from diaData.ownershipCoverage
  // + diaData.unprospectedCount (loaded in the main loadDiaData Promise.all), so a
  // re-render (e.g. _loadDiaHeavyDetail) never strands them on "loading…". The
  // ONLY lazy load left here is the modal top-list (v_prospect_targets rows) for
  // the BD-targets drill-down — gated on cache-null (not a once-flag), so it can
  // re-fetch if the cache is cleared but skips when already loaded.
  if (window._diaTopUnprospected == null && !_diaOwnershipCoverageLoading) {
    _diaOwnershipCoverageLoading = true;
    (async () => {
      try {
        const ptRes = await diaQuery('v_prospect_targets', 'true_owner_id,name,prop_count,state,last_contact_date,prospecting_status', { order: 'prop_count.desc.nullslast', limit: 1000 });
        window._diaTopUnprospected = Array.isArray(ptRes) ? ptRes : (ptRes && ptRes.data) || [];
      } catch (err) {
        console.warn('Prospect targets (modal list) load failed:', err.message);
        window._diaTopUnprospected = window._diaTopUnprospected || [];
      }
      _diaOwnershipCoverageLoading = false;
    })();
  }

  // Lazy-load SJC Salesforce deal book (Section 6b). Reads the aggregated
  // v_sjc_deal_book_summary (small) so it's cheap; gated to load once/session.
  if (!_diaSjcDealBookLoading && !diaSjcDealBook) {
    _diaSjcDealBookLoading = true;
    (async () => {
      try {
        const rows = await diaQueryAll('v_sjc_deal_book_summary', '*');
        const data = Array.isArray(rows) ? rows : (rows.data || []);
        const sale = data.filter(r => r.deal_side === 'Sale Deal - Commercial');
        const sumF = (arr, f) => arr.reduce((s, r) => s + (Number(r[f]) || 0), 0);
        const closedRows = sale.filter(r => r.deal_stage === 'closed');
        const closedDeals = sumF(closedRows, 'closed_deals');
        const closedVol = sumF(closedRows, 'closed_volume');
        const activeDeals = sumF(sale.filter(r => r.deal_stage === 'active_listing'), 'deals');
        const ucDeals = sumF(sale.filter(r => r.deal_stage === 'in_escrow' || r.deal_stage === 'under_loi'), 'deals');
        const setTxt = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
        setTxt('sjcClosedVal', fmtN(closedDeals)); setTxt('sjcClosedSub', 'closed sale deals (all teams)');
        setTxt('sjcVolVal', '$' + fmtN(Math.round(closedVol / 1e6)) + 'M'); setTxt('sjcVolSub', 'lifetime closed volume');
        setTxt('sjcActiveVal', fmtN(activeDeals)); setTxt('sjcActiveSub', 'signed & marketing');
        setTxt('sjcUCVal', fmtN(ucDeals)); setTxt('sjcUCSub', 'LOI executed / in escrow');

        // Closed-sales track record by year. Built into a string so it can be
        // both injected now AND cached for the next render (Unit 1).
        let byYearHtml = '';
        try {
          const yrs = await diaQueryAll('v_sjc_deal_book_by_year', '*');
          const yrRows = (Array.isArray(yrs) ? yrs : (yrs && yrs.data) || [])
            .filter(r => r.close_year).sort((a, b) => b.close_year - a.close_year).slice(0, 10);
          if (yrRows.length) {
            const maxVol = Math.max.apply(null, yrRows.map(r => Number(r.closed_volume) || 0)) || 1;
            let t = '<div style="font-size:11px;color:var(--text3);margin:6px 0 4px">Closed sales by year (Sale Deal - Commercial)</div>'
              + '<table style="width:100%;border-collapse:collapse;font-size:12px"><tbody>';
            yrRows.forEach(r => {
              const vol = Number(r.closed_volume) || 0;
              const barPct = Math.round(vol / maxVol * 100);
              t += '<tr style="border-top:1px solid var(--border)">'
                + '<td style="padding:4px 8px;width:48px">' + r.close_year + '</td>'
                + '<td style="padding:4px 8px;text-align:right;width:64px">' + fmtN(r.closed_deals) + '</td>'
                + '<td style="padding:4px 8px;text-align:right;width:80px">$' + fmtN(Math.round(vol / 1e6)) + 'M</td>'
                + '<td style="padding:4px 8px"><div style="background:var(--green,#34d399);height:8px;border-radius:4px;width:' + barPct + '%;min-width:2px"></div></td>'
                + '<td style="padding:4px 8px;text-align:right;width:64px;color:var(--text3)">' + (r.avg_cap_rate ? (Number(r.avg_cap_rate) * 100).toFixed(2) + '%' : '') + '</td></tr>';
            });
            t += '</tbody></table>';
            byYearHtml = t;
            const ywrap = document.getElementById('sjcDealBookByYear');
            if (ywrap) ywrap.innerHTML = t;
          }
        } catch (ye) { console.warn('sjc by-year load failed:', ye.message); }

        // Per-team rollup (sale-side), ranked by closed deals.
        const byTeam = {};
        sale.forEach(r => {
          const t = r.sjc_team || '(unassigned)';
          byTeam[t] = byTeam[t] || { team: t, closed: 0, vol: 0, active: 0, uc: 0 };
          if (r.deal_stage === 'closed') { byTeam[t].closed += Number(r.closed_deals) || 0; byTeam[t].vol += Number(r.closed_volume) || 0; }
          if (r.deal_stage === 'active_listing') byTeam[t].active += Number(r.deals) || 0;
          if (r.deal_stage === 'in_escrow' || r.deal_stage === 'under_loi') byTeam[t].uc += Number(r.deals) || 0;
        });
        const teams = Object.values(byTeam).sort((a, b) => b.closed - a.closed).slice(0, 12);
        let teamsHtml = '';
        if (teams.length) {
          let t = '<table style="width:100%;border-collapse:collapse;font-size:12px"><thead><tr style="text-align:left;color:var(--text3)">'
            + '<th style="padding:4px 8px">Team</th><th style="padding:4px 8px;text-align:right">Closed</th>'
            + '<th style="padding:4px 8px;text-align:right">Closed Vol</th><th style="padding:4px 8px;text-align:right">Active</th>'
            + '<th style="padding:4px 8px;text-align:right">Under Contract</th></tr></thead><tbody>';
          teams.forEach(r => {
            t += '<tr style="border-top:1px solid var(--border)">'
              + '<td style="padding:4px 8px">' + esc(r.team) + '</td>'
              + '<td style="padding:4px 8px;text-align:right">' + fmtN(r.closed) + '</td>'
              + '<td style="padding:4px 8px;text-align:right">$' + fmtN(Math.round(r.vol / 1e6)) + 'M</td>'
              + '<td style="padding:4px 8px;text-align:right">' + fmtN(r.active) + '</td>'
              + '<td style="padding:4px 8px;text-align:right">' + fmtN(r.uc) + '</td></tr>';
          });
          t += '</tbody></table>';
          teamsHtml = t;
          const wrap = document.getElementById('sjcDealBookTeams');
          if (wrap) wrap.innerHTML = t;
        }

        // Recent closed sale deals (drill list). Unit 5: each row links through
        // to the LCC property detail (linked_property_id) when matched, else to
        // the Salesforce Opportunity (sf_deal_id) — graceful non-clickable when
        // neither id is present.
        const recent = await diaQuery('v_sjc_deal_book',
          'deal_name,sjc_team,state,closed_price,est_close_date,deal_side,linked_property_id,sf_deal_id',
          { filter: 'deal_stage=eq.closed', order: 'est_close_date.desc.nullslast', limit: 25 });
        const recentRows = (Array.isArray(recent) ? recent : (recent && recent.data) || [])
          .filter(r => r.deal_side === 'Sale Deal - Commercial').slice(0, 10);
        let recentHtml = '';
        if (recentRows.length) {
          let t = '<div style="font-size:11px;color:var(--text3);margin:6px 0 4px">Recent closed sales</div>'
            + '<table style="width:100%;border-collapse:collapse;font-size:12px"><tbody>';
          recentRows.forEach(r => {
            const pid = Number(r.linked_property_id) || 0;
            const sfId = r.sf_deal_id ? String(r.sf_deal_id) : '';
            // UI Phase 3 Unit 0b — use the shared .clickable-row class (cursor:
            // pointer + hover) so the click is discoverable. The old inline
            // style="cursor:pointer" was a SECOND style attr on a <tr> that
            // already had style="border-top…" → the browser ignored it.
            let rowAttr = '';
            if (pid) {
              rowAttr = ' class="clickable-row" onclick="openUnifiedDetail(\'dialysis\',{property_id:' + pid + '},null,\'sales\')" title="Open property detail"';
            } else if (sfId) {
              rowAttr = ' class="clickable-row" onclick="window.open(\'https://northmarqcapital.lightning.force.com/lightning/r/Opportunity/' + encodeURIComponent(sfId) + '/view\',\'_blank\',\'noopener\')" title="Open deal in Salesforce"';
            }
            t += '<tr style="border-top:1px solid var(--border)"' + rowAttr + '>'
              + '<td style="padding:4px 8px">' + esc((r.deal_name || '—').substring(0, 48)) + '</td>'
              + '<td style="padding:4px 8px;color:var(--text3)">' + esc(r.sjc_team || '') + '</td>'
              + '<td style="padding:4px 8px;color:var(--text3)">' + esc(r.state || '') + '</td>'
              + '<td style="padding:4px 8px;text-align:right">' + (r.closed_price ? '$' + fmtN(Math.round(Number(r.closed_price) / 1e6 * 10) / 10) + 'M' : '—') + '</td>'
              + '<td style="padding:4px 8px;text-align:right;color:var(--text3)">' + esc(r.est_close_date || '') + '</td></tr>';
          });
          t += '</tbody></table>';
          recentHtml = t;
          const rwrap = document.getElementById('sjcRecentDeals');
          if (rwrap) rwrap.innerHTML = t;
        }

        // Cache so a re-render paints tiles + tables from memory (no '...').
        diaSjcDealBook = { closedDeals, closedVol, activeDeals, ucDeals, byYearHtml, teamsHtml, recentHtml };
      } catch (err) {
        console.warn('SJC deal book load failed:', err.message);
        const wrap = document.getElementById('diaSjcDealBook');
        if (wrap) wrap.innerHTML = '<div class="dia-info-card" style="padding:16px;color:var(--text3);font-size:12px">SJC deal book unavailable</div>';
      }
      _diaSjcDealBookLoading = false;
    })();
  }

  // Listings Needing Confirmation (Section 7b): the 3 count tiles render
  // SYNCHRONOUSLY from window._lcConfirmRows (loaded in the main Promise.all).
  // Fill the resolve LIST once the Overview HTML is in the DOM — re-render safe
  // (reads the same cache; getElementById no-ops if the Overview isn't mounted).
  setTimeout(function() { try { renderDiaListingConfirm(); } catch (e) {} }, 0);

  // LLC Research Queue (Section 7c): the count tiles render SYNCHRONOUSLY from the
  // main-loaded health globals (window._diaLlcPending / _diaLlcDone). The per-owner
  // resolve list comes from a separate endpoint (/api/llc-research-queue) — lazy,
  // gated on cache-null (not a once-flag) so it re-fetches if cleared, and it
  // NEVER blocks the count tiles.
  if (window._llcQueueItems == null && !_diaLlcQueueLoading) {
    _diaLlcQueueLoading = true;
    (async () => {
      try {
        const _ctrl = new AbortController();
        const _to = setTimeout(() => _ctrl.abort(), 20000);
        let resp;
        try {
          resp = await fetch('/api/llc-research-queue?domain=dialysis&limit=25', { signal: _ctrl.signal });
        } finally { clearTimeout(_to); }
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        const j = await resp.json();
        window._llcQueueItems = (j && j.items) || [];
      } catch (err) {
        const msg = err.name === 'AbortError' ? 'request timed out' : (err.message || 'load failed');
        console.warn('llc queue list load failed:', msg);
        window._llcQueueItems = window._llcQueueItems || [];
      }
      _diaLlcQueueLoading = false;
      try { renderDiaLlcQueue(); } catch (e) {}
    })();
  }
  setTimeout(function() { try { renderDiaLlcQueue(); } catch (e) {} }, 0);

  let html = '<div style="padding:4px 0">';

  // ── STYLE ──
  html += `<style>
    .dia-info-card { background: var(--s2); border: 1px solid var(--border); border-radius: 12px; padding: 16px 18px; transition: all 0.15s; position: relative; overflow: hidden; }
    .dia-info-card:hover { border-color: var(--accent); transform: translateY(-1px); box-shadow: 0 4px 20px rgba(0,0,0,0.15); }
    .dia-info-card[onclick] { cursor: pointer; }
    .dia-info-card[onclick]::after { content: '→'; position: absolute; top: 12px; right: 14px; font-size: 14px; color: var(--text3); opacity: 0; transition: opacity 0.15s; }
    .dia-info-card[onclick]:hover::after { opacity: 1; color: var(--accent); }
    .dia-grid { display: grid; gap: 10px; }
    .dia-grid-4 { grid-template-columns: repeat(4, 1fr); }
    .dia-grid-3 { grid-template-columns: repeat(3, 1fr); }
    .dia-grid-5 { grid-template-columns: repeat(5, 1fr); }
    .dia-divider { border: none; border-top: 1px solid var(--border); margin: 8px 0; }
    @media (max-width: 900px) {
      .dia-grid-4, .dia-grid-5 { grid-template-columns: repeat(2, 1fr); }
      .dia-grid-3 { grid-template-columns: repeat(2, 1fr); }
    }
  </style>`;

  // ── DATA ──
  const f = diaData.freshness || {};
  const totalClinics = f.total_clinics || 0;
  const coveragePct = f.coverage_pct || 0;
  const clinicsWithCounts = f.clinics_with_counts || 0;
  const addedCount = diaData.inventorySummary.added?.clinic_count || 0;
  const removedCount = diaData.inventorySummary.removed?.clinic_count || 0;
  const npiSignalCount = Object.values(diaData.npiSummary).reduce((s,r) => s + (r.signal_count||0), 0);
  // Round 76eb: actionable = total minus auto_resolvable (which the matview hides by default)
  const npiAutoResolvable = Object.values(diaData.npiSummary).reduce((s,r) => s + (r.auto_resolvable_count||0), 0);
  const npiActionableCount = Math.max(0, npiSignalCount - npiAutoResolvable);
  const propQueueLen = diaData.propertyReviewQueue?.length || 0;
  const leaseBackfillLen = diaData.leaseBackfillRows?.length || 0;
  // UI Phase 3 Unit 0a — the honest backlog size = the count=exact probe
  // (v_clinic_lease_backfill_candidates, ~3,035), never the 1,000-row capped
  // page. Falls back to the capped length only when the probe didn't load.
  const leaseBackfillExact = (diaData.leaseBackfillCount != null && diaData.leaseBackfillCount > 0)
    ? diaData.leaseBackfillCount : leaseBackfillLen;
  // True count from count=exact (research_queue_outcomes ~1,166); falls back to
  // the capped page length only if the probe failed. Never the 1,000 cap.
  const researchDone = (diaData.researchOutcomesCount != null && diaData.researchOutcomesCount > 0)
    ? diaData.researchOutcomesCount
    : (diaData.researchOutcomes?.length || 0);

  // Compute patient stats from v_facility_patient_counts_latest (loaded async) or inventory diff as fallback
  const ptSrc = diaPatientCounts && diaPatientCounts.length > 0 ? diaPatientCounts : diaData.inventoryChanges.filter(c => c.latest_total_patients > 0);
  const clinicsWithPatients = diaPatientCounts && diaPatientCounts.length > 0 ? ptSrc : ptSrc;
  const totalPatients = ptSrc.reduce((s,c) => s + (c.total_patients || c.latest_total_patients || 0), 0);
  const avgPatients = ptSrc.length > 0 ? Math.round(totalPatients / ptSrc.length) : 0;

  // Touchpoint metrics from DIA Supabase salesforce_activities — full Northmarq IS team
  const diaActivities = diaData.sfActivities || [];
  const now = new Date();
  const sixMonthsAgo = new Date(now); sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
  const oneMonthAgo = new Date(now); oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
  const yearStart = new Date(now.getFullYear(), 0, 1);
  const touchpointsYTD = diaActivities.filter(a => a.activity_date && new Date(a.activity_date) >= yearStart).length;
  const touchpoints6mo = diaActivities.filter(a => a.activity_date && new Date(a.activity_date) >= sixMonthsAgo).length;
  const touchpoints1mo = diaActivities.filter(a => a.activity_date && new Date(a.activity_date) >= oneMonthAgo).length;
  const uniqueAccounts = new Set(diaActivities.map(a => a.company_name).filter(Boolean)).size;
  const avgTouchPerAcct = uniqueAccounts > 0 ? (touchpointsYTD / uniqueAccounts).toFixed(1) : '—';

  // Property linkage stats
  const linkedPct = totalClinics > 0 ? ((totalClinics - propQueueLen) / totalClinics * 100).toFixed(1) : '—';
  // Lease Coverage is derived from the server-side MV (see _diaLeaseCoverage),
  // NOT from `1 - cappedPageLength/totalClinics` (which falsely read 100%/0 on
  // an empty/timed-out fetch and measured the wrong denominator). Unit 3.
  const leaseCov = _diaLeaseCoverage();

  // ═══════════════════════════════════════════════
  // SECTION 0: ACTIONABLE HIGHLIGHTS (Round 54)
  // Auto-populated from live data — what needs your attention right now
  // ═══════════════════════════════════════════════
  // SECTION 0: ACTION ITEMS — BD-first-then-DQ taxonomy shared with gov,
  // rendered into a refreshable placeholder (BD counts load async — see the
  // mv/listings callbacks below).
  html += '<div id="diaActionItems" style="margin-bottom:20px">' + renderDiaActionItemsInner() + '</div>';

  // ═══════════════════════════════════════════════
  // UI Phase 2 — unified value-first Overview order (mirrors gov.js):
  // Portfolio → Lease Expiration Risk → Market Activity → Pipeline →
  // Breakdown → Data Health & Coverage (ops at the bottom).
  // ═══════════════════════════════════════════════
  const _diaGroup = (label) => '<div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:1.5px;color:var(--text3);margin:30px 0 0;padding:0 2px 6px;border-bottom:2px solid var(--border)">' + label + '</div>';

  // ── SECTION 1: PORTFOLIO AT A GLANCE (value-first headline) ──
  html += sectionHeader('Portfolio at a Glance', '🏥', 'search');
  html += '<div id="diaPortfolioGlance">' + renderDiaPortfolioGlanceInner() + '</div>';

  // ── SECTION 2: LEASE EXPIRATION RISK ──
  html += sectionHeader('Lease Expiration Risk', '⏰', 'sales');
  html += '<div id="diaLeaseExpRisk">' + renderDiaLeaseExpRiskInner() + '</div>';

  // ── SECTION 3: MARKET ACTIVITY (TTM Sales · Northmarq · On Market · SJC) ──
  html += _diaGroup('Market Activity');
  html += sectionHeader('TTM Sales Activity', '💰', 'sales');
  html += '<div id="diaOverviewSales">' + renderSalesMetricsInner() + '</div>';

  html += sectionHeader('Northmarq Performance', '🏆', 'sales');
  html += '<div id="diaOverviewNM">' + renderNorthmarqInner() + '</div>';

  html += sectionHeader('On Market', '🏪', 'sales');
  html += '<div id="diaOverviewMarket">' + renderOnMarketInner() + '</div>';

  // SJC Deal Book (Salesforce, all teams) — value tiles render from the cached
  // summary (diaSjcDealBook) when present so a re-render keeps the real numbers
  // instead of collapsing back to '...'; the one-shot async fetch below fills
  // the cache on first load (DIA_OVERVIEW_TILE_AUDIT Unit 1).
  html += sectionHeader('SJC Deal Book (Salesforce)', '📒', 'sales');
  const _sjc = diaSjcDealBook;
  html += '<div id="diaSjcDealBook"><div class="dia-grid dia-grid-4">';
  html += infoCard({ title: 'Closed Sales', value: _sjc ? fmtN(_sjc.closedDeals) : '...', sub: _sjc ? 'closed sale deals (all teams)' : 'loading Salesforce deal book', color: 'green', id: 'sjcClosedVal', subId: 'sjcClosedSub' });
  html += infoCard({ title: 'Closed Volume', value: _sjc ? '$' + fmtN(Math.round(_sjc.closedVol / 1e6)) + 'M' : '...', sub: _sjc ? 'lifetime closed volume' : 'all teams', color: 'blue', id: 'sjcVolVal', subId: 'sjcVolSub' });
  html += infoCard({ title: 'Active Listings', value: _sjc ? fmtN(_sjc.activeDeals) : '...', sub: _sjc ? 'signed & marketing' : 'listing signed', color: 'cyan', id: 'sjcActiveVal', subId: 'sjcActiveSub' });
  html += infoCard({ title: 'Under Contract', value: _sjc ? fmtN(_sjc.ucDeals) : '...', sub: _sjc ? 'LOI executed / in escrow' : 'LOI / escrow', color: 'orange', id: 'sjcUCVal', subId: 'sjcUCSub' });
  html += '</div><div id="sjcDealBookByYear" style="margin-top:10px">' + ((_sjc && _sjc.byYearHtml) || '') + '</div><div id="sjcDealBookTeams" style="margin-top:10px">' + ((_sjc && _sjc.teamsHtml) || '') + '</div><div id="sjcRecentDeals" style="margin-top:10px">' + ((_sjc && _sjc.recentHtml) || '') + '</div></div>';

  // ── SECTION 4: PIPELINE SNAPSHOT (team BD activity) ──
  html += _diaGroup('Pipeline Snapshot');
  html += sectionHeader('Team Outreach & Touchpoints', '📞', 'activity');
  html += '<div class="dia-grid dia-grid-5">';
  html += infoCard({ title: 'Team Touchpoints YTD', value: fmtN(touchpointsYTD), sub: now.getFullYear() + ' year to date', color: 'blue', tab: 'activity' });
  html += infoCard({ title: 'Last 6 Months', value: fmtN(touchpoints6mo), sub: 'team contacts', color: 'green', tab: 'activity' });
  html += infoCard({ title: 'Last 30 Days', value: fmtN(touchpoints1mo), sub: 'recent contacts', color: 'cyan', tab: 'activity' });
  html += infoCard({ title: 'Unique Accounts', value: fmtN(uniqueAccounts), sub: 'companies touched', color: 'purple', tab: 'activity' });
  html += infoCard({ title: 'Avg / Account', value: avgTouchPerAcct, sub: 'touchpoints per account YTD', color: 'yellow', tab: 'activity' });
  html += '</div>';

  // Per-team-member breakdown
  html += '<div class="dia-grid dia-grid-4" style="margin-top:10px">';
  const memberColors = { 'kelly largent': 'green', 'sarah martin': 'purple', 'scott briggs': 'blue', 'nathanael berwaldt': 'cyan' };
  NM_TEAM.forEach(name => {
    const lastName = name.split(' ').pop();
    const memberActs = diaActivities.filter(a => (a.assigned_to || '').toLowerCase().includes(lastName));
    const ytd = memberActs.filter(a => a.activity_date && new Date(a.activity_date) >= yearStart).length;
    const displayName = name.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
    html += infoCard({ title: displayName, value: fmtN(ytd), sub: 'YTD touchpoints', color: memberColors[name] || 'blue', tab: 'activity' });
  });
  html += '</div>';

  // ── SECTION 5: OPERATOR & GEOGRAPHIC BREAKDOWN ──
  html += sectionHeader('Operator & Geographic Breakdown', '🏢', 'search');
  html += '<div id="diaBreakdown">' + renderDiaBreakdownInner() + '</div>';

  // ═══════════════════════════════════════════════
  // SECTION 6: DATA HEALTH & COVERAGE (ops — at the bottom)
  // ═══════════════════════════════════════════════
  html += _diaGroup('Data Health &amp; Coverage');

  // Database Health
  html += sectionHeader('Database Health', '🏥', 'search');
  if (f._fallback) {
    html += '<div style="font-size:11px;color:var(--text3);margin-bottom:8px;padding:6px 10px;background:var(--s2);border-radius:6px;border-left:3px solid #fbbf24">⚠ View not available — using estimates from inventory data (' + fmtN(totalClinics) + ' clinics loaded)</div>';
  }
  html += '<div class="dia-grid dia-grid-4">';
  html += infoCard({ title: 'Total Clinics', value: fmtN(totalClinics), sub: f._fallback ? 'from inventory data' : 'tracked nationwide', color: 'blue', tab: 'search' });
  html += infoCard({ title: 'Data Coverage', value: coveragePct.toFixed(1) + '%', sub: fmtN(clinicsWithCounts) + ' clinics with patient data', color: coveragePct > 50 ? 'green' : 'yellow', tab: 'search' });
  html += infoCard({ title: 'Property Linked', value: linkedPct + '%', sub: fmtN(totalClinics - propQueueLen) + ' of ' + fmtN(totalClinics) + ' matched', color: 'cyan', tab: 'research' });
  html += infoCard({ title: 'Lease Coverage', value: leaseCov.pct, sub: leaseCov.sub, color: 'purple', tab: 'research', id: 'diaLeaseCoverageVal', subId: 'diaLeaseCoverageSub' });
  html += '</div>';

  // Clinical Metrics
  html += sectionHeader('Clinical Metrics', '📊', 'changes');
  // Honest "as of" caption — patient counts are a CMS reporting-period series,
  // published periodically (≈annually), NOT a nightly feed. Decoupled from the
  // nightly ingestion timestamp so the tiles never imply stale live data.
  (function(){
    var a = _diaPatientAsOfLabel();
    html += '<div style="font-size:11px;color:var(--text3);margin:-2px 0 8px;padding-left:2px">'
      + 'CMS patient data' + (a ? ' as of <strong>' + a + '</strong>' : '')
      + ' · CMS publishes this dataset periodically (≈annually), not nightly'
      + '</div>';
  })();
  html += '<div id="diaOverviewPatientMetrics">' + renderPatientMetricsInner() + '</div>';
  html += '<div class="dia-grid dia-grid-4" style="margin-top:10px">';
  html += infoCard({ title: 'Inventory Changes', value: fmtN(addedCount + removedCount), sub: '+' + fmtN(addedCount) + ' added · -' + fmtN(removedCount) + ' removed', color: addedCount > removedCount ? 'green' : 'red', tab: 'changes' });
  html += infoCard({ title: 'NPI Signals', value: fmtN(npiActionableCount), sub: npiAutoResolvable > 0 ? fmtN(npiAutoResolvable) + ' auto-resolved · ' + fmtN(npiActionableCount) + ' need review' : 'need human review', color: 'orange', tab: 'npi' });
  const _diaAsOfMover = _diaPatientAsOfLabel();
  const _diaHasMovers = (diaData.moversUp && diaData.moversUp.length) || (diaData.moversDown && diaData.moversDown.length);
  html += infoCard({ title: 'Top Mover', value: diaData.moversUp?.[0] ? '+' + fmtN(diaData.moversUp[0].delta_patients) : '—', sub: diaData.moversUp?.[0] ? norm(diaData.moversUp[0].facility_name && diaData.moversUp[0].facility_name !== 'null' ? diaData.moversUp[0].facility_name : diaData.moversUp[0].clinic_name || diaData.moversUp[0].address || 'Unknown Clinic').substring(0,30) : ('no new CMS period' + (_diaAsOfMover ? ' since ' + _diaAsOfMover : '')), color: 'green', tab: 'changes' });
  html += '</div>';

  // Top Movers — only real period-over-period movement (the mom view excludes
  // CMS year-end re-stamps). When there is no new genuine CMS reporting period,
  // show an honest empty-state instead of a list of <1% backfill noise. It
  // re-populates automatically when CMS publishes a new period.
  if (!_diaHasMovers) {
    html += '<div class="dia-info-card" style="margin-top:10px;padding:14px 16px;cursor:default">'
      + '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:8px">Patient Volume Movers</div>'
      + '<div style="font-size:12px;color:var(--text2);line-height:1.5">No new CMS reporting period'
      + (_diaAsOfMover ? ' since <strong>' + _diaAsOfMover + '</strong>' : '')
      + ' — patient volumes unchanged. CMS publishes this dataset periodically (≈annually); '
      + 'Top Movers updates automatically when the next period is released.</div>'
      + '</div>';
  } else {
  // Top Movers mini-charts
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px">';
  html += '<div class="dia-info-card" onclick="goToDiaTab(\'changes\')" style="cursor:pointer;padding:14px 16px">';
  html += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">Top 5 Movers Up</div>';
  (diaData.moversUp || []).slice(0, 5).forEach((r, i) => {
    const maxDelta = diaData.moversUp[0]?.delta_patients || 1;
    const barW = Math.round((r.delta_patients / maxDelta) * 100);
    html += `<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
      <div style="width:20px;font-size:10px;color:var(--text3);text-align:right">${i+1}</div>
      <div style="flex:1;font-size:11px;color:var(--text1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(norm(r.facility_name && !(/\bnull\b/i.test(r.facility_name)) ? r.facility_name : r.clinic_name && !(/\bnull\b/i.test(r.clinic_name)) ? r.clinic_name : r.address || 'Unknown Clinic').substring(0,25))}</div>
      <div style="width:80px;height:8px;background:var(--s3);border-radius:4px;overflow:hidden"><div style="width:${barW}%;height:100%;background:#34d399;border-radius:4px"></div></div>
      <div style="width:36px;font-size:10px;color:#34d399;text-align:right;font-weight:600">+${r.delta_patients}</div>
    </div>`;
  });
  html += '</div>';

  html += '<div class="dia-info-card" onclick="goToDiaTab(\'changes\')" style="cursor:pointer;padding:14px 16px">';
  html += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">Top 5 Movers Down</div>';
  (diaData.moversDown || []).slice(0, 5).forEach((r, i) => {
    const maxDelta = Math.abs(diaData.moversDown[0]?.delta_patients || 1);
    const barW = Math.round((Math.abs(r.delta_patients) / maxDelta) * 100);
    html += `<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
      <div style="width:20px;font-size:10px;color:var(--text3);text-align:right">${i+1}</div>
      <div style="flex:1;font-size:11px;color:var(--text1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(norm(r.facility_name && !(/\bnull\b/i.test(r.facility_name)) ? r.facility_name : r.clinic_name && !(/\bnull\b/i.test(r.clinic_name)) ? r.clinic_name : r.address || 'Unknown Clinic').substring(0,25))}</div>
      <div style="width:80px;height:8px;background:var(--s3);border-radius:4px;overflow:hidden"><div style="width:${barW}%;height:100%;background:#f87171;border-radius:4px"></div></div>
      <div style="width:36px;font-size:10px;color:#f87171;text-align:right;font-weight:600">${r.delta_patients}</div>
    </div>`;
  });
  html += '</div>';
  html += '</div>';
  } // end real-movers branch (else: honest "no new CMS period" empty-state above)

  // ═══════════════════════════════════════════════
  // SECTION 3: CLINIC FINANCIALS (async)
  // ═══════════════════════════════════════════════
  html += sectionHeader('Clinic Financial Estimates', '💵', 'search');
  html += '<div id="diaOverviewFinancials">' + renderFinancialMetricsInner() + '</div>';

  // Ownership Coverage — rendered SYNCHRONOUSLY from diaData.ownershipCoverage +
  // diaData.unprospectedCount (loaded in the main Promise.all). Never a hanging
  // async / once-flag, so a re-render always paints the real percentages.
  html += sectionHeader('Ownership Coverage', '🏛️', 'sales');
  html += '<div id="diaOwnershipCoverage">' + _diaOwnershipCoverageCards() + '</div>';

  // ═══════════════════════════════════════════════
  // SECTION 7b: LISTINGS NEEDING CONFIRMATION (manual follow-up)
  // The availability-checker parks "looks-sold" listings as
  // unverified_assumed_off; the sweep promotes the deed-matched ones. The rest
  // need a human. This panel surfaces them with one-click resolve actions
  // (Confirm Sold / Withdrawn / Still Active) via v_listings_needing_manual_confirmation.
  // ═══════════════════════════════════════════════
  html += sectionHeader('Listings Needing Confirmation', '🔎', 'sales');
  // Count tiles render SYNCHRONOUSLY from window._lcConfirmRows (main-loaded); the
  // resolve list fills via the scheduled renderDiaListingConfirm() call above.
  html += '<div id="diaListingConfirm">' + _diaListingConfirmTiles() + '<div id="lcConfirmList" style="margin-top:10px"></div></div>';

  // ═══════════════════════════════════════════════
  // SECTION 7c: LLC RESEARCH QUEUE (owner enrichment, manual resolve)
  // The automated llc-research-tick is feature-flagged off (no OpenCorporates
  // key); this panel makes the queue actionable — SOS lookup link + mark
  // Completed/No Match via /api/resolve-llc-research.
  // ═══════════════════════════════════════════════
  html += sectionHeader('LLC Research Queue', '🏛️', 'research');
  // Count tiles render SYNCHRONOUSLY from the main-loaded health globals; the
  // resolve list fills via the scheduled renderDiaLlcQueue() call above.
  html += '<div id="diaLlcQueue">' + _diaLlcTiles() + '<div id="llcQueueList" style="margin-top:10px"></div></div>';

  // ═══════════════════════════════════════════════
  // SECTION 8: RESEARCH PIPELINE
  // ═══════════════════════════════════════════════
  html += sectionHeader('Research Pipeline', '🔬', 'research');
  html += '<div class="dia-grid dia-grid-4">';
  html += infoCard({ title: 'Property Queue', value: fmtN(propQueueLen), sub: 'pending review', color: 'yellow', tab: 'research' });
  html += infoCard({ title: 'Lease Backfill', value: fmtN(leaseBackfillExact), sub: 'missing lease data', color: 'orange', tab: 'research' });
  html += infoCard({ title: 'Completed Reviews', value: fmtN(researchDone), sub: 'outcomes logged', color: 'green', tab: 'research' });
  const reconStatus = diaData.reconciliation?.run_status || 'unknown';
  const reconDate = diaData.reconciliation?.started_at ? new Date(diaData.reconciliation.started_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '—';
  html += infoCard({ title: 'Last Ingestion', value: reconDate, sub: reconStatus, color: reconStatus === 'success' ? 'green' : reconStatus === 'partial' ? 'yellow' : 'red' });
  html += '</div>';

  html += '</div>'; // end wrapper
  return html;
}

// ── Inner renderers for async-loaded sections ──

function renderSalesMetricsInner() {
  if (!diaSalesComps) {
    if (diaSalesLoading) {
      return '<div class="dia-grid dia-grid-5"><div class="dia-info-card" style="grid-column:span 5;text-align:center;padding:24px"><span class="spinner"></span><div style="margin-top:8px;font-size:12px;color:var(--text2)">Loading sales data...</div></div></div>';
    }
    return '<div class="dia-grid dia-grid-5"><div class="dia-info-card" style="grid-column:span 5;text-align:center;padding:24px;color:var(--text2);font-size:13px">No sales data available</div></div>';
  }
  const comps = diaSalesComps;
  const now = new Date();
  const ttmStart = new Date(now); ttmStart.setFullYear(ttmStart.getFullYear() - 1);
  const ttmComps = comps.filter(r => r.sold_date && new Date(r.sold_date) >= ttmStart);
  const ttmWithPrice = ttmComps.filter(r => r.price > 0);
  const ttmVolume = ttmWithPrice.reduce((s,r) => s + parseFloat(r.price || 0), 0);
  const ttmTxns = ttmComps.length;

  // Cap rates (filter outliers: 1%–25%)
  const validCaps = ttmComps.filter(r => { const v = parseFloat(r.cap_rate); return v > 0.01 && v < 0.25; }).map(r => parseFloat(r.cap_rate)).sort((a,b) => a - b);
  const avgCap = validCaps.length > 0 ? (validCaps.reduce((s,v) => s+v, 0) / validCaps.length * 100).toFixed(2) + '%' : '—';
  const q1Idx = Math.floor(validCaps.length * 0.25);
  const q3Idx = Math.floor(validCaps.length * 0.75);
  const lowerQCap = validCaps.length > 4 ? (validCaps[q1Idx] * 100).toFixed(2) + '%' : '—';
  const upperQCap = validCaps.length > 4 ? (validCaps[q3Idx] * 100).toFixed(2) + '%' : '—';

  let h = '<div class="dia-grid dia-grid-5">';
  h += infoCard({ title: 'TTM Volume', value: '$' + fmtN(Math.round(ttmVolume / 1000000)) + 'M', sub: fmtN(ttmWithPrice.length) + ' priced transactions', color: 'green', tab: 'sales' });
  h += infoCard({ title: 'TTM Transactions', value: fmtN(ttmTxns), sub: 'trailing 12 months', color: 'blue', tab: 'sales' });
  h += infoCard({ title: 'Avg Cap Rate', value: avgCap, sub: fmtN(validCaps.length) + ' with cap data', color: 'cyan', tab: 'sales' });
  h += infoCard({ title: 'Lower Quartile', value: lowerQCap, sub: '25th percentile', color: 'purple', tab: 'sales' });
  h += infoCard({ title: 'Upper Quartile', value: upperQCap, sub: '75th percentile', color: 'yellow', tab: 'sales' });
  h += '</div>';

  // Historical total comps
  h += '<div class="dia-grid dia-grid-3" style="margin-top:10px">';
  const allWithPrice = comps.filter(r => r.price > 0);
  const totalVolume = allWithPrice.reduce((s,r) => s + parseFloat(r.price || 0), 0);
  const avgPrice = allWithPrice.length > 0 ? '$' + fmtN(Math.round(allWithPrice.reduce((s,r) => s + parseFloat(r.price), 0) / allWithPrice.length)) : '—';
  h += infoCard({ title: 'All-Time Comps', value: fmtN(comps.length), sub: 'total in database', color: 'blue', tab: 'sales' });
  h += infoCard({ title: 'All-Time Volume', value: '$' + fmtN(Math.round(totalVolume / 1000000)) + 'M', sub: fmtN(allWithPrice.length) + ' priced sales', color: 'green', tab: 'sales' });
  h += infoCard({ title: 'Avg Sale Price', value: avgPrice, sub: 'across all comps', color: 'purple', tab: 'sales' });
  h += '</div>';
  return h;
}

function renderNorthmarqInner() {
  if (!diaSalesComps) {
    if (diaSalesLoading) {
      return '<div class="dia-grid dia-grid-4"><div class="dia-info-card" style="grid-column:span 4;text-align:center;padding:24px"><span class="spinner"></span><div style="margin-top:8px;font-size:12px;color:var(--text2)">Loading...</div></div></div>';
    }
    return '<div class="dia-grid dia-grid-4"><div class="dia-info-card" style="grid-column:span 4;text-align:center;padding:24px;color:var(--text2);font-size:13px">No Northmarq data available</div></div>';
  }
  const comps = diaSalesComps;
  const now = new Date();
  const ttmStart = new Date(now); ttmStart.setFullYear(ttmStart.getFullYear() - 1);
  const ttmComps = comps.filter(r => r.sold_date && new Date(r.sold_date) >= ttmStart);
  // Round 76ej (2026-04-29): tightened the team-member match to require the
  // FULL "first last" phrase, not any word > 3 chars. The old loose match
  // turned every "Scott Gould" / "Joseph Martin" deal into a false NM hit
  // (the dashboard's "5 of 160 TTM" was actually 1 real NM + 4 spurious
  // matches on third-party brokers named Scott / Martin). Brand strings
  // ("northmarq", "north marq", "nm capital") still match on their own.
  // r.broker_name / r.seller_broker / r.buyer_broker are dropped from the
  // concat — those keys never get set on the normalized row.
  // Canonical NM attribution = the is_northmarq flag (app.js lccIsNorthmarq),
  // matching the capital-markets views, gov dashboard, and detail.js. The flag
  // is a complete superset of the old broker-name match (which under-reported
  // dia to ~0 because team deals are spelled "Scott Briggs"/"SJC; Briggs", not
  // "Northmarq"). See 2026-05-29 NM attribution audit.
  const isNM = r => lccIsNorthmarq(r);
  const nmComps = ttmComps.filter(isNM);
  const nmWithPrice = nmComps.filter(r => r.price > 0);
  const nmVolume = nmWithPrice.reduce((s,r) => s + parseFloat(r.price || 0), 0);
  const ttmWithPrice = ttmComps.filter(r => r.price > 0);
  const ttmVolume = ttmWithPrice.reduce((s,r) => s + parseFloat(r.price || 0), 0);
  const marketShareTxn = ttmComps.length > 0 ? (nmComps.length / ttmComps.length * 100).toFixed(1) + '%' : '—';
  const marketShareVol = ttmVolume > 0 ? (nmVolume / ttmVolume * 100).toFixed(1) + '%' : '—';

  // NM avg cap vs market avg cap
  const nmCaps = nmComps.filter(r => { const v = parseFloat(r.cap_rate); return v > 0.01 && v < 0.25; }).map(r => parseFloat(r.cap_rate));
  const mktCaps = ttmComps.filter(r => { const v = parseFloat(r.cap_rate); return v > 0.01 && v < 0.25; }).map(r => parseFloat(r.cap_rate));
  const nmAvgCap = nmCaps.length > 0 ? (nmCaps.reduce((s,v)=>s+v,0)/nmCaps.length*100).toFixed(2) + '%' : '—';
  const mktAvgCap = mktCaps.length > 0 ? (mktCaps.reduce((s,v)=>s+v,0)/mktCaps.length*100).toFixed(2) + '%' : '—';
  // Cap rate advantage (lower cap = higher price = better for sellers).
  // Positive bps = NM cap tighter than market = better for sellers.
  // Negative bps = NM cap wider than market = worse for sellers.
  // Round 76ej: the label used to be a hardcoded "tighter" regardless of
  // sign — so "-68 bps tighter" rendered for clearly-wider results, which
  // looked like a math contradiction. Pick "tighter" / "wider" / "even"
  // dynamically and use Math.abs for the magnitude.
  const capAdv = (nmCaps.length > 0 && mktCaps.length > 0) ?
    Math.round((mktCaps.reduce((s,v)=>s+v,0)/mktCaps.length - nmCaps.reduce((s,v)=>s+v,0)/nmCaps.length) * 10000) : null;
  let capAdvStr;
  if (capAdv === null) {
    capAdvStr = '—';
  } else if (capAdv === 0) {
    capAdvStr = 'even with market';
  } else if (capAdv > 0) {
    capAdvStr = capAdv + ' bps tighter';
  } else {
    capAdvStr = Math.abs(capAdv) + ' bps wider';
  }

  let h = '<div class="dia-grid dia-grid-4">';
  h += infoCard({ title: 'NM TTM Sales', value: fmtN(nmComps.length), sub: '$' + fmtN(Math.round(nmVolume / 1000000)) + 'M volume', color: 'green', tab: 'sales' });
  h += infoCard({ title: 'Market Share (Txns)', value: marketShareTxn, sub: fmtN(nmComps.length) + ' of ' + fmtN(ttmComps.length) + ' TTM deals', color: 'blue', tab: 'sales' });
  h += infoCard({ title: 'NM Avg Cap Rate', value: nmAvgCap, sub: 'vs ' + mktAvgCap + ' market avg', color: 'cyan', tab: 'sales' });
  h += infoCard({ title: 'Seller Value Add', value: capAdvStr, sub: capAdv != null && Number(capAdv) > 0 ? 'tighter caps = higher proceeds' : 'vs market average', color: capAdv != null && Number(capAdv) > 0 ? 'green' : 'yellow', tab: 'sales' });
  h += '</div>';
  return h;
}

// Render the Listings Needing Confirmation panel from window._lcConfirmRows.
function renderDiaListingConfirm() {
  const rows = window._lcConfirmRows || [];
  const matchReady = rows.filter(r => r.confirmation_state === 'sale_match_promote');
  const aged = rows.filter(r => r.confirmation_state === 'aged_needs_research');
  const setTxt = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  setTxt('lcNeedVal', fmtN(rows.length)); setTxt('lcNeedSub', 'unverified_assumed_off');
  setTxt('lcMatchVal', fmtN(matchReady.length)); setTxt('lcMatchSub', 'deed match — confirm sold');
  setTxt('lcAgedVal', fmtN(aged.length)); setTxt('lcAgedSub', 'no deed match, aged');

  // Show the highest-priority subset (match-ready first, then aged), cap 25.
  const show = matchReady.concat(aged).concat(rows.filter(r => r.confirmation_state === 'awaiting_sweep')).slice(0, 25);
  const wrap = document.getElementById('lcConfirmList');
  if (!wrap) return;
  if (!show.length) { wrap.innerHTML = '<div style="font-size:12px;color:var(--text3);padding:8px">Nothing awaiting confirmation 🎉</div>'; return; }
  let t = '<table style="width:100%;border-collapse:collapse;font-size:12px"><thead><tr style="text-align:left;color:var(--text3)">'
    + '<th style="padding:4px 8px">Property</th><th style="padding:4px 8px">Off-Mkt</th>'
    + '<th style="padding:4px 8px">Sale Match</th><th style="padding:4px 8px">Actions</th></tr></thead><tbody>';
  show.forEach(r => {
    const addr = esc([r.address, r.city, r.state].filter(Boolean).join(', ') || ('#' + r.property_id));
    const url = r.listing_url ? '<a href="' + esc(r.listing_url) + '" target="_blank" rel="noopener">' + esc((r.tenant_operator || 'listing')) + '</a>' : esc(r.tenant_operator || '');
    const match = r.candidate_sale_id
      ? '$' + fmtN(Math.round((Number(r.candidate_sold_price) || 0) / 1e6 * 10) / 10) + 'M · ' + esc(r.candidate_sale_date || '')
      : '<span style="color:var(--text3)">none</span>';
    const lid = JSON.stringify(r.listing_id);
    const sid = r.candidate_sale_id ? JSON.stringify(r.candidate_sale_id) : 'null';
    const sd = r.candidate_sale_date ? JSON.stringify(r.candidate_sale_date) : 'null';
    let actions = '';
    if (r.candidate_sale_id) {
      actions += '<button onclick=\'diaResolveListing(' + lid + ',"confirm_sold",' + sid + ',' + sd + ')\' style="font-size:11px;padding:3px 8px;margin-right:4px;border:1px solid var(--green,#34d399);background:rgba(52,211,153,.12);color:var(--green,#34d399);border-radius:4px;cursor:pointer">Confirm Sold</button>';
    } else {
      actions += '<button onclick=\'diaResolveListing(' + lid + ',"confirm_sold",null,null)\' style="font-size:11px;padding:3px 8px;margin-right:4px;border:1px solid var(--border);background:var(--s2);color:var(--text);border-radius:4px;cursor:pointer">Confirm Sold</button>';
    }
    actions += '<button onclick=\'diaResolveListing(' + lid + ',"mark_withdrawn",null,null)\' style="font-size:11px;padding:3px 8px;margin-right:4px;border:1px solid var(--border);background:var(--s2);color:var(--text);border-radius:4px;cursor:pointer">Withdrawn</button>';
    actions += '<button onclick=\'diaResolveListing(' + lid + ',"still_active",null,null)\' style="font-size:11px;padding:3px 8px;border:1px solid var(--border);background:var(--s2);color:var(--text);border-radius:4px;cursor:pointer">Still Active</button>';
    t += '<tr style="border-top:1px solid var(--border)" id="lcRow-' + esc(String(r.listing_id)) + '">'
      + '<td style="padding:4px 8px">' + addr + (r.tenant_operator ? '<br><span style="color:var(--text3);font-size:11px">' + url + '</span>' : '') + '</td>'
      + '<td style="padding:4px 8px;color:var(--text3)">' + esc(r.off_market_date || '') + '<br><span style="font-size:11px">' + esc(r.confirmation_state) + '</span></td>'
      + '<td style="padding:4px 8px">' + match + '</td>'
      + '<td style="padding:4px 8px">' + actions + '</td></tr>';
  });
  t += '</tbody></table>';
  wrap.innerHTML = t;
}

// Resolve a confirmation row via the main-app endpoint (not sidebar).
async function diaResolveListing(listingId, action, saleId, saleDate) {
  const labels = { confirm_sold: 'Confirm as SOLD', mark_withdrawn: 'Mark WITHDRAWN', still_active: 'Mark STILL ACTIVE' };
  if (!confirm(labels[action] + ' for this listing?')) return;
  const rowEl = document.getElementById('lcRow-' + listingId);
  if (rowEl) rowEl.style.opacity = '0.5';
  try {
    const resp = await fetch('/api/resolve-listing-confirmation', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain: 'dia', listing_id: listingId, action, sale_id: saleId, sale_date: saleDate }),
    });
    if (!resp.ok) { const e = await resp.text(); throw new Error('HTTP ' + resp.status + ' ' + e); }
    // Drop the resolved row from the cached set and re-render.
    window._lcConfirmRows = (window._lcConfirmRows || []).filter(r => String(r.listing_id) !== String(listingId));
    renderDiaListingConfirm();
  } catch (err) {
    console.error('resolve listing failed:', err);
    if (rowEl) rowEl.style.opacity = '1';
    alert('Could not resolve listing: ' + err.message);
  }
}

// Render the LLC Research Queue panel from window._llcQueueItems.
function renderDiaLlcQueue() {
  const items = window._llcQueueItems || [];
  const setTxt = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  // Canonical counts from v_llc_research_queue_health; '—' until it loads.
  const pending = window._diaLlcHealthLoaded ? window._diaLlcPending : null;
  const done = window._diaLlcHealthLoaded ? window._diaLlcDone : null;
  setTxt('llcTotalVal', pending == null ? '—' : fmtN(pending)); setTxt('llcTotalSub', 'awaiting research');
  setTxt('llcShownVal', done == null ? '—' : fmtN(done)); setTxt('llcShownSub', 'resolved to date');
  const wrap = document.getElementById('llcQueueList');
  if (!wrap) return;
  if (!items.length) { wrap.innerHTML = '<div style="font-size:12px;color:var(--text3);padding:8px">' + (window._diaLlcHealthLoaded && !pending ? 'No owners awaiting research 🎉' : 'No owner list to show') + '</div>'; return; }
  let t = '<table style="width:100%;border-collapse:collapse;font-size:12px"><thead><tr style="text-align:left;color:var(--text3)">'
    + '<th style="padding:4px 8px">Owner</th><th style="padding:4px 8px">Property</th>'
    + '<th style="padding:4px 8px">State</th><th style="padding:4px 8px">Actions</th></tr></thead><tbody>';
  items.forEach(it => {
    const nm = esc(it.search_name || '');
    const st = esc(it.guessed_state || it.property_state || '');
    const prop = esc([it.property_address, it.property_city, it.property_state].filter(Boolean).join(', ') || ('#' + (it.property_id || '')));
    // SOS search helper (Google "<state> secretary of state business search <name>").
    const sosUrl = 'https://www.google.com/search?q=' + encodeURIComponent((st ? st + ' ' : '') + 'secretary of state business search ' + (it.search_name || ''));
    const qid = JSON.stringify(it.queue_id);
    let actions = '<a href="' + sosUrl + '" target="_blank" rel="noopener" style="font-size:11px;padding:3px 8px;margin-right:4px;border:1px solid var(--border);background:var(--s2);color:var(--text);border-radius:4px;text-decoration:none">SOS Lookup</a>';
    actions += '<button onclick=\'diaResolveLlc(' + qid + ',"completed")\' style="font-size:11px;padding:3px 8px;margin-right:4px;border:1px solid var(--green,#34d399);background:rgba(52,211,153,.12);color:var(--green,#34d399);border-radius:4px;cursor:pointer">Completed</button>';
    actions += '<button onclick=\'diaResolveLlc(' + qid + ',"no_match")\' style="font-size:11px;padding:3px 8px;border:1px solid var(--border);background:var(--s2);color:var(--text);border-radius:4px;cursor:pointer">No Match</button>';
    t += '<tr style="border-top:1px solid var(--border)" id="llcRow-' + esc(String(it.queue_id)) + '">'
      + '<td style="padding:4px 8px">' + nm + (it.tenant ? '<br><span style="color:var(--text3);font-size:11px">' + esc(it.tenant) + '</span>' : '') + '</td>'
      + '<td style="padding:4px 8px;color:var(--text3)">' + prop + '</td>'
      + '<td style="padding:4px 8px">' + st + '</td>'
      + '<td style="padding:4px 8px">' + actions + '</td></tr>';
  });
  t += '</tbody></table>';
  wrap.innerHTML = t;
}

// Resolve an LLC research queue row (mark completed / no_match).
async function diaResolveLlc(queueId, status) {
  const label = status === 'completed' ? 'Mark this owner research COMPLETED' : 'Mark NO MATCH';
  let foundFilingId = null;
  if (status === 'completed') {
    foundFilingId = prompt(label + '.\nOptional: enter the SOS filing/entity number (or leave blank):', '');
    if (foundFilingId === null) return; // cancelled
  } else if (!confirm(label + ' for this owner?')) { return; }
  const rowEl = document.getElementById('llcRow-' + queueId);
  if (rowEl) rowEl.style.opacity = '0.5';
  try {
    const body = { queue_id: queueId, status };
    if (foundFilingId) body.found_filing_id = foundFilingId;
    const resp = await fetch('/api/resolve-llc-research', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    });
    if (!resp.ok) { const e = await resp.text(); throw new Error('HTTP ' + resp.status + ' ' + e); }
    window._llcQueueItems = (window._llcQueueItems || []).filter(it => String(it.queue_id) !== String(queueId));
    window._llcQueueTotal = Math.max(0, (window._llcQueueTotal || 1) - 1);
    renderDiaLlcQueue();
  } catch (err) {
    console.error('resolve llc failed:', err);
    if (rowEl) rowEl.style.opacity = '1';
    alert('Could not resolve: ' + err.message);
  }
}

// ── Data-Health tile inner-renderers (synchronous, cache-fed) ────────────────
// Each reads a value loaded once in the main loadDiaData Promise.all, so a
// re-render (e.g. _loadDiaHeavyDetail) always paints the real number instead of
// stranding the tile on a "loading…" placeholder that a once-flag then refuses
// to refill (the bug this round fixes).

function _diaOwnershipCoverageCards() {
  const cov = (typeof diaData !== 'undefined') ? diaData.ownershipCoverage : null;
  const unpros = (typeof diaData !== 'undefined') ? diaData.unprospectedCount : null;
  const loaded = (typeof diaData !== 'undefined') && ('ownershipCoverage' in diaData);
  const pct = (v) => (v == null ? '—' : Math.round(Number(v)) + '%');
  let h = '<div class="dia-grid dia-grid-3">';
  if (!loaded) {
    h += infoCard({ title: 'Ownership Depth', value: '…', sub: 'loading', color: 'blue' });
    h += infoCard({ title: 'SF Prospecting', value: '…', sub: 'loading', color: 'green' });
    h += infoCard({ title: 'Unprospected Owners', value: '…', sub: 'loading', color: 'red' });
    return h + '</div>';
  }
  if (!cov) {
    return '<div class="dia-info-card" style="padding:16px;color:var(--text3);font-size:12px">Ownership coverage unavailable</div>';
  }
  h += infoCard({ title: 'Ownership Depth', value: pct(cov.pct_property_has_true_owner),
    sub: 'of ' + fmtN(cov.properties) + ' properties resolved to a true owner · ' + pct(cov.pct_property_has_recorded_owner) + ' recorded · ' + pct(cov.pct_property_has_county_deed) + ' county deed',
    color: 'blue', tab: 'sales' });
  h += infoCard({ title: 'SF Prospecting', value: pct(cov.pct_true_owner_has_salesforce), sub: 'of owners linked to Salesforce', color: 'green', tab: 'sales' });
  h += infoCard({ title: 'Unprospected Owners', value: (unpros != null ? fmtN(unpros) : '—'),
    sub: (unpros != null ? 'owners with property, no SF link — click to view BD targets' : 'unavailable'),
    color: 'red', onclick: (unpros != null ? '_diaShowProspectTargets()' : null) });
  return h + '</div>';
}

function _diaListingConfirmTiles() {
  const rows = window._lcConfirmRows;
  const loaded = Array.isArray(rows);
  const matchReady = loaded ? rows.filter(r => r.confirmation_state === 'sale_match_promote') : [];
  const aged = loaded ? rows.filter(r => r.confirmation_state === 'aged_needs_research') : [];
  const v = (n) => loaded ? fmtN(n) : '…';
  let h = '<div class="dia-grid dia-grid-3">';
  h += infoCard({ title: 'Need Confirmation', value: v(loaded ? rows.length : 0), sub: 'unverified_assumed_off', color: 'orange', id: 'lcNeedVal', subId: 'lcNeedSub' });
  h += infoCard({ title: 'Sale Match Ready', value: v(matchReady.length), sub: 'deed match — confirm sold', color: 'green', id: 'lcMatchVal', subId: 'lcMatchSub' });
  h += infoCard({ title: 'Aged > 90d', value: v(aged.length), sub: 'no deed match, aged', color: 'red', id: 'lcAgedVal', subId: 'lcAgedSub' });
  return h + '</div>';
}

function _diaLlcTiles() {
  const loaded = window._diaLlcHealthLoaded;
  const pending = loaded ? window._diaLlcPending : null;
  const done = loaded ? window._diaLlcDone : null;
  let h = '<div class="dia-grid dia-grid-3">';
  h += infoCard({ title: 'Queued Owners', value: (pending == null ? '…' : fmtN(pending)), sub: 'awaiting research', color: 'purple', id: 'llcTotalVal', subId: 'llcTotalSub' });
  h += infoCard({ title: 'Resolved', value: (done == null ? '…' : fmtN(done)), sub: 'resolved to date', color: 'blue', id: 'llcShownVal', subId: 'llcShownSub' });
  h += infoCard({ title: 'Resolve', value: 'manual', sub: 'SOS lookup + mark done', color: 'cyan', tab: 'research' });
  return h + '</div>';
}

function renderOnMarketInner() {
  // The CANONICAL On-Market set is v_dia_on_market (the T9d entry/exit/cap model,
  // ~184) — read its ROWS directly (diaData.onMarketRows, loaded in the main
  // Promise.all) so the count no longer depends on the flaky v_available_listings
  // client load (which, when it failed/emptied, made the filter yield "0
  // currently on market"). Fall back to the legacy diaAvailListings intersection
  // only if the canonical rows aren't loaded.
  const haveCanonical = (typeof diaData !== 'undefined') && Array.isArray(diaData.onMarketRows);
  if (!haveCanonical && !diaAvailListings) {
    return '<div class="dia-grid dia-grid-4"><div class="dia-info-card" style="grid-column:span 4;text-align:center;padding:24px"><span class="spinner"></span><div style="margin-top:8px;font-size:12px;color:var(--text2)">Loading listings...</div></div></div>';
  }
  // Round 76cx Phase 2: kick off lazy load of the verification digest the
  // first time the on-market dashboard renders. Fire-and-forget; the card
  // shows "Loading verification digest…" until the data arrives, then a
  // re-render fills in the counts.
  if (!diaVerificationSummary && !diaVerificationSummaryLoading) {
    loadDiaVerificationSummary();
  }
  // Round 76et-F: same lazy-load pattern for the recent verifications
  // drill-down panel rendered below the metrics row.
  if (diaRecentVerifications === null && !diaRecentVerificationsLoading) {
    loadRecentDiaVerifications();
  }

  let recentListings, staleCount;
  if (haveCanonical) {
    // v_dia_on_market rows ARE the current on-market set — no client filter.
    recentListings = diaData.onMarketRows;
    staleCount = 0;
  } else if (diaOnMarketIds) {
    recentListings = diaAvailListings.filter(r => diaOnMarketIds.has(r.listing_id));
    staleCount = diaAvailListings.length - recentListings.length;
  } else {
    const cutoff = new Date('2023-01-01');
    recentListings = diaAvailListings.filter(r => {
      if (!r.listing_date) return true; // keep listings without a date (benefit of the doubt)
      return new Date(r.listing_date) >= cutoff;
    });
    staleCount = diaAvailListings.length - recentListings.length;
  }

  // Check multiple possible field names for price, cap rate, and days on market.
  // v_dia_on_market exposes asking_price / current_cap_rate / on_market_date /
  // listing_broker; v_available_listings uses the ask_*/dom aliases — support both.
  const getPrice = r => parseFloat(r.ask_price || r.asking_price || r.listing_price || r.price || 0);
  // Cap rates are standardized as decimals in DB (0.065 = 6.5%) — convert to display pct
  const getCapNorm = r => {
    const raw = parseFloat(r.ask_cap || r.asking_cap_rate || r.cap_rate || r.current_cap_rate || r.last_cap_rate || 0);
    if (!raw || raw <= 0) return 0;
    // DB normalized to decimal (2026-04-17). Convert to display percentage.
    return raw < 1 ? raw * 100 : raw;  // safety: if somehow still whole pct, pass through
  };
  const getDom = r => {
    const d = parseInt(r.dom || r.days_on_market || 0, 10);
    if (d > 0) return d;
    // Derive from on_market_date when the row carries no DOM column (canonical set).
    if (r.on_market_date) {
      const t = Date.parse(r.on_market_date);
      if (!isNaN(t)) return Math.max(0, Math.round((Date.now() - t) / 86400000));
    }
    return 0;
  };
  const withPrice = recentListings.filter(r => getPrice(r) > 0);
  // Filter to reasonable cap rates: 3%-15% for dialysis properties
  const validCaps = recentListings.map(r => getCapNorm(r)).filter(v => v >= 3 && v <= 15).sort((a,b) => a-b);
  const avgAskCap = validCaps.length > 0 ? (validCaps.reduce((s,v)=>s+v,0)/validCaps.length).toFixed(2) + '%' : '—';
  const q1Idx = Math.floor(validCaps.length * 0.25);
  const q3Idx = Math.floor(validCaps.length * 0.75);
  const lowerQ = validCaps.length > 4 ? validCaps[q1Idx].toFixed(2)+'%' : '—';
  const upperQ = validCaps.length > 4 ? validCaps[q3Idx].toFixed(2)+'%' : '—';
  const avgDom = recentListings.filter(r => getDom(r) > 0);
  const avgDomVal = avgDom.length > 0 ? Math.round(avgDom.reduce((s,r)=>s+getDom(r),0)/avgDom.length) : '—';
  const isNMListing = r => {
    var b = ((r.listing_broker||'')+(r.broker_name||'')+(r.broker_companies||'')).toLowerCase();
    if (b.includes('northmarq') || b.includes('north marq') || b.includes('nm capital')) return true;
    return NM_TEAM.some(name => { var parts = name.split(' '); return parts.some(p => p.length > 3 && b.includes(p)); });
  };
  const nmListings = recentListings.filter(isNMListing);

  let h = '<div class="dia-grid dia-grid-5">';
  const staleSub = diaOnMarketIds
    ? 'currently on market'
    : (staleCount > 0 ? recentListings.length + ' recent · ' + staleCount + ' stale excluded' : 'clinics on market');
  h += infoCard({ title: 'Active Listings', value: fmtN(recentListings.length), sub: staleSub, color: 'blue', tab: 'sales' });
  h += infoCard({ title: 'Avg Ask Cap', value: avgAskCap, sub: fmtN(validCaps.length) + ' with cap data', color: 'cyan', tab: 'sales' });
  h += infoCard({ title: 'Lower Quartile', value: lowerQ, sub: '25th pctl ask cap', color: 'purple', tab: 'sales' });
  h += infoCard({ title: 'Upper Quartile', value: upperQ, sub: '75th pctl ask cap', color: 'yellow', tab: 'sales' });
  h += infoCard({ title: 'NM On Market', value: fmtN(nmListings.length), sub: 'Northmarq listings', color: 'green', tab: 'sales' });
  h += '</div>';

  // Additional row
  h += '<div class="dia-grid dia-grid-4" style="margin-top:10px">';
  const avgAskPrice = withPrice.length > 0 ? '$' + fmtN(Math.round(withPrice.reduce((s,r)=>s+getPrice(r),0)/withPrice.length)) : '—';
  h += infoCard({ title: 'Avg Ask Price', value: avgAskPrice, sub: fmtN(withPrice.length) + ' priced', color: 'blue', tab: 'sales' });
  h += infoCard({ title: 'Avg Days on Market', value: avgDomVal, sub: fmtN(avgDom.length) + ' with dates', color: 'yellow', tab: 'sales' });
  h += infoCard({ title: 'NM Market Share', value: recentListings.length > 0 ? (nmListings.length/recentListings.length*100).toFixed(1)+'%' : '—', sub: 'of active listings', color: 'green', tab: 'sales' });
  // Round 76cx Phase 2: verification status card
  h += renderListingVerificationCard();
  h += '</div>';
  // Round 76et-F: drill-down panel below the metrics row.
  h += renderRecentDiaVerificationsPanel();
  return h;
}

// Format the CMS patient-data "as of" period (e.g. "Mar 2025") from
// diaData.patientAsOf. Parsed manually to avoid Date() timezone drift on a
// bare YYYY-MM-DD. Returns '' when unknown.
function _diaPatientAsOfLabel() {
  var s = (typeof diaData !== 'undefined' && diaData) ? diaData.patientAsOf : null;
  if (!s || typeof s !== 'string') return '';
  var m = s.match(/^(\d{4})-(\d{2})/);
  if (!m) return '';
  var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  var mi = parseInt(m[2], 10) - 1;
  return (months[mi] || '') + ' ' + m[1];
}

function renderPatientMetricsInner() {
  const ptSrc = diaPatientCounts && diaPatientCounts.length > 0 ? diaPatientCounts : null;
  if (!ptSrc) {
    // Fallback to inventory diff while loading
    const inv = (typeof diaData !== 'undefined' && diaData.inventoryChanges) ? diaData.inventoryChanges.filter(c => c.latest_total_patients > 0) : [];
    const total = inv.reduce((s,c) => s + (c.latest_total_patients || 0), 0);
    const avg = inv.length > 0 ? Math.round(total / inv.length) : 0;
    const loading = !diaPatientCounts; // null means still loading
    return '<div class="dia-grid dia-grid-4">' +
      infoCard({ title: 'Avg Patients / Clinic', value: loading ? '...' : fmtN(avg), sub: loading ? 'loading full patient data...' : fmtN(total) + ' total across ' + fmtN(inv.length) + ' clinics', color: 'blue', tab: 'changes' }) +
      '</div>';
  }
  const total = ptSrc.reduce((s,c) => s + (c.total_patients || 0), 0);
  const avg = ptSrc.length > 0 ? Math.round(total / ptSrc.length) : 0;
  // Estimate concurrent census — CMS total_patients is annual treated (includes turnover).
  // Published ESRD prevalence ~577K. Scale by ratio of our clinic count to CMS universe (~7,800).
  const estConcurrent = Math.round(577000 * (ptSrc.length / 7800));
  const estConcurrentAvg = ptSrc.length > 0 ? Math.round(estConcurrent / ptSrc.length) : 0;
  // State breakdown for top 5
  const byState = {};
  ptSrc.forEach(c => { const st = c.state || '??'; byState[st] = (byState[st] || 0) + (c.total_patients || 0); });
  const topStates = Object.entries(byState).sort((a,b) => b[1] - a[1]).slice(0, 5);
  const statesSub = topStates.map(([st, cnt]) => st + ': ' + fmtN(cnt)).join(' · ');
  return '<div class="dia-grid dia-grid-4">' +
    infoCard({ title: 'Avg Patients / Clinic', value: fmtN(avg), sub: fmtN(total) + ' annual treated · ~' + fmtN(estConcurrentAvg) + ' concurrent est.', color: 'blue', tab: 'changes' }) +
    infoCard({ title: 'Clinics Reporting', value: fmtN(ptSrc.length), sub: (function(){ var a=_diaPatientAsOfLabel(); return 'CMS patient counts' + (a ? ' · as of ' + a : ''); })(), color: 'green', tab: 'changes' }) +
    infoCard({ title: 'Annual Treated', value: fmtN(total), sub: '~' + fmtN(estConcurrent) + ' est. concurrent (ESRD prev.)', color: 'purple', tab: 'changes' }) +
    renderTopStatesRankedCard(topStates) +
    '</div>';
}

function renderTopStatesRankedCard(topStates) {
  // Round 76cv: ranked-list card matching Top 5 Movers visual treatment.
  // Avoids the giant-letter hero + comma-separated tail look that felt
  // visually inconsistent with the rest of the Clinical Metrics row.
  if (!topStates || topStates.length === 0) {
    return '<div class="dia-info-card" onclick="goToDiaTab(\'changes\')" style="cursor:pointer;padding:14px 16px;color:var(--text3);font-size:11px">No state data</div>';
  }
  const maxCount = topStates[0][1] || 1;
  let h = '<div class="dia-info-card" onclick="goToDiaTab(\'changes\')" style="cursor:pointer;padding:14px 16px">';
  h += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:10px">Top States</div>';
  topStates.forEach(([st, cnt], i) => {
    const barW = Math.round((cnt / maxCount) * 100);
    // QA-29 (2026-05-18): state-name cell was getting 0 width because the
    // sum of fixed widths (rank 20 + bar 80 + count 50 + 3x8 gap = 174px)
    // exceeded the card's grid column. The cell had `flex:1` but no
    // min-width, so it shrank to invisibility. Fix: give state name an
    // explicit min-width of 32px (enough for "CA"/"TX") and shrink the
    // bar from 80px to 50px so all four cells fit in narrow cards.
    h += `<div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
      <div style="width:14px;flex-shrink:0;font-size:10px;color:var(--text3);text-align:right">${i+1}</div>
      <div style="min-width:32px;flex:1;font-size:11px;font-weight:600;color:var(--text1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${st}</div>
      <div style="width:50px;flex-shrink:0;height:8px;background:var(--s3);border-radius:4px;overflow:hidden"><div style="width:${barW}%;height:100%;background:#22d3ee;border-radius:4px"></div></div>
      <div style="width:54px;flex-shrink:0;font-size:10px;color:#22d3ee;text-align:right;font-weight:600">${fmtN(cnt)}</div>
    </div>`;
  });
  h += '</div>';
  return h;
}

function renderFinancialMetricsInner() {
  if (!diaFinancialEstimates) {
    return '<div class="dia-grid dia-grid-5"><div class="dia-info-card" style="grid-column:span 5;text-align:center;padding:24px"><span class="spinner"></span><div style="margin-top:8px;font-size:12px;color:var(--text2)">Loading financial estimates...</div></div></div>';
  }
  // R4-B: consume the single-row server-side summary (v_clinic_financial_overview).
  const s = diaFinancialEstimates;
  if (s._error) {
    return '<div class="dia-info-card" style="text-align:center;padding:18px;color:var(--red,#ef4444)">Financial estimates unavailable — ' + esc(String(s._error)) + '</div>';
  }
  if (s._empty || !s.clinics_estimated) {
    return '<div class="dia-info-card" style="text-align:center;padding:18px;color:var(--text2)">No financial estimates available</div>';
  }

  const clinicsEstimated = Number(s.clinics_estimated) || 0;
  const withRev = Number(s.with_revenue) || 0;
  const withProfit = Number(s.with_profit) || 0;
  const withEbitda = Number(s.with_ebitda) || 0;
  const totalRev = Number(s.total_revenue) || 0;
  const avgRev = Number(s.avg_revenue) || 0;
  const avgProfit = Number(s.avg_profit) || 0;
  const avgEbitda = Number(s.avg_ebitda) || 0;
  const avgMargin = avgRev > 0 ? (avgProfit / avgRev * 100).toFixed(1) : '—';

  // Prefer the universe from the freshness feed; fall back to the view's count.
  const totalClinicUniverse = (typeof diaData !== 'undefined' && diaData.freshness?.total_clinics > 0)
    ? diaData.freshness.total_clinics : (Number(s.total_clinic_universe) || 0);
  const coveragePct = clinicsEstimated > 0 && totalClinicUniverse > 0
    ? (clinicsEstimated / totalClinicUniverse * 100).toFixed(1) : '—';
  const coverageSub = totalClinicUniverse > 0
    ? fmtN(clinicsEstimated) + ' of ' + fmtN(totalClinicUniverse) + ' clinics (' + coveragePct + '%)'
    : fmtN(clinicsEstimated) + ' clinics estimated';

  let h = '<div class="dia-grid dia-grid-5">';
  h += infoCard({ title: 'Clinics Estimated', value: fmtN(clinicsEstimated), sub: coverageSub, color: 'blue', tab: 'search' });
  h += infoCard({ title: 'Avg Revenue / Clinic', value: '$' + fmtN(Math.round(avgRev / 1000)) + 'K', sub: fmtN(withRev) + ' with revenue data', color: 'green', tab: 'search' });
  h += infoCard({ title: 'Avg Profit / Clinic', value: '$' + fmtN(Math.round(avgProfit / 1000)) + 'K', sub: avgMargin + '% avg margin', color: 'cyan', tab: 'search' });
  h += infoCard({ title: 'Avg EBITDA', value: '$' + fmtN(Math.round(avgEbitda / 1000)) + 'K', sub: fmtN(withEbitda) + ' with EBITDA', color: 'purple', tab: 'search' });
  h += infoCard({ title: 'Industry Revenue', value: '$' + fmtN(Math.round(totalRev / 1e9)) + 'B', sub: 'est. across ' + fmtN(withRev) + ' clinics', color: 'yellow', tab: 'search' });
  h += '</div>';

  // Source breakdown row (from the view's jsonb source_breakdown)
  const sources = (s.source_breakdown && typeof s.source_breakdown === 'object') ? s.source_breakdown : {};
  if (Object.keys(sources).length) {
    h += '<div class="dia-grid dia-grid-4" style="margin-top:10px">';
    const srcLabels = { ttm_reported: 'TTM Reported', cms_patient_count: 'CMS Patient Count', google_hours: 'Google Hours', cms_chair_count: 'CMS Chair Count', '10k_filing': '10-K Filing' };
    const srcColors = { ttm_reported: 'green', cms_patient_count: 'blue', google_hours: 'cyan', cms_chair_count: 'yellow', '10k_filing': 'orange' };
    Object.entries(sources).forEach(([src, cnt]) => {
      h += infoCard({ title: srcLabels[src] || src, value: fmtN(Number(cnt) || 0), sub: 'estimates', color: srcColors[src] || 'blue' });
    });
    h += '</div>';
  }
  return h;
}

/**
 * Render movers charts (legacy — kept for backward compat but overview uses inline bars now)
 */
function renderDiaMoversChart() {
  const upLabels = (diaData.moversUp || []).map(r => norm(r.facility_name || '').substring(0, 20));
  const upValues = (diaData.moversUp || []).map(r => r.delta_patients);
  const downLabels = (diaData.moversDown || []).map(r => norm(r.facility_name || '').substring(0, 20));
  const downValues = (diaData.moversDown || []).map(r => Math.abs(r.delta_patients));
  if (upLabels.length > 0 && typeof renderBarChart === 'function') {
    renderBarChart('diaMoversUpChart', upLabels, [{ label: 'Patients Added', data: upValues }], false);
  }
  if (downLabels.length > 0 && typeof renderBarChart === 'function') {
    renderBarChart('diaMoversDownChart', downLabels, [{ label: 'Patients Lost', data: downValues }], false);
  }
}

// ============================================================================
// CHANGES TAB
// ============================================================================

/**
 * Render CMS Data tab (formerly Inventory) — comprehensive clinic table with financials,
 * dynamic averages, sort, and filter
 */
function renderDiaChanges() {
  // Lazy-load CMS data from the comprehensive view
  if (diaCmsData === null && !diaCmsLoading) {
    diaCmsLoading = true;
    (async () => {
      try {
        // Fetch CMS base data
        let all = [], offset = 0;
        while (true) {
          const batch = await diaQuery('v_cms_data', '*', {
            order: 'latest_total_patients.desc.nullslast',
            limit: 1000, offset
          });
          all = all.concat(batch || []);
          if (!batch || batch.length < 1000) break;
          offset += 1000;
        }
        // Fetch rankings data (payor mix, quality, margin) and merge by medicare_id → clinic_id
        try {
          let rankings = [], rOff = 0;
          while (true) {
            const rb = await diaQuery('v_property_rankings', 'medicare_id,payer_mix_medicare_pct,payer_mix_medicaid_pct,payer_mix_private_pct,star_rating,deficiency_count,ttm_operating_margin,ttm_revenue,ttm_operating_costs,ttm_operating_profit,ttm_total_treatments,ttm_medicare_treatments,ttm_commercial_treatments,revenue_calc_method,profit_nonprofit', {
              limit: 1000, offset: rOff
            });
            rankings = rankings.concat(rb || []);
            if (!rb || rb.length < 1000) break;
            rOff += 1000;
          }
          const rankMap = {};
          rankings.forEach(r => { if (r.medicare_id) rankMap[r.medicare_id] = r; });
          all.forEach(row => {
            const rk = rankMap[row.clinic_id];
            if (rk) {
              row.payer_mix_medicare_pct = rk.payer_mix_medicare_pct;
              row.payer_mix_medicaid_pct = rk.payer_mix_medicaid_pct;
              row.payer_mix_private_pct = rk.payer_mix_private_pct;
              row.star_rating = rk.star_rating;
              row.deficiency_count = rk.deficiency_count;
              row.ttm_operating_margin = rk.ttm_operating_margin != null ? Number(rk.ttm_operating_margin) * 100 : null;
              row.ttm_revenue = rk.ttm_revenue;
              row.ttm_operating_costs = rk.ttm_operating_costs;
              row.ttm_operating_profit = rk.ttm_operating_profit;
              row.ttm_total_treatments = rk.ttm_total_treatments;
              row.ttm_medicare_treatments = rk.ttm_medicare_treatments;
              row.ttm_commercial_treatments = rk.ttm_commercial_treatments;
              row.revenue_calc_method = rk.revenue_calc_method;
              row.profit_nonprofit = rk.profit_nonprofit;
            }
          });
          console.log('[CMS] Merged rankings for', Object.keys(rankMap).length, 'clinics');
        } catch (re) {
          console.warn('Rankings merge skipped:', re.message);
        }
        diaCmsData = all;
      } catch (e) {
        console.error('CMS data load error:', e);
        showToast('CMS data load failed', 'error');
        diaCmsData = [];
      }
      diaCmsLoading = false;
      renderDiaTab();
    })();
    return '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading CMS data...</p></div>';
  }
  if (diaCmsLoading) {
    return '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading CMS data...</p></div>';
  }

  const data = diaCmsData || [];

  // === Apply filters ===
  let filtered = data;
  if (diaCmsModalityFilter) filtered = filtered.filter(r => r.modality_type === diaCmsModalityFilter);
  if (diaCmsStateFilter) filtered = filtered.filter(r => r.state === diaCmsStateFilter);
  if (diaCmsOperatorFilter) filtered = filtered.filter(r => (r.operator_name || r.chain_organization || '') === diaCmsOperatorFilter);
  if (diaCmsSearch) {
    const sq = diaCmsSearch.toLowerCase();
    filtered = filtered.filter(r =>
      (r.facility_name || '').toLowerCase().includes(sq) ||
      (r.operator_name || '').toLowerCase().includes(sq) ||
      (r.city || '').toLowerCase().includes(sq) ||
      (r.address || '').toLowerCase().includes(sq) ||
      (r.chain_organization || '').toLowerCase().includes(sq) ||
      (r.recorded_owner_name || '').toLowerCase().includes(sq) ||
      (r.clinic_id || '').includes(sq)
    );
  }

  // === Apply sort ===
  if (diaCmsSort.col) {
    const dir = diaCmsSort.dir === 'asc' ? 1 : -1;
    const col = diaCmsSort.col;
    // Virtual columns for computed payor mix values
    const _virtualGetter = col === '_medicare_pct' ? r => { const v = r.payer_mix_medicare_pct != null ? Number(r.payer_mix_medicare_pct) : r.payer_mix_medicare != null ? (Number(r.payer_mix_medicare) <= 1 ? Number(r.payer_mix_medicare) * 100 : Number(r.payer_mix_medicare)) : null; return v; }
      : col === '_medicaid_pct' ? r => { const v = r.payer_mix_medicaid_pct != null ? Number(r.payer_mix_medicaid_pct) : r.payer_mix_medicaid != null ? (Number(r.payer_mix_medicaid) <= 1 ? Number(r.payer_mix_medicaid) * 100 : Number(r.payer_mix_medicaid)) : null; return v; }
      : col === '_private_pct' ? r => { const v = r.payer_mix_private_pct != null ? Number(r.payer_mix_private_pct) : r.payer_mix_commercial != null ? (Number(r.payer_mix_commercial) <= 1 ? Number(r.payer_mix_commercial) * 100 : Number(r.payer_mix_commercial)) : null; return v; }
      : null;
    filtered = [...filtered].sort((a, b) => {
      let va = _virtualGetter ? _virtualGetter(a) : a[col];
      let vb = _virtualGetter ? _virtualGetter(b) : b[col];
      if (va == null && vb == null) return 0;
      if (va == null) return 1;
      if (vb == null) return -1;
      if (typeof va === 'string') return va.localeCompare(vb) * dir;
      return (va - vb) * dir;
    });
  }

  // === Compute dynamic averages for filtered set ===
  const n = filtered.length;
  const sum = (arr, fn) => arr.reduce((s, r) => { const v = fn(r); return v != null && !isNaN(v) ? s + Number(v) : s; }, 0);
  const cnt = (arr, fn) => arr.reduce((s, r) => { const v = fn(r); return v != null && !isNaN(v) ? s + 1 : s; }, 0);
  const avg = (arr, fn) => { const c = cnt(arr, fn); return c > 0 ? sum(arr, fn) / c : null; };

  const avgICPts = avg(filtered, r => r.est_in_center_patients);
  const avgHomePts = avg(filtered, r => r.est_home_patients);
  const avgRevenue = avg(filtered, r => r.estimated_annual_revenue);
  const avgEbitda = avg(filtered, r => r.estimated_ebitda);
  const totalEstRevenue = sum(filtered, r => r.est_combined_revenue);
  const cntHome = filtered.filter(r => r.modality_type === 'home').length;
  const cntHybrid = filtered.filter(r => r.modality_type === 'hybrid').length;
  const cntIC = filtered.filter(r => r.modality_type === 'in_center').length;

  // Payor mix helper: normalize decimal (0-1) vs pct (0-100) formats
  const payerPct = (row, field, fieldPct) => {
    if (row[fieldPct] != null) return Number(row[fieldPct]);
    if (row[field] != null) { const v = Number(row[field]); return v <= 1 ? v * 100 : v; }
    return null;
  };
  const avgMedicarePct = avg(filtered, r => payerPct(r, 'payer_mix_medicare', 'payer_mix_medicare_pct'));
  const avgMedicaidPct = avg(filtered, r => payerPct(r, 'payer_mix_medicaid', 'payer_mix_medicaid_pct'));
  const avgPrivatePct = avg(filtered, r => payerPct(r, 'payer_mix_commercial', 'payer_mix_private_pct'));
  const avgMargin = avg(filtered, r => r.ttm_operating_margin);
  const avgStarRating = avg(filtered, r => r.star_rating);

  let html = '<div class="biz-section">';

  // === Action guidance banner ===
  html += '<div style="padding:10px 14px;background:rgba(96,165,250,0.08);border-radius:8px;border-left:3px solid #60a5fa;margin-bottom:12px;display:flex;align-items:center;gap:10px;">';
  html += '<div style="font-size:13px;color:var(--text);line-height:1.4"><strong>CMS Clinic Data</strong> — Browse the latest CMS enrollment data with payor mix, financials, and quality ratings. <strong>Flag</strong> clinics worth researching further. Click any row for full property details. <button onclick="document.getElementById(\'cmsMethodPanel\').style.display=document.getElementById(\'cmsMethodPanel\').style.display===\'none\'?\'block\':\'none\'" style="background:none;border:none;color:var(--accent);cursor:pointer;font-size:12px;font-weight:600;text-decoration:underline;padding:0;margin-left:4px">Data Sources & Methodology ▾</button></div>';
  html += '</div>';

  // === Methodology & Assumptions Panel (collapsible) ===
  html += '<div id="cmsMethodPanel" style="display:none;margin-bottom:16px;border:1px solid var(--border);border-radius:10px;background:var(--s1);padding:16px 20px;font-size:12px;line-height:1.6;color:var(--text2)">';
  html += '<div style="font-size:14px;font-weight:700;color:var(--text);margin-bottom:10px">Data Sources & Methodology</div>';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">';

  // Left column — Reported Data
  html += '<div>';
  html += '<div style="font-weight:700;color:var(--text);margin-bottom:6px;font-size:12px;text-transform:uppercase;letter-spacing:0.5px">✅ CMS-Reported Data (Direct from Source)</div>';
  html += '<div style="margin-bottom:8px"><strong style="color:var(--text)">Patient Counts</strong> — Reported by CMS Medicare enrollment data. Updated monthly as CMS publishes new Dialysis Facility Compare datasets. IC Patients and Home Patients are enrollment-based counts, not census.</div>';
  html += '<div style="margin-bottom:8px"><strong style="color:var(--text)">Payor Mix (Medicare %, Medicaid %, Private/Comm %)</strong> — Derived from CMS claims data via the property rankings model. Reflects the share of patients by primary insurance type. Coverage: ~7% of clinics have payor mix data. Percentages may not sum to 100% due to dual-eligible patients (e.g., Medicare + Medicaid) being counted in both categories. Clinics showing "–" have no payor mix data available from CMS.</div>';
  html += '<div style="margin-bottom:8px"><strong style="color:var(--text)">Star Rating</strong> — CMS 5-Star Quality Rating from Dialysis Facility Compare. Composite measure of clinical outcomes (mortality, hospitalization, transfusion) and patient experience surveys. Updated by CMS quarterly.</div>';
  html += '<div style="margin-bottom:8px"><strong style="color:var(--text)">Modality Type</strong> — CMS-designated treatment modality: In-Center (IC), Home, or Hybrid (offering both). Based on CMS certification data.</div>';
  html += '<div><strong style="color:var(--text)">Facility Name, Location, Operator</strong> — CMS Provider Enrollment data cross-referenced with chain organization filings.</div>';
  html += '</div>';

  // Right column — Estimated Data
  html += '<div>';
  html += '<div style="font-weight:700;color:var(--text);margin-bottom:6px;font-size:12px;text-transform:uppercase;letter-spacing:0.5px">⚙️ Estimated / Calculated Figures</div>';
  html += '<div style="margin-bottom:8px"><strong style="color:var(--text)">Revenue (IC Rev, Home Rev, TTM Rev)</strong> — Estimated using a blended reimbursement model: Medicare patients × ~$290/treatment × 3 treatments/week × 52 weeks, plus commercial patients at 1.4× Medicare rate, plus Medicaid at 0.85× Medicare rate. Home patients use a separate home-therapy rate (~$260/treatment). These are annualized estimates, not audited financials.</div>';
  html += '<div style="margin-bottom:8px"><strong style="color:var(--text)">EBITDA</strong> — Estimated by applying an operating cost per-treatment assumption (~$245 for IC, ~$220 for home) to estimated treatment counts, then subtracting from estimated revenue. Industry-standard margin benchmarks (10–18%) are used as sanity checks. Not derived from operator financial statements.</div>';
  html += '<div style="margin-bottom:8px"><strong style="color:var(--text)">Operating Margin</strong> — Calculated as (TTM Revenue − Estimated Operating Costs) ÷ TTM Revenue × 100. Coverage: ~97% of clinics. Color-coded: <span style="color:#34d399;font-weight:600">green ≥ 12%</span>, <span style="color:#fbbf24;font-weight:600">yellow 0–12%</span>, <span style="color:#f87171;font-weight:600">red < 0%</span>. Based on estimated revenue and cost models, not reported margins.</div>';
  html += '<div><strong style="color:var(--text)">Treatment Counts</strong> — Estimated from patient counts × 3 treatments/week (standard in-center protocol). Actual treatment frequency varies by patient acuity and modality. Home patients average fewer weekly treatments (~2.5/week for PD, variable for home HD).</div>';
  html += '</div>';

  html += '</div>'; // grid

  // Key caveats
  html += '<div style="margin-top:12px;padding:10px 14px;background:rgba(251,191,36,0.08);border-radius:6px;border-left:3px solid #fbbf24;font-size:11px;color:var(--text2);line-height:1.5">';
  html += '<strong style="color:var(--text)">Important for Client Conversations:</strong> All revenue and EBITDA figures are modeling estimates based on CMS enrollment data and published reimbursement rates — they are not audited financials. Payor mix percentages and star ratings are CMS-reported. When discussing with buyers or prospects, clearly distinguish: "CMS reports X Medicare patients" vs. "We estimate Y in annual revenue based on published reimbursement rates." Actual facility financials may differ due to contract rates, case mix, ancillary services, and operational efficiency.';
  html += '</div>';

  html += '</div>'; // cmsMethodPanel

  // === Dynamic average cards — Row 1: Volume & Financial ===
  html += '<div style="display:grid;grid-template-columns:repeat(6,1fr);gap:8px;margin-bottom:8px">';
  html += _cmsAvgCard('Clinics', fmtN(n) + '<div style="font-size:9px;color:var(--text3);margin-top:2px">' + cntIC + ' IC · ' + cntHybrid + ' Hyb · ' + cntHome + ' Home</div>', '#60a5fa');
  html += _cmsAvgCard('Avg In-Center Pts', avgICPts != null ? Math.round(avgICPts).toLocaleString() : '–', '#34d399');
  html += _cmsAvgCard('Avg Home Pts', avgHomePts != null ? Math.round(avgHomePts).toLocaleString() : '–', '#a78bfa');
  html += _cmsAvgCard('Avg Revenue', avgRevenue != null ? '$' + (avgRevenue / 1000000).toFixed(1) + 'M' : '–', '#fb923c');
  html += _cmsAvgCard('Avg EBITDA', avgEbitda != null ? '$' + Math.round(avgEbitda / 1000).toLocaleString() + 'K' : '–', '#f87171');
  html += _cmsAvgCard('Est Total Rev', totalEstRevenue > 0 ? '$' + (totalEstRevenue / 1000000000).toFixed(2) + 'B' : '–', '#22d3ee');
  html += '</div>';
  // === Row 2: Payor Mix & Quality (averages across filtered set) ===
  html += '<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin-bottom:16px">';
  html += _cmsAvgCard('Avg Medicare %', avgMedicarePct != null ? avgMedicarePct.toFixed(1) + '%' : '–', '#3b82f6');
  html += _cmsAvgCard('Avg Medicaid %', avgMedicaidPct != null ? avgMedicaidPct.toFixed(1) + '%' : '–', '#8b5cf6');
  html += _cmsAvgCard('Avg Private/Comm %', avgPrivatePct != null ? avgPrivatePct.toFixed(1) + '%' : '–', '#10b981');
  html += _cmsAvgCard('Avg Oper. Margin', avgMargin != null ? avgMargin.toFixed(1) + '%' : '–', avgMargin != null && avgMargin >= 12 ? '#34d399' : avgMargin != null && avgMargin >= 0 ? '#fbbf24' : '#f87171');
  html += _cmsAvgCard('Avg Star Rating', avgStarRating != null ? avgStarRating.toFixed(1) + ' / 5' : '–', '#fbbf24');
  html += '</div>';

  // === Filters row ===
  html += '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px">';
  // Search
  html += `<input type="text" id="cmsSearch" placeholder="Search clinics..." value="${esc(diaCmsSearch)}" style="flex:1;min-width:180px;font-size:12px;padding:6px 10px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text)">`;
  // State dropdown
  const states = [...new Set(data.map(r => r.state).filter(Boolean))].sort();
  html += `<select id="cmsStateFilter" style="font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text)">`;
  html += `<option value="">All States</option>`;
  states.forEach(s => html += `<option value="${s}" ${diaCmsStateFilter === s ? 'selected' : ''}>${s}</option>`);
  html += '</select>';
  // Operator dropdown (top 20)
  const opCounts = {};
  data.forEach(r => { const op = r.operator_name || r.chain_organization; if (op) opCounts[op] = (opCounts[op] || 0) + 1; });
  const topOps = Object.entries(opCounts).sort((a, b) => b[1] - a[1]).slice(0, 30);
  html += `<select id="cmsOperatorFilter" style="font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);max-width:200px">`;
  html += `<option value="">All Operators</option>`;
  topOps.forEach(([op, ct]) => html += `<option value="${esc(op)}" ${diaCmsOperatorFilter === op ? 'selected' : ''}>${esc(op)} (${ct})</option>`);
  html += '</select>';
  // Modality filter
  html += `<select id="cmsModalityFilter" style="font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text)">`;
  html += `<option value="">All Types</option>`;
  html += `<option value="in_center" ${diaCmsModalityFilter === 'in_center' ? 'selected' : ''}>In-Center</option>`;
  html += `<option value="hybrid" ${diaCmsModalityFilter === 'hybrid' ? 'selected' : ''}>Hybrid</option>`;
  html += `<option value="home" ${diaCmsModalityFilter === 'home' ? 'selected' : ''}>Home Only</option>`;
  html += '</select>';
  html += `<span style="font-size:11px;color:var(--text3)">${fmtN(filtered.length)} of ${fmtN(data.length)}</span>`;
  html += '</div>';

  // === Table ===
  const page = filtered.slice(diaCmsPage * DIA_CMS_PAGE_SIZE, (diaCmsPage + 1) * DIA_CMS_PAGE_SIZE);
  const totalPages = Math.ceil(filtered.length / DIA_CMS_PAGE_SIZE);

  html += '<div class="table-wrapper" style="overflow-x:auto">';
  html += '<div class="data-table" style="min-width:1200px">';

  // Header (sortable)
  const cols = [
    { key: 'operator_name', label: 'Operator', flex: '1.1' },
    { key: 'facility_name', label: 'Facility', flex: '1.3' },
    { key: 'city', label: 'City', flex: '0.7' },
    { key: 'state', label: 'ST', flex: '0.3' },
    { key: 'modality_type', label: 'Type', flex: '0.5' },
    { key: 'est_in_center_patients', label: 'IC Pts', flex: '0.5', align: 'right' },
    { key: 'est_home_patients', label: 'Home Pts', flex: '0.5', align: 'right' },
    { key: '_medicare_pct', label: 'Mcare %', flex: '0.45', align: 'right' },
    { key: '_medicaid_pct', label: 'Mcaid %', flex: '0.45', align: 'right' },
    { key: '_private_pct', label: 'Priv %', flex: '0.45', align: 'right' },
    { key: 'est_in_center_revenue', label: 'IC Rev', flex: '0.6', align: 'right' },
    { key: 'est_home_revenue', label: 'Home Rev', flex: '0.6', align: 'right' },
    { key: 'estimated_annual_revenue', label: 'TTM Rev', flex: '0.6', align: 'right' },
    { key: 'estimated_ebitda', label: 'EBITDA', flex: '0.6', align: 'right' },
    { key: 'ttm_operating_margin', label: 'Margin', flex: '0.5', align: 'right' },
    { key: 'star_rating', label: 'Stars', flex: '0.4', align: 'center' },
    { key: '_actions', label: 'Actions', flex: '0.7', align: 'center' }
  ];

  html += '<div class="table-row" style="font-weight:600;border-bottom:2px solid var(--border);font-size:11px;text-transform:uppercase;letter-spacing:0.5px;color:var(--text3)">';
  cols.forEach(c => {
    const isActive = diaCmsSort.col === c.key;
    const arrow = isActive ? (diaCmsSort.dir === 'asc' ? ' ↑' : ' ↓') : '';
    const style = `flex:${c.flex};${c.align ? 'text-align:' + c.align + ';' : ''}cursor:pointer;user-select:none;${isActive ? 'color:var(--accent);' : ''}`;
    html += `<div data-cms-sort="${c.key}" style="${style}">${c.label}${arrow}</div>`;
  });
  html += '</div>';

  // Rows
  page.forEach((row, idx) => {
    const modBadge = row.modality_type === 'hybrid' ? '<span style="color:#fbbf24;font-weight:600">Hybrid</span>'
      : row.modality_type === 'home' ? '<span style="color:#a78bfa;font-weight:600">Home</span>'
      : '<span style="color:#34d399;font-weight:600">IC</span>';
    const icPts = Number(row.est_in_center_patients) || 0;
    const hmPts = Number(row.est_home_patients) || 0;
    const icRev = Number(row.est_in_center_revenue) || 0;
    const hmRev = Number(row.est_home_revenue) || 0;
    const fmtRev = v => v > 0 ? '$' + (v / 1000000).toFixed(1) + 'M' : '–';
    const isSelected = diaCmsSelectedIdx === idx;

    html += `<div class="table-row clickable-row" data-cms-row-idx="${idx}" style="font-size:12px;cursor:pointer;${isSelected ? 'background:rgba(96,165,250,0.1);border-left:3px solid #60a5fa;' : ''}">`;
    html += `<div style="flex:1.1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text2)">${(row.operator_name || row.chain_organization) ? entityLink(row.operator_name || row.chain_organization, 'operator', null) : '–'}</div>`;
    html += `<div style="flex:1.3;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500">${esc(row.facility_name || '')}</div>`;
    html += `<div style="flex:0.7;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text2)">${esc(row.city || '')}</div>`;
    html += `<div style="flex:0.3;color:var(--text2)">${esc(row.state || '')}</div>`;
    html += `<div style="flex:0.5;font-size:11px">${modBadge}</div>`;
    html += `<div style="flex:0.5;text-align:right;font-weight:500;color:#34d399">${icPts > 0 ? fmtN(icPts) : '–'}</div>`;
    html += `<div style="flex:0.5;text-align:right;font-weight:500;color:#a78bfa">${hmPts > 0 ? fmtN(hmPts) : '–'}</div>`;
    // Payor mix columns
    const rMcarePct = payerPct(row, 'payer_mix_medicare', 'payer_mix_medicare_pct');
    const rMcaidPct = payerPct(row, 'payer_mix_medicaid', 'payer_mix_medicaid_pct');
    const rPrivPct = payerPct(row, 'payer_mix_commercial', 'payer_mix_private_pct');
    html += `<div style="flex:0.45;text-align:right;color:#3b82f6;font-size:11px" title="CMS-reported Medicare patient %">${rMcarePct != null ? rMcarePct.toFixed(1) + '%' : '–'}</div>`;
    html += `<div style="flex:0.45;text-align:right;color:#8b5cf6;font-size:11px" title="CMS-reported Medicaid patient %">${rMcaidPct != null ? rMcaidPct.toFixed(1) + '%' : '–'}</div>`;
    html += `<div style="flex:0.45;text-align:right;color:#10b981;font-size:11px" title="CMS-reported Private/Commercial %">${rPrivPct != null ? rPrivPct.toFixed(1) + '%' : '–'}</div>`;
    html += `<div style="flex:0.6;text-align:right;color:var(--text2)">${fmtRev(icRev)}</div>`;
    html += `<div style="flex:0.6;text-align:right;color:var(--text2)">${fmtRev(hmRev)}</div>`;
    html += `<div style="flex:0.6;text-align:right;color:var(--text2)">${row.estimated_annual_revenue ? '$' + (Number(row.estimated_annual_revenue) / 1000000).toFixed(1) + 'M' : '–'}</div>`;
    html += `<div style="flex:0.6;text-align:right;color:var(--text2)">${row.estimated_ebitda ? '$' + Math.round(Number(row.estimated_ebitda) / 1000).toLocaleString() + 'K' : '–'}</div>`;
    // Operating margin & star rating
    const rowMargin = row.ttm_operating_margin != null ? Number(row.ttm_operating_margin) : null;
    const marginColor = rowMargin != null ? (rowMargin >= 12 ? '#34d399' : rowMargin >= 0 ? '#fbbf24' : '#f87171') : 'var(--text3)';
    html += `<div style="flex:0.5;text-align:right;font-size:11px;color:${marginColor}" title="Estimated operating margin (TTM revenue − estimated costs)">${rowMargin != null ? rowMargin.toFixed(1) + '%' : '–'}</div>`;
    const rowStars = row.star_rating != null ? Number(row.star_rating) : null;
    html += `<div style="flex:0.4;text-align:center;font-size:11px" title="CMS 5-Star Quality Rating">${rowStars != null ? '<span style="color:#fbbf24">★</span> ' + rowStars.toFixed(1) : '–'}</div>`;
    html += `<div style="flex:0.7;text-align:center;display:flex;gap:3px;justify-content:center" onclick="event.stopPropagation()"><button class="cms-flag-btn" data-clinic-id="${esc(row.clinic_id || row.ccn || '')}" data-clinic-name="${esc(row.facility_name || '')}" style="font-size:10px;padding:3px 8px;border:1px solid var(--border);border-radius:4px;background:var(--s3);color:var(--text2);cursor:pointer;" title="Flag for research">Flag</button><button class="gov-row-action" onclick='showDetail(${safeJSON(row)}, "dia-clinic", "Ownership")' title="View owner & contacts">📞</button><button class="gov-row-action accent" onclick='showDetail(${safeJSON(row)}, "dia-clinic", "Intel")' title="Research & intel">🔍</button></div>`;
    html += '</div>';
  });

  if (page.length === 0) {
    html += '<div class="table-empty" style="padding:24px;text-align:center;color:var(--text3)">No clinics match filters</div>';
  }

  html += '</div>'; // data-table
  html += '</div>'; // table-wrapper

  // Pagination
  if (totalPages > 1) {
    html += '<div style="display:flex;justify-content:center;align-items:center;gap:8px;margin-top:12px;font-size:12px">';
    html += `<button id="cmsPrev" style="padding:4px 12px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text2);cursor:pointer" ${diaCmsPage === 0 ? 'disabled' : ''}>← Prev</button>`;
    html += `<span style="color:var(--text3)">Page ${diaCmsPage + 1} of ${totalPages}</span>`;
    html += `<button id="cmsNext" style="padding:4px 12px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text2);cursor:pointer" ${diaCmsPage >= totalPages - 1 ? 'disabled' : ''}>Next →</button>`;
    html += '</div>';
  }

  // === Inline context card for selected row ===
  if (diaCmsSelectedIdx !== undefined && page[diaCmsSelectedIdx]) {
    const sel = page[diaCmsSelectedIdx];
    html += '<div style="margin-top:16px;border:1px solid #60a5fa;border-radius:12px;padding:16px 20px;background:var(--s1)">';
    html += '<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px">';
    html += '<div>';
    html += '<h3 style="margin:0;font-size:15px;font-weight:700;color:var(--text)">' + esc(sel.facility_name || 'Unknown') + '</h3>';
    html += '<div style="font-size:12px;color:var(--text2);margin-top:2px">' + esc((sel.city || '') + (sel.state ? ', ' + sel.state : '')) + (sel.address ? ' — ' + esc(sel.address) : '') + '</div>';
    html += '</div>';
    html += '<button style="font-size:11px;padding:4px 10px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text2);cursor:pointer" onclick="diaCmsSelectedIdx=undefined;renderDiaTab()">Close</button>';
    html += '</div>';
    // Key clinic data grid
    html += '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px;font-size:12px">';
    const _cv = (lbl, val) => '<div style="background:var(--s2);padding:8px;border-radius:6px"><div style="color:var(--text3);font-size:10px;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:2px">' + lbl + '</div><div style="font-weight:600;color:var(--text)">' + val + '</div></div>';
    html += _cv('Operator', esc(sel.operator_name || sel.chain_organization || '—'));
    html += _cv('Modality', esc(sel.modality_type ? sel.modality_type.replace(/_/g, ' ') : '—'));
    html += _cv('IC Patients', fmtN(Number(sel.est_in_center_patients) || 0));
    html += _cv('Home Patients', fmtN(Number(sel.est_home_patients) || 0));
    html += _cv('Annual Revenue', sel.estimated_annual_revenue ? '$' + (Number(sel.estimated_annual_revenue) / 1e6).toFixed(1) + 'M' : '—');
    html += _cv('EBITDA', sel.estimated_ebitda ? '$' + Math.round(Number(sel.estimated_ebitda) / 1000).toLocaleString() + 'K' : '—');
    html += _cv('Clinic ID', esc(String(sel.clinic_id || sel.ccn || '—')));
    html += _cv('Medicare ID', esc(String(sel.medicare_id || '—')));
    html += '</div>';
    // Payor mix & quality row
    const selMcarePct = payerPct(sel, 'payer_mix_medicare', 'payer_mix_medicare_pct');
    const selMcaidPct = payerPct(sel, 'payer_mix_medicaid', 'payer_mix_medicaid_pct');
    const selPrivPct = payerPct(sel, 'payer_mix_commercial', 'payer_mix_private_pct');
    const selMargin = sel.ttm_operating_margin != null ? Number(sel.ttm_operating_margin) : null;
    const selStars = sel.star_rating != null ? Number(sel.star_rating) : null;
    html += '<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin-bottom:12px;font-size:12px">';
    html += _cv('Medicare %', selMcarePct != null ? '<span style="color:#3b82f6;font-weight:700">' + selMcarePct.toFixed(1) + '%</span> <span style="font-size:9px;color:var(--text3)">CMS reported</span>' : '—');
    html += _cv('Medicaid %', selMcaidPct != null ? '<span style="color:#8b5cf6;font-weight:700">' + selMcaidPct.toFixed(1) + '%</span> <span style="font-size:9px;color:var(--text3)">CMS reported</span>' : '—');
    html += _cv('Private/Comm %', selPrivPct != null ? '<span style="color:#10b981;font-weight:700">' + selPrivPct.toFixed(1) + '%</span> <span style="font-size:9px;color:var(--text3)">CMS reported</span>' : '—');
    html += _cv('Oper. Margin', selMargin != null ? '<span style="color:' + (selMargin >= 12 ? '#34d399' : selMargin >= 0 ? '#fbbf24' : '#f87171') + ';font-weight:700">' + selMargin.toFixed(1) + '%</span> <span style="font-size:9px;color:var(--text3)">Estimated</span>' : '—');
    html += _cv('Star Rating', selStars != null ? '<span style="color:#fbbf24">★</span> ' + selStars.toFixed(1) + ' <span style="font-size:9px;color:var(--text3)">CMS reported</span>' : '—');
    html += '</div>';
    // Quick actions
    html += '<div style="display:flex;gap:8px;flex-wrap:wrap">';
    const searchQ = (sel.facility_name || '') + ' ' + (sel.address || '') + ' ' + (sel.city || '') + ' ' + (sel.state || '') + ' dialysis';
    html += '<a href="https://www.google.com/search?q=' + encodeURIComponent(searchQ.trim()) + '" target="_blank" rel="noopener" style="font-size:11px;padding:5px 12px;border-radius:6px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none;cursor:pointer">Google Search</a>';
    html += '<button class="btn-action default" style="font-size:11px;padding:5px 12px;" onclick=\'showDetail(' + safeJSON(sel) + ',"dia-clinic")\'>Open Full Detail</button>';
    html += '<button class="cms-flag-btn" data-clinic-id="' + esc(sel.clinic_id || sel.ccn || '') + '" data-clinic-name="' + esc(sel.facility_name || '') + '" style="font-size:11px;padding:5px 12px;border:1px solid var(--accent);border-radius:6px;background:rgba(52,211,153,0.1);color:var(--accent);cursor:pointer;font-weight:600">Flag for Research</button>';
    html += '</div>';
    html += '</div>';
  }

  html += '</div>'; // biz-section

  // === Attach handlers ===
  setTimeout(() => {
    // CMS row clicks — show inline context card
    document.querySelectorAll('[data-cms-row-idx]').forEach(el => {
      el.addEventListener('click', () => {
        const idx = parseInt(el.dataset.cmsRowIdx, 10);
        diaCmsSelectedIdx = diaCmsSelectedIdx === idx ? undefined : idx;
        renderDiaTab();
      });
    });
    // Sort headers
    document.querySelectorAll('[data-cms-sort]').forEach(el => {
      el.addEventListener('click', () => {
        const col = el.dataset.cmsSort;
        if (diaCmsSort.col === col) {
          diaCmsSort.dir = diaCmsSort.dir === 'desc' ? 'asc' : 'desc';
        } else {
          diaCmsSort.col = col;
          diaCmsSort.dir = 'desc';
        }
        diaCmsPage = 0;
        diaCmsSelectedIdx = undefined;
        renderDiaTab();
      });
    });
    // Search
    const searchEl = document.getElementById('cmsSearch');
    if (searchEl) {
      let debounce;
      searchEl.addEventListener('input', () => {
        clearTimeout(debounce);
        debounce = setTimeout(() => {
          diaCmsSearch = searchEl.value;
          diaCmsPage = 0;
          renderDiaTab();
          // Restore focus after DOM re-render
          const restored = document.getElementById('cmsSearch');
          if (restored) {
            restored.focus();
            restored.setSelectionRange(restored.value.length, restored.value.length);
          }
        }, 300);
      });
    }
    // State filter
    const stateEl = document.getElementById('cmsStateFilter');
    if (stateEl) {
      stateEl.addEventListener('change', () => {
        diaCmsStateFilter = stateEl.value;
        diaCmsPage = 0;
        renderDiaTab();
      });
    }
    // Operator filter
    const opEl = document.getElementById('cmsOperatorFilter');
    if (opEl) {
      opEl.addEventListener('change', () => {
        diaCmsOperatorFilter = opEl.value;
        diaCmsPage = 0;
        renderDiaTab();
      });
    }
    // Modality filter
    const modEl = document.getElementById('cmsModalityFilter');
    if (modEl) {
      modEl.addEventListener('change', () => {
        diaCmsModalityFilter = modEl.value;
        diaCmsPage = 0;
        renderDiaTab();
      });
    }
    // Pagination
    const prevBtn = document.getElementById('cmsPrev');
    const nextBtn = document.getElementById('cmsNext');
    if (prevBtn) prevBtn.addEventListener('click', () => { diaCmsPage--; diaCmsSelectedIdx = undefined; renderDiaTab(); });
    if (nextBtn) nextBtn.addEventListener('click', () => { diaCmsPage++; diaCmsSelectedIdx = undefined; renderDiaTab(); });
    // Flag-for-review buttons
    document.querySelectorAll('.cms-flag-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const clinicId = btn.dataset.clinicId;
        const clinicName = btn.dataset.clinicName;
        if (!clinicId) return;
        btn.disabled = true;
        btn.textContent = '...';
        try {
          await applyInsertWithFallback({
            proxyBase: '/api/dia-query',
            table: 'research_queue_outcomes',
            data: {
              medicare_id: clinicId,
              outcome: 'flagged_for_review',
              notes: 'Flagged from CMS Data tab for research',
              created_at: new Date().toISOString()
            },
            source_surface: 'dia_cms_flag'
          });
          btn.textContent = '✓';
          btn.style.color = 'var(--success)';
          btn.style.borderColor = 'var(--success)';
          showToast('Flagged ' + (clinicName || clinicId) + ' for review', 'success');
        } catch(e) {
          btn.disabled = false;
          btn.textContent = 'Flag';
          showToast('Flag failed: ' + e.message, 'error');
        }
      });
    });
  }, 0);

  return html;
}

function _cmsAvgCard(title, value, color) {
  return `<div style="background:var(--s2);border:1px solid var(--border);border-radius:8px;padding:10px 12px;text-align:center">
    <div style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:2px">${title}</div>
    <div style="font-size:18px;font-weight:800;color:${color}">${value}</div>
  </div>`;
}

// ============================================================================
// LIST WINDOWING — render-side virtualization for heavy Dialysis lists
// ============================================================================
// Each list tracks how many rows are currently materialized into the DOM. The
// full in-memory arrays (npiSignals, inventoryChanges, researchOutcomes, etc.)
// are NEVER truncated — counts, filters, and resolve actions all keep working
// over the full data. Only the rendered HTML is capped, with a "Load more"
// control to grow the window when the user actually wants to see further.
const _diaListWindow = {};
const _DIA_WINDOW_DEFAULT = {
  allSignals: 100,
  bdEvents: 100,
  cleanupMissing: 30,
  cleanupDup: 25,
  inventoryChanges: 100,
};
function _diaWindowGet(key) {
  if (typeof _diaListWindow[key] !== 'number') {
    _diaListWindow[key] = _DIA_WINDOW_DEFAULT[key] || 100;
  }
  return _diaListWindow[key];
}
function _diaWindowReset(key) {
  if (key) delete _diaListWindow[key];
  else for (const k in _diaListWindow) delete _diaListWindow[k];
}
window._diaWindowMore = function(key, step, total) {
  const cur = _diaWindowGet(key);
  _diaListWindow[key] = Math.min(cur + step, total);
  renderDiaTab();
};
window._diaWindowShowAll = function(key, total) {
  _diaListWindow[key] = total;
  renderDiaTab();
};
function _diaWindowFooter(key, shown, total, step) {
  if (shown >= total) {
    if (total === 0) return '';
    return `<div style="padding:8px;font-size:11px;color:var(--text3);text-align:center">Showing all ${fmtN(total)}</div>`;
  }
  const nextStep = Math.min(step, total - shown);
  return `<div style="padding:12px;text-align:center;color:var(--text3);font-size:12px;background:var(--s2);border-radius:8px;margin-top:10px">
    <span>Showing ${fmtN(shown)} of ${fmtN(total)}</span>
    <button onclick="_diaWindowMore('${key}', ${step}, ${total})" style="margin-left:12px;font-size:11px;padding:6px 14px;border-radius:6px;border:1px solid var(--accent);background:rgba(52,211,153,0.1);color:var(--accent);cursor:pointer;font-weight:600">Load ${fmtN(nextStep)} more</button>
    <button onclick="_diaWindowShowAll('${key}', ${total})" style="margin-left:6px;font-size:11px;padding:6px 14px;border-radius:6px;border:1px solid var(--border);background:var(--s2);color:var(--text2);cursor:pointer">Show all</button>
  </div>`;
}

// ============================================================================
// NPI TAB
// ============================================================================

/**
 * Render NPI Intelligence tab — Round 76eb
 *
 * The matview now classifies each duplicate-NPI signal by severity. Same-
 * physical-clinic duplicates with a clear primary CCN are auto-resolved
 * nightly and hidden from the default view (severity='auto_resolvable').
 * The default 'actionable' filter shows: data_error (likely typos),
 * data_quality (multi-loc operators sharing NPI), unresolved (no primary
 * picked yet), and all missing-NPI rows.
 *
 * UX: side drawer (right) instead of below-table panel; bulk-select +
 * bulk-flag/dismiss; signal-reason text comes from the matview row itself
 * so the action prompt is correct per signal type.
 */

// Severity styling — keyed by matview severity column (or a synthetic key
// for provider-change signals, which all have severity='data_quality' but
// represent BD events rather than data-hygiene cleanup).
const NPI_SEVERITY_META = {
  provider_change: { label: 'Provider Change', color: '#fb923c', bg: 'rgba(251,146,60,0.10)',  priority: 1 },
  data_error:      { label: 'Likely Typo',     color: '#f87171', bg: 'rgba(248,113,113,0.10)', priority: 1 },
  data_quality:    { label: 'Needs Review',    color: '#fbbf24', bg: 'rgba(251,191,36,0.10)',  priority: 2 },
  unresolved:      { label: 'Auto-Pending',    color: '#a78bfa', bg: 'rgba(167,139,250,0.10)', priority: 3 },
  missing:         { label: 'Look Up NPI',     color: '#22d3ee', bg: 'rgba(34,211,238,0.10)',  priority: 2 },
  auto_resolvable: { label: 'Auto-Resolved',   color: '#34d399', bg: 'rgba(52,211,153,0.10)',  priority: 5 }
};

const NPI_PROVIDER_CHANGE_TYPES = new Set([
  'npi_deactivated','address_change','name_change','official_change','new_npi'
]);

function _npiRowKey(row) {
  return (row.clinic_id || '') + '|' + (row.npi || '') + '|' + (row.signal_type || '');
}

function _npiSeverityKey(row) {
  if (row.signal_type === 'missing_inventory_npi') return 'missing';
  if (NPI_PROVIDER_CHANGE_TYPES.has(row.signal_type)) return 'provider_change';
  return row.severity || 'unresolved';
}

function _npiBannerText(rows) {
  // Adapt the action guidance to what's actually in the visible set.
  const types = new Set(rows.map(r => r.signal_type));
  const sevs  = new Set(rows.map(_npiSeverityKey));

  if (rows.length === 0) {
    return 'No actionable NPI signals — the matview has classified everything as auto-resolved or filtered. Switch the filter to <strong>All</strong> to inspect resolved/dismissed signals.';
  }
  const parts = [];
  // Provider-change signals (Round 76ed) — highest BD value, surface first
  if (types.has('npi_deactivated')) {
    parts.push('<strong>NPI deactivated</strong>: NPPES marked an NPI inactive — likely closure, merger, or operator change. Confirm operating status.');
  }
  if (types.has('address_change')) {
    parts.push('<strong>Address changed</strong>: NPPES practice address moved — usually a relocation or lease event worth a property note.');
  }
  if (types.has('name_change')) {
    parts.push('<strong>Name changed</strong>: org name on NPPES changed — rebrand or ownership transition.');
  }
  if (types.has('new_npi')) {
    parts.push('<strong>New NPI at known address</strong>: a new ESRD NPI was registered at an active clinic that has no NPI link — adopt as that clinic\'s NPI.');
  }
  if (types.has('official_change')) {
    parts.push('<strong>Authorized official changed</strong>: lower-priority governance signal.');
  }
  // Data-hygiene signals
  if (types.has('missing_inventory_npi')) {
    parts.push('<strong>Missing NPI</strong>: clinic exists but NPI field is blank — open the row to look up the NPI on the registry by name + address, then patch the clinic record.');
  }
  if (sevs.has('data_error') && types.has('duplicate_inventory_npi')) {
    parts.push('<strong>Likely typo</strong>: same NPI on rows with different names AND addresses — almost certainly a wrong NPI on one row. Open both, decide which is correct, clear the other.');
  }
  if (sevs.has('unresolved') && types.has('duplicate_inventory_npi')) {
    parts.push('<strong>Auto-pending</strong>: nightly resolver will assign a primary CCN on next run. Safe to ignore unless you need an immediate fix.');
  }
  return parts.join(' ');
}

// ──────────────────────────────────────────────────────────────────────────
// BD Events feed — provider-change signals as cards (Round 76ef)
//
// Each card answers: what happened, where, and what to do about it.
// One-click actions: Open property | Adopt (for new_npi) | Flag | Dismiss.
// ──────────────────────────────────────────────────────────────────────────

const NPI_BD_META = {
  npi_deactivated: { icon: '🚪', color: '#f87171', label: 'NPPES Deactivated' },
  address_change:  { icon: '📍', color: '#fb923c', label: 'Address Changed' },
  name_change:     { icon: '✏️', color: '#fbbf24', label: 'Name Changed' },
  official_change: { icon: '👤', color: '#a78bfa', label: 'Official Changed' },
  new_npi:         { icon: '🆕', color: '#34d399', label: 'New NPI at Address' },
};

function _renderNpiBdEvents(rows) {
  let html = '';

  // Window filter pills
  const windowBtn = (days, label) => {
    const active = diaNpiBdWindowDays === days;
    return `<button data-bd-window="${days}" style="font-size:11px;padding:4px 12px;border-radius:6px;border:1px solid ${active ? 'var(--accent)' : 'var(--border)'};background:${active ? 'rgba(52,211,153,0.1)' : 'var(--s2)'};color:${active ? 'var(--accent)' : 'var(--text2)'};cursor:pointer;font-weight:${active ? 600 : 400}">${label}</button>`;
  };

  // Banner — explains what BD Events are and why they matter.
  html += '<div style="padding:12px 16px;background:rgba(52,211,153,0.08);border-radius:8px;border-left:3px solid var(--accent);margin-bottom:12px;">';
  html += '<div style="font-weight:700;font-size:13px;margin-bottom:4px;color:var(--text)">Provider Change Events</div>';
  html += '<div style="font-size:12px;color:var(--text2);line-height:1.5">NPPES registry changes detected against active dialysis clinics in our inventory — these are the BD-actionable signals: closures, relocations, rebrands, and ownership transitions. Each one deserves a research decision.</div>';
  html += '</div>';

  // Window filter
  html += '<div style="display:flex;gap:6px;margin-bottom:12px;align-items:center">';
  html += '<span style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:0.5px;font-weight:600">Detected:</span>';
  html += windowBtn(7, 'Last 7 days');
  html += windowBtn(30, 'Last 30 days');
  html += windowBtn(90, 'Last 90 days');
  html += windowBtn(0, 'All-time');
  html += '</div>';

  // Filter rows by window — using cms_updated_at as proxy if no signal_date
  // Note: matview doesn't carry a signal_date column today; we just show all
  // rows when window != 0 since the matview only retains the latest snapshot.
  // Future: add a signal_first_seen column to track when each signal first appeared.
  let visible = rows.slice();

  // Sort: priority asc, then patient count desc
  visible.sort((a, b) => {
    const pa = a.signal_priority || 5, pb = b.signal_priority || 5;
    if (pa !== pb) return pa - pb;
    return (b.latest_total_patients || 0) - (a.latest_total_patients || 0);
  });

  if (visible.length === 0) {
    html += '<div style="padding:48px 16px;text-align:center;color:var(--text3);background:var(--s2);border-radius:8px">';
    html += '<div style="font-size:32px;margin-bottom:8px">🔍</div>';
    html += '<div style="font-size:14px;font-weight:600;color:var(--text2);margin-bottom:4px">No provider-change events detected</div>';
    html += '<div style="font-size:12px">The weekly NPPES sync runs Sundays at 06:30 UTC. Change-detection signals require at least two snapshots to compare, so the first BD events arrive after two consecutive Sunday runs.</div>';
    html += '</div>';
    return html;
  }

  // Card per event — windowed render (full array drives counts/filters)
  const _bdWin = _diaWindowGet('bdEvents');
  const _bdShown = Math.min(_bdWin, visible.length);
  html += '<div style="display:flex;flex-direction:column;gap:10px">';
  for (const row of visible.slice(0, _bdShown)) {
    const meta = NPI_BD_META[row.signal_type] || { icon: '•', color: 'var(--text2)', label: row.signal_type };
    const npiId = row.npi || row.clinic_id || '';
    const isNewNpi = row.signal_type === 'new_npi';

    html += '<div style="border:1px solid var(--border);border-left:3px solid ' + meta.color + ';border-radius:10px;padding:14px 16px;background:var(--s1)">';
    // Top row: icon + label + facility
    html += '<div style="display:flex;align-items:flex-start;gap:12px;margin-bottom:8px">';
    html += '<div style="font-size:22px;flex-shrink:0;line-height:1">' + meta.icon + '</div>';
    html += '<div style="flex:1;min-width:0">';
    html += '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:2px">';
    html += '<span style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.6px;padding:2px 8px;border-radius:8px;background:' + meta.color + '22;color:' + meta.color + '">' + meta.label + '</span>';
    if (row.latest_total_patients) {
      html += '<span style="font-size:11px;color:var(--text3)">' + fmtN(row.latest_total_patients) + ' patients</span>';
    }
    html += '</div>';
    html += '<h4 style="margin:0;font-size:14px;font-weight:700;color:var(--text);overflow-wrap:anywhere">' + esc(norm(row.facility_name) || 'Unknown') + '</h4>';
    html += '<div style="font-size:12px;color:var(--text2);margin-top:2px">' + esc((row.city || '') + (row.state ? ', ' + row.state : '')) + (row.operator_name ? ' · ' + esc(row.operator_name) : '') + '</div>';
    html += '</div>';
    html += '</div>';

    // Detail (signal_reason from matview)
    html += '<div style="font-size:12px;color:var(--text);line-height:1.5;padding:8px 12px;background:var(--s2);border-radius:6px;margin-bottom:10px">' + esc(row.signal_reason || '') + '</div>';

    // Action buttons
    html += '<div style="display:flex;gap:6px;flex-wrap:wrap">';
    if (isNewNpi) {
      // Adopt — primary action: patches medicare_clinics.npi
      html += '<button class="npi-adopt-btn" data-clinic-id="' + esc(row.clinic_id) + '" data-npi="' + esc(row.npi) + '" style="font-size:11px;padding:6px 12px;border:1px solid var(--accent);border-radius:6px;background:var(--accent);color:#000;cursor:pointer;font-weight:600">✓ Adopt this NPI</button>';
    }
    html += '<button class="btn-action default" style="font-size:11px;padding:6px 12px" onclick=\'showDetail(' + safeJSON(row) + ',"dia-clinic")\'>Open property</button>';
    html += '<a href="https://npiregistry.cms.hhs.gov/provider-view/' + encodeURIComponent(row.npi || '') + '" target="_blank" rel="noopener" style="font-size:11px;padding:6px 12px;border-radius:6px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none">NPPES ↗</a>';
    html += '<button class="npi-flag-btn" data-npi-id="' + esc(npiId) + '" data-npi-name="' + esc(row.facility_name || '') + '" style="font-size:11px;padding:6px 12px;border:1px solid var(--accent);border-radius:6px;background:rgba(52,211,153,0.1);color:var(--accent);cursor:pointer;font-weight:600">Flag for research</button>';
    html += '<button class="npi-dismiss-btn" data-npi-id="' + esc(npiId) + '" style="font-size:11px;padding:6px 12px;border:1px solid #f87171;border-radius:6px;background:rgba(248,113,113,0.1);color:#f87171;cursor:pointer;font-weight:600">Dismiss</button>';
    html += '</div>';
    html += '</div>';
  }
  html += '</div>';
  html += _diaWindowFooter('bdEvents', _bdShown, visible.length, 100);

  // Wire handlers
  setTimeout(() => {
    document.querySelectorAll('[data-bd-window]').forEach(btn => {
      btn.addEventListener('click', () => {
        diaNpiBdWindowDays = parseInt(btn.dataset.bdWindow, 10);
        _diaWindowReset('bdEvents');
        renderDiaTab();
      });
    });
    _wireNpiAdoptButtons();
    _wireNpiFlagDismissButtons();
  }, 0);

  return html;
}

// ──────────────────────────────────────────────────────────────────────────
// Cleanup Queue — Missing NPI batch + Duplicate cluster batch (Round 76ef)
//
// One card per task. Each card shows the minimum info needed to make the
// decision and a primary action button. No table, no scrolling past 500
// rows of context — just the actionable items.
// ──────────────────────────────────────────────────────────────────────────

function _renderNpiCleanup(missingRows, dupRows) {
  let html = '';

  // Sub-tab toggle
  const subBtn = (key, label, count) => {
    const active = diaNpiCleanupSubMode === key;
    const badge = `<span style="font-size:10px;padding:1px 6px;border-radius:8px;background:${active ? 'rgba(255,255,255,0.25)' : 'var(--s3)'};color:${active ? '#fff' : 'var(--text2)'};margin-left:4px">${fmtN(count)}</span>`;
    return `<button data-cleanup-sub="${key}" style="font-size:12px;font-weight:600;padding:6px 12px;border-radius:6px;border:1px solid ${active ? 'var(--accent)' : 'var(--border)'};background:${active ? 'var(--accent)' : 'var(--s2)'};color:${active ? '#000' : 'var(--text2)'};cursor:pointer">${label}${badge}</button>`;
  };

  const dupClusters = _groupDupClusters(dupRows);

  html += '<div style="display:flex;gap:6px;margin-bottom:14px;align-items:center">';
  html += subBtn('missing', 'Missing NPI', missingRows.length);
  html += subBtn('duplicate', 'Duplicate Review', dupClusters.length);
  html += '</div>';

  if (diaNpiCleanupLoading) {
    html += '<div style="padding:48px;text-align:center;color:var(--text3)"><span class="spinner"></span><div style="margin-top:12px;font-size:12px">Loading NPPES candidates…</div></div>';
    return html;
  }

  if (diaNpiCleanupSubMode === 'missing') {
    html += _renderNpiCleanupMissing(missingRows);
  } else {
    html += _renderNpiCleanupDuplicates(dupClusters);
  }

  setTimeout(() => {
    document.querySelectorAll('[data-cleanup-sub]').forEach(btn => {
      btn.addEventListener('click', () => {
        diaNpiCleanupSubMode = btn.dataset.cleanupSub;
        _diaWindowReset('cleanupMissing');
        _diaWindowReset('cleanupDup');
        renderDiaTab();
      });
    });
  }, 0);

  return html;
}

function _groupDupClusters(dupRows) {
  const map = new Map();
  for (const row of dupRows) {
    if (!row.npi) continue;
    if (!map.has(row.npi)) map.set(row.npi, []);
    map.get(row.npi).push(row);
  }
  return Array.from(map.entries())
    .map(([npi, rows]) => ({ npi, rows }))
    .sort((a, b) => {
      // Sort by signal_priority of any row in the cluster (data_error > data_quality)
      const pa = Math.min(...a.rows.map(r => r.signal_priority || 5));
      const pb = Math.min(...b.rows.map(r => r.signal_priority || 5));
      if (pa !== pb) return pa - pb;
      const totalA = a.rows.reduce((s, r) => s + (r.latest_total_patients || 0), 0);
      const totalB = b.rows.reduce((s, r) => s + (r.latest_total_patients || 0), 0);
      return totalB - totalA;
    });
}

function _renderNpiCleanupMissing(rows) {
  let html = '';

  if (rows.length === 0) {
    html += '<div style="padding:48px;text-align:center;color:var(--text3);background:var(--s2);border-radius:8px"><div style="font-size:32px;margin-bottom:8px">✨</div><div style="font-size:14px;font-weight:600;color:var(--text2)">All clinics have NPIs populated</div></div>';
    return html;
  }

  // Banner with bulk action
  html += '<div style="padding:10px 14px;background:rgba(34,211,238,0.08);border-radius:8px;border-left:3px solid #22d3ee;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;gap:12px">';
  html += '<div style="font-size:12px;color:var(--text);line-height:1.5;flex:1;min-width:0">' + fmtN(rows.length) + ' active clinics need NPIs filled. The system has fetched NPPES candidates for some — confirm the right one with one click. For the rest, click <strong>Run NPPES lookup</strong> to fetch candidates now.</div>';
  html += '<button id="npi-bulk-lookup-btn" style="font-size:11px;padding:6px 12px;border:1px solid #22d3ee;border-radius:6px;background:rgba(34,211,238,0.1);color:#22d3ee;cursor:pointer;font-weight:600;flex-shrink:0;white-space:nowrap">Run NPPES lookup</button>';
  html += '</div>';

  // Sort: rows with candidates first, then by patient count desc
  const lookups = diaNpiLookupCache || new Map();
  const sorted = rows.slice().sort((a, b) => {
    const la = lookups.get(a.clinic_id);
    const lb = lookups.get(b.clinic_id);
    const ca = la && Array.isArray(la.raw_response) && la.raw_response.length > 0;
    const cb = lb && Array.isArray(lb.raw_response) && lb.raw_response.length > 0;
    if (ca !== cb) return ca ? -1 : 1;
    return (b.latest_total_patients || 0) - (a.latest_total_patients || 0);
  });

  const _cmWin = _diaWindowGet('cleanupMissing');
  const _cmShown = Math.min(_cmWin, sorted.length);
  html += '<div style="display:flex;flex-direction:column;gap:10px">';
  for (const row of sorted.slice(0, _cmShown)) {
    const lookup = lookups.get(row.clinic_id);
    const cands = (lookup && Array.isArray(lookup.raw_response)) ? lookup.raw_response : [];
    html += _renderMissingNpiCard(row, cands);
  }
  html += '</div>';
  html += _diaWindowFooter('cleanupMissing', _cmShown, sorted.length, 30);

  // Wire handlers
  setTimeout(() => {
    _wireNpiAdoptButtons();
    _wireNpiUnmappableButtons();
    const bulkBtn = document.getElementById('npi-bulk-lookup-btn');
    if (bulkBtn) bulkBtn.addEventListener('click', _onNpiBulkLookup);
  }, 0);

  return html;
}

function _renderMissingNpiCard(row, candidates) {
  let html = '';
  const facilityName = norm(row.facility_name) || 'Unknown';
  const addrLine = (row.address || '') + (row.city ? ', ' + row.city : '') + (row.state ? ' ' + row.state : '');
  const npiId = row.clinic_id;

  html += '<div style="border:1px solid var(--border);border-radius:10px;padding:14px 16px;background:var(--s1)">';
  // Header: clinic identity
  html += '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:10px">';
  html += '<div style="min-width:0;flex:1">';
  html += '<h4 style="margin:0;font-size:14px;font-weight:700;color:var(--text);overflow-wrap:anywhere">' + esc(facilityName) + '</h4>';
  html += '<div style="font-size:12px;color:var(--text2);margin-top:2px">' + esc(addrLine) + '</div>';
  html += '<div style="font-size:11px;color:var(--text3);margin-top:2px">CCN ' + esc(row.clinic_id || '—') + ' · ' + (row.operator_name ? esc(row.operator_name) : 'Independent') + (row.latest_total_patients ? ' · ' + fmtN(row.latest_total_patients) + ' patients' : '') + '</div>';
  html += '</div>';
  html += '</div>';

  // Candidates section
  if (candidates.length === 0) {
    html += '<div style="padding:10px 12px;background:var(--s2);border-radius:6px;font-size:12px;color:var(--text3);margin-bottom:10px">No NPPES candidates fetched yet — click <strong>Run NPPES lookup</strong> above to query the registry for this clinic.</div>';
  } else {
    html += '<div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:var(--text3);margin-bottom:6px">NPPES candidates</div>';
    html += '<div style="display:flex;flex-direction:column;gap:6px;margin-bottom:10px">';
    for (const c of candidates.slice(0, 4)) {
      const score = typeof c.score === 'number' ? c.score : 0;
      const scorePct = Math.round(score * 100);
      const scoreColor = score >= 0.9 ? 'var(--accent)' : score >= 0.6 ? '#fbbf24' : 'var(--text3)';
      const scoreLabel = score >= 0.9 ? 'Strong match' : score >= 0.6 ? 'Possible match' : 'Weak match';
      html += '<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:8px 10px;background:var(--s2);border-radius:6px;border-left:2px solid ' + scoreColor + '">';
      html += '<div style="min-width:0;flex:1">';
      html += '<div style="display:flex;align-items:center;gap:6px;font-size:11px;color:var(--text);margin-bottom:2px">';
      html += '<span style="font-family:monospace;font-weight:600">' + esc(c.npi || '—') + '</span>';
      html += '<span style="color:' + scoreColor + ';font-weight:600">· ' + scorePct + '% ' + scoreLabel + '</span>';
      html += '</div>';
      html += '<div style="font-size:12px;color:var(--text);font-weight:600;overflow-wrap:anywhere">' + esc(c.name || '') + '</div>';
      html += '<div style="font-size:11px;color:var(--text2);margin-top:1px;overflow-wrap:anywhere">' + esc((c.addr || '') + (c.city ? ', ' + c.city : '') + (c.state ? ' ' + c.state : '')) + '</div>';
      html += '</div>';
      html += '<button class="npi-adopt-btn" data-clinic-id="' + esc(npiId) + '" data-npi="' + esc(c.npi || '') + '" data-source="manual_adopt" style="font-size:11px;padding:6px 10px;border:1px solid var(--accent);border-radius:5px;background:rgba(52,211,153,0.1);color:var(--accent);cursor:pointer;font-weight:600;white-space:nowrap;flex-shrink:0">Adopt</button>';
      html += '</div>';
    }
    html += '</div>';
  }

  // Footer actions
  html += '<div style="display:flex;gap:6px;flex-wrap:wrap">';
  const searchQ = (row.facility_name || '') + ' ' + (row.city || '') + ' ' + (row.state || '') + ' NPI';
  html += '<a href="https://npiregistry.cms.hhs.gov/search?city=' + encodeURIComponent(row.city || '') + '&state=' + encodeURIComponent(row.state || '') + '&taxonomy_description=End-Stage+Renal+Disease" target="_blank" rel="noopener" style="font-size:11px;padding:5px 10px;border-radius:5px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none">Open NPPES ↗</a>';
  html += '<a href="https://www.google.com/search?q=' + encodeURIComponent(searchQ.trim()) + '" target="_blank" rel="noopener" style="font-size:11px;padding:5px 10px;border-radius:5px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none">Google ↗</a>';
  html += '<button class="npi-unmappable-btn" data-clinic-id="' + esc(npiId) + '" style="font-size:11px;padding:5px 10px;border:1px solid var(--border);border-radius:5px;background:var(--s2);color:var(--text3);cursor:pointer;margin-left:auto">Mark unmappable</button>';
  html += '</div>';
  html += '</div>';
  return html;
}

function _renderNpiCleanupDuplicates(clusters) {
  let html = '';

  if (clusters.length === 0) {
    html += '<div style="padding:48px;text-align:center;color:var(--text3);background:var(--s2);border-radius:8px"><div style="font-size:32px;margin-bottom:8px">✨</div><div style="font-size:14px;font-weight:600;color:var(--text2)">No duplicate-NPI clusters need human review</div><div style="font-size:12px;margin-top:4px">All same-address dups are auto-resolved nightly; multi-address dups are auto-cleared by the NPPES address resolver after the weekly sync populates the registry.</div></div>';
    return html;
  }

  html += '<div style="padding:10px 14px;background:rgba(248,113,113,0.06);border-radius:8px;border-left:3px solid #f87171;margin-bottom:12px;font-size:12px;color:var(--text);line-height:1.5">' + fmtN(clusters.length) + ' NPI clusters span multiple addresses — for each, decide which clinic should keep the NPI. When NPPES has the practice address, the recommendation is shown; otherwise verify both records and pick.</div>';

  const _cdWin = _diaWindowGet('cleanupDup');
  const _cdShown = Math.min(_cdWin, clusters.length);
  html += '<div style="display:flex;flex-direction:column;gap:10px">';
  for (const cluster of clusters.slice(0, _cdShown)) {
    html += _renderDupClusterCard(cluster);
  }
  html += '</div>';
  html += _diaWindowFooter('cleanupDup', _cdShown, clusters.length, 25);

  setTimeout(() => {
    _wireDupClusterButtons();
  }, 0);
  return html;
}

function _renderDupClusterCard(cluster) {
  const reg = (diaNpiRegistryCache && diaNpiRegistryCache.get(cluster.npi)) || null;
  let html = '';

  // Score each row against NPPES address (mirrors the SQL resolver logic)
  const normAddr = s => (s || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
  const normSt = s => (s || '').toUpperCase().trim();
  const regAddrNorm = reg ? normAddr(reg.npi_address) : '';
  const regSt = reg ? normSt(reg.npi_state) : '';

  const scored = cluster.rows.map(r => {
    let score = 0;
    if (reg && regAddrNorm && normAddr(r.address) === regAddrNorm && normSt(r.state) === regSt) score = 1.0;
    return { ...r, _score: score };
  }).sort((a, b) => b._score - a._score);
  const recommended = scored[0]._score >= 0.9 && (scored[1] === undefined || scored[1]._score < 0.5) ? scored[0] : null;

  html += '<div style="border:1px solid var(--border);border-radius:10px;padding:14px 16px;background:var(--s1)">';
  // Header
  html += '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:10px">';
  html += '<div style="min-width:0;flex:1">';
  html += '<div style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:0.5px;font-weight:600;margin-bottom:2px">NPI cluster · ' + cluster.rows.length + ' clinics share</div>';
  html += '<div style="font-family:monospace;font-size:14px;font-weight:700;color:var(--text)">' + esc(cluster.npi) + '</div>';
  html += '</div>';
  html += '</div>';

  // NPPES truth (or absence)
  if (reg) {
    html += '<div style="padding:8px 10px;background:rgba(52,211,153,0.08);border-radius:6px;border-left:2px solid var(--accent);margin-bottom:10px;font-size:11px">';
    html += '<div style="color:var(--text3);text-transform:uppercase;letter-spacing:0.5px;font-weight:600;margin-bottom:2px">NPPES says</div>';
    html += '<div style="color:var(--text);font-weight:600;overflow-wrap:anywhere">' + esc(reg.organization_name || '—') + '</div>';
    html += '<div style="color:var(--text2)">' + esc((reg.npi_address || '') + (reg.npi_city ? ', ' + reg.npi_city : '') + (reg.npi_state ? ' ' + reg.npi_state : '')) + '</div>';
    html += '</div>';
  } else {
    html += '<div style="padding:8px 10px;background:var(--s2);border-radius:6px;font-size:11px;color:var(--text3);margin-bottom:10px">NPPES record not in our registry yet — Sunday\'s national sweep will fetch it. Until then, decide manually.</div>';
  }

  // Per-row compare
  html += '<div style="display:flex;flex-direction:column;gap:6px;margin-bottom:10px">';
  for (const r of scored) {
    const isRec = recommended && r.clinic_id === recommended.clinic_id;
    const borderColor = isRec ? 'var(--accent)' : (r._score > 0 ? '#fbbf24' : 'var(--border)');
    html += '<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:8px 10px;background:var(--s2);border-radius:6px;border-left:2px solid ' + borderColor + '">';
    html += '<div style="min-width:0;flex:1">';
    html += '<div style="display:flex;align-items:center;gap:6px;font-size:11px;color:var(--text2);margin-bottom:2px">';
    html += '<span style="font-family:monospace;font-weight:600">CCN ' + esc(r.clinic_id) + '</span>';
    if (isRec) html += '<span style="color:var(--accent);font-weight:700">· Recommended</span>';
    if (r.latest_total_patients) html += '<span>· ' + fmtN(r.latest_total_patients) + ' patients</span>';
    html += '</div>';
    html += '<div style="font-size:12px;color:var(--text);font-weight:600;overflow-wrap:anywhere">' + esc(norm(r.facility_name) || 'Unknown') + '</div>';
    html += '<div style="font-size:11px;color:var(--text2);margin-top:1px;overflow-wrap:anywhere">' + esc((r.address || '') + (r.city ? ', ' + r.city : '') + (r.state ? ' ' + r.state : '')) + '</div>';
    html += '</div>';
    html += '<button class="dup-keep-btn" data-keep-id="' + esc(r.clinic_id) + '" data-npi="' + esc(cluster.npi) + '" style="font-size:11px;padding:6px 10px;border:1px solid ' + (isRec ? 'var(--accent)' : 'var(--border)') + ';border-radius:5px;background:' + (isRec ? 'var(--accent)' : 'var(--s2)') + ';color:' + (isRec ? '#000' : 'var(--text2)') + ';cursor:pointer;font-weight:600;white-space:nowrap;flex-shrink:0">Keep NPI here</button>';
    html += '</div>';
  }
  html += '</div>';

  // Footer
  html += '<div style="display:flex;gap:6px;flex-wrap:wrap">';
  html += '<a href="https://npiregistry.cms.hhs.gov/provider-view/' + encodeURIComponent(cluster.npi) + '" target="_blank" rel="noopener" style="font-size:11px;padding:5px 10px;border-radius:5px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none">Open NPPES ↗</a>';
  html += '<button class="dup-skip-btn" data-npi="' + esc(cluster.npi) + '" style="font-size:11px;padding:5px 10px;border:1px solid var(--border);border-radius:5px;background:var(--s2);color:var(--text3);cursor:pointer;margin-left:auto">Skip (review later)</button>';
  html += '</div>';
  html += '</div>';
  return html;
}

// ──────────────────────────────────────────────────────────────────────────
// Action wirers — Adopt, Flag, Dismiss, Unmappable, Dup Keep
// ──────────────────────────────────────────────────────────────────────────

async function _onNpiBulkLookup() {
  const btn = document.getElementById('npi-bulk-lookup-btn');
  if (!btn) return;
  btn.disabled = true;
  btn.textContent = 'Querying NPPES…';
  try {
    const res = await fetch('/api/npi-lookup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ all: true, max: 700 })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || data.detail || ('HTTP ' + res.status));
    showToast(`Scanned ${data.scanned}: ${data.auto_applied} auto-applied, ${data.too_ambiguous + data.low_confidence} ready for human review`, data.auto_applied > 0 ? 'success' : 'warn');
    diaNpiLookupCache = null;
    await loadDiaData();
    await loadNpiCleanupData();
    renderDiaTab();
  } catch (e) {
    btn.disabled = false;
    btn.textContent = 'Run NPPES lookup';
    showToast('Lookup failed: ' + e.message, 'error');
  }
}

function _wireNpiAdoptButtons() {
  document.querySelectorAll('.npi-adopt-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const clinicId = btn.dataset.clinicId;
      const npi = btn.dataset.npi;
      if (!clinicId || !npi) return;
      btn.disabled = true;
      const orig = btn.textContent;
      btn.textContent = '…';
      try {
        await applyManualChange({
          actor: (typeof LCC_USER !== 'undefined' && LCC_USER.display_name) || 'lcc_analyst',
          source_surface: 'dia_npi_adopt',
          target_table: 'medicare_clinics',
          target_source: 'dia',
          mutation_mode: 'update',
          record_identifier: clinicId,
          id_column: 'medicare_id',
          changed_fields: { npi: npi, updated_at: new Date().toISOString() },
          notes: 'NPI adopted from NPPES match via NPI Intel UI'
        });
        // Audit row in npi_registry_lookups
        await applyInsertWithFallback({
          proxyBase: '/api/dia-query',
          table: 'npi_registry_lookups',
          data: {
            clinic_id: clinicId,
            best_match_npi: npi,
            applied: true,
            apply_decision: 'manual_adopted',
            notes: 'User-confirmed NPPES match via NPI Intel UI'
          },
          source_surface: 'dia_npi_adopt'
        });
        // Local state: drop this missing-NPI signal, drop any new_npi signal pointing at it
        diaData.npiSignals = (diaData.npiSignals || []).filter(s =>
          !(s.signal_type === 'missing_inventory_npi' && s.clinic_id === clinicId) &&
          !(s.signal_type === 'new_npi' && s.clinic_id === clinicId)
        );
        showToast('NPI ' + npi + ' adopted', 'success');
        renderDiaTab();
      } catch(e) {
        btn.disabled = false;
        btn.textContent = orig;
        showToast('Adopt failed: ' + e.message, 'error');
      }
    });
  });
}

function _wireNpiUnmappableButtons() {
  document.querySelectorAll('.npi-unmappable-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const clinicId = btn.dataset.clinicId;
      if (!clinicId) return;
      if (!confirm('Mark this clinic as unmappable to NPPES? It will be hidden from the Missing NPI queue.')) return;
      btn.disabled = true; btn.textContent = '…';
      try {
        await applyInsertWithFallback({
          proxyBase: '/api/dia-query',
          table: 'npi_registry_lookups',
          data: {
            clinic_id: clinicId,
            applied: false,
            apply_decision: 'manual_unmappable',
            notes: 'User marked unmappable from NPI Intel UI'
          },
          source_surface: 'dia_npi_unmappable'
        });
        diaData.npiSignals = (diaData.npiSignals || []).filter(s =>
          !(s.signal_type === 'missing_inventory_npi' && s.clinic_id === clinicId)
        );
        showToast('Marked unmappable', 'success');
        renderDiaTab();
      } catch(e) {
        btn.disabled = false; btn.textContent = 'Mark unmappable';
        showToast('Failed: ' + e.message, 'error');
      }
    });
  });
}

function _wireDupClusterButtons() {
  // "Keep NPI here" — apply Phase 3 logic: keep NPI on chosen, clear on others in cluster
  document.querySelectorAll('.dup-keep-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const keepId = btn.dataset.keepId;
      const npi = btn.dataset.npi;
      if (!keepId || !npi) return;
      const cluster = (diaData.npiSignals || []).filter(r => r.signal_type === 'duplicate_inventory_npi' && r.npi === npi);
      const losers = cluster.filter(r => r.clinic_id !== keepId).map(r => r.clinic_id);
      if (losers.length === 0) return;
      if (!confirm(`Keep NPI ${npi} on CCN ${keepId} and clear from ${losers.length} other clinic${losers.length > 1 ? 's' : ''}?`)) return;
      btn.disabled = true; btn.textContent = '…';
      try {
        // Clear NPI on each loser
        for (const loser of losers) {
          await applyManualChange({
            actor: (typeof LCC_USER !== 'undefined' && LCC_USER.display_name) || 'lcc_analyst',
            source_surface: 'dia_npi_dup_resolve',
            target_table: 'medicare_clinics',
            target_source: 'dia',
            mutation_mode: 'update',
            record_identifier: loser,
            id_column: 'medicare_id',
            changed_fields: { npi: null, updated_at: new Date().toISOString() },
            notes: 'NPI duplicate-cluster resolution: kept on ' + keepId + ', cleared here'
          });
        }
        // Drop cluster from in-memory signals
        diaData.npiSignals = (diaData.npiSignals || []).filter(r =>
          !(r.signal_type === 'duplicate_inventory_npi' && r.npi === npi)
        );
        showToast(`Resolved ${losers.length + 1}-clinic cluster`, 'success');
        renderDiaTab();
      } catch(e) {
        btn.disabled = false; btn.textContent = 'Keep NPI here';
        showToast('Failed: ' + e.message, 'error');
      }
    });
  });
  // Skip — just hide for this session
  document.querySelectorAll('.dup-skip-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const npi = btn.dataset.npi;
      diaData.npiSignals = (diaData.npiSignals || []).filter(r =>
        !(r.signal_type === 'duplicate_inventory_npi' && r.npi === npi)
      );
      renderDiaTab();
    });
  });
}

function _wireNpiFlagDismissButtons() {
  document.querySelectorAll('.npi-flag-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const npiId = btn.dataset.npiId;
      const npiName = btn.dataset.npiName;
      if (!npiId) return;
      btn.disabled = true; btn.textContent = '…';
      try {
        await applyInsertWithFallback({
          proxyBase: '/api/dia-query',
          table: 'research_queue_outcomes',
          data: { medicare_id: npiId, outcome: 'flagged_for_review', notes: 'Flagged from NPI Intel BD events', created_at: new Date().toISOString() },
          source_surface: 'dia_npi_flag'
        });
        showToast('Flagged ' + (npiName || npiId), 'success');
        // Remove from local list so card disappears
        diaData.npiSignals = (diaData.npiSignals || []).filter(s =>
          !((s.npi || s.clinic_id || '') === npiId && NPI_PROVIDER_CHANGE_TYPES.has(s.signal_type))
        );
        renderDiaTab();
      } catch(e) {
        btn.disabled = false; btn.textContent = 'Flag for research';
        showToast('Flag failed: ' + e.message, 'error');
      }
    });
  });
  document.querySelectorAll('.npi-dismiss-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const npiId = btn.dataset.npiId;
      if (!npiId) return;
      btn.disabled = true; btn.textContent = '…';
      try {
        await applyInsertWithFallback({
          proxyBase: '/api/dia-query',
          table: 'research_queue_outcomes',
          data: { medicare_id: npiId, outcome: 'dismissed', notes: 'Dismissed from NPI Intel BD events', created_at: new Date().toISOString() },
          source_surface: 'dia_npi_dismiss'
        });
        diaData.npiSignals = (diaData.npiSignals || []).filter(s =>
          !((s.npi || s.clinic_id || '') === npiId && NPI_PROVIDER_CHANGE_TYPES.has(s.signal_type))
        );
        showToast('Dismissed', 'success');
        renderDiaTab();
      } catch(e) {
        btn.disabled = false; btn.textContent = 'Dismiss';
        showToast('Dismiss failed: ' + e.message, 'error');
      }
    });
  });
}

// ──────────────────────────────────────────────────────────────────────────
// NPI Intel — 3-mode dispatcher (Round 76ef)
//
// "BD Events"     — provider-change cards: closures, relocations, rebrand,
//                   official changes, new NPIs at known clinic addresses.
//                   This is what the user actually wants to see.
// "Cleanup"       — focused review of the residual data-hygiene tasks the
//                   auto-resolvers couldn't finish:
//                     - Missing NPI: clinic + NPPES candidates inline
//                     - Duplicate cluster: side-by-side compare vs NPPES truth
// "All Signals"   — legacy table view of the full matview output. Power-user.
// ──────────────────────────────────────────────────────────────────────────

// ============================================================================
// INVENTORY CHANGES TAB — Round 76eg
//
// CMS publishes a fresh inventory snapshot quarterly. v_clinic_inventory_latest_diff
// flags clinics that appeared (added) or disappeared (removed) since the prior
// snapshot. Each is BD-actionable:
//   • added   → potential new lease tenant; possibly already on a fresh lease
//                we could backfill from CoStar/county records
//   • removed → potential closure or operator change; touch the property to
//                check if it's coming to market
//
// The old "tab=changes preFilter=added" UX dumped the user on a 7,000-row CMS
// data table with a search box pre-filled. This tab replaces that with a
// focused card feed of just the 31 inventory changes, each with one-click
// research actions.
// ============================================================================

const INVENTORY_META = {
  added:   { icon: '🆕', color: '#34d399', label: 'New CMS Clinic',  bg: 'rgba(52,211,153,0.10)' },
  removed: { icon: '🚪', color: '#f87171', label: 'Dropped from CMS', bg: 'rgba(248,113,113,0.10)' },
};

function renderDiaInventoryChanges() {
  const all = (diaData.inventoryChanges || []).filter(r => !diaInventoryDismissed.has(r.clinic_id));
  const added = all.filter(r => r.change_type === 'added');
  const removed = all.filter(r => r.change_type === 'removed');

  let html = '<div class="biz-section">';

  // ─── Banner ──────────────────────────────────────────────────────────
  html += '<div style="padding:12px 16px;background:rgba(52,211,153,0.08);border-radius:8px;border-left:3px solid var(--accent);margin-bottom:14px;">';
  html += '<div style="font-weight:700;font-size:13px;margin-bottom:4px;color:var(--text)">CMS Inventory Changes</div>';
  html += '<div style="font-size:12px;color:var(--text2);line-height:1.5">Clinics that appeared in or dropped from the latest CMS Dialysis Compare snapshot. <strong>New clinics</strong> are potential lease prospects — confirm property linkage and backfill ownership data. <strong>Closures</strong> are potential disposition opportunities — confirm operating status and check property records for transactions.</div>';
  html += '</div>';

  // ─── Mode pills ──────────────────────────────────────────────────────
  const filterBtn = (key, label, count) => {
    const active = diaInventoryFilter === key;
    const badge = `<span style="font-size:10px;padding:1px 6px;border-radius:8px;background:${active ? 'rgba(255,255,255,0.25)' : 'var(--s3)'};color:${active ? '#fff' : 'var(--text2)'};margin-left:4px">${fmtN(count)}</span>`;
    return `<button data-inv-filter="${key}" style="font-size:12px;font-weight:600;padding:6px 12px;border-radius:6px;border:1px solid ${active ? 'var(--accent)' : 'var(--border)'};background:${active ? 'var(--accent)' : 'var(--s2)'};color:${active ? '#000' : 'var(--text2)'};cursor:pointer">${label}${badge}</button>`;
  };
  html += '<div style="display:flex;gap:6px;margin-bottom:14px;align-items:center">';
  html += filterBtn('all', 'All', added.length + removed.length);
  html += filterBtn('added', 'New clinics', added.length);
  html += filterBtn('removed', 'Closures', removed.length);
  html += '</div>';

  // ─── Filter + sort ───────────────────────────────────────────────────
  let visible = all;
  if (diaInventoryFilter === 'added') visible = added;
  else if (diaInventoryFilter === 'removed') visible = removed;
  visible = visible.slice().sort((a, b) => {
    // Big clinics first (by patients), then by chairs, then by certification date
    const pa = a.latest_total_patients || a.prior_total_patients || 0;
    const pb = b.latest_total_patients || b.prior_total_patients || 0;
    if (pa !== pb) return pb - pa;
    return (b.number_of_chairs || 0) - (a.number_of_chairs || 0);
  });

  if (visible.length === 0) {
    html += '<div style="padding:48px;text-align:center;color:var(--text3);background:var(--s2);border-radius:8px">';
    html += '<div style="font-size:32px;margin-bottom:8px">📋</div>';
    html += '<div style="font-size:14px;font-weight:600;color:var(--text2)">No inventory changes detected</div>';
    html += '<div style="font-size:12px;margin-top:4px">CMS publishes new snapshots quarterly — check back after the next refresh.</div>';
    html += '</div>';
    html += '</div>';
    return html;
  }

  // ─── Card list ───────────────────────────────────────────────────────
  const _icWin = _diaWindowGet('inventoryChanges');
  const _icShown = Math.min(_icWin, visible.length);
  html += '<div style="display:flex;flex-direction:column;gap:10px">';
  for (const row of visible.slice(0, _icShown)) {
    html += _renderInventoryChangeCard(row);
  }
  html += '</div>';
  html += _diaWindowFooter('inventoryChanges', _icShown, visible.length, 100);

  html += '</div>'; // biz-section

  // ─── Wire handlers ───────────────────────────────────────────────────
  setTimeout(() => {
    document.querySelectorAll('[data-inv-filter]').forEach(btn => {
      btn.addEventListener('click', () => {
        diaInventoryFilter = btn.dataset.invFilter;
        _diaWindowReset('inventoryChanges');
        renderDiaTab();
      });
    });
    _wireInventoryActionButtons();
  }, 0);

  return html;
}

function _renderInventoryChangeCard(row) {
  const meta = INVENTORY_META[row.change_type] || { icon: '•', color: 'var(--text2)', label: row.change_type, bg: 'var(--s2)' };
  const isAdded = row.change_type === 'added';
  const facilityName = norm(row.facility_name) || 'Unknown';
  const addrLine = (row.address || '') + (row.city ? ', ' + row.city : '') + (row.state ? ' ' + row.state : '');
  const patientCount = isAdded ? row.latest_total_patients : row.prior_total_patients;
  const chairs = row.number_of_chairs;
  const dateLabel = isAdded ? 'CMS-certified' : 'Last seen';
  const dateValue = isAdded
    ? (row.certification_date ? new Date(row.certification_date).toLocaleDateString() : '—')
    : (row.prior_snapshot_date ? new Date(row.prior_snapshot_date).toLocaleDateString() : '—');

  // BD priority hint: large clinic + independent operator = highest BD value
  const isBigOpportunity = (patientCount || 0) >= 50 && (row.operator_name === 'Independent' || row.parent_organization === null);

  let html = '';
  html += '<div style="border:1px solid var(--border);border-left:3px solid ' + meta.color + ';border-radius:10px;padding:14px 16px;background:var(--s1)">';

  // Top row: icon + identity
  html += '<div style="display:flex;align-items:flex-start;gap:12px;margin-bottom:10px">';
  html += '<div style="font-size:24px;flex-shrink:0;line-height:1">' + meta.icon + '</div>';
  html += '<div style="flex:1;min-width:0">';
  html += '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:2px">';
  html += '<span style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.6px;padding:2px 8px;border-radius:8px;background:' + meta.bg + ';color:' + meta.color + '">' + meta.label + '</span>';
  if (isBigOpportunity) {
    html += '<span style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.6px;padding:2px 8px;border-radius:8px;background:rgba(251,191,36,0.15);color:#fbbf24">★ High BD value</span>';
  }
  html += '</div>';
  html += '<h4 style="margin:0;font-size:14px;font-weight:700;color:var(--text);overflow-wrap:anywhere">' + esc(facilityName) + '</h4>';
  html += '<div style="font-size:12px;color:var(--text2);margin-top:2px">' + esc(addrLine) + '</div>';
  html += '</div>';
  html += '</div>';

  // Stats grid
  html += '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:10px;font-size:11px">';
  const _fact = (lbl, val) => '<div style="background:var(--s2);padding:6px 8px;border-radius:5px"><div style="color:var(--text3);font-size:9px;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:1px">' + lbl + '</div><div style="font-weight:600;color:var(--text);overflow-wrap:anywhere">' + val + '</div></div>';
  html += _fact('Operator', esc(row.operator_name || row.parent_organization || 'Independent'));
  html += _fact('Patients', patientCount != null ? fmtN(patientCount) : '—');
  html += _fact('Chairs', chairs != null ? fmtN(chairs) : '—');
  html += _fact(dateLabel, dateValue);
  html += '</div>';

  // Row identifiers (CCN, NPI)
  html += '<div style="font-size:10px;color:var(--text3);margin-bottom:10px;font-family:monospace">CCN ' + esc(row.clinic_id) + (row.medicare_npi ? ' · NPI ' + esc(row.medicare_npi) : ' · No NPI') + '</div>';

  // Actions
  html += '<div style="display:flex;gap:6px;flex-wrap:wrap">';
  html += '<button class="btn-action default" style="font-size:11px;padding:6px 12px" onclick=\'showDetail(' + safeJSON(row) + ',"dia-clinic")\'>Open property research</button>';
  if (row.medicare_npi) {
    html += '<a href="https://npiregistry.cms.hhs.gov/provider-view/' + encodeURIComponent(row.medicare_npi) + '" target="_blank" rel="noopener" style="font-size:11px;padding:6px 12px;border-radius:6px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none">NPPES ↗</a>';
  }
  const searchQ = (row.facility_name || '') + ' ' + (row.city || '') + ' ' + (row.state || '') + (isAdded ? ' lease' : ' closure');
  html += '<a href="https://www.google.com/search?q=' + encodeURIComponent(searchQ.trim()) + '" target="_blank" rel="noopener" style="font-size:11px;padding:6px 12px;border-radius:6px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none">Google ↗</a>';
  html += '<button class="inv-flag-btn" data-clinic-id="' + esc(row.clinic_id) + '" data-name="' + esc(facilityName) + '" data-change="' + esc(row.change_type) + '" style="font-size:11px;padding:6px 12px;border:1px solid var(--accent);border-radius:6px;background:rgba(52,211,153,0.1);color:var(--accent);cursor:pointer;font-weight:600">Flag for research</button>';
  html += '<button class="inv-dismiss-btn" data-clinic-id="' + esc(row.clinic_id) + '" style="font-size:11px;padding:6px 12px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text3);cursor:pointer;margin-left:auto">Dismiss</button>';
  html += '</div>';

  html += '</div>';
  return html;
}

function _wireInventoryActionButtons() {
  document.querySelectorAll('.inv-flag-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const clinicId = btn.dataset.clinicId;
      const name = btn.dataset.name;
      const change = btn.dataset.change;
      if (!clinicId) return;
      btn.disabled = true; btn.textContent = '…';
      try {
        await applyInsertWithFallback({
          proxyBase: '/api/dia-query',
          table: 'research_queue_outcomes',
          data: {
            medicare_id: clinicId,
            outcome: 'flagged_for_review',
            notes: 'Flagged from Inventory Changes tab — ' + change,
            created_at: new Date().toISOString()
          },
          source_surface: 'dia_inventory_flag'
        });
        diaInventoryDismissed.add(clinicId);
        showToast('Flagged ' + (name || clinicId), 'success');
        renderDiaTab();
      } catch(e) {
        btn.disabled = false; btn.textContent = 'Flag for research';
        showToast('Flag failed: ' + e.message, 'error');
      }
    });
  });

  document.querySelectorAll('.inv-dismiss-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const clinicId = btn.dataset.clinicId;
      if (!clinicId) return;
      btn.disabled = true; btn.textContent = '…';
      try {
        await applyInsertWithFallback({
          proxyBase: '/api/dia-query',
          table: 'research_queue_outcomes',
          data: {
            medicare_id: clinicId,
            outcome: 'dismissed',
            notes: 'Dismissed from Inventory Changes tab',
            created_at: new Date().toISOString()
          },
          source_surface: 'dia_inventory_dismiss'
        });
        diaInventoryDismissed.add(clinicId);
        renderDiaTab();
      } catch(e) {
        btn.disabled = false; btn.textContent = 'Dismiss';
        showToast('Dismiss failed: ' + e.message, 'error');
      }
    });
  });
}

function renderDiaNpi() {
  const allSignals = (diaData.npiSignals || []).map(r => ({
    ...r,
    _sev: _npiSeverityKey(r),
    _key: _npiRowKey(r)
  }));

  let html = '<div class="biz-section">';

  // ─── Mode segmented control ──────────────────────────────────────────
  const bdRows      = allSignals.filter(r => NPI_PROVIDER_CHANGE_TYPES.has(r.signal_type));
  const missingRows = allSignals.filter(r => r.signal_type === 'missing_inventory_npi');
  const dupRows     = allSignals.filter(r => r.signal_type === 'duplicate_inventory_npi' && r._sev !== 'auto_resolvable');
  const dupClusterCount = new Set(dupRows.map(r => r.npi)).size;

  const modeBtn = (key, label, count) => {
    const active = diaNpiMode === key;
    const countBadge = count > 0 ? ` <span style="font-size:10px;padding:1px 6px;border-radius:8px;background:${active ? 'rgba(255,255,255,0.25)' : 'var(--s3)'};color:${active ? '#fff' : 'var(--text2)'};margin-left:4px">${fmtN(count)}</span>` : '';
    return `<button data-npi-mode="${key}" style="font-size:13px;font-weight:600;padding:8px 16px;border:none;border-bottom:2px solid ${active ? 'var(--accent)' : 'transparent'};background:transparent;color:${active ? 'var(--text)' : 'var(--text2)'};cursor:pointer">${label}${countBadge}</button>`;
  };
  html += '<div style="display:flex;gap:4px;border-bottom:1px solid var(--border);margin-bottom:16px">';
  html += modeBtn('bd', 'BD Events', bdRows.length);
  html += modeBtn('cleanup', 'Cleanup Queue', missingRows.length + dupClusterCount);
  html += modeBtn('all', 'All Signals', allSignals.length);
  html += '</div>';

  // ─── Mode body ───────────────────────────────────────────────────────
  if (diaNpiMode === 'bd') {
    html += _renderNpiBdEvents(bdRows);
  } else if (diaNpiMode === 'cleanup') {
    html += _renderNpiCleanup(missingRows, dupRows);
  } else {
    html += _renderNpiAllSignals(allSignals);
  }

  html += '</div>';

  // Mode switcher
  setTimeout(() => {
    document.querySelectorAll('[data-npi-mode]').forEach(btn => {
      btn.addEventListener('click', () => {
        diaNpiMode = btn.dataset.npiMode;
        diaNpiSelectedIdx = undefined;
        _diaWindowReset('allSignals');
        _diaWindowReset('bdEvents');
        _diaWindowReset('cleanupMissing');
        _diaWindowReset('cleanupDup');
        renderDiaTab();
        // Lazy-load cleanup data on first entry
        if (diaNpiMode === 'cleanup' && !diaNpiCleanupLoading && (!diaNpiLookupCache || !diaNpiRegistryCache)) {
          loadNpiCleanupData().then(() => renderDiaTab());
        }
      });
    });
  }, 0);

  return html;
}

// Lazy-loader for Cleanup mode data — fetches latest NPPES lookup candidates
// per clinic and the npi_registry rows for any NPIs in dup clusters.
async function loadNpiCleanupData() {
  diaNpiCleanupLoading = true;
  try {
    // 1. Latest lookup per clinic (with raw_response candidates)
    const lookups = await diaQuery('npi_registry_lookups',
      'clinic_id,queried_at,result_count,best_match_npi,best_match_score,best_match_org,applied,apply_decision,raw_response,query_org_name,query_city,query_state',
      { order: 'queried_at.desc', limit: 2000 }
    ).catch(() => []);
    const lookupMap = new Map();
    for (const l of lookups) {
      // Keep only latest per clinic (rows already ordered by queried_at desc)
      if (!lookupMap.has(l.clinic_id)) lookupMap.set(l.clinic_id, l);
    }
    diaNpiLookupCache = lookupMap;

    // 2. NPPES registry rows for NPIs in current dup clusters
    const dupNpis = Array.from(new Set(
      (diaData.npiSignals || [])
        .filter(r => r.signal_type === 'duplicate_inventory_npi' && r.npi)
        .map(r => r.npi)
    ));
    if (dupNpis.length > 0) {
      // PostgREST IN list — chunk if very large
      const regCache = new Map();
      for (let i = 0; i < dupNpis.length; i += 200) {
        const chunk = dupNpis.slice(i, i + 200);
        const rows = await diaQuery('npi_registry',
          'npi,organization_name,npi_status,npi_address,npi_city,npi_state,npi_zip,is_esrd_taxonomy,authorized_official,updated_at',
          { filter: 'npi=in.(' + chunk.join(',') + ')', limit: 1000 }
        ).catch(() => []);
        for (const r of rows) regCache.set(r.npi, r);
      }
      diaNpiRegistryCache = regCache;
    } else {
      diaNpiRegistryCache = new Map();
    }
  } finally {
    diaNpiCleanupLoading = false;
  }
}

// Legacy all-signals view body — extracted from the original renderDiaNpi
// so the new mode dispatcher can call it. Same UX as before.
function _renderNpiAllSignals(allSignals) {
  let html = '';

  // Filter by severity bucket (default 'actionable' = everything except auto_resolvable)
  let visible = allSignals;
  if (diaNpiSeverityFilter === 'actionable') {
    visible = allSignals.filter(r => r._sev !== 'auto_resolvable');
  } else if (diaNpiSeverityFilter !== 'all') {
    visible = allSignals.filter(r => r._sev === diaNpiSeverityFilter);
  }
  // Then by signal_type pill (if user picked one)
  if (diaNpiFilter && diaNpiFilter !== 'all') {
    visible = visible.filter(r => r.signal_type === diaNpiFilter);
  }
  // Sort: priority asc, then patients desc
  visible.sort((a, b) => {
    const pa = a.signal_priority || 5;
    const pb = b.signal_priority || 5;
    if (pa !== pb) return pa - pb;
    return (b.latest_total_patients || 0) - (a.latest_total_patients || 0);
  });

  // ─── Severity-aware action banner + NPPES auto-fill action ──────────
  // Count missing-NPI rows from the loaded summary so the auto-fill button
  // shows an accurate target count even when the user has filtered to a
  // different severity bucket.
  const missingNpiCount = ((diaData.npiSummary || {}).missing_inventory_npi || {}).signal_count || 0;
  html += '<div style="padding:12px 16px;background:rgba(251,191,36,0.08);border-radius:8px;border-left:3px solid #fbbf24;margin-bottom:16px;">';
  html += '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px">';
  html += '<div style="flex:1;min-width:0">';
  html += '<div style="font-weight:700;font-size:13px;margin-bottom:4px;color:var(--text)">NPI Intelligence Signals</div>';
  html += '<div style="font-size:12px;color:var(--text2);line-height:1.5">' + _npiBannerText(visible) + '</div>';
  html += '</div>';
  if (missingNpiCount > 0) {
    html += '<button id="npi-autofill-btn" style="font-size:11px;padding:6px 12px;border:1px solid #22d3ee;border-radius:6px;background:rgba(34,211,238,0.1);color:#22d3ee;cursor:pointer;font-weight:600;flex-shrink:0;white-space:nowrap" title="Query NPPES live API for the ' + fmtN(missingNpiCount) + ' active clinics with no NPI; auto-write high-confidence matches.">Auto-fill ' + fmtN(missingNpiCount) + ' missing NPIs</button>';
  }
  html += '</div></div>';

  // ─── Severity-bucket counts (from matview summary view) ──────────────
  const summary = diaData.npiSummary || {};
  const totalAll = Object.values(summary).reduce((s, r) => s + (r.signal_count || 0), 0);
  const autoCnt  = Object.values(summary).reduce((s, r) => s + (r.auto_resolvable_count || 0), 0);
  const errCnt   = Object.values(summary).reduce((s, r) => s + (r.data_error_count || 0), 0);
  const dqCnt    = Object.values(summary).reduce((s, r) => s + (r.data_quality_count || 0), 0);
  const missCnt  = (summary.missing_inventory_npi && summary.missing_inventory_npi.signal_count) || 0;
  const actionableCnt = totalAll - autoCnt;

  html += '<div class="gov-metrics">';
  html += metricHTML('Actionable', fmtN(actionableCnt), 'need human review', '');
  html += metricHTML('Likely Typos', fmtN(errCnt), 'wrong NPI somewhere', '');
  html += metricHTML('Multi-Loc Review', fmtN(dqCnt), 'same operator, diff addr', '');
  html += metricHTML('Missing NPI', fmtN(missCnt), 'clinic record, no NPI', '');
  html += metricHTML('Auto-Resolved', fmtN(autoCnt), 'hidden by default', '');
  html += '</div>';

  // ─── Severity filter pills (primary control) ─────────────────────────
  const sevPill = (key, label) => {
    const active = diaNpiSeverityFilter === key ? ' active' : '';
    return `<button class="pill${active}" data-sev-filter="${key}">${label}</button>`;
  };
  html += '<div class="pills" style="margin: 16px 0 8px;">';
  html += sevPill('actionable', 'Actionable (default)');
  html += sevPill('provider_change', 'Provider Changes');
  html += sevPill('data_error', 'Likely Typos');
  html += sevPill('data_quality', 'Multi-Loc Review');
  html += sevPill('missing', 'Missing NPI');
  html += sevPill('unresolved', 'Auto-Pending');
  html += sevPill('auto_resolvable', 'Auto-Resolved');
  html += sevPill('all', 'All');
  html += '</div>';

  // ─── Bulk action bar (visible when rows are selected) ────────────────
  if (diaNpiSelectedIds.size > 0) {
    html += '<div style="display:flex;align-items:center;gap:8px;padding:8px 12px;margin-bottom:8px;background:rgba(251,191,36,0.08);border-radius:6px;border:1px solid #fbbf24;">';
    html += '<span style="font-size:12px;font-weight:600;color:var(--text)">' + diaNpiSelectedIds.size + ' selected</span>';
    html += '<button class="btn-action" id="npi-bulk-flag" style="font-size:11px;padding:4px 10px;border:1px solid var(--accent);border-radius:5px;background:rgba(52,211,153,0.1);color:var(--accent);cursor:pointer;font-weight:600">Flag all for research</button>';
    html += '<button class="btn-action" id="npi-bulk-dismiss" style="font-size:11px;padding:4px 10px;border:1px solid #f87171;border-radius:5px;background:rgba(248,113,113,0.1);color:#f87171;cursor:pointer;font-weight:600">Dismiss all</button>';
    html += '<button id="npi-bulk-clear" style="font-size:11px;padding:4px 10px;margin-left:auto;border:1px solid var(--border);border-radius:5px;background:var(--s2);color:var(--text2);cursor:pointer">Clear selection</button>';
    html += '</div>';
  }

  // ─── Two-column layout: table (left) + drawer (right) ────────────────
  const drawerOpen = diaNpiSelectedIdx !== undefined && visible[diaNpiSelectedIdx];
  html += '<div style="display:grid;grid-template-columns:' + (drawerOpen ? '1fr 380px' : '1fr') + ';gap:12px;align-items:flex-start">';

  // === LEFT: signals table ===
  html += '<div class="table-wrapper" style="min-width:0">';
  html += '<div class="data-table">';

  if (visible.length === 0) {
    html += '<div class="table-empty">No signals match the current filter</div>';
  } else {
    const allSelected = visible.length > 0 && visible.every(r => diaNpiSelectedIds.has(r._key));
    html += '<div class="table-row" style="font-weight: 600; border-bottom: 1px solid var(--border);">';
    html += `<div style="flex: 0 0 32px"><input type="checkbox" id="npi-select-all" ${allSelected ? 'checked' : ''} title="Select visible"></div>`;
    html += '<div style="flex: 1.4;">Severity</div>';
    html += '<div style="flex: 2.2;">Facility</div>';
    html += '<div style="flex: 1;">City</div>';
    html += '<div style="flex: 0 0 40px;">St</div>';
    html += '<div style="flex: 1.5;">Operator</div>';
    html += '<div style="flex: 0 0 70px; text-align: right;">Pts</div>';
    html += '<div style="flex: 0 0 90px; text-align: center;">NPI</div>';
    html += '</div>';

    const _asWin = _diaWindowGet('allSignals');
    const _asShown = Math.min(_asWin, visible.length);
    visible.slice(0, _asShown).forEach((row, idx) => {
      const meta = NPI_SEVERITY_META[row._sev] || NPI_SEVERITY_META.unresolved;
      const isSelected = diaNpiSelectedIdx === idx;
      const isChecked = diaNpiSelectedIds.has(row._key);

      html += `<div class="table-row clickable-row" data-npi-row-idx="${idx}" style="cursor:pointer;${isSelected ? 'background:rgba(251,191,36,0.1);border-left:3px solid #fbbf24;' : ''}">`;
      html += `<div style="flex: 0 0 32px" onclick="event.stopPropagation();"><input type="checkbox" class="npi-row-cb" data-row-key="${esc(row._key)}" ${isChecked ? 'checked' : ''}></div>`;
      html += `<div style="flex: 1.4;"><span style="display:inline-block;padding:2px 8px;border-radius:10px;background:${meta.bg};color:${meta.color};font-size:10px;font-weight:700">${meta.label}</span></div>`;
      html += `<div style="flex: 2.2;" class="truncate">${esc(norm(row.facility_name) || '')}${row.cluster_size > 1 ? ` <span style="color:var(--text3);font-size:10px">(×${row.cluster_size})</span>` : ''}</div>`;
      html += `<div style="flex: 1;">${esc(norm(row.city) || '')}</div>`;
      html += `<div style="flex: 0 0 40px;">${esc(row.state || '')}</div>`;
      html += `<div style="flex: 1.5;" class="truncate">${row.operator_name ? entityLink(row.operator_name, 'operator', null) : '<span style="color:var(--text3)">—</span>'}</div>`;
      html += `<div style="flex: 0 0 70px; text-align: right; color: var(--accent);">${fmtN(row.latest_total_patients || 0)}</div>`;
      html += `<div style="flex: 0 0 90px; text-align: center; font-family: monospace; font-size: 11px; color: var(--text2);">${esc(row.npi || '—')}</div>`;
      html += '</div>';
    });
    html += _diaWindowFooter('allSignals', _asShown, visible.length, 100);
  }
  html += '</div></div>';

  // === RIGHT: side drawer (only when row selected) ===
  if (drawerOpen) {
    const sel = visible[diaNpiSelectedIdx];
    const meta = NPI_SEVERITY_META[sel._sev] || NPI_SEVERITY_META.unresolved;
    const npiId = sel.npi || sel.clinic_id || '';
    const searchQ = (sel.facility_name || '') + ' ' + (sel.city || '') + ' ' + (sel.state || '') + ' NPI ' + (sel.npi || '');

    html += '<div style="position:sticky;top:12px;border:1px solid ' + meta.color + ';border-radius:12px;padding:14px 16px;background:var(--s1);max-height:calc(100vh - 80px);overflow-y:auto">';
    // Header + close
    html += '<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px">';
    html += '<div style="min-width:0;flex:1">';
    html += '<div style="display:inline-block;padding:2px 8px;border-radius:10px;background:' + meta.bg + ';color:' + meta.color + ';font-size:10px;font-weight:700;margin-bottom:4px">' + meta.label + '</div>';
    html += '<h3 style="margin:0;font-size:14px;font-weight:700;color:var(--text);overflow-wrap:anywhere">' + esc(norm(sel.facility_name) || 'Unknown') + '</h3>';
    html += '<div style="font-size:12px;color:var(--text2);margin-top:2px">' + esc((sel.city || '') + (sel.state ? ', ' + sel.state : '')) + '</div>';
    html += '</div>';
    html += '<button id="npi-drawer-close" style="font-size:11px;padding:4px 10px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text2);cursor:pointer;flex-shrink:0;margin-left:8px">Close</button>';
    html += '</div>';

    // Why this signal — pulled from matview signal_reason column
    html += '<div style="padding:10px 12px;background:' + meta.bg + ';border-radius:8px;border-left:3px solid ' + meta.color + ';margin-bottom:12px;">';
    html += '<div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:var(--text2);margin-bottom:4px">Why you\'re seeing this</div>';
    html += '<div style="font-size:12px;color:var(--text);line-height:1.5">' + esc(sel.signal_reason || '') + '</div>';
    html += '</div>';

    // Context grid
    const _nv = (lbl, val) => '<div style="background:var(--s2);padding:8px;border-radius:6px"><div style="color:var(--text3);font-size:9px;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:2px">' + lbl + '</div><div style="font-weight:600;color:var(--text);font-size:12px;overflow-wrap:anywhere">' + val + '</div></div>';
    html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:12px">';
    html += _nv('Operator', esc(sel.operator_name || '—'));
    html += _nv('Patients', fmtN(sel.latest_total_patients || 0));
    html += _nv('NPI', esc(String(sel.npi || '—')));
    html += _nv('Clinic ID', esc(String(sel.clinic_id || '—')));
    if (sel.cluster_size > 1) {
      html += _nv('Cluster Size', fmtN(sel.cluster_size) + ' rows');
      html += _nv('Same Address?', sel.same_address_in_cluster ? 'Yes' : 'No');
    }
    if (sel.last_seen_date) html += _nv('Last Seen', new Date(sel.last_seen_date).toLocaleDateString());
    if (sel.cluster_winner_medicare_id && sel.cluster_winner_medicare_id !== sel.clinic_id) {
      html += _nv('Winner CCN', esc(String(sel.cluster_winner_medicare_id)));
    }
    html += '</div>';

    // Actions — stacked vertically in the drawer
    html += '<div style="display:flex;flex-direction:column;gap:6px">';
    html += '<a href="https://npiregistry.cms.hhs.gov/provider-view/' + encodeURIComponent(sel.npi || '') + '" target="_blank" rel="noopener" style="font-size:11px;padding:6px 12px;border-radius:6px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none;text-align:center">Open in NPI Registry ↗</a>';
    html += '<a href="https://www.google.com/search?q=' + encodeURIComponent(searchQ.trim()) + '" target="_blank" rel="noopener" style="font-size:11px;padding:6px 12px;border-radius:6px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none;text-align:center">Google search ↗</a>';
    html += '<button class="btn-action default" style="font-size:11px;padding:6px 12px;" onclick=\'showDetail(' + safeJSON(sel) + ',"dia-clinic")\'>Open full clinic detail</button>';
    html += '<button class="npi-flag-btn" data-npi-id="' + esc(npiId) + '" data-npi-name="' + esc(sel.facility_name || '') + '" style="font-size:11px;padding:6px 12px;border:1px solid var(--accent);border-radius:6px;background:rgba(52,211,153,0.1);color:var(--accent);cursor:pointer;font-weight:600">Flag for Research</button>';
    html += '<button class="npi-dismiss-btn" data-npi-id="' + esc(npiId) + '" style="font-size:11px;padding:6px 12px;border:1px solid #f87171;border-radius:6px;background:rgba(248,113,113,0.1);color:#f87171;cursor:pointer;font-weight:600">Dismiss Signal</button>';
    html += '</div>';
    html += '</div>';
  }

  html += '</div>';  // end grid (biz-section close handled by dispatcher)

  // ─── Event handlers ─────────────────────────────────────────────────
  setTimeout(() => {
    // Severity pill
    document.querySelectorAll('[data-sev-filter]').forEach(btn => {
      btn.addEventListener('click', e => {
        diaNpiSeverityFilter = e.currentTarget.dataset.sevFilter;
        diaNpiSelectedIdx = undefined;
        _diaWindowReset('allSignals');
        renderDiaTab();
      });
    });
    // Auto-fill missing NPIs via NPPES live API
    const autofillBtn = document.getElementById('npi-autofill-btn');
    if (autofillBtn) {
      autofillBtn.addEventListener('click', async () => {
        if (!confirm('Query the NPPES registry for ' + fmtN(missingNpiCount) + ' clinics?\n\nHigh-confidence matches (≥0.9) will be auto-written. Medium-confidence matches (0.6–0.9) will be queued for human review. May take 30–90 seconds.')) return;
        autofillBtn.disabled = true;
        const originalText = autofillBtn.textContent;
        autofillBtn.textContent = 'Querying NPPES…';
        try {
          const res = await fetch('/api/npi-lookup', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ all: true, max: 700 })
          });
          const data = await res.json().catch(() => ({}));
          if (!res.ok) {
            throw new Error(data.error || data.detail || ('HTTP ' + res.status));
          }
          const msg = `Scanned ${data.scanned}: ${data.auto_applied} auto-applied, ${data.too_ambiguous + data.low_confidence} queued for review, ${data.no_match} no match` + (data.errors ? `, ${data.errors} errors` : '');
          showToast(msg, data.auto_applied > 0 ? 'success' : 'warn');
          // Reload NPI summary + signals so the screen reflects new state
          await loadDiaData();
          renderDiaTab();
        } catch(e) {
          showToast('Auto-fill failed: ' + e.message, 'error');
          autofillBtn.disabled = false;
          autofillBtn.textContent = originalText;
        }
      });
    }
    // Row click → drawer
    document.querySelectorAll('[data-npi-row-idx]').forEach(el => {
      el.addEventListener('click', () => {
        const idx = parseInt(el.dataset.npiRowIdx, 10);
        diaNpiSelectedIdx = diaNpiSelectedIdx === idx ? undefined : idx;
        renderDiaTab();
      });
    });
    // Drawer close
    const closeBtn = document.getElementById('npi-drawer-close');
    if (closeBtn) closeBtn.addEventListener('click', () => { diaNpiSelectedIdx = undefined; renderDiaTab(); });

    // Per-row checkbox
    document.querySelectorAll('.npi-row-cb').forEach(cb => {
      cb.addEventListener('change', e => {
        const k = e.target.dataset.rowKey;
        if (e.target.checked) diaNpiSelectedIds.add(k); else diaNpiSelectedIds.delete(k);
        renderDiaTab();
      });
    });
    // Select all
    const selAll = document.getElementById('npi-select-all');
    if (selAll) selAll.addEventListener('change', e => {
      if (e.target.checked) visible.forEach(r => diaNpiSelectedIds.add(r._key));
      else visible.forEach(r => diaNpiSelectedIds.delete(r._key));
      renderDiaTab();
    });
    // Bulk clear
    const clr = document.getElementById('npi-bulk-clear');
    if (clr) clr.addEventListener('click', () => { diaNpiSelectedIds.clear(); renderDiaTab(); });

    // Bulk flag / dismiss
    const bulkAct = async (kind) => {
      const ids = Array.from(diaNpiSelectedIds);
      if (ids.length === 0) return;
      const confirmMsg = `${kind === 'flag' ? 'Flag' : 'Dismiss'} ${ids.length} selected signal${ids.length > 1 ? 's' : ''}?`;
      if (!confirm(confirmMsg)) return;
      let ok = 0, fail = 0;
      for (const k of ids) {
        const row = allSignals.find(r => r._key === k);
        if (!row) continue;
        const npiId = row.npi || row.clinic_id || '';
        try {
          await applyInsertWithFallback({
            proxyBase: '/api/dia-query',
            table: 'research_queue_outcomes',
            data: {
              medicare_id: npiId,
              outcome: kind === 'flag' ? 'flagged_for_review' : 'dismissed',
              notes: (kind === 'flag' ? 'Bulk flagged' : 'Bulk dismissed') + ' from NPI signals tab',
              created_at: new Date().toISOString()
            },
            source_surface: 'dia_npi_bulk_' + kind
          });
          if (kind === 'dismiss') {
            const i = diaData.npiSignals.findIndex(s => _npiRowKey(s) === k);
            if (i >= 0) diaData.npiSignals.splice(i, 1);
          }
          ok++;
        } catch(e) { fail++; }
      }
      diaNpiSelectedIds.clear();
      showToast(`${ok} ${kind === 'flag' ? 'flagged' : 'dismissed'}` + (fail ? `, ${fail} failed` : ''), fail ? 'warn' : 'success');
      renderDiaTab();
    };
    const bf = document.getElementById('npi-bulk-flag');
    if (bf) bf.addEventListener('click', () => bulkAct('flag'));
    const bd = document.getElementById('npi-bulk-dismiss');
    if (bd) bd.addEventListener('click', () => bulkAct('dismiss'));

    // Single-row Flag / Dismiss (in drawer)
    document.querySelectorAll('.npi-flag-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const npiId = btn.dataset.npiId;
        const npiName = btn.dataset.npiName;
        if (!npiId) return;
        btn.disabled = true; btn.textContent = '...';
        try {
          await applyInsertWithFallback({
            proxyBase: '/api/dia-query',
            table: 'research_queue_outcomes',
            data: {
              medicare_id: npiId,
              outcome: 'flagged_for_review',
              notes: 'Flagged from NPI signals tab',
              created_at: new Date().toISOString()
            },
            source_surface: 'dia_npi_flag'
          });
          showToast('Flagged ' + (npiName || npiId) + ' for review', 'success');
          diaNpiSelectedIdx = undefined;
          renderDiaTab();
        } catch(e) {
          btn.disabled = false; btn.textContent = 'Flag for Research';
          showToast('Flag failed: ' + e.message, 'error');
        }
      });
    });
    document.querySelectorAll('.npi-dismiss-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const npiId = btn.dataset.npiId;
        if (!npiId) return;
        btn.disabled = true; btn.textContent = '...';
        try {
          await applyInsertWithFallback({
            proxyBase: '/api/dia-query',
            table: 'research_queue_outcomes',
            data: {
              medicare_id: npiId,
              outcome: 'dismissed',
              notes: 'Dismissed from NPI signals tab',
              created_at: new Date().toISOString()
            },
            source_surface: 'dia_npi_dismiss'
          });
          const idx = diaData.npiSignals.findIndex(s => (s.npi || s.clinic_id || s.id || '') === npiId);
          if (idx >= 0) diaData.npiSignals.splice(idx, 1);
          showToast('Signal dismissed', 'success');
          diaNpiSelectedIdx = undefined;
          renderDiaTab();
        } catch(e) {
          btn.disabled = false; btn.textContent = 'Dismiss Signal';
          showToast('Dismiss failed: ' + e.message, 'error');
        }
      });
    });
  }, 0);

  return html;
}

// ============================================================================
// RESEARCH UI HELPERS — Shared by Dialysis & Government research tabs
// ============================================================================

/**
 * Render a field-level completeness indicator dot
 * @param {'verified'|'auto'|'missing'} state
 * @param {string} [source] - e.g., "CoStar", "GSA", "manual"
 * @returns {string} HTML
 */
function fieldInd(state, source) {
  const icons = { verified: '✓', auto: '?', missing: '○' };
  const tips = {
    verified: source ? `Verified (${source})` : 'Verified',
    auto: source ? `Auto-filled from ${source} — verify` : 'Auto-filled — needs verification',
    missing: 'Missing — manual input needed'
  };
  return `<span class="field-ind ${state}" title="${tips[state]}">${icons[state]}</span>`;
}

/**
 * Determine field state based on value and source
 * @param {*} value - current field value
 * @param {string} [source] - data source if auto-populated
 * @param {boolean} [humanVerified] - true if explicitly saved by user
 * @returns {'verified'|'auto'|'missing'}
 */
function fieldState(value, source, humanVerified) {
  if (humanVerified) return 'verified';
  if (value !== null && value !== undefined && value !== '' && value !== 0) {
    return source ? 'auto' : 'verified';
  }
  return 'missing';
}

/**
 * Compute completeness summary for a set of fields
 * @param {Array<{name: string, value: *, source?: string, required?: boolean, verified?: boolean}>} fields
 * @returns {{pct: number, verified: number, auto: number, missing: number, missingRequired: string[], total: number}}
 */
function computeCompleteness(fields) {
  let verified = 0, auto = 0, missing = 0;
  const missingRequired = [];
  fields.forEach(f => {
    const st = fieldState(f.value, f.source, f.verified);
    if (st === 'verified') verified++;
    else if (st === 'auto') auto++;
    else {
      missing++;
      if (f.required) missingRequired.push(f.name);
    }
  });
  const total = fields.length;
  const filledCount = verified + auto;
  const pct = total > 0 ? Math.round((filledCount / total) * 100) : 100;
  return { pct, verified, auto, missing, missingRequired, total };
}

/**
 * Render completeness summary bar
 * @param {{pct: number, verified: number, auto: number, missing: number, missingRequired: string[]}} c
 * @returns {string} HTML
 */
function renderCompletenessBar(c) {
  const fillColor = c.pct >= 80 ? 'var(--green, #34d399)' : c.pct >= 50 ? '#fbbf24' : '#f87171';
  const badge = c.missing === 0 ? '<span class="task-badge ready">Ready</span>'
    : c.missingRequired.length > 0 ? '<span class="task-badge urgent">' + c.missingRequired.length + ' required</span>'
    : '<span class="task-badge needs-input">' + c.missing + ' optional</span>';

  let html = '<div class="completeness-bar">';
  html += `<div class="cb-score">${c.pct}%</div>`;
  html += `<div style="flex:1">`;
  html += `<div class="cb-meter"><div class="cb-fill" style="width:${c.pct}%;background:${fillColor}"></div></div>`;
  html += `<div class="cb-counts" style="margin-top:6px">`;
  if (c.missing > 0) html += `<span class="ct-miss">○ ${c.missing} missing</span>`;
  if (c.auto > 0) html += `<span class="ct-auto">? ${c.auto} verify</span>`;
  if (c.verified > 0) html += `<span class="ct-ok">✓ ${c.verified} confirmed</span>`;
  html += `</div></div>`;
  html += badge;
  html += '</div>';
  return html;
}

/**
 * Render step navigation dots
 * @param {number} current - 0-indexed current step
 * @param {Array<{label: string, complete: boolean}>} steps
 * @param {string} onClickFn - JS function name to call with step index
 * @returns {string} HTML
 */
function renderStepNav(current, steps, onClickFn) {
  let html = '<div class="step-nav">';
  steps.forEach((s, i) => {
    const cls = i === current ? 'current' : s.complete ? 'done' : '';
    html += `<div style="display:flex;flex-direction:column;align-items:center;">`;
    html += `<div class="step-dot ${cls}" onclick="${onClickFn}(${i})">${s.complete && i !== current ? '✓' : i + 1}</div>`;
    html += `<div class="step-label ${i === current ? 'current' : ''}">${s.label}</div>`;
    html += `</div>`;
  });
  html += '</div>';
  return html;
}

/**
 * Render a guided form field with indicator and optional source hint
 * @param {string} id - input element ID
 * @param {string} label - display label
 * @param {*} value - current value
 * @param {object} opts - { type, placeholder, source, required, verified, readonly, options }
 * @returns {string} HTML
 */
function guidedField(id, label, value, opts = {}) {
  const st = fieldState(value, opts.source, opts.verified);
  const ind = fieldInd(st, opts.source);
  const sourceHint = opts.source ? `<span class="field-source">via ${opts.source}</span>` : '';
  const reqMark = opts.required ? ' <span style="color:#f87171">*</span>' : '';

  let html = '<div class="form-group">';
  html += `<label>${esc(label)}${reqMark}${ind}${sourceHint}</label>`;

  if (opts.options) {
    // Select dropdown
    html += `<select id="${id}"${opts.readonly ? ' disabled' : ''}>`;
    html += `<option value="">Select...</option>`;
    opts.options.forEach(o => {
      const sel = (value === o.value || value === o.label) ? ' selected' : '';
      html += `<option value="${esc(o.value)}"${sel}>${esc(o.label)}</option>`;
    });
    html += '</select>';
  } else if (opts.type === 'textarea') {
    html += `<textarea id="${id}" placeholder="${esc(opts.placeholder || '')}"${opts.readonly ? ' readonly' : ''} rows="${opts.rows || 3}">${esc(value || '')}</textarea>`;
  } else if (opts.type === 'date') {
    html += `<input type="date" id="${id}" value="${value ? String(value).substring(0, 10) : ''}"${opts.readonly ? ' readonly' : ''}>`;
  } else {
    const inputType = opts.type || 'text';
    html += `<input type="${inputType}" id="${id}" value="${esc(value || '')}" placeholder="${esc(opts.placeholder || '')}"${opts.readonly ? ' readonly' : ''}${opts.step ? ' step="' + opts.step + '"' : ''}>`;
  }

  html += '</div>';
  return html;
}

// ============================================================================
// PIPELINE/OPS RESEARCH MODES — Data loading functions
// ============================================================================

/**
 * Load unmatched clinics queue (pending_updates where status='needs_match')
 */
async function loadDiaUnmatchedQueue() {
  if (diaUnmatchedLoading) return;
  diaUnmatchedLoading = true;
  try {
    const data = await diaQuery('v_pending_updates_workbench', '*', {
      filter: "status=eq.needs_match",
      order: "created_at.desc",
      limit: 1000
    });
    diaUnmatchedQueue = data || [];
  } catch(e) {
    console.error('loadDiaUnmatchedQueue error:', e);
    showToast('Unmatched queue load failed', 'error');
    diaUnmatchedQueue = [];
  }
  diaUnmatchedLoading = false;
  if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'dialysis') return;
  renderDiaTab();
}

/**
 * Load quarantine queue (medicare_ingest_quarantine)
 */
async function loadDiaQuarantineQueue() {
  if (diaQuarantineLoading) return;
  diaQuarantineLoading = true;
  try {
    const data = await diaQuery('medicare_ingest_quarantine', '*', {
      order: "ingested_at.desc",
      limit: 1000
    });
    diaQuarantineQueue = data || [];
  } catch(e) {
    console.error('loadDiaQuarantineQueue error:', e);
    showToast('Quarantine queue load failed', 'error');
    diaQuarantineQueue = [];
  }
  diaQuarantineLoading = false;
  if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'dialysis') return;
  renderDiaTab();
}

/**
 * Load clarification queue (pending_updates where status='needs_clarification')
 */
async function loadDiaClarificationQueue() {
  if (diaClarificationLoading) return;
  diaClarificationLoading = true;
  try {
    const data = await diaQuery('pending_updates', '*', {
      filter: "status=eq.needs_clarification",
      order: "created_at.desc",
      limit: 1000
    });
    diaClarificationQueue = data || [];
  } catch(e) {
    console.error('loadDiaClarificationQueue error:', e);
    showToast('Clarification queue load failed', 'error');
    diaClarificationQueue = [];
  }
  diaClarificationLoading = false;
  if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'dialysis') return;
  renderDiaTab();
}

/**
 * Load Ownership Research backlog from v_recorded_owner_canonical_clusters
 * (Layer H.2.a) and v_ownership_research_backlog (Layer H.1).
 *
 * Strategy: pull the canonical clusters view as the leverage list — every
 * row is one canonical entity with the count of recorded_owners variants
 * + total dialysis properties under that canonical. Sorted by total
 * properties DESC so the highest-leverage research targets surface first.
 *
 * The backlog view (v_ownership_research_backlog) also has per-property
 * detail, but for the worklist UI we want one row per research target,
 * not one row per property.
 */
async function loadDiaOwnershipBacklog() {
  if (diaOwnershipBacklogLoading) return;
  diaOwnershipBacklogLoading = true;
  try {
    // The cluster view already aggregates by canonical with cluster_size +
    // canonical_total_properties. We collapse to one row per canonical
    // client-side.
    const rows = await diaQuery('v_recorded_owner_canonical_clusters', '*', {
      order: 'canonical_total_properties.desc',
      limit: 500
    });
    const seen = new Set();
    const collapsed = [];
    for (const r of (rows || [])) {
      if (seen.has(r.canonical)) continue;
      seen.add(r.canonical);
      collapsed.push({
        canonical:                  r.canonical,
        cluster_size:               Number(r.cluster_size) || 0,
        canonical_total_properties: Number(r.canonical_total_properties) || 0,
        // Carry one representative recorded_owner row for the property
        // drilldown link.
        sample_recorded_owner_id:   r.recorded_owner_id,
        sample_recorded_owner_name: r.recorded_owner_name,
        sample_properties:          Number(r.properties) || 0,
      });
    }
    diaOwnershipBacklog = collapsed;
  } catch (e) {
    console.error('loadDiaOwnershipBacklog error:', e);
    showToast('Ownership backlog load failed', 'error');
    diaOwnershipBacklog = [];
  }
  diaOwnershipBacklogLoading = false;
  if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'dialysis') return;
  renderDiaTab();
}

/**
 * Load email intake queue — staged items with extraction + match data
 */
async function loadDiaIntakeQueue() {
  if (diaIntakeLoading) return;
  diaIntakeLoading = true;
  try {
    const url = new URL('/api/intake-queue', window.location.origin);
    url.searchParams.set('domain', 'dialysis');
    url.searchParams.set('limit', '50');
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000);
    const response = await fetch(url.toString(), { signal: controller.signal });
    clearTimeout(timeout);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const result = await response.json();
    diaIntakeQueue = result.items || [];
  } catch(e) {
    console.error('loadDiaIntakeQueue error:', e);
    showToast('Intake queue load failed', 'error');
    diaIntakeQueue = [];
  }
  diaIntakeLoading = false;
  if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'dialysis') return;
  renderDiaTab();
}

/**
 * Render email intake queue — documents awaiting review before DB promotion
 */
function renderDiaIntakeQueue() {
  if (diaIntakeLoading || !diaIntakeQueue) {
    return '<div style="text-align:center;padding:40px;color:var(--text3)"><div class="spinner"></div><div style="margin-top:12px">Loading intake queue...</div></div>';
  }

  const items = diaIntakeQueue;
  if (items.length === 0) {
    return '<div style="text-align:center;padding:40px">'
      + '<div style="font-size:36px;margin-bottom:12px">📬</div>'
      + '<div style="font-size:15px;font-weight:600;color:var(--text)">No intake items</div>'
      + '<div style="font-size:12px;color:var(--text3);margin-top:4px">Documents from email intake will appear here for review</div>'
      + '<button onclick="diaIntakeQueue=null;loadDiaIntakeQueue()" style="margin-top:12px;padding:6px 16px;border-radius:6px;border:1px solid var(--border);background:var(--s2);color:var(--text2);cursor:pointer;font-size:12px">Refresh</button>'
      + '</div>';
  }

  let html = '<div style="margin-bottom:12px;display:flex;align-items:center;justify-content:space-between">';
  html += `<div style="font-size:13px;color:var(--text2)">${items.length} item${items.length !== 1 ? 's' : ''} awaiting review</div>`;
  html += '<button onclick="diaIntakeQueue=null;loadDiaIntakeQueue()" style="padding:4px 12px;border-radius:6px;border:1px solid var(--border);background:var(--s2);color:var(--text2);cursor:pointer;font-size:11px">Refresh</button>';
  html += '</div>';

  html += '<div style="display:flex;flex-direction:column;gap:10px">';
  items.forEach((item, idx) => {
    html += renderIntakeCard(item, idx, 'dia');
  });
  html += '</div>';

  return html;
}

/**
 * Shared intake card renderer — used by both dialysis and gov
 */
function renderIntakeCard(item, idx, prefix) {
  const matchIcon = item.match_status === 'matched' ? '✅' : item.match_status === 'review_needed' ? '⚠️' : '❌';
  const matchLabel = item.match_status === 'matched'
    ? `Auto-matched to ${item.match_candidates?.[0]?.address || item.match_property_id || 'property'}`
    : item.match_status === 'review_needed' ? 'Needs Review' : 'No Match';
  const matchColor = item.match_status === 'matched' ? '#34d399' : item.match_status === 'review_needed' ? '#fbbf24' : '#f87171';

  const docTypeLabel = { om: 'Offering Memo', rent_roll: 'Rent Roll', lease_abstract: 'Lease Abstract', unknown: 'Unknown' }[item.document_type] || item.document_type;
  const docTypeColor = { om: '#6c8cff', rent_roll: '#34d399', lease_abstract: '#fbbf24', unknown: '#94a3b8' }[item.document_type] || '#94a3b8';

  const fmt = (v, pre, suf) => v != null ? (pre || '') + v.toLocaleString() + (suf || '') : null;

  let html = `<div style="border:1px solid var(--border);border-radius:10px;padding:14px;background:var(--s1);transition:box-shadow 0.2s" class="intake-card">`;

  // Header: subject + sender
  html += '<div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:10px">';
  html += `<div style="flex:1;min-width:0">`;
  html += `<div style="font-size:13px;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${(item.source_email_subject || '').replace(/"/g, '&quot;')}">${item.source_email_subject || '(No subject)'}</div>`;
  html += `<div style="font-size:11px;color:var(--text3);margin-top:2px">${item.source_email_sender || 'Unknown sender'}</div>`;
  html += '</div>';
  html += `<span style="display:inline-block;padding:2px 8px;border-radius:6px;font-size:10px;font-weight:600;background:${docTypeColor}18;color:${docTypeColor};white-space:nowrap;margin-left:8px">${docTypeLabel}</span>`;
  html += '</div>';

  // Extracted fields grid
  const fields = [
    item.address ? { label: 'Address', value: `${item.address}${item.city ? ', ' + item.city : ''}${item.state ? ', ' + item.state : ''}` } : null,
    item.tenant_name ? { label: 'Tenant', value: item.tenant_name } : null,
    fmt(item.cap_rate, '', '%') ? { label: 'Cap Rate', value: fmt(item.cap_rate, '', '%') } : null,
    fmt(item.noi, '$') ? { label: 'NOI', value: fmt(item.noi, '$') } : null,
    fmt(item.asking_price, '$') ? { label: 'Asking Price', value: fmt(item.asking_price, '$') } : null,
    fmt(item.annual_rent, '$') ? { label: 'Annual Rent', value: fmt(item.annual_rent, '$') } : null,
  ].filter(Boolean);

  if (fields.length > 0) {
    html += '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:6px 12px;margin-bottom:10px">';
    fields.forEach(f => {
      html += `<div><div style="font-size:9px;text-transform:uppercase;letter-spacing:0.5px;color:var(--text3);margin-bottom:1px">${f.label}</div><div style="font-size:12px;font-weight:500;color:var(--text)">${f.value}</div></div>`;
    });
    html += '</div>';
  }

  // Match status + confidence
  html += `<div style="display:flex;align-items:center;gap:8px;padding:8px 10px;background:${matchColor}08;border:1px solid ${matchColor}30;border-radius:6px;margin-bottom:10px">`;
  html += `<span style="font-size:14px">${matchIcon}</span>`;
  html += `<span style="font-size:12px;color:var(--text);flex:1">${matchLabel}</span>`;
  if (item.confidence != null) {
    html += `<span style="font-size:11px;font-weight:600;color:${matchColor};background:${matchColor}15;padding:2px 8px;border-radius:4px">${Math.round(item.confidence * 100)}%</span>`;
  }
  html += '</div>';

  // Action buttons
  html += '<div style="display:flex;gap:8px">';
  html += `<button onclick="intakePromote('${item.intake_id}','${prefix}')" style="flex:1;padding:7px 0;border-radius:6px;border:none;background:#34d399;color:#fff;font-size:12px;font-weight:600;cursor:pointer;transition:opacity 0.2s" onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">Promote to DB</button>`;
  if (item.match_status !== 'matched') {
    html += `<button onclick="intakeLinkProperty('${item.intake_id}','${prefix}')" style="flex:1;padding:7px 0;border-radius:6px;border:1px solid var(--border);background:var(--s2);color:var(--text);font-size:12px;font-weight:500;cursor:pointer;transition:background 0.2s" onmouseover="this.style.background='var(--s3)'" onmouseout="this.style.background='var(--s2)'">Link to Property</button>`;
  }
  html += `<button onclick="intakeDiscard('${item.intake_id}','${prefix}')" style="padding:7px 14px;border-radius:6px;border:1px solid #f8717130;background:#f8717110;color:#f87171;font-size:12px;font-weight:500;cursor:pointer;transition:background 0.2s" onmouseover="this.style.background='#f8717120'" onmouseout="this.style.background='#f8717110'">Discard</button>`;
  html += '</div>';

  html += '</div>';
  return html;
}

/**
 * Promote an intake item to the domain database
 */
window.intakePromote = async function(intakeId, prefix) {
  const btn = event.target;
  const card = btn.closest('.intake-card');
  btn.disabled = true;
  btn.textContent = 'Promoting...';
  try {
    const response = await fetch('/api/intake-promote', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ intake_id: intakeId }),
    });
    const result = await response.json();
    if (!response.ok || !result.ok) throw new Error(result.error || 'Promote failed');
    showToast(`Promoted to ${result.domain || 'DB'}${result.domain_property_id ? ' (property ' + result.domain_property_id + ')' : ''}`, 'success');
    if (card) card.style.opacity = '0.4';
    // Refresh the queue
    if (prefix === 'dia') { diaIntakeQueue = null; loadDiaIntakeQueue(); }
    else { govIntakeQueue = null; loadGovIntakeQueue(); }
  } catch(e) {
    console.error('intakePromote error:', e);
    showToast('Promote failed: ' + e.message, 'error');
    btn.disabled = false;
    btn.textContent = 'Promote to DB';
  }
};

/**
 * Link an intake item to an existing property (placeholder — opens search)
 */
window.intakeLinkProperty = async function(intakeId, prefix) {
  showToast('Link to Property: select a property from search to link this intake item', 'info');
  // Future: open a property search modal, then call promote with property_id
};

/**
 * Discard an intake item
 */
window.intakeDiscard = async function(intakeId, prefix) {
  if (!confirm('Discard this intake item? This cannot be undone.')) return;
  const btn = event.target;
  const card = btn.closest('.intake-card');
  btn.disabled = true;
  btn.textContent = 'Discarding...';
  try {
    const response = await fetch('/api/intake-discard', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ intake_id: intakeId }),
    });
    const result = await response.json();
    if (!response.ok || !result.ok) throw new Error(result.error || 'Discard failed');
    showToast('Intake item discarded', 'success');
    if (card) card.style.opacity = '0.4';
    if (prefix === 'dia') { diaIntakeQueue = null; loadDiaIntakeQueue(); }
    else { govIntakeQueue = null; loadGovIntakeQueue(); }
  } catch(e) {
    console.error('intakeDiscard error:', e);
    showToast('Discard failed: ' + e.message, 'error');
    btn.disabled = false;
    btn.textContent = 'Discard';
  }
};

/**
 * Load staleness monitor data (v_source_health_dashboard or v_counts_freshness)
 */
async function loadDiaStalenessData() {
  if (diaStalenessLoading) return;
  diaStalenessLoading = true;
  try {
    const data = await diaQuery('v_source_health_dashboard', '*', {
      limit: 1000
    });
    diaStalenessData = data || [];
  } catch(e) {
    console.error('loadDiaStalenessData error:', e);
    diaStalenessData = [];
    showToast('Staleness data load failed: ' + e.message, 'error');
  }
  diaStalenessLoading = false;
  if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'dialysis') return;
  renderDiaTab();
}

// Round 76cx Phase 2: load the verification summary digest. Single-row
// view; the dashboard widget renders due_for_verification + overdue +
// broken-URL counts so the user sees at a glance how many listings need
// human eyes.
async function loadDiaVerificationSummary() {
  if (diaVerificationSummaryLoading) return;
  diaVerificationSummaryLoading = true;
  try {
    // getRows() normalizes diaQuery/govQuery's divergent return shapes
    // (see app.js). Defensive against null, plain array, or {data}.
    const rows = getRows(await diaQuery('v_listing_verification_summary', '*', { limit: 1 }));
    diaVerificationSummary = rows[0] || null;
  } catch (e) {
    console.error('loadDiaVerificationSummary error:', e);
    diaVerificationSummary = null;
  }
  diaVerificationSummaryLoading = false;
  if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'dialysis') return;
  renderDiaTab();
}

// Round 76cx Phase 2: dashboard card. Renders a compact verification
// digest. Click → toast for now (Phase 3 wires this to a triage queue
// view). Color reflects urgency:
//   blue   — nothing overdue
//   yellow — some listings due
//   red    — broken URLs or 90d+ overdue
function renderListingVerificationCard() {
  if (!diaVerificationSummary) {
    return '<div class="dia-info-card" style="padding:14px 16px;color:var(--text3);font-size:11px">Loading verification digest…</div>';
  }
  const s = diaVerificationSummary;
  const due       = Number(s.due_for_verification) || 0;
  const overdue30 = Number(s.overdue_30d) || 0;
  const overdue90 = Number(s.overdue_90d) || 0;
  const broken    = Number(s.broken_url_count) || 0;
  const recent    = Number(s.verifications_last_7d) || 0;
  const changes7d = Number(s.recent_status_changes_7d) || 0;
  // Round 76et-E breakout. Falls back to the monolithic 'recent' count
  // when running against a database that hasn't applied the migration yet.
  const evidence7d = (s.evidence_verifications_7d != null) ? Number(s.evidence_verifications_7d) : null;
  const cronOnly7d = (s.cron_timer_advances_7d   != null) ? Number(s.cron_timer_advances_7d)   : null;
  const checks7dPart = (evidence7d != null && cronOnly7d != null)
    ? `${evidence7d} evidence/7d · ${cronOnly7d} cron-only/7d`
    : `${recent} checks/7d`;

  let color = 'blue';
  if (overdue90 > 0 || broken > 0) color = 'red';
  else if (due > 0 || overdue30 > 0) color = 'yellow';

  // DIA_OVERVIEW_TILE_AUDIT Unit 4: headline the actionable OVERDUE count, not
  // the "due now" number (which is genuinely 0 and read as broken). "due now"
  // moves into the sub-detail.
  const title = 'Verification Status';
  const value = fmtN(overdue30);
  const headlineLabel = 'overdue (30d+)';
  const sub = `${due} due now · ${overdue90} 90d-overdue · ${broken} broken-url · ${checks7dPart} · ${changes7d} status-changes/7d`;

  // Round 76et-B (2026-04-29): Phase 3 + 3b + 4b all shipped. The card was
  // pointing users at a "lands later" toast for a feature that already exists.
  // Now the card surfaces the active verification toolset: open any overdue
  // listing in the sidebar (CoStar/LoopNet/etc.) and click "Verify still
  // available" or "Mark off market". The 6h auto-scrape cron handles the
  // sale-window heuristic automatically; manual review is for everything
  // it can't decide.
  const tooltipText = `Open an overdue listing in the sidebar and use Verify still available / Mark off market. The auto-scrape cron handles ${recent} checks/7d automatically.`;
  return `<div class="dia-info-card dia-info-${color}" onclick="showToast('${escapeHtmlSafe(tooltipText)}','info')" style="cursor:pointer;padding:14px 16px" title="${escapeHtmlSafe(tooltipText)}">
    <div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:6px">${title}</div>
    <div style="font-size:24px;font-weight:700;color:var(--text1);margin-bottom:4px">${value}</div>
    <div style="font-size:11px;color:var(--text2)">${escapeHtmlSafe(headlineLabel)} · ${escapeHtmlSafe(sub)}</div>
  </div>`;
}

// Round 76et-F: drill-down for the verification summary card. Pulls the
// last ~50 listing_verification_history rows (7d window, ordered desc) and
// renders a filterable list. Closes the loop between the summary numbers
// and the actual evidence trail without requiring a SQL view migration.
async function loadRecentDiaVerifications() {
  if (diaRecentVerificationsLoading) return;
  diaRecentVerificationsLoading = true;
  try {
    const sevenDaysAgo = new Date(Date.now() - 7 * 86400000).toISOString();
    // getRows() normalizes diaQuery/govQuery's divergent return shapes
    // (see app.js).
    diaRecentVerifications = getRows(await diaQuery(
      'listing_verification_history',
      'id,listing_id,verified_at,method,check_result,notes,source_url',
      { filter: 'verified_at=gte.' + sevenDaysAgo, order: 'verified_at.desc', limit: 50 }
    ));
  } catch (e) {
    console.error('loadRecentDiaVerifications error:', e);
    diaRecentVerifications = [];
  }
  diaRecentVerificationsLoading = false;
  if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'dialysis') return;
  renderDiaTab();
}

window.setDiaRecentVerificationsFilter = function (f) {
  if (f !== 'all' && f !== 'evidence' && f !== 'cron') return;
  diaRecentVerificationsFilter = f;
  renderDiaTab();
};

function _diaFmtTimeAgo(iso) {
  if (!iso) return '';
  const ms = Date.now() - Date.parse(iso);
  if (!Number.isFinite(ms) || ms < 0) return '';
  const m = Math.floor(ms / 60000);
  if (m < 1)  return 'just now';
  if (m < 60) return m + 'm ago';
  const h = Math.floor(m / 60);
  if (h < 24) return h + 'h ago';
  const d = Math.floor(h / 24);
  return d + 'd ago';
}

function renderRecentDiaVerificationsPanel() {
  if (diaRecentVerifications === null) {
    return '<div class="dia-info-card" style="margin-top:14px;padding:14px 16px;color:var(--text3);font-size:11px">Loading recent verifications…</div>';
  }
  const all = diaRecentVerifications;
  const filter = diaRecentVerificationsFilter;
  const isCron = (r) => r.method === 'auto_scrape' && r.check_result === 'inferred_active';
  const evidenceLen = all.filter(r => !isCron(r)).length;
  const cronLen     = all.filter(isCron).length;
  const filtered = filter === 'all'      ? all
                 : filter === 'cron'     ? all.filter(isCron)
                 :                          all.filter(r => !isCron(r));

  let h = '<div class="dia-info-card" style="margin-top:14px;padding:14px 16px">';
  h += '<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap">';
  h += '<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3)">Recent Verifications (7d)</div>';
  h += '<div style="flex:1"></div>';
  h += '<button class="ops-filter ' + (filter === 'all'      ? 'active' : '') + '" onclick="setDiaRecentVerificationsFilter(\'all\')">All ('      + all.length + ')</button>';
  h += '<button class="ops-filter ' + (filter === 'evidence' ? 'active' : '') + '" onclick="setDiaRecentVerificationsFilter(\'evidence\')">Evidence (' + evidenceLen + ')</button>';
  h += '<button class="ops-filter ' + (filter === 'cron'     ? 'active' : '') + '" onclick="setDiaRecentVerificationsFilter(\'cron\')">Cron-only ('  + cronLen + ')</button>';
  h += '</div>';

  if (filtered.length === 0) {
    h += '<div style="color:var(--text3);font-size:12px;padding:8px 0">No rows for this filter.</div>';
  } else {
    h += '<div style="max-height:280px;overflow-y:auto">';
    for (const r of filtered.slice(0, 50)) {
      const ago = _diaFmtTimeAgo(r.verified_at);
      const noteSnip = String(r.notes || '').substring(0, 80);
      const url = r.source_url ? '<a href="' + escapeHtmlSafe(r.source_url) + '" target="_blank" rel="noopener" style="color:var(--accent);text-decoration:none">↗</a>' : '';
      h += '<div style="display:grid;grid-template-columns:80px 110px 110px 80px 1fr 20px;gap:10px;padding:6px 0;border-bottom:1px solid var(--s2);font-size:12px;align-items:center">';
      h += '<span style="color:var(--text3)">' + escapeHtmlSafe(ago) + '</span>';
      h += '<span class="q-badge">' + escapeHtmlSafe(String(r.method || '')) + '</span>';
      h += '<span class="q-badge">' + escapeHtmlSafe(String(r.check_result || '')) + '</span>';
      h += '<span style="font-family:monospace;color:var(--text2);font-size:11px">#' + escapeHtmlSafe(String(r.listing_id || '')) + '</span>';
      h += '<span style="color:var(--text2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + escapeHtmlSafe(noteSnip) + '">' + escapeHtmlSafe(noteSnip) + '</span>';
      h += '<span>' + url + '</span>';
      h += '</div>';
    }
    h += '</div>';
  }
  h += '</div>';
  return h;
}

// Defensive escapeHtml stub (some dialysis.js builds inline this differently;
// fallback returns raw string if global escapeHtml is unavailable).
function escapeHtmlSafe(s) {
  if (typeof escapeHtml === 'function') return escapeHtml(String(s ?? ''));
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
}

/**
 * Load run health data (ingestion_tracker + v_ingestion_reconciliation)
 */
async function loadDiaRunHealthData() {
  if (diaRunHealthLoading) return;
  diaRunHealthLoading = true;
  try {
    const data = await diaQuery('ingestion_tracker', '*', {
      order: "started_at.desc",
      limit: 100
    });
    diaRunHealthData = data || [];
  } catch(e) {
    console.error('loadDiaRunHealthData error:', e);
    showToast('Run health data load failed', 'error');
    diaRunHealthData = [];
  }
  diaRunHealthLoading = false;
  if (typeof currentBizTab !== 'undefined' && currentBizTab !== 'dialysis') return;
  renderDiaTab();
}

// ============================================================================
// PIPELINE/OPS RESEARCH MODES — Render functions
// ============================================================================

/**
 * Render unmatched clinics research interface
 */
function renderDiaUnmatchedClinics() {
  let html = '<div class="research-progress" style="margin-bottom: 30px;">';

  if (diaUnmatchedLoading || !diaUnmatchedQueue) {
    html += '<div style="padding:20px;text-align:center;color:var(--text2);">Loading unmatched records...</div>';
    html += '</div>';
    return html;
  }

  const total = diaUnmatchedQueue.length;
  html += `<div class="progress-text" style="margin-bottom:10px;"><strong>${total} unmatched records</strong> awaiting property linkage</div>`;
  html += '</div>';

  // Two-column layout: list + detail
  html += '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; align-items: start;">';

  // Left: scrollable list
  html += '<div style="border: 1px solid var(--border); border-radius: 8px; overflow: hidden; max-height: 500px; overflow-y: auto; background: var(--s2);">';
  html += '<div style="position: sticky; top: 0; background: var(--s3); padding: 12px; border-bottom: 1px solid var(--border); font-weight: 600; font-size: 12px; color: var(--text2);">Records Needing Match</div>';

  if (total === 0) {
    html += '<div style="padding: 30px; text-align: center; color: var(--text2);">No unmatched records</div>';
  } else {
    diaUnmatchedQueue.slice(0, 100).forEach((item, idx) => {
      const isSelected = diaUnmatchedIdx === idx;
      const daysSince = item.created_at ? Math.floor((Date.now() - new Date(item.created_at).getTime()) / (1000 * 60 * 60 * 24)) : 0;
      const bgColor = isSelected ? 'background: rgba(52, 211, 153, 0.15); border-left: 3px solid var(--accent);' : 'border-left: 3px solid transparent;';

      html += `<div class="clickable-row" data-um-idx="${idx}" style="padding: 12px; cursor: pointer; border-bottom: 1px solid var(--border); ${bgColor}">`;
      html += `<div style="font-weight: 500; color: var(--text); font-size: 13px; margin-bottom: 4px; max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${esc(item.address || 'Unknown')}</div>`;
      html += `<div style="color: var(--text2); font-size: 11px; margin-bottom: 3px;">${esc(item.city || '')}${item.city && item.state ? ', ' : ''}${esc(item.state || '')}</div>`;
      html += `<div style="display: flex; justify-content: space-between; font-size: 10px; color: var(--text2);">`;
      html += `<span>${esc(item.reason || 'Unknown')}</span>`;
      html += `<span>${daysSince}d ago</span>`;
      html += `</div>`;
      html += `</div>`;
    });
  }
  html += '</div>';

  // Right: detail card
  if (total > 0 && diaUnmatchedIdx < total) {
    const item = diaUnmatchedQueue[diaUnmatchedIdx];
    html += '<div style="border: 1px solid var(--border); border-radius: 8px; padding: 20px; background: var(--s2);">';
    html += '<div class="task-header" style="margin-bottom: 20px;">';
    html += '<div style="flex: 1;">Match to Property</div>';
    html += '<span class="task-badge urgent" style="margin-left: 10px;">Action Required</span>';
    html += '</div>';

    // Raw data display
    html += '<div style="margin-bottom: 20px; padding: 12px; background: var(--s3); border-radius: 6px; border-left: 3px solid var(--text2);">';
    html += `<div style="font-size: 12px; margin-bottom: 8px;"><strong>Address:</strong> ${esc(item.address || 'N/A')}</div>`;
    html += `<div style="font-size: 12px; margin-bottom: 8px;"><strong>City/State:</strong> ${esc(item.city || '')} ${esc(item.state || '')}</div>`;
    html += `<div style="font-size: 12px; margin-bottom: 8px;"><strong>Table:</strong> ${esc(item.table_name || 'N/A')}</div>`;
    html += `<div style="font-size: 12px;"><strong>Reason:</strong> ${esc(item.reason || 'N/A')}</div>`;
    html += '</div>';

    // Property search
    html += '<div style="margin-bottom: 20px;">';
    html += '<label style="font-weight: 600; font-size: 13px; margin-bottom: 8px; display: block;">Search Properties:</label>';
    html += `<input type="text" id="um-property-search" placeholder="Enter address or property name..." style="width: 100%; padding: 8px; border: 1px solid var(--border); border-radius: 6px; background: var(--s2); color: var(--text); font-size: 12px; box-sizing: border-box;">`;
    html += '<div id="um-search-results" style="margin-top: 10px; max-height: 150px; overflow-y: auto;"></div>';
    html += '</div>';

    // Manual property ID entry
    html += '<div style="margin-bottom: 20px;">';
    html += '<label style="font-weight: 600; font-size: 13px; margin-bottom: 8px; display: block;">Or Enter Property ID:</label>';
    html += `<input type="number" id="um-property-id" placeholder="Property ID..." style="width: 100%; padding: 8px; border: 1px solid var(--border); border-radius: 6px; background: var(--s2); color: var(--text); font-size: 12px; box-sizing: border-box;">`;
    html += '</div>';

    // Selected property display
    html += `<div id="um-selected-property" style="margin-bottom: 20px;"></div>`;

    // Notes field
    html += guidedField('um-notes', 'Resolution Notes', '', { type: 'textarea', placeholder: 'Add notes about this resolution...', rows: 3 });

    // Action buttons
    html += '<div class="action-row" style="margin-top: 20px; display: flex; gap: 10px; flex-wrap: wrap;">';
    html += `<button class="btn-action primary" data-um-action="resolve" style="flex: 1; min-width: 120px;">Link to Property</button>`;
    html += `<button class="btn-action warn" data-um-action="create" style="flex: 1; min-width: 120px;">Create New Property</button>`;
    html += `<button class="btn-action default" data-um-action="skip" style="flex: 1; min-width: 120px;">Skip</button>`;
    html += `<button class="btn-action danger" data-um-action="dismiss" style="flex: 1; min-width: 120px;">Dismiss</button>`;
    html += '</div>';

    // Inline create-property form (hidden by default)
    html += `<div id="um-create-form" style="display:none;margin-top:16px;padding:14px;background:var(--s3);border-radius:8px;border:1px solid var(--border);">`;
    html += `<div style="font-weight:600;font-size:13px;margin-bottom:10px;color:var(--accent);">Create New Property</div>`;
    html += `<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px;">`;
    html += `<input type="text" id="um-new-addr" placeholder="Address *" style="padding:7px 10px;font-size:12px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);">`;
    html += `<input type="text" id="um-new-name" placeholder="Property Name" style="padding:7px 10px;font-size:12px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);">`;
    html += `<input type="text" id="um-new-city" placeholder="City *" style="padding:7px 10px;font-size:12px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);">`;
    html += `<input type="text" id="um-new-state" placeholder="State *" style="padding:7px 10px;font-size:12px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);">`;
    html += `</div>`;
    html += `<div style="display:flex;gap:8px;">`;
    html += `<button class="btn-action primary" id="um-create-confirm" style="flex:1;">Create & Link</button>`;
    html += `<button class="btn-action default" id="um-create-cancel" style="flex:0;">Cancel</button>`;
    html += `</div>`;
    html += `</div>`;

    html += '</div>';
  } else if (total === 0) {
    html += '<div style="padding: 30px; text-align: center; color: var(--green); font-weight: 600;">All records matched!</div>';
  }

  html += '</div>';

  // Attach handlers
  setTimeout(() => {
    // List item selection
    document.querySelectorAll('[data-um-idx]').forEach(row => {
      row.addEventListener('click', e => {
        diaUnmatchedIdx = parseInt(e.currentTarget.dataset.umIdx, 10);
        renderDiaTab();
      });
    });

    // Property search
    const searchInput = document.getElementById('um-property-search');
    if (searchInput) {
      let searchTimeout;
      searchInput.addEventListener('input', async e => {
        clearTimeout(searchTimeout);
        const query = e.target.value.trim();
        const resultsDiv = document.getElementById('um-search-results');
        if (!resultsDiv) return;

        if (query.length < 2) {
          resultsDiv.innerHTML = '';
          return;
        }

        searchTimeout = setTimeout(async () => {
          try {
            const safeQ = query.replace(/[*()',\\]/g, '');
            if (!safeQ) { resultsDiv.innerHTML = ''; return; }
            resultsDiv.innerHTML = '<div style="padding: 8px; font-size: 12px; color: var(--text2);">Searching...</div>';
            const props = await Promise.race([
              diaQuery('properties', 'id, address, city, state, property_name', {
                filter: `or(address.ilike.*${safeQ}*,property_name.ilike.*${safeQ}*)`,
                limit: 10
              }),
              new Promise(function(_, reject) { setTimeout(function() { reject(new Error('timeout')); }, 5000); })
            ]);

            if (props.length === 0) {
              resultsDiv.innerHTML = '<div style="padding: 8px; font-size: 12px; color: var(--text2);">No properties found</div>';
            } else {
              resultsDiv.innerHTML = props.map(p =>
                `<div class="clickable-row um-search-result" data-prop-id="${p.id}" style="padding: 8px; border-bottom: 1px solid var(--border); cursor: pointer; font-size: 12px;">${esc(p.address || '')} - ${esc(p.city || '')} ${esc(p.state || '')}</div>`
              ).join('');

              document.querySelectorAll('.um-search-result').forEach(el => {
                el.addEventListener('click', e => {
                  const propId = parseInt(e.currentTarget.dataset.propId, 10);
                  const propIdEl = document.getElementById('um-property-id');
                  if (propIdEl) propIdEl.value = propId;

                  // Display selected property
                  const prop = props.find(p => p.id === propId);
                  if (prop) {
                    const selectedEl = document.getElementById('um-selected-property');
                    if (selectedEl) selectedEl.innerHTML =
                      `<div style="padding: 12px; background: rgba(52, 211, 153, 0.1); border-radius: 6px; border-left: 3px solid var(--accent);"><strong>Selected:</strong> ${esc(prop.address || '')} (ID: ${prop.id})</div>`;
                  }
                  resultsDiv.innerHTML = '';
                });
              });
            }
          } catch(err) {
            console.error('Property search error:', err);
            if (err.message === 'timeout') {
              resultsDiv.innerHTML = '<div style="padding: 8px; font-size: 12px; color: var(--error);">Search timed out — try again</div>';
            } else {
              resultsDiv.innerHTML = '<div style="padding: 8px; font-size: 12px; color: var(--error);">Search error</div>';
            }
          }
        }, 300);
      });
    }

    // Action buttons
    document.querySelectorAll('[data-um-action]').forEach(btn => {
      btn.addEventListener('click', async e => {
        const action = e.target.dataset.umAction;
        const item = diaUnmatchedQueue[diaUnmatchedIdx];
        if (!item) return;

        // "Create New Property" toggles inline form
        if (action === 'create') {
          const createForm = document.getElementById('um-create-form');
          if (createForm) {
            createForm.style.display = createForm.style.display === 'none' ? 'block' : 'none';
            // Pre-fill with raw record data if available
            const raw = item.raw || item;
            if (raw.address) { const el = document.getElementById('um-new-addr'); if (el && !el.value) el.value = raw.address; }
            if (raw.facility_name) { const el = document.getElementById('um-new-name'); if (el && !el.value) el.value = raw.facility_name; }
            if (raw.city) { const el = document.getElementById('um-new-city'); if (el && !el.value) el.value = raw.city; }
            if (raw.state) { const el = document.getElementById('um-new-state'); if (el && !el.value) el.value = raw.state; }
          }
          return;
        }

        const propIdEl = document.getElementById('um-property-id');
        const propertyId = propIdEl?.value ? parseInt(propIdEl.value, 10) : null;

        if (action === 'resolve' && !propertyId) {
          showToast('Please select or enter a Property ID', 'error');
          return;
        }

        if (action === 'resolve') {
          if (!(await lccConfirm('Link this clinic to Property ID ' + propertyId + '? This cannot be undone.', 'Link'))) return;
        }

        if (action === 'dismiss') {
          if (!(await lccConfirm('Dismiss this unmatched record? It cannot be undone from this view.', 'Dismiss'))) return;
        }

        const allBtns = document.querySelectorAll('[data-um-action]');
        const origText = e.target.textContent;
        allBtns.forEach(b => { b.disabled = true; b.style.opacity = '0.6'; });
        e.target.textContent = 'Processing\u2026';
        try {
          await resolveDiaUnmatched(item.id, action, propertyId);
        } catch (err) {
          console.error('resolveDiaUnmatched error:', err);
          showToast('Action failed: ' + err.message, 'error');
          allBtns.forEach(b => { b.disabled = false; b.style.opacity = ''; });
          e.target.textContent = origText;
        }
      });
    });

    // Create-form confirm & cancel
    const umCreateConfirm = document.getElementById('um-create-confirm');
    if (umCreateConfirm) {
      umCreateConfirm.addEventListener('click', async () => {
        const item = diaUnmatchedQueue[diaUnmatchedIdx];
        if (!item) return;
        const addr = document.getElementById('um-new-addr')?.value?.trim();
        const city = document.getElementById('um-new-city')?.value?.trim();
        const state = document.getElementById('um-new-state')?.value?.trim();
        const name = document.getElementById('um-new-name')?.value?.trim();
        if (!addr || !city || !state) { showToast('Address, city, and state are required', 'error'); return; }
        umCreateConfirm.disabled = true;
        umCreateConfirm.textContent = 'Creating\u2026';
        try {
          const result = await applyInsertWithFallback({
            proxyBase: '/api/dia-query',
            table: 'properties',
            data: { address: addr, city: city, state: state, property_name: name || addr },
            source_surface: 'dia_unmatched_create'
          });
          if (result && result.ok && result.data && result.data[0]) {
            const newId = result.data[0].property_id || result.data[0].id;
            await resolveDiaUnmatched(item.id, 'resolve', newId);
            showToast('Property #' + newId + ' created & linked!', 'success');
          } else {
            showToast('Failed to create property', 'error');
          }
        } catch (err) {
          showToast('Error: ' + err.message, 'error');
        } finally {
          umCreateConfirm.disabled = false;
          umCreateConfirm.textContent = 'Create & Link';
        }
      });
    }
    const umCreateCancel = document.getElementById('um-create-cancel');
    if (umCreateCancel) {
      umCreateCancel.addEventListener('click', () => {
        const f = document.getElementById('um-create-form');
        if (f) f.style.display = 'none';
      });
    }
  }, 0);

  return html;
}

/**
 * Render quarantine review interface
 */
function renderDiaQuarantineReview() {
  let html = '<div class="research-progress" style="margin-bottom: 30px;">';

  if (diaQuarantineLoading || !diaQuarantineQueue) {
    html += '<div style="padding:20px;text-align:center;color:var(--text2);">Loading quarantine records...</div>';
    html += '</div>';
    return html;
  }

  const total = diaQuarantineQueue.length;
  html += `<div class="progress-text" style="margin-bottom:10px;"><strong>${total} quarantined records</strong> requiring review</div>`;
  html += '</div>';

  // Two-column layout
  html += '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; align-items: start;">';

  // Left: list
  html += '<div style="border: 1px solid var(--border); border-radius: 8px; overflow: hidden; max-height: 500px; overflow-y: auto; background: var(--s2);">';
  html += '<div style="position: sticky; top: 0; background: var(--s3); padding: 12px; border-bottom: 1px solid var(--border); font-weight: 600; font-size: 12px; color: var(--text2);">Quarantine Queue</div>';

  if (total === 0) {
    html += '<div style="padding: 30px; text-align: center; color: var(--text2);">No quarantined records</div>';
  } else {
    diaQuarantineQueue.slice(0, 100).forEach((item, idx) => {
      const isSelected = diaQuarantineIdx === idx;
      const daysSince = item.ingested_at ? Math.floor((Date.now() - new Date(item.ingested_at).getTime()) / (1000 * 60 * 60 * 24)) : 0;
      const bgColor = isSelected ? 'background: rgba(52, 211, 153, 0.15); border-left: 3px solid var(--accent);' : 'border-left: 3px solid transparent;';

      html += `<div class="clickable-row" data-q-idx="${idx}" style="padding: 12px; cursor: pointer; border-bottom: 1px solid var(--border); ${bgColor}">`;
      html += `<div style="font-weight: 500; color: var(--red); font-size: 13px; margin-bottom: 4px;">${esc(item.reason || 'Unknown')}</div>`;
      html += `<div style="color: var(--text2); font-size: 11px; margin-bottom: 3px;">${esc(item.source || 'Unknown')}</div>`;
      html += `<div style="display: flex; justify-content: space-between; font-size: 10px; color: var(--text2);">`;
      html += `<span>${daysSince}d ago</span>`;
      html += `</div>`;
      html += `</div>`;
    });
  }
  html += '</div>';

  // Right: detail card
  if (total > 0 && diaQuarantineIdx < total) {
    const item = diaQuarantineQueue[diaQuarantineIdx];
    const raw = item.raw || {};

    html += '<div style="border: 1px solid var(--border); border-radius: 8px; padding: 20px; background: var(--s2);">';
    html += '<div class="task-header" style="margin-bottom: 20px;">';
    html += '<div style="flex: 1;">Quarantine Review</div>';
    html += '<span class="task-badge urgent">Needs Review</span>';
    html += '</div>';

    // Raw data display
    html += '<div style="margin-bottom: 20px; padding: 12px; background: var(--s3); border-radius: 6px; border-left: 3px solid var(--red); max-height: 200px; overflow-y: auto; font-size: 12px;">';
    html += `<div style="margin-bottom: 8px;"><strong>Reason:</strong> ${esc(item.reason || 'N/A')}</div>`;
    html += `<div style="margin-bottom: 8px;"><strong>Source:</strong> ${esc(item.source || 'N/A')}</div>`;

    if (raw.facility_name) html += `<div style="margin-bottom: 8px;"><strong>Facility:</strong> ${esc(raw.facility_name)}</div>`;
    if (raw.ccn) html += `<div style="margin-bottom: 8px;"><strong>CCN:</strong> ${esc(raw.ccn)}</div>`;
    if (raw.address) html += `<div style="margin-bottom: 8px;"><strong>Address:</strong> ${esc(raw.address)}</div>`;
    if (raw.city) html += `<div style="margin-bottom: 8px;"><strong>City:</strong> ${esc(raw.city)}</div>`;
    if (raw.state) html += `<div style="margin-bottom: 8px;"><strong>State:</strong> ${esc(raw.state)}</div>`;

    html += '</div>';

    // Property resolution — search or create to link this quarantined record
    html += '<div style="margin-top:16px;padding:12px;background:var(--s3);border-radius:6px;border:1px dashed var(--warning);">';
    html += '<div style="font-size:12px;font-weight:600;color:var(--warning);margin-bottom:8px;">Link to Property (optional)</div>';
    html += '<div style="display:flex;gap:8px;margin-bottom:8px;">';
    html += '<input type="text" id="q-prop-search" placeholder="Search by address or name..." style="flex:1;padding:6px 10px;font-size:12px;border:1px solid var(--border);border-radius:4px;background:var(--bg);color:var(--text);">';
    html += '<button class="btn-action default" id="q-prop-search-btn" style="padding:6px 12px;font-size:11px;">Search</button>';
    html += '</div>';
    html += '<div id="q-prop-results" style="max-height:120px;overflow-y:auto;margin-bottom:8px;"></div>';
    html += '<div id="q-prop-selected" style="margin-bottom:8px;"></div>';
    html += '<input type="hidden" id="q-prop-id" value="">';
    html += '</div>';

    // Action buttons
    html += '<div class="action-row" style="margin-top: 20px; display: flex; gap: 10px; flex-wrap: wrap;">';
    html += `<button class="btn-action primary" data-q-action="reingest" style="flex: 1; min-width: 120px;">Resolve & Re-ingest</button>`;
    html += `<button class="btn-action warn" data-q-action="merge" style="flex: 1; min-width: 120px;">Mark Duplicate</button>`;
    html += `<button class="btn-action danger" data-q-action="dismiss" style="flex: 1; min-width: 120px;">Dismiss</button>`;
    html += '</div>';

    html += '</div>';
  } else if (total === 0) {
    html += '<div style="padding: 30px; text-align: center; color: var(--green); font-weight: 600;">All clear!</div>';
  }

  html += '</div>';

  // Attach handlers
  setTimeout(() => {
    document.querySelectorAll('[data-q-idx]').forEach(row => {
      row.addEventListener('click', e => {
        diaQuarantineIdx = parseInt(e.currentTarget.dataset.qIdx, 10);
        renderDiaTab();
      });
    });

    // Quarantine property search
    const qSearchBtn = document.getElementById('q-prop-search-btn');
    const qSearchInput = document.getElementById('q-prop-search');
    if (qSearchBtn && qSearchInput) {
      const doQSearch = async () => {
        const query = qSearchInput.value.trim();
        const resultsDiv = document.getElementById('q-prop-results');
        if (!resultsDiv) return;
        if (query.length < 2) { showToast('Enter at least 2 characters', 'info'); return; }
        resultsDiv.innerHTML = '<div style="padding:4px;font-size:11px;color:var(--text2);">Searching...</div>';
        try {
          const safeQ = query.replace(/[*()',\\]/g, '');
          const props = await diaQuery('properties', 'property_id,address,city,state,property_name', {
            filter: `or(address.ilike.*${safeQ}*,property_name.ilike.*${safeQ}*)`, limit: 10
          });
          if (!props || props.length === 0) {
            resultsDiv.innerHTML = '<div style="padding:4px;font-size:11px;color:var(--text2);">No properties found</div>';
            return;
          }
          resultsDiv.innerHTML = props.map(p =>
            `<div class="clickable-row q-prop-pick" data-pid="${p.property_id}" style="padding:6px 8px;font-size:11px;border-bottom:1px solid var(--border);cursor:pointer;">${esc(p.address || p.property_name || 'Unknown')} — ${esc((p.city || '') + (p.state ? ', ' + p.state : ''))}</div>`
          ).join('');
          document.querySelectorAll('.q-prop-pick').forEach(el => {
            el.addEventListener('click', () => {
              const pid = el.dataset.pid;
              document.getElementById('q-prop-id').value = pid;
              document.getElementById('q-prop-selected').innerHTML = '<div style="padding:8px;background:rgba(52,211,153,0.1);border-radius:4px;font-size:12px;border-left:3px solid var(--accent);"><strong>Selected:</strong> Property #' + pid + ' — ' + esc(el.textContent) + '</div>';
              resultsDiv.innerHTML = '';
            });
          });
        } catch(e) {
          resultsDiv.innerHTML = '<div style="padding:4px;font-size:11px;color:var(--error);">Search failed</div>';
        }
      };
      qSearchBtn.addEventListener('click', doQSearch);
      qSearchInput.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); doQSearch(); } });
    }

    document.querySelectorAll('[data-q-action]').forEach(btn => {
      btn.addEventListener('click', async e => {
        const action = e.target.dataset.qAction;
        const item = diaQuarantineQueue[diaQuarantineIdx];
        if (!item) return;
        const linkedPropId = document.getElementById('q-prop-id')?.value || null;

        console.debug('Quarantine action:', action, item);

        const allQBtns = document.querySelectorAll('[data-q-action]');
        const origText = e.target.textContent;

        if (action === 'dismiss') {
          if (!(await lccConfirm('Dismiss this quarantined record? It will be removed from the queue.', 'Dismiss'))) return;
        } else if (action === 'reingest') {
          if (!(await lccConfirm('Mark this record as resolved and re-ingest it?', 'Resolve'))) return;
        } else if (action === 'merge') {
          if (!linkedPropId) { showToast('Search and select a property to merge with first', 'warning'); return; }
          if (!(await lccConfirm('Mark as duplicate and link to Property #' + linkedPropId + '?', 'Merge'))) return;
        }

        allQBtns.forEach(b => { b.disabled = true; b.style.opacity = '0.6'; });
        e.target.textContent = 'Processing\u2026';
        try {
          const updateData = {
            status: action === 'dismiss' ? 'dismissed' : action === 'merge' ? 'merged' : 'resolved',
            resolved_at: new Date().toISOString(),
            resolved_by: 'dashboard'
          };
          if (linkedPropId) updateData.linked_property_id = parseInt(linkedPropId, 10);
          await diaPatchRecord('medicare_ingest_quarantine', 'id', item.id, updateData);
          diaQuarantineQueue = diaQuarantineQueue.filter((_, i) => i !== diaQuarantineIdx);
          diaQuarantineIdx = Math.min(diaQuarantineIdx, Math.max(0, diaQuarantineQueue.length - 1));
          const labels = { dismiss: 'Dismissed', reingest: 'Resolved & queued for re-ingest', merge: 'Merged with property' };
          showToast(labels[action] || 'Done', 'success');
          renderDiaTab();
        } catch (err) {
          console.error('Quarantine action error:', err);
          showToast('Action failed: ' + err.message, 'error');
          allQBtns.forEach(b => { b.disabled = false; b.style.opacity = ''; });
          e.target.textContent = origText;
        }
      });
    });
  }, 0);

  return html;
}

/**
 * Render clarification queue interface
 */
function renderDiaClarificationQueue() {
  let html = '<div class="research-progress" style="margin-bottom: 30px;">';

  if (diaClarificationLoading || !diaClarificationQueue) {
    html += '<div style="padding:20px;text-align:center;color:var(--text2);">Loading clarification queue...</div>';
    html += '</div>';
    return html;
  }

  const total = diaClarificationQueue.length;
  html += `<div class="progress-text" style="margin-bottom:10px;"><strong>${total} clarification requests</strong></div>`;
  html += '</div>';

  // Two-column layout
  html += '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; align-items: start;">';

  // Left: list
  html += '<div style="border: 1px solid var(--border); border-radius: 8px; overflow: hidden; max-height: 500px; overflow-y: auto; background: var(--s2);">';
  html += '<div style="position: sticky; top: 0; background: var(--s3); padding: 12px; border-bottom: 1px solid var(--border); font-weight: 600; font-size: 12px; color: var(--text2);">Pending Clarification</div>';

  if (total === 0) {
    html += '<div style="padding: 30px; text-align: center; color: var(--green);">No pending clarifications</div>';
  } else {
    diaClarificationQueue.slice(0, 100).forEach((item, idx) => {
      const isSelected = diaClarificationIdx === idx;
      const bgColor = isSelected ? 'background: rgba(52, 211, 153, 0.15); border-left: 3px solid var(--accent);' : 'border-left: 3px solid transparent;';

      html += `<div class="clickable-row" data-cl-idx="${idx}" style="padding: 12px; cursor: pointer; border-bottom: 1px solid var(--border); ${bgColor}">`;
      html += `<div style="font-weight: 500; color: var(--text); font-size: 13px; margin-bottom: 4px;">${esc(item.clarification_prompt ? item.clarification_prompt.substring(0, 30) : 'Clarification')}</div>`;
      html += `<div style="color: var(--text2); font-size: 11px;">${esc(item.table_name || 'Unknown')}</div>`;
      html += `</div>`;
    });
  }
  html += '</div>';

  // Right: detail card
  if (total > 0 && diaClarificationIdx < total) {
    const item = diaClarificationQueue[diaClarificationIdx];

    html += '<div style="border: 1px solid var(--border); border-radius: 8px; padding: 20px; background: var(--s2);">';
    html += '<div class="task-header" style="margin-bottom: 20px;">';
    html += '<div style="flex: 1;">Provide Missing Data</div>';
    html += '<span class="task-badge needs-input">Response Needed</span>';
    html += '</div>';

    // Clarification prompt (prominent)
    html += '<div style="margin-bottom: 20px; padding: 12px; background: rgba(251, 191, 36, 0.1); border-radius: 6px; border-left: 3px solid #fbbf24;">';
    html += `<div style="font-weight: 600; color: #fbbf24; font-size: 13px; margin-bottom: 8px;">Question:</div>`;
    html += `<div style="font-size: 13px; color: var(--text);">${esc(item.clarification_prompt || 'Clarification needed')}</div>`;
    html += '</div>';

    // Input field for the missing data
    html += `<div style="margin-bottom: 20px;">`;
    html += `<label style="font-weight: 600; font-size: 13px; margin-bottom: 8px; display: block;">Your Response:</label>`;
    html += `<textarea id="cl-response" placeholder="Enter the missing information..." style="width: 100%; padding: 8px; border: 1px solid var(--border); border-radius: 6px; background: var(--s2); color: var(--text); font-size: 12px; box-sizing: border-box; min-height: 100px;"></textarea>`;
    html += `</div>`;

    // View related record button — lets user open detail panel for context
    if (item.record_id) {
      html += `<div style="margin-bottom:12px;">`;
      html += `<button class="btn-action default" id="cl-view-record" style="width:100%;font-size:12px;padding:8px;">View Related Record in Detail Panel</button>`;
      html += `</div>`;
    }

    // Action buttons
    html += '<div class="action-row" style="margin-top: 20px; display: flex; gap: 10px; flex-wrap: wrap;">';
    html += `<button class="btn-action primary" data-cl-action="submit" style="flex: 1; min-width: 120px;">Submit Data</button>`;
    html += `<button class="btn-action warn" data-cl-action="cannot-determine" style="flex: 1; min-width: 120px;">Cannot Determine</button>`;
    html += `<button class="btn-action default" data-cl-action="skip" style="flex: 1; min-width: 120px;">Skip</button>`;
    html += '</div>';

    html += '</div>';
  }

  html += '</div>';

  // Attach handlers
  setTimeout(() => {
    document.querySelectorAll('[data-cl-idx]').forEach(row => {
      row.addEventListener('click', e => {
        diaClarificationIdx = parseInt(e.currentTarget.dataset.clIdx, 10);
        renderDiaTab();
      });
    });

    // "View Related Record" opens the unified detail panel
    const clViewBtn = document.getElementById('cl-view-record');
    if (clViewBtn) {
      clViewBtn.addEventListener('click', () => {
        const item = diaClarificationQueue[diaClarificationIdx];
        if (!item) return;
        const fakeRec = { property_id: item.property_id || null, medicare_id: item.record_id || null };
        if (typeof showUnifiedDetail === 'function') {
          showUnifiedDetail(fakeRec, 'dia-clinic');
        } else if (typeof showDetail === 'function') {
          showDetail(fakeRec, 'dia-clinic');
        }
      });
    }

    document.querySelectorAll('[data-cl-action]').forEach(btn => {
      btn.addEventListener('click', async e => {
        const action = e.target.dataset.clAction;
        const item = diaClarificationQueue[diaClarificationIdx];
        if (!item) return;

        const response = document.getElementById('cl-response')?.value || '';

        console.debug('Clarification action:', action, item);
        if (action === 'submit') {
          if (!response.trim()) {
            showToast('Please enter your response before submitting', 'error');
            return;
          }
          const allClBtns = document.querySelectorAll('[data-cl-action]');
          allClBtns.forEach(b => { b.disabled = true; });
          e.target.textContent = 'Submitting...';
          // Write clarification response to the source record
          try {
            if (item.table_name && item.record_id) {
              await diaPatchRecord(item.table_name, item.id_column || 'id', item.record_id, {
                [item.field_name || 'clarification_response']: response.trim(),
                clarification_status: 'resolved'
              });
            }
            showToast('Clarification submitted!', 'success');
          } catch(err) {
            console.error('Clarification submit error:', err);
            showToast('Submit failed: ' + err.message + ' — please retry', 'error');
            allClBtns.forEach(b => { b.disabled = false; });
            e.target.textContent = 'Submit Data';
            return;
          }
          diaClarificationQueue = diaClarificationQueue.filter((_, i) => i !== diaClarificationIdx);
          diaClarificationIdx = Math.min(diaClarificationIdx, Math.max(0, diaClarificationQueue.length - 1));
          renderDiaTab();
        } else if (action === 'cannot-determine') {
          if (!(await lccConfirm('Mark as "Cannot Determine"? The item will be removed from your queue.', 'Cannot Determine'))) return;
          const clItem = diaClarificationQueue[diaClarificationIdx];
          if (clItem && clItem.id) {
            const ok = await diaPatchRecord('pending_updates', 'id', clItem.id, { status: 'cannot_determine' });
            if (!ok) { showToast('Failed to persist — please retry', 'error'); return; }
          }
          diaClarificationQueue = diaClarificationQueue.filter((_, i) => i !== diaClarificationIdx);
          diaClarificationIdx = Math.min(diaClarificationIdx, Math.max(0, diaClarificationQueue.length - 1));
          showToast('Marked as cannot determine', 'success');
          renderDiaTab();
        } else if (action === 'skip') {
          const prevIdx = diaClarificationIdx;
          diaClarificationIdx = Math.min(diaClarificationIdx + 1, Math.max(0, diaClarificationQueue.length - 1));
          if (diaClarificationIdx === prevIdx && diaClarificationQueue.length > 0) {
            showToast('End of clarification queue reached', 'info');
          } else {
            showToast('Skipped — ' + (diaClarificationIdx + 1) + ' / ' + diaClarificationQueue.length, 'info');
          }
          renderDiaTab();
        }
      });
    });
  }, 0);

  return html;
}

/**
 * Render staleness monitor
 */
function renderDiaStalenessMonitor() {
  let html = '<div style="margin-bottom: 30px;">';

  if (diaStalenessLoading || !diaStalenessData) {
    html += '<div style="padding:20px;text-align:center;color:var(--text2);">Loading staleness data...</div>';
    html += '</div>';
    return html;
  }

  html += '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">';
  html += '<div style="font-size: 16px; font-weight: 600;">Data Source Freshness</div>';
  html += `<button class="btn-action default" id="dia-refresh-staleness" style="padding: 6px 12px; font-size: 12px;">Refresh</button>`;
  html += '</div>';

  // Grid of source health
  html += '<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 15px;">';

  if (diaStalenessData.length === 0) {
    html += '<div style="padding: 30px; text-align: center; color: var(--text2);">No staleness data available</div>';
  } else {
    diaStalenessData.forEach(source => {
      const lastUpdate = source.last_update_date ? new Date(source.last_update_date) : null;
      const daysSince = lastUpdate ? Math.floor((Date.now() - lastUpdate.getTime()) / (1000 * 60 * 60 * 24)) : null;

      let color = 'var(--text2)';
      let badge = 'Unknown';
      if (daysSince !== null) {
        if (daysSince < 7) {
          color = 'var(--green)';
          badge = 'Fresh';
        } else if (daysSince < 30) {
          color = '#fbbf24';
          badge = 'Stale';
        } else {
          color = 'var(--red)';
          badge = 'Very Stale';
        }
      }

      html += '<div style="border: 1px solid var(--border); border-radius: 8px; padding: 15px; background: var(--s2);">';
      html += `<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">`;
      html += `<div style="font-weight: 600; color: var(--text);">${esc(source.source || 'Unknown')}</div>`;
      html += `<span class="task-badge" style="background: ${color}; color: white; border: none;">${badge}</span>`;
      html += `</div>`;
      html += `<div style="font-size: 13px; color: var(--text2); margin-bottom: 8px;">`;
      if (daysSince !== null) {
        html += `Last updated: <strong style="color: ${color};">${daysSince} days ago</strong>`;
      } else {
        html += `Last updated: Unknown`;
      }
      html += `</div>`;
      if (source.run_status) {
        html += `<div style="font-size: 12px; color: var(--text2);">Status: ${esc(source.run_status)}</div>`;
      }
      html += '</div>';
    });
  }

  html += '</div>';
  html += '</div>';

  // Attach handlers
  setTimeout(() => {
    document.getElementById('dia-refresh-staleness')?.addEventListener('click', async (e) => {
      e.target.disabled = true;
      e.target.textContent = 'Refreshing...';
      diaStalenessData = null;
      await loadDiaStalenessData();
      // renderDiaTab rebuilds the button fresh
    });
  }, 0);

  return html;
}

/**
 * Render run health dashboard
 */
function renderDiaRunHealth() {
  let html = '<div style="margin-bottom: 30px;">';

  if (diaRunHealthLoading || !diaRunHealthData) {
    html += '<div style="padding:20px;text-align:center;color:var(--text2);">Loading run health data...</div>';
    html += '</div>';
    return html;
  }

  // Summary metrics
  const successfulRuns = diaRunHealthData.filter(r => r.run_status === 'success').length;
  const totalRuns = diaRunHealthData.length;
  const lastRun = diaRunHealthData.length > 0 ? diaRunHealthData[0] : null;
  const errorRate = totalRuns > 0 ? Math.round((totalRuns - successfulRuns) / totalRuns * 100) : 0;

  html += '<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 30px;">';
  html += '<div style="border: 1px solid var(--border); border-radius: 8px; padding: 15px; background: var(--s2);">';
  html += '<div style="font-size: 11px; color: var(--text2); margin-bottom: 5px;">Last Run</div>';
  html += `<div style="font-size: 14px; font-weight: 600; color: var(--text);">${lastRun && lastRun.finished_at ? new Date(lastRun.finished_at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'N/A'}</div>`;
  html += '</div>';

  html += '<div style="border: 1px solid var(--border); border-radius: 8px; padding: 15px; background: var(--s2);">';
  html += '<div style="font-size: 11px; color: var(--text2); margin-bottom: 5px;">Success Rate</div>';
  html += `<div style="font-size: 14px; font-weight: 600; color: ${successfulRuns === totalRuns ? 'var(--green)' : 'var(--text)'};">${successfulRuns} / ${totalRuns}</div>`;
  html += '</div>';

  html += '<div style="border: 1px solid var(--border); border-radius: 8px; padding: 15px; background: var(--s2);">';
  html += '<div style="font-size: 11px; color: var(--text2); margin-bottom: 5px;">Error Rate</div>';
  html += `<div style="font-size: 14px; font-weight: 600; color: ${errorRate > 0 ? 'var(--red)' : 'var(--green)'};">${errorRate}%</div>`;
  html += '</div>';
  html += '</div>';

  // Recent runs table
  html += '<div style="margin-bottom: 30px;">';
  html += '<div style="font-size: 14px; font-weight: 600; margin-bottom: 15px;">Recent Runs</div>';
  html += '<div style="border: 1px solid var(--border); border-radius: 8px; overflow: hidden; background: var(--s2);">';
  html += '<div style="display: grid; grid-template-columns: 1.5fr 1fr 1fr 1fr 0.8fr; gap: 0; border-bottom: 1px solid var(--border); font-weight: 600; font-size: 12px; padding: 12px; background: var(--s3); color: var(--text2);">';
  html += '<div>Task / Source</div>';
  html += '<div>Status</div>';
  html += '<div>Started</div>';
  html += '<div>Stats</div>';
  html += '<div>Actions</div>';
  html += '</div>';

  if (diaRunHealthData.length === 0) {
    html += '<div style="padding: 30px; text-align: center; color: var(--text2);">No run data available</div>';
  } else {
    diaRunHealthData.slice(0, 20).forEach((run, idx) => {
      const statusColor = run.run_status === 'success' ? 'var(--green)' : 'var(--red)';
      const startedTime = run.started_at ? new Date(run.started_at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'N/A';
      const stats = `${run.rows_fetched || 0}F / ${run.rows_inserted || 0}I / ${run.rows_updated || 0}U`;

      html += '<div style="display: grid; grid-template-columns: 1.5fr 1fr 1fr 1fr 0.8fr; gap: 0; padding: 12px; border-bottom: 1px solid var(--border); font-size: 12px; align-items: center;">';
      html += `<div><strong>${esc(run.task_name || run.source || 'Unknown')}</strong></div>`;
      html += `<div><span class="task-badge" style="background: ${statusColor}; color: white; border: none; font-size: 11px;">${run.run_status || 'pending'}</span></div>`;
      html += `<div style="color: var(--text2);">${startedTime}</div>`;
      html += `<div style="color: var(--text2); font-size: 11px;">${stats}</div>`;
      html += `<div><button class="btn-link" data-rh-expand="${idx}" style="font-size: 11px; cursor: pointer;">Detail</button></div>`;
      html += '</div>';

      // Expandable error detail
      if (run.error_summary || run.error_log) {
        html += `<div id="rh-detail-${idx}" style="display: none; padding: 12px; background: var(--s3); border-bottom: 1px solid var(--border); font-size: 11px; color: var(--text2); max-height: 150px; overflow-y: auto;">`;
        if (run.error_summary) html += `<div><strong>Error:</strong> ${esc(run.error_summary)}</div>`;
        if (run.error_log) html += `<div style="margin-top: 8px; font-family: monospace; white-space: pre-wrap; word-break: break-word;">${esc(run.error_log.substring(0, 300))}</div>`;
        html += `</div>`;
      }
    });
  }
  html += '</div>';
  html += '</div>';

  // Attach handlers
  setTimeout(() => {
    document.querySelectorAll('[data-rh-expand]').forEach(btn => {
      btn.addEventListener('click', e => {
        const idx = e.target.dataset.rhExpand;
        const detail = document.getElementById(`rh-detail-${idx}`);
        if (detail) {
          detail.style.display = detail.style.display === 'none' ? 'block' : 'none';
          e.target.textContent = detail.style.display === 'none' ? 'Detail' : 'Hide';
        }
      });
    });
  }, 0);

  return html;
}

// ============================================================================
// ACTION HANDLER FUNCTIONS
// ============================================================================

/**
 * Resolve unmatched clinic
 */
async function resolveDiaUnmatched(updateId, action, propertyId) {
  const notes = document.getElementById('um-notes')?.value || '';
  const status = action === 'dismiss' ? 'dismissed' : action === 'resolve' ? 'resolved' : 'needs_match';

  console.debug('Resolving unmatched:', { updateId, action, propertyId, status, notes });

  try {
    const updateData = {
      status: status,
      resolved_at: new Date().toISOString(),
      resolved_by: 'dashboard'
    };

    if (notes) {
      updateData.notes = notes;
    }

    if (propertyId && status === 'resolved') {
      updateData.property_id = propertyId;
    }

    const ok = await diaPatchRecord('pending_updates', 'id', updateId, updateData);

    if (ok) {
      diaUnmatchedQueue = diaUnmatchedQueue.filter(r => r.id !== updateId);
      diaUnmatchedIdx = Math.min(diaUnmatchedIdx, Math.max(0, diaUnmatchedQueue.length - 1));
      const actionLabel = action === 'dismiss' ? 'Dismissed' : action === 'resolve' ? 'Linked to property' : action === 'create' ? 'New property created' : 'Skipped';
      showToast(actionLabel, 'success');
      renderDiaTab();
    } else {
      console.error('Failed to resolve unmatched record:', updateId);
      showToast('Failed to resolve record — please try again', 'error');
    }
  } catch(e) {
    console.error('Error resolving unmatched:', e);
    showToast('Error: ' + e.message, 'error');
  }
}

// ============================================================================
// RESEARCH TAB (WORKBENCH)
// ============================================================================

/**
 * Render research workbench — pipeline-ordered human closed-loop interface.
 * Tabs follow the logical data lifecycle from ingest → enrichment → prospecting → monitoring.
 */
function renderDiaResearch() {
  let html = '<div class="research-workbench">';

  // Queue counts for badges
  const qCount = diaQuarantineQueue ? diaQuarantineQueue.length : null;
  const umCount = diaUnmatchedQueue ? diaUnmatchedQueue.length : null;
  const clCount = diaClarificationQueue ? diaClarificationQueue.length : null;
  const inCount = diaIntakeQueue ? diaIntakeQueue.length : null;
  const prCount = (diaData.propertyReviewQueue || []).length;
  // Honest backlog from the canonical summary (v_clinic_lease_backfill_summary,
  // ~3,039) — NOT the 1,000-capped candidate page. Falls back to the page length
  // only if the summary count didn't load.
  const lbCount = (diaData.leaseBackfillCount != null && diaData.leaseBackfillCount > 0)
    ? diaData.leaseBackfillCount
    : (diaData.leaseBackfillRows || []).length;
  const clLeadCount = diaClinicLeadQueue ? diaClinicLeadQueue.length : null;

  // Pipeline step definitions — ordered from data ingest to prospecting to monitoring
  const pipelineSteps = [
    { key: 'quarantine',     num: '1', label: 'Quarantine',       count: qCount,     phase: 'ingest',      desc: 'Fix bad data caught during ingest' },
    { key: 'unmatched',      num: '2', label: 'Unmatched',        count: umCount,    phase: 'ingest',      desc: 'Link clinics to property records' },
    { key: 'clarification',  num: '3', label: 'Clarification',    count: clCount,    phase: 'ingest',      desc: 'Answer missing required fields' },
    { key: 'intake',         num: '4', label: 'Intake',           count: inCount,    phase: 'ingest',      desc: 'Review email intake documents before DB promotion' },
    { key: 'property',       num: '5', label: 'Property Review',  count: prCount,    phase: 'enrichment',  desc: 'Verify property-clinic links' },
    { key: 'lease',          num: '6', label: 'Lease Backfill',   count: lbCount,    phase: 'enrichment',  desc: 'Research missing lease data' },
    { key: 'ownership',      num: '7', label: 'Ownership',        count: (typeof diaOwnershipBacklog !== 'undefined' && diaOwnershipBacklog) ? diaOwnershipBacklog.length : null, phase: 'enrichment',  desc: 'Resolve LLC chains to real decision-makers' },
    { key: 'clinic_leads',   num: '8', label: 'Clinic Leads',     count: clLeadCount, phase: 'prospecting', desc: 'Qualify leads for outreach' },
    { key: 'staleness',      num: '',  label: 'Staleness',        count: null,       phase: 'monitoring',  desc: 'Data freshness monitoring' },
    { key: 'run_health',     num: '',  label: 'Run Health',       count: null,       phase: 'monitoring',  desc: 'Pipeline run diagnostics' },
  ];

  // Phase labels for visual grouping
  const phases = [
    { key: 'ingest',      label: 'DATA QUALITY',  color: '#f87171', icon: '🛡️' },
    { key: 'enrichment',  label: 'ENRICHMENT',    color: '#fbbf24', icon: '🔍' },
    { key: 'prospecting', label: 'PROSPECTING',   color: '#34d399', icon: '🎯' },
    { key: 'monitoring',  label: 'MONITORING',    color: '#60a5fa', icon: '📊' },
  ];

  // Current step's phase
  const currentStep = pipelineSteps.find(s => s.key === diaResearchMode) || pipelineSteps[0];
  const currentPhase = phases.find(p => p.key === currentStep.phase) || phases[0];

  // === Pipeline progress bar ===
  html += '<div style="display:flex;gap:0;margin-bottom:16px;border-radius:8px;overflow:hidden;border:1px solid var(--border);background:var(--s2);height:4px">';
  phases.forEach(ph => {
    const stepsInPhase = pipelineSteps.filter(s => s.phase === ph.key);
    const isActive = ph.key === currentStep.phase;
    const isPast = phases.indexOf(ph) < phases.indexOf(currentPhase);
    const pct = (stepsInPhase.length / pipelineSteps.length * 100).toFixed(0);
    const bg = isActive ? ph.color : isPast ? ph.color + '60' : 'transparent';
    html += `<div style="flex:${stepsInPhase.length};height:100%;background:${bg};transition:background 0.3s"></div>`;
  });
  html += '</div>';

  // === Tab strip — unified pipeline order ===
  html += '<div style="display:flex;gap:0;margin-bottom:20px;border:1px solid var(--border);border-radius:10px;overflow:hidden;background:var(--s2)">';

  let lastPhase = '';
  pipelineSteps.forEach((step, i) => {
    const isActive = diaResearchMode === step.key;
    const phase = phases.find(p => p.key === step.phase);
    const showSeparator = step.phase !== lastPhase && i > 0;
    lastPhase = step.phase;

    // Phase separator
    if (showSeparator) {
      html += '<div style="width:1px;background:var(--border);flex-shrink:0"></div>';
    }

    // Tab button
    const activeBg = isActive ? phase.color + '18' : 'transparent';
    const activeBorder = isActive ? 'border-bottom:2px solid ' + phase.color + ';' : '';
    const activeColor = isActive ? phase.color : 'var(--text2)';
    const fontWeight = isActive ? '700' : '500';
    const badge = step.count != null && step.count > 0
      ? `<span style="display:inline-block;min-width:18px;text-align:center;padding:1px 5px;border-radius:10px;font-size:9px;font-weight:700;background:${phase.color}20;color:${phase.color};margin-left:4px">${step.count > 999 ? '999+' : step.count}</span>`
      : step.count === 0 ? '<span style="display:inline-block;min-width:18px;text-align:center;padding:1px 5px;border-radius:10px;font-size:9px;font-weight:700;background:var(--s3);color:var(--text3);margin-left:4px">0</span>' : '';
    const numBadge = step.num ? `<span style="display:inline-block;width:16px;height:16px;line-height:16px;text-align:center;border-radius:50%;font-size:9px;font-weight:700;background:${isActive ? phase.color : 'var(--s3)'};color:${isActive ? '#fff' : 'var(--text3)'};margin-right:4px">${step.num}</span>` : '';

    html += `<button data-mode="${step.key}" style="flex:1;padding:10px 6px;font-size:11px;font-weight:${fontWeight};color:${activeColor};background:${activeBg};border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:2px;white-space:nowrap;${activeBorder}transition:all 0.2s" title="${step.desc}">`;
    html += numBadge;
    html += `<span>${step.label}</span>`;
    html += badge;
    html += '</button>';
  });

  html += '</div>';

  // === Phase context header ===
  html += `<div style="padding:10px 14px;background:${currentPhase.color}10;border-radius:8px;border-left:3px solid ${currentPhase.color};margin-bottom:16px;display:flex;align-items:center;gap:10px;">`;
  html += `<span style="font-size:18px">${currentPhase.icon}</span>`;
  html += `<div>`;
  html += `<div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:${currentPhase.color};margin-bottom:2px">${currentPhase.label}${currentStep.num ? ' — Step ' + currentStep.num + ' of 8' : ''}</div>`;
  html += `<div style="font-size:13px;color:var(--text);line-height:1.4"><strong>${currentStep.label}:</strong> ${currentStep.desc}</div>`;
  html += '</div></div>';

  // Live Intake workbench - only show for enrichment/prospecting modes
  const isResearchMode = ['property', 'lease', 'clinic_leads'].includes(diaResearchMode);
  if (isResearchMode) {
    html += renderLiveIngestWorkbench('dialysis');
  }

  // Render selected mode
  if (diaResearchMode === 'quarantine') {
    if (!diaQuarantineQueue) loadDiaQuarantineQueue();
    html += renderDiaQuarantineReview();
  } else if (diaResearchMode === 'unmatched') {
    if (!diaUnmatchedQueue) loadDiaUnmatchedQueue();
    html += renderDiaUnmatchedClinics();
  } else if (diaResearchMode === 'clarification') {
    if (!diaClarificationQueue) loadDiaClarificationQueue();
    html += renderDiaClarificationQueue();
  } else if (diaResearchMode === 'intake') {
    if (!diaIntakeQueue) loadDiaIntakeQueue();
    html += renderDiaIntakeQueue();
  } else if (diaResearchMode === 'property') {
    html += renderDiaPropertyResearch();
  } else if (diaResearchMode === 'lease') {
    html += renderDiaLeaseResearch();
  } else if (diaResearchMode === 'ownership') {
    if (!diaOwnershipBacklog) loadDiaOwnershipBacklog();
    html += renderDiaOwnershipResearch();
  } else if (diaResearchMode === 'clinic_leads') {
    html += renderDiaClinicLeads();
  } else if (diaResearchMode === 'staleness') {
    if (!diaStalenessData) loadDiaStalenessData();
    html += renderDiaStalenessMonitor();
  } else if (diaResearchMode === 'run_health') {
    if (!diaRunHealthData) loadDiaRunHealthData();
    html += renderDiaRunHealth();
  }

  html += '</div>';

  // Attach mode handlers
  setTimeout(() => {
    bindLiveIngestWorkbench('dialysis');
    document.querySelectorAll('[data-mode]').forEach(btn => {
      btn.addEventListener('click', () => {
        diaResearchMode = btn.dataset.mode;
        diaResearchIdx = 0;
        renderDiaTab();
      });
    });
  }, 0);

  return html;
}

// Keyboard shortcuts for dialysis research workflow
(function() {
  document.addEventListener('keydown', function(e) {
    // Only active when a dialysis research card is visible and no input/textarea is focused
    if (!document.querySelector('.research-card') && !document.querySelector('[data-confirm-prop]') && !document.querySelector('[data-verify-lease]') && !document.getElementById('clSaveBtn') && !document.getElementById('clNextBtn')) return;
    var tag = (e.target.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable) return;
    // Only when dialysis tab is active
    if (!document.querySelector('[data-mode="property"]')) return;

    if (e.key === 'k' || e.key === 'K') {
      e.preventDefault();
      // Click the visible skip button
      var skipBtn = document.querySelector('[data-skip-prop]') || document.querySelector('[data-skip-lease]') || document.getElementById('clSkipBtn');
      if (skipBtn) skipBtn.click();
    } else if (e.key === 's' || e.key === 'S') {
      e.preventDefault();
      // Click the visible save/confirm button
      var saveBtn = document.querySelector('[data-confirm-prop]') || document.querySelector('[data-verify-lease]') || document.getElementById('clSaveBtn');
      if (saveBtn) saveBtn.click();
    } else if (e.key === 'n' || e.key === 'N') {
      e.preventDefault();
      // N = Next step in multi-step forms
      if (document.querySelector('[data-verify-lease]')) {
        // Lease backfill: 5 steps (0-4)
        if (diaLeaseBackfillStep < 4) window.diaLeaseStepNav(diaLeaseBackfillStep + 1);
      } else if (document.getElementById('clSaveBtn') || document.getElementById('clNextBtn')) {
        // Clinic leads: 5 steps (0-4)
        if (diaClinicLeadStep < 4) window.diaClStepNav(diaClinicLeadStep + 1);
      }
    } else if (e.key === 'b' || e.key === 'B') {
      e.preventDefault();
      // B = Back step in multi-step forms
      if (document.querySelector('[data-verify-lease]')) {
        if (diaLeaseBackfillStep > 0) window.diaLeaseStepNav(diaLeaseBackfillStep - 1);
      } else if (document.getElementById('clSaveBtn') || document.getElementById('clNextBtn') || document.getElementById('clBackBtn')) {
        if (diaClinicLeadStep > 0) window.diaClStepNav(diaClinicLeadStep - 1);
      }
    } else if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      // Ctrl+Enter (or Cmd+Enter on Mac) saves the current research card
      var saveBtn = document.querySelector('.research-card button[onclick*="save"], .research-card button[onclick*="Save"]');
      if (saveBtn && !saveBtn.disabled) {
        saveBtn.click();
      }
    }
  });
})();

/**
 * Render property review queue section
 */
function renderDiaPropertyResearch() {
  let html = '<div class="research-progress" style="margin-bottom: 30px;">';
  
  const total = diaData.propertyReviewQueue.length;
  const reviewed = diaData.researchOutcomes.filter(o => o.queue_type === 'property_review').length;
  const pct = total > 0 ? Math.round((reviewed / total) * 100) : 0;
  
  html += `<div class="progress-text">${reviewed} of ${total} reviewed (${pct}%)</div>`;
  html += `<div class="progress-bar"><div style="width: ${pct}%; background: #34d399;"></div></div>`;
  html += '</div>';
  
  // Summary metrics
  html += '<div class="gov-metrics" style="margin-bottom: 30px;">';
  
  const pending = diaData.propertyReviewQueue.length;
  const largeClinic = diaData.propertyReviewQueue.filter(r => r.total_patients > 200).length;
  
  html += metricHTML('Pending Review', fmtN(pending), 'items in queue', '');
  html += metricHTML('Large Clinics', fmtN(largeClinic), '200+ patients', '');
  html += metricHTML('States', fmtN(new Set(diaData.propertyReviewQueue.map(r => r.state)).size), 'represented', '');
  html += metricHTML('Avg Patients', fmtN(Math.round(diaData.propertyReviewQueue.reduce((s, r) => s + (r.total_patients || 0), 0) / Math.max(pending, 1))), 'per clinic', '');

  html += '</div>';

  // Recently auto-linked audit panel (collapsible). Surfaces silent
  // auto-link decisions so they can be spot-checked.
  html += renderDiaAutoLinkAuditPanel();

  // Keyboard shortcuts hint
  html += '<div style="display:flex;gap:10px;margin-bottom:12px;padding:6px 10px;background:var(--s2);border-radius:6px;font-size:11px;color:var(--text3);align-items:center;">';
  html += '<span><kbd style="padding:2px 6px;background:var(--s3);border:1px solid var(--border);border-radius:3px;font-size:10px;font-family:monospace;">S</kbd> Save</span>';
  html += '<span><kbd style="padding:2px 6px;background:var(--s3);border:1px solid var(--border);border-radius:3px;font-size:10px;font-family:monospace;">K</kbd> Skip</span>';
  html += '</div>';

  // Filter
  html += '<div class="pills" style="margin: 20px 0;">';
  html += '<button class="pill active" data-filter-type="all">All</button>';
  const reviewTypes = [...new Set(diaData.propertyReviewQueue.map(r => r.review_type))];
  reviewTypes.forEach(type => {
    html += `<button class="pill" data-filter-type="${type}">${type}</button>`;
  });
  html += '</div>';

  // Hide reviewed toggle
  const propReviewedCount = diaData.researchOutcomes.filter(o => o.queue_type === 'property_review').length;
  html += '<div style="display:flex;align-items:center;gap:6px;margin-bottom:12px">';
  html += '<label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:12px;color:var(--text2)">';
  html += '<input type="checkbox" id="propHideReviewed" ' + (diaPropertyFilter.hideReviewed ? 'checked' : '') + ' style="accent-color:var(--accent)" />';
  html += 'Hide reviewed (' + propReviewedCount + ')</label>';
  html += '</div>';

  // Pre-compute filter for operations card (show at top, before list)
  let filtered = diaData.propertyReviewQueue;
  if (diaPropertyFilter.hideReviewed) {
    const reviewedClinicIds = new Set(diaData.researchOutcomes.filter(o => o.queue_type === 'property_review').map(o => o.clinic_id));
    filtered = filtered.filter(r => !reviewedClinicIds.has(r.clinic_id));
  }
  if (diaPropertyFilter.review_type) {
    filtered = filtered.filter(r => r.review_type === diaPropertyFilter.review_type);
  }

  // Round 76ej: Sort by best_fuzzy_score DESC. The view pre-computes match
  // scores against candidate properties; processing high-confidence rows
  // first lets the user drain "click Confirm Link" wins quickly and saves
  // the genuine-research rows (low score / no candidates) for last.
  filtered = filtered.slice().sort((a, b) => {
    const sa = (typeof a.best_fuzzy_score === 'number') ? a.best_fuzzy_score : -1;
    const sb = (typeof b.best_fuzzy_score === 'number') ? b.best_fuzzy_score : -1;
    if (sb !== sa) return sb - sa;
    return (b.total_patients || 0) - (a.total_patients || 0);
  });

  // Operations card — render at the top so it's immediately visible
  if (diaPropertyFilter.selectedIdx !== undefined && filtered[diaPropertyFilter.selectedIdx]) {
    const item = filtered[diaPropertyFilter.selectedIdx];
    html += renderDiaPropertyCard(item);
  }

  // Queue table
  html += '<div class="table-wrapper" style="margin-bottom: 20px;">';
  html += '<div class="data-table">';

  if (filtered.length === 0) {
    const totalPropItems = diaData.propertyReviewQueue.length;
    const reviewedPropItems = diaData.researchOutcomes.filter(o => o.queue_type === 'property_review').length;
    html += '<div class="table-empty">';
    if (diaPropertyFilter.review_type) {
      html += 'No items match the "' + esc(diaPropertyFilter.review_type) + '" filter. <button class="btn-link" onclick="diaPropertyFilter.review_type=null;renderDiaTab()">Show all</button>';
    } else if (totalPropItems === 0) {
      html += 'Property review queue is empty. New items will appear when the data pipeline detects properties needing verification.';
    } else {
      html += 'All ' + totalPropItems + ' items have been reviewed (' + reviewedPropItems + ' outcomes recorded). <button class="btn-link" onclick="diaPropertyFilter.review_type=null;renderDiaTab()">Refresh</button>';
    }
    html += '</div>';
  } else {
    html += '<div class="table-row" style="font-weight: 600; border-bottom: 1px solid var(--border);">';
    html += '<div style="flex: 0.5;">ID</div>';
    html += '<div style="flex: 2;">Facility</div>';
    html += '<div style="flex: 1;">Operator</div>';
    html += '<div style="flex: 0.5;">State</div>';
    html += '<div style="flex: 0.7; text-align: right;">Patients</div>';
    html += '<div style="flex: 0.7;">Match</div>';
    html += '<div style="flex: 1;">Review Type</div>';
    html += '</div>';

    filtered.slice(0, 50).forEach((row, idx) => {
      const isSelected = diaPropertyFilter.selectedIdx === idx;
      const isResolved = diaData.researchOutcomes.some(o => o.clinic_id === row.clinic_id && o.queue_type === 'property_review');
      const rowStyle = isSelected ? 'background: rgba(52, 211, 153, 0.1); border-left: 3px solid var(--accent);' : isResolved ? 'background: rgba(52, 211, 153, 0.05); opacity: 0.7;' : '';
      // Round 76ej: surface the pre-computed fuzzy-match score so the user
      // can see at a glance which rows are quick "Confirm Link" wins vs.
      // genuine research tasks. Color-coded: green ≥0.92, yellow ≥0.75,
      // grey otherwise; "—" when no candidates were found.
      const score = (typeof row.best_fuzzy_score === 'number') ? row.best_fuzzy_score : null;
      const candCount = row.fuzzy_candidate_count || 0;
      let matchCell;
      if (score == null || candCount === 0) {
        matchCell = '<span style="font-size:10px;color:var(--text3)">— no match</span>';
      } else {
        const pct = Math.round(score * 100);
        const color = score >= 0.92 ? '#34d399' : score >= 0.75 ? '#fbbf24' : '#9ca3af';
        const label = score >= 0.92 ? 'Strong' : score >= 0.75 ? 'Likely' : 'Weak';
        matchCell = '<span style="font-size:10px;font-weight:700;padding:1px 6px;border-radius:3px;background:' + color + ';color:#0a0a0a">' + label + ' ' + pct + '%</span>'
          + (candCount > 1 ? ' <span style="font-size:10px;color:var(--text3)">(' + candCount + ')</span>' : '');
      }
      html += `<div class="table-row clickable-row" style="cursor: pointer; ${rowStyle}" data-prop-idx="${idx}">`;
      html += `<div style="flex: 0.5; color: var(--text2);">${esc(String(row.clinic_id || ''))}</div>`;
      html += `<div style="flex: 2;" class="truncate">${esc(row.facility_name || '')}</div>`;
      html += `<div style="flex: 1;">${row.operator_name ? entityLink(row.operator_name, 'operator', null) : ''}</div>`;
      html += `<div style="flex: 0.5;">${esc(row.state || '')}</div>`;
      html += `<div style="flex: 0.7; text-align: right; color: var(--accent);">${fmtN(row.total_patients || 0)}</div>`;
      html += `<div style="flex: 0.7;">${matchCell}</div>`;
      html += `<div style="flex: 1; color: var(--text2);">${esc(row.review_type || '')}</div>`;
      if (isResolved) {
        html += `<div style="flex: 0.3; text-align: right;"><span style="color:var(--green);font-size:16px" title="Resolved">✓</span></div>`;
      } else {
        html += `<div style="flex: 0.3; text-align: right;"><span style="color:var(--accent);font-size:16px" title="Open detail" onclick='event.stopPropagation();showDetail(${safeJSON(row)}, "dia-clinic")'>&rsaquo;</span></div>`;
      }
      html += '</div>';
    });
  }
  
  html += '</div>';
  html += '</div>';

  // Attach handlers
  setTimeout(() => {
    document.querySelectorAll('[data-filter-type]').forEach(btn => {
      btn.addEventListener('click', e => {
        diaPropertyFilter.review_type = e.target.dataset.filterType === 'all' ? null : e.target.dataset.filterType;
        renderDiaTab();
      });
    });
    
    document.querySelectorAll('[data-prop-idx]').forEach(row => {
      row.addEventListener('click', e => {
        const idx = parseInt(e.currentTarget.dataset.propIdx, 10);
        diaPropertyFilter.selectedIdx = idx;
        renderDiaTab();
      });
    });

    const propHideEl = document.getElementById('propHideReviewed');
    if (propHideEl) {
      propHideEl.addEventListener('change', () => {
        diaPropertyFilter.hideReviewed = propHideEl.checked;
        renderDiaTab();
      });
    }
  }, 0);
  
  return html;
}

/**
 * Render property review card
 */
function renderDiaPropertyCard(item) {
  let html = '<div class="research-card" style="display: grid; grid-template-columns: 1fr 400px; gap: 20px; margin-top: 20px;">';

  // Context panel (left) — EXPLAIN the issue and show what needs resolving
  html += '<div class="research-context">';

  // Task header with human-readable explanation
  const reviewType = item.review_type || '';
  const taskExplanations = {
    'multiple_property_candidates': 'This clinic matches multiple properties in our database. Pick the correct one below.',
    'no_property_link': 'This clinic has no linked property record. Search for a matching property or create a new one.',
    'no_exact_property_candidate': 'No exact address match in our property database. Search by name or street, or create a new property.',
    'fuzzy_property_candidates': 'Likely matches found via fuzzy address similarity. Click to link the right one.',
    'single_lower_confidence_candidate': 'One candidate found below. Confirm if correct, or search for the right property.',
    'address_mismatch': 'The clinic address doesn\'t match the linked property. Verify the correct address and update.',
    'stale_match': 'This property link hasn\'t been verified recently. Confirm the link is still correct.',
    'ownership_conflict': 'Ownership data conflicts between sources. Review and confirm the correct owner.',
    'data_quality': 'Data quality flags detected. Review the fields below and correct any errors.'
  };
  const explanation = taskExplanations[reviewType] || ('Review needed: ' + (item.review_reason || reviewType).replace(/_/g, ' '));

  html += '<div style="padding:14px;background:rgba(251,191,36,0.08);border-radius:8px;border-left:3px solid #fbbf24;margin-bottom:16px;">';
  html += '<div style="font-weight:700;font-size:14px;margin-bottom:6px;color:var(--text)">What To Do</div>';
  html += '<div style="font-size:13px;color:var(--text);line-height:1.5;">' + esc(explanation) + '</div>';
  html += '</div>';

  // Clinic context — what we know
  html += '<div style="background:var(--s2);border-radius:8px;padding:14px;margin-bottom:12px;">';
  html += '<div style="font-weight:600;font-size:11px;text-transform:uppercase;letter-spacing:0.5px;color:var(--text3);margin-bottom:10px;">Clinic Record</div>';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:12px;">';
  html += '<div><span style="color:var(--text3)">Facility:</span> <strong>' + esc(item.facility_name || '—') + '</strong></div>';
  html += '<div><span style="color:var(--text3)">Clinic ID:</span> ' + esc(String(item.clinic_id || '—')) + '</div>';
  html += '<div><span style="color:var(--text3)">Operator:</span> ' + (item.operator_name ? entityLink(item.operator_name, 'operator', null) : '—') + '</div>';
  html += '<div><span style="color:var(--text3)">Patients:</span> ' + fmtN(item.total_patients || 0) + '</div>';
  if (item.address) html += '<div><span style="color:var(--text3)">Address:</span> ' + esc(item.address) + '</div>';
  if (item.city || item.state) html += '<div><span style="color:var(--text3)">Location:</span> ' + esc((item.city || '') + (item.city && item.state ? ', ' : '') + (item.state || '')) + '</div>';
  html += '</div></div>';

  // If property_id exists, show linked property
  if (item.property_id) {
    html += '<div style="background:rgba(52,211,153,0.08);border-radius:8px;padding:14px;margin-bottom:12px;border-left:3px solid var(--accent);">';
    html += '<div style="font-weight:600;font-size:11px;text-transform:uppercase;letter-spacing:0.5px;color:var(--accent);margin-bottom:6px;">Currently Linked Property</div>';
    html += '<div style="font-size:12px;">Property #' + item.property_id;
    if (item.property_name) html += ' — ' + esc(item.property_name);
    if (item.property_address) html += '<br>' + esc(item.property_address);
    html += '</div>';
    html += '<button class="btn-action default" style="margin-top:8px;font-size:11px;padding:4px 10px;" onclick=\'showDetail(' + safeJSON(item) + ',"dia-clinic")\'>Open in Detail Panel</button>';
    html += '</div>';
  }

  // Review type detail + suggested candidates (one-click chips)
  const suggested = Array.isArray(item.suggested_candidates) ? item.suggested_candidates : [];
  if (suggested.length > 0) {
    html += renderSuggestedCandidates(item, suggested);
  } else if (item.candidate_types) {
    html += '<div style="background:rgba(251,191,36,0.06);border-radius:8px;padding:14px;margin-bottom:12px;border-left:3px solid #fbbf24;">';
    html += '<div style="font-weight:600;font-size:11px;text-transform:uppercase;letter-spacing:0.5px;color:#fbbf24;margin-bottom:6px;">Property Candidates</div>';
    html += '<div style="font-size:12px;color:var(--text);">' + esc(item.candidate_types) + '</div>';
    html += '<div style="font-size:11px;color:var(--text2);margin-top:4px;">No address-based suggestions — use Search below.</div>';
    html += '</div>';
  }

  // Quick research links
  const searchQ = (item.facility_name || '') + ' ' + (item.address || '') + ' ' + (item.city || '') + ' ' + (item.state || '');
  html += '<div style="display:flex;gap:6px;flex-wrap:wrap;">';
  html += '<a href="https://www.google.com/search?q=' + encodeURIComponent(searchQ.trim()) + '" target="_blank" rel="noopener" style="font-size:11px;padding:4px 10px;border-radius:6px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none;cursor:pointer">Google Search</a>';
  const mapQ = encodeURIComponent((item.address || '') + ' ' + (item.city || '') + ' ' + (item.state || ''));
  html += '<a href="https://www.google.com/maps/search/' + mapQ + '" target="_blank" rel="noopener" style="font-size:11px;padding:4px 10px;border-radius:6px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none;cursor:pointer">Google Maps</a>';
  html += '</div>';

  html += '</div>';

  // Form panel (right)
  html += '<div class="research-form">';

  // Completeness bar
  const fields = [
    { name: 'outcome', value: item.outcome, required: true },
    { name: 'property_id', value: item.property_id, required: item.outcome === 'approved_link' },
    { name: 'source', value: item.verification_source },
    { name: 'notes', value: item.notes }
  ];
  const completeness = computeCompleteness(fields);
  html += renderCompletenessBar(completeness);

  // Outcome
  html += guidedField('propOutcome', 'Outcome', item.outcome, {
    type: 'select',
    required: true,
    options: [
      { label: 'Pending Review', value: 'pending_review' },
      { label: 'Approved Link', value: 'approved_link' },
      { label: 'Needs Research', value: 'needs_research' },
      { label: 'Rejected Candidate', value: 'rejected_candidate' },
      { label: 'Escalated', value: 'escalated' }
    ]
  });

  // === PROPERTY RESOLUTION / SEARCH ===
  // Always show search — for unlinked clinics it's the primary workflow;
  // for linked clinics it lets users check for duplicates or re-link.
  html += renderPropertyResolution(item, 'v_clinic_property_link_review_queue', 'clinic_id');

  // Property ID
  html += guidedField('propPropertyId', 'Property ID', item.property_id, {
    type: 'text',
    required: item.outcome === 'approved_link',
    placeholder: 'Enter linked property ID'
  });

  // Verification Source
  html += guidedField('propSource', 'Verification Source', item.verification_source, {
    type: 'select',
    options: [
      { label: 'CoStar', value: 'costar' },
      { label: 'County Records', value: 'county_records' },
      { label: 'Google', value: 'google' },
      { label: 'Manual Verify', value: 'manual_verify' },
      { label: 'Other', value: 'other' }
    ]
  });

  // Notes
  html += guidedField('propNotes', 'Notes', item.notes, {
    type: 'textarea',
    placeholder: 'Add notes...',
    rows: 3
  });

  // Action row
  html += '<div class="action-row">';
  html += `<button class="btn-action primary" data-confirm-prop="${item.clinic_id}">Confirm Link</button>`;
  html += `<button class="btn-action danger" data-reject-prop="${item.clinic_id}">Reject</button>`;
  html += `<button class="btn-action" data-skip-prop="${item.clinic_id}">Skip</button>`;
  html += '</div>';

  html += '</div>';
  html += '</div>';

  setTimeout(() => {
    const confirmBtn = document.querySelector(`[data-confirm-prop="${item.clinic_id}"]`);
    const rejectBtn = document.querySelector(`[data-reject-prop="${item.clinic_id}"]`);
    const skipBtn = document.querySelector(`[data-skip-prop="${item.clinic_id}"]`);

    if (confirmBtn) {
      confirmBtn.addEventListener('click', async () => {
        const outcome = q('#propOutcome')?.value;
        const propId = q('#propPropertyId')?.value;
        const source = q('#propSource')?.value;
        const notes = q('#propNotes')?.value;

        if (!outcome) {
          showToast('Please select an outcome', 'warning');
          return;
        }

        if (outcome === 'approved_link' && !propId) {
          showToast('Property ID required when approving link', 'warning');
          return;
        }

        confirmBtn.disabled = true;
        confirmBtn.textContent = 'Saving\u2026';
        confirmBtn.style.opacity = '0.6';
        try {
          const ok = await saveDiaOutcome('property_review', item.clinic_id, outcome, propId, notes, source);
          if (!ok) { confirmBtn.disabled = false; confirmBtn.textContent = 'Confirm Link'; confirmBtn.style.opacity = ''; }
        } catch (e) { console.error('confirm link error:', e); showToast('Save failed: ' + e.message, 'error'); confirmBtn.disabled = false; confirmBtn.textContent = 'Confirm Link'; confirmBtn.style.opacity = ''; }
      });
    }

    if (rejectBtn) {
      rejectBtn.addEventListener('click', async () => {
        const notes = q('#propNotes')?.value;
        rejectBtn.disabled = true;
        rejectBtn.textContent = 'Saving\u2026';
        rejectBtn.style.opacity = '0.6';
        try {
          const ok = await saveDiaOutcome('property_review', item.clinic_id, 'rejected_candidate', '', notes);
          if (!ok) { rejectBtn.disabled = false; rejectBtn.textContent = 'Reject'; rejectBtn.style.opacity = ''; }
        } catch (e) { console.error('reject error:', e); showToast('Reject failed: ' + e.message, 'error'); rejectBtn.disabled = false; rejectBtn.textContent = 'Reject'; rejectBtn.style.opacity = ''; }
      });
    }

    if (skipBtn) {
      skipBtn.addEventListener('click', () => {
        const filtered = diaData.propertyReviewQueue.filter(r => !diaPropertyFilter.review_type || r.review_type === diaPropertyFilter.review_type);
        const currentIdx = diaPropertyFilter.selectedIdx || 0;
        if (currentIdx + 1 < filtered.length) {
          diaPropertyFilter.selectedIdx = currentIdx + 1;
          showToast('Skipped \u2014 ' + (currentIdx + 2) + ' / ' + filtered.length, 'info');
        } else {
          diaPropertyFilter.selectedIdx = undefined;
          showToast('End of queue reached', 'info');
        }
        renderDiaTab();
      });
    }
  }, 0);

  return html;
}


// ──────────────────────────────────────────────────────────────────────────
// Lease Backfill — Portfolio Overview (Round 76eh)
//
// Buckets the 4,381-row backfill queue by parent_organization. Each card
// shows the operator's totals (clinics, patients, high-risk, large clinics)
// and one click drills into the per-clinic queue scoped to that operator.
// Drains 64% of the queue into 4 named institutional cards (Fresenius,
// DaVita, USRC, DCI) so the user is no longer scrolling 4K rows.
// ──────────────────────────────────────────────────────────────────────────
function renderDiaLeasePortfolioOverview() {
  const all = diaData.leaseBackfillRows || [];
  const reviewedIds = new Set(diaData.researchOutcomes.filter(o => o.queue_type === 'lease_backfill').map(o => o.clinic_id));

  // Group by operator identity. parent_organization is sometimes NULL on rows
  // that DO have an operator_name set (CMS chain_organization data quality
  // gap). Coalesce to operator_name so the portfolio cards show the real
  // distribution — e.g., 192 Fresenius rows with NULL chain_organization no
  // longer get bucketed as "Independent."
  const groups = new Map();
  for (const row of all) {
    const parent = (row.parent_organization && row.parent_organization.trim()) || '';
    const operator = (row.operator_name && row.operator_name.trim()) || '';
    const key = parent || operator || 'Independent';
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(row);
  }
  // Sort groups by row count desc; surface portfolios with most volume first
  const sortedGroups = Array.from(groups.entries())
    .map(([name, rows]) => {
      const pending = rows.filter(r => !reviewedIds.has(r.clinic_id));
      return {
        name,
        total: rows.length,
        pending: pending.length,
        verified: rows.length - pending.length,
        highRisk: rows.filter(r => r.closure_watch_level === 'high').length,
        largeClinic: rows.filter(r => r.total_patients > 100).length,
        totalPatients: rows.reduce((s, r) => s + (r.total_patients || 0), 0),
        states: new Set(rows.map(r => r.state).filter(Boolean)).size,
      };
    })
    .sort((a, b) => b.pending - a.pending);

  let html = '';

  // Banner — explain the operator-portfolio framing
  html += '<div style="padding:12px 16px;background:rgba(96,165,250,0.08);border-radius:8px;border-left:3px solid #60a5fa;margin-bottom:14px;">';
  html += '<div style="font-weight:700;font-size:13px;margin-bottom:4px;color:var(--text)">Lease Backfill by Operator Portfolio</div>';
  html += '<div style="font-size:12px;color:var(--text2);line-height:1.5">' + fmtN(all.length) + ' clinics with linked properties but no lease record. Most are clustered in 4-5 institutional operators — drain them one portfolio at a time. Click any operator to scope the per-clinic research queue to just that portfolio.</div>';
  html += '</div>';

  // Portfolio cards
  html += '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:12px">';
  for (const g of sortedGroups) {
    const isInstitutional = g.total >= 100;
    const isIndependent = g.name === 'Independent';
    html += '<div style="border:1px solid var(--border);border-left:3px solid ' + (isInstitutional ? '#60a5fa' : isIndependent ? '#a78bfa' : '#fbbf24') + ';border-radius:10px;padding:14px 16px;background:var(--s1);cursor:pointer" data-lease-portfolio="' + esc(g.name) + '">';
    // Header
    html += '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;margin-bottom:8px">';
    html += '<div style="min-width:0;flex:1">';
    html += '<h4 style="margin:0;font-size:14px;font-weight:700;color:var(--text);overflow-wrap:anywhere">' + esc(g.name) + '</h4>';
    html += '<div style="font-size:11px;color:var(--text3);margin-top:2px">' + fmtN(g.states) + ' states · ' + fmtN(g.totalPatients) + ' total patients</div>';
    html += '</div>';
    html += '<div style="text-align:right;flex-shrink:0">';
    html += '<div style="font-size:22px;font-weight:800;color:var(--text);line-height:1">' + fmtN(g.pending) + '</div>';
    html += '<div style="font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:0.5px;margin-top:2px">pending</div>';
    html += '</div>';
    html += '</div>';

    // Mini stats
    html += '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px;font-size:11px;margin-bottom:10px">';
    const _stat = (lbl, val, color) => '<div style="background:var(--s2);padding:6px 8px;border-radius:5px"><div style="color:var(--text3);font-size:9px;text-transform:uppercase;letter-spacing:0.5px">' + lbl + '</div><div style="font-weight:700;color:' + (color || 'var(--text)') + ';font-size:13px;margin-top:1px">' + val + '</div></div>';
    html += _stat('High risk', fmtN(g.highRisk), g.highRisk > 0 ? '#f87171' : 'var(--text2)');
    html += _stat('100+ pts', fmtN(g.largeClinic), g.largeClinic > 0 ? '#fbbf24' : 'var(--text2)');
    html += _stat('Verified', fmtN(g.verified), g.verified > 0 ? 'var(--accent)' : 'var(--text2)');
    html += '</div>';

    // CTA
    html += '<div style="display:flex;justify-content:space-between;align-items:center;font-size:11px;color:var(--text2)">';
    html += '<span>Click to research →</span>';
    html += '<span style="color:var(--text3)">' + (isInstitutional ? 'Institutional operator' : isIndependent ? 'Multiple independent operators' : 'Mid-sized operator') + '</span>';
    html += '</div>';
    html += '</div>';
  }
  html += '</div>';

  return html;
}

function renderDiaLeaseResearch() {
  let html = '';

  // Round 76eh: Portfolio-first view. The 4,381-row queue is mostly clustered
  // in 4 institutional operators (Fresenius/DaVita/USRC/DCI = 64% of rows).
  // Default landing is a per-operator overview so the user can drain one
  // portfolio at a time instead of scrolling a single 4K-row list.
  // Toggle to Per-Clinic mode preserves the existing one-at-a-time workflow.

  // View-mode toggle
  const modeBtn = (key, label) => {
    const active = (diaLeaseFilter.viewMode || 'portfolio') === key;
    return `<button data-lease-view="${key}" style="font-size:12px;font-weight:600;padding:6px 14px;border-radius:6px;border:1px solid ${active ? 'var(--accent)' : 'var(--border)'};background:${active ? 'var(--accent)' : 'var(--s2)'};color:${active ? '#000' : 'var(--text2)'};cursor:pointer">${label}</button>`;
  };
  html += '<div style="display:flex;gap:6px;margin-bottom:14px;align-items:center;justify-content:space-between">';
  html += '<div style="display:flex;gap:6px">';
  html += modeBtn('portfolio', 'Portfolio overview');
  html += modeBtn('clinic', 'Per-clinic queue');
  html += '</div>';
  if (diaLeaseFilter.parentOrg) {
    html += '<div style="display:flex;align-items:center;gap:8px;font-size:12px;color:var(--text2)">';
    html += '<span>Filtered to: <strong style="color:var(--text)">' + esc(diaLeaseFilter.parentOrg) + '</strong></span>';
    html += '<button onclick="diaLeaseFilter.parentOrg=null;diaLeaseFilter.selectedIdx=undefined;renderDiaTab()" style="font-size:11px;padding:3px 8px;border:1px solid var(--border);border-radius:4px;background:var(--s2);color:var(--text2);cursor:pointer">Clear filter</button>';
    html += '</div>';
  }
  html += '</div>';

  // Portfolio mode renders + early-returns
  if ((diaLeaseFilter.viewMode || 'portfolio') === 'portfolio' && !diaLeaseFilter.parentOrg) {
    html += renderDiaLeasePortfolioOverview();
    setTimeout(() => {
      document.querySelectorAll('[data-lease-view]').forEach(btn => {
        btn.addEventListener('click', () => { diaLeaseFilter.viewMode = btn.dataset.leaseView; diaLeaseFilter.selectedIdx = undefined; renderDiaTab(); });
      });
      document.querySelectorAll('[data-lease-portfolio]').forEach(btn => {
        btn.addEventListener('click', () => {
          diaLeaseFilter.parentOrg = btn.dataset.leasePortfolio === '__null__' ? null : btn.dataset.leasePortfolio;
          diaLeaseFilter.viewMode = 'clinic';
          diaLeaseFilter.selectedIdx = undefined;
          renderDiaTab();
        });
      });
    }, 0);
    return html;
  }

  // Per-clinic mode (existing workflow) — wrap with research-progress
  html += '<div class="research-progress" style="margin-bottom: 30px;">';

  // Apply parentOrg filter using the same coalesce key as renderDiaLeasePortfolioOverview
  // so clicking a card always re-filters to that exact bucket.
  const scopedRows = diaLeaseFilter.parentOrg
    ? diaData.leaseBackfillRows.filter(r => {
        const parent = (r.parent_organization && r.parent_organization.trim()) || '';
        const operator = (r.operator_name && r.operator_name.trim()) || '';
        return (parent || operator || 'Independent') === diaLeaseFilter.parentOrg;
      })
    : diaData.leaseBackfillRows;

  const total = scopedRows.length;
  const verified = diaData.researchOutcomes.filter(o => o.queue_type === 'lease_backfill' && o.status === 'verified_lease').length;
  const pct = total > 0 ? Math.round((verified / total) * 100) : 0;

  html += `<div class="progress-text">${verified} of ${total} verified (${pct}%)</div>`;
  html += `<div class="progress-bar"><div style="width: ${pct}%; background: #34d399;"></div></div>`;
  html += '</div>';
  
  // Summary metrics — scoped to current parentOrg filter when active
  html += '<div class="gov-metrics" style="margin-bottom: 30px;">';

  const pending = scopedRows.length;
  const highRisk = scopedRows.filter(r => r.closure_watch_level === 'high').length;
  const largeClinic = scopedRows.filter(r => r.total_patients > 100).length;

  html += metricHTML('Pending Backfill', fmtN(pending), 'lease candidates', '');
  html += metricHTML('High Risk', fmtN(highRisk), 'closure watch', '');
  html += metricHTML('Large Clinics', fmtN(largeClinic), '100+ patients', '');
  html += metricHTML('Avg Patients', fmtN(Math.round(scopedRows.reduce((s, r) => s + (r.total_patients || 0), 0) / Math.max(pending, 1))), 'per clinic', '');

  html += '</div>';

  // Keyboard shortcuts hint
  html += '<div style="display:flex;gap:10px;margin-bottom:12px;padding:6px 10px;background:var(--s2);border-radius:6px;font-size:11px;color:var(--text3);align-items:center;">';
  html += '<span><kbd style="padding:2px 6px;background:var(--s3);border:1px solid var(--border);border-radius:3px;font-size:10px;font-family:monospace;">S</kbd> Save</span>';
  html += '<span><kbd style="padding:2px 6px;background:var(--s3);border:1px solid var(--border);border-radius:3px;font-size:10px;font-family:monospace;">N</kbd> Next</span>';
  html += '<span><kbd style="padding:2px 6px;background:var(--s3);border:1px solid var(--border);border-radius:3px;font-size:10px;font-family:monospace;">B</kbd> Back</span>';
  html += '<span><kbd style="padding:2px 6px;background:var(--s3);border:1px solid var(--border);border-radius:3px;font-size:10px;font-family:monospace;">K</kbd> Skip</span>';
  html += '</div>';

  // Filter
  html += '<div class="pills" style="margin: 20px 0;">';
  html += '<button class="pill active" data-filter-priority="all">All</button>';
  ['high', 'medium', 'low'].forEach(priority => {
    html += `<button class="pill" data-filter-priority="${priority}">${priority}</button>`;
  });
  html += '</div>';

  // Hide reviewed toggle
  const leaseReviewedCount = diaData.researchOutcomes.filter(o => o.queue_type === 'lease_backfill').length;
  html += '<div style="display:flex;align-items:center;gap:6px;margin-bottom:12px">';
  html += '<label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:12px;color:var(--text2)">';
  html += '<input type="checkbox" id="leaseHideReviewed" ' + (diaLeaseFilter.hideReviewed ? 'checked' : '') + ' style="accent-color:var(--accent)" />';
  html += 'Hide reviewed (' + leaseReviewedCount + ')</label>';
  html += '</div>';

  // Queue table
  html += '<div class="table-wrapper" style="margin-bottom: 20px;">';
  html += '<div class="data-table">';

  let filtered = scopedRows;
  if (diaLeaseFilter.hideReviewed) {
    const reviewedLeaseIds = new Set(diaData.researchOutcomes.filter(o => o.queue_type === 'lease_backfill').map(o => o.clinic_id));
    filtered = filtered.filter(r => !reviewedLeaseIds.has(r.clinic_id));
  }
  if (diaLeaseFilter.priority) {
    filtered = filtered.filter(r => r.lease_backfill_priority === diaLeaseFilter.priority);
  }

  // Operations card — render at the top so it's immediately visible
  if (diaLeaseFilter.selectedIdx !== undefined && filtered[diaLeaseFilter.selectedIdx]) {
    const item = filtered[diaLeaseFilter.selectedIdx];
    html += renderDiaLeaseCard(item);
  }

  if (filtered.length === 0) {
    const totalLeaseItems = diaData.leaseBackfillRows.length;
    const verifiedLeaseItems = diaData.researchOutcomes.filter(o => o.queue_type === 'lease_backfill' && o.status === 'verified_lease').length;
    html += '<div class="table-empty">';
    if (diaLeaseFilter.priority) {
      html += 'No items match the "' + esc(diaLeaseFilter.priority) + '" priority filter. <button class="btn-link" onclick="diaLeaseFilter.priority=null;renderDiaTab()">Show all</button>';
    } else if (totalLeaseItems === 0) {
      html += 'Lease backfill queue is empty. New items will appear when clinics are identified that need lease data.';
    } else {
      html += 'All ' + totalLeaseItems + ' items have been processed (' + verifiedLeaseItems + ' leases verified). <button class="btn-link" onclick="diaLeaseFilter.priority=null;renderDiaTab()">Refresh</button>';
    }
    html += '</div>';
  } else {
    html += '<div class="table-row" style="font-weight: 600; border-bottom: 1px solid var(--border);">';
    html += '<div style="flex: 0.5;">ID</div>';
    html += '<div style="flex: 2;">Facility</div>';
    html += '<div style="flex: 1;">Operator</div>';
    html += '<div style="flex: 0.7; text-align: right;">Patients</div>';
    html += '<div style="flex: 1;">Watch Level</div>';
    html += '<div style="flex: 1;">Priority</div>';
    html += '</div>';

    filtered.slice(0, 50).forEach((row, idx) => {
      const watchColor = row.closure_watch_level === 'high' ? '#f87171' : 'var(--text2)';
      const isSelected = diaLeaseFilter.selectedIdx === idx;
      const isResolved = diaData.researchOutcomes.some(o => o.clinic_id === row.clinic_id && o.queue_type === 'lease_backfill');
      const rowStyle = isSelected ? 'background: rgba(52, 211, 153, 0.1); border-left: 3px solid var(--accent);' : isResolved ? 'background: rgba(52, 211, 153, 0.05); opacity: 0.7;' : '';

      html += `<div class="table-row clickable-row" style="cursor: pointer; ${rowStyle}" data-lease-idx="${idx}">`;
      html += `<div style="flex: 0.5; color: var(--text2);">${esc(String(row.clinic_id || ''))}</div>`;
      html += `<div style="flex: 2;" class="truncate">${esc(row.facility_name || '')}</div>`;
      html += `<div style="flex: 1;">${row.operator_name ? entityLink(row.operator_name, 'operator', null) : ''}</div>`;
      html += `<div style="flex: 0.7; text-align: right; color: var(--accent);">${fmtN(row.total_patients || 0)}</div>`;
      html += `<div style="flex: 1; color: ${watchColor};">${esc(row.closure_watch_level || 'none')}</div>`;
      html += `<div style="flex: 1; color: var(--text2);">${esc(row.lease_backfill_priority || 'unknown')}</div>`;
      if (isResolved) {
        html += `<div style="flex: 0.3; text-align: right;"><span style="color:var(--green);font-size:16px" title="Resolved">✓</span></div>`;
      } else {
        html += `<div style="flex: 0.3; text-align: right;"><span style="color:var(--accent);font-size:16px" title="Open detail" onclick='event.stopPropagation();showDetail(${safeJSON(row)}, "dia-clinic")'>&rsaquo;</span></div>`;
      }
      html += '</div>';
    });
  }
  
  html += '</div>';
  html += '</div>';

  // Attach handlers
  setTimeout(() => {
    document.querySelectorAll('[data-lease-view]').forEach(btn => {
      btn.addEventListener('click', () => {
        diaLeaseFilter.viewMode = btn.dataset.leaseView;
        diaLeaseFilter.selectedIdx = undefined;
        renderDiaTab();
      });
    });
    document.querySelectorAll('[data-filter-priority]').forEach(btn => {
      btn.addEventListener('click', e => {
        diaLeaseFilter.priority = e.target.dataset.filterPriority === 'all' ? null : e.target.dataset.filterPriority;
        renderDiaTab();
      });
    });
    
    document.querySelectorAll('[data-lease-idx]').forEach(row => {
      row.addEventListener('click', e => {
        const idx = parseInt(e.currentTarget.dataset.leaseIdx, 10);
        diaLeaseFilter.selectedIdx = idx;
        renderDiaTab();
      });
    });

    const leaseHideEl = document.getElementById('leaseHideReviewed');
    if (leaseHideEl) {
      leaseHideEl.addEventListener('change', () => {
        diaLeaseFilter.hideReviewed = leaseHideEl.checked;
        renderDiaTab();
      });
    }
  }, 0);
  
  return html;
}

/**
 * Render lease backfill card
 */
function renderDiaLeaseCard(item) {
  const step = diaLeaseBackfillStep || 0;
  let html = '<div class="research-card" style="display: grid; grid-template-columns: 1fr 400px; gap: 20px; margin-bottom: 20px;">';

  // Context panel (left) — explain what's needed and show current data
  html += '<div class="research-context">';

  // Human-readable task explanation
  const backfillExplanations = {
    'no_lease_data': 'This clinic has no lease information on file. Research and enter the lease terms.',
    'expired_lease': 'The lease on file has expired. Verify if the lease was renewed and update the terms.',
    'missing_rent': 'Lease exists but annual rent is missing. Find and enter the rent amount.',
    'missing_term': 'Lease exists but the term/expiration is missing. Find and enter the lease term.',
    'stale_data': 'Lease data hasn\'t been updated in over 12 months. Verify current terms.',
  };
  const explanation = backfillExplanations[item.backfill_reason] || ('Lease data needed: ' + (item.backfill_reason || 'missing information').replace(/_/g, ' '));

  html += '<div style="padding:14px;background:rgba(251,191,36,0.08);border-radius:8px;border-left:3px solid #fbbf24;margin-bottom:16px;">';
  html += '<div style="font-weight:700;font-size:14px;margin-bottom:6px;color:var(--text)">What To Do</div>';
  html += '<div style="font-size:13px;color:var(--text);line-height:1.5;">' + esc(explanation) + '</div>';
  html += '</div>';

  // Clinic context
  html += '<div style="background:var(--s2);border-radius:8px;padding:14px;margin-bottom:12px;">';
  html += '<div style="font-weight:600;font-size:11px;text-transform:uppercase;letter-spacing:0.5px;color:var(--text3);margin-bottom:10px;">Clinic Info</div>';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:12px;">';
  html += '<div><span style="color:var(--text3)">Facility:</span> <strong>' + esc(item.facility_name || '\u2014') + '</strong></div>';
  html += '<div><span style="color:var(--text3)">Clinic ID:</span> ' + esc(String(item.clinic_id || '\u2014')) + '</div>';
  html += '<div><span style="color:var(--text3)">Operator:</span> ' + (item.operator_name ? entityLink(item.operator_name, 'operator', null) : '\u2014') + '</div>';
  html += '<div><span style="color:var(--text3)">Patients:</span> ' + fmtN(item.total_patients || 0) + '</div>';
  if (item.address) html += '<div><span style="color:var(--text3)">Address:</span> ' + esc(item.address) + '</div>';
  if (item.city || item.state) html += '<div><span style="color:var(--text3)">Location:</span> ' + esc((item.city || '') + (item.city && item.state ? ', ' : '') + (item.state || '')) + '</div>';
  html += '</div></div>';

  // Current lease data on file — show what exists vs. what's missing
  html += '<div style="background:var(--s2);border-radius:8px;padding:14px;margin-bottom:12px;">';
  html += '<div style="font-weight:600;font-size:11px;text-transform:uppercase;letter-spacing:0.5px;color:var(--text3);margin-bottom:10px;">Lease Data On File</div>';
  const leaseFields = [
    { label: 'Property ID', value: item.property_id, key: 'property_id' },
    { label: 'Lease Term', value: item.lease_term, key: 'lease_term' },
    { label: 'Annual Rent', value: item.annual_rent ? '$' + fmtN(Math.round(item.annual_rent)) : null, key: 'annual_rent' },
    { label: 'Rent/SF', value: item.rent_per_sf ? '$' + Number(item.rent_per_sf).toFixed(2) : null, key: 'rent_per_sf' },
    { label: 'Expiration', value: item.lease_expiration, key: 'lease_expiration' },
    { label: 'Watch Level', value: item.closure_watch_level, key: 'closure_watch_level' },
  ];
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;font-size:12px;">';
  leaseFields.forEach(f => {
    const hasVal = f.value != null && String(f.value).trim() !== '';
    const icon = hasVal ? '<span style="color:var(--success)">\u2713</span>' : '<span style="color:#f87171">\u25CB</span>';
    html += '<div>' + icon + ' <span style="color:var(--text3)">' + f.label + ':</span> ' + (hasVal ? '<strong>' + esc(String(f.value)) + '</strong>' : '<span style="color:#f87171">Missing</span>') + '</div>';
  });
  html += '</div></div>';

  // Quick research links
  const searchQ = (item.facility_name || '') + ' ' + (item.address || '') + ' ' + (item.city || '') + ' ' + (item.state || '') + ' lease';
  html += '<div style="display:flex;gap:6px;flex-wrap:wrap;">';
  html += '<a href="https://www.google.com/search?q=' + encodeURIComponent(searchQ.trim()) + '" target="_blank" rel="noopener" style="font-size:11px;padding:4px 10px;border-radius:6px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none;cursor:pointer">Google Search</a>';
  if (item.city && item.state) {
    html += '<a href="https://www.google.com/search?q=' + encodeURIComponent(item.city + ' ' + item.state + ' county property records') + '" target="_blank" rel="noopener" style="font-size:11px;padding:4px 10px;border-radius:6px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none;cursor:pointer">County Records</a>';
  }
  html += '<button class="btn-action default" style="font-size:11px;padding:4px 10px;" onclick=\'showDetail(' + safeJSON(item) + ',"dia-clinic")\'>Open Detail Panel</button>';
  html += '</div>';

  html += '</div>';

  // Form panel (right) — 5-step workflow
  html += '<div class="research-form">';

  // Completeness bar
  const cFields = [
    { name: 'outcome', value: item.outcome, required: true },
    { name: 'property_id', value: item.property_id, required: item.outcome === 'verified_lease' },
    { name: 'lease_term', value: item.lease_term },
    { name: 'annual_rent', value: item.annual_rent },
    { name: 'rent_per_sf', value: item.rent_per_sf },
    { name: 'source', value: item.lease_source },
    { name: 'notes', value: item.notes }
  ];
  const completeness = computeCompleteness(cFields);
  html += renderCompletenessBar(completeness);

  // Step navigation
  const steps = [
    { label: 'Lease Details', complete: !!item.outcome && item.outcome !== 'pending_backfill' },
    { label: 'Rent Schedule', complete: !!item.annual_rent || !!item.rent_per_sf },
    { label: 'Property', complete: !!item.property_id },
    { label: 'Financing', complete: !!item.lender_name || !!item.loan_amount },
    { label: 'Notes', complete: !!item.notes }
  ];
  html += renderStepNav(step, steps, 'window.diaLeaseStepNav');

  // ===== Step 0: Lease Details =====
  html += '<div class="form-step" style="display:' + (step === 0 ? 'block' : 'none') + ';margin-top:16px">';
  html += '<div class="form-step-head"><h4 style="margin:0;font-size:13px;font-weight:700">Step 1: Lease Details</h4></div>';

  html += guidedField('leaseOutcome', 'Outcome', item.outcome, {
    type: 'select', required: true,
    options: [
      { label: 'Pending Backfill', value: 'pending_backfill' },
      { label: 'Requested Lease', value: 'requested_lease' },
      { label: 'Verified Lease', value: 'verified_lease' },
      { label: 'Not Owned', value: 'not_owned' },
      { label: 'Escalated', value: 'escalated' }
    ]
  });
  html += guidedField('leaseTerm', 'Lease Term', item.lease_term, { type: 'text', placeholder: 'e.g., 10 years' });
  html += guidedField('leaseExpiration', 'Lease Expiration', item.lease_expiration, { type: 'date' });
  html += guidedField('leaseSource', 'Lease Source', item.lease_source, {
    type: 'select',
    options: [
      { label: 'CoStar', value: 'costar' },
      { label: 'Direct Contact', value: 'direct_contact' },
      { label: 'County Records', value: 'county_records' },
      { label: 'Broker', value: 'broker' },
      { label: 'Other', value: 'other' }
    ]
  });
  html += '</div>';

  // ===== Step 1: Rent Schedule =====
  html += '<div class="form-step" style="display:' + (step === 1 ? 'block' : 'none') + ';margin-top:16px">';
  html += '<div class="form-step-head"><h4 style="margin:0;font-size:13px;font-weight:700">Step 2: Rent Schedule</h4></div>';

  html += guidedField('leaseRent', 'Current Annual Rent', item.annual_rent, { type: 'number', placeholder: '$' });
  html += guidedField('leaseRentSF', 'Rent/SF', item.rent_per_sf, { type: 'number', placeholder: '$', step: 0.01 });
  html += guidedField('leaseEscalations', 'Escalations', item.escalations, { type: 'text', placeholder: 'e.g., 2% annual, CPI, fixed' });

  // Prior Leases — bulk entry section
  html += '<div style="margin-top:16px;border-top:1px solid var(--border);padding-top:12px">';
  html += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">';
  html += '<div style="font-weight:600;font-size:12px;color:var(--text)">Prior Leases</div>';
  html += '<button id="addPriorLease" style="font-size:11px;padding:4px 10px;border-radius:6px;background:var(--accent);color:#fff;border:none;cursor:pointer;font-weight:600">+ Add Row</button>';
  html += '</div>';

  // Table header for prior leases
  html += '<div style="font-size:10px;font-weight:600;color:var(--text3);display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr 30px;gap:4px;margin-bottom:4px;text-transform:uppercase;letter-spacing:0.5px">';
  html += '<div>Start</div><div>End</div><div>Annual Rent</div><div>Rent/SF</div><div>Escalations</div><div></div>';
  html += '</div>';

  // Existing prior lease rows container
  html += '<div id="priorLeaseRows">';
  var priorLeases = window._diaLeaseFormDraft._priorLeases || [{}];
  priorLeases.forEach(function(pl, pi) {
    html += _renderPriorLeaseRow(pi, pl);
  });
  html += '</div>';
  html += '</div>';
  html += '</div>';

  // ===== Step 2: Property =====
  html += '<div class="form-step" style="display:' + (step === 2 ? 'block' : 'none') + ';margin-top:16px">';
  html += '<div class="form-step-head"><h4 style="margin:0;font-size:13px;font-weight:700">Step 3: Property</h4></div>';
  html += guidedField('leasePropertyId', 'Property ID', item.property_id, { type: 'text', placeholder: 'Enter property ID' });
  html += renderPropertyResolution(item, 'lease_backfill', 'clinic_id');
  html += '</div>';

  // ===== Step 3: Financing =====
  html += '<div class="form-step" style="display:' + (step === 3 ? 'block' : 'none') + ';margin-top:16px">';
  html += '<div class="form-step-head"><h4 style="margin:0;font-size:13px;font-weight:700">Step 4: Financing</h4></div>';
  html += guidedField('leaseLender', 'Lender', item.lender_name, { type: 'text', placeholder: 'Lender name' });
  html += guidedField('leaseLoanAmount', 'Loan Amount', item.loan_amount, { type: 'number', placeholder: '$' });
  html += guidedField('leaseLoanType', 'Loan Type', item.loan_type, {
    type: 'select',
    options: [
      { label: 'Fixed', value: 'fixed' },
      { label: 'Variable', value: 'variable' },
      { label: 'CMBS', value: 'cmbs' },
      { label: 'SBA', value: 'sba' },
      { label: 'Other', value: 'other' }
    ]
  });
  html += guidedField('leaseLoanMaturity', 'Loan Maturity', item.loan_maturity_date, { type: 'date' });
  html += '</div>';

  // ===== Step 4: Notes =====
  html += '<div class="form-step" style="display:' + (step === 4 ? 'block' : 'none') + ';margin-top:16px">';
  html += '<div class="form-step-head"><h4 style="margin:0;font-size:13px;font-weight:700">Step 5: Notes</h4></div>';
  html += guidedField('leaseNotes', 'Notes', item.notes, { type: 'textarea', placeholder: 'Add notes...', rows: 4 });
  html += '</div>';

  // Action buttons — always visible
  html += '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px">';
  if (step > 0) {
    html += '<button id="leaseBackBtn" style="padding:10px 16px;background:var(--s2);border:1px solid var(--border);border-radius:8px;font-size:13px;cursor:pointer;color:var(--text2)">\u2190 Back</button>';
  }
  if (step < 4) {
    html += '<button id="leaseNextBtn" style="flex:1;padding:10px;background:var(--accent);color:#fff;border:none;border-radius:8px;font-weight:600;font-size:13px;cursor:pointer">Next \u2192</button>';
  }
  html += '<button class="btn-action primary" data-verify-lease="' + item.clinic_id + '" style="' + (step === 4 ? 'flex:1;' : '') + 'padding:10px 16px;font-size:13px">Verify Lease</button>';
  html += '<button class="btn-action warn" data-notowned-lease="' + item.clinic_id + '" style="padding:10px 16px;font-size:13px">Not Owned</button>';
  html += '<button class="btn-action" data-skip-lease="' + item.clinic_id + '" style="padding:10px 16px;font-size:13px">Skip</button>';
  html += '</div>';

  html += '</div>';
  html += '</div>';

  setTimeout(function() {
    // Step navigation buttons
    var backBtn = document.getElementById('leaseBackBtn');
    var nextBtn = document.getElementById('leaseNextBtn');
    if (backBtn) backBtn.addEventListener('click', function() { window.diaLeaseStepNav(step - 1); });
    if (nextBtn) nextBtn.addEventListener('click', function() { window.diaLeaseStepNav(step + 1); });

    // Prior lease add/remove
    var addBtn = document.getElementById('addPriorLease');
    if (addBtn) {
      addBtn.addEventListener('click', function() {
        _capturePriorLeases();
        window._diaLeaseFormDraft._priorLeases.push({});
        renderDiaTab();
      });
    }
    document.querySelectorAll('[data-remove-prior]').forEach(function(btn) {
      btn.addEventListener('click', function() {
        _capturePriorLeases();
        var idx = parseInt(btn.dataset.removePrior, 10);
        window._diaLeaseFormDraft._priorLeases.splice(idx, 1);
        if (window._diaLeaseFormDraft._priorLeases.length === 0) window._diaLeaseFormDraft._priorLeases = [{}];
        renderDiaTab();
      });
    });

    // Save / action buttons
    var verifyBtn = document.querySelector('[data-verify-lease="' + item.clinic_id + '"]');
    var notownedBtn = document.querySelector('[data-notowned-lease="' + item.clinic_id + '"]');
    var skipBtn = document.querySelector('[data-skip-lease="' + item.clinic_id + '"]');

    if (verifyBtn) {
      verifyBtn.addEventListener('click', async function() {
        var outcome = q('#leaseOutcome') ? q('#leaseOutcome').value : '';
        var propId = q('#leasePropertyId') ? q('#leasePropertyId').value : '';
        var term = q('#leaseTerm') ? q('#leaseTerm').value : '';
        var rent = q('#leaseRent') ? q('#leaseRent').value : '';
        var rentSF = q('#leaseRentSF') ? q('#leaseRentSF').value : '';
        var source = q('#leaseSource') ? q('#leaseSource').value : '';
        var notes = q('#leaseNotes') ? q('#leaseNotes').value : '';

        if (!outcome) { showToast('Please select an outcome', 'warning'); return; }
        if (outcome === 'verified_lease' && !propId) { showToast('Property ID required when verifying lease', 'warning'); return; }

        verifyBtn.disabled = true;
        verifyBtn.textContent = 'Saving\u2026';
        verifyBtn.style.opacity = '0.6';
        try {
          var ok = await saveDiaOutcome('lease_backfill', item.clinic_id, outcome, propId, notes, source, term, rent, rentSF);
          if (ok) { diaLeaseBackfillStep = 0; window._diaLeaseFormDraft = {}; }
          else { verifyBtn.disabled = false; verifyBtn.textContent = 'Verify Lease'; verifyBtn.style.opacity = ''; }
        } catch (e) { console.error('verify lease error:', e); showToast('Save failed: ' + e.message, 'error'); verifyBtn.disabled = false; verifyBtn.textContent = 'Verify Lease'; verifyBtn.style.opacity = ''; }
      });
    }

    if (notownedBtn) {
      notownedBtn.addEventListener('click', async function() {
        var notes = q('#leaseNotes') ? q('#leaseNotes').value : '';
        notownedBtn.disabled = true;
        notownedBtn.textContent = 'Saving\u2026';
        notownedBtn.style.opacity = '0.6';
        try {
          var ok = await saveDiaOutcome('lease_backfill', item.clinic_id, 'not_owned', '', notes);
          if (ok) { diaLeaseBackfillStep = 0; window._diaLeaseFormDraft = {}; }
          else { notownedBtn.disabled = false; notownedBtn.textContent = 'Not Owned'; notownedBtn.style.opacity = ''; }
        } catch (e) { console.error('not owned error:', e); showToast('Save failed: ' + e.message, 'error'); notownedBtn.disabled = false; notownedBtn.textContent = 'Not Owned'; notownedBtn.style.opacity = ''; }
      });
    }

    if (skipBtn) {
      skipBtn.addEventListener('click', function() {
        var filteredRows = diaData.leaseBackfillRows.filter(function(r) { return !diaLeaseFilter.priority || r.lease_backfill_priority === diaLeaseFilter.priority; });
        var currentIdx = diaLeaseFilter.selectedIdx || 0;
        diaLeaseBackfillStep = 0;
        window._diaLeaseFormDraft = {};
        if (currentIdx + 1 < filteredRows.length) {
          diaLeaseFilter.selectedIdx = currentIdx + 1;
          showToast('Skipped \u2014 ' + (currentIdx + 2) + ' / ' + filteredRows.length, 'info');
        } else {
          diaLeaseFilter.selectedIdx = undefined;
          showToast('End of queue reached', 'info');
        }
        renderDiaTab();
      });
    }
  }, 0);

  return html;
}

// Helper: render a prior lease row for bulk entry
function _renderPriorLeaseRow(idx, data) {
  var d = data || {};
  var html = '<div class="prior-lease-row" style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr 30px;gap:4px;margin-bottom:4px">';
  html += '<input type="date" id="pl-start-' + idx + '" value="' + esc(d.start_date || '') + '" style="font-size:11px;padding:4px 6px;border:1px solid var(--border);border-radius:4px;background:var(--s2);color:var(--text);box-sizing:border-box" />';
  html += '<input type="date" id="pl-end-' + idx + '" value="' + esc(d.end_date || '') + '" style="font-size:11px;padding:4px 6px;border:1px solid var(--border);border-radius:4px;background:var(--s2);color:var(--text);box-sizing:border-box" />';
  html += '<input type="number" id="pl-rent-' + idx + '" value="' + esc(d.annual_rent || '') + '" placeholder="$" style="font-size:11px;padding:4px 6px;border:1px solid var(--border);border-radius:4px;background:var(--s2);color:var(--text);box-sizing:border-box" />';
  html += '<input type="number" id="pl-rentsf-' + idx + '" value="' + esc(d.rent_psf || '') + '" placeholder="$/SF" step="0.01" style="font-size:11px;padding:4px 6px;border:1px solid var(--border);border-radius:4px;background:var(--s2);color:var(--text);box-sizing:border-box" />';
  html += '<input type="text" id="pl-esc-' + idx + '" value="' + esc(d.escalations || '') + '" placeholder="2% annual" style="font-size:11px;padding:4px 6px;border:1px solid var(--border);border-radius:4px;background:var(--s2);color:var(--text);box-sizing:border-box" />';
  html += '<button data-remove-prior="' + idx + '" style="font-size:14px;background:none;border:none;color:#f87171;cursor:pointer;padding:0" title="Remove">\u00D7</button>';
  html += '</div>';
  return html;
}

// Capture prior lease row values into draft
function _capturePriorLeases() {
  var rows = document.querySelectorAll('.prior-lease-row');
  var leases = [];
  rows.forEach(function(row, i) {
    var startEl = document.getElementById('pl-start-' + i);
    var endEl = document.getElementById('pl-end-' + i);
    var rentEl = document.getElementById('pl-rent-' + i);
    var rentsfEl = document.getElementById('pl-rentsf-' + i);
    var escEl = document.getElementById('pl-esc-' + i);
    leases.push({
      start_date: startEl ? startEl.value : '',
      end_date: endEl ? endEl.value : '',
      annual_rent: rentEl ? rentEl.value : '',
      rent_psf: rentsfEl ? rentsfEl.value : '',
      escalations: escEl ? escEl.value : ''
    });
  });
  window._diaLeaseFormDraft._priorLeases = leases;
}


// ============================================================================
// OWNERSHIP RESEARCH WORKBENCH (Layer H.5 — frontend for the backlog series)
// ============================================================================
//
// Surfaces the canonical-name leverage list from
// v_recorded_owner_canonical_clusters so Scott can resolve one SPE name
// and fix multiple properties. Each row = one canonical entity (e.g.
// "SMBC Leasing & Finance Inc"), showing how many name variants exist
// and how many dialysis properties currently sit under that canonical.
//
// Clicking a row opens a sample property in the detail drawer where the
// existing Resolve Ownership form can be used to set the true_owner_id.
// When that fires, the migration-V propagation trigger auto-fills any
// linked properties whose true_owner_id is NULL — so one click can
// resolve dozens of buildings.

function renderDiaOwnershipResearch() {
  if (diaOwnershipBacklog === null) {
    return '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading ownership backlog…</p></div>';
  }
  const rows = diaOwnershipBacklog || [];
  const filterText  = (diaOwnershipFilterText || '').toLowerCase().trim();
  const filterState = (diaOwnershipFilterState || '').toUpperCase().trim();
  const filtered = rows.filter(r => {
    if (filterText && !(r.canonical || '').toLowerCase().includes(filterText)) return false;
    return true;
  });
  // filterState is reserved for future use (cluster view doesn't carry
  // state today). Drilldown into the per-property backlog will respect it.

  // Top metrics
  const totalClusters     = rows.length;
  const totalProperties   = rows.reduce((s, r) => s + (r.canonical_total_properties || 0), 0);
  const totalVariants     = rows.reduce((s, r) => s + (r.cluster_size || 0), 0);
  const top5Properties    = rows.slice(0, 5).reduce((s, r) => s + (r.canonical_total_properties || 0), 0);

  let html = '<div class="ownership-research-workbench">';

  // Context header
  html += '<div style="padding:12px 14px;background:var(--s2);border:1px solid var(--border);border-radius:8px;margin-bottom:14px">';
  html += '<div style="font-size:13px;color:var(--text);line-height:1.5">';
  html += '<strong>Ownership research backlog.</strong> Each row is one canonical entity (e.g. "SMBC Leasing & Finance Inc") that has multiple recorded_owner name variants in our deed data. ';
  html += 'Resolving the canonical&rsquo;s true_owner_id once via the property detail panel auto-fills any linked properties whose true_owner is still NULL ';
  html += '(via the migration-V propagation trigger). Sorted by total properties &mdash; biggest leverage first.';
  html += '</div></div>';

  // Metrics row
  html += '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:14px">';
  const metric = (label, value, sub, color) =>
    `<div style="background:var(--s2);border:1px solid var(--border);border-left:3px solid ${color};border-radius:8px;padding:10px 14px">` +
    `<div style="font-size:10px;text-transform:uppercase;letter-spacing:0.5px;color:var(--text3);margin-bottom:4px">${esc(label)}</div>` +
    `<div style="font-size:20px;font-weight:700;color:var(--text)">${esc(value)}</div>` +
    `<div style="font-size:11px;color:var(--text2);margin-top:2px">${esc(sub)}</div>` +
    `</div>`;
  html += metric('Canonical clusters', fmtN(totalClusters),        'distinct research targets', '#62B5E5');
  html += metric('Properties covered', fmtN(totalProperties),      'under a canonical', '#34d399');
  html += metric('Total variants',     fmtN(totalVariants),        'recorded_owners rows', '#fbbf24');
  html += metric('Top-5 properties',   fmtN(top5Properties),       'resolve these first', '#a855e8');
  html += '</div>';

  // Filter / search
  html += '<div style="display:flex;gap:8px;margin-bottom:12px;align-items:center">';
  html += `<input id="ownershipBacklogFilter" type="text" value="${esc(diaOwnershipFilterText || '')}" placeholder="Filter canonical name…" style="flex:1;padding:6px 10px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);font-size:12px">`;
  html += '<button id="ownershipBacklogRefresh" style="padding:6px 14px;border-radius:6px;border:1px solid var(--border);background:var(--s2);color:var(--text2);cursor:pointer;font-size:12px">Refresh</button>';
  html += '</div>';

  // Empty state
  if (!filtered.length) {
    html += '<div style="text-align:center;padding:48px;color:var(--text3);background:var(--s2);border:1px dashed var(--border);border-radius:8px">';
    html += rows.length === 0
      ? 'No canonical clusters yet &mdash; v_recorded_owner_canonical_clusters returned 0 rows. Run dia_unify_canonical_true_owners on the DB to seed.'
      : 'No clusters match your filter.';
    html += '</div></div>';
    return html;
  }

  // Top leverage table
  html += '<div style="background:var(--s2);border:1px solid var(--border);border-radius:8px;overflow:hidden">';
  html += '<div style="display:flex;padding:10px 14px;font-size:10px;text-transform:uppercase;letter-spacing:0.5px;color:var(--text3);font-weight:700;background:var(--s3);border-bottom:1px solid var(--border)">';
  html += '<div style="flex:3">Canonical entity</div>';
  html += '<div style="flex:1;text-align:right">Variants</div>';
  html += '<div style="flex:1;text-align:right">Properties</div>';
  html += '<div style="flex:2">Sample recorded_owner</div>';
  html += '<div style="flex:1.4;text-align:right">Action</div>';
  html += '</div>';

  filtered.slice(0, 100).forEach((r, idx) => {
    const rowBg = idx % 2 === 0 ? 'var(--s2)' : 'var(--s2-alt, var(--s2))';
    html += `<div style="display:flex;align-items:center;padding:10px 14px;border-bottom:1px solid var(--border);background:${rowBg};font-size:12px">`;
    html += `<div style="flex:3;font-weight:600;color:var(--text)">${esc(r.canonical || '')}</div>`;
    html += `<div style="flex:1;text-align:right;color:var(--text2)">${esc(fmtN(r.cluster_size))}</div>`;
    html += `<div style="flex:1;text-align:right;color:var(--text);font-weight:700">${esc(fmtN(r.canonical_total_properties))}</div>`;
    html += `<div style="flex:2;color:var(--text3);font-size:11px">${esc(r.sample_recorded_owner_name || '—')}</div>`;
    html += `<div style="flex:1.4;text-align:right">`;
    if (r.sample_recorded_owner_id) {
      html += `<button class="ownership-open-sample" data-canonical="${esc(r.canonical || '')}" data-recorded-owner-id="${esc(r.sample_recorded_owner_id)}" style="padding:4px 10px;border-radius:5px;border:1px solid var(--border);background:var(--s3);color:var(--text);cursor:pointer;font-size:11px">Open sample &rsaquo;</button>`;
    }
    html += `</div>`;
    html += '</div>';
  });

  if (filtered.length > 100) {
    html += `<div style="padding:8px 14px;color:var(--text3);font-size:11px;background:var(--s3);text-align:center">Showing top 100 of ${fmtN(filtered.length)} clusters. Filter to narrow.</div>`;
  }
  html += '</div>';
  html += '</div>';

  // Bind handlers after render
  setTimeout(() => {
    const refresh = document.getElementById('ownershipBacklogRefresh');
    if (refresh) refresh.addEventListener('click', () => {
      diaOwnershipBacklog = null;
      loadDiaOwnershipBacklog();
    });
    const filter = document.getElementById('ownershipBacklogFilter');
    if (filter) filter.addEventListener('input', (e) => {
      diaOwnershipFilterText = e.target.value || '';
      renderDiaTab();
      // Restore focus + caret after rerender
      setTimeout(() => {
        const refocus = document.getElementById('ownershipBacklogFilter');
        if (refocus) {
          refocus.focus();
          try { refocus.setSelectionRange(refocus.value.length, refocus.value.length); } catch (e) {}
        }
      }, 0);
    });
    document.querySelectorAll('.ownership-open-sample').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.preventDefault();
        const recOwnerId = btn.dataset.recordedOwnerId;
        if (!recOwnerId) return;
        // Find one dialysis property pointing at this recorded_owner_id so
        // we can open the detail drawer with the existing Resolve Ownership
        // form already wired up. The first match is enough — resolving
        // its true_owner_id propagates to all sibling properties via the
        // migration-V trigger.
        try {
          const props = await diaQuery('properties',
            'property_id,facility_name,address,city,state,recorded_owner_id,true_owner_id',
            { filter: `recorded_owner_id=eq.${encodeURIComponent(recOwnerId)}`, limit: 1 });
          const row = props && props[0];
          if (!row) {
            showToast('No dialysis property found for that recorded_owner', 'warn');
            return;
          }
          if (typeof showDetail === 'function') {
            showDetail(row, 'dia-clinic');
          } else {
            showToast('showDetail not available', 'error');
          }
        } catch (err) {
          console.error('open-sample error', err);
          showToast('Failed to open sample property', 'error');
        }
      });
    });
  }, 0);

  return html;
}


function renderDiaClinicLeads() {
  // Lazy-load the priority queue
  if (diaClinicLeadQueue === null && !diaClinicLeadLoading) {
    diaClinicLeadLoading = true;
    (async () => {
      try {
        let all = [], offset = 0;
        while (true) {
          const batch = await diaQuery('v_clinic_research_priority', '*', {
            order: 'priority_score.desc.nullslast',
            limit: 1000, offset
          });
          all = all.concat(batch || []);
          if (!batch || batch.length < 1000) break;
          offset += 1000;
        }
        diaClinicLeadQueue = all;
      } catch (e) {
        console.error('Clinic leads queue load error:', e);
        showToast('Clinic leads load failed', 'error');
        diaClinicLeadQueue = null; // keep null so next visit retries
      }
      diaClinicLeadLoading = false;
      renderDiaTab();
    })();
    return '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading clinic leads queue...</p></div>';
  }
  if (diaClinicLeadLoading) {
    return '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading clinic leads queue...</p></div>';
  }

  const queue = diaClinicLeadQueue || [];
  const resolvedIds = new Set(
    (diaData.researchOutcomes || [])
      .filter(o => o.queue_type === 'clinic_lead')
      .map(o => o.clinic_id)
  );

  // Category & tier counts
  const cats = { unlinked: 0, ownership_gap: 0, seller_signal: 0 };
  const tiers = { high: 0, medium: 0, low: 0 };
  queue.forEach(r => { cats[r.research_category] = (cats[r.research_category] || 0) + 1; tiers[r.priority_tier] = (tiers[r.priority_tier] || 0) + 1; });

  let html = '';

  // === Summary metrics ===
  html += '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:20px;">';
  html += _clCard('Total Clinics', fmtN(queue.length), 'blue');
  html += _clCard('High Priority', fmtN(tiers.high), 'red');
  html += _clCard('Ownership Gap', fmtN(cats.ownership_gap), 'orange');
  html += _clCard('Seller Signals', fmtN(cats.seller_signal), 'purple');
  html += '</div>';

  // Progress bar
  const clTotal = queue.length;
  const clResolved = queue.filter(r => resolvedIds.has(r.medicare_id)).length;
  const clPct = clTotal > 0 ? Math.round((clResolved / clTotal) * 100) : 0;
  html += '<div class="research-progress" style="margin-bottom:16px;">';
  html += `<div class="progress-text">${clResolved} of ${clTotal} reviewed (${clPct}%)</div>`;
  html += `<div class="progress-bar"><div style="width: ${clPct}%; background: #34d399;"></div></div>`;
  html += '</div>';

  // Keyboard hint bar
  html += '<div style="display:flex;gap:10px;margin-bottom:12px;padding:6px 10px;background:var(--s2);border-radius:6px;font-size:11px;color:var(--text3);align-items:center;">';
  html += '<span><kbd style="padding:2px 6px;background:var(--s3);border:1px solid var(--border);border-radius:3px;font-size:10px;font-family:monospace;">S</kbd> Save</span>';
  html += '<span><kbd style="padding:2px 6px;background:var(--s3);border:1px solid var(--border);border-radius:3px;font-size:10px;font-family:monospace;">N</kbd> Next</span>';
  html += '<span><kbd style="padding:2px 6px;background:var(--s3);border:1px solid var(--border);border-radius:3px;font-size:10px;font-family:monospace;">B</kbd> Back</span>';
  html += '<span><kbd style="padding:2px 6px;background:var(--s3);border:1px solid var(--border);border-radius:3px;font-size:10px;font-family:monospace;">K</kbd> Skip</span>';
  html += '</div>';

  // === Filters ===
  html += '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px;">';
  // Category filters
  html += '<div style="display:flex;gap:4px;align-items:center;margin-right:12px;">';
  html += '<span style="font-size:11px;font-weight:600;color:var(--text3);text-transform:uppercase;letter-spacing:0.5px">Category:</span>';
  const catOpts = [
    { key: null, label: 'All' },
    { key: 'ownership_gap', label: `Ownership Gap (${fmtN(cats.ownership_gap)})` },
    { key: 'seller_signal', label: `Seller Signal (${fmtN(cats.seller_signal)})` },
    { key: 'unlinked', label: `Unlinked (${cats.unlinked})` }
  ];
  catOpts.forEach(o => {
    const active = diaClinicLeadFilter.category === o.key;
    html += `<button class="cl-filter-btn" data-cl-cat="${o.key}" style="font-size:11px;padding:4px 10px;border-radius:12px;border:1px solid ${active ? 'var(--accent)' : 'var(--border)'};background:${active ? 'var(--accent)' : 'var(--s2)'};color:${active ? '#fff' : 'var(--text2)'};cursor:pointer">${o.label}</button>`;
  });
  html += '</div>';
  // Tier filters
  html += '<div style="display:flex;gap:4px;align-items:center;">';
  html += '<span style="font-size:11px;font-weight:600;color:var(--text3);text-transform:uppercase;letter-spacing:0.5px">Priority:</span>';
  const tierOpts = [
    { key: null, label: 'All' },
    { key: 'high', label: 'High', color: '#f87171' },
    { key: 'medium', label: 'Medium', color: '#fbbf24' },
    { key: 'low', label: 'Low', color: '#94a3b8' }
  ];
  tierOpts.forEach(o => {
    const active = diaClinicLeadFilter.tier === o.key;
    html += `<button class="cl-filter-btn" data-cl-tier="${o.key}" style="font-size:11px;padding:4px 10px;border-radius:12px;border:1px solid ${active ? (o.color || 'var(--accent)') : 'var(--border)'};background:${active ? (o.color || 'var(--accent)') : 'var(--s2)'};color:${active ? '#fff' : 'var(--text2)'};cursor:pointer">${o.label}</button>`;
  });
  html += '</div>';
  html += '</div>';

  // Hide resolved toggle
  const hideRes = diaClinicLeadFilter.hideResolved;
  const resolvedCount = queue.filter(r => resolvedIds.has(r.medicare_id)).length;
  html += '<div style="display:flex;align-items:center;gap:6px;margin-bottom:12px">';
  html += `<label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:12px;color:var(--text2)">`;
  html += `<input type="checkbox" id="clHideResolved" ${hideRes ? 'checked' : ''} style="accent-color:var(--accent)" />`;
  html += `Hide dismissed (${resolvedCount})</label>`;
  html += '</div>';

  // Apply filters
  let filtered = queue;
  if (hideRes) filtered = filtered.filter(r => !resolvedIds.has(r.medicare_id));
  if (diaClinicLeadFilter.category) filtered = filtered.filter(r => r.research_category === diaClinicLeadFilter.category);
  if (diaClinicLeadFilter.tier) filtered = filtered.filter(r => r.priority_tier === diaClinicLeadFilter.tier);
  if (diaClinicLeadFilter.state) filtered = filtered.filter(r => r.state === diaClinicLeadFilter.state);

  // Operations card — render at top so it's immediately visible
  const clPage = filtered.slice(0, 50);
  if (diaClinicLeadFilter.selectedIdx !== undefined && clPage[diaClinicLeadFilter.selectedIdx]) {
    html += renderClinicLeadCard(clPage[diaClinicLeadFilter.selectedIdx]);
  }

  // State dropdown
  const states = [...new Set(filtered.map(r => r.state).filter(Boolean))].sort();
  html += '<div style="margin-bottom:12px;display:flex;align-items:center;gap:8px;">';
  html += `<select id="clStateFilter" style="font-size:12px;padding:4px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text)">`;
  html += `<option value="">All States (${states.length})</option>`;
  states.forEach(s => html += `<option value="${s}" ${diaClinicLeadFilter.state === s ? 'selected' : ''}>${s}</option>`);
  html += '</select>';
  html += `<span style="font-size:12px;color:var(--text3)">${fmtN(filtered.length)} clinics</span>`;
  html += '</div>';

  // === Table ===
  html += '<div class="data-table">';
  // Header
  html += '<div class="table-row" style="font-weight:600;border-bottom:1px solid var(--border);font-size:11px;text-transform:uppercase;letter-spacing:0.5px;color:var(--text3)">';
  html += '<div style="flex:0.5">Score</div>';
  html += '<div style="flex:1.5">Facility</div>';
  html += '<div style="flex:0.8">City/State</div>';
  html += '<div style="flex:0.6">Patients</div>';
  html += '<div style="flex:0.7">Revenue</div>';
  html += '<div style="flex:0.6">Category</div>';
  html += '<div style="flex:0.3">&#x200B;</div>';
  html += '</div>';

  clPage.forEach((row, idx) => {
    const isSelected = diaClinicLeadFilter.selectedIdx === idx;
    const isResolved = resolvedIds.has(row.medicare_id);
    const tierColor = row.priority_tier === 'high' ? '#f87171' : row.priority_tier === 'medium' ? '#fbbf24' : '#94a3b8';
    const catLabel = row.research_category === 'seller_signal' ? 'Seller' : row.research_category === 'ownership_gap' ? 'Gap' : 'Unlinked';

    html += `<div class="table-row cl-row clickable-row" data-cl-idx="${idx}" style="font-size:12px;cursor:pointer;${isSelected ? 'background:rgba(52,211,153,0.1);border-left:3px solid #34d399;' : ''}${isResolved ? 'opacity:0.5;' : ''}">`;
    html += `<div style="flex:0.5"><span style="display:inline-block;padding:2px 6px;border-radius:8px;font-size:11px;font-weight:700;background:${tierColor}20;color:${tierColor}">${row.priority_score}</span></div>`;
    html += `<div style="flex:1.5;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(row.facility_name || '')}</div>`;
    html += `<div style="flex:0.8;color:var(--text2)">${esc(row.city || '')}${row.state ? ', ' + row.state : ''}</div>`;
    html += `<div style="flex:0.6;color:var(--text2)">${row.latest_estimated_patients || '–'}</div>`;
    html += `<div style="flex:0.7;color:var(--text2)">${row.estimated_annual_revenue ? '$' + fmtN(Math.round(row.estimated_annual_revenue / 1000)) + 'K' : '–'}</div>`;
    html += `<div style="flex:0.6"><span style="font-size:10px;padding:2px 6px;border-radius:4px;background:var(--s3);color:var(--text2)">${catLabel}</span></div>`;
    html += `<div style="flex:0.3;text-align:right">${isResolved ? '✓' : '→'}</div>`;
    html += '</div>';
  });

  if (clPage.length === 0) {
    html += '<div class="table-empty" style="padding:24px;text-align:center;color:var(--text3)">No clinics match current filters</div>';
  }
  html += '</div>';

  // Attach handlers
  setTimeout(() => {
    // Row clicks — show inline research card
    document.querySelectorAll('.cl-row').forEach(el => {
      el.addEventListener('click', () => {
        const idx = parseInt(el.dataset.clIdx, 10);
        diaClinicLeadFilter.selectedIdx = idx;
        renderDiaTab();
      });
    });
    // Category filter
    document.querySelectorAll('[data-cl-cat]').forEach(btn => {
      btn.addEventListener('click', () => {
        const val = btn.dataset.clCat;
        diaClinicLeadFilter.category = val === 'null' ? null : val;
        diaClinicLeadFilter.selectedIdx = undefined;
        renderDiaTab();
      });
    });
    // Tier filter
    document.querySelectorAll('[data-cl-tier]').forEach(btn => {
      btn.addEventListener('click', () => {
        const val = btn.dataset.clTier;
        diaClinicLeadFilter.tier = val === 'null' ? null : val;
        diaClinicLeadFilter.selectedIdx = undefined;
        renderDiaTab();
      });
    });
    // State filter
    const stateEl = document.getElementById('clStateFilter');
    if (stateEl) {
      stateEl.addEventListener('change', () => {
        diaClinicLeadFilter.state = stateEl.value || null;
        diaClinicLeadFilter.selectedIdx = undefined;
        renderDiaTab();
      });
    }
    // Hide resolved toggle
    const hideEl = document.getElementById('clHideResolved');
    if (hideEl) {
      hideEl.addEventListener('change', () => {
        diaClinicLeadFilter.hideResolved = hideEl.checked;
        diaClinicLeadFilter.selectedIdx = undefined;
        renderDiaTab();
      });
    }
  }, 0);

  return html;
}

function _clCard(title, value, color) {
  const colors = { blue: '#60a5fa', green: '#34d399', red: '#f87171', orange: '#fb923c', purple: '#a78bfa', yellow: '#fbbf24', cyan: '#22d3ee' };
  const c = colors[color] || colors.blue;
  return `<div style="background:var(--s2);border:1px solid var(--border);border-radius:10px;padding:12px 14px">
    <div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:4px">${title}</div>
    <div style="font-size:22px;font-weight:800;color:${c}">${value}</div>
  </div>`;
}

/**
 * Render the research card for a selected clinic lead — mirrors GSA research pattern
 */
function renderClinicLeadCard(rec) {
  var step = diaClinicLeadStep || 0;
  let html = '<div style="margin-bottom:20px;border:1px solid var(--accent);border-radius:12px;padding:20px;background:var(--s1)">';

  // Header
  html += '<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px">';
  html += '<div>';
  html += '<h3 style="margin:0;font-size:16px;font-weight:700;color:var(--text)">' + esc(rec.facility_name || 'Unknown Facility') + '</h3>';
  html += '<div style="font-size:12px;color:var(--text2);margin-top:2px">' + esc(rec.address || '') + (rec.city ? ', ' + esc(rec.city) : '') + (rec.state ? ', ' + rec.state : '') + ' ' + (rec.zip_code || '') + '</div>';
  html += '</div>';
  var tierColor = rec.priority_tier === 'high' ? '#f87171' : rec.priority_tier === 'medium' ? '#fbbf24' : '#94a3b8';
  html += '<div style="text-align:right">';
  html += '<span style="display:inline-block;padding:4px 10px;border-radius:8px;font-size:12px;font-weight:700;background:' + tierColor + '20;color:' + tierColor + '">' + rec.priority_score + ' pts</span>';
  html += '<div style="font-size:10px;color:var(--text3);margin-top:2px">' + (rec.research_category || '').replace('_', ' ').toUpperCase() + '</div>';
  html += '</div></div>';

  // Category-specific "What To Do" explanation
  var categoryExplanations = {
    'ownership_gap': {
      title: 'Ownership Gap \u2014 Identify Who Owns This Property',
      body: 'This clinic has missing or incomplete ownership data. Research the property owner, verify the operating entity, and fill in the ownership fields below.',
      color: '#fbbf24',
      fields: [
        { label: 'Recorded Owner', value: rec.recorded_owner },
        { label: 'True Owner', value: rec.true_owner },
        { label: 'State of Incorporation', value: rec.state_of_incorporation },
        { label: 'Principal Names', value: rec.principal_names },
        { label: 'Ownership Tenure', value: rec.ownership_tenure_yrs ? rec.ownership_tenure_yrs + ' yrs' : null },
      ]
    },
    'seller_signal': {
      title: 'Seller Signal \u2014 Evaluate Disposition Likelihood',
      body: 'This clinic shows signals that the owner may be willing to sell. Review signal details, verify accuracy, and determine if outreach is warranted.',
      color: '#f87171',
      fields: [
        { label: 'Loan Maturity', value: rec.months_to_maturity != null ? rec.months_to_maturity + ' months' : null },
        { label: 'Loan Amount', value: rec.loan_amount ? '$' + fmtN(Math.round(rec.loan_amount)) : null },
        { label: 'Lender', value: rec.lender_name },
        { label: 'Ownership Tenure', value: rec.ownership_tenure_yrs ? rec.ownership_tenure_yrs + ' yrs' : null },
        { label: 'Recorded Owner', value: rec.recorded_owner },
        { label: 'Est. Revenue', value: rec.estimated_annual_revenue ? '$' + fmtN(Math.round(rec.estimated_annual_revenue)) : null },
      ]
    },
    'unlinked': {
      title: 'Unlinked Clinic \u2014 Match to a Property Record',
      body: 'This clinic exists in CMS data but is not linked to a property in the database. Search for an existing property match or create a new property record.',
      color: '#60a5fa',
      fields: [
        { label: 'Address', value: rec.address },
        { label: 'City/State', value: (rec.city || '') + (rec.city && rec.state ? ', ' : '') + (rec.state || '') || null },
        { label: 'Building SF', value: rec.building_size ? fmtN(Math.round(rec.building_size)) + ' SF' : null },
        { label: 'Year Built', value: rec.year_built },
      ]
    }
  };
  var catInfo = categoryExplanations[rec.research_category] || { title: 'Research Needed', body: 'Review this clinic record and fill in any missing information.', color: '#94a3b8', fields: [] };

  html += '<div style="padding:14px;background:' + catInfo.color + '14;border-radius:8px;border-left:3px solid ' + catInfo.color + ';margin-bottom:16px;">';
  html += '<div style="font-weight:700;font-size:14px;margin-bottom:6px;color:var(--text)">' + esc(catInfo.title) + '</div>';
  html += '<div style="font-size:13px;color:var(--text);line-height:1.5;margin-bottom:10px;">' + esc(catInfo.body) + '</div>';
  if (catInfo.fields.length) {
    html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;font-size:12px;">';
    catInfo.fields.forEach(function(f) {
      var hasVal = f.value != null && String(f.value).trim() !== '';
      var icon = hasVal ? '<span style="color:var(--success)">\u2713</span>' : '<span style="color:#f87171">\u25CB</span>';
      html += '<div>' + icon + ' <span style="color:var(--text3)">' + esc(f.label) + ':</span> ' + (hasVal ? '<strong>' + esc(String(f.value)) + '</strong>' : '<span style="color:#f87171">Missing</span>') + '</div>';
    });
    html += '</div>';
  }
  html += '</div>';

  // Context grid
  html += '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:16px;font-size:12px">';
  html += _clCtx('Medicare ID', rec.medicare_id);
  html += _clCtx('Operator', rec.chain_organization || 'Independent');
  html += _clCtx('Stations', rec.stations || '\u2013');
  html += _clCtx('Patients', rec.latest_estimated_patients || '\u2013');
  html += _clCtx('Est. Revenue', rec.estimated_annual_revenue ? '$' + fmtN(Math.round(rec.estimated_annual_revenue)) : '\u2013');
  html += _clCtx('Capacity Util.', rec.capacity_utilization_pct ? rec.capacity_utilization_pct + '%' : '\u2013');
  html += _clCtx('Building SF', rec.building_size ? fmtN(Math.round(rec.building_size)) : '\u2013');
  html += _clCtx('Land Area', rec.land_area ? fmtN(Math.round(rec.land_area)) + ' SF' : '\u2013');
  html += _clCtx('Year Built', rec.year_built || '\u2013');
  html += _clCtx('Last Rent', rec.last_known_rent ? '$' + fmtN(Math.round(rec.last_known_rent)) : '\u2013');
  html += _clCtx('Ownership Tenure', rec.ownership_tenure_yrs ? rec.ownership_tenure_yrs + ' yrs' : '\u2013');
  html += _clCtx('Loan Maturity', rec.months_to_maturity != null ? rec.months_to_maturity + ' mo' : '\u2013');
  html += '</div>';

  // Loan context (if exists)
  if (rec.loan_id) {
    html += '<div style="background:var(--s2);border:1px solid var(--border);border-radius:8px;padding:10px 12px;margin-bottom:16px;font-size:12px">';
    html += '<div style="font-weight:600;margin-bottom:4px;color:var(--text3);font-size:10px;text-transform:uppercase;letter-spacing:0.5px">Loan Info</div>';
    html += '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px">';
    html += _clCtx('Lender', rec.lender_name || '\u2013');
    html += _clCtx('Amount', rec.loan_amount ? '$' + fmtN(Math.round(rec.loan_amount)) : '\u2013');
    html += _clCtx('Type', rec.loan_type || '\u2013');
    html += '</div></div>';
  }

  // Quick actions
  html += '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:16px">';
  var searchQ = (rec.facility_name || '') + ' ' + (rec.address || '') + ' ' + (rec.city || '') + ' ' + (rec.state || '') + ' dialysis ownership';
  html += '<a href="https://www.google.com/search?q=' + encodeURIComponent(searchQ) + '" target="_blank" rel="noopener" style="font-size:11px;padding:4px 10px;border-radius:6px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none;cursor:pointer">Google Search</a>';
  if (rec.state) {
    html += '<a href="https://www.google.com/search?q=' + encodeURIComponent('Secretary of State business search ' + rec.state) + '" target="_blank" rel="noopener" style="font-size:11px;padding:4px 10px;border-radius:6px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none;cursor:pointer">SOS ' + rec.state + '</a>';
  }
  if (rec.city && rec.state) {
    html += '<a href="https://www.google.com/search?q=' + encodeURIComponent(rec.city + ' ' + rec.state + ' county property records') + '" target="_blank" rel="noopener" style="font-size:11px;padding:4px 10px;border-radius:6px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none;cursor:pointer">County Records</a>';
  }
  html += '</div>';

  // === RESEARCH FORM (5-STEP WORKFLOW) ===
  html += '<div style="border-top:1px solid var(--border);padding-top:16px">';

  // Completeness bar
  var cFields = [
    { name: 'recorded_owner', value: rec.recorded_owner, required: true },
    { name: 'true_owner', value: rec.true_owner },
    { name: 'incorporation', value: rec.state_of_incorporation },
    { name: 'principals', value: rec.principal_names },
    { name: 'property', value: rec.property_id },
    { name: 'email', value: rec.contact_email },
    { name: 'phone', value: rec.phone },
    { name: 'pipeline', value: rec.pipeline_status, required: true },
    { name: 'notes', value: rec.research_notes }
  ];
  var completeness = computeCompleteness(cFields);
  html += renderCompletenessBar(completeness);

  // Step navigation — 5 steps
  var clSteps = [
    { label: 'Clinic Info', complete: !!rec.facility_name },
    { label: 'Ownership', complete: !!rec.recorded_owner },
    { label: 'Property', complete: !!rec.property_id },
    { label: 'Contacts', complete: !!rec.contact_email || !!rec.phone },
    { label: 'Notes', complete: !!rec.pipeline_status }
  ];
  html += renderStepNav(step, clSteps, 'window.diaClStepNav');

  // ===== Step 0: Clinic Info (read-only context) =====
  html += '<div class="form-step" style="display:' + (step === 0 ? 'block' : 'none') + ';margin-top:16px">';
  html += '<div class="form-step-head"><h4 style="margin:0;font-size:13px;font-weight:700">Step 1: Clinic Info</h4></div>';
  html += '<div style="font-size:12px;color:var(--text2);margin-bottom:12px">Review the clinic context above. Confirm details are accurate before proceeding to ownership research.</div>';
  // Show key fields as read-only summary
  html += '<div style="background:var(--s2);border-radius:8px;padding:12px;font-size:12px">';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">';
  html += '<div><span style="color:var(--text3)">Facility:</span> <strong>' + esc(rec.facility_name || '\u2014') + '</strong></div>';
  html += '<div><span style="color:var(--text3)">Medicare ID:</span> ' + esc(rec.medicare_id || '\u2014') + '</div>';
  html += '<div><span style="color:var(--text3)">Operator:</span> ' + esc(rec.chain_organization || 'Independent') + '</div>';
  html += '<div><span style="color:var(--text3)">Patients:</span> ' + (rec.latest_estimated_patients || '\u2013') + '</div>';
  html += '<div><span style="color:var(--text3)">Address:</span> ' + esc(rec.address || '\u2014') + '</div>';
  html += '<div><span style="color:var(--text3)">City/State:</span> ' + esc((rec.city || '') + (rec.city && rec.state ? ', ' : '') + (rec.state || '')) + '</div>';
  html += '<div><span style="color:var(--text3)">Building SF:</span> ' + (rec.building_size ? fmtN(Math.round(rec.building_size)) : '\u2013') + '</div>';
  html += '<div><span style="color:var(--text3)">Year Built:</span> ' + (rec.year_built || '\u2013') + '</div>';
  html += '</div></div>';
  html += '</div>';

  // ===== Step 1: Ownership =====
  html += '<div class="form-step" style="display:' + (step === 1 ? 'block' : 'none') + ';margin-top:16px">';
  html += '<div class="form-step-head"><h4 style="margin:0;font-size:13px;font-weight:700">Step 2: Ownership</h4></div>';

  html += guidedField('cl-recorded-owner', 'Recorded Owner', rec.recorded_owner, { type: 'text', required: true });
  html += guidedField('cl-true-owner', 'True Owner / Developer', rec.true_owner, { type: 'text' });
  html += guidedField('cl-incorporation', 'State of Incorporation', rec.state_of_incorporation, { type: 'text' });
  html += guidedField('cl-principals', 'Principal Names', rec.principal_names, { type: 'text' });
  html += guidedField('cl-mailing', 'Mailing Address', rec.mailing_address, { type: 'text' });
  html += '</div>';

  // ===== Step 2: Property =====
  html += '<div class="form-step" style="display:' + (step === 2 ? 'block' : 'none') + ';margin-top:16px">';
  html += '<div class="form-step-head"><h4 style="margin:0;font-size:13px;font-weight:700">Step 3: Property</h4></div>';
  html += guidedField('cl-property-id', 'Property ID', rec.property_id, { type: 'text', placeholder: 'Enter or link property ID' });
  html += renderPropertyResolution(rec, 'clinic_leads', 'medicare_id');
  html += '</div>';

  // ===== Step 3: Contacts (dynamic rows) =====
  html += '<div class="form-step" style="display:' + (step === 3 ? 'block' : 'none') + ';margin-top:16px">';
  html += '<div class="form-step-head"><h4 style="margin:0;font-size:13px;font-weight:700">Step 4: Contacts</h4></div>';

  // Primary contact fields
  html += guidedField('cl-email', 'Primary Email', rec.contact_email, { type: 'email' });
  html += guidedField('cl-phone', 'Primary Phone', rec.phone, { type: 'tel' });

  // Dynamic contact rows
  html += '<div style="margin-top:16px;border-top:1px solid var(--border);padding-top:12px">';
  html += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">';
  html += '<div style="font-weight:600;font-size:12px;color:var(--text)">Additional Contacts</div>';
  html += '<button id="addClContact" style="font-size:11px;padding:4px 10px;border-radius:6px;background:var(--accent);color:#fff;border:none;cursor:pointer;font-weight:600">+ Add Contact</button>';
  html += '</div>';

  // Table header
  html += '<div style="font-size:10px;font-weight:600;color:var(--text3);display:grid;grid-template-columns:1fr 1fr 1fr 0.8fr 30px;gap:4px;margin-bottom:4px;text-transform:uppercase;letter-spacing:0.5px">';
  html += '<div>Name</div><div>Phone</div><div>Email</div><div>Role</div><div></div>';
  html += '</div>';

  html += '<div id="clContactRows">';
  var contacts = window._diaClinicFormDraft._contacts || [{}];
  contacts.forEach(function(ct, ci) {
    html += _renderClContactRow(ci, ct);
  });
  html += '</div>';
  html += '</div>';
  html += '</div>';

  // ===== Step 4: Notes =====
  html += '<div class="form-step" style="display:' + (step === 4 ? 'block' : 'none') + ';margin-top:16px">';
  html += '<div class="form-step-head"><h4 style="margin:0;font-size:13px;font-weight:700">Step 5: Notes & Pipeline</h4></div>';

  html += guidedField('cl-pipeline-status', 'Pipeline Status', rec.pipeline_status, {
    type: 'select', required: true,
    options: [
      { label: 'New Lead', value: 'new_lead' },
      { label: 'Researching', value: 'researching' },
      { label: 'Contacted', value: 'contacted' },
      { label: 'Meeting Set', value: 'meeting_set' },
      { label: 'Proposal Sent', value: 'proposal_sent' },
      { label: 'Not For Sale', value: 'not_for_sale' },
      { label: 'Dead', value: 'dead' }
    ]
  });

  html += guidedField('cl-notes', 'Research Notes', rec.research_notes, {
    type: 'textarea', placeholder: 'Research findings, next steps...', rows: 4
  });
  html += '</div>';

  // Action buttons — always visible
  html += '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px">';
  if (step > 0) {
    html += '<button id="clBackBtn" style="padding:10px 16px;background:var(--s2);border:1px solid var(--border);border-radius:8px;font-size:13px;cursor:pointer;color:var(--text2)">\u2190 Back</button>';
  }
  if (step < 4) {
    html += '<button id="clNextBtn" style="flex:1;padding:10px;background:var(--accent);color:#fff;border:none;border-radius:8px;font-weight:600;font-size:13px;cursor:pointer">Next \u2192</button>';
  }
  html += '<button id="clSaveBtn" style="' + (step === 4 ? 'flex:1;' : '') + 'padding:10px 16px;background:var(--accent);color:#fff;border:none;border-radius:8px;font-weight:600;font-size:13px;cursor:pointer">Save</button>';
  html += '<button id="clNaBtn" style="padding:10px 16px;background:rgba(239,68,68,0.15);border:1px solid rgba(239,68,68,0.3);border-radius:8px;font-size:13px;cursor:pointer;color:#f87171">N/A</button>';
  html += '<button id="clSkipBtn" style="padding:10px 16px;background:var(--s2);border:1px solid var(--border);border-radius:8px;font-size:13px;cursor:pointer;color:var(--text2)">Skip</button>';
  html += '</div>';

  html += '</div>'; // form
  html += '</div>'; // card

  // Attach handlers
  setTimeout(function() {
    var nextBtn = document.getElementById('clNextBtn');
    var backBtn = document.getElementById('clBackBtn');
    var saveBtn = document.getElementById('clSaveBtn');
    var naBtn = document.getElementById('clNaBtn');
    var skipBtn = document.getElementById('clSkipBtn');

    if (nextBtn) nextBtn.addEventListener('click', function() { window.diaClStepNav(step + 1); });
    if (backBtn) backBtn.addEventListener('click', function() { window.diaClStepNav(step - 1); });

    if (saveBtn) {
      saveBtn.addEventListener('click', async function() {
        saveBtn.disabled = true;
        saveBtn.textContent = 'Saving\u2026';
        saveBtn.style.opacity = '0.6';
        try {
          await saveClinicLeadResearch(rec);
          diaClinicLeadStep = 0;
          window._diaClinicFormDraft = {};
        } catch (e) {
          console.error('saveClinicLeadResearch error:', e);
          showToast('Save failed: ' + e.message, 'error');
        } finally {
          saveBtn.disabled = false;
          saveBtn.textContent = 'Save';
          saveBtn.style.opacity = '';
        }
      });
    }

    if (naBtn) {
      naBtn.addEventListener('click', async function() {
        if (!(await lccConfirm('Mark this clinic lead as N/A? It will be removed from your research queue.', 'Mark N/A'))) return;
        naBtn.disabled = true;
        naBtn.style.opacity = '0.6';
        try {
          await markClinicLead(rec, 'not_applicable');
          diaClinicLeadStep = 0;
          window._diaClinicFormDraft = {};
        } catch (e) {
          console.error('markClinicLead error:', e);
          showToast('Mark failed: ' + e.message, 'error');
        } finally {
          naBtn.disabled = false;
          naBtn.style.opacity = '';
        }
      });
    }

    if (skipBtn) {
      skipBtn.addEventListener('click', function() {
        diaClinicLeadStep = 0;
        window._diaClinicFormDraft = {};
        diaClinicLeadFilter.selectedIdx = undefined;
        showToast('Skipped \u2014 returned to list', 'info');
        renderDiaTab();
      });
    }

    // Dynamic contact add/remove
    var addContactBtn = document.getElementById('addClContact');
    if (addContactBtn) {
      addContactBtn.addEventListener('click', function() {
        _captureClinicFormDraft();
        window._diaClinicFormDraft._contacts.push({});
        renderDiaTab();
      });
    }
    document.querySelectorAll('[data-remove-contact]').forEach(function(btn) {
      btn.addEventListener('click', function() {
        _captureClinicFormDraft();
        var idx = parseInt(btn.dataset.removeContact, 10);
        window._diaClinicFormDraft._contacts.splice(idx, 1);
        if (window._diaClinicFormDraft._contacts.length === 0) window._diaClinicFormDraft._contacts = [{}];
        renderDiaTab();
      });
    });
  }, 0);

  return html;
}

// Helper: render a dynamic contact row for clinic leads
function _renderClContactRow(idx, data) {
  var d = data || {};
  var html = '<div class="cl-contact-row" style="display:grid;grid-template-columns:1fr 1fr 1fr 0.8fr 30px;gap:4px;margin-bottom:4px">';
  html += '<input type="text" id="cl-ct-name-' + idx + '" value="' + esc(d.name || '') + '" placeholder="Name" style="font-size:11px;padding:4px 6px;border:1px solid var(--border);border-radius:4px;background:var(--s2);color:var(--text);box-sizing:border-box" />';
  html += '<input type="tel" id="cl-ct-phone-' + idx + '" value="' + esc(d.phone || '') + '" placeholder="Phone" style="font-size:11px;padding:4px 6px;border:1px solid var(--border);border-radius:4px;background:var(--s2);color:var(--text);box-sizing:border-box" />';
  html += '<input type="email" id="cl-ct-email-' + idx + '" value="' + esc(d.email || '') + '" placeholder="Email" style="font-size:11px;padding:4px 6px;border:1px solid var(--border);border-radius:4px;background:var(--s2);color:var(--text);box-sizing:border-box" />';
  html += '<input type="text" id="cl-ct-role-' + idx + '" value="' + esc(d.role || '') + '" placeholder="Role" style="font-size:11px;padding:4px 6px;border:1px solid var(--border);border-radius:4px;background:var(--s2);color:var(--text);box-sizing:border-box" />';
  html += '<button data-remove-contact="' + idx + '" style="font-size:14px;background:none;border:none;color:#f87171;cursor:pointer;padding:0" title="Remove">\u00D7</button>';
  html += '</div>';
  return html;
}

/**
 * Draft state preservation for lease backfill and clinic leads multi-step forms
 */
window._diaLeaseFormDraft = {};
window._diaClinicFormDraft = {};

function _captureLeaseFormDraft() {
  var fields = ['leaseOutcome', 'leaseTerm', 'leaseExpiration', 'leaseSource', 'leaseRent', 'leaseRentSF', 'leaseEscalations', 'leasePropertyId', 'leaseLender', 'leaseLoanAmount', 'leaseLoanType', 'leaseLoanMaturity', 'leaseNotes'];
  fields.forEach(function(id) {
    var el = document.getElementById(id);
    if (el && el.value !== undefined && el.value !== '') {
      window._diaLeaseFormDraft[id] = el.value;
    }
  });
  _capturePriorLeases();
}

function _captureClinicFormDraft() {
  var fields = ['cl-recorded-owner', 'cl-true-owner', 'cl-incorporation', 'cl-principals', 'cl-mailing', 'cl-property-id', 'cl-email', 'cl-phone', 'cl-phone-2', 'cl-mailing-2', 'cl-pipeline-status', 'cl-notes'];
  fields.forEach(function(id) {
    var el = document.getElementById(id);
    if (el && el.value !== undefined && el.value !== '') {
      window._diaClinicFormDraft[id] = el.value;
    }
  });
  // Capture dynamic contact rows
  var contactRows = document.querySelectorAll('.cl-contact-row');
  if (contactRows.length > 0) {
    var contacts = [];
    contactRows.forEach(function(row, i) {
      contacts.push({
        name: (document.getElementById('cl-ct-name-' + i) || {}).value || '',
        phone: (document.getElementById('cl-ct-phone-' + i) || {}).value || '',
        email: (document.getElementById('cl-ct-email-' + i) || {}).value || '',
        role: (document.getElementById('cl-ct-role-' + i) || {}).value || ''
      });
    });
    window._diaClinicFormDraft._contacts = contacts;
  }
}

function _restoreDraft(draft) {
  requestAnimationFrame(function() {
    Object.keys(draft).forEach(function(id) {
      if (id.startsWith('_')) return; // skip special keys
      var el = document.getElementById(id);
      if (el && !el.value) el.value = draft[id];
    });
  });
}

/**
 * Step navigation handler for lease backfill multi-step form
 */
window.diaLeaseStepNav = function(idx) {
  _captureLeaseFormDraft();
  diaLeaseBackfillStep = idx;
  renderDiaTab();
  _restoreDraft(window._diaLeaseFormDraft);
};

/**
 * Step navigation handler for clinic lead multi-step form
 */
window.diaClStepNav = function(idx) {
  _captureClinicFormDraft();
  diaClinicLeadStep = idx;
  renderDiaTab();
  _restoreDraft(window._diaClinicFormDraft);
};

/**
 * Render property resolution component for research cards lacking property_id
 */
/**
 * Render the ranked candidate chips for property-link review.
 * Each chip links to a property in one click; high-confidence candidates
 * (score >= 0.92) are highlighted as a primary action.
 */
var diaAutoLinkAuditExpanded = false;
function renderDiaAutoLinkAuditPanel() {
  // Filter the cached outcomes for auto-link sources, last 14 days, top 50.
  const cutoff = new Date(Date.now() - 14 * 86400000).toISOString();
  const autoLinkSources = ['auto_link_exact_singleton','auto_link_high_confidence','auto_link_orphan_property','auto_stub_from_clinic'];
  const recent = (diaData.researchOutcomes || [])
    .filter(o => o.queue_type === 'property_review'
      && autoLinkSources.indexOf(o.source_name) !== -1
      && (o.created_at || '') >= cutoff)
    .sort((a, b) => (b.created_at || '').localeCompare(a.created_at || ''))
    .slice(0, 50);

  if (recent.length === 0) {
    return '';  // Don't show the panel if nothing recent
  }

  // Group counts for the header
  const bySource = {};
  recent.forEach(o => { bySource[o.source_name] = (bySource[o.source_name] || 0) + 1; });
  const sourceLabel = function(s) {
    return s === 'auto_link_exact_singleton' ? 'exact'
         : s === 'auto_link_high_confidence' ? 'fuzzy'
         : s === 'auto_link_orphan_property' ? 'orphan'
         : s === 'auto_stub_from_clinic' ? 'stub' : s;
  };
  const headerCounts = Object.keys(bySource)
    .sort((a, b) => bySource[b] - bySource[a])
    .map(s => bySource[s] + ' ' + sourceLabel(s)).join(' · ');

  let html = '<div style="margin-bottom:16px;background:rgba(99,102,241,0.05);border:1px solid rgba(99,102,241,0.25);border-radius:8px;padding:10px 14px;">';
  html += '<div style="display:flex;justify-content:space-between;align-items:center;cursor:pointer;" onclick="diaAutoLinkAuditExpanded=!diaAutoLinkAuditExpanded;renderDiaTab();">';
  html += '<div style="font-size:12px;color:var(--text);font-weight:600;">';
  html += '<span style="font-size:11px;color:#6366f1;letter-spacing:0.5px;">RECENTLY AUTO-LINKED</span>';
  html += ' &middot; <span style="color:var(--text2);font-weight:400;">' + recent.length + ' in last 14 days (' + esc(headerCounts) + ')</span>';
  html += '</div>';
  html += '<button class="btn-action default" style="font-size:11px;padding:3px 10px;">' + (diaAutoLinkAuditExpanded ? '▲ Hide' : '▼ Show details') + '</button>';
  html += '</div>';

  if (diaAutoLinkAuditExpanded) {
    html += '<div style="margin-top:10px;max-height:280px;overflow-y:auto;border-top:1px solid var(--border);padding-top:8px;">';
    html += '<div style="font-size:11px;color:var(--text3);margin-bottom:6px;">Spot-check the system\'s silent decisions. To revert one, copy the SQL command.</div>';
    recent.forEach(o => {
      const tag = sourceLabel(o.source_name);
      const tagColor = o.source_name === 'auto_link_exact_singleton' ? '#34d399'
                     : o.source_name === 'auto_link_high_confidence' ? '#fbbf24'
                     : o.source_name === 'auto_link_orphan_property' ? '#60a5fa'
                     : '#a78bfa';
      const when = (o.created_at || '').slice(0, 16).replace('T', ' ');
      html += '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;padding:6px 8px;margin-bottom:4px;background:var(--s2);border-radius:5px;font-size:11px;">';
      html += '<div style="flex:1;min-width:0;">';
      html += '<span style="display:inline-block;font-size:9px;font-weight:700;padding:1px 5px;border-radius:3px;background:' + tagColor + ';color:#0a0a0a;margin-right:6px;">' + esc(tag.toUpperCase()) + '</span>';
      html += '<span style="color:var(--text3);">' + esc(when) + '</span>';
      html += ' &middot; clinic ' + esc(String(o.clinic_id)) + ' &rarr; property #' + esc(String(o.selected_property_id || '?'));
      if (o.notes) html += '<div style="font-size:10px;color:var(--text3);margin-top:1px;" class="truncate">' + esc(o.notes) + '</div>';
      html += '</div>';
      html += '<button class="btn-action default" style="font-size:10px;padding:2px 8px;white-space:nowrap;" onclick="diaAutoLinkAuditCopyRevert(\'' + esc(String(o.clinic_id)) + '\')">Copy revert</button>';
      html += '</div>';
    });
    html += '</div>';
  }

  html += '</div>';
  return html;
}

window.diaAutoLinkAuditCopyRevert = function(clinicId) {
  const sql = "SELECT public.revert_property_link_outcome('" + String(clinicId).replace(/'/g, "''") + "');";
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(sql).then(
      () => showToast('Revert SQL copied to clipboard', 'success'),
      () => showToast(sql, 'info')
    );
  } else {
    // Fallback for non-secure contexts
    showToast(sql, 'info');
  }
};

function renderSuggestedCandidates(item, suggested) {
  const top = suggested.slice(0, 5);
  const best = top[0];
  const bestScore = best && typeof best.score === 'number' ? best.score : 0;
  const isHighConfidence = bestScore >= 0.92;
  const clinicId = item.clinic_id;

  let html = '<div style="background:rgba(52,211,153,0.06);border-radius:8px;padding:14px;margin-bottom:12px;border-left:3px solid var(--accent);">';
  html += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">';
  html += '<div style="font-weight:600;font-size:11px;text-transform:uppercase;letter-spacing:0.5px;color:var(--accent);">Suggested Properties (' + top.length + ')</div>';
  html += '<div style="font-size:11px;color:var(--text2);">Click any to link in one click</div>';
  html += '</div>';

  top.forEach((c, idx) => {
    const score = typeof c.score === 'number' ? c.score : 0;
    const scorePct = Math.round(score * 100);
    const isExact = c.match_type === 'exact_address_city_state_zip' || c.match_type === 'exact_address_city_state';
    const isFuzzy = c.match_type === 'fuzzy_address_state';
    const badgeColor = score >= 0.92 ? '#34d399' : score >= 0.75 ? '#fbbf24' : '#9ca3af';
    const badgeLabel = isExact ? 'EXACT' : isFuzzy ? 'FUZZY' : 'MATCH';
    const isPrimary = idx === 0 && isHighConfidence;

    const cityState = (c.city || '') + (c.city && c.state ? ', ' : '') + (c.state || '');
    const addrLine = (c.address || '—') + (c.zip_code ? ' · ' + c.zip_code : '');

    html += '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;padding:8px 10px;margin-bottom:6px;background:var(--s2);border:1px solid ' + (isPrimary ? 'var(--accent)' : 'var(--border)') + ';border-radius:6px;">';
    html += '<div style="flex:1;min-width:0;">';
    html += '<div style="display:flex;gap:6px;align-items:center;margin-bottom:2px;">';
    html += '<span style="font-size:10px;font-weight:700;padding:1px 6px;border-radius:3px;background:' + badgeColor + ';color:#0a0a0a;">' + badgeLabel + ' ' + scorePct + '%</span>';
    html += '<span style="font-size:11px;color:var(--text3);">#' + esc(String(c.property_id)) + (c.property_name ? ' · ' + esc(c.property_name) : '') + '</span>';
    html += '</div>';
    html += '<div style="font-size:12px;color:var(--text);font-weight:500;" class="truncate">' + esc(addrLine) + '</div>';
    if (cityState) html += '<div style="font-size:11px;color:var(--text2);">' + esc(cityState) + '</div>';
    html += '</div>';
    html += '<button class="btn-action ' + (isPrimary ? 'primary' : 'default') + '" style="font-size:11px;padding:5px 12px;white-space:nowrap;" onclick="propResLinkFromQueue(\'' + String(clinicId).replace(/\'/g, "\\\'") + '\',' + c.property_id + ')">' + (isPrimary ? '✓ Confirm Link' : 'Link') + '</button>';
    html += '</div>';
  });

  html += '</div>';
  return html;
}

var _propResLinkInFlight = false;
window.propResLinkFromQueue = async function(clinicId, propertyId) {
  // Module-level lock prevents double-saves while the request is in flight.
  // (Earlier versions disabled `event.target` after `await lccConfirm`, but
  // the post-await `event` global resolved to the *modal*'s OK button,
  // which left it permanently disabled and broke subsequent links.)
  if (_propResLinkInFlight) return;

  if (!(await lccConfirm('Link clinic ' + clinicId + ' to Property #' + propertyId + '?', 'Link'))) return;

  _propResLinkInFlight = true;

  try {
    // research_queue_outcomes has a UNIQUE(queue_type, clinic_id) constraint,
    // so an INSERT for an already-reviewed clinic returns 409. Check the
    // existing outcomes cache and PATCH the row in place if it exists,
    // otherwise INSERT a new one.
    const existing = (diaData.researchOutcomes || []).find(function(o) {
      return o && o.queue_type === 'property_review'
        && String(o.clinic_id) === String(clinicId);
    });

    const payload = {
      queue_type: 'property_review',
      clinic_id: String(clinicId),
      status: 'approved_link',
      notes: 'Linked from suggested candidate',
      selected_property_id: propertyId,
      source_name: 'manual_verify',
      assigned_at: new Date().toISOString()
    };

    let result;
    if (existing) {
      result = await applyChangeWithFallback({
        proxyBase: '/api/dia-query',
        table: 'research_queue_outcomes',
        idColumn: 'clinic_id',
        idValue: String(clinicId),
        matchFilters: [{ column: 'queue_type', value: 'property_review' }],
        data: payload,
        source_surface: 'dialysis_property_review',
        propagation_scope: 'research_queue_outcome'
      });
    } else {
      result = await applyInsertWithFallback({
        proxyBase: '/api/dia-query',
        table: 'research_queue_outcomes',
        idColumn: 'clinic_id',
        recordIdentifier: String(clinicId),
        data: payload,
        source_surface: 'dialysis_property_review',
        propagation_scope: 'research_queue_outcome'
      });

      // Race condition fallback: another writer (the auto-link cron, a parallel
      // tab, or the user double-clicking past the in-flight guard) may have
      // inserted an outcome row between our cache check and our request,
      // causing 409 from the UNIQUE(queue_type, clinic_id) constraint. Treat
      // that as "someone got there first" and PATCH the existing row to
      // record the user's intent (which may differ — e.g. they want a
      // different selected_property_id than the auto-linker chose).
      const looks_like_409 = !result.ok
        && Array.isArray(result.errors)
        && result.errors.some(e => /409/.test(String(e)));
      if (looks_like_409) {
        result = await applyChangeWithFallback({
          proxyBase: '/api/dia-query',
          table: 'research_queue_outcomes',
          idColumn: 'clinic_id',
          idValue: String(clinicId),
          matchFilters: [{ column: 'queue_type', value: 'property_review' }],
          data: payload,
          source_surface: 'dialysis_property_review',
          propagation_scope: 'research_queue_outcome'
        });
      }
    }

    if (!result || !result.ok) {
      const msg = (result && result.errors && result.errors.join('; ')) || 'unknown error';
      showToast('Failed to save link: ' + msg, 'error');
      return;
    }

    showToast('Linked to Property #' + propertyId, 'success');

    // Persist the canonical link in properties.medicare_id so the gap view
    // recognizes the clinic as linked. This is the field
    // v_clinic_lease_data_gaps joins on; without it the clinic stays in the
    // queue forever (regardless of medicare_clinics.property_id state).
    // Best-effort: the outcome row above is the durable user decision; this
    // patch is a follow-up that lets the queue self-clean.
    try {
      await applyChangeWithFallback({
        proxyBase: '/api/dia-query',
        table: 'properties',
        idColumn: 'property_id',
        idValue: propertyId,
        data: { medicare_id: String(clinicId) },
        source_surface: 'dialysis_property_review',
        propagation_scope: 'property_clinic_link'
      });
    } catch (linkErr) {
      console.warn('[propResLinkFromQueue] properties.medicare_id patch failed:', linkErr);
    }

    // Refresh outcomes cache so the queue advances and this row is hidden.
    try {
      const fresh = await diaQuery('research_queue_outcomes', '*', { limit: 500 });
      diaData.researchOutcomes = fresh || [];
    } catch (_) { /* non-fatal */ }

    canonicalBridge('log_activity', {
      title: 'Property link approved',
      domain: 'dialysis',
      source_system: 'dia',
      // R35: the dia ASSET identity is the property_id, NOT the clinic CCN.
      // Passing the CCN here used to mint a (dia, asset, <CCN>) junk identity.
      external_id: String(propertyId),
      user_name: (typeof LCC_USER !== 'undefined' && LCC_USER.display_name) || 'unknown',
      metadata: { clinic_id: clinicId, property_id: propertyId, source: 'one_click_candidate' }
    });

    // Drop the linked clinic out of the in-memory queue so the next
    // render skips it. Avoid a full loadDiaData() reload — that re-runs
    // 10+ queries and can take 20s on a slow connection.
    const cidStr = String(clinicId);
    diaData.propertyReviewQueue = (diaData.propertyReviewQueue || []).filter(function(r) {
      return String(r.clinic_id) !== cidStr;
    });

    // Selection index points into the *filtered* slice, so recompute against
    // the new filtered length and clamp.
    const filtered = diaData.propertyReviewQueue.filter(function(r) {
      return !diaPropertyFilter.review_type || r.review_type === diaPropertyFilter.review_type;
    });
    if (filtered.length === 0) {
      diaPropertyFilter.selectedIdx = undefined;
    } else {
      const targetIdx = (typeof diaPropertyFilter.selectedIdx === 'number')
        ? diaPropertyFilter.selectedIdx
        : 0;
      diaPropertyFilter.selectedIdx = Math.min(targetIdx, filtered.length - 1);
    }

    renderDiaTab();
  } catch (err) {
    console.error('propResLinkFromQueue error:', err);
    showToast('Failed to save link: ' + (err.message || 'unknown error'), 'error');
  } finally {
    _propResLinkInFlight = false;
  }
};

function renderPropertyResolution(rec, sourceTable, sourceIdCol) {
  if (rec.property_id) {
    return `<div class="prop-linked" style="padding:8px;background:var(--bg2);border-radius:6px;margin:8px 0;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
        <span style="color:var(--success);font-size:12px;">✓ Linked to Property #${rec.property_id}</span>
        <div style="display:flex;gap:4px;">
          <button onclick="openUnifiedDetail('dialysis',{property_id:${rec.property_id}})" style="font-size:11px;padding:2px 8px;background:var(--accent);color:#fff;border:none;border-radius:4px;cursor:pointer;">View</button>
          <button onclick="document.getElementById('propResRelink').style.display=document.getElementById('propResRelink').style.display==='none'?'block':'none'" style="font-size:11px;padding:2px 8px;background:var(--s3);color:var(--text2);border:1px solid var(--border);border-radius:4px;cursor:pointer;">Search / Re-link</button>
        </div>
      </div>
      <div id="propResRelink" style="display:none;margin-top:6px;padding-top:6px;border-top:1px solid var(--border);">
        <div style="display:flex;gap:6px;margin-bottom:6px;">
          <input type="text" id="propResSearch" placeholder="Search by address or name..." onkeydown="if(event.key==='Enter'){event.preventDefault();propResDoSearch('${sourceTable}','${sourceIdCol}',${rec[sourceIdCol]||'null'});}" style="flex:1;padding:5px 8px;font-size:11px;border:1px solid var(--border);border-radius:4px;background:var(--bg);color:var(--text);">
          <button onclick="propResDoSearch('${sourceTable}','${sourceIdCol}',${rec[sourceIdCol]||'null'})" style="padding:5px 10px;font-size:11px;background:var(--accent);color:#fff;border:none;border-radius:4px;cursor:pointer;">Search</button>
        </div>
        <div id="propResResults" style="max-height:150px;overflow-y:auto;"></div>
      </div>
    </div>`;
  }

  return `<div class="prop-resolution" style="padding:10px;background:var(--bg2);border-radius:6px;margin:8px 0;border:1px dashed var(--warning);">
    <div style="font-size:12px;font-weight:600;color:var(--warning);margin-bottom:8px;">⚠ No Property Linked</div>
    <div style="display:flex;gap:8px;margin-bottom:8px;">
      <input type="text" id="propResSearch" placeholder="Search by address or name..." onkeydown="if(event.key==='Enter'){event.preventDefault();propResDoSearch('${sourceTable}','${sourceIdCol}',${rec[sourceIdCol]||'null'});}" style="flex:1;padding:6px 10px;font-size:12px;border:1px solid var(--border);border-radius:4px;background:var(--bg);color:var(--text);">
      <button onclick="propResDoSearch('${sourceTable}','${sourceIdCol}',${rec[sourceIdCol] || 'null'})" style="padding:6px 12px;font-size:11px;background:var(--accent);color:#fff;border:none;border-radius:4px;cursor:pointer;">Search</button>
    </div>
    <div id="propResResults" style="max-height:150px;overflow-y:auto;margin-bottom:8px;"></div>
    <button onclick="propResShowCreate('${sourceTable}','${sourceIdCol}',${rec[sourceIdCol] || 'null'})" style="font-size:11px;padding:4px 10px;background:var(--bg);color:var(--text);border:1px solid var(--border);border-radius:4px;cursor:pointer;">+ Create New Property</button>
    <div id="propResCreateForm" style="display:none;margin-top:8px;"></div>
  </div>`;
}

function _clCtx(label, value) {
  return `<div><span style="color:var(--text3);font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px">${label}</span><div style="font-weight:500;color:var(--text)">${value}</div></div>`;
}

function _clInput(label, id, value, type) {
  return `<div>
    <label style="font-size:11px;font-weight:600;color:var(--text2);display:block;margin-bottom:3px">${label}</label>
    <input type="${type || 'text'}" id="${id}" value="${esc(value || '')}" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box">
  </div>`;
}

/**
 * Save clinic lead research — writes to research_queue_outcomes + updates properties if data entered
 */
let _diaClinicSaving = false;
async function saveClinicLeadResearch(rec) {
  if (_diaClinicSaving) { showToast('Save in progress', 'info'); return; }
  _diaClinicSaving = true;
  try { await _saveClinicLeadResearchInner(rec); } finally { _diaClinicSaving = false; }
}
async function _saveClinicLeadResearchInner(rec) {
  // Capture current step's visible fields into draft before reading
  _captureClinicFormDraft();
  var draft = window._diaClinicFormDraft;

  // Read from DOM (current step) or draft (other steps)
  function _clVal(id) {
    var el = document.getElementById(id);
    if (el && el.value) return el.value;
    return draft[id] || null;
  }

  const data = {
    recorded_owner: _clVal('cl-recorded-owner'),
    true_owner: _clVal('cl-true-owner'),
    state_of_incorporation: _clVal('cl-incorporation'),
    principal_names: _clVal('cl-principals'),
    contact_email: _clVal('cl-email'),
    contact_phone: _clVal('cl-phone'),
    phone_2: _clVal('cl-phone-2'),
    mailing_address: _clVal('cl-mailing'),
    mailing_address_2: _clVal('cl-mailing-2'),
    pipeline_status: _clVal('cl-pipeline-status'),
    notes: _clVal('cl-notes'),
    property_id: _clVal('cl-property-id')
  };

  const _anyClField = Object.values(data).some(v => v !== null && v !== undefined && String(v).trim() !== '');
  if (!_anyClField) { showToast('Please fill in at least one field before saving', 'info'); return; }

  var _propId = data.property_id || rec.property_id;

  // 1. Save research outcome
  const outcomeOk = await saveClinicLeadOutcome(rec.medicare_id, 'completed', data.notes, _propId);
  if (!outcomeOk) return;

  // 2. If we have owner info and a property_id, update the property's owner fields
  if (_propId && (data.recorded_owner || data.true_owner)) {
    const propUpdate = {};
    if (data.recorded_owner) propUpdate.tenant = data.recorded_owner; // recorded_owner maps to tenant field for display
    await diaPatchRecord('properties', 'property_id', _propId, propUpdate);
  }

  // Bridge to canonical model
  canonicalBridge('complete_research', {
    domain: 'dialysis',
    research_type: 'clinic_lead',
    external_id: String(rec.medicare_id || rec.property_id),
    source_system: 'dia',
    source_type: rec.property_id ? 'asset' : 'clinic',
    outcome: 'completed',
    notes: data.notes,
    source_record_id: String(rec.medicare_id || rec.property_id),
    source_table: rec.property_id ? 'properties' : 'clinic_leads',
    title: rec.facility_name || rec.address || `Clinic ${rec.medicare_id || rec.property_id}`,
    entity_fields: {
      name: rec.facility_name || rec.address || `Clinic ${rec.medicare_id || rec.property_id}`,
      address: rec.address || null,
      city: rec.city || null,
      state: rec.state || null,
      asset_type: 'dialysis_clinic'
    }
  });

  showToast('Clinic lead saved!', 'success');

  // Advance to next
  diaClinicLeadFilter.selectedIdx = undefined;
  renderDiaTab();
}

/**
 * Mark a clinic lead as N/A or other quick-status
 */
async function markClinicLead(rec, status) {
  const ok = await saveClinicLeadOutcome(rec.medicare_id, status, null, rec.property_id);
  if (!ok) return; // saveClinicLeadOutcome already showed error toast

  // Bridge to canonical model
  canonicalBridge(status === 'not_applicable' ? 'dismiss_lead' : 'complete_research', {
    domain: 'dialysis',
    research_type: 'clinic_lead',
    external_id: String(rec.medicare_id || rec.property_id),
    source_system: 'dia',
    outcome: status,
    reason: status
  });

  showToast(`Marked as ${status.replace('_', ' ')}`, 'success');
  diaClinicLeadFilter.selectedIdx = undefined;
  renderDiaTab();
}

/**
 * Persist to research_queue_outcomes for clinic_lead queue type
 */
async function saveClinicLeadOutcome(clinicId, status, notes, propertyId) {
  try {
    const payload = {
      queue_type: 'clinic_lead',
      clinic_id: clinicId,
      status: status,
      notes: notes || null,
      selected_property_id: propertyId || null,
      assigned_at: new Date().toISOString()
    };

    const result = await applyInsertWithFallback({
      proxyBase: '/api/dia-query',
      table: 'research_queue_outcomes',
      idColumn: 'clinic_id',
      recordIdentifier: clinicId,
      data: payload,
      source_surface: 'dialysis_clinic_leads',
      propagation_scope: 'research_queue_outcome'
    });

    if (!result.ok) {
      console.error('Clinic lead save error:', result.errors || []);
      showToast('Error saving clinic lead', 'error');
      return false;
    }

    // Refresh outcomes cache
    const freshOutcomes = await diaQuery('research_queue_outcomes', '*', { limit: 500 });
    diaData.researchOutcomes = freshOutcomes || [];

    canonicalBridge('log_activity', {
      title: 'Clinic lead outcome recorded',
      domain: 'dialysis',
      source_system: 'dia',
      // R35: dia ASSET identity is the property_id, not the clinic CCN.
      external_id: String(propertyId),
      user_name: (typeof LCC_USER !== 'undefined' && LCC_USER.display_name) || 'unknown',
      metadata: { clinic_id: clinicId, status: status, notes: notes, property_id: propertyId }
    });

    return true;
  } catch (err) {
    console.error('saveClinicLeadOutcome error:', err);
    showToast('Error saving: ' + err.message, 'error');
    return false;
  }
}

/**
 * Save research outcome
 */
async function saveDiaOutcome(queueType, clinicId, status, propId, notes, source, term, rent, rentSF) {
  try {
    // research_queue_outcomes only has these columns:
    //   queue_type, clinic_id, status, notes, selected_property_id,
    //   selected_candidate_property_ids, source_bucket, source_name,
    //   assigned_to, assigned_at, root_cause, confidence_*, etc.
    //
    // Earlier versions of this function included lease_term, annual_rent,
    // rent_per_sf, and verification_source — none of which exist on this
    // table. PostgREST rejected the writes with http_400 ("Could not find
    // column 'lease_term' on table 'research_queue_outcomes'"). The
    // Confirm Link path now uses propResLinkFromQueue which builds its
    // own clean payload, but the Reject path still hit this bug.
    //
    // Stripped to the columns that actually exist. Lease-specific fields
    // (term, rent, rentSF) are still captured — they just go into the
    // notes field as a structured suffix so we don't lose the info.
    const payload = {
      queue_type: queueType,
      clinic_id: String(clinicId),
      status: status,
      notes: notes || null,
      selected_property_id: propId ? Number(propId) : null,
      source_name: source || null,
      assigned_at: new Date().toISOString()
    };

    // Append lease-specific values into notes if provided (they have no
    // home on research_queue_outcomes itself).
    const leaseSuffix = [];
    if (term) leaseSuffix.push('term: ' + term);
    if (rent) leaseSuffix.push('annual_rent: ' + rent);
    if (rentSF) leaseSuffix.push('rent_per_sf: ' + rentSF);
    if (leaseSuffix.length > 0) {
      payload.notes = (payload.notes ? payload.notes + ' | ' : '') + leaseSuffix.join(', ');
    }

    // Try PATCH (existing row) first; fall back to INSERT if no row matched.
    // research_queue_outcomes has UNIQUE(queue_type, clinic_id) so we can't
    // double-insert; the bridge's 409 fallback (PR #480) catches the race.
    const existing = (diaData.researchOutcomes || []).find(function(o) {
      return o && o.queue_type === queueType && String(o.clinic_id) === String(clinicId);
    });

    let result;
    if (existing) {
      result = await applyChangeWithFallback({
        proxyBase: '/api/dia-query',
        table: 'research_queue_outcomes',
        idColumn: 'clinic_id',
        idValue: String(clinicId),
        matchFilters: [{ column: 'queue_type', value: queueType }],
        data: payload,
        source_surface: 'dialysis_research_outcome',
        propagation_scope: 'research_queue_outcome'
      });
    } else {
      result = await applyInsertWithFallback({
        proxyBase: '/api/dia-query',
        table: 'research_queue_outcomes',
        idColumn: 'clinic_id',
        recordIdentifier: String(clinicId),
        data: payload,
        source_surface: 'dialysis_research_outcome',
        propagation_scope: 'research_queue_outcome'
      });
    }

    if (!result.ok) {
      throw new Error('Failed to save outcome: ' + (result.errors || []).join('; '));
    }

    showToast('Outcome saved', 'success');
    canonicalBridge('log_activity', {
      title: 'Research outcome saved',
      domain: 'dialysis',
      source_system: 'dia',
      // R35: dia ASSET identity is the property_id, not the clinic CCN.
      external_id: String(propId),
      user_name: (typeof LCC_USER !== 'undefined' && LCC_USER.display_name) || 'unknown',
      metadata: { queue_type: queueType, clinic_id: clinicId, status: status, property_id: propId, notes: notes, source: source, lease_term: term, annual_rent: rent, rent_per_sf: rentSF }
    });

    // Drop the resolved clinic from the in-memory queue so the next render
    // skips it. The MV refresh happens on the 1-min cron; in the meantime
    // the local pop gives an instant queue-advance UX. Avoid loadDiaData() —
    // that re-runs 10+ Promise.all queries (~20s on slow connections).
    // (Same pattern as propResLinkFromQueue — see PR #469.)
    const cidStr = String(clinicId);
    if (queueType === 'property_review') {
      diaData.propertyReviewQueue = (diaData.propertyReviewQueue || []).filter(function(r) {
        return String(r.clinic_id) !== cidStr;
      });
      const filtered = diaData.propertyReviewQueue.filter(function(r) {
        return !diaPropertyFilter.review_type || r.review_type === diaPropertyFilter.review_type;
      });
      if (filtered.length === 0) {
        diaPropertyFilter.selectedIdx = undefined;
        showToast('Outcome saved — queue complete!', 'success');
      } else {
        const target = (typeof diaPropertyFilter.selectedIdx === 'number')
          ? diaPropertyFilter.selectedIdx : 0;
        diaPropertyFilter.selectedIdx = Math.min(target, filtered.length - 1);
        showToast('Outcome saved — advancing to next item', 'success');
      }
    } else {
      diaData.leaseBackfillRows = (diaData.leaseBackfillRows || []).filter(function(r) {
        return String(r.clinic_id) !== cidStr;
      });
      const filtered = diaData.leaseBackfillRows.filter(function(r) {
        return !diaLeaseFilter.priority || r.lease_backfill_priority === diaLeaseFilter.priority;
      });
      if (filtered.length === 0) {
        diaLeaseFilter.selectedIdx = undefined;
        showToast('Outcome saved — queue complete!', 'success');
      } else {
        const target = (typeof diaLeaseFilter.selectedIdx === 'number')
          ? diaLeaseFilter.selectedIdx : 0;
        diaLeaseFilter.selectedIdx = Math.min(target, filtered.length - 1);
        showToast('Outcome saved — advancing to next item', 'success');
      }
    }

    // Refresh outcomes cache so the audit panel picks up the new row, then
    // re-render. Both cheap; no full data reload.
    try {
      const fresh = await diaQuery('research_queue_outcomes',
        'outcome_id,clinic_id,queue_type,status,assigned_to,assigned_at,created_at,source_name,selected_property_id,notes',
        { limit: 2000 });
      diaData.researchOutcomes = fresh || [];
    } catch (_) { /* non-fatal */ }

    renderDiaTab();
    return true;
  } catch (err) {
    console.error('saveDiaOutcome error:', err);
    showToast('Failed to save outcome: ' + err.message, 'error');
    return false;
  }
}

// ============================================================================
// ACTIVITY TAB
// ============================================================================

/**
 * Render activity/audit log tab
 */
function renderDiaActivity() {
  let html = '<div class="biz-section">';
  
  html += '<h3 class="gov-chart-title">Recent Activity</h3>';
  
  html += '<div class="data-table">';
  
  const outcomes = diaData.researchOutcomes || [];
  
  if (outcomes.length === 0) {
    html += '<div class="table-empty">No activity recorded</div>';
  } else {
    html += '<div class="table-row" style="font-weight: 600; border-bottom: 1px solid var(--border);">';
    html += '<div style="flex: 1;">Queue Type</div>';
    html += '<div style="flex: 0.5;">Clinic ID</div>';
    html += '<div style="flex: 1;">Status</div>';
    html += '<div style="flex: 1.5;">Assigned To</div>';
    html += '<div style="flex: 1;">Date</div>';
    html += '<div style="flex: 0.5;">Action</div>';
    html += '</div>';
    
    outcomes.slice(0, 100).forEach(row => {
      const statusColor = row.status === 'verified_lease' || row.status === 'approved_link' ? '#34d399' : 'var(--text2)';

      html += `<div class="table-row clickable-row" onclick='showDetail(${safeJSON(row)}, "dia-clinic")'>`;
      html += `<div style="flex: 1;">${esc(row.queue_type || 'unknown')}</div>`;
      html += `<div style="flex: 0.5; color: var(--text2);">${esc(String(row.clinic_id || ''))}</div>`;
      html += `<div style="flex: 1; color: ${statusColor};">${esc(row.status || 'unknown')}</div>`;
      html += `<div style="flex: 1.5;">${row.assigned_to ? esc(row.assigned_to) : '–'}</div>`;
      html += `<div style="flex: 1; color: var(--text2);">${fmt(row.assigned_at || row.created_at)}</div>`;
      html += `<div style="flex: 0.5; text-align: right;"><button class="act-btn" style="font-size:10px;padding:2px 6px" onclick="event.stopPropagation();reopenDiaOutcome('${esc(row.queue_type || '')}','${esc(String(row.clinic_id || ''))}')">Reopen</button></div>`;
      html += '</div>';
    });
  }
  
  html += '</div>';
  html += '</div>';
  
  return html;
}

async function reopenDiaOutcome(queueType, clinicId) {
  if (!(await lccConfirm('Reopen this item? It will be returned to the research queue.', 'Reopen'))) return;
  try {
    const result = await applyChangeWithFallback({
      proxyBase: '/api/dia-query',
      table: 'research_queue_outcomes',
      idColumn: 'clinic_id',
      idValue: clinicId,
      matchFilters: [{ column: 'queue_type', value: queueType }],
      data: { status: 'reopened', reopened_at: new Date().toISOString() },
      source_surface: 'dialysis_activity_reopen',
      propagation_scope: 'research_queue_outcome'
    });
    if (result.ok) {
      showToast('Item reopened', 'success');
      await loadDiaData();
      renderDiaTab();
    } else {
      showToast('Reopen failed', 'error');
    }
  } catch (err) {
    console.error('Reopen error:', err);
    showToast('Error: ' + err.message, 'error');
  }
}

// ============================================================================
// DETAIL PANEL RENDERER
// ============================================================================

/**
 * Main detail panel renderer - dispatches to tab-specific renderers
 */
function renderDiaDetailBody(record, tab) {
  tab = (tab || 'Overview').toLowerCase();

  if (!record) {
    return '<div class="detail-empty">No record selected</div>';
  }

  let html = '';

  switch (tab) {
    case 'overview':
      html = renderDiaDetailOverview(record);
      break;
    case 'property':
      html = renderDiaDetailProperty(record);
      break;
    case 'ownership':
      html = renderDiaDetailOwnership(record);
      break;
    case 'signals':
      html = renderDiaDetailSignals(record);
      break;
    case 'research':
      html = renderDiaDetailResearch(record);
      break;
    case 'activity':
      html = renderDiaDetailActivity(record);
      break;
    default:
      html = renderDiaDetailOverview(record);
  }

  return html;
}

/**
 * Overview tab — comprehensive facility info with financials, lease, and ownership summary
 */
function renderDiaDetailOverview(record) {
  const r = record;
  let html = '<div class="detail-section">';

  // Facility identity
  html += '<div class="detail-section-title">' + esc(r.facility_name || '—') + '</div>';
  html += _detRow('Address', [r.address, r.city, r.state, r.zip_code].filter(Boolean).join(', ') || '—');
  html += _detRow('CCN / Medicare ID', r.ccn || r.clinic_id || r.medicare_id || '—');
  html += _detRow('NPI', r.npi || r.medicare_npi || '—');
  html += _detRow('Operator', (r.operator_name || r.chain_organization) ? entityLink(r.operator_name || r.chain_organization, 'operator', null) : '—');
  html += _detRow('Parent Org', r.parent_organization || '—');
  html += _detRow('Stations', r.stations || r.number_of_chairs || '—');

  // Modality & Patient metrics
  const modLabel = r.modality_type === 'hybrid' ? 'Hybrid (IC + Home)' : r.modality_type === 'home' ? 'Home Only' : 'In-Center';
  const modColor = r.modality_type === 'hybrid' ? '#fbbf24' : r.modality_type === 'home' ? '#a78bfa' : '#34d399';
  html += '<div class="detail-section-title" style="margin-top:20px">Patient Volume</div>';
  html += '<div class="detail-row"><div class="detail-lbl">Modality</div><div class="detail-val" style="color:' + modColor + ';font-weight:600">' + modLabel + '</div></div>';
  html += _detRow('CMS Total Patients', r.latest_total_patients != null ? fmtN(r.latest_total_patients) : '—');
  const icPts = Number(r.est_in_center_patients) || 0;
  const hmPts = Number(r.est_home_patients) || 0;
  if (r.modality_type === 'hybrid' || r.modality_type === 'home') {
    html += '<div class="detail-row"><div class="detail-lbl">Est. In-Center Pts</div><div class="detail-val" style="color:#34d399;font-weight:600">' + fmtN(icPts) + '</div></div>';
    html += '<div class="detail-row"><div class="detail-lbl">Est. Home Pts</div><div class="detail-val" style="color:#a78bfa;font-weight:600">' + fmtN(hmPts) + '</div></div>';
  }
  html += _detRow('Capacity Utilization', r.capacity_utilization_pct ? r.capacity_utilization_pct + '%' : '—');

  // Financial summary — bifurcated
  html += '<div class="detail-section-title" style="margin-top:20px">Financials</div>';
  if (r.estimated_annual_revenue) {
    html += _detRow('TTM Revenue (Reported)', '$' + Number(r.estimated_annual_revenue).toLocaleString(undefined, {maximumFractionDigits: 0}));
  }
  const icRev = Number(r.est_in_center_revenue) || 0;
  const hmRev = Number(r.est_home_revenue) || 0;
  const combRev = Number(r.est_combined_revenue) || 0;
  if (r.modality_type === 'hybrid') {
    html += '<div class="detail-row"><div class="detail-lbl">Est. IC Revenue</div><div class="detail-val" style="color:#34d399">$' + icRev.toLocaleString(undefined, {maximumFractionDigits: 0}) + '</div></div>';
    html += '<div class="detail-row"><div class="detail-lbl">Est. Home Revenue</div><div class="detail-val" style="color:#a78bfa">$' + hmRev.toLocaleString(undefined, {maximumFractionDigits: 0}) + '</div></div>';
    html += _detRow('Est. Combined Revenue', '$' + combRev.toLocaleString(undefined, {maximumFractionDigits: 0}));
  } else if (r.modality_type === 'home') {
    html += '<div class="detail-row"><div class="detail-lbl">Est. Home Revenue</div><div class="detail-val" style="color:#a78bfa">$' + hmRev.toLocaleString(undefined, {maximumFractionDigits: 0}) + '</div></div>';
  } else {
    html += _detRow('Est. IC Revenue', '$' + icRev.toLocaleString(undefined, {maximumFractionDigits: 0}));
  }
  html += _detRow('Est. EBITDA', r.estimated_ebitda ? '$' + Number(r.estimated_ebitda).toLocaleString(undefined, {maximumFractionDigits: 0}) : '—');
  html += _detRow('Operating Margin', r.operating_margin_assumption ? (Number(r.operating_margin_assumption) * 100).toFixed(1) + '%' : '—');
  html += _detRow('Payer Mix (Medicare)', r.payer_mix_medicare ? (Number(r.payer_mix_medicare) * 100).toFixed(0) + '%' : '—');
  html += _detRow('Payer Mix (Commercial)', r.payer_mix_commercial ? (Number(r.payer_mix_commercial) * 100).toFixed(0) + '%' : '—');

  // Lease summary (if present)
  html += '<div class="detail-section-title" style="margin-top:20px">Lease</div>';
  if (r.lease_id) {
    html += _detRow('Tenant', r.lease_tenant || '—');
    html += _detRow('Lease Start', r.lease_start || '—');
    html += _detRow('Lease Expiration', r.lease_expiration || '—');
    html += _detRow('Rent', r.rent ? '$' + Number(r.rent).toLocaleString(undefined, {maximumFractionDigits: 0}) : '—');
    html += _detRow('Rent PSF', r.rent_per_sf ? '$' + Number(r.rent_per_sf).toFixed(2) : '—');
    html += _detRow('Expense Structure', r.expense_structure || '—');
    html += _detRow('Guarantor', r.guarantor || '—');
    html += _detRow('Renewal Options', r.renewal_options || '—');
    if (r.lease_expiration_risk) {
      const riskColor = r.lease_expiration_risk === 'high' ? '#f87171' : r.lease_expiration_risk === 'medium' ? '#fbbf24' : '#34d399';
      html += '<div class="detail-row"><div class="detail-lbl">Expiration Risk</div><div class="detail-val" style="color:' + riskColor + ';font-weight:600">' + esc(r.lease_expiration_risk) + '</div></div>';
    }
  } else {
    html += '<div style="color:var(--text3);font-size:12px;padding:4px 0">No active lease linked</div>';
  }

  // Ownership summary (if present)
  html += '<div class="detail-section-title" style="margin-top:20px">Ownership</div>';
  if (r.ownership_id) {
    html += _detRow('Recorded Owner', r.recorded_owner_name || '—');
    html += _detRow('True Owner / Developer', r.true_owner_name || '— not traced');
    html += _detRow('Owner Type', r.owner_type || '—');
    html += _detRow('Ownership Start', r.ownership_start || '—');
    html += _detRow('Last Sale Price', r.last_sold_price ? '$' + Number(r.last_sold_price).toLocaleString(undefined, {maximumFractionDigits: 0}) : '—');
    if (r.is_developer) html += _detRow('Developer?', 'Yes');
  } else {
    html += '<div style="color:var(--text3);font-size:12px;padding:4px 0">No ownership chain linked — <span style="color:var(--accent);cursor:pointer" onclick="switchUnifiedTab(\'Ownership\')">resolve now</span></div>';
  }

  html += '</div>';
  return html;
}

function _detRow(label, value) {
  return '<div class="detail-row"><div class="detail-lbl">' + label + '</div><div class="detail-val">' + esc(String(value || '—')) + '</div></div>';
}

/**
 * Property tab — location, building info, and inventory snapshots
 */
function renderDiaDetailProperty(record) {
  const r = record;
  let html = '<div class="detail-section">';

  html += '<div class="detail-section-title">Property Information</div>';
  html += _detRow('Facility', r.facility_name || '—');
  html += _detRow('Address', r.address || '—');
  html += _detRow('City / State', (r.city || '—') + ', ' + (r.state || '—'));
  html += _detRow('ZIP', r.zip_code || '—');
  // Use != null so that a legitimate property_id of 0 is still treated as linked.
  html += _detRow('Property ID', r.property_id != null ? r.property_id : 'Not linked');
  html += _detRow('Building Size', r.building_size ? fmtN(Math.round(Number(r.building_size))) + ' SF' : '—');
  html += _detRow('Land Area', r.land_area ? fmtN(Math.round(Number(r.land_area))) + ' SF' : '—');
  // Treat 0 as "unknown" — CoStar sometimes sends blank Year Built as 0.
  const ybNum = Number(r.year_built);
  html += _detRow('Year Built', (r.year_built && ybNum >= 1600 && ybNum <= 2100) ? ybNum : '—');
  html += _detRow('Stations', r.stations || r.number_of_chairs || '—');

  // Ownership vs operator — never conflate the two.
  // "Recorded Owner" is the deed holder (e.g. Agree Central LLC) sourced from the
  // recorded_owners table via v_property_detail. "Tenant / Operator" is the facility
  // operator (e.g. DaVita Kidney Care) sourced from CMS clinic data. Earlier versions
  // of this renderer leaked the CMS operator into the "Owner" slot via a data merge —
  // keep them on separate rows so the display cannot regress.
  html += '<div class="detail-section-title" style="margin-top:20px">Ownership &amp; Operator</div>';
  html += _detRow('Recorded Owner', r.recorded_owner_name || '— unknown');
  if (r.recorded_owner_address) {
    html += _detRow('Recorded Owner Address', r.recorded_owner_address);
  }
  html += _detRow('Tenant / Operator', r.operator_name || r.chain_organization || '—');

  // Lease detail section
  html += '<div class="detail-section-title" style="margin-top:20px">Active Lease</div>';
  if (r.lease_id) {
    html += _detRow('Tenant', r.lease_tenant || '—');
    html += _detRow('Lease Start', r.lease_start || '—');
    html += _detRow('Lease Expiration', r.lease_expiration || '—');
    html += _detRow('Renewal Options', r.renewal_options || '—');
    html += _detRow('Rent', r.rent ? '$' + Number(r.rent).toLocaleString(undefined, {maximumFractionDigits: 0}) : '—');
    html += _detRow('Rent PSF', r.rent_per_sf ? '$' + Number(r.rent_per_sf).toFixed(2) : '—');
    html += _detRow('Expense Structure', r.expense_structure || '—');
    html += _detRow('Guarantor', r.guarantor || '—');
    html += _detRow('Lease Status', r.lease_status || '—');
    if (r.lease_expiration_risk) {
      const riskColor = r.lease_expiration_risk === 'high' ? '#f87171' : r.lease_expiration_risk === 'medium' ? '#fbbf24' : '#34d399';
      html += '<div class="detail-row"><div class="detail-lbl">Expiration Risk</div><div class="detail-val" style="color:' + riskColor + ';font-weight:600">' + esc(r.lease_expiration_risk) + '</div></div>';
    }
  } else {
    html += '<div style="color:var(--text3);font-size:12px;padding:4px 0">No active lease found for this property</div>';
  }

  html += '</div>';
  return html;
}

/**
 * Ownership tab — view chain and resolve ownership back to developer
 *
 * Uses the v_ownership_chain array (loaded by detail.js into window._udCache.chain)
 * to render a full timeline of every recorded owner for this property, most recent
 * at top. Falls back to the single v_ownership_current record fields embedded on
 * the record when no chain is available (e.g. when this renderer is invoked
 * outside of the unified detail panel flow).
 */
function renderDiaDetailOwnership(record) {
  const r = record;
  let html = '<div class="detail-section">';

  html += '<div class="detail-section-title">Ownership Chain</div>';

  // Pull chain from the unified detail cache when available. detail.js populates
  // window._udCache.chain via openUnifiedDetail() before invoking any tab renderer.
  const chain = (window._udCache && Array.isArray(window._udCache.chain))
    ? window._udCache.chain
    : [];

  if (chain.length > 0) {
    // 90-day fallback rule: if the most-recent entry has an ownership_end within
    // 90 days of today, treat it as current. This guards against stale end dates
    // on the active ownership record (e.g. Agree Central's 2026-03-13 bug).
    const NINETY_DAYS_MS = 90 * 24 * 60 * 60 * 1000;
    const nowMs = Date.now();
    const isChainEntryCurrent = (entry, isMostRecent) => {
      if (!isMostRecent) return false;
      if (!entry.ownership_end) return true;
      const endMs = new Date(entry.ownership_end).getTime();
      if (isNaN(endMs)) return true;
      return Math.abs(nowMs - endMs) <= NINETY_DAYS_MS;
    };

    html += '<div class="detail-timeline">';
    chain.forEach((h, idx) => {
      const isFirst = idx === 0;
      const isCurrent = isChainEntryCurrent(h, isFirst);
      const ownerLabel = h.recorded_owner_name || h.true_owner_name || '—';
      const startStr = h.transfer_date
        ? new Date(h.transfer_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
        : 'Unknown';
      const endStr = isCurrent
        ? 'Present'
        : (h.ownership_end
            ? new Date(h.ownership_end).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
            : 'Unknown');
      const priceStr = h.sale_price
        ? '$' + Number(h.sale_price).toLocaleString(undefined, { maximumFractionDigits: 0 })
        : 'Not Disclosed';
      const capStr = h.cap_rate ? Number(h.cap_rate).toFixed(2) + '%' : '—';

      html += '<div class="detail-timeline-item ' + (isCurrent ? 'green' : '') + '" style="margin-bottom:10px">';
      html += '<div class="detail-card-date">' + esc(startStr) + ' → ' + esc(endStr);
      if (isCurrent) html += ' <span class="detail-badge" style="background:var(--green);color:#fff;margin-left:6px">Current</span>';
      html += '</div>';
      // Clickable owner name — opens the entity/contact by name so the user
      // can jump from the ownership chain into LCC Contacts.
      html += '<div class="detail-card-title">' + (typeof entityLink === 'function' ? entityLink(ownerLabel, 'contact', null) : esc(ownerLabel)) + '</div>';
      html += '<div class="detail-card-body">';
      if (h.true_owner_name && h.recorded_owner_name && h.true_owner_name !== h.recorded_owner_name) {
        html += '<span style="font-size:12px;color:var(--text3)">True Owner:</span> ' + (typeof entityLink === 'function' ? entityLink(h.true_owner_name, 'contact', null) : esc(h.true_owner_name)) + '<br>';
      }
      html += '<div style="font-size:12px">Sale price: <span class="mono" style="color:var(--green)">' + esc(priceStr) + '</span> <span style="color:var(--text3)">|</span> Cap rate: ' + esc(capStr) + '</div>';
      if (h.ownership_type) html += '<div style="font-size:11px;color:var(--text3);margin-top:2px">Type: ' + esc(h.ownership_type) + '</div>';
      if (h.ownership_source) html += '<div style="font-size:11px;color:var(--text3)">Source: ' + esc(h.ownership_source) + '</div>';
      html += '</div>';
      html += '</div>';
    });
    html += '</div>';
  } else if (r.ownership_id) {
    // Fallback: no chain loaded — show the single current-ownership fields
    // embedded on the record (legacy v_ownership_current path).
    html += _detRow('Recorded Owner', r.recorded_owner_name || '— unknown');
    html += _detRow('True Owner / Developer', r.true_owner_name || '— not traced');
    html += _detRow('Owner Type', r.owner_type || '—');
    html += _detRow('Ownership Start', r.ownership_start || '—');
    html += _detRow('Last Sale Price', r.last_sold_price ? '$' + Number(r.last_sold_price).toLocaleString(undefined, {maximumFractionDigits: 0}) : '—');
  } else {
    html += '<div style="color:var(--text3);font-size:12px;padding:8px 0">No ownership records found for this property</div>';
  }

  // Ownership resolution form
  html += '<div class="detail-section-title" style="margin-top:20px">Resolve Ownership</div>';
  html += '<div style="font-size:11px;color:var(--text3);margin-bottom:10px">Trace the ownership chain back to the developer / true owner. This writes to the ownership_history table.</div>';

  html += '<div class="detail-grid" style="gap:10px">';
  html += '<div class="detail-row" style="flex-direction:column;align-items:stretch"><label style="font-size:11px;font-weight:600;color:var(--text2);margin-bottom:2px">Recorded Owner</label><input id="dia-own-recorded" type="text" value="' + esc(r.recorded_owner_name || '') + '" placeholder="Entity name on deed" style="font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text)"></div>';
  html += '<div class="detail-row" style="flex-direction:column;align-items:stretch"><label style="font-size:11px;font-weight:600;color:var(--text2);margin-bottom:2px">True Owner / Developer</label><input id="dia-own-true" type="text" value="' + esc(r.true_owner_name || '') + '" placeholder="Parent entity, developer, fund" style="font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text)"></div>';
  html += '<div class="detail-row" style="flex-direction:column;align-items:stretch"><label style="font-size:11px;font-weight:600;color:var(--text2);margin-bottom:2px">Owner Type</label><select id="dia-own-type" style="font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text)"><option value="">— Select —</option><option value="individual"' + (r.owner_type === 'individual' ? ' selected' : '') + '>Individual</option><option value="llc"' + (r.owner_type === 'llc' ? ' selected' : '') + '>LLC</option><option value="reit"' + (r.owner_type === 'reit' ? ' selected' : '') + '>REIT</option><option value="developer"' + (r.owner_type === 'developer' ? ' selected' : '') + '>Developer</option><option value="fund"' + (r.owner_type === 'fund' ? ' selected' : '') + '>Fund</option><option value="operator"' + (r.owner_type === 'operator' ? ' selected' : '') + '>Operator</option><option value="other"' + (r.owner_type === 'other' ? ' selected' : '') + '>Other</option></select></div>';
  html += '<div class="detail-row" style="flex-direction:column;align-items:stretch"><label style="font-size:11px;font-weight:600;color:var(--text2);margin-bottom:2px">Notes</label><textarea id="dia-own-notes" rows="2" placeholder="Research notes..." style="font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);resize:vertical;font-family:inherit"></textarea></div>';
  html += '</div>';

  html += '<button onclick="_udBtnGuard(this, saveDiaOwnershipResolution)" style="margin-top:12px;width:100%;padding:10px;background:var(--accent);color:#fff;border:none;border-radius:8px;font-weight:600;font-size:13px;cursor:pointer">Save Ownership</button>';

  // Quick actions
  html += '<div style="margin-top:12px;display:flex;gap:6px;flex-wrap:wrap">';
  const searchQ = (r.recorded_owner_name || r.facility_name || '') + ' ' + (r.state || '');
  html += '<a href="https://www.google.com/search?q=' + encodeURIComponent(searchQ + ' ownership') + '" target="_blank" rel="noopener" style="font-size:11px;padding:4px 10px;border-radius:6px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none">Google Owner</a>';
  if (r.state) {
    html += '<a href="https://www.google.com/search?q=' + encodeURIComponent('Secretary of State business search ' + r.state) + '" target="_blank" rel="noopener" style="font-size:11px;padding:4px 10px;border-radius:6px;background:var(--s2);border:1px solid var(--border);color:var(--text2);text-decoration:none">SOS ' + esc(r.state) + '</a>';
  }
  html += '</div>';

  html += '</div>';
  return html;
}

/**
 * Signals tab - NPI and data quality signals
 */
function renderDiaDetailSignals(record) {
  const ccn = record.ccn;
  const npi = record.npi;
  
  let html = '<div class="detail-section">';
  
  if (!ccn && !npi) {
    html += '<div class="detail-empty">No facility identifiers to look up signals</div>';
    html += '</div>';
    return html;
  }
  
  const signals = (diaData.npiSignals || []).filter(s => s.ccn === ccn || s.npi === npi);
  
  if (signals.length === 0) {
    html += '<div class="detail-empty">No signals detected for this facility</div>';
    html += '</div>';
    return html;
  }
  
  html += '<div class="detail-section-title">Data Quality Signals</div>';
  
  signals.forEach(signal => {
    const signalClass = signal.signal_type === 'npi_change' ? 'badge-warning' : 'badge-info';
    
    html += '<div class="detail-card">';
    html += '<div class="detail-card-header">';
    html += '<div class="detail-card-title">';
    html += '<span class="detail-badge ' + signalClass + '">' + esc(cleanLabel(signal.signal_type)) + '</span>';
    html += '</div>';
    html += '</div>';
    html += '<div class="detail-card-body">';
    
    if (signal.signal_type === 'npi_change') {
      html += '<div class="detail-row">';
      html += '<div class="detail-lbl">Old NPI</div>';
      html += '<div class="detail-val">' + esc(signal.old_npi || '—') + '</div>';
      html += '</div>';
      html += '<div class="detail-row">';
      html += '<div class="detail-lbl">New NPI</div>';
      html += '<div class="detail-val">' + esc(signal.new_npi || '—') + '</div>';
      html += '</div>';
    }
    
    html += '<div class="detail-row">';
    html += '<div class="detail-lbl">Patients</div>';
    html += '<div class="detail-val">' + fmtN(signal.latest_total_patients) + '</div>';
    html += '</div>';
    
    html += '</div>';
    html += '</div>';
  });
  
  html += '</div>';
  
  return html;
}

/**
 * Research tab - property review queue and lease backfill status
 */
function renderDiaDetailResearch(record) {
  const clinic_id = record.clinic_id;
  const ccn = record.ccn;
  
  let html = '<div class="detail-section">';
  
  // Property review queue items
  if (ccn && diaData.propertyReviewQueue) {
    const reviewItems = diaData.propertyReviewQueue.filter(r => r.ccn === ccn);
    
    if (reviewItems.length > 0) {
      html += '<div class="detail-section-title">Property Review Queue</div>';
      
      reviewItems.forEach(item => {
        html += '<div class="detail-card">';
        html += '<div class="detail-card-header">';
        html += '<div class="detail-card-title">' + metricHTML(item.review_type) + '</div>';
        html += '<div class="detail-card-date">' + fmt(item.created_at) + '</div>';
        html += '</div>';
        html += '<div class="detail-card-body">';
        html += '<div class="detail-row">';
        html += '<div class="detail-lbl">Facility</div>';
        html += '<div class="detail-val">' + esc(item.facility_name || '—') + '</div>';
        html += '</div>';
        html += '<div class="detail-row">';
        html += '<div class="detail-lbl">Status</div>';
        html += '<div class="detail-val">' + (item.status || '—') + '</div>';
        html += '</div>';
        html += '</div>';
        html += '</div>';
      });
    }
  }
  
  // Lease backfill items
  if (ccn && diaData.leaseBackfillRows) {
    const leaseItems = diaData.leaseBackfillRows.filter(r => r.ccn === ccn);
    
    if (leaseItems.length > 0) {
      html += '<div class="detail-section-title" style="margin-top: 24px;">Lease Backfill Status</div>';
      
      leaseItems.forEach(item => {
        html += '<div class="detail-card">';
        html += '<div class="detail-card-header">';
        html += '<div class="detail-card-title">' + esc(item.facility_name || '—') + '</div>';
        html += '<div class="detail-card-date">' + fmt(item.updated_at || item.created_at) + '</div>';
        html += '</div>';
        html += '<div class="detail-card-body">';
        html += '<div class="detail-row">';
        html += '<div class="detail-lbl">Status</div>';
        html += '<div class="detail-val">' + (item.status || 'pending') + '</div>';
        html += '</div>';
        html += '</div>';
        html += '</div>';
      });
    }
  }
  
  // Research status form
  html += '<div class="detail-section-title" style="margin-top: 24px;">Update Research Status</div>';
  
  html += '<div class="detail-form">';
  html += '<div class="form-group">';
  html += '<label style="display: block; color: var(--text2); font-size: 12px; margin-bottom: 8px; font-weight: 600;">Research Status</label>';
  html += '<select id="diaDetailStatus" style="width: 100%; padding: 8px; background: var(--s2); color: var(--text); border: 1px solid var(--border); border-radius: 4px;">';
  html += '<option value="">Select status...</option>';
  html += '<option value="pending">Pending</option>';
  html += '<option value="in_progress">In Progress</option>';
  html += '<option value="verified_lease">Verified Lease</option>';
  html += '<option value="approved_link">Approved Link</option>';
  html += '<option value="rejected">Rejected</option>';
  html += '</select>';
  html += '</div>';
  
  html += '<div class="form-group">';
  html += '<label style="display: block; color: var(--text2); font-size: 12px; margin-bottom: 8px; font-weight: 600;">Notes</label>';
  html += '<textarea id="diaDetailNotes" placeholder="Add notes..." style="width: 100%; padding: 8px; background: var(--s2); color: var(--text); border: 1px solid var(--border); border-radius: 4px; resize: vertical; min-height: 100px;"></textarea>';
  html += '</div>';
  
  html += '<div style="display: flex; gap: 8px;">';
  html += '<button class="btn-primary" onclick="_udBtnGuard(this, saveDiaDetailResearch)">Save</button>';
  html += '</div>';
  html += '</div>';
  
  html += '</div>';
  
  return html;
}

/**
 * Activity tab - research outcomes timeline
 */
function renderDiaDetailActivity(record) {
  const clinic_id = record.clinic_id;
  
  let html = '<div class="detail-section">';
  
  if (!clinic_id) {
    html += '<div class="detail-empty">No clinic ID to look up activity</div>';
    html += '</div>';
    return html;
  }
  
  const outcomes = (diaData.researchOutcomes || []).filter(o => o.clinic_id === clinic_id);
  
  if (outcomes.length === 0) {
    html += '<div class="detail-empty">No research outcomes recorded</div>';
    html += '</div>';
    return html;
  }
  
  html += '<div class="detail-section-title">Research Activity Timeline</div>';
  
  html += '<div class="detail-timeline">';
  
  outcomes.slice().reverse().forEach((outcome, idx) => {
    const statusColor = outcome.status === 'verified_lease' || outcome.status === 'approved_link' ? 'color: var(--success);' : 'color: var(--text2);';
    const liveIngestMeta = window.parseLiveIngestOutcomeNotes ? window.parseLiveIngestOutcomeNotes(outcome.notes) : null;
    
    html += '<div class="detail-timeline-item">';
    html += '<div style="display: flex; justify-content: space-between; margin-bottom: 8px;">';
    html += '<div style="font-weight: 600;">' + esc(outcome.queue_type || 'unknown') + '</div>';
    html += '<div style="color: var(--text2); font-size: 12px;">' + fmt(outcome.assigned_at || outcome.created_at) + '</div>';
    html += '</div>';
    html += '<div style="display: flex; justify-content: space-between; align-items: center;">';
    html += '<div style="' + statusColor + '">' + esc(outcome.status || 'unknown') + '</div>';
    if (outcome.assigned_to) {
      html += '<div style="color: var(--text2); font-size: 12px;">by ' + esc(outcome.assigned_to) + '</div>';
    }
    html += '</div>';
    if (liveIngestMeta && window.renderLiveIngestOutcomeProvenance) {
      html += window.renderLiveIngestOutcomeProvenance(liveIngestMeta, { limit: 4 });
    } else if (outcome.notes) {
      html += '<div style="margin-top:8px;color:var(--text2);font-size:12px;white-space:pre-wrap">' + esc(outcome.notes) + '</div>';
    }
    html += '</div>';
  });
  
  html += '</div>';
  
  html += '</div>';
  
  return html;
}

/**
 * Save research status from detail panel
 */
async function saveDiaDetailResearch() {
  const status = document.getElementById('diaDetailStatus')?.value;
  const notes = document.getElementById('diaDetailNotes')?.value;

  if (!status) {
    showToast('Please select a status', 'warning');
    return;
  }

  // Get clinic ID from the current detail panel context
  const clinicIdEl = document.querySelector('[data-clinic-id]');
  const clinicId = clinicIdEl ? clinicIdEl.getAttribute('data-clinic-id') : null;

  if (!clinicId) {
    showToast('Clinic ID not found', 'error');
    return;
  }

  const btn = document.querySelector('[onclick*="saveDiaDetailResearch"]');
  if (btn) { btn.disabled = true; btn.textContent = 'Saving\u2026'; btn.style.opacity = '0.6'; }
  try {
    await saveDiaOutcome('property_review', clinicId, status, null, notes);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Save'; btn.style.opacity = ''; }
  }
}

// ============================================================================
// EXPORT PUBLIC FUNCTIONS
// ============================================================================

// These override the placeholders in index.html
window.diaQuery = diaQuery;
window.loadDiaData = loadDiaData;
// ============================================================================
// PROPERTIES TAB — Server-side paginated property inventory browser
// ============================================================================

window.diaPropertiesSortBy = function(col) {
  if (diaPropertiesSort.col === col) {
    diaPropertiesSort.dir = diaPropertiesSort.dir === 'asc' ? 'desc' : 'asc';
  } else {
    diaPropertiesSort = { col: col, dir: 'desc' };
  }
  diaPropertiesPage = 0;
  renderDiaProperties();
};

// Build PostgREST order string from current sort state
function _diaPropsOrder() {
  var col = diaPropertiesSort.col || 'address';
  var dir = diaPropertiesSort.dir || 'asc';
  var nulls = (col === 'address' || col === 'property_name' || col === 'city' || col === 'state' || col === 'owner' || col === 'tenant') ? '' : '.nullslast';
  return col + '.' + dir + nulls;
}

// Build server-side filter + filter2 from search + state inputs
function _diaPropsFilters() {
  var filter = null, filter2 = null;
  if (diaPropertiesStateFilter) {
    filter = 'state=eq.' + diaPropertiesStateFilter;
  }
  if (diaPropertiesSearch) {
    var sq = diaPropertiesSearch.replace(/%/g, '').replace(/\\/g, '');
    var searchFilter = 'or(address.ilike.*' + sq + '*,property_name.ilike.*' + sq + '*,city.ilike.*' + sq + '*,state.ilike.*' + sq + '*,owner.ilike.*' + sq + '*)';
    if (filter) { filter2 = searchFilter; } else { filter = searchFilter; }
  }
  return { filter: filter, filter2: filter2 };
}

// Canonical US state/territory codes (50 states + DC + 5 inhabited territories = 56)
// Used to whitelist raw values from the properties.state column so junk data
// (foreign codes, full names, whitespace, casing dupes) does not leak into the
// Properties tab state filter dropdown.
var DIA_US_STATES = new Set([
  'AL','AK','AZ','AR','CA','CO','CT','DE','FL','GA','HI','ID','IL','IN','IA',
  'KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ',
  'NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT',
  'VA','WA','WV','WI','WY','DC','PR','VI','GU','AS','MP'
]);

// Background-load summary stats (states, avg SF) via lightweight aggregate queries.
// Two parallel single-column queries instead of fetching all 11k rows:
//   1) state column (non-null only) — deduplicate client-side for distinct count
//   2) building_size column (> 0 only) — compute avg from the filtered subset
//      NOTE: the DIA properties table uses `building_size` (the v_available_listings
//      view aliases it as `rba`). An earlier attempt queried `building_sf`, which
//      does not exist on this table and silently returned 0 rows.
async function _loadDiaPropertiesSummary() {
  if (diaPropertiesSummary) return;
  try {
    // Run two focused queries in parallel — much lighter than SELECT state, building_size FROM all rows
    var results = await Promise.all([
      diaQueryAll('properties', 'state', { filter: 'state=not.is.null' }),
      diaQueryAll('properties', 'building_size', { filter: 'building_size=gt.0' })
    ]);
    var stateRows = results[0];
    var sfRows = results[1];

    // If both queries returned nothing, likely a transient error — don't cache so we can retry
    if (stateRows.length === 0 && sfRows.length === 0) {
      console.warn('Properties summary: both queries returned 0 rows, will retry on next render');
      return;
    }

    // Extract unique states — normalize (trim + uppercase) and whitelist to canonical
    // US codes so junk values (foreign codes like AD/AG, lowercase dupes, full names
    // like "Alabama", stray whitespace) don't pollute the filter dropdown.
    var states = [];
    var seen = {};
    for (var i = 0; i < stateRows.length; i++) {
      var raw = stateRows[i].state;
      if (!raw) continue;
      var st = String(raw).trim().toUpperCase();
      if (!DIA_US_STATES.has(st)) continue;
      if (!seen[st]) { seen[st] = true; states.push(st); }
    }
    states.sort();

    // Compute avg SF from pre-filtered rows (only rows with building_size > 0)
    var withSFCount = sfRows.length;
    var sfSum = 0;
    for (var j = 0; j < sfRows.length; j++) {
      sfSum += parseFloat(sfRows[j].building_size);
    }
    var avgSF = withSFCount > 0 ? Math.round(sfSum / withSFCount) : 0;

    diaPropertiesSummary = { states: states, withSFCount: withSFCount, avgSF: avgSF, total: stateRows.length };

    // Update DOM in-place without full re-render
    var statesValEl = document.getElementById('diaPropStatesValue');
    var statesSubEl = document.getElementById('diaPropStatesSub');
    if (statesValEl) statesValEl.textContent = fmtN(states.length);
    if (statesSubEl) statesSubEl.textContent = states.slice(0, 5).join(', ') + (states.length > 5 ? '...' : '');
    var sfValEl = document.getElementById('diaPropSFValue');
    var sfSubEl = document.getElementById('diaPropSFSub');
    if (sfValEl) sfValEl.textContent = avgSF > 0 ? fmtN(avgSF) : '\u2014';
    if (sfSubEl) sfSubEl.textContent = withSFCount + ' with SF data';
    // Populate state dropdown if not yet populated
    var sel = document.getElementById('diaPropsStateSelect');
    if (sel && sel.options.length <= 1) {
      states.forEach(function(s) {
        var opt = document.createElement('option');
        opt.value = s;
        opt.textContent = s;
        if (diaPropertiesStateFilter === s) opt.selected = true;
        sel.appendChild(opt);
      });
    }
  } catch (e) {
    console.error('Properties summary error:', e);
  }
}

async function renderDiaProperties() {
  var inner = q('#bizPageInner');
  if (!inner) return;

  // Build server-side query params
  var order = _diaPropsOrder();
  var filters = _diaPropsFilters();
  var offset = diaPropertiesPage * DIA_PROPERTIES_PAGE_SIZE;

  // Show loading spinner on first render only
  if (diaPropertiesData === null) {
    inner.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading properties...</p></div>';
  }

  // Race-condition guard: ignore responses from stale requests
  var requestId = ++diaPropertiesRequestId;
  diaPropertiesLoading = true;

  try {
    var result = await diaQueryPage('properties', '*', {
      order: order,
      filter: filters.filter,
      filter2: filters.filter2,
      limit: DIA_PROPERTIES_PAGE_SIZE,
      offset: offset
    });
    if (requestId !== diaPropertiesRequestId) return; // stale
    diaPropertiesData = result.data;
    diaPropertiesTotalCount = result.count;
  } catch (e) {
    if (requestId !== diaPropertiesRequestId) return;
    console.error('Properties load error:', e);
    showToast('Properties load failed', 'error');
    diaPropertiesData = [];
    diaPropertiesTotalCount = 0;
  }
  diaPropertiesLoading = false;

  var pageRows = diaPropertiesData;
  var totalCount = diaPropertiesTotalCount;
  var totalPages = Math.max(1, Math.ceil(totalCount / DIA_PROPERTIES_PAGE_SIZE));

  // Kick off background summary load (states, avg SF) — runs once
  if (!diaPropertiesSummary) { _loadDiaPropertiesSummary(); }
  var summary = diaPropertiesSummary; // may be null on first render

  var html = '<div class="biz-section">';

  // Action guidance banner
  html += '<div style="padding:10px 14px;background:rgba(108,140,255,0.08);border-radius:8px;border-left:3px solid #6c8cff;margin-bottom:16px;display:flex;align-items:center;gap:10px;">';
  html += '<div style="font-size:13px;color:var(--text);line-height:1.4"><strong>Properties</strong> \u2014 Browse the full dialysis property inventory. Click any row to view property details, ownership, and linked clinics.</div>';
  html += '</div>';

  // Summary metrics — total count from server, others from background summary
  html += '<div class="dia-grid dia-grid-3" style="margin-bottom:16px;">';
  html += infoCard({ title: 'Total Properties', value: fmtN(totalCount), sub: 'in database', color: 'blue' });
  html += infoCard({
    title: 'States Represented',
    value: summary ? fmtN(summary.states.length) : '...',
    sub: summary ? summary.states.slice(0, 5).join(', ') + (summary.states.length > 5 ? '...' : '') : 'loading',
    color: 'green', id: 'diaPropStatesValue', subId: 'diaPropStatesSub'
  });
  html += infoCard({
    title: 'Avg Building SF',
    value: summary ? (summary.avgSF > 0 ? fmtN(summary.avgSF) : '\u2014') : '...',
    sub: summary ? summary.withSFCount + ' with SF data' : 'loading',
    color: 'purple', id: 'diaPropSFValue', subId: 'diaPropSFSub'
  });
  html += '</div>';

  // Search bar + State filter
  var summaryStates = summary ? summary.states : [];
  html += '<div style="margin:16px 0;display:flex;gap:8px;align-items:center;flex-wrap:wrap;">';
  html += '<input type="text" id="diaPropsSearchInput" placeholder="Search address, name, city, state, owner..." value="' + esc(diaPropertiesSearch) + '" style="flex:1;min-width:200px;padding:8px 12px;border-radius:8px;border:1px solid var(--border);background:var(--s2);color:var(--text);font-size:13px;" />';
  html += '<select id="diaPropsStateSelect" style="padding:8px 12px;border-radius:8px;border:1px solid var(--border);background:var(--s2);color:var(--text);font-size:13px;">';
  html += '<option value="">All States</option>';
  summaryStates.forEach(function(st) {
    html += '<option value="' + esc(st) + '"' + (diaPropertiesStateFilter === st ? ' selected' : '') + '>' + esc(st) + '</option>';
  });
  html += '</select>';
  if (diaPropertiesSort.col && diaPropertiesSort.col !== 'address') {
    html += '<button class="pill active" id="diaPropsClearSort" style="font-size:11px;padding:4px 10px;">Clear Sort</button>';
  }
  html += '<span style="font-size:12px;color:var(--text3);">' + fmtN(totalCount) + ' results</span>';
  html += '</div>';

  // Sort toolbar — address is the default/primary sort
  var SORT_COLS = [
    { col: 'address', label: 'Address' },
    { col: 'city', label: 'City' },
    { col: 'state', label: 'State' },
    { col: 'building_size', label: 'SF' },
    { col: 'year_built', label: 'Year Built' },
    { col: 'tenant', label: 'Tenant' },
    { col: 'owner', label: 'Owner' }
  ];
  var sortArrow = function(col) {
    if (diaPropertiesSort.col !== col) return '';
    return diaPropertiesSort.dir === 'asc' ? ' \u25B2' : ' \u25BC';
  };
  html += '<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-bottom:10px;">';
  html += '<span style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:0.4px;margin-right:4px;">Sort:</span>';
  SORT_COLS.forEach(function(s) {
    var active = diaPropertiesSort.col === s.col;
    html += '<button class="pill' + (active ? ' active' : '') + '" data-prop-sort-col="' + s.col + '" style="font-size:11px;padding:4px 10px;">' + s.label + sortArrow(s.col) + '</button>';
  });
  html += '</div>';

  // Scrollable card grid — address is the primary title, with city/state/zip subtitle
  html += '<div style="overflow-y:auto;-webkit-overflow-scrolling:touch;border:1px solid var(--border);border-radius:10px;max-height:70vh;padding:10px;display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px;">';

  pageRows.forEach(function(r, _ri) {
    // Title priority: address (primary) > property_name / facility_name (fallback)
    var title = r.address || r.property_name || r.facility_name || '\u2014';
    var locParts = [];
    if (r.city) locParts.push(r.city);
    if (r.state) locParts.push(r.state);
    var locLine = locParts.join(', ');
    if (r.zip_code) locLine = locLine ? locLine + ' ' + r.zip_code : String(r.zip_code);

    var metaParts = [];
    if (r.building_size && parseFloat(r.building_size) > 0) {
      metaParts.push(fmtN(Math.round(parseFloat(r.building_size))) + ' SF');
    }
    if (r.year_built) metaParts.push('Built ' + r.year_built);
    if (r.cap_rate) {
      var capNum = parseFloat(r.cap_rate);
      if (capNum > 0) {
        var capPct = capNum < 1 ? (capNum * 100).toFixed(1) : capNum.toFixed(1);
        metaParts.push('Cap: ' + capPct + '%');
      }
    }

    html += '<div class="prop-card clickable-row" data-prop-idx="' + _ri + '" style="cursor:pointer;padding:12px 14px;border:1px solid var(--border);border-radius:10px;background:var(--s2);display:flex;flex-direction:column;gap:3px;">';
    html += '<div class="prop-card-title" style="font-size:14px;font-weight:700;color:var(--text);line-height:1.3;overflow:hidden;text-overflow:ellipsis;">' + esc(title) + '</div>';
    if (locLine) {
      html += '<div class="prop-card-sub" style="font-size:12px;color:var(--text2);">' + esc(locLine) + '</div>';
    }
    if (r.tenant) {
      html += '<div class="prop-card-tenant" style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:0.4px;margin-top:3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + esc(r.tenant) + '</div>';
    }
    if (metaParts.length) {
      html += '<div class="prop-card-meta" style="font-size:11px;color:var(--text2);font-family:\'JetBrains Mono\',monospace;margin-top:4px;">' + esc(metaParts.join(' | ')) + '</div>';
    }
    if (r.owner && r.owner !== r.tenant) {
      html += '<div class="prop-card-owner" style="font-size:10px;color:var(--text3);margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">Owner: ' + esc(r.owner) + '</div>';
    }
    html += '</div>';
  });

  if (pageRows.length === 0) {
    html += '<div style="grid-column:1/-1;text-align:center;padding:32px;color:var(--text3);">No properties to display</div>';
  }
  html += '</div>';

  // Pagination
  if (totalPages > 1) {
    html += '<div style="display:flex;justify-content:space-between;align-items:center;margin-top:12px;font-size:13px;color:var(--text2);">';
    html += '<span>Page ' + (diaPropertiesPage + 1) + ' of ' + fmtN(totalPages) + ' (' + fmtN(totalCount) + ' total)</span>';
    html += '<div style="display:flex;gap:6px;">';
    html += '<button class="pill' + (diaPropertiesPage === 0 ? '' : ' active') + '" data-props-page="prev"' + (diaPropertiesPage === 0 ? ' disabled style="opacity:0.4;pointer-events:none"' : '') + '>&laquo; Prev</button>';
    html += '<button class="pill' + (diaPropertiesPage >= totalPages - 1 ? '' : ' active') + '" data-props-page="next"' + (diaPropertiesPage >= totalPages - 1 ? ' disabled style="opacity:0.4;pointer-events:none"' : '') + '>Next &raquo;</button>';
    html += '</div></div>';
  }

  html += '</div>';

  // Render to DOM
  inner.innerHTML = html;

  // Bind row click — open unified detail sidebar
  document.querySelectorAll('[data-prop-idx]').forEach(function(tr) {
    tr.addEventListener('click', function() {
      var idx = parseInt(this.dataset.propIdx, 10);
      var row = pageRows[idx];
      if (row && row.property_id) {
        openUnifiedDetail('dialysis', { property_id: row.property_id }, row);
      }
    });
  });

  // Pagination handlers
  document.querySelectorAll('[data-props-page]').forEach(function(btn) {
    btn.addEventListener('click', function() {
      if (this.dataset.propsPage === 'prev' && diaPropertiesPage > 0) diaPropertiesPage--;
      else if (this.dataset.propsPage === 'next') diaPropertiesPage++;
      renderDiaProperties();
    });
  });

  // Search input — debounced server-side search
  var searchInput = document.getElementById('diaPropsSearchInput');
  if (searchInput) {
    var debounce;
    searchInput.addEventListener('input', function(e) {
      clearTimeout(debounce);
      debounce = setTimeout(function() {
        diaPropertiesSearch = e.target.value.trim();
        diaPropertiesPage = 0;
        renderDiaProperties();
        var restored = document.getElementById('diaPropsSearchInput');
        if (restored) {
          restored.focus();
          restored.setSelectionRange(restored.value.length, restored.value.length);
        }
      }, 400);
    });
    searchInput.focus();
    searchInput.selectionStart = searchInput.selectionEnd = searchInput.value.length;
  }

  // State filter
  var stateSelect = document.getElementById('diaPropsStateSelect');
  if (stateSelect) {
    stateSelect.addEventListener('change', function() {
      diaPropertiesStateFilter = this.value;
      diaPropertiesPage = 0;
      renderDiaProperties();
    });
  }

  // Clear sort button
  var clearSortBtn = document.getElementById('diaPropsClearSort');
  if (clearSortBtn) {
    clearSortBtn.addEventListener('click', function() {
      diaPropertiesSort = { col: 'address', dir: 'asc' };
      diaPropertiesPage = 0;
      renderDiaProperties();
    });
  }

  // Column sort handlers
  document.querySelectorAll('[data-prop-sort-col]').forEach(function(thEl) {
    thEl.addEventListener('click', function() {
      var col = this.dataset.propSortCol;
      if (diaPropertiesSort.col === col) {
        diaPropertiesSort.dir = diaPropertiesSort.dir === 'asc' ? 'desc' : 'asc';
      } else {
        diaPropertiesSort = { col: col, dir: 'desc' };
      }
      diaPropertiesPage = 0;
      renderDiaProperties();
    });
  });
}

// ============================================================================
// DIALYSIS SALES (Facility Transfers / Market Activity)
// ============================================================================

async function renderDiaSales() {
  // Lazy-load sales comps and available listings data on first visit
  if (diaSalesView === 'comps' && diaSalesComps === null && !diaSalesLoading) {
    diaSalesLoading = true;
    const inner = q('#bizPageInner');
    if (inner) inner.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading sales comps...</p></div>';
    try {
      diaSalesComps = await loadDiaSalesCompsFromTxns();
    } catch (e) { console.error('Sales comps load error:', e); showToast('Sales comps load failed', 'error'); diaSalesComps = []; }
    diaSalesLoading = false;
  }
  if (diaSalesView === 'available' && (!diaAvailListings || diaAvailListings.length === 0) && !diaSalesLoading) {
    diaSalesLoading = true;
    const inner = q('#bizPageInner');
    if (inner) inner.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading available listings...</p></div>';
    try {
      let all = [], pg = 0;
      while (true) {
        const batch = await diaQuery('v_available_listings', '*', {
          order: 'listing_date.desc.nullslast', limit: 1000, offset: pg * 1000,
        });
        all = all.concat(batch || []);
        if (!batch || batch.length < 1000) break;
        pg++;
      }
      diaAvailListings = all;
    } catch (e) { console.error('Available listings load error:', e); showToast('Listings load failed', 'error'); diaAvailListings = []; }
    diaSalesLoading = false;
  }

  const isComps = diaSalesView === 'comps';
  let data = isComps ? (diaSalesComps || []) : (diaAvailListings || []);

  // Available view: restrict to the canonical CURRENT on-market set
  // (v_dia_on_market membership ~184) so the tab count matches the Overview
  // tile + the CM available number. Falls back to the full loaded set only if
  // the membership view hasn't loaded.
  if (!isComps && diaOnMarketIds) {
    data = data.filter(r => diaOnMarketIds.has(r.listing_id));
  }

  // Filter out blank/empty records — require at least an address or operator name
  data = data.filter(r => (r.address && r.address.trim()) || (r.tenant_operator && r.tenant_operator.trim()) || (r.facility_name && r.facility_name.trim()));

  // Deduplicate rows — Sales Comps are already DB-deduped by sale_id in
  // sales_transactions, so the dedup pass runs only for Available Listings
  // (v_available_listings can still return duplicates from joins).
  if (!isComps) {
    const seen = new Set();
    data = data.filter(r => {
      const addr = (r.address || '').trim().toLowerCase();
      const dateKey = r.listing_date || '';
      const priceKey = r.ask_price || '';
      const key = `${addr}|${dateKey}|${priceKey}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  // Apply state filter
  let filtered = data;
  if (diaSalesStateFilter) {
    filtered = filtered.filter(r => r.state === diaSalesStateFilter);
  }

  // Apply search filter
  if (diaSalesSearch) {
    const sq = diaSalesSearch.toLowerCase();
    filtered = filtered.filter(r =>
      (r.tenant_operator || '').toLowerCase().includes(sq) ||
      (r.address || '').toLowerCase().includes(sq) ||
      (r.city || '').toLowerCase().includes(sq) ||
      (r.state || '').toLowerCase().includes(sq) ||
      (r.seller || '').toLowerCase().includes(sq) ||
      (r.listing_broker || '').toLowerCase().includes(sq) ||
      (isComps ? (r.buyer || '').toLowerCase().includes(sq) || (r.procuring_broker || '').toLowerCase().includes(sq) : false)
    );
  }

  // Apply sort
  if (diaSalesSort.col) {
    const col = diaSalesSort.col;
    const dir = diaSalesSort.dir === 'asc' ? 1 : -1;
    const numericCols = ['land_area','year_built','rba','rent','rent_per_sf','term_remaining_yrs','price','price_per_sf','cap_rate','bid_ask_spread','dom','ask_price','ask_cap'];
    const isNumeric = numericCols.indexOf(col) >= 0;
    filtered = filtered.slice().sort(function(a, b) {
      let va = a[col], vb = b[col];
      if (va == null) return 1;
      if (vb == null) return -1;
      if (isNumeric) {
        return (parseFloat(va) - parseFloat(vb)) * dir;
      }
      return String(va).localeCompare(String(vb)) * dir;
    });
  }

  // Store filtered data for export
  diaFilteredSalesData = filtered;

  const totalPages = Math.ceil(filtered.length / DIA_SALES_PAGE_SIZE);
  const pageRows = filtered.slice(diaSalesPage * DIA_SALES_PAGE_SIZE, (diaSalesPage + 1) * DIA_SALES_PAGE_SIZE);

  let html = '<div class="biz-section">';

  // === Action guidance banner ===
  html += '<div style="padding:10px 14px;background:rgba(52,211,153,0.08);border-radius:8px;border-left:3px solid #34d399;margin-bottom:16px;display:flex;align-items:center;gap:10px;">';
  if (isComps) {
    // Count comps where one or more fields were filled from a secondary
    // source (ownership_history, deed_records, medicare_clinics, etc.).
    const xrefCount = (diaSalesComps || []).filter(r => r && r._provenance).length;
    const xrefBlurb = xrefCount > 0
      ? ' <span style="color:var(--text2);font-size:12px">(' + fmtN(xrefCount) + ' rows enriched from cross-referenced sources)</span>'
      : '';
    html += '<div style="font-size:13px;color:var(--text);line-height:1.4"><strong>Sales Comps</strong> — Browse closed dialysis property transactions. Use these as comparable evidence for BOV underwriting. Click any row to view full property details and financials.' + xrefBlurb + '</div>';
  } else {
    html += '<div style="font-size:13px;color:var(--text);line-height:1.4"><strong>Available Listings</strong> — Monitor on-market dialysis properties. Identify acquisition opportunities or competitive positioning for your pipeline. Click any row for property details.</div>';
  }
  html += '</div>';

  // Sub-tab toggle: Sales Comps | Available
  html += '<div class="pills" style="margin-bottom: 16px;">';
  html += '<button class="pill' + (isComps ? ' active' : '') + '" data-sales-view="comps">Sales Comps (' + (diaSalesComps ? fmtN(diaSalesComps.length) : '…') + ')</button>';
  const _availPillCount = diaAvailListings ? (diaOnMarketIds ? diaAvailListings.filter(r => diaOnMarketIds.has(r.listing_id)).length : diaAvailListings.length) : null;
  html += '<button class="pill' + (!isComps ? ' active' : '') + '" data-sales-view="available">Available (' + (_availPillCount == null ? '…' : fmtN(_availPillCount)) + ')</button>';
  html += '</div>';

  // Metrics
  html += '<div class="dia-grid dia-grid-4" style="margin-bottom: 16px;">';
  // Helper: compute average cap rate, normalizing mixed formats.
  // DB stores some rows as decimals (0.07 = 7%) and others as percentages (7.15 = 7.15%).
  // Normalize everything to decimal before averaging, then display as percentage.
  const avgCapRate = (arr, field) => {
    const normalized = [];
    arr.forEach(r => {
      const v = parseFloat(r[field]);
      if (!v || v <= 0) return;
      // Same threshold as fmtCap: v < 1 means decimal format, else percentage format
      const dec = v < 1 ? v : v / 100;
      // Filter outliers: keep 1%–25% (0.01–0.25 in decimal)
      if (dec > 0.01 && dec < 0.25) normalized.push(dec);
    });
    if (normalized.length === 0) return { val: '—', n: 0 };
    return { val: (normalized.reduce((s, d) => s + d, 0) / normalized.length * 100).toFixed(2) + '%', n: normalized.length };
  };
  if (isComps) {
    const withPrice = data.filter(r => r.price > 0);
    const cap = avgCapRate(data, 'cap_rate');
    const avgPrice = withPrice.length > 0 ? '$' + fmtN(Math.round(withPrice.reduce((s, r) => s + parseFloat(r.price), 0) / withPrice.length)) : '—';
    // Bid-Ask Spread in basis points
    const withBidAsk = data.filter(r => r.bid_ask_spread != null && parseFloat(r.bid_ask_spread) > 0 && parseFloat(r.bid_ask_spread) < 2000);
    const avgBidAsk = withBidAsk.length > 0 ? Math.round(withBidAsk.reduce((s, r) => s + parseFloat(r.bid_ask_spread), 0) / withBidAsk.length) : null;
    html += infoCard({ title: 'Total Sales', value: fmtN(data.length), sub: 'dialysis comps', color: 'blue' });
    html += infoCard({ title: 'Avg Cap Rate', value: cap.val, sub: cap.n + ' with cap data', color: 'green' });
    html += infoCard({ title: 'Avg Sale Price', value: avgPrice, sub: withPrice.length + ' with price data', color: 'purple' });
    html += infoCard({ title: 'Avg Bid-Ask Spread', value: avgBidAsk != null ? avgBidAsk + ' bps' : '—', sub: withBidAsk.length + ' with spread data', color: 'cyan' });
  } else {
    const withPrice = data.filter(r => r.ask_price > 0);
    const cap = avgCapRate(data, 'ask_cap');
    const avgAsk = withPrice.length > 0 ? '$' + fmtN(Math.round(withPrice.reduce((s, r) => s + parseFloat(r.ask_price), 0) / withPrice.length)) : '—';
    html += infoCard({ title: 'Active Listings', value: fmtN(data.length), sub: 'on market', color: 'blue' });
    html += infoCard({ title: 'Avg Ask Cap', value: cap.val, sub: cap.n + ' with cap data', color: 'green' });
    html += infoCard({ title: 'Avg Ask Price', value: avgAsk, sub: withPrice.length + ' priced', color: 'purple' });
    const avgDom = data.filter(r => r.dom > 0);
    const avgDomVal = avgDom.length > 0 ? Math.round(avgDom.reduce((s, r) => s + r.dom, 0) / avgDom.length) : '—';
    html += infoCard({ title: 'Avg DOM', value: avgDomVal, sub: avgDom.length + ' with dates', color: 'yellow' });
  }
  html += '</div>';

  // Search bar + State filter
  const allStates = [...new Set(data.map(r => r.state).filter(Boolean))].sort();
  html += '<div style="margin: 16px 0; display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">';
  html += '<input type="text" id="diaSalesSearchInput" placeholder="Search tenant, address, city, broker..." value="' + esc(diaSalesSearch) + '" style="flex:1; min-width: 200px; padding: 8px 12px; border-radius: 8px; border: 1px solid var(--border); background: var(--s2); color: var(--text); font-size: 13px;" />';
  html += '<select id="diaSalesStateSelect" style="padding: 8px 12px; border-radius: 8px; border: 1px solid var(--border); background: var(--s2); color: var(--text); font-size: 13px;">';
  html += '<option value="">All States</option>';
  allStates.forEach(function(st) {
    html += '<option value="' + esc(st) + '"' + (diaSalesStateFilter === st ? ' selected' : '') + '>' + esc(st) + '</option>';
  });
  html += '</select>';
  const _defSort = diaSalesDefaultSort(diaSalesView);
  const isDefaultSort = diaSalesSort.col === _defSort.col && diaSalesSort.dir === _defSort.dir;
  if (!isDefaultSort) {
    html += '<button class="pill active" id="diaSalesClearSort" style="font-size:11px;padding:4px 10px;" title="Reset to newest-first">Reset Sort</button>';
  }
  html += '<span style="font-size: 12px; color: var(--text3);">' + fmtN(filtered.length) + ' results</span>';
  html += '<button onclick="exportCompsToXlsx(diaFilteredSalesData, \'sales\')" style="padding:6px 14px;border-radius:8px;border:1px solid var(--border);background:var(--s2);color:var(--accent);font-size:12px;font-weight:600;cursor:pointer;white-space:nowrap;display:flex;align-items:center;gap:4px;" title="Export all ' + fmtN(filtered.length) + ' filtered results to Excel">&#x1F4E5; Export</button>';
  html += '</div>';

  // Scrollable table
  html += '<div style="overflow-x: auto; -webkit-overflow-scrolling: touch; border: 1px solid var(--border); border-radius: 10px; max-height: 70vh;">';
  html += '<table style="width: max-content; min-width: 2200px; border-collapse: collapse; font-size: 12px;">';

  // Sortable header helper
  const sortArrow = function(col) {
    if (diaSalesSort.col !== col) return ' <span style="opacity:0.3;font-size:9px">⇅</span>';
    return diaSalesSort.dir === 'asc' ? ' <span style="color:var(--accent)">▲</span>' : ' <span style="color:var(--accent)">▼</span>';
  };
  const thBase = 'padding:10px 8px;font-weight:600;font-size:11px;letter-spacing:0.3px;text-transform:uppercase;color:var(--text2);border-bottom:2px solid var(--border);white-space:nowrap;cursor:pointer;user-select:none;';
  const th = function(label, w, col) { return '<th data-sort-col="' + col + '" style="text-align:left;' + thBase + 'min-width:' + w + 'px;">' + label + sortArrow(col) + '</th>'; };
  const thr = function(label, w, col) { return '<th data-sort-col="' + col + '" style="text-align:right;' + thBase + 'min-width:' + w + 'px;">' + label + sortArrow(col) + '</th>'; };

  html += '<thead><tr style="background: var(--s2); position: sticky; top: 0; z-index: 1;">';
  if (isComps) {
    html += th('Tenant/Operator', 160, 'tenant_operator');
    html += th('Address', 140, 'address');
    html += th('City', 90, 'city');
    html += th('State', 40, 'state');
    html += thr('Land', 55, 'land_area');
    html += thr('Built', 45, 'year_built');
    html += thr('RBA', 60, 'rba');
    html += thr('Rent', 75, 'rent');
    html += thr('Rent/SF', 60, 'rent_per_sf');
    html += th('Expiration', 85, 'lease_expiration');
    html += thr('Term Rem', 65, 'term_remaining_yrs');
    html += th('Expenses', 70, 'expenses');
    html += th('Bumps', 90, 'bumps');
    html += thr('Price', 85, 'price');
    html += thr('Price/SF', 65, 'price_per_sf');
    html += thr('Cap', 55, 'cap_rate');
    html += th('Sold Date', 80, 'sold_date');
    html += th('Seller', 110, 'seller');
    html += th('Listing Broker', 100, 'listing_broker');
    html += th('Buyer', 110, 'buyer');
    html += th('Procuring Broker', 110, 'procuring_broker');
    html += thr('Bid-Ask (bps)', 70, 'bid_ask_spread');
    html += thr('DOM', 45, 'dom');
  } else {
    html += th('Tenant/Operator', 160, 'tenant_operator');
    html += th('Address', 140, 'address');
    html += th('City', 90, 'city');
    html += th('State', 40, 'state');
    html += thr('Land', 55, 'land_area');
    html += thr('Built', 45, 'year_built');
    html += thr('RBA', 60, 'rba');
    html += thr('Rent', 75, 'rent');
    html += thr('Rent/SF', 60, 'rent_per_sf');
    html += th('Expiration', 85, 'lease_expiration');
    html += thr('Term Rem', 65, 'term_remaining_yrs');
    html += th('Expenses', 70, 'expenses');
    html += th('Bumps', 90, 'bumps');
    html += thr('Ask Price', 85, 'ask_price');
    html += thr('Price/SF', 65, 'price_per_sf');
    html += thr('Ask Cap', 55, 'ask_cap');
    html += th('Seller', 110, 'seller');
    html += th('Listing Broker', 100, 'listing_broker');
    html += thr('DOM', 45, 'dom');
  }
  html += '<th style="text-align:center;min-width:90px;position:sticky;right:0;background:var(--s2);z-index:2;border-left:1px solid var(--border)">Actions</th>';
  html += '</tr></thead>';

  // Body
  html += '<tbody>';
  const td = (val, trunc) => '<td style="padding: 8px; border-bottom: 1px solid var(--border); white-space: nowrap;' + (trunc ? ' max-width: 180px; overflow: hidden; text-overflow: ellipsis;' : '') + '">' + esc(val || '—') + '</td>';
  const tdr = (val) => '<td style="padding: 8px; border-bottom: 1px solid var(--border); white-space: nowrap; text-align: right; font-family: \'JetBrains Mono\', monospace; font-size: 11px;">' + (val || '—') + '</td>';
  // Cross-source marker: faint dot appended to a cell value when the value
  // came from a secondary source (ownership_history, deed_records, etc.).
  // Hover reveals which source supplied it. We render via td/tdr by passing
  // the already-formatted value so the marker survives whatever formatter
  // ran upstream.
  const xrefMark = (provSrc) => provSrc
    ? ' <span style="color:var(--accent);opacity:0.65;font-size:10px;" title="Cross-sourced from ' + esc(provSrc) + '">●</span>'
    : '';
  const tdX = (val, prov, key, trunc) => {
    const src = prov ? prov[key] : null;
    const inner = esc(val || '—') + xrefMark(src);
    return '<td style="padding: 8px; border-bottom: 1px solid var(--border); white-space: nowrap;' + (trunc ? ' max-width: 180px; overflow: hidden; text-overflow: ellipsis;' : '') + '">' + inner + '</td>';
  };
  const tdrX = (val, prov, key) => {
    const src = prov ? prov[key] : null;
    const inner = (val || '—') + xrefMark(src);
    return '<td style="padding: 8px; border-bottom: 1px solid var(--border); white-space: nowrap; text-align: right; font-family: \'JetBrains Mono\', monospace; font-size: 11px;">' + inner + '</td>';
  };
  const fmtMoney = (v) => v != null && v > 0 ? '$' + Number(v).toLocaleString('en-US', { maximumFractionDigits: 0 }) : '—';
  const fmtCap = (v) => v != null && v > 0 ? (v < 1 ? (v * 100).toFixed(2) : parseFloat(v).toFixed(2)) + '%' : '—';
  const fmtPSF = (v) => v != null && v > 0 ? '$' + Number(v).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '—';
  const fmtAcres = (v) => v != null && v > 0 ? parseFloat(v).toFixed(2) + ' ac' : '—';
  const fmtSF = (v) => v != null && v > 0 ? Number(Math.round(v)).toLocaleString('en-US') + ' SF' : '—';
  const fmtTerm = (v) => v != null ? (parseFloat(v) < 0 ? 'Exp.' : parseFloat(v).toFixed(1) + ' yr') : '—';
  const fmtDate = (v) => v || '—';

  pageRows.forEach((r, _ri) => {
    const _zebra = _ri % 2 === 0 ? '' : 'background:rgba(255,255,255,0.02);';
    const prov = r._provenance || null;
    html += '<tr class="clickable-row" onclick=\'openDiaSaleOrProperty(' + safeJSON(r) + ')\' style="cursor: pointer;' + _zebra + '">';
    html += tdX(r.tenant_operator, prov, 'tenant_operator', true);
    html += td(r.address, true);
    html += td(r.city);
    html += td(r.state);
    html += tdrX(fmtAcres(r.land_area), prov, 'land_area');
    html += tdrX(r.year_built || '—', prov, 'year_built');
    html += tdrX(fmtSF(r.rba), prov, 'rba');
    html += tdr(fmtMoney(r.rent));
    html += tdr(fmtPSF(r.rent_per_sf));
    html += td(fmtDate(r.lease_expiration));
    html += tdr(fmtTerm(r.term_remaining_yrs));
    html += td(r.expenses);
    html += td(r.bumps, true);
    if (isComps) {
      html += tdrX(fmtMoney(r.price), prov, 'price');
      html += tdr(fmtPSF(r.price_per_sf));
      html += tdrX(fmtCap(r.cap_rate), prov, 'cap_rate');
      html += td(fmtDate(r.sold_date));
      html += tdX(r.seller, prov, 'seller', true);
      html += tdX(r.listing_broker, prov, 'listing_broker', true);
      html += tdX(r.buyer, prov, 'buyer', true);
      html += tdX(r.procuring_broker, prov, 'procuring_broker', true);
      html += tdr(r.bid_ask_spread != null && parseFloat(r.bid_ask_spread) > 0 ? Math.round(parseFloat(r.bid_ask_spread)) + ' bps' : '—');
      html += tdr(r.dom != null ? r.dom + 'd' : '—');
    } else {
      html += tdr(fmtMoney(r.ask_price));
      html += tdr(fmtPSF(r.price_per_sf));
      html += tdr(fmtCap(r.ask_cap));
      html += td(r.seller, true);
      html += td(r.listing_broker, true);
      html += tdr(r.dom != null ? r.dom + 'd' : '—');
    }
    html += '<td style="text-align:center;position:sticky;right:0;background:var(--s1);z-index:1;border-left:1px solid var(--border);padding:4px" onclick="event.stopPropagation()">';
    html += '<div style="display:flex;gap:3px;justify-content:center;flex-wrap:wrap">';
    // Marketing collateral icons — OM PDF + any marketplace/broker URLs.
    // Dia schema uses separate `url` + `listing_url` text columns (no
    // tracked_urls jsonb), so surface both via extraUrlFields.
    if (typeof buildCollateralIcons === 'function') {
      html += buildCollateralIcons(r, {
        pdf:             'intake_artifact_path',
        pdfType:         'intake_artifact_type',
        primaryUrl:      'url',
        extraUrlFields:  ['listing_url']
      });
    }
    html += '<button class="gov-row-action" onclick=\'showDetail(' + safeJSON(r) + ', "dia-clinic", "Ownership")\' title="View owner & contacts">📞</button>';
    html += '<button class="gov-row-action accent" onclick=\'showDetail(' + safeJSON(r) + ', "dia-clinic", "Intel")\' title="Research & intel">🔍</button>';
    html += '</div></td>';
    html += '</tr>';
  });

  if (pageRows.length === 0) {
    const colSpan = isComps ? 24 : 20;
    html += '<tr><td colspan="' + colSpan + '" style="text-align: center; padding: 32px; color: var(--text3);">No ' + (isComps ? 'sales comps' : 'available listings') + ' to display</td></tr>';
  }
  html += '</tbody></table></div>';

  // Pagination
  if (totalPages > 1) {
    html += '<div style="display: flex; justify-content: space-between; align-items: center; margin-top: 12px; font-size: 13px; color: var(--text2);">';
    html += '<span>Page ' + (diaSalesPage + 1) + ' of ' + totalPages + ' (' + fmtN(filtered.length) + ' total)</span>';
    html += '<div style="display: flex; gap: 6px;">';
    html += '<button class="pill' + (diaSalesPage === 0 ? '' : ' active') + '" data-sales-page="prev"' + (diaSalesPage === 0 ? ' disabled style="opacity:0.4;pointer-events:none"' : '') + '>&laquo; Prev</button>';
    html += '<button class="pill' + (diaSalesPage >= totalPages - 1 ? '' : ' active') + '" data-sales-page="next"' + (diaSalesPage >= totalPages - 1 ? ' disabled style="opacity:0.4;pointer-events:none"' : '') + '>Next &raquo;</button>';
    html += '</div></div>';
  }

  html += '</div>';

  // Render to DOM
  const inner = q('#bizPageInner');
  if (inner) inner.innerHTML = html;

  // Bind events
  document.querySelectorAll('[data-sales-view]').forEach(btn => {
    btn.addEventListener('click', e => {
      diaSalesView = e.target.dataset.salesView;
      diaSalesPage = 0;
      diaSalesSearch = '';
      diaSalesSort = diaSalesDefaultSort(diaSalesView);
      diaSalesStateFilter = '';
      renderDiaSales();
    });
  });
  document.querySelectorAll('[data-sales-page]').forEach(btn => {
    btn.addEventListener('click', e => {
      if (e.target.dataset.salesPage === 'prev' && diaSalesPage > 0) diaSalesPage--;
      else if (e.target.dataset.salesPage === 'next') diaSalesPage++;
      renderDiaSales();
    });
  });
  const searchInput = document.getElementById('diaSalesSearchInput');
  if (searchInput) {
    let debounce;
    searchInput.addEventListener('input', e => {
      clearTimeout(debounce);
      debounce = setTimeout(() => {
        diaSalesSearch = e.target.value.trim();
        diaSalesPage = 0;
        renderDiaSales();
        // Restore focus after DOM re-render
        const restored = document.getElementById('diaSalesSearchInput');
        if (restored) {
          restored.focus();
          restored.setSelectionRange(restored.value.length, restored.value.length);
        }
      }, 300);
    });
    searchInput.focus();
    searchInput.selectionStart = searchInput.selectionEnd = searchInput.value.length;
  }
  // State filter
  const stateSelect = document.getElementById('diaSalesStateSelect');
  if (stateSelect) {
    stateSelect.addEventListener('change', function() {
      diaSalesStateFilter = this.value;
      diaSalesPage = 0;
      renderDiaSales();
    });
  }
  // Clear sort button
  const clearSortBtn = document.getElementById('diaSalesClearSort');
  if (clearSortBtn) {
    clearSortBtn.addEventListener('click', function() {
      diaSalesSort = diaSalesDefaultSort(diaSalesView);
      diaSalesPage = 0;
      renderDiaSales();
    });
  }
  // Column sort handlers
  document.querySelectorAll('[data-sort-col]').forEach(function(thEl) {
    thEl.addEventListener('click', function() {
      const col = this.dataset.sortCol;
      if (diaSalesSort.col === col) {
        diaSalesSort.dir = diaSalesSort.dir === 'asc' ? 'desc' : 'asc';
      } else {
        diaSalesSort = { col: col, dir: 'desc' };
      }
      diaSalesPage = 0;
      renderDiaSales();
    });
  });
}

// ============================================================================

// ============================================================================
// DIALYSIS LEASES TAB
// ============================================================================
let diaLeasesData = null;
let diaLeaseWatchlist = null;
let diaLeaseGaps = null;

function renderDiaLeases() {
  const el = document.getElementById('bizPageInner');
  if (!el) return '';

  if (!diaLeasesData) {
    el.innerHTML = '<div class="loading"><span class="spinner"></span> Loading lease data...</div>';
    (async () => {
      try {
        // These views may return 403 if Supabase role lacks SELECT permission — catch individually
        const [watchlist, gaps] = await Promise.all([
          diaQueryAll('v_clinic_lease_renewal_watchlist', '*').catch(function(e) {
            console.warn('v_clinic_lease_renewal_watchlist: ' + (e.message || '403 — grant SELECT to API role'));
            return [];
          }),
          diaQueryAll('v_clinic_lease_data_gaps', 'gap_type,clinic_id,facility_name,operator_name,city,state,lease_expiration,total_patients').catch(function(e) {
            console.warn('v_clinic_lease_data_gaps: ' + (e.message || '403 — grant SELECT to API role'));
            return [];
          })
        ]);
        diaLeaseWatchlist = watchlist || [];
        diaLeaseGaps = gaps || [];
        diaLeasesData = true;
        el.innerHTML = buildDiaLeasesHTML();
      } catch (e) {
        console.error('Dia leases load error:', e);
        el.innerHTML = '<div class="widget-error"><div class="err-msg">Failed to load lease data: ' + esc(e.message || '') + '</div><button class="retry-btn" onclick="diaLeasesData=null;renderDiaLeases()">Retry</button></div>';
      }
    })();
    return '';
  }

  el.innerHTML = buildDiaLeasesHTML();
  return '';
}

function buildDiaLeasesHTML() {
  const watchlist = diaLeaseWatchlist || [];
  const gaps = diaLeaseGaps || [];
  const backfill = diaData.leaseBackfillRows || [];
  const totalClinics = (diaData.freshness || {}).total_clinics || 8513;

  // Gap type counts
  const gapCounts = {};
  gaps.forEach(function(g) { gapCounts[g.gap_type] = (gapCounts[g.gap_type] || 0) + 1; });
  const missingPropLink = gapCounts['missing_property_link'] || 0;
  const missingLeaseRow = gapCounts['missing_lease_row'] || 0;
  const staleLeases = gapCounts['lease_stale_vs_inventory'] || 0;
  const expiredActive = gapCounts['expired_lease_on_active_clinic'] || 0;
  const expiring12m = gapCounts['expiring_within_12_months'] || 0;
  const totalGaps = gaps.length;
  const linkedWithLease = totalClinics - missingPropLink - missingLeaseRow;

  // Watchlist buckets
  const expired = watchlist.filter(function(w) { return w.renewal_watchlist_type === 'expired_lease_risk'; });
  const risk12m = watchlist.filter(function(w) { return w.renewal_watchlist_type.indexOf('12m') >= 0; });
  const missingFollow = watchlist.filter(function(w) { return w.renewal_watchlist_type === 'missing_lease_followup'; });

  let html = '<div style="margin-bottom:24px">';
  html += '<div style="font-size:16px;font-weight:700;margin-bottom:12px;display:flex;align-items:center;gap:8px"><span style="font-size:20px">📋</span> Dialysis Lease Intelligence</div>';

  // === Action guidance banner ===
  html += '<div style="padding:10px 14px;background:rgba(248,113,113,0.08);border-radius:8px;border-left:3px solid #f87171;margin-bottom:16px;display:flex;align-items:center;gap:10px;">';
  html += '<div style="font-size:13px;color:var(--text);line-height:1.4"><strong>Action:</strong> Review lease expirations and data gaps across tracked clinics. <strong>Flag</strong> watchlist items that need lease research or pipeline consideration. Use the <em>Research Workbench</em> to backfill missing lease data.</div>';
  html += '</div>';

  // Summary Stats
  html += '<div class="dia-grid dia-grid-4" style="margin-bottom:20px">';
  html += infoCard({ title: 'Total Clinics', value: fmtN(totalClinics), sub: 'Tracked nationwide', color: 'blue' });
  html += infoCard({ title: 'Lease Coverage', value: ((linkedWithLease / totalClinics) * 100).toFixed(1) + '%', sub: fmtN(linkedWithLease) + ' with lease data', color: 'cyan' });
  html += infoCard({ title: 'Data Gaps', value: fmtN(totalGaps), sub: 'Clinics need attention', color: 'yellow' });
  html += infoCard({ title: 'Watchlist', value: fmtN(watchlist.length), sub: fmtN(expired.length) + ' expired · ' + fmtN(risk12m.length) + ' within 12m', color: 'red' });
  html += '</div>';

  // Backfill Queue
  if (backfill.length > 0) {
    html += '<div class="widget" style="margin-bottom:16px">';
    html += '<div class="widget-title">Lease Data Backfill Queue <span style="font-size:12px;font-weight:400;color:var(--text3)">(' + backfill.length + ' clinics need lease data)</span></div>';
    html += '<div style="font-size:13px;color:var(--text2);margin-bottom:10px">Clinics missing lease information — research candidates for the Research tab.</div>';
    html += '<button class="retry-btn" onclick="currentDiaTab=\'research\';renderDiaTab()">Go to Research Workbench</button>';
    html += '</div>';
  }

  // Data Gap Summary
  if (totalGaps > 0) {
    html += '<div class="widget" style="margin-bottom:16px">';
    html += '<div class="widget-title">Lease Data Quality</div>';
    var gapBuckets = [
      { label: 'Missing Property Link', count: missingPropLink, color: '#ef4444' },
      { label: 'Stale vs Inventory', count: staleLeases, color: '#fb923c' },
      { label: 'Missing Lease Row', count: missingLeaseRow, color: '#f59e0b' },
      { label: 'Expired on Active', count: expiredActive, color: '#f87171' },
      { label: 'Expiring < 12mo', count: expiring12m, color: '#fbbf24' },
    ];
    var maxB = Math.max.apply(null, gapBuckets.map(function(b) { return b.count; }).concat([1]));
    html += '<div style="display:flex;flex-direction:column;gap:6px">';
    for (var gi = 0; gi < gapBuckets.length; gi++) {
      var b = gapBuckets[gi];
      if (b.count === 0) continue;
      var pctW = ((b.count / maxB) * 100).toFixed(0);
      html += '<div style="display:flex;align-items:center;gap:8px">';
      html += '<div style="width:140px;font-size:12px;color:var(--text2);text-align:right;flex-shrink:0">' + b.label + '</div>';
      html += '<div style="flex:1;background:var(--s2);border-radius:4px;height:22px;overflow:hidden">';
      html += '<div style="width:' + pctW + '%;background:' + b.color + ';height:100%;border-radius:4px;min-width:2px"></div>';
      html += '</div>';
      html += '<div style="width:50px;font-size:12px;font-weight:600;color:var(--text)">' + fmtN(b.count) + '</div>';
      html += '</div>';
    }
    html += '</div></div>';
  }

  // Lease Renewal Watchlist Table
  if (watchlist.length > 0) {
    html += '<div class="widget" style="margin-bottom:16px">';
    html += '<div class="widget-title">Lease Renewal Watchlist <span style="font-size:12px;font-weight:400;color:var(--text3)">(' + watchlist.length + ' clinics)</span></div>';
    html += '<div style="font-size:13px;color:var(--text2);margin-bottom:10px">Clinics with expiring, expired, or at-risk leases — sorted by urgency.</div>';
    html += '<div class="gov-table-card"><table class="gov-table"><thead><tr>';
    html += '<th>Facility</th><th>Operator</th><th>City</th><th>State</th><th>Risk</th><th style="text-align:right">Months Left</th><th>Expiration</th><th style="text-align:center;min-width:140px">Actions</th>';
    html += '</tr></thead><tbody>';
    var sorted = watchlist.slice().sort(function(a, b) { return (a.months_to_expiration || 999) - (b.months_to_expiration || 999); });
    for (var wi = 0; wi < Math.min(sorted.length, 75); wi++) {
      var c = sorted[wi];
      var mo = c.months_to_expiration;
      var moLabel = mo != null ? (mo <= 0 ? 'Expired' : mo + 'mo') : '—';
      var moColor = mo != null ? (mo <= 0 ? 'var(--red)' : mo <= 12 ? '#f87171' : mo <= 24 ? '#fb923c' : 'var(--text2)') : 'var(--text3)';
      var riskBadge = c.closure_watch_level === 'high' ? '<span style="background:#ef4444;color:#fff;padding:1px 6px;border-radius:4px;font-size:11px">HIGH</span>'
        : c.closure_watch_level === 'moderate' ? '<span style="background:#f59e0b;color:#000;padding:1px 6px;border-radius:4px;font-size:11px">MOD</span>'
        : '<span style="font-size:11px;color:var(--text3)">low</span>';
      var exp = c.lease_expiration ? new Date(c.lease_expiration).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : '—';
      html += '<tr class="clickable-row" onclick=\'showDetail(' + safeJSON(c) + ', "dia-clinic")\'>';
      html += '<td>' + esc(c.facility_name || '—') + '</td>';
      html += '<td>' + ((c.operator_name || c.parent_organization) ? entityLink(c.operator_name || c.parent_organization, 'operator', null) : '—') + '</td>';
      html += '<td>' + esc(c.city || '—') + '</td>';
      html += '<td>' + esc(c.state || '—') + '</td>';
      html += '<td>' + riskBadge + '</td>';
      html += '<td style="text-align:right;color:' + moColor + ';font-weight:600">' + moLabel + '</td>';
      html += '<td>' + exp + '</td>';
      html += '<td style="text-align:center" onclick="event.stopPropagation()">';
      html += '<div style="display:flex;gap:3px;justify-content:center">';
      html += '<button class="lease-flag-btn" data-lid="' + esc(c.clinic_id || c.medicare_id || '') + '" data-lname="' + esc(c.facility_name || '') + '" style="font-size:9px;padding:2px 8px;border:1px solid var(--border);border-radius:3px;background:var(--s3);color:var(--text2);cursor:pointer;" title="Flag for research">Flag</button>';
      html += '<button class="gov-row-action" onclick=\'showDetail(' + safeJSON(c) + ', "dia-clinic", "Ownership")\' title="View owner details & contacts">📞</button>';
      html += '<button class="gov-row-action accent" onclick=\'showDetail(' + safeJSON(c) + ', "dia-clinic", "Intel")\' title="Research & intel">🔍</button>';
      html += '</div></td>';
      html += '</tr>';
    }
    html += '</tbody></table></div>';
    if (watchlist.length > 75) html += '<div style="text-align:center;font-size:12px;color:var(--text3);padding:8px">Showing 75 of ' + watchlist.length + '</div>';
    html += '</div>';
  }

  // Operator Lease Exposure
  var opMap = {};
  for (var oi = 0; oi < watchlist.length; oi++) {
    var row = watchlist[oi];
    var op = row.operator_name || row.parent_organization || 'Independent';
    if (!opMap[op]) opMap[op] = { count: 0, expired: 0, expiring12m: 0 };
    opMap[op].count++;
    if (row.months_to_expiration != null && row.months_to_expiration <= 0) opMap[op].expired++;
    if (row.months_to_expiration != null && row.months_to_expiration > 0 && row.months_to_expiration <= 12) opMap[op].expiring12m++;
  }
  var topOps = Object.entries(opMap).sort(function(a, b) { return b[1].count - a[1].count; }).slice(0, 15);
  if (topOps.length > 0) {
    html += '<div class="widget">';
    html += '<div class="widget-title">Operator Lease Exposure (Watchlist)</div>';
    html += '<div class="gov-table-card"><table class="gov-table"><thead><tr>';
    html += '<th>Operator</th><th style="text-align:right">On Watchlist</th><th style="text-align:right">Expired</th><th style="text-align:right">Expiring &lt;12mo</th>';
    html += '</tr></thead><tbody>';
    for (var ti = 0; ti < topOps.length; ti++) {
      var name = topOps[ti][0], data = topOps[ti][1];
      html += '<tr><td>' + esc(name) + '</td>';
      html += '<td style="text-align:right">' + fmtN(data.count) + '</td>';
      html += '<td style="text-align:right;color:' + (data.expired > 0 ? 'var(--red)' : 'var(--text2)') + '">' + fmtN(data.expired) + '</td>';
      html += '<td style="text-align:right;color:' + (data.expiring12m > 0 ? '#f87171' : 'var(--text2)') + '">' + fmtN(data.expiring12m) + '</td>';
      html += '</tr>';
    }
    html += '</tbody></table></div></div>';
  }

  html += '</div>';

  // Attach handlers after DOM render (called via setTimeout from renderDiaLeases)
  setTimeout(function() {
    document.querySelectorAll('.lease-flag-btn').forEach(function(btn) {
      btn.addEventListener('click', async function() {
        var lid = btn.dataset.lid;
        var lname = btn.dataset.lname;
        if (!lid) return;
        btn.disabled = true;
        btn.textContent = '...';
        try {
          await applyInsertWithFallback({
            proxyBase: '/api/dia-query',
            table: 'research_queue_outcomes',
            data: {
              medicare_id: lid,
              outcome: 'flagged_for_review',
              notes: 'Flagged from Lease Watchlist — expiring/at-risk lease',
              created_at: new Date().toISOString()
            },
            source_surface: 'dia_lease_flag'
          });
          btn.textContent = '✓';
          btn.style.color = 'var(--success)';
          btn.style.borderColor = 'var(--success)';
          showToast('Flagged ' + (lname || lid) + ' for review', 'success');
        } catch(e) {
          btn.disabled = false;
          btn.textContent = 'Flag';
          showToast('Flag failed: ' + e.message, 'error');
        }
      });
    });
  }, 0);

  return html;
}

// ============================================================================
// DIALYSIS LOANS TAB
// ============================================================================
let diaLoansData = null;

function renderDiaLoans() {
  const el = document.getElementById('bizPageInner');
  if (!el) return '';

  if (!diaLoansData) {
    el.innerHTML = '<div class="loading"><span class="spinner"></span> Loading loan data...</div>';
    (async () => {
      try {
        const loans = await diaQuery('v_loans',
          'loan_id,property_id,facility_name,address,city,state,operator,loan_amount,current_balance,interest_rate_percent,interest_rate_text,maturity_date,origination_date,loan_to_value,loan_type,recourse,alert_flag,lender_name,loan_term',
          { limit: 1000 }
        );
        diaLoansData = loans || [];
        el.innerHTML = buildDiaLoansHTML();
      } catch (e) {
        console.error('Dia loans load error:', e);
        el.innerHTML = '<div class="widget-error"><div class="err-msg">Failed to load loan data: ' + esc(e.message || '') + '</div><button class="retry-btn" onclick="diaLoansData=null;renderDiaLoans()">Retry</button></div>';
      }
    })();
    return '';
  }

  el.innerHTML = buildDiaLoansHTML();
  return '';
}

function buildDiaLoansHTML() {
  const loans = diaLoansData || [];

  let html = '<div style="margin-bottom:24px">';
  html += '<div style="font-size:16px;font-weight:700;margin-bottom:12px;display:flex;align-items:center;gap:8px"><span style="font-size:20px">🏦</span> Dialysis Loan Intelligence</div>';

  // === Action guidance banner ===
  html += '<div style="padding:10px 14px;background:rgba(108,140,255,0.08);border-radius:8px;border-left:3px solid #6c8cff;margin-bottom:16px;display:flex;align-items:center;gap:10px;">';
  html += '<div style="font-size:13px;color:var(--text);line-height:1.4"><strong>Action:</strong> Review loan data for maturity signals and financing patterns. <strong>Flag</strong> loans approaching maturity or with distress indicators for prospecting consideration. <strong>Ack</strong> (acknowledge) flagged loans you have already reviewed.</div>';
  html += '</div>';

  if (loans.length === 0) {
    html += '<div class="widget" style="text-align:center;padding:40px 20px">';
    html += '<div style="font-size:48px;margin-bottom:12px;opacity:0.3">🏦</div>';
    html += '<div style="font-size:16px;font-weight:600;margin-bottom:8px;color:var(--text)">No Loan Data Available</div>';
    html += '</div></div>';
    return html;
  }

  // Stats
  var withAmt = loans.filter(function(l) { return l.loan_amount; });
  var totalVol = withAmt.reduce(function(s, l) { return s + (parseFloat(l.loan_amount) || 0); }, 0);
  var withRate = loans.filter(function(l) { return parseFloat(l.interest_rate_percent) > 0; });
  var avgRate = withRate.length > 0 ? (withRate.reduce(function(s, l) { return s + parseFloat(l.interest_rate_percent); }, 0) / withRate.length) : 0;
  var withMaturity = loans.filter(function(l) { return l.maturity_date; });
  var now = new Date();
  var oneYr = new Date(now.getFullYear() + 1, now.getMonth(), now.getDate());
  var maturingUnder1 = withMaturity.filter(function(l) { return new Date(l.maturity_date) <= oneYr; }).length;
  var flagged = loans.filter(function(l) { return l.alert_flag; }).length;

  html += '<div class="dia-grid dia-grid-4" style="margin-bottom:20px">';
  html += infoCard({ title: 'Total Loans', value: fmtN(loans.length), sub: fmtN(withAmt.length) + ' with amounts', color: 'blue' });
  html += infoCard({ title: 'Total Volume', value: fmt(totalVol), sub: 'Across ' + fmtN(withAmt.length) + ' loans', color: 'green' });
  html += infoCard({ title: 'Avg Rate', value: avgRate > 0 ? avgRate.toFixed(2) + '%' : 'N/A', sub: withRate.length + ' loans with rates', color: 'cyan' });
  html += infoCard({ title: 'Flagged', value: fmtN(flagged), sub: flagged > 0 ? 'Need attention' : 'No alerts', color: flagged > 0 ? 'red' : 'green' });
  html += '</div>';

  // Loan size distribution
  var buckets = [
    { label: '$0–$1M', min: 0, max: 1e6, count: 0, vol: 0 },
    { label: '$1M–$5M', min: 1e6, max: 5e6, count: 0, vol: 0 },
    { label: '$5M–$10M', min: 5e6, max: 10e6, count: 0, vol: 0 },
    { label: '$10M–$25M', min: 10e6, max: 25e6, count: 0, vol: 0 },
    { label: '$25M+', min: 25e6, max: Infinity, count: 0, vol: 0 }
  ];
  withAmt.forEach(function(l) {
    var amt = parseFloat(l.loan_amount) || 0;
    for (var i = 0; i < buckets.length; i++) {
      if (amt >= buckets[i].min && amt < buckets[i].max) {
        buckets[i].count++;
        buckets[i].vol += amt;
        break;
      }
    }
  });
  var maxBkt = Math.max.apply(null, buckets.map(function(b) { return b.count; }).concat([1]));

  html += '<div class="widget" style="margin-bottom:16px">';
  html += '<div class="widget-title">Loan Size Distribution</div>';
  html += '<div style="display:flex;flex-direction:column;gap:6px">';
  for (var bi = 0; bi < buckets.length; bi++) {
    var bk = buckets[bi];
    if (bk.count === 0) continue;
    var pctW = ((bk.count / maxBkt) * 100).toFixed(0);
    html += '<div style="display:flex;align-items:center;gap:8px">';
    html += '<div style="width:100px;font-size:12px;color:var(--text2);text-align:right;flex-shrink:0">' + bk.label + '</div>';
    html += '<div style="flex:1;background:var(--s2);border-radius:4px;height:22px;overflow:hidden">';
    html += '<div style="width:' + pctW + '%;background:#6c8cff;height:100%;border-radius:4px;min-width:2px"></div>';
    html += '</div>';
    html += '<div style="width:40px;font-size:12px;font-weight:600;color:var(--text)">' + fmtN(bk.count) + '</div>';
    html += '<div style="width:70px;font-size:11px;color:var(--text3)">' + fmt(bk.vol) + '</div>';
    html += '</div>';
  }
  html += '</div></div>';

  // Loan table — top loans by amount
  var sorted = withAmt.slice().sort(function(a, b) { return (parseFloat(b.loan_amount) || 0) - (parseFloat(a.loan_amount) || 0); });
  html += '<div class="widget" style="margin-bottom:16px">';
  html += '<div class="widget-title">Largest Loans <span style="font-size:12px;font-weight:400;color:var(--text3)">(' + fmtN(sorted.length) + ' loans with amounts)</span></div>';
  html += '<div class="gov-table-card"><table class="gov-table"><thead><tr>';
  html += '<th>Facility</th><th>City</th><th style="text-align:right">Loan Amount</th><th style="text-align:right">Rate</th><th>Type</th><th>Lender</th><th>Maturity</th><th>Alert</th><th style="text-align:center;min-width:140px">Actions</th>';
  html += '</tr></thead><tbody>';
  for (var li = 0; li < Math.min(sorted.length, 50); li++) {
    var ln = sorted[li];
    var rate = parseFloat(ln.interest_rate_percent) > 0 ? parseFloat(ln.interest_rate_percent).toFixed(2) + '%' : (ln.interest_rate_text || '—');
    var alertBadge = ln.alert_flag ? '<span style="background:#ef4444;color:#fff;padding:1px 6px;border-radius:4px;font-size:11px">FLAG</span>' : '<span style="font-size:11px;color:var(--text3)">—</span>';
    var matDate = ln.maturity_date ? new Date(ln.maturity_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short' }) : '—';
    html += '<tr class="clickable-row" onclick=\'showDetail(' + safeJSON(ln) + ', "dia-clinic")\'>';
    html += '<td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(ln.facility_name || String(ln.property_id || '—')) + '</td>';
    html += '<td>' + esc((ln.city || '') + (ln.state ? ', ' + ln.state : '')) + '</td>';
    html += '<td style="text-align:right;font-weight:600">' + fmt(parseFloat(ln.loan_amount) || 0) + '</td>';
    html += '<td style="text-align:right">' + rate + '</td>';
    html += '<td>' + esc(ln.loan_type || '—') + '</td>';
    html += '<td>' + esc(ln.lender_name || '—') + '</td>';
    html += '<td>' + matDate + '</td>';
    html += '<td>' + alertBadge + '</td>';
    html += '<td style="text-align:center" onclick="event.stopPropagation()">';
    html += '<div style="display:flex;gap:3px;justify-content:center">';
    html += '<button class="loan-flag-btn" data-loan-id="' + esc(ln.loan_id || '') + '" data-loan-name="' + esc(ln.facility_name || '') + '" style="font-size:9px;padding:2px 8px;border:1px solid var(--border);border-radius:3px;background:var(--s3);color:var(--text2);cursor:pointer;" title="Flag for review">' + (ln.alert_flag ? 'Ack' : 'Flag') + '</button>';
    html += '<button class="gov-row-action" onclick=\'showDetail(' + safeJSON(ln) + ', "dia-clinic", "Ownership")\' title="View owner details & contacts">📞</button>';
    html += '<button class="gov-row-action accent" onclick=\'showDetail(' + safeJSON(ln) + ', "dia-clinic", "Intel")\' title="Research & intel">🔍</button>';
    html += '</div></td>';
    html += '</tr>';
  }
  html += '</tbody></table></div>';
  if (sorted.length > 50) html += '<div style="text-align:center;font-size:12px;color:var(--text3);padding:8px">Showing 50 of ' + fmtN(sorted.length) + '</div>';
  html += '</div>';

  html += '</div>';

  // Attach handlers after DOM render
  setTimeout(function() {
    document.querySelectorAll('.loan-flag-btn').forEach(function(btn) {
      btn.addEventListener('click', async function() {
        var loanId = btn.dataset.loanId;
        var loanName = btn.dataset.loanName;
        if (!loanId) return;
        btn.disabled = true;
        btn.textContent = '...';
        try {
          await applyInsertWithFallback({
            proxyBase: '/api/dia-query',
            table: 'research_queue_outcomes',
            data: {
              medicare_id: loanId,
              outcome: 'flagged_for_review',
              notes: 'Flagged from Loans tab — loan alert acknowledged',
              created_at: new Date().toISOString()
            },
            source_surface: 'dia_loan_flag'
          });
          btn.textContent = '✓';
          btn.style.color = 'var(--success)';
          btn.style.borderColor = 'var(--success)';
          showToast('Loan flagged: ' + (loanName || loanId), 'success');
        } catch(e) {
          btn.disabled = false;
          btn.textContent = 'Flag';
          showToast('Flag failed: ' + e.message, 'error');
        }
      });
    });
  }, 0);

  return html;
}
// DIALYSIS PLAYERS (Top Operators, Largest Clinics)
// ============================================================================

let diaPlayersView = 'operators';
let diaBuyers = null;        // lazy-loaded from sales_transactions
let diaSellers = null;       // lazy-loaded from sales_transactions
let diaBrokers = null;       // lazy-loaded from sale_brokers/brokers/sales_transactions (joined client-side)
let diaPlayersLoading = false;

function renderDiaPlayers() {
  // Apply pending navigation filter
  if (window._pendingOpFilter) {
    const filter = window._pendingOpFilter;
    window._pendingOpFilter = null;

    if (filter.type === 'operator') {
      // Switch to operators view and highlight the matching operator
      diaPlayersView = 'operators';
      window._highlightOperator = filter.value;
    } else if (filter.type === 'state') {
      // Switch to operators view filtered by state
      diaPlayersView = 'operators';
      window._highlightState = filter.value;
    }
  }

  let html = '<div class="biz-section">';

  // === Action guidance banner ===
  html += '<div style="padding:10px 14px;background:rgba(167,139,250,0.08);border-radius:8px;border-left:3px solid #a78bfa;margin-bottom:16px;display:flex;align-items:center;gap:10px;">';
  html += '<div style="font-size:13px;color:var(--text);line-height:1.4"><strong>Market Players</strong> — Analyze operators, buyers, sellers, and brokers active in the dialysis property market. Click any row to view entity details and related properties. Use this intelligence for pipeline targeting and competitive positioning.</div>';
  html += '</div>';

  // View toggle
  html += '<div class="pills" style="margin-bottom: 20px;">';
  ['operators', 'largest', 'movers', 'buyers', 'sellers', 'brokers'].forEach(view => {
    const active = diaPlayersView === view ? ' active' : '';
    const label = view === 'operators' ? 'Top Operators' : view === 'largest' ? 'Largest Clinics' : view === 'movers' ? 'Biggest Movers' : view === 'buyers' ? 'Top Buyers' : view === 'sellers' ? 'Top Sellers' : 'Brokers';
    html += '<button class="pill' + active + '" onclick="diaPlayersView=\'' + view + '\';renderDiaTab()">' + label + '</button>';
  });
  html += '</div>';

  const changes = diaData.inventoryChanges || [];

  if (diaPlayersView === 'operators') {
    // Aggregate by operator
    const opMap = {};
    changes.forEach(r => {
      if (r.operator_name) {
        const key = r.operator_name.trim().toUpperCase();
        if (!opMap[key]) opMap[key] = { name: r.operator_name, clinics: 0, patients: 0, records: [] };
        opMap[key].clinics++;
        opMap[key].patients += (r.latest_total_patients || 0);
        opMap[key].records.push(r);
      }
    });
    const topOps = Object.values(opMap).sort((a, b) => b.clinics - a.clinics).slice(0, 50);

    html += '<div class="gov-metrics">';
    html += metricHTML('Unique Operators', fmtN(topOps.length), 'in dataset', 'blue');
    html += metricHTML('Top Operator', (topOps[0]?.name || '—').substring(0, 25), topOps[0]?.clinics + ' clinics', 'green');
    const totalPatients = topOps.reduce((s, p) => s + p.patients, 0);
    html += metricHTML('Total Patients', fmtN(totalPatients), 'across all operators', 'purple');
    html += '</div>';

    html += '<div class="table-wrapper"><div class="data-table">';
    html += '<div class="table-row" style="font-weight: 600; border-bottom: 2px solid var(--border);">';
    html += '<div style="flex: 3;">Operator</div>';
    html += '<div style="flex: 1; text-align: right;">Clinics</div>';
    html += '<div style="flex: 1; text-align: right;">Total Patients</div>';
    html += '<div style="flex: 1; text-align: right;">Avg Patients</div>';
    html += '<div style="flex: 0.8; text-align: center;">Actions</div>';
    html += '</div>';

    topOps.forEach((p, idx) => {
      const avg = p.clinics > 0 ? Math.round(p.patients / p.clinics) : 0;

      // Check for operator or state highlighting
      const isHighlightOp = window._highlightOperator && (p.name || '').toLowerCase().includes(window._highlightOperator.toLowerCase());
      const isHighlightState = window._highlightState && p.records.some(r => (r.state || '').toUpperCase() === window._highlightState.toUpperCase());
      const rowStyle = (isHighlightOp || isHighlightState) ? 'background:var(--accent-bg,rgba(59,130,246,0.1));border-left: 3px solid var(--accent,#3b82f6);' : '';

      html += '<div class="table-row clickable-row" style="' + rowStyle + '" onclick=\'showDetail(' + safeJSON(p.records[0]) + ', "dia-clinic")\'>';
      html += '<div style="flex: 3;"><span style="color: var(--text2); margin-right: 8px;">#' + (idx + 1) + '</span>' + esc(p.name) + '</div>';
      html += '<div style="flex: 1; text-align: right; color: var(--accent);">' + p.clinics + '</div>';
      html += '<div style="flex: 1; text-align: right;">' + fmtN(p.patients) + '</div>';
      html += '<div style="flex: 1; text-align: right; color: var(--text2);">' + fmtN(avg) + '</div>';
      html += '<div style="flex: 0.8; text-align: center;" onclick="event.stopPropagation()"><button class="gov-row-action" onclick=\'showDetail(' + safeJSON(p.records[0]) + ', "dia-clinic", "Ownership")\' title="View owner & contacts">📞</button> <button class="gov-row-action accent" onclick=\'showDetail(' + safeJSON(p.records[0]) + ', "dia-clinic", "Intel")\' title="Research & intel">🔍</button></div>';
      html += '</div>';
    });
    html += '</div></div>';

    // Clear highlight flags after rendering
    window._highlightOperator = null;
    window._highlightState = null;

  } else if (diaPlayersView === 'largest') {
    // Largest clinics by patient count
    const sorted = [...changes].sort((a, b) => (b.latest_total_patients || 0) - (a.latest_total_patients || 0)).slice(0, 50);

    html += '<div class="gov-metrics">';
    html += metricHTML('Largest Clinic', (sorted[0]?.facility_name || '—').substring(0, 25), fmtN(sorted[0]?.latest_total_patients || 0) + ' patients', 'green');
    html += metricHTML('Top 10 Avg', fmtN(Math.round(sorted.slice(0, 10).reduce((s, r) => s + (r.latest_total_patients || 0), 0) / Math.min(10, sorted.length))), 'patients per clinic', 'blue');
    html += '</div>';

    html += '<div class="table-wrapper"><div class="data-table">';
    html += '<div class="table-row" style="font-weight: 600; border-bottom: 2px solid var(--border);">';
    html += '<div style="flex: 2;">Facility</div>';
    html += '<div style="flex: 1;">City, State</div>';
    html += '<div style="flex: 1;">Operator</div>';
    html += '<div style="flex: 1; text-align: right;">Patients</div>';
    html += '<div style="flex: 1;">CCN</div>';
    html += '<div style="flex: 0.8; text-align: center;">Actions</div>';
    html += '</div>';

    sorted.forEach((r, idx) => {
      html += '<div class="table-row clickable-row" onclick=\'showDetail(' + safeJSON(r) + ', "dia-clinic")\'>';
      html += '<div style="flex: 2;"><span style="color: var(--text2); margin-right: 8px;">#' + (idx + 1) + '</span>' + esc(r.facility_name || '—') + '</div>';
      html += '<div style="flex: 1;">' + esc((r.city || '') + (r.city && r.state ? ', ' : '') + (r.state || '')) + '</div>';
      html += '<div style="flex: 1;" class="truncate">' + (r.operator_name ? entityLink(r.operator_name, 'operator', null) : '—') + '</div>';
      html += '<div style="flex: 1; text-align: right; color: var(--accent);">' + fmtN(r.latest_total_patients || 0) + '</div>';
      html += '<div style="flex: 1; color: var(--text2);">' + esc(r.ccn || '—') + '</div>';
      html += '<div style="flex: 0.8; text-align: center;" onclick="event.stopPropagation()"><button class="gov-row-action" onclick=\'showDetail(' + safeJSON(r) + ', "dia-clinic", "Ownership")\' title="View owner & contacts">📞</button> <button class="gov-row-action accent" onclick=\'showDetail(' + safeJSON(r) + ', "dia-clinic", "Intel")\' title="Research & intel">🔍</button></div>';
      html += '</div>';
    });
    html += '</div></div>';

  } else if (diaPlayersView === 'movers') {
    // Biggest movers by absolute delta
    const sorted = [...changes].filter(r => r.delta_patients !== 0).sort((a, b) => Math.abs(b.delta_patients || 0) - Math.abs(a.delta_patients || 0)).slice(0, 50);

    html += '<div class="gov-metrics">';
    const biggestUp = changes.filter(r => (r.delta_patients || 0) > 0).sort((a, b) => b.delta_patients - a.delta_patients)[0];
    const biggestDown = changes.filter(r => (r.delta_patients || 0) < 0).sort((a, b) => a.delta_patients - b.delta_patients)[0];
    html += metricHTML('Biggest Gainer', (biggestUp?.facility_name || '—').substring(0, 25), '+' + fmtN(biggestUp?.delta_patients || 0) + ' patients', 'green');
    html += metricHTML('Biggest Loser', (biggestDown?.facility_name || '—').substring(0, 25), fmtN(biggestDown?.delta_patients || 0) + ' patients', 'red');
    html += '</div>';

    html += '<div class="table-wrapper"><div class="data-table">';
    html += '<div class="table-row" style="font-weight: 600; border-bottom: 2px solid var(--border);">';
    html += '<div style="flex: 2;">Facility</div>';
    html += '<div style="flex: 1;">City, State</div>';
    html += '<div style="flex: 1;">Operator</div>';
    html += '<div style="flex: 1; text-align: right;">Delta</div>';
    html += '<div style="flex: 1; text-align: right;">% Change</div>';
    html += '<div style="flex: 1; text-align: right;">Current</div>';
    html += '<div style="flex: 0.8; text-align: center;">Actions</div>';
    html += '</div>';

    sorted.forEach((r, idx) => {
      const deltaColor = (r.delta_patients || 0) > 0 ? '#34d399' : '#f87171';
      html += '<div class="table-row clickable-row" onclick=\'showDetail(' + safeJSON(r) + ', "dia-clinic")\'>';
      html += '<div style="flex: 2;"><span style="color: var(--text2); margin-right: 8px;">#' + (idx + 1) + '</span>' + esc(r.facility_name || '—') + '</div>';
      html += '<div style="flex: 1;">' + esc((r.city || '') + (r.city && r.state ? ', ' : '') + (r.state || '')) + '</div>';
      html += '<div style="flex: 1;" class="truncate">' + (r.operator_name ? entityLink(r.operator_name, 'operator', null) : '—') + '</div>';
      html += '<div style="flex: 1; text-align: right; color: ' + deltaColor + ';">' + ((r.delta_patients || 0) > 0 ? '+' : '') + fmtN(r.delta_patients || 0) + '</div>';
      html += '<div style="flex: 1; text-align: right; color: var(--text2);">' + pct(r.pct_change || 0) + '</div>';
      html += '<div style="flex: 1; text-align: right; color: var(--accent);">' + fmtN(r.latest_total_patients || 0) + '</div>';
      html += '<div style="flex: 0.8; text-align: center;" onclick="event.stopPropagation()"><button class="gov-row-action" onclick=\'showDetail(' + safeJSON(r) + ', "dia-clinic", "Ownership")\' title="View owner & contacts">📞</button> <button class="gov-row-action accent" onclick=\'showDetail(' + safeJSON(r) + ', "dia-clinic", "Intel")\' title="Research & intel">🔍</button></div>';
      html += '</div>';
    });
    html += '</div></div>';
  } else if (diaPlayersView === 'buyers') {
    // Show loading spinner and load data on first view
    if (diaBuyers === null && !diaPlayersLoading) {
      html += '<div style="color: var(--text2); text-align: center; padding: 40px;">Loading buyer data...</div>';
      diaPlayersLoading = true;
      (async () => {
        try {
          const buyersRaw = await diaQueryAll('sales_transactions', 'buyer_name,buyer_type,sold_price,sale_date,cap_rate,property_id');
          // Group by buyer_name
          const buyerMap = {};
          buyersRaw.forEach(r => {
            if (r.buyer_name) {
              const key = r.buyer_name.trim().toUpperCase();
              if (!buyerMap[key]) buyerMap[key] = { name: r.buyer_name, type: r.buyer_type, deals: 0, volume: 0, prices: [], capRates: [], records: [] };
              buyerMap[key].deals++;
              buyerMap[key].volume += (r.sold_price || 0);
              if (r.cap_rate) { var _cr = parseFloat(r.cap_rate); buyerMap[key].capRates.push(_cr < 1 ? _cr * 100 : _cr); }
              buyerMap[key].records.push(r);
            }
          });
          diaBuyers = Object.values(buyerMap).sort((a, b) => b.volume - a.volume);
          diaPlayersLoading = false;
          renderDiaTab();
        } catch (err) {
          console.error('Error loading buyer data:', err);
          diaPlayersLoading = false;
        }
      })();
    } else if (diaBuyers) {
      const top50 = diaBuyers.slice(0, 50);
      const totalVolume = top50.reduce((s, b) => s + b.volume, 0);
      const totalDeals = top50.reduce((s, b) => s + b.deals, 0);

      html += '<div class="dia-grid dia-grid-4" style="gap: 12px; margin-bottom: 20px;">';
      html += infoCard({ title: 'Total Buyers', value: fmtN(diaBuyers.length), sub: 'in dataset', color: 'blue' });
      html += infoCard({ title: 'Top Buyer', value: top50[0] ? (top50[0].name.substring(0, 30) || '—') : '—', sub: top50[0] ? fmt(top50[0].volume) + ' volume' : '', color: 'green' });
      html += infoCard({ title: 'Avg Deal Size', value: fmt(Math.round(totalVolume / Math.max(1, totalDeals))), sub: 'across top 50', color: 'cyan' });
      html += infoCard({ title: 'Total Deals', value: fmtN(totalDeals), sub: 'transactions (top 50)', color: 'purple' });
      html += '</div>';

      html += '<div class="table-wrapper"><div class="data-table">';
      html += '<div class="table-row" style="font-weight: 600; border-bottom: 2px solid var(--border);">';
      html += '<div style="flex: 2;">Buyer Name</div>';
      html += '<div style="flex: 1;">Type</div>';
      html += '<div style="flex: 1; text-align: right;">Deals</div>';
      html += '<div style="flex: 1; text-align: right;">Total Volume</div>';
      html += '<div style="flex: 1; text-align: right;">Avg Cap Rate</div>';
      html += '<div style="flex: 0.8; text-align: center;">Actions</div>';
      html += '</div>';

      top50.forEach((b, idx) => {
        const avgCapRate = b.capRates.length > 0 ? b.capRates.reduce((s, cr) => s + cr, 0) / b.capRates.length : 0;
        html += '<div class="table-row clickable-row" onclick=\'showDetail(' + safeJSON(b.records[0]) + ', "sales-transaction")\'>';
        html += '<div style="flex: 2;"><span style="color: var(--text2); margin-right: 8px;">#' + (idx + 1) + '</span>' + entityLink(b.name, 'contact', null, 'dialysis') + '</div>';
        html += '<div style="flex: 1;">' + esc(b.type || '—') + '</div>';
        html += '<div style="flex: 1; text-align: right; color: var(--accent);">' + b.deals + '</div>';
        html += '<div style="flex: 1; text-align: right;">' + fmt(b.volume, 'currency') + '</div>';
        html += '<div style="flex: 1; text-align: right; color: var(--text2);">' + pct(avgCapRate / 100) + '</div>';
        html += '<div style="flex: 0.8; text-align: center;" onclick="event.stopPropagation()"><button class="gov-row-action" onclick=\'showDetail(' + safeJSON(b.records[0]) + ', "dia-clinic", "Ownership")\' title="View owner & contacts">📞</button> <button class="gov-row-action accent" onclick=\'showDetail(' + safeJSON(b.records[0]) + ', "dia-clinic", "Intel")\' title="Research & intel">🔍</button></div>';
        html += '</div>';
      });
      html += '</div></div>';
    }

  } else if (diaPlayersView === 'sellers') {
    // Show loading spinner and load data on first view
    if (diaSellers === null && !diaPlayersLoading) {
      html += '<div style="color: var(--text2); text-align: center; padding: 40px;">Loading seller data...</div>';
      diaPlayersLoading = true;
      (async () => {
        try {
          const sellersRaw = await diaQueryAll('sales_transactions', 'seller_name,seller_type,sold_price,sale_date,cap_rate,property_id');
          // Group by seller_name
          const sellerMap = {};
          sellersRaw.forEach(r => {
            if (r.seller_name) {
              const key = r.seller_name.trim().toUpperCase();
              if (!sellerMap[key]) sellerMap[key] = { name: r.seller_name, type: r.seller_type, deals: 0, volume: 0, prices: [], capRates: [], records: [] };
              sellerMap[key].deals++;
              sellerMap[key].volume += (r.sold_price || 0);
              if (r.cap_rate) { var _cr = parseFloat(r.cap_rate); sellerMap[key].capRates.push(_cr < 1 ? _cr * 100 : _cr); }
              sellerMap[key].records.push(r);
            }
          });
          diaSellers = Object.values(sellerMap).sort((a, b) => b.volume - a.volume);
          diaPlayersLoading = false;
          renderDiaTab();
        } catch (err) {
          console.error('Error loading seller data:', err);
          diaPlayersLoading = false;
        }
      })();
    } else if (diaSellers) {
      const top50 = diaSellers.slice(0, 50);
      const totalVolume = top50.reduce((s, s2) => s + s2.volume, 0);
      const totalDeals = top50.reduce((s, s2) => s + s2.deals, 0);

      html += '<div class="dia-grid dia-grid-4" style="gap: 12px; margin-bottom: 20px;">';
      html += infoCard({ title: 'Total Sellers', value: fmtN(diaSellers.length), sub: 'in dataset', color: 'red' });
      html += infoCard({ title: 'Top Seller', value: top50[0] ? (top50[0].name.substring(0, 30) || '—') : '—', sub: top50[0] ? fmt(top50[0].volume) + ' volume' : '', color: 'green' });
      html += infoCard({ title: 'Avg Deal Size', value: fmt(Math.round(totalVolume / Math.max(1, totalDeals))), sub: 'across top 50', color: 'cyan' });
      html += infoCard({ title: 'Total Deals', value: fmtN(totalDeals), sub: 'transactions (top 50)', color: 'purple' });
      html += '</div>';

      html += '<div class="table-wrapper"><div class="data-table">';
      html += '<div class="table-row" style="font-weight: 600; border-bottom: 2px solid var(--border);">';
      html += '<div style="flex: 2;">Seller Name</div>';
      html += '<div style="flex: 1;">Type</div>';
      html += '<div style="flex: 1; text-align: right;">Deals</div>';
      html += '<div style="flex: 1; text-align: right;">Total Volume</div>';
      html += '<div style="flex: 1; text-align: right;">Avg Cap Rate</div>';
      html += '<div style="flex: 0.8; text-align: center;">Actions</div>';
      html += '</div>';

      top50.forEach((s2, idx) => {
        const avgCapRate = s2.capRates.length > 0 ? s2.capRates.reduce((s, cr) => s + cr, 0) / s2.capRates.length : 0;
        html += '<div class="table-row clickable-row" onclick=\'showDetail(' + safeJSON(s2.records[0]) + ', "sales-transaction")\'>';
        html += '<div style="flex: 2;"><span style="color: var(--text2); margin-right: 8px;">#' + (idx + 1) + '</span>' + entityLink(s2.name, 'contact', null, 'dialysis') + '</div>';
        html += '<div style="flex: 1;">' + esc(s2.type || '—') + '</div>';
        html += '<div style="flex: 1; text-align: right; color: var(--accent);">' + s2.deals + '</div>';
        html += '<div style="flex: 1; text-align: right;">' + fmt(s2.volume, 'currency') + '</div>';
        html += '<div style="flex: 1; text-align: right; color: var(--text2);">' + pct(avgCapRate / 100) + '</div>';
        html += '<div style="flex: 0.8; text-align: center;" onclick="event.stopPropagation()"><button class="gov-row-action" onclick=\'showDetail(' + safeJSON(s2.records[0]) + ', "dia-clinic", "Ownership")\' title="View owner & contacts">📞</button> <button class="gov-row-action accent" onclick=\'showDetail(' + safeJSON(s2.records[0]) + ', "dia-clinic", "Intel")\' title="Research & intel">🔍</button></div>';
        html += '</div>';
      });
      html += '</div></div>';
    }

  } else if (diaPlayersView === 'brokers') {
    // Show loading spinner and load data on first view
    if (diaBrokers === null && !diaPlayersLoading) {
      html += '<div style="color: var(--text2); text-align: center; padding: 40px;">Loading broker data...</div>';
      diaPlayersLoading = true;
      (async () => {
        try {
          // Query three tables and join client-side
          const saleBrokers = await diaQueryAll('sale_brokers', '*');
          const brokers = await diaQueryAll('brokers', 'broker_id,broker_name,company,email,phone');
          const sales = await diaQueryAll('sales_transactions', 'sale_id,sold_price,sale_date,cap_rate,buyer_name,seller_name');
          
          // Create lookup maps
          const brokerMap = {};
          brokers.forEach(b => { brokerMap[b.broker_id] = b; });
          const saleMap = {};
          sales.forEach(s => { saleMap[s.sale_id] = s; });
          
          // Join: for each sale_broker, add broker and sale info
          const brokerStats = {};
          saleBrokers.forEach(sb => {
            const broker = brokerMap[sb.broker_id];
            const sale = saleMap[sb.sale_id];
            if (broker && sale) {
              const key = broker.broker_id;
              if (!brokerStats[key]) {
                brokerStats[key] = {
                  broker_id: broker.broker_id,
                  broker_name: broker.broker_name,
                  company: broker.company,
                  email: broker.email,
                  phone: broker.phone,
                  deals: 0,
                  volume: 0,
                  capRates: [],
                  roles: new Set(),
                  records: []
                };
              }
              brokerStats[key].deals++;
              brokerStats[key].volume += (sale.sold_price || 0);
              if (sale.cap_rate) { var _cr = parseFloat(sale.cap_rate); brokerStats[key].capRates.push(_cr < 1 ? _cr * 100 : _cr); }
              brokerStats[key].roles.add(sb.role);
              brokerStats[key].records.push({ ...sb, broker: broker, sale: sale });
            }
          });
          
          // Convert to array and sort by volume
          diaBrokers = Object.values(brokerStats)
            .map(b => ({ ...b, roles: Array.from(b.roles) }))
            .sort((a, b) => b.volume - a.volume);
          diaPlayersLoading = false;
          renderDiaTab();
        } catch (err) {
          console.error('Error loading broker data:', err);
          diaPlayersLoading = false;
        }
      })();
    } else if (diaBrokers) {
      const top50 = diaBrokers.slice(0, 50);
      const totalVolume = top50.reduce((s, b) => s + b.volume, 0);
      const totalDeals = top50.reduce((s, b) => s + b.deals, 0);

      html += '<div class="dia-grid dia-grid-4" style="gap: 12px; margin-bottom: 20px;">';
      html += infoCard({ title: 'Total Brokers', value: fmtN(diaBrokers.length), sub: 'in dataset', color: 'orange' });
      html += infoCard({ title: 'Top Broker', value: top50[0] ? (top50[0].broker_name.substring(0, 30) || '—') : '—', sub: top50[0] ? fmt(top50[0].volume) + ' volume' : '', color: 'green' });
      html += infoCard({ title: 'Avg Deal Size', value: fmt(Math.round(totalVolume / Math.max(1, totalDeals))), sub: 'across top 50', color: 'cyan' });
      html += infoCard({ title: 'Total Deals', value: fmtN(totalDeals), sub: 'transactions (top 50)', color: 'purple' });
      html += '</div>';

      html += '<div class="table-wrapper"><div class="data-table">';
      html += '<div class="table-row" style="font-weight: 600; border-bottom: 2px solid var(--border);">';
      html += '<div style="flex: 2;">Broker Name</div>';
      html += '<div style="flex: 1;">Company</div>';
      html += '<div style="flex: 1; text-align: right;">Deals</div>';
      html += '<div style="flex: 1; text-align: right;">Total Volume</div>';
      html += '<div style="flex: 1; text-align: right;">Avg Cap Rate</div>';
      html += '<div style="flex: 0.8; text-align: center;">Actions</div>';
      html += '</div>';

      top50.forEach((b, idx) => {
        const avgCapRate = b.capRates.length > 0 ? b.capRates.reduce((s, cr) => s + cr, 0) / b.capRates.length : 0;
        html += '<div class="table-row clickable-row" onclick=\'showDetail(' + safeJSON(b.records[0]) + ', "sale-broker")\'>';
        html += '<div style="flex: 2;"><span style="color: var(--text2); margin-right: 8px;">#' + (idx + 1) + '</span>' + esc(b.broker_name) + '</div>';
        html += '<div style="flex: 1;" class="truncate">' + esc(b.company || '—') + '</div>';
        html += '<div style="flex: 1; text-align: right; color: var(--accent);">' + b.deals + '</div>';
        html += '<div style="flex: 1; text-align: right;">' + fmt(b.volume, 'currency') + '</div>';
        html += '<div style="flex: 1; text-align: right; color: var(--text2);">' + pct(avgCapRate / 100) + '</div>';
        html += '<div style="flex: 0.8; text-align: center;" onclick="event.stopPropagation()"><button class="gov-row-action" onclick=\'showDetail(' + safeJSON(b.records[0]) + ', "dia-clinic", "Ownership")\' title="View owner & contacts">📞</button> <button class="gov-row-action accent" onclick=\'showDetail(' + safeJSON(b.records[0]) + ', "dia-clinic", "Intel")\' title="Research & intel">🔍</button></div>';
        html += '</div>';
      });
      html += '</div></div>';
    }
  }

  html += '</div>';
  return html;
}

// ============================================================================
// DIALYSIS SEARCH
// ============================================================================

let diaSearchTerm = '';
let diaSearchResults = null;
let diaSearching = false;
const DIA_SEARCH_COLLAPSED_LIMIT = 5;
let _diaSearchExpanded = {}; // Track which categories are expanded

function renderDiaSearch() {
  let html = '<div class="biz-section">';
  html += '<div class="search-bar">';
  html += '<input type="text" id="diaSearchInput" placeholder="Search by facility name, city, state, operator, address..." value="' + esc(diaSearchTerm) + '" />';
  html += '<button onclick="execDiaSearch()">Search</button>';
  html += '</div>';

  if (diaSearching) {
    html += '<div class="search-loading">Searching across all dialysis records...</div>';
  } else if (diaSearchResults === null) {
    html += '<div class="search-empty">';
    html += '<div class="search-empty-icon">&#128269;</div>';
    html += '<p>Search across clinic inventory, NPI signals, property links, and research outcomes</p>';
    html += '</div>';
  } else {
    const { clinics, npiSignals, propQueue, outcomes } = diaSearchResults;
    const total = clinics.length + npiSignals.length + propQueue.length + outcomes.length;

    if (total === 0) {
      html += '<div class="search-empty"><p>No results found for "' + esc(diaSearchTerm) + '"</p></div>';
    } else {
      html += '<div style="color: var(--text2); font-size: 13px; margin-bottom: 12px;">' + total + ' result' + (total !== 1 ? 's' : '') + ' found</div>';

      // Category anchor bar — clickable jump links for each result type
      const categories = [
        { key: 'clinics', label: 'Clinics', count: clinics.length, color: '#a78bfa' },
        { key: 'npi', label: 'NPI Signals', count: npiSignals.length, color: '#f87171' },
        { key: 'property', label: 'Property Queue', count: propQueue.length, color: '#fbbf24' },
        { key: 'outcomes', label: 'Research', count: outcomes.length, color: '#34d399' }
      ].filter(c => c.count > 0);

      html += '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px">';
      categories.forEach(c => {
        html += '<a href="#dia-search-' + c.key + '" style="display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600;text-decoration:none;background:' + c.color + '20;color:' + c.color + ';border:1px solid ' + c.color + '30;cursor:pointer" onclick="event.preventDefault();document.getElementById(\'dia-search-' + c.key + '\')?.scrollIntoView({behavior:\'smooth\',block:\'start\'})">';
        html += c.label + ' <span style="opacity:0.8">(' + c.count + ')</span></a>';
      });
      html += '</div>';

      // Store flat search results array for onclick references (avoids massive inline JSON in DOM)
      window._diaSearchFlat = [];
      function pushDiaRef(record) {
        var idx = window._diaSearchFlat.length;
        window._diaSearchFlat.push(record);
        return idx;
      }

      if (clinics.length > 0) {
        var isExpanded = _diaSearchExpanded.clinics || false;
        var visibleClinics = isExpanded ? clinics : clinics.slice(0, DIA_SEARCH_COLLAPSED_LIMIT);
        html += '<div class="search-results-section" id="dia-search-clinics"><h4>Clinics (' + clinics.length + ')</h4>';
        visibleClinics.forEach(r => {
          var idx = pushDiaRef(r);
          html += '<div class="search-card" onclick="showDetail(window._diaSearchFlat[' + idx + '], \'dia-clinic\')">';
          html += '<div class="search-card-header"><span class="search-card-title">' + esc(norm(r.facility_name) || '—') + '</span>';
          html += '<span class="search-card-badge" style="background: rgba(167,139,250,0.15); color: #a78bfa;">Clinic</span></div>';
          html += '<div class="search-card-meta">';
          if (r.city || r.state) html += '<span>' + esc((norm(r.city) || '') + (r.city && r.state ? ', ' : '') + (r.state || '')) + '</span>';
          if (r.medicare_npi) html += '<span>NPI: ' + esc(r.medicare_npi) + '</span>';
          if (r.operator_name) html += '<span>Op: ' + esc(norm(r.operator_name)) + '</span>';
          if (r.latest_total_patients) html += '<span>Patients: ' + fmtN(r.latest_total_patients) + '</span>';
          if (r.change_type) html += '<span>' + esc(cleanLabel(r.change_type)) + '</span>';
          html += '</div>';
          html += '<div style="display:flex;gap:4px;margin-top:6px" onclick="event.stopPropagation()">';
          html += '<button class="gov-row-action" onclick="showDetail(window._diaSearchFlat[' + idx + '], \'dia-clinic\', \'Ownership\')" title="View owner & contacts">📞 Contacts</button>';
          html += '<button class="gov-row-action accent" onclick="showDetail(window._diaSearchFlat[' + idx + '], \'dia-clinic\', \'Intel\')" title="Research & intel">🔍 Intel</button>';
          html += '</div></div>';
        });
        if (clinics.length > DIA_SEARCH_COLLAPSED_LIMIT) {
          if (!isExpanded) {
            html += '<button onclick="_diaSearchExpanded.clinics=true;renderDiaTab()" style="width:100%;padding:8px;margin-top:4px;background:var(--s2);border:1px solid var(--border);border-radius:6px;color:var(--accent);font-size:12px;font-weight:600;cursor:pointer">Show all ' + clinics.length + ' clinics</button>';
          } else {
            html += '<button onclick="_diaSearchExpanded.clinics=false;renderDiaTab()" style="width:100%;padding:8px;margin-top:4px;background:var(--s2);border:1px solid var(--border);border-radius:6px;color:var(--text2);font-size:12px;font-weight:600;cursor:pointer">Collapse</button>';
          }
        }
        html += '</div>';
      }

      if (npiSignals.length > 0) {
        var isExpanded = _diaSearchExpanded.npi || false;
        var visibleNpi = isExpanded ? npiSignals : npiSignals.slice(0, DIA_SEARCH_COLLAPSED_LIMIT);
        html += '<div class="search-results-section" id="dia-search-npi"><h4>NPI Signals (' + npiSignals.length + ')</h4>';
        visibleNpi.forEach(r => {
          var idx = pushDiaRef(r);
          html += '<div class="search-card" onclick="showDetail(window._diaSearchFlat[' + idx + '], \'dia-clinic\')">';
          html += '<div class="search-card-header"><span class="search-card-title">' + esc(norm(r.facility_name) || r.npi || '—') + '</span>';
          html += '<span class="search-card-badge" style="background: rgba(248,113,113,0.15); color: #f87171;">NPI Signal</span></div>';
          html += '<div class="search-card-meta">';
          if (r.city || r.state) html += '<span>' + esc((norm(r.city) || '') + (r.city && r.state ? ', ' : '') + (r.state || '')) + '</span>';
          if (r.signal_type) html += '<span>Signal: ' + esc(cleanLabel(r.signal_type)) + '</span>';
          if (r.npi) html += '<span>NPI: ' + esc(r.npi) + '</span>';
          html += '</div>';
          html += '<div style="display:flex;gap:4px;margin-top:6px" onclick="event.stopPropagation()">';
          html += '<button class="gov-row-action" onclick="showDetail(window._diaSearchFlat[' + idx + '], \'dia-clinic\', \'Ownership\')" title="View owner & contacts">📞 Contacts</button>';
          html += '<button class="gov-row-action accent" onclick="showDetail(window._diaSearchFlat[' + idx + '], \'dia-clinic\', \'Intel\')" title="Research & intel">🔍 Intel</button>';
          html += '</div></div>';
        });
        if (npiSignals.length > DIA_SEARCH_COLLAPSED_LIMIT) {
          if (!isExpanded) {
            html += '<button onclick="_diaSearchExpanded.npi=true;renderDiaTab()" style="width:100%;padding:8px;margin-top:4px;background:var(--s2);border:1px solid var(--border);border-radius:6px;color:var(--accent);font-size:12px;font-weight:600;cursor:pointer">Show all ' + npiSignals.length + ' NPI signals</button>';
          } else {
            html += '<button onclick="_diaSearchExpanded.npi=false;renderDiaTab()" style="width:100%;padding:8px;margin-top:4px;background:var(--s2);border:1px solid var(--border);border-radius:6px;color:var(--text2);font-size:12px;font-weight:600;cursor:pointer">Collapse</button>';
          }
        }
        html += '</div>';
      }

      if (propQueue.length > 0) {
        var isExpanded = _diaSearchExpanded.property || false;
        var visibleProp = isExpanded ? propQueue : propQueue.slice(0, DIA_SEARCH_COLLAPSED_LIMIT);
        html += '<div class="search-results-section" id="dia-search-property"><h4>Property Review Queue (' + propQueue.length + ')</h4>';
        visibleProp.forEach(r => {
          var idx = pushDiaRef(r);
          html += '<div class="search-card" onclick="showDetail(window._diaSearchFlat[' + idx + '], \'dia-clinic\')">';
          html += '<div class="search-card-header"><span class="search-card-title">' + esc(norm(r.facility_name) || r.clinic_id || '—') + '</span>';
          html += '<span class="search-card-badge" style="background: rgba(251,191,36,0.15); color: #fbbf24;">Property</span></div>';
          html += '<div class="search-card-meta">';
          if (r.state) html += '<span>' + esc(r.state) + '</span>';
          if (r.operator_name) html += '<span>Op: ' + esc(norm(r.operator_name)) + '</span>';
          if (r.review_type) html += '<span>Review: ' + esc(cleanLabel(r.review_type)) + '</span>';
          html += '</div>';
          html += '<div style="display:flex;gap:4px;margin-top:6px" onclick="event.stopPropagation()">';
          html += '<button class="gov-row-action" onclick="showDetail(window._diaSearchFlat[' + idx + '], \'dia-clinic\', \'Ownership\')" title="View owner & contacts">📞 Contacts</button>';
          html += '<button class="gov-row-action accent" onclick="showDetail(window._diaSearchFlat[' + idx + '], \'dia-clinic\', \'Intel\')" title="Research & intel">🔍 Intel</button>';
          html += '</div></div>';
        });
        if (propQueue.length > DIA_SEARCH_COLLAPSED_LIMIT) {
          if (!isExpanded) {
            html += '<button onclick="_diaSearchExpanded.property=true;renderDiaTab()" style="width:100%;padding:8px;margin-top:4px;background:var(--s2);border:1px solid var(--border);border-radius:6px;color:var(--accent);font-size:12px;font-weight:600;cursor:pointer">Show all ' + propQueue.length + ' properties</button>';
          } else {
            html += '<button onclick="_diaSearchExpanded.property=false;renderDiaTab()" style="width:100%;padding:8px;margin-top:4px;background:var(--s2);border:1px solid var(--border);border-radius:6px;color:var(--text2);font-size:12px;font-weight:600;cursor:pointer">Collapse</button>';
          }
        }
        html += '</div>';
      }

      if (outcomes.length > 0) {
        var isExpanded = _diaSearchExpanded.outcomes || false;
        var visibleOutcomes = isExpanded ? outcomes : outcomes.slice(0, DIA_SEARCH_COLLAPSED_LIMIT);
        html += '<div class="search-results-section" id="dia-search-outcomes"><h4>Research Outcomes (' + outcomes.length + ')</h4>';
        visibleOutcomes.forEach(r => {
          var idx = pushDiaRef(r);
          html += '<div class="search-card" onclick="showDetail(window._diaSearchFlat[' + idx + '], \'dia-clinic\')">';
          html += '<div class="search-card-header"><span class="search-card-title">' + esc(r.queue_type || r.clinic_id || '—') + '</span>';
          html += '<span class="search-card-badge" style="background: rgba(52,211,153,0.15); color: #34d399;">Research</span></div>';
          html += '<div class="search-card-meta">';
          if (r.status) html += '<span>Status: ' + esc(r.status) + '</span>';
          if (r.queue_type) html += '<span>Type: ' + esc(r.queue_type) + '</span>';
          if (r.source_bucket) html += '<span>Source: ' + esc(r.source_bucket) + '</span>';
          html += '</div>';
          html += '<div style="display:flex;gap:4px;margin-top:6px" onclick="event.stopPropagation()">';
          html += '<button class="gov-row-action" onclick="showDetail(window._diaSearchFlat[' + idx + '], \'dia-clinic\', \'Ownership\')" title="View owner & contacts">📞 Contacts</button>';
          html += '<button class="gov-row-action accent" onclick="showDetail(window._diaSearchFlat[' + idx + '], \'dia-clinic\', \'Intel\')" title="Research & intel">🔍 Intel</button>';
          html += '</div></div>';
        });
        if (outcomes.length > DIA_SEARCH_COLLAPSED_LIMIT) {
          if (!isExpanded) {
            html += '<button onclick="_diaSearchExpanded.outcomes=true;renderDiaTab()" style="width:100%;padding:8px;margin-top:4px;background:var(--s2);border:1px solid var(--border);border-radius:6px;color:var(--accent);font-size:12px;font-weight:600;cursor:pointer">Show all ' + outcomes.length + ' outcomes</button>';
          } else {
            html += '<button onclick="_diaSearchExpanded.outcomes=false;renderDiaTab()" style="width:100%;padding:8px;margin-top:4px;background:var(--s2);border:1px solid var(--border);border-radius:6px;color:var(--text2);font-size:12px;font-weight:600;cursor:pointer">Collapse</button>';
          }
        }
        html += '</div>';
      }
    }
  }

  html += '</div>';

  setTimeout(() => {
    const input = document.getElementById('diaSearchInput');
    if (input) {
      input.onkeydown = e => { if (e.key === 'Enter') execDiaSearch(); };
      input.focus();
    }
  }, 0);

  return html;
}

async function execDiaSearch() {
  const input = document.getElementById('diaSearchInput');
  if (!input) return;
  const term = input.value.trim();
  if (!term) return;

  const searchBtn = document.querySelector('[onclick*="execDiaSearch"]');
  if (searchBtn) { searchBtn.disabled = true; searchBtn.textContent = 'Searching\u2026'; searchBtn.style.opacity = '0.6'; }

  diaSearchTerm = term;
  diaSearching = true;
  _diaSearchExpanded = {}; // Reset expansion state on new search
  renderDiaTab();

  // Sanitize for PostgREST ilike filter — strip syntax-breaking characters
  const safeTerm = term.replace(/[*()',\\]/g, '');
  if (!safeTerm) { diaSearching = false; renderDiaTab(); return; }
  const like = '*' + safeTerm + '*';
  try {
    const [clinics, npiSignals, propQueue, outcomes] = await Promise.all([
      diaQuery('v_clinic_inventory_latest_diff', '*', { filter: 'or(facility_name.ilike.' + like + ',city.ilike.' + like + ',state.ilike.' + like + ',operator_name.ilike.' + like + ',address.ilike.' + like + ')', limit: 100 }).catch(e => { console.warn('[DiaSearch] clinic inventory query failed:', e.message); return []; }),
      diaQuery('v_npi_inventory_signals', '*', { filter: 'or(facility_name.ilike.' + like + ',city.ilike.' + like + ',state.ilike.' + like + ',npi.ilike.' + like + ',operator_name.ilike.' + like + ')', limit: 50 }).catch(e => { console.warn('[DiaSearch] NPI signals query failed:', e.message); return []; }),
      diaQuery('v_clinic_property_link_review_queue', '*', { filter: 'or(facility_name.ilike.' + like + ',operator_name.ilike.' + like + ',state.ilike.' + like + ')', limit: 50 }).catch(e => { console.warn('[DiaSearch] property queue query failed:', e.message); return []; }),
      diaQuery('research_queue_outcomes', '*', { filter: 'or(queue_type.ilike.' + like + ',status.ilike.' + like + ',notes.ilike.' + like + ')', limit: 50 }).catch(e => { console.warn('[DiaSearch] outcomes query failed:', e.message); return []; })
    ]);

    diaSearchResults = {
      clinics: clinics || [],
      npiSignals: npiSignals || [],
      propQueue: propQueue || [],
      outcomes: outcomes || []
    };
  } catch (err) {
    console.error('Dia search error:', err);
    diaSearchResults = { clinics: [], npiSignals: [], propQueue: [], outcomes: [] };
    showToast('Search failed: ' + err.message, 'error');
  }

  diaSearching = false;
  if (searchBtn) { searchBtn.disabled = false; searchBtn.textContent = 'Search'; searchBtn.style.opacity = ''; }
  renderDiaTab();
}

// ============================================================================
// EXPORTS
// ============================================================================

window.renderDiaTab = renderDiaTab;
window.renderDiaOverview = renderDiaOverview;
// ============================================================================
// SALES COMP DETAIL/EDIT PANEL
// ============================================================================

async function diaPatchRecord(table, idCol, idVal, data) {
  // Route through closed-loop mutation service with fallback to direct PATCH
  try {
    const result = await applyChangeWithFallback({
      proxyBase: '/api/dia-query',
      table,
      idColumn: idCol,
      idValue: idVal,
      data,
      source_surface: 'dia_workspace'
    });

    if (!result.ok) {
      console.error('diaPatchRecord error [' + table + '.' + idCol + '=' + idVal + ']:', (result.errors || []).join(', '));
      showToast('Error saving ' + table + ': ' + ((result.errors || [])[0] || 'unknown error'), 'error');
      return false;
    }

    return true;
  } catch (err) {
    console.error('diaPatchRecord error [' + table + '.' + idCol + '=' + idVal + ']:', err);
    showToast('Error saving ' + table + ': ' + (err.message || 'unknown error'), 'error');
    return false;
  }
}

async function showSaleDetail(record) {
  if (!record || !record.sale_id) {
    showToast('Unable to open sale detail', 'error');
    return;
  }

  // Store in window for detail panel
  window._saleRecord = record;
  window._saleCurrentTab = 'deal';

  const overlay = q('#detailOverlay');
  const panel = q('#detailPanel');
  const header = q('#detailHeader');
  const tabsContainer = q('#detailTabs');
  const body = q('#detailBody');

  if (!panel || !header || !tabsContainer || !body) return;

  // Show panel
  if (overlay) { overlay.classList.add('open'); overlay.style.display = ''; }
  panel.style.display = 'flex';

  // Render header
  const title = esc(record.tenant_operator || 'Sale Comp');
  const subtitle = esc(`${record.address || ''}, ${record.city || ''}, ${record.state || ''}`);
  const salePrice = record.price ? '$' + Number(record.price).toLocaleString('en-US', { maximumFractionDigits: 0 }) : 'N/A';

  header.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; padding: 16px; border-bottom: 1px solid var(--border);">
      <div>
        <h2 style="margin: 0; color: var(--text); font-size: 18px; font-weight: 600;">${title}</h2>
        <p style="margin: 4px 0 0 0; color: var(--text2); font-size: 13px;">${subtitle}</p>
      </div>
      <div style="display: flex; gap: 8px; align-items: center;">
        <span style="color: var(--accent); font-weight: 600; font-size: 14px;">${salePrice}</span>
        <button onclick="closeSaleDetail()" style="background: none; border: none; color: var(--text2); font-size: 24px; cursor: pointer; padding: 0; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;">&times;</button>
      </div>
    </div>
  `;

  // Render tabs
  const tabs = ['Deal', 'Property', 'Ownership', 'Research'];
  let tabsHtml = '<div style="display: flex; border-bottom: 1px solid var(--border); gap: 0;">';
  tabs.forEach(tab => {
    const isActive = window._saleCurrentTab === tab.toLowerCase();
    const style = isActive
      ? 'color: var(--accent); border-bottom: 2px solid var(--accent); background: rgba(var(--accent-rgb), 0.1);'
      : 'color: var(--text2); border-bottom: 2px solid transparent;';
    tabsHtml += `<button onclick="switchSaleTab('${tab.toLowerCase()}')" style="flex: 1; padding: 12px; background: none; border: none; cursor: pointer; font-weight: 600; font-size: 13px; text-transform: uppercase; letter-spacing: 0.3px; ${style}">${tab}</button>`;
  });
  tabsHtml += '</div>';
  tabsContainer.innerHTML = tabsHtml;

  // Render body based on current tab
  renderSaleDetailBody(record);
}

function switchSaleTab(tab) {
  window._saleCurrentTab = tab;
  const record = window._saleRecord;
  if (record) renderSaleDetailBody(record);

  // Update active tab style
  document.querySelectorAll('#detailTabs button').forEach(btn => {
    const btnTab = btn.textContent.trim().toLowerCase();
    if (btnTab === tab) {
      btn.style.color = 'var(--accent)';
      btn.style.borderBottomColor = 'var(--accent)';
      btn.style.background = 'rgba(var(--accent-rgb), 0.1)';
    } else {
      btn.style.color = 'var(--text2)';
      btn.style.borderBottomColor = 'transparent';
      btn.style.background = 'none';
    }
  });
}

async function renderSaleDetailBody(record) {
  const body = q('#detailBody');
  if (!body) return;

  let html = '';
  try {
    if (window._saleCurrentTab === 'deal') {
      html = renderSaleDealTab(record);
    } else if (window._saleCurrentTab === 'property') {
      html = renderSalePropertyTab(record);
    } else if (window._saleCurrentTab === 'ownership') {
      html = await renderSaleOwnershipTab(record);
    } else if (window._saleCurrentTab === 'research') {
      html = renderSaleResearchTab(record);
    }
  } catch (err) {
    console.error('renderSaleDetailBody error:', err);
    html = '<div style="padding:20px;color:var(--red);font-size:13px">Failed to load tab content.</div>';
  }

  body.innerHTML = html;
}

function renderSaleDealTab(record) {
  const lblStyle = 'display:block;color:var(--text2);font-size:12px;margin-bottom:6px;font-weight:600;';
  const inpStyle = 'width:100%;padding:8px;background:var(--s2);color:var(--text);border:1px solid var(--border);border-radius:4px;box-sizing:border-box;font-family:inherit;font-size:13px;';
  const gridStyle = 'display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;';

  let html = '<div style="padding: 16px; overflow-y: auto; max-height: calc(100% - 100px);">';

  // Transaction Details section
  html += '<div style="margin-bottom: 24px;">';
  html += '<h3 style="color: var(--text); font-size: 14px; font-weight: 600; margin: 0 0 16px 0; text-transform: uppercase; letter-spacing: 0.3px; color: var(--accent);">Transaction Details</h3>';
  
  html += '<div style="' + gridStyle + '">';
  html += '<div>';
  html += '<label style="' + lblStyle + '">Buyer Name</label>';
  html += '<input type="text" id="dia-buyer-name" value="' + esc(record.buyer_name || '') + '" placeholder="Buyer name" style="' + inpStyle + '" />';
  html += '</div>';
  
  html += '<div>';
  html += '<label style="' + lblStyle + '">Buyer Type</label>';
  html += '<select id="dia-buyer-type" style="' + inpStyle + '">';
  html += '<option value=""' + (record.buyer_type ? '' : ' selected') + '>Select type</option>';
  const buyerTypes = ['Individual', 'Private Equity', 'REIT', 'Strategic Buyer', 'Other'];
  buyerTypes.forEach(t => {
    html += '<option value="' + esc(t) + '"' + (record.buyer_type === t ? ' selected' : '') + '>' + esc(t) + '</option>';
  });
  html += '</select>';
  html += '</div>';
  
  html += '<div>';
  html += '<label style="' + lblStyle + '">Seller Name</label>';
  html += '<input type="text" id="dia-seller-name" value="' + esc(record.seller_name || '') + '" placeholder="Seller name" style="' + inpStyle + '" />';
  html += '</div>';
  
  html += '<div>';
  html += '<label style="' + lblStyle + '">Sold Price</label>';
  html += '<input type="number" id="dia-sold-price" value="' + (record.sold_price || '') + '" placeholder="0" style="' + inpStyle + '" />';
  html += '</div>';
  
  html += '<div>';
  html += '<label style="' + lblStyle + '">Cap Rate (%)</label>';
  html += '<input type="number" id="dia-cap-rate" value="' + ((record.cap_rate && record.cap_rate < 1) ? (record.cap_rate * 100).toFixed(2) : (record.cap_rate || '')) + '" placeholder="0.00" step="0.01" style="' + inpStyle + '" />';
  html += '</div>';
  
  html += '<div>';
  html += '<label style="' + lblStyle + '">Sale Date</label>';
  html += '<input type="date" id="dia-sale-date" value="' + (record.sale_date || '') + '" style="' + inpStyle + '" />';
  html += '</div>';
  
  html += '<div>';
  html += '<label style="' + lblStyle + '">Cap Rate Method</label>';
  html += '<select id="dia-cap-rate-method" style="' + inpStyle + '">';
  html += '<option value=""' + (record.cap_rate_method ? '' : ' selected') + '>Select method</option>';
  const methods = ['NOI / Purchase Price', 'Operating Expense Analysis', 'Market Comparable', 'Other'];
  methods.forEach(m => {
    html += '<option value="' + esc(m) + '"' + (record.cap_rate_method === m ? ' selected' : '') + '>' + esc(m) + '</option>';
  });
  html += '</select>';
  html += '</div>';
  
  html += '</div>';
  
  html += '<div>';
  html += '<label style="' + lblStyle + '">Cap Rate Notes</label>';
  html += '<textarea id="dia-cap-rate-notes" placeholder="Notes about cap rate calculation..." style="' + inpStyle + 'min-height:80px;resize:vertical;">' + esc(record.cap_rate_notes || '') + '</textarea>';
  html += '</div>';
  
  html += '<div style="margin-top: 12px;">';
  html += '<label style="' + lblStyle + '">Transaction Notes</label>';
  html += '<textarea id="dia-notes" placeholder="Additional notes..." style="' + inpStyle + 'min-height:80px;resize:vertical;">' + esc(record.notes || '') + '</textarea>';
  html += '</div>';
  
  html += '</div>';

  // Broker Info section
  html += '<div style="margin-bottom: 24px;">';
  html += '<h3 style="color: var(--text); font-size: 14px; font-weight: 600; margin: 0 0 16px 0; text-transform: uppercase; letter-spacing: 0.3px; color: var(--accent);">Broker Info (Read-Only)</h3>';
  
  html += '<div style="' + gridStyle + '">';
  html += '<div>';
  html += '<label style="' + lblStyle + '">Listing Broker</label>';
  html += '<div style="padding:8px;background:var(--s3);color:var(--text3);border:1px solid var(--border);border-radius:4px;font-size:13px;">' + esc(record.listing_broker || '—') + '</div>';
  html += '</div>';
  
  html += '<div>';
  html += '<label style="' + lblStyle + '">Procuring Broker</label>';
  html += '<div style="padding:8px;background:var(--s3);color:var(--text3);border:1px solid var(--border);border-radius:4px;font-size:13px;">' + esc(record.procuring_broker || '—') + '</div>';
  html += '</div>';
  
  html += '</div>';
  html += '</div>';

  // Computed section
  html += '<div style="margin-bottom: 24px;">';
  html += '<h3 style="color: var(--text); font-size: 14px; font-weight: 600; margin: 0 0 16px 0; text-transform: uppercase; letter-spacing: 0.3px; color: var(--accent);">Computed Values (Read-Only)</h3>';
  
  const pricePerSF = record.rba && record.price ? (record.price / record.rba).toFixed(2) : 'N/A';
  const bidAskSpread = record.bid_ask_spread ? Math.round(record.bid_ask_spread) + ' bps' : 'N/A';
  const dom = record.dom ? record.dom + ' days' : 'N/A';
  
  html += '<div style="' + gridStyle + '">';
  html += '<div>';
  html += '<label style="' + lblStyle + '">Price Per SF</label>';
  html += '<div style="padding:8px;background:var(--s3);color:var(--text3);border:1px solid var(--border);border-radius:4px;font-size:13px;">' + esc(pricePerSF) + '</div>';
  html += '</div>';
  
  html += '<div>';
  html += '<label style="' + lblStyle + '">Bid-Ask Spread</label>';
  html += '<div style="padding:8px;background:var(--s3);color:var(--text3);border:1px solid var(--border);border-radius:4px;font-size:13px;">' + esc(bidAskSpread) + '</div>';
  html += '</div>';
  
  html += '<div>';
  html += '<label style="' + lblStyle + '">Days on Market</label>';
  html += '<div style="padding:8px;background:var(--s3);color:var(--text3);border:1px solid var(--border);border-radius:4px;font-size:13px;">' + esc(dom) + '</div>';
  html += '</div>';
  
  html += '</div>';
  html += '</div>';

  // Save button
  html += '<div style="position: sticky; bottom: 0; padding: 12px 16px; border-top: 1px solid var(--border); background: var(--s1);">';
  html += '<button onclick="_udBtnGuard(this, saveSaleTransaction)" style="width: 100%; padding: 10px; background: var(--accent); color: white; border: none; border-radius: 6px; font-weight: 600; font-size: 13px; cursor: pointer;">Save Transaction</button>';
  html += '</div>';

  html += '</div>';
  return html;
}

function renderSalePropertyTab(record) {
  const lblStyle = 'display:block;color:var(--text2);font-size:12px;margin-bottom:6px;font-weight:600;';
  const inpStyle = 'width:100%;padding:8px;background:var(--s2);color:var(--text);border:1px solid var(--border);border-radius:4px;box-sizing:border-box;font-family:inherit;font-size:13px;';
  const gridStyle = 'display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;';

  let html = '<div style="padding: 16px; overflow-y: auto; max-height: calc(100% - 100px);">';
  html += '<h3 style="color: var(--text); font-size: 14px; font-weight: 600; margin: 0 0 16px 0; text-transform: uppercase; letter-spacing: 0.3px; color: var(--accent);">Property Information</h3>';
  
  html += '<div style="' + gridStyle + '">';
  html += '<div>';
  html += '<label style="' + lblStyle + '">Address</label>';
  html += '<input type="text" id="dia-prop-address" value="' + esc(record.address || '') + '" placeholder="Address" style="' + inpStyle + '" />';
  html += '</div>';
  
  html += '<div>';
  html += '<label style="' + lblStyle + '">City</label>';
  html += '<input type="text" id="dia-prop-city" value="' + esc(record.city || '') + '" placeholder="City" style="' + inpStyle + '" />';
  html += '</div>';
  
  html += '<div>';
  html += '<label style="' + lblStyle + '">State</label>';
  html += '<input type="text" id="dia-prop-state" value="' + esc(record.state || '') + '" placeholder="State" maxlength="2" style="' + inpStyle + '" />';
  html += '</div>';
  
  html += '<div>';
  html += '<label style="' + lblStyle + '">Tenant/Operator</label>';
  html += '<input type="text" id="dia-prop-tenant" value="' + esc(record.tenant_operator || '') + '" placeholder="Tenant/Operator" style="' + inpStyle + '" />';
  html += '</div>';
  
  html += '<div>';
  html += '<label style="' + lblStyle + '">Building Size (RBA, SF)</label>';
  html += '<input type="number" id="dia-prop-rba" value="' + (record.rba || '') + '" placeholder="0" style="' + inpStyle + '" />';
  html += '</div>';
  
  html += '<div>';
  html += '<label style="' + lblStyle + '">Land Area (acres)</label>';
  html += '<input type="number" id="dia-prop-land" value="' + (record.land_area || '') + '" placeholder="0" step="0.01" style="' + inpStyle + '" />';
  html += '</div>';
  
  html += '<div>';
  html += '<label style="' + lblStyle + '">Year Built</label>';
  html += '<input type="number" id="dia-prop-year" value="' + (record.year_built || '') + '" placeholder="YYYY" min="1800" max="2100" style="' + inpStyle + '" />';
  html += '</div>';
  
  html += '</div>';

  html += '</div>';

  // Save button
  html += '<div style="position: sticky; bottom: 0; padding: 12px 16px; border-top: 1px solid var(--border); background: var(--s1);">';
  html += '<button onclick="_udBtnGuard(this, saveSaleProperty)" style="width: 100%; padding: 10px; background: var(--accent); color: white; border: none; border-radius: 6px; font-weight: 600; font-size: 13px; cursor: pointer;">Save Property</button>';
  html += '</div>';

  return html;
}

async function renderSaleOwnershipTab(record) {
  const lblStyle = 'display:block;color:var(--text2);font-size:12px;margin-bottom:6px;font-weight:600;';
  const inpStyle = 'width:100%;padding:8px;background:var(--s2);color:var(--text);border:1px solid var(--border);border-radius:4px;box-sizing:border-box;font-family:inherit;font-size:13px;';

  let html = '<div style="padding: 16px; overflow-y: auto; max-height: calc(100% - 60px);">';
  html += '<h3 style="color: var(--text); font-size: 14px; font-weight: 600; margin: 0 0 16px 0; text-transform: uppercase; letter-spacing: 0.3px; color: var(--accent);">Ownership History</h3>';

  let owners = [];
  try {
    // Filter out cms_operator_chain shim rows so this sub-tab doesn't render
    // synthetic operator-presence rows (Fresenius / DaVita / etc.) alongside
    // real deed ownership records. See Layer D migration 20260513120000.
    owners = await diaQuery('ownership_history', '*', {
      filter: `property_id=eq.${record.property_id}`,
      filter2: 'ownership_source=not.eq.cms_operator_chain',
      order: 'start_date.desc',
      limit: 50
    }) || [];
  } catch (e) {
    console.error('Ownership load error:', e);
    showToast('Failed to load ownership history', 'error');
  }

  if (!owners || owners.length === 0) {
    html += '<p style="color: var(--text3); font-size: 13px;">No ownership history records found.</p>';
  } else {
    owners.forEach((owner, idx) => {
      html += '<div style="margin-bottom: 16px; padding: 12px; background: var(--s2); border: 1px solid var(--border); border-radius: 6px;">';
      html += '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px;">';

      html += '<div>';
      html += '<label style="' + lblStyle + '">Owner Type</label>';
      html += '<select id="dia-owner-type-' + idx + '" style="' + inpStyle + '">';
      const ownerTypes = ['Operator', 'Owner', 'Investor', 'Other'];
      ownerTypes.forEach(t => {
        html += '<option value="' + esc(t) + '"' + (owner.owner_type === t ? ' selected' : '') + '>' + esc(t) + '</option>';
      });
      html += '</select>';
      html += '</div>';

      html += '<div>';
      html += '<label style="' + lblStyle + '">Ownership Source</label>';
      html += '<input type="text" id="dia-owner-source-' + idx + '" value="' + esc(owner.ownership_source || '') + '" placeholder="Source" style="' + inpStyle + '" />';
      html += '</div>';

      html += '</div>';

      html += '<div>';
      html += '<label style="' + lblStyle + '">Notes</label>';
      html += '<textarea id="dia-owner-notes-' + idx + '" placeholder="Notes..." style="' + inpStyle + 'min-height:60px;resize:vertical;">' + esc(owner.notes || '') + '</textarea>';
      html += '</div>';

      html += '<button onclick="_udBtnGuard(this, saveSaleOwner, ' + owner.ownership_id + ', ' + idx + ')" style="width: 100%; padding: 8px; margin-top: 8px; background: var(--accent); color: white; border: none; border-radius: 4px; font-weight: 600; font-size: 12px; cursor: pointer;">Save Owner Record</button>';
      html += '</div>';
    });
  }

  html += '</div>';
  return html;
}

function renderSaleResearchTab(record) {
  const lblStyle = 'display:block;color:var(--text2);font-size:12px;margin-bottom:6px;font-weight:600;';
  const inpStyle = 'width:100%;padding:8px;background:var(--s2);color:var(--text);border:1px solid var(--border);border-radius:4px;box-sizing:border-box;font-family:inherit;font-size:13px;';

  let html = '<div style="padding: 16px; overflow-y: auto; max-height: calc(100% - 100px);">';
  html += '<h3 style="color: var(--text); font-size: 14px; font-weight: 600; margin: 0 0 16px 0; text-transform: uppercase; letter-spacing: 0.3px; color: var(--accent);">Research Resolution</h3>';

  html += '<div style="margin-bottom: 16px;">';
  html += '<label style="' + lblStyle + '">Status</label>';
  html += '<select id="dia-research-status" style="' + inpStyle + '">';
  const statuses = ['pending_review', 'verified', 'needs_correction', 'flagged', 'resolved'];
  statuses.forEach(s => {
    html += '<option value="' + esc(s) + '">' + esc(s.replace(/_/g, ' ')) + '</option>';
  });
  html += '</select>';
  html += '</div>';

  html += '<div>';
  html += '<label style="' + lblStyle + '">Research Notes</label>';
  html += '<textarea id="dia-research-notes" placeholder="Notes about this sale comp..." style="' + inpStyle + 'min-height:120px;resize:vertical;"></textarea>';
  html += '</div>';

  html += '</div>';

  // Save button
  html += '<div style="position: sticky; bottom: 0; padding: 12px 16px; border-top: 1px solid var(--border); background: var(--s1);">';
  html += '<button onclick="_udBtnGuard(this, saveSaleResearch)" style="width: 100%; padding: 10px; background: var(--accent); color: white; border: none; border-radius: 6px; font-weight: 600; font-size: 13px; cursor: pointer;">Resolve Research</button>';
  html += '</div>';

  return html;
}

async function saveSaleTransaction() {
  const record = window._saleRecord;
  if (!record || !record.sale_id) return;

  // Quick check: at least one field should have data
  const _anyField = ['#dia-buyer-name','#dia-seller-name','#dia-sold-price','#dia-cap-rate','#dia-sale-date','#dia-notes'].some(s => { const v = q(s)?.value?.trim(); return v && v !== ''; });
  if (!_anyField) { showToast('No changes to save', 'info'); return; }

  const buyer = q('#dia-buyer-name')?.value?.trim() || null;
  const buyerType = q('#dia-buyer-type')?.value?.trim() || null;
  const seller = q('#dia-seller-name')?.value?.trim() || null;
  const price = _pf(q('#dia-sold-price'));
  const capRateVal = parseFloat(q('#dia-cap-rate')?.value);
  const capRate = capRateVal ? capRateVal / 100 : null;
  const saleDate = q('#dia-sale-date')?.value || null;
  const capMethod = q('#dia-cap-rate-method')?.value?.trim() || null;
  const capNotes = q('#dia-cap-rate-notes')?.value?.trim() || null;
  const notes = q('#dia-notes')?.value?.trim() || null;

  const data = {
    buyer_name: buyer || null,
    buyer_type: buyerType || null,
    seller_name: seller || null,
    sold_price: price,
    cap_rate: capRate,
    sale_date: saleDate,
    cap_rate_method: capMethod || null,
    cap_rate_notes: capNotes || null,
    notes: notes || null
  };

  try {
    const success = await diaPatchRecord('sales_transactions', 'sale_id', record.sale_id, data);
    if (success) {
      showToast('Transaction saved successfully', 'success');
      // Update in-memory record
      Object.assign(record, data);
      // Update in array
      if (window.diaSalesComps) {
        const idx = window.diaSalesComps.findIndex(r => r.sale_id === record.sale_id);
        if (idx >= 0) {
          Object.assign(window.diaSalesComps[idx], data);
        }
      }
      canonicalBridge('log_activity', {
        title: 'Sale transaction saved',
        domain: 'dialysis',
        source_system: 'dia',
        external_id: String(record.sale_id),
        user_name: (typeof LCC_USER !== 'undefined' && LCC_USER.display_name) || 'unknown',
        metadata: { sale_id: record.sale_id, buyer: buyer, seller: seller, sold_price: price, sale_date: saleDate }
      });
      // Re-render detail panel to show updated values
      await renderSaleDetailBody(record);
    }
  } catch (err) {
    console.error('Sale transaction save error:', err);
    showToast('Error saving transaction: ' + (err.message || 'unknown error'), 'error');
  }
}

async function saveSaleProperty() {
  const record = window._saleRecord;
  if (!record || !record.property_id) return;

  const _anyField = ['#dia-prop-address','#dia-prop-city','#dia-prop-state','#dia-prop-tenant','#dia-prop-rba','#dia-prop-land','#dia-prop-year'].some(s => { const v = q(s)?.value?.trim(); return v && v !== ''; });
  if (!_anyField) { showToast('No changes to save', 'info'); return; }

  const address = q('#dia-prop-address')?.value?.trim() || null;
  const city = q('#dia-prop-city')?.value?.trim() || null;
  const state = q('#dia-prop-state')?.value?.trim() || null;
  const tenant = q('#dia-prop-tenant')?.value?.trim() || null;
  const rba = _pf(q('#dia-prop-rba'));
  const land = _pf(q('#dia-prop-land'));
  const year = _py(q('#dia-prop-year'));

  const data = {
    address: address || null,
    city: city || null,
    state: state || null,
    tenant: tenant || null,
    building_size: rba,
    land_area: land,
    year_built: year
  };

  try {
    const success = await diaPatchRecord('properties', 'property_id', record.property_id, data);
    if (success) {
      showToast('Property saved successfully', 'success');
      Object.assign(record, data);
      if (window.diaSalesComps) {
        const idx = window.diaSalesComps.findIndex(r => r.property_id === record.property_id);
        if (idx >= 0) {
          Object.assign(window.diaSalesComps[idx], data);
        }
      }
      canonicalBridge('log_activity', {
        title: 'Sale property updated',
        domain: 'dialysis',
        source_system: 'dia',
        external_id: String(record.property_id),
        user_name: (typeof LCC_USER !== 'undefined' && LCC_USER.display_name) || 'unknown',
        property_name: address || null,
        metadata: { property_id: record.property_id, address: address, city: city, state: state, tenant: tenant }
      });
      // Re-render detail panel to show updated values
      await renderSaleDetailBody(record);
    }
  } catch (err) {
    console.error('Sale property save error:', err);
    showToast('Error saving property: ' + (err.message || 'unknown error'), 'error');
  }
}

async function saveSaleOwner(ownershipId, idx) {
  const ownerType = q('#dia-owner-type-' + idx)?.value?.trim() || null;
  const ownerSource = q('#dia-owner-source-' + idx)?.value?.trim() || null;
  const notes = q('#dia-owner-notes-' + idx)?.value?.trim() || null;

  const data = {
    owner_type: ownerType || null,
    ownership_source: ownerSource || null,
    notes: notes || null
  };

  if (!ownerType && !ownerSource && !notes) { showToast('No changes to save', 'info'); return; }

  const success = await diaPatchRecord('ownership_history', 'ownership_id', ownershipId, data);
  if (success) {
    showToast('Owner record saved successfully', 'success');
    canonicalBridge('save_ownership', {
      domain: 'dialysis',
      source_system: 'dia',
      external_id: String(ownershipId),
      user_name: (typeof LCC_USER !== 'undefined' && LCC_USER.display_name) || 'unknown',
      owner_type: ownerType,
      metadata: { ownership_id: ownershipId, owner_type: ownerType, ownership_source: ownerSource, notes: notes }
    });
  }
}

async function saveSaleResearch() {
  const record = window._saleRecord;
  if (!record || !record.sale_id) return;

  const status = q('#dia-research-status')?.value?.trim() || null;
  const notes = q('#dia-research-notes')?.value?.trim() || null;

  if (!status) {
    showToast('Please select a status', 'error');
    return;
  }

  if (!record.clinic_id) {
    showToast('No clinic linked to this sale — cannot save research outcome', 'error');
    return;
  }

  // Create or update research_queue_outcomes record
  try {
    const data = {
      queue_type: 'sales_comp',
      clinic_id: record.clinic_id,
      status: status,
      notes: notes || null,
      selected_property_id: record.property_id || null
    };

    const result = await applyInsertWithFallback({
      proxyBase: '/api/dia-query',
      table: 'research_queue_outcomes',
      idColumn: 'clinic_id',
      recordIdentifier: record.clinic_id,
      data,
      source_surface: 'dialysis_sales_detail',
      propagation_scope: 'research_queue_outcome'
    });

    if (!result.ok) {
      const errorMsg = result.errors && result.errors.length > 0 ? result.errors[0] : 'unknown error';
      console.error('Research save error:', result.errors || []);
      showToast('Error saving research: ' + errorMsg, 'error');
      return;
    }

    showToast('Research resolution saved', 'success');
    canonicalBridge('complete_research', {
      domain: 'dialysis',
      research_type: 'entity_enrichment',
      source_system: 'dia',
      external_id: String(record.clinic_id),
      source_type: 'clinic',
      outcome: status || 'completed',
      notes: notes,
      source_record_id: String(record.clinic_id),
      source_table: 'research_queue_outcomes',
      title: record.facility_name || record.address || `Clinic ${record.clinic_id}`,
      entity_fields: {
        name: record.facility_name || record.address || `Clinic ${record.clinic_id}`,
        address: record.address || null,
        city: record.city || null,
        state: record.state || null,
        asset_type: 'dialysis_clinic'
      },
      metadata: { queue_type: 'sales_comp', clinic_id: record.clinic_id, status: status, property_id: record.property_id }
    });
  } catch (err) {
    console.error('saveSaleResearch error:', err);
    showToast('Error saving research: ' + (err.message || 'unknown error'), 'error');
  }
}

function closeSaleDetail() {
  // Check for unsaved changes
  const body = document.getElementById('detailBody');
  if (body) {
    const inputs = body.querySelectorAll('input, select, textarea');
    const hasDirty = Array.from(inputs).some(function(inp) {
      if (inp.tagName === 'SELECT') return false; // selects don't track defaultValue well
      return inp.value !== (inp.defaultValue || '');
    });
    if (hasDirty) {
      lccConfirm('You have unsaved changes. Close anyway?', 'Close').then(function(ok) {
        if (ok) _closeSaleDetailInner();
      });
      return;
    }
  }
  _closeSaleDetailInner();
}

function _closeSaleDetailInner() {
  window._saleRecord = null;
  window._saleCurrentTab = null;
  const overlay = q('#detailOverlay');
  const panel = q('#detailPanel');
  if (overlay) { overlay.classList.remove('open'); overlay.style.display = ''; }
  if (panel) panel.style.display = 'none';
  q('#detailHeader').innerHTML = '';
  q('#detailTabs').innerHTML = '';
  q('#detailBody').innerHTML = '';
}

/**
 * Property Resolution Component Handlers
 */
window.propResDoSearch = async function(sourceTable, sourceIdCol, sourceIdVal) {
  const query = document.getElementById('propResSearch')?.value?.trim();
  if (!query || query.length < 2) { showToast('Enter at least 2 characters', 'info'); return; }
  const resultsDiv = document.getElementById('propResResults');
  if (!resultsDiv) return;
  resultsDiv.innerHTML = '<div style="padding:4px;font-size:11px;color:var(--text2);">Searching...</div>';

  try {
    const safeQ = query.replace(/[*()',\\]/g, '');
    const props = await diaQuery('properties', 'property_id,address,city,state,property_name', {
      filter: `or(address.ilike.*${safeQ}*,property_name.ilike.*${safeQ}*)`,
      limit: 10
    });
    if (!props || props.length === 0) {
      resultsDiv.innerHTML = '<div style="padding:4px;font-size:11px;color:var(--text2);">No properties found</div>';
      return;
    }
    resultsDiv.innerHTML = props.map(p =>
      `<div onclick="propResLink('${sourceTable}','${sourceIdCol}',${sourceIdVal},${p.property_id})" style="padding:6px 8px;font-size:11px;border-bottom:1px solid var(--border);cursor:pointer;display:flex;justify-content:space-between;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">
        <span>${esc(p.address || p.property_name || 'Unknown')}</span>
        <span style="color:var(--text2);">${esc((p.city || '') + (p.state ? ', ' + p.state : ''))}</span>
      </div>`
    ).join('');
  } catch (e) {
    resultsDiv.innerHTML = '<div style="padding:4px;font-size:11px;color:var(--error);">Search failed</div>';
  }
};

window.propResLink = async function(sourceTable, sourceIdCol, sourceIdVal, propertyId) {
  if (!(await lccConfirm('Link this record to Property #' + propertyId + '?', 'Link'))) return;
  const ok = await diaPatchRecord(sourceTable, sourceIdCol, sourceIdVal, { property_id: propertyId });
  if (ok) {
    showToast('Property linked successfully!', 'success');
    renderDiaTab();
  }
};

window.propResShowCreate = function(sourceTable, sourceIdCol, sourceIdVal) {
  const form = document.getElementById('propResCreateForm');
  if (!form) return;
  form.style.display = form.style.display === 'none' ? 'block' : 'none';
  form.innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:8px;">
      <input type="text" id="propNewAddr" placeholder="Address *" style="padding:5px 8px;font-size:11px;border:1px solid var(--border);border-radius:4px;background:var(--bg);color:var(--text);">
      <input type="text" id="propNewName" placeholder="Property Name" style="padding:5px 8px;font-size:11px;border:1px solid var(--border);border-radius:4px;background:var(--bg);color:var(--text);">
      <input type="text" id="propNewCity" placeholder="City *" style="padding:5px 8px;font-size:11px;border:1px solid var(--border);border-radius:4px;background:var(--bg);color:var(--text);">
      <input type="text" id="propNewState" placeholder="State *" style="padding:5px 8px;font-size:11px;border:1px solid var(--border);border-radius:4px;background:var(--bg);color:var(--text);">
    </div>
    <button onclick="propResCreate('${sourceTable}','${sourceIdCol}',${sourceIdVal})" style="padding:5px 12px;font-size:11px;background:var(--success);color:#fff;border:none;border-radius:4px;cursor:pointer;">Create & Link</button>
  `;
};

window.propResCreate = async function(sourceTable, sourceIdCol, sourceIdVal) {
  const addr = document.getElementById('propNewAddr')?.value?.trim();
  const city = document.getElementById('propNewCity')?.value?.trim();
  const state = document.getElementById('propNewState')?.value?.trim();
  const name = document.getElementById('propNewName')?.value?.trim();
  if (!addr || !city || !state) { showToast('Address, city, and state are required', 'error'); return; }

  const btn = event.target;
  if (btn) { btn.disabled = true; btn.textContent = 'Creating...'; }

  try {
    const result = await applyInsertWithFallback({
      proxyBase: '/api/dia-query',
      table: 'properties',
      data: { address: addr, city: city, state: state, property_name: name || addr },
      source_surface: 'dia_research_prop_create'
    });
    if (result && result.ok && result.data && result.data[0]) {
      const newId = result.data[0].property_id;
      const linkOk = await diaPatchRecord(sourceTable, sourceIdCol, sourceIdVal, { property_id: newId });
      if (linkOk) {
        showToast('Property created (#' + newId + ') and linked!', 'success');
        renderDiaTab();
      }
    } else {
      showToast('Failed to create property', 'error');
    }
  } catch (e) {
    showToast('Error creating property: ' + e.message, 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Create & Link'; }
  }
};

window.renderDiaChanges = renderDiaChanges;
window.renderDiaInventoryChanges = renderDiaInventoryChanges;
window.renderDiaNpi = renderDiaNpi;
window.renderDiaResearch = renderDiaResearch;
window.renderDiaActivity = renderDiaActivity;
window.renderDiaDetailBody = renderDiaDetailBody;
window.saveDiaDetailResearch = saveDiaDetailResearch;
window.renderDiaSearch = renderDiaSearch;
window.execDiaSearch = execDiaSearch;
window._diaSearchExpanded = _diaSearchExpanded;
window.renderDiaProperties = renderDiaProperties;
window.renderDiaSales = renderDiaSales;
window.renderDiaPlayers = renderDiaPlayers;
window.renderDiaLeases = renderDiaLeases;
window.renderDiaLoans = renderDiaLoans;
window.goToDiaTab = goToDiaTab;
window.infoCard = infoCard;

// QA-25 (2026-05-18): show top unprospected owners modal. Opens when user
// clicks the reframed "Unprospected Owners" card on the dia home dashboard.
// Data was prefetched by the ownership-coverage block and stashed at
// window._diaTopUnprospected (rows from v_prospect_targets).
window._diaShowProspectTargets = function() {
  const rows = window._diaTopUnprospected || [];
  // QA-29 (2026-05-18): footer uses the true total (not rows.length, which
  // is capped at the query limit). Falls back to rows.length if total isn't
  // stashed.
  const trueTotal = window._diaUnprospectedTotal || rows.length;
  if (!rows.length) {
    alert('Loading prospect targets — try again in a moment.');
    return;
  }
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let modal = document.getElementById('diaProspectModal');
  if (modal) modal.remove();
  modal = document.createElement('div');
  modal.id = 'diaProspectModal';
  modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.65);z-index:9999;display:flex;align-items:center;justify-content:center;padding:24px';
  modal.onclick = (e) => { if (e.target === modal) modal.remove(); };
  const top = rows.slice(0, 100);
  const tableRows = top.map((r, i) => `
    <tr style="border-bottom:1px solid var(--border)">
      <td style="padding:8px 10px;color:var(--text3);font-variant-numeric:tabular-nums">${i + 1}</td>
      <td style="padding:8px 10px;font-weight:600">${esc(r.name || '(unnamed)')}</td>
      <td style="padding:8px 10px;text-align:right;font-variant-numeric:tabular-nums;color:#6c8cff;font-weight:700">${r.prop_count || 0}</td>
      <td style="padding:8px 10px;color:var(--text2)">${esc(r.state || '—')}</td>
      <td style="padding:8px 10px;color:var(--text3);font-size:11px">${r.prospecting_status ? esc(r.prospecting_status) : (r.last_contact_date ? 'last contact ' + esc(String(r.last_contact_date).slice(0,10)) : 'never contacted')}</td>
    </tr>`).join('');
  modal.innerHTML = `
    <div style="background:var(--s1);border:1px solid var(--border);border-radius:14px;max-width:900px;width:100%;max-height:85vh;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 24px 80px rgba(0,0,0,0.5)">
      <div style="padding:18px 24px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;background:var(--s2)">
        <div>
          <div style="font-size:18px;font-weight:800;color:var(--text1)">Unprospected Owners — Top BD Targets</div>
          <div style="font-size:12px;color:var(--text2);margin-top:4px">Owners with property holdings but no SF account link. Ordered by property count.</div>
        </div>
        <button onclick="document.getElementById('diaProspectModal').remove()" style="background:transparent;border:1px solid var(--border);color:var(--text1);padding:8px 14px;border-radius:8px;cursor:pointer;font-size:13px">Close</button>
      </div>
      <div style="overflow-y:auto;flex:1">
        <table style="width:100%;border-collapse:collapse;font-size:13px">
          <thead style="position:sticky;top:0;background:var(--s2);z-index:1">
            <tr style="border-bottom:2px solid var(--border)">
              <th style="padding:10px;text-align:left;font-size:10px;text-transform:uppercase;color:var(--text3);letter-spacing:0.6px">#</th>
              <th style="padding:10px;text-align:left;font-size:10px;text-transform:uppercase;color:var(--text3);letter-spacing:0.6px">Owner</th>
              <th style="padding:10px;text-align:right;font-size:10px;text-transform:uppercase;color:var(--text3);letter-spacing:0.6px">Properties</th>
              <th style="padding:10px;text-align:left;font-size:10px;text-transform:uppercase;color:var(--text3);letter-spacing:0.6px">State</th>
              <th style="padding:10px;text-align:left;font-size:10px;text-transform:uppercase;color:var(--text3);letter-spacing:0.6px">Status</th>
            </tr>
          </thead>
          <tbody>${tableRows}</tbody>
        </table>
      </div>
      <div style="padding:12px 24px;border-top:1px solid var(--border);font-size:11px;color:var(--text3);background:var(--s2)">Showing top ${top.length} of ${trueTotal} unprospected owners${rows.length < trueTotal ? ' (' + rows.length + ' fetched)' : ''}. To add an owner to your SF prospecting list, look them up in Salesforce and link the account ID via the owner detail panel.</div>
    </div>`;
  document.body.appendChild(modal);
};
window.showSaleDetail = showSaleDetail;
window.openDiaSaleOrProperty = function(record) {
  // If the sale comp has a property_id, open the full property sidebar
  if (record && record.property_id) {
    openUnifiedDetail('dialysis', { property_id: record.property_id }, record, 'sales');
  } else {
    // Fallback to the dedicated sale detail form
    showSaleDetail(record);
  }
};
window.switchSaleTab = switchSaleTab;
window.saveSaleTransaction = saveSaleTransaction;
window.saveSaleProperty = saveSaleProperty;
window.saveSaleOwner = saveSaleOwner;
window.saveSaleResearch = saveSaleResearch;
window.closeSaleDetail = closeSaleDetail;
window.renderDiaClinicLeads = renderDiaClinicLeads;
window.saveClinicLeadResearch = saveClinicLeadResearch;
window.markClinicLead = markClinicLead;
window.saveDiaOwnershipResolution = saveDiaOwnershipResolution;

/**
 * Save ownership resolution from the dialysis-specific detail panel (fallback path).
 * Reads form fields from renderDiaDetailOwnership(), patches ownership_history
 * if a record exists, and logs the resolution to research_queue_outcomes.
 */
async function saveDiaOwnershipResolution() {
  const record = window._detailRecord;
  if (!record) { showToast('No record loaded', 'error'); return; }

  const propertyId = record.property_id;
  if (!propertyId) { showToast('No property ID — cannot save ownership', 'error'); return; }

  const _saveBtn = document.querySelector('[onclick*="saveDiaOwnershipResolution"]');
  if (_saveBtn) { _saveBtn.disabled = true; _saveBtn.textContent = 'Saving\u2026'; _saveBtn.style.opacity = '0.6'; }

  const recordedOwner = q('#dia-own-recorded')?.value?.trim() || null;
  const trueOwner     = q('#dia-own-true')?.value?.trim() || null;
  const ownerType     = q('#dia-own-type')?.value || null;
  const notes         = q('#dia-own-notes')?.value?.trim() || null;

  // If there's an existing ownership record, PATCH it
  if (record.ownership_id) {
    const patchData = {};
    if (ownerType) patchData.owner_type = ownerType;
    if (notes) patchData.notes = notes;
    if (Object.keys(patchData).length > 0) {
      const ok = await diaPatchRecord('ownership_history', 'ownership_id', record.ownership_id, patchData);
      if (!ok) return; // toast already shown by diaPatchRecord
    }
  }

  // Log resolution to research_queue_outcomes
  const clinicId = record.clinic_id || record.medicare_id || null;
  if (clinicId) {
    try {
      const payload = {
        queue_type: 'ownership_resolution',
        clinic_id: clinicId,
        status: 'completed',
        notes: [
          recordedOwner ? 'Recorded Owner: ' + recordedOwner : null,
          trueOwner ? 'True Owner: ' + trueOwner : null,
          ownerType ? 'Type: ' + ownerType : null,
          notes ? 'Notes: ' + notes : null
        ].filter(Boolean).join(' | '),
        selected_property_id: propertyId,
        assigned_at: new Date().toISOString()
      };
      const result = await applyInsertWithFallback({
        proxyBase: '/api/dia-query',
        table: 'research_queue_outcomes',
        idColumn: 'clinic_id',
        recordIdentifier: clinicId,
        data: payload,
        source_surface: 'dialysis_ownership_detail',
        propagation_scope: 'research_queue_outcome'
      });
      if (!result.ok) {
        console.error('Ownership resolution save error:', result.errors || []);
        showToast('Ownership outcome log failed — resolution may be incomplete', 'error');
        if (_saveBtn) { _saveBtn.disabled = false; _saveBtn.textContent = 'Save Ownership'; _saveBtn.style.opacity = ''; }
        return;
      }
    } catch (e) {
      console.error('Ownership resolution POST error:', e);
      showToast('Save error: ' + e.message, 'error');
      if (_saveBtn) { _saveBtn.disabled = false; _saveBtn.textContent = 'Save Ownership'; _saveBtn.style.opacity = ''; }
      return;
    }
  }

  if (_saveBtn) { _saveBtn.disabled = false; _saveBtn.textContent = 'Save Ownership'; _saveBtn.style.opacity = ''; }
  showToast('Ownership resolution saved!', 'success');
  canonicalBridge('save_ownership', {
    domain: 'dialysis',
    source_system: 'dia',
    external_id: String(propertyId),
    user_name: (typeof LCC_USER !== 'undefined' && LCC_USER.display_name) || 'unknown',
    owner_name: recordedOwner,
    true_owner_name: trueOwner,
    owner_type: ownerType,
    metadata: { property_id: propertyId, clinic_id: record.clinic_id || record.medicare_id || null, notes: notes }
  });
}
