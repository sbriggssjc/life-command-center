// ============================================================================
// UNIFIED PROPERTY DETAIL PAGE
// Shared across Gov and Dialysis — fetches from normalized Supabase views
// Loaded after index.html, gov.js, dialysis.js
// ============================================================================

// Cache for the current detail data (avoids re-fetch on tab switch)
let _udCache = null;
// Helper: update the cache and mirror to window so cross-file consumers
// (e.g. renderDiaDetailOwnership in dialysis.js) can read chain/ownership.
function _setUdCache(v) { _udCache = v; window._udCache = v; }
let _udFormDirty = false; // track unsaved form edits for beforeunload guard

// Helper for safe parseFloat: converts empty strings to null instead of NaN
function _dpf(v) { return v && v.trim() ? parseFloat(v) : null; }

// Cap rate display: DB stores decimals (0.07 = 7%). Convert to percentage for display.
// Values > 1 are assumed to already be in percentage form.
function _fmtCapRate(v) {
  if (v == null) return null;
  const n = Number(v);
  if (isNaN(n) || n === 0) return null;
  const pct = n < 1 ? n * 100 : n;
  return pct.toFixed(2) + '%';
}

/**
 * Generic async button guard — disables button during operation, shows "Saving…",
 * re-enables on completion or error. Prevents double-clicks on any async save.
 * Usage: onclick="_udBtnGuard(this, _intelSavePriorSale)"
 */
async function _udBtnGuard(btn, fn, ...args) {
  if (!btn || btn.disabled) return;
  const orig = btn.textContent;
  btn.disabled = true; btn.textContent = 'Saving\u2026'; btn.style.opacity = '0.6';
  try { await fn(...args); _udFormDirty = false; } finally { btn.disabled = false; btn.textContent = orig; btn.style.opacity = ''; }
}

/**
 * Action button guard — same pattern but shows "Working…" instead of "Saving…"
 */
async function _udActionBtnGuard(btn, fn, ...args) {
  if (!btn || btn.disabled) return;
  const orig = btn.textContent;
  btn.disabled = true; btn.textContent = 'Working\u2026'; btn.style.opacity = '0.6';
  try { await fn(...args); } finally { btn.disabled = false; btn.textContent = orig; btn.style.opacity = ''; }
}

// ── beforeunload guard: warn if user navigates away with unsaved edits ──
window.addEventListener('beforeunload', function (e) {
  if (_udFormDirty) { e.preventDefault(); e.returnValue = ''; }
});
// Mark form dirty on input within the detail panel
document.addEventListener('input', function (e) {
  if (e.target.closest('#detailBody')) _udFormDirty = true;
});
let _udAssistantState = {
  ownership: { loading: false, reply: '', error: '' },
  intel: { loading: false, reply: '', error: '' },
};
let _udIntakeState = {
  fileName: '',
  fileType: '',
  notice: '',
  text: '',
  imageDataUrl: '',
  loading: false,
  analysis: '',
  error: '',
};

/**
 * Open the unified detail panel for any property/clinic.
 * @param {'gov'|'dia'} db - which Supabase project to query
 * @param {object} ids - { property_id, lease_number } lookup keys
 * @param {object} fallback - the raw record from the list (shown while loading)
 */
async function openUnifiedDetail(db, ids, fallback, initialTab) {
  // Normalize db aliases - callers may pass 'dialysis' or 'government'
  if (db === 'dialysis') db = 'dia';
  if (db === 'government') db = 'gov';

  _setUdCache(null);
  _opsExtraCache = null; // reset operations extra data for new clinic
  _opsGovCache   = null; // reset gov Operations cache for new property
  _salesCache = null; // reset sales data for new property
  const panel = document.getElementById('detailPanel');
  const overlay = document.getElementById('detailOverlay');
  if (!panel || !overlay) return;

  fallback = fallback || {};  // guard against null/undefined callers

  // Show panel immediately with loading state
  panel.style.display = 'block';
  overlay.classList.add('open');

  // Render loading header from fallback record
  const title = fallback.page_title ||
    fallback.facility_name ||
    fallback.tenant_operator ||
    fallback.agency ||
    fallback.address ||
    fallback.tenant_agency ||
    fallback.lessor_name ||
    '(Loading...)';
  const loc = (fallback.city || '') + (fallback.city && fallback.state ? ', ' : '') + (fallback.state || '');
  // QA-12 (2026-05-18): page_title often embeds the city already
  // ("1200 New Jersey Ave SE – Washington, DC"). Showing the subtitle
  // when the title contains it produces "Washington, DC" twice. Drop
  // the subtitle when it's a substring of the title.
  const locForSubtitle = (loc && title && title.toLowerCase().includes(loc.toLowerCase())) ? '' : loc;

  const headerEl = document.getElementById('detailHeader');
  const tabsEl = document.getElementById('detailTabs');
  const bodyEl = document.getElementById('detailBody');

  if (headerEl) headerEl.innerHTML = `
    <button class="detail-back" onclick="detailBack()">&#x2190;<span>Back</span></button>
    <div class="detail-header-info">
      <div style="flex:1;min-width:0">
        <div class="detail-title">${esc(title)}</div>
        ${locForSubtitle ? `<div class="detail-subtitle">${esc(locForSubtitle)}</div>` : ''}
      </div>
      <button class="detail-action-btn" id="consolidateBtn"
        title="Find duplicate properties + same-tenant clusters"
        onclick="openConsolidateModal('${db}', ${ids.property_id || 'null'})"
        style="background:transparent;border:1px solid var(--border);color:var(--text2);padding:6px 12px;border-radius:6px;font-size:12px;cursor:pointer;margin-right:8px"
        ${ids.property_id ? '' : 'disabled'}>
        🔗 Consolidate
      </button>
      <span class="detail-badge" style="background:${db === 'gov' ? 'var(--gov-green)' : 'var(--purple)'};color:#fff">${db === 'gov' ? 'GOV' : 'DIA'}</span>
    </div>
    <button class="detail-close" onclick="closeDetail()">&times;</button>`;

  // Render tab bar — highlight initialTab if provided, else first tab.
  // Tabs restructured to match broker workflow (2026-04-15).
  // Legacy tab names still resolve to the correct new tab via _udMapLegacyTab().
  // Tab order follows the property-intelligence lifecycle (2026-05-31, UX move #1):
  // identity -> tenancy -> operation -> market activity/value -> OWNERSHIP (the
  // de-anonymization climax + prospecting feed) -> activity. Ownership & CRM moved
  // after Deal History so the user understands the economics before resolving who
  // owns it. Dispatch is a name-keyed switch (_udRenderTab), so order is display-only.
  const tabs = ['Overview', 'Rent Roll', 'Operations', 'Deal History', 'Ownership & CRM', 'Activity Log'];
  const mappedInitialTab = initialTab ? _udMapLegacyTab(initialTab) : null;
  const activeTab = (mappedInitialTab && tabs.includes(mappedInitialTab)) ? mappedInitialTab : tabs[0];
  if (tabsEl) tabsEl.innerHTML = tabs.map(t =>
    `<button class="detail-tab ${t === activeTab ? 'active' : ''}" onclick="switchUnifiedTab(decodeURIComponent('${encodeURIComponent(t)}'))">${esc(t)}</button>`
  ).join('');
  // Store requested initial tab for use after data loads
  window._udInitialTab = activeTab;

  // Client routing (UI Phase 1): mirror the open property+tab into the hash so a
  // reload / pasted deep-link re-opens this exact detail. Loop-guarded (no-op
  // when the router is the one driving this open). Needs a stable property_id;
  // clinic-only opens (no property_id) are not deep-linked this phase.
  if (typeof _routeSetDetailHash === 'function' && ids && ids.property_id) {
    _routeSetDetailHash({ kind: 'prop', db, id: ids.property_id, tab: activeTab });
  }
  // UI Phase 4: reconcile the back-stack so a lateral/drill hop pushes a new
  // level (and the breadcrumb updates immediately). Uses the fallback-derived
  // title as the crumb label; refined to the real title once data loads below.
  if (typeof _detailStackSync === 'function' && ids && ids.property_id) {
    _detailStackSync({ kind: 'prop', db, id: ids.property_id, tab: activeTab }, title);
  }

  // Show spinner in body
  if (bodyEl) bodyEl.innerHTML =
    '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading details...</p></div>';

  // Determine query function
  const qFn = db === 'gov' ? govQuery : diaQuery;
  let propertyId = ids.property_id;
  const leaseNumber = ids.lease_number;

  // For Dialysis clinics without property_id, resolve via medicare_clinics
  const clinicIdent = fallback.clinic_id || fallback.medicare_id || fallback.ccn;
  if (!propertyId && db === 'dia' && (clinicIdent || fallback.npi || fallback.medicare_npi)) {
    try {
      // Try medicare_id first, then NPI
      const lookupField = clinicIdent ? 'medicare_id' : 'npi';
      const lookupVal = clinicIdent || fallback.npi || fallback.medicare_npi;
      const mcRes = await diaQuery('medicare_clinics', 'property_id,medicare_id', {
        filter: `${lookupField}=eq.${encodeURIComponent(lookupVal)}`,
        limit: 1
      });
      const mcArr = Array.isArray(mcRes) ? mcRes : (mcRes?.data || []);
      if (mcArr.length && mcArr[0].property_id) {
        propertyId = mcArr[0].property_id;
      }
      // Backfill clinic_id on fallback so downstream tabs work
      if (mcArr.length && mcArr[0].medicare_id && !fallback.clinic_id) {
        fallback.clinic_id = mcArr[0].medicare_id;
      }
    } catch (e) { console.warn('clinic→property lookup failed', e); }
  }

  // Address-based fallback: if the CMS row had no medicare_clinics back-link
  // (medicare_clinics.property_id is NULL — common for unlinked clinics), try
  // to find the property by address+state. Without this, opening a CMS Data
  // row for an unlinked clinic dead-ended at the fallback panel and the
  // "Link CMS facility" button errored "Property ID not available" because
  // _udCache.property was never populated. See diagnosis on
  // claude/fix-fresenius-record-link-kLjaY.
  if (!propertyId && db === 'dia' && fallback.address && fallback.state) {
    try {
      // ilike for case + minor punctuation differences (CMS = "DRIVE NE",
      // properties = "Dr Ne"). Bound the search to state to avoid
      // cross-state collisions on common street names.
      const addrPattern = String(fallback.address).trim().split(/\s+/).slice(0, 3).join('%');
      const addrRes = await diaQuery('properties', 'property_id', {
        filter: `address=ilike.${encodeURIComponent('%' + addrPattern + '%')}&state=eq.${encodeURIComponent(fallback.state)}`,
        limit: 2
      });
      const addrArr = Array.isArray(addrRes) ? addrRes : (addrRes?.data || []);
      // Only auto-anchor when the address+state is unique. Multiple matches
      // mean we'd need user disambiguation, which is out of scope here.
      if (addrArr.length === 1 && addrArr[0].property_id) {
        propertyId = addrArr[0].property_id;
      }
    } catch (e) { console.warn('clinic→property address fallback failed', e); }
  }

  // Build filter — prefer property_id, fall back to lease_number
  const propFilter = propertyId ? `property_id=eq.${propertyId}` : null;
  const leaseFilter = leaseNumber ? `lease_number=eq.${encodeURIComponent(leaseNumber)}` : null;
  const mainFilter = propFilter || leaseFilter;

  if (!mainFilter) {
    // No property_id or lease_number — render a fallback detail panel
    // using the fields already present on the search card record
    _setUdCache({ db, ids, property: null, leases: [], ownership: null, chain: [], rankings: null, fallback, _fallbackOnly: true });
    _udRenderFallbackHeader(db, fallback);
    if (bodyEl) bodyEl.innerHTML = _udRenderTab(activeTab);
    return;
  }

  try {
    // Fetch all views in parallel
    const promises = [
      qFn('v_property_detail', '*', { filter: mainFilter, limit: 1 }),
      qFn('v_lease_detail', '*', { filter: mainFilter, limit: 5 }),
      propFilter ? qFn('v_ownership_current', '*', { filter: propFilter, limit: 1 }) : Promise.resolve({ data: [], count: 0 }),
    ];

    // Ownership chain — Gov uses lease_number, Dia uses property_id.
    // QA-17 (2026-05-18): on gov, fall back to NO chain fetch when
    // lease_number is missing — the previous fallback to `mainFilter`
    // would pass property_id=eq.X to v_ownership_chain on gov, which
    // 400s with "column v_ownership_chain.property_id does not exist".
    // No useful chain rows are available for a gov property without a
    // lease number anyway, so an empty array is the right result.
    if (db === 'gov') {
      if (leaseNumber) {
        const chainFilter = `lease_number=eq.${encodeURIComponent(leaseNumber)}`;
        promises.push(qFn('v_ownership_chain', '*', { filter: chainFilter, order: 'transfer_date.desc', limit: 50 }));
      } else {
        promises.push(Promise.resolve({ data: [], count: 0 }));
      }
    } else {
      promises.push(qFn('v_ownership_chain', '*', { filter: propFilter || mainFilter, order: 'transfer_date.desc', limit: 50 }));
    }

    // Rankings only exist in Dia DB
    if (db === 'dia') {
      promises.push(qFn('v_property_rankings', '*', { filter: propFilter || mainFilter, limit: 1 }));
    } else {
      promises.push(Promise.resolve(db === 'gov' ? { data: [], count: 0 } : []));
    }

    // Dia: pull the denormalized CMS link columns + rent anchor / escalation
    // metadata directly from `properties`. v_property_detail may not expose
    // these. The anchor_rent triplet is tier 1 of the rent-of-record policy
    // (see _udPickCurrentRent below); the escalation pair is needed to
    // project the anchor to any target date. `rba` feeds leased-SF fallbacks
    // in _udBuildRentSchedule / _udPickCurrentRent.
    if (db === 'dia' && propFilter) {
      promises.push(diaQuery('properties',
        'property_id,medicare_id,linked_medicare_facility_id,' +
        'anchor_rent,anchor_rent_date,anchor_rent_source,lease_commencement,' +
        'lease_bump_pct,lease_bump_interval_mo,' +
        // Site/building fields fed into the client-deliverable Operations
        // export. v_property_detail exposes year_built/building_type but
        // not building_size/land_area/lot_sf/year_renovated, so we pull
        // them straight from the table.
        'building_size,year_built,year_renovated,land_area,lot_sf,building_type',
        { filter: propFilter, limit: 1 }
      ));
    } else {
      promises.push(Promise.resolve([]));
    }

    // Completeness — pulls v_property_completeness for the rail at the top
    // of the detail panel (Item #6 Phase A, 2026-05-17). Best-effort: never
    // blocks the detail render if the view fetch fails.
    if (propFilter) {
      promises.push(qFn('v_property_completeness', '*', { filter: propFilter, limit: 1 }));
    } else {
      promises.push(Promise.resolve([]));
    }

    // Next-action — pulls top-ranked gap from v_next_best_action for the
    // sticky action bar at the bottom of the panel (Item #8 Phase A,
    // 2026-05-17). Best-effort: never blocks the detail render.
    if (propFilter) {
      promises.push(qFn('v_next_best_action', '*', {
        filter: propFilter,
        order: 'gap_value.desc.nullslast',
        limit: 1,
      }));
    } else {
      promises.push(Promise.resolve([]));
    }

    const settled = await Promise.allSettled(promises);
    let _partialFail = false;

    // Normalize results — govQuery returns {data,count}, diaQuery returns array
    const extract = (r) => {
      if (Array.isArray(r)) return r;
      if (r && r.data) return r.data;
      return [];
    };
    const safeExtract = (idx) => {
      if (settled[idx].status === 'fulfilled') return extract(settled[idx].value);
      console.warn('Detail load partial failure [' + idx + ']:', settled[idx].reason);
      _partialFail = true;
      return [];
    };

    const property = safeExtract(0)[0] || null;
    const leasesRaw = safeExtract(1) || [];
    const ownership = safeExtract(2)[0] || null;
    const chain = safeExtract(3) || [];
    const rankings = safeExtract(4)[0] || null;
    const propertyCmsRow = safeExtract(5)[0] || null;
    // Index 6 is the completeness view (Item #6 Phase A). May be empty if
    // the view fetch failed or this is a fallback-only render.
    const completenessRow = safeExtract(6)[0] || null;
    // Index 7 is the top next-action row (Item #8 Phase A). May be empty
    // if the property has no open gaps or the view fetch failed.
    const nextActionRow = safeExtract(7)[0] || null;
    // Authoritative denormalized CMS link from `properties`. Either column may
    // hold the CCN; treat them equivalently for short-circuit purposes.
    const denormCcn = propertyCmsRow
      ? (propertyCmsRow.linked_medicare_facility_id || propertyCmsRow.medicare_id || null)
      : null;

    // Strip buyer-side stubs and duplicate rows. The DB unique index prevents
    // new duplicates, but historical rows may still arrive from v_lease_detail
    // until the backfill ships. See supabase/migrations/20260414213000_*.sql.
    const leases = _udFilterAndDedupeLeases(leasesRaw);

    if (_partialFail) showToast('Some detail sections failed to load — showing available data', 'error');

    // If all views returned empty, use the fallback record's fields as a synthetic property
    const allEmpty = !property && leases.length === 0 && !ownership && chain.length === 0;
    const synthProperty = allEmpty ? _udSynthPropertyFromFallback(fallback, db) : property;

    // Merge rent-anchor / escalation fields from `properties` onto the view-based
    // property object. v_property_detail may not surface these, so the Rent Roll
    // synthesizer would otherwise see flat 0% escalations even when the anchor
    // fields are populated.
    if (synthProperty && propertyCmsRow) {
      for (const key of [
        'anchor_rent', 'anchor_rent_date', 'anchor_rent_source',
        'lease_commencement', 'lease_bump_pct', 'lease_bump_interval_mo',
        'rba',
      ]) {
        if (synthProperty[key] == null && propertyCmsRow[key] != null) {
          synthProperty[key] = propertyCmsRow[key];
        }
      }
    }

    // Fetch LCC entity metadata (CoStar estimates) for this property by address.
    // These supplement v_lease_detail on the Lease tab when no executed lease
    // document is on file. Best-effort only — never blocks the detail render.
    let entityMeta = null;
    // R4-A: stash the resolved LCC asset entity id so the "Data Resolution
    // Status" badge renders "LCC Entity Registered" (green). Before this, the
    // badge only read entityMeta.entity_id/id (rarely present in metadata), so
    // a correctly-linked om_intake property showed "LCC Entity Not Registered".
    let resolvedLccEntityId = null;
    try {
      const lookupAddr = (synthProperty && synthProperty.address) || fallback.address;
      const lookupState = (synthProperty && synthProperty.state) || fallback.state;
      const lookupCity = (synthProperty && synthProperty.city) || fallback.city;
      if (lookupAddr) {
        const params = new URLSearchParams({ action: 'lookup_asset', address: lookupAddr });
        if (lookupCity) params.set('city', lookupCity);
        if (lookupState) params.set('state', lookupState);
        const entRes = await _entityApiFetch('/api/entities?' + params.toString());
        const ent = entRes?.entity || null;
        entityMeta = ent?.metadata || null;
        if (ent && ent.id) resolvedLccEntityId = ent.id;
        // Stash the resolved asset entity id onto the ownership cache so the
        // "Next step" banner can render the PERSISTED lead/cadence state on a
        // fresh re-open instead of re-offering "Create the lead" (Bug c,
        // 2026-06-03). bridgeCreateLead anchors the BD opportunity to this same
        // asset entity, so an open-opportunity / cadence check keyed on it
        // reflects the truth across reopens.
        if (ent && ent.id && ownership && !ownership.owner_entity_id) {
          ownership.owner_entity_id = ent.id;
        }
      }
    } catch (e) {
      console.warn('entity metadata lookup failed', e);
    }

    // Merge the direct-from-properties anchor / escalation columns onto the
    // view-sourced property record so _udPickCurrentRent can read them
    // without another fetch. The view may not expose these columns.
    const mergedProperty = synthProperty && propertyCmsRow
      ? Object.assign({}, synthProperty, {
          anchor_rent:            propertyCmsRow.anchor_rent            ?? synthProperty.anchor_rent            ?? null,
          anchor_rent_date:       propertyCmsRow.anchor_rent_date       ?? synthProperty.anchor_rent_date       ?? null,
          anchor_rent_source:     propertyCmsRow.anchor_rent_source     ?? synthProperty.anchor_rent_source     ?? null,
          lease_commencement:     propertyCmsRow.lease_commencement     ?? synthProperty.lease_commencement     ?? null,
          lease_bump_pct:         propertyCmsRow.lease_bump_pct         ?? synthProperty.lease_bump_pct         ?? null,
          lease_bump_interval_mo: propertyCmsRow.lease_bump_interval_mo ?? synthProperty.lease_bump_interval_mo ?? null,
          // Site/building fields used by the client-deliverable export.
          building_size:          propertyCmsRow.building_size          ?? synthProperty.building_size          ?? null,
          year_built:             propertyCmsRow.year_built             ?? synthProperty.year_built             ?? null,
          year_renovated:         propertyCmsRow.year_renovated         ?? synthProperty.year_renovated         ?? null,
          land_area:              propertyCmsRow.land_area              ?? synthProperty.land_area              ?? null,
          lot_sf:                 propertyCmsRow.lot_sf                 ?? synthProperty.lot_sf                 ?? null,
          building_type:          propertyCmsRow.building_type          ?? synthProperty.building_type          ?? null,
          // CMS link columns — handy when the export wants to surface CCN
          // even before the cms-match resolver runs.
          medicare_id:                 propertyCmsRow.medicare_id                 ?? synthProperty.medicare_id                 ?? null,
          linked_medicare_facility_id: propertyCmsRow.linked_medicare_facility_id ?? synthProperty.linked_medicare_facility_id ?? null,
        })
      : synthProperty;

    _setUdCache({ db, ids, property: mergedProperty, leases, ownership, chain, rankings, fallback, entityMeta, lccEntityId: resolvedLccEntityId, completeness: completenessRow, nextAction: nextActionRow, _fallbackOnly: allEmpty });
    // Render the data completeness rail at the top of the detail panel.
    // Best-effort: never throws upward (Item #6 Phase A, 2026-05-17).
    try { _udRenderCompletenessRail(); } catch (e) { console.warn('completeness rail render failed', e); }
    // Render the next-action bar at the bottom of the detail panel.
    // Best-effort: never throws upward (Item #8 Phase A, 2026-05-17).
    // Phase 8: ranked prospecting feed (PR1). Falls back to the single-row
    // bar on empty feed or render error, so this degrades to prior behavior.
    // R59 Unit 1: route-param hint — the BD worklist carries the signal it sent
    // the operator here to work. Show it instantly; _udLoadBdSignals (authoritative,
    // POST-ready) confirms/replaces it for any entry point incl. direct nav.
    if (fallback && fallback._bdSignal && fallback._bdSignal.type) {
      try { _udCache.bdSignal = fallback._bdSignal; } catch (_e) {}
    }
    Promise.allSettled([_udFetchProspectingFeed(6), _udFetchPriorityBand(), _udLoadBdSignals(db, propertyId)]).then(function () {
      try { _udRenderProspectingFeed(); }
      catch (e) { console.warn('prospecting feed render failed', e); try { _udRenderNextActionBar(); } catch (_e) {} }
      try { _udRenderNextStep(); } catch (_e) {}
    });
    // Enrich ownership ladder signals (confidence + divergence); re-render the
    // Ownership tab if it's the active one once they load.
    _udEnrichOwnershipSignals().then(function () {
      try {
        var _bodyEl = document.getElementById('detailBody');
        if (_bodyEl && typeof activeTab !== 'undefined' && activeTab === 'Ownership & CRM') _bodyEl.innerHTML = _udRenderTab('Ownership & CRM');
      } catch (_e) {}
      try { _udRenderNextStep(); } catch (_e) {}
    });

    // ── Dialysis Operations tab: auto-match CMS facility when rankings is empty ──
    // Uses the /api/cms-match?action=resolve endpoint to fuzzy-match the property's
    // address to medicare_clinics.medicare_id, cache the match in property_cms_link,
    // and return a compact CMS snapshot (rankings/quality/patient/payer/operator).
    // We also resolve when rankings exists but has no medicare_id — the Operations
    // tab still needs CMS quality/trends/payer/cost data which live on medicare_id.
    //
    // Priority order for the CCN:
    //   1) properties.linked_medicare_facility_id / properties.medicare_id
    //      (authoritative denormalized link — never run fuzzy auto-match when set)
    //   2) v_property_rankings.medicare_id (pre-linked via medicare_clinics)
    //   3) /api/cms-match?action=resolve (fuzzy match fallback)
    const rankingsHasCcn = !!(rankings && rankings.medicare_id);
    if (db === 'dia' && denormCcn) {
      // Seed cms cache from the property's curated CCN so the Operations tab
      // never falls into the "No CMS facility linked" card. If rankings is
      // missing, also call resolve — the backend will short-circuit on the
      // denormalized field (no fuzzy match) and return a full snapshot.
      _udCache.cms = {
        medicare_id: denormCcn,
        match_score: 1.0,
        match_method: 'auto:property_field',
        source: 'property_field',
        operator: _udDetectOperator(rankings || {}),
      };
      if (!rankings && propertyId) {
        try {
          await _udResolveCmsFacility(propertyId);
        } catch (e) {
          console.warn('cms-match resolve (snapshot fetch) failed:', e);
        }
      }
    } else if (db === 'dia' && propertyId && (!rankings || !rankingsHasCcn)) {
      try {
        await _udResolveCmsFacility(propertyId);
      } catch (e) {
        console.warn('cms-match resolve failed:', e);
      }
    } else if (db === 'dia' && rankingsHasCcn && !_udCache.cms) {
      // Rankings already carry the CCN (pre-linked via medicare_clinics).
      // Seed a minimal cms cache so the Operations tab can find the CCN for
      // its secondary fetches (quality/trend/payer/cost) without a round-trip.
      _udCache.cms = {
        medicare_id: rankings.medicare_id,
        match_score: 1.0,
        match_method: 'auto:medicare_clinics',
        source: 'rankings',
        operator: _udDetectOperator(rankings),
      };
    }

    // Kick off a best-effort fetch for lease extensions + rent schedule.
    // These fill in the "No. of Extensions / Last Extension" and the Rent Roll
    // sub-view on the Lease tab. Never blocks the main render; on failure the
    // Lease tab simply renders without the enriched values.
    if (db === 'dia' && Array.isArray(leases) && leases.length > 0) {
      _udFetchLeaseEnrichment(leases).then((enrichment) => {
        if (!_udCache) return;
        _setUdCache({ ..._udCache, leaseExtensions: enrichment.extensions, leaseRentSchedule: enrichment.schedule, leaseOptions: enrichment.options || new Map() });
        // Re-render if the Rent Roll tab is currently active
        const activeTabEl = document.querySelector('#detailTabs .detail-tab.active');
        const activeLabel = activeTabEl ? activeTabEl.textContent.trim() : '';
        if (activeLabel === 'Rent Roll' || activeLabel === 'Lease') {
          const bodyEl = document.getElementById('detailBody');
          if (bodyEl) bodyEl.innerHTML = _udRenderTab(activeLabel);
        }
      }).catch((e) => { console.warn('lease enrichment fetch failed', e); });
    }

    // Update header with real data (page_title or fallback to tenant/address)
    if (synthProperty) {
      const realTitle = synthProperty.page_title || synthProperty.facility_name || fallback.tenant_operator || fallback.agency || synthProperty.address || fallback.address || '(Unknown)';
      // UI Phase 4: refine this level's breadcrumb crumb to the loaded title.
      if (typeof _detailStackSetLabel === 'function' && (propertyId || ids.property_id)) {
        _detailStackSetLabel({ kind: 'prop', db, id: propertyId || ids.property_id }, realTitle);
      }
      const loc2 = (synthProperty.city || '') + (synthProperty.state ? ', ' + synthProperty.state : '');
      // QA-12 (2026-05-18): drop the city subtitle when the title already
      // embeds it (page_title often does), so the panel doesn't show
      // "Washington, DC" twice in a row.
      const loc2ForSubtitle = (loc2 && realTitle && realTitle.toLowerCase().includes(loc2.toLowerCase())) ? '' : loc2;
      const subtitleSuffix = synthProperty.county ? (loc2ForSubtitle ? ' · ' : '') + esc(synthProperty.county) + ' County' : '';
      // "Not a Lead" button for dia-clinic records (dismiss from clinic lead pipeline)
      const dismissBtn = (db === 'dia' && (fallback.clinic_id || fallback.medicare_id))
        ? `<button onclick="_udDismissLead()" style="background:rgba(239,68,68,0.12);color:var(--red,#ef4444);border:1px solid rgba(239,68,68,0.25);border-radius:6px;padding:4px 10px;font-size:11px;font-weight:600;cursor:pointer;white-space:nowrap;font-family:Outfit,sans-serif;margin-right:6px" title="Mark as not a viable lead (hospital campus, etc.)">Not a Lead</button>`
        : '';
      if (headerEl) headerEl.innerHTML = `
        <div class="detail-header-info">
          <div style="flex:1">
            <div class="detail-title">${esc(realTitle)}</div>
            ${(loc2ForSubtitle || subtitleSuffix) ? `<div class="detail-subtitle">${esc(loc2ForSubtitle)}${subtitleSuffix}</div>` : ''}
            ${_udKeyFields(db, synthProperty, ownership)}
          </div>
          ${dismissBtn}
          ${_udLeaseCompsControlHtml(db, propertyId || synthProperty?.property_id || ids.property_id)}
          <button class="detail-action-btn" id="consolidateBtn"
            title="Find duplicate properties + same-tenant clusters"
            onclick="openConsolidateModal('${db}', ${(propertyId || ids.property_id) || 'null'})"
            style="background:transparent;border:1px solid var(--border);color:var(--text2);padding:6px 12px;border-radius:6px;font-size:12px;cursor:pointer;margin-right:8px"
            ${(propertyId || ids.property_id) ? '' : 'disabled'}>
            🔗 Consolidate
          </button>
          <span class="detail-badge" style="background:${db === 'gov' ? 'var(--gov-green)' : 'var(--purple)'};color:#fff">${db === 'gov' ? 'GOV' : 'DIA'}</span>
          <button class="detail-close" onclick="closeDetail()">&times;</button>
        </div>`;
    }

    // Render active tab (preserve on refresh) or default to Overview
    const activeTabEl = document.querySelector('#detailTabs .detail-tab.active');
    const activeTab = activeTabEl ? activeTabEl.textContent.trim() : 'Overview';
    // Operations and Deal History tabs need async data loading
    if (activeTab === 'Operations' && db === 'dia') {
      _udRenderOperationsAsync(bodyEl);
    } else if (activeTab === 'Deal History') {
      _udRenderDealHistoryAsync(bodyEl);
    } else if (activeTab === 'Activity Log') {
      _udRenderActivityLogAsync(bodyEl);
    } else {
      if (bodyEl) bodyEl.innerHTML = _udRenderTab(activeTab);
      if (activeTab === 'Overview') { _udHydratePipelineStage(); _intelRenderPriorSaleSummaryAsync(); }
    }

  } catch (err) {
    console.error('Unified detail load error:', err);
    showToast('Error loading details: ' + (err.message || 'unknown'), 'error');
    if (bodyEl) bodyEl.innerHTML =
      `<div class="detail-empty">Error loading details: ${esc(err.message)}</div>`;
  }
}

/** Key fields bar under the header */
function _udKeyFields(db, prop, own) {
  let html = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:4px 16px;margin-top:8px;font-size:12px;">';
  if (prop.address) html += `<div><span class="t-muted3">Address:</span> <span class="t-body">${esc(prop.address)}</span></div>`;
  if (prop.lease_number) html += `<div><span class="t-muted3">Lease:</span> <span style="color:var(--text);font-family:monospace">${esc(prop.lease_number)}</span></div>`;
  if (db === 'dia') {
    // Dialysis: show operator, not agency — check property data then fallback record
    const fb = _udCache?.fallback || {};
    const opName = prop.operator_name || fb.operator_name || fb.chain_organization || prop.facility_name || fb.facility_name || '';
    if (opName) html += `<div><span class="t-muted3">Operator:</span> <span class="t-body">${esc(opName)}</span></div>`;
  } else {
    if (prop.agency_short || prop.agency_full) html += `<div><span class="t-muted3">Agency:</span> <span class="t-body">${esc(prop.agency_short || prop.agency_full)}</span></div>`;
  }
  if (own) {
    // Prefer canonical names (Layer H.2.a) so casing/SPE variants collapse to one consistent label.
    const ownerName = own.true_owner_canonical || own.true_owner || own.recorded_owner_canonical || own.recorded_owner || '';
    if (ownerName) html += `<div><span class="t-muted3">Owner:</span> <span class="t-body">${esc(ownerName)}</span></div>`;
  }
  if (prop.estimated_value) html += `<div><span class="t-muted3">Est. Value:</span> <span style="color:var(--green);font-weight:600">${fmt(prop.estimated_value)}</span></div>`;
  if (prop.deal_grade) html += `<div><span class="t-muted3">Grade:</span> <span style="color:var(--accent);font-weight:600">${esc(prop.deal_grade)}</span></div>`;
  html += '</div>';
  return html;
}

/** Show the dismiss form inline at the top of the detail body */
function _udDismissLead() {
  if (!_udCache || _udCache.db !== 'dia') return;
  const existing = document.getElementById('ud-dismiss-form');
  if (existing) { existing.remove(); return; } // toggle off

  const prop = _udCache.property || {};
  const currentSF = prop.building_sf || prop.building_size || '';

  const formHTML = `
    <div id="ud-dismiss-form" style="background:rgba(239,68,68,0.06);border:1px solid rgba(239,68,68,0.2);border-radius:10px;padding:14px 16px;margin:0 0 16px 0;font-size:12px;">
      <div style="font-weight:700;color:var(--red,#ef4444);font-size:13px;margin-bottom:10px">Dismiss Lead — Not Viable</div>

      <div style="margin-bottom:8px">
        <label style="color:var(--text3);font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px">Reason</label>
        <select id="ud-dismiss-reason" style="display:block;width:100%;margin-top:3px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);font-size:12px">
          <option value="hospital_campus">Hospital Campus / Medical Complex</option>
          <option value="multi_tenant">Multi-Tenant Building (not single-tenant NNN)</option>
          <option value="government_owned">Government-Owned Property</option>
          <option value="too_small">Too Small / Not Institutional Grade</option>
          <option value="no_property_match">Cannot Match to Property</option>
          <option value="closed">Clinic Closed / Relocated</option>
          <option value="other">Other</option>
        </select>
      </div>

      <div style="margin-bottom:8px">
        <label style="color:var(--text3);font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px">Notes</label>
        <input type="text" id="ud-dismiss-notes" placeholder="e.g. In 1.4M SF hospital, owned by Hartford Healthcare" style="display:block;width:100%;margin-top:3px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);font-size:12px;box-sizing:border-box" />
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">
        <div>
          <label style="color:var(--text3);font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px">Building Size (SF)</label>
          <input type="number" id="ud-dismiss-rba" value="${currentSF}" placeholder="e.g. 1400000" style="display:block;width:100%;margin-top:3px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);font-size:12px;box-sizing:border-box" />
        </div>
        <div>
          <label style="color:var(--text3);font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px">Occupancy</label>
          <select id="ud-dismiss-occupancy" style="display:block;width:100%;margin-top:3px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);font-size:12px">
            <option value="">— no change —</option>
            <option value="multi">Multi-Tenant</option>
            <option value="single">Single-Tenant</option>
          </select>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">
        <div>
          <label style="color:var(--text3);font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px">True Owner</label>
          <input type="text" id="ud-dismiss-owner" placeholder="e.g. Hartford Healthcare" style="display:block;width:100%;margin-top:3px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);font-size:12px;box-sizing:border-box" />
        </div>
        <div>
          <label style="color:var(--text3);font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px">Owner Type</label>
          <select id="ud-dismiss-owner-type" style="display:block;width:100%;margin-top:3px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);font-size:12px">
            <option value="">— not specified —</option>
            <option value="hospital_system">Hospital System</option>
            <option value="university">University / Academic Medical Center</option>
            <option value="government">Government Entity</option>
            <option value="reit">REIT / Institutional</option>
            <option value="private_equity">Private Equity</option>
            <option value="individual">Individual / Family</option>
            <option value="operator">Operator-Owned</option>
            <option value="other">Other</option>
          </select>
        </div>
      </div>

      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px">
        <button onclick="var _df=document.getElementById('ud-dismiss-form');if(_df)_df.remove()" style="padding:6px 14px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text2);font-size:12px;cursor:pointer;font-family:Outfit,sans-serif">Cancel</button>
        <button onclick="_udBtnGuard(this, _udSubmitDismiss)" style="padding:6px 14px;border:none;border-radius:6px;background:var(--red,#ef4444);color:#fff;font-size:12px;font-weight:600;cursor:pointer;font-family:Outfit,sans-serif">Dismiss Lead</button>
      </div>
    </div>`;

  const body = document.getElementById('detailBody');
  if (body) body.insertAdjacentHTML('afterbegin', formHTML);
}
window._udDismissLead = _udDismissLead;

/** Submit the dismiss form — save outcome + update property data */
async function _udSubmitDismiss() {
  if (!_udCache || _udCache.db !== 'dia') return;
  const clinicId = _udCache.fallback?.clinic_id || _udCache.fallback?.medicare_id;
  const propertyId = _udCache.ids?.property_id;
  if (!clinicId) { showToast('No clinic ID — cannot dismiss', 'error'); return; }

  if (!(await lccConfirm('Dismiss this lead as not viable? This will remove it from the clinic leads queue.'))) return;

  const reason = document.getElementById('ud-dismiss-reason')?.value || 'other';
  const notes = document.getElementById('ud-dismiss-notes')?.value?.trim() || '';
  const rba = document.getElementById('ud-dismiss-rba')?.value;
  const occupancy = document.getElementById('ud-dismiss-occupancy')?.value;
  const trueOwner = document.getElementById('ud-dismiss-owner')?.value?.trim() || '';
  const ownerType = document.getElementById('ud-dismiss-owner-type')?.value || '';

  const reasonLabels = {
    hospital_campus: 'Hospital Campus / Medical Complex',
    multi_tenant: 'Multi-Tenant Building',
    government_owned: 'Government-Owned Property',
    too_small: 'Too Small / Not Institutional',
    no_property_match: 'Cannot Match to Property',
    closed: 'Clinic Closed / Relocated',
    other: 'Other'
  };
  const fullNotes = [
    'Reason: ' + (reasonLabels[reason] || reason),
    notes || null,
    rba ? 'Building SF: ' + Number(rba).toLocaleString() : null,
    occupancy === 'multi' ? 'Multi-tenant building' : null,
    trueOwner ? 'Owner: ' + trueOwner : null,
    ownerType ? 'Owner type: ' + ownerType : null
  ].filter(Boolean).join(' | ');

  // Disable the submit button to prevent double-clicks
  const btn = document.querySelector('#ud-dismiss-form button:last-child');
  if (btn) { btn.disabled = true; btn.textContent = 'Saving...'; }

  try {
    // 1. Save research_queue_outcomes
    const outPayload = {
      queue_type: 'clinic_lead',
      clinic_id: clinicId,
      status: 'not_applicable',
      notes: fullNotes,
      selected_property_id: propertyId || null,
      assigned_at: new Date().toISOString()
    };
    const outResult = await applyInsertWithFallback({
      proxyBase: '/api/dia-query',
      table: 'research_queue_outcomes',
      idColumn: 'clinic_id',
      recordIdentifier: clinicId,
      data: outPayload,
      source_surface: 'detail_clinic_dismiss',
      propagation_scope: 'research_queue_outcome'
    });
    if (!outResult.ok) {
      console.error('Dismiss outcome error:', outResult.errors || []);
      showToast('Error saving dismiss outcome', 'error');
      if (btn) { btn.disabled = false; btn.textContent = 'Dismiss Lead'; }
      return;
    }

    // 2. Update property record via mutation service if we have a property_id and any property data
    if (propertyId && (rba || occupancy || trueOwner)) {
      const propPayload = {};
      if (rba) propPayload.building_sf = parseInt(rba, 10);
      if (occupancy === 'multi') propPayload.is_single_tenant = false;
      if (occupancy === 'single') propPayload.is_single_tenant = true;
      if (trueOwner) propPayload.tenant = trueOwner; // tenant field used for owner display

      const propResult = await applyChangeWithFallback({
        proxyBase: '/api/dia-query',
        table: 'properties',
        idColumn: 'property_id',
        idValue: propertyId,
        data: propPayload,
        source_surface: 'clinic_workspace',
        notes: 'Property update during lead dismiss'
      });
      if (!propResult.ok) {
        console.warn('Property update warning:', (propResult.errors || []).join(', '));
        // Non-fatal — the lead is still dismissed
      }
    }

    // 3. If true owner entered, also save to ownership records
    if (propertyId && trueOwner) {
      try {
        const owPayload = { name: trueOwner, owner_type: ownerType || 'other' };
        await applyInsertWithFallback({
          proxyBase: '/api/dia-query',
          table: 'true_owners',
          data: owPayload,
          source_surface: 'detail_clinic_dismiss',
          propagation_scope: 'ownership_helper_record'
        });
      } catch (e) { console.warn('Owner record save warning:', e); showToast('Warning: owner record not saved — ' + (e.message || 'unknown error'), 'warning'); }
    }

    // Refresh local outcomes cache
    if (typeof diaData !== 'undefined' && diaData.researchOutcomes) {
      diaData.researchOutcomes.push(outPayload);
    }

    showToast('Lead dismissed — research saved', 'success');
    closeDetail();
    if (typeof renderDiaTab === 'function') renderDiaTab();
  } catch (e) {
    console.error('Dismiss error:', e);
    showToast('Error: ' + e.message, 'error');
    if (btn) { btn.disabled = false; btn.textContent = 'Dismiss Lead'; }
  }
}
window._udSubmitDismiss = _udSubmitDismiss;

/** Switch tabs without re-fetching data */
function switchUnifiedTab(tabName) {
  if (!_udCache) return;
  tabName = _udMapLegacyTab(tabName);
  // Client routing (UI Phase 1): keep the tab segment in the hash current
  // (replace, so reload keeps the tab and no history entry / loop is created).
  if (typeof _routeUpdateTabHash === 'function') _routeUpdateTabHash(tabName);
  document.querySelectorAll('#detailTabs .detail-tab').forEach(t => {
    t.classList.toggle('active', t.textContent.trim() === tabName);
  });
  const bodyEl = document.getElementById('detailBody');
  // Operations tab may need async data loading
  if (tabName === 'Operations' && _udCache.db === 'dia') {
    _udRenderOperationsAsync(bodyEl);
  } else if (tabName === 'Deal History') {
    _udRenderDealHistoryAsync(bodyEl);
  } else if (tabName === 'Activity Log') {
    _udRenderActivityLogAsync(bodyEl);
  } else {
    if (bodyEl) bodyEl.innerHTML = _udRenderTab(tabName);
    if (tabName === 'Overview') { _udHydratePipelineStage(); _intelRenderPriorSaleSummaryAsync(); }
  }
}

/**
 * Translate legacy tab names (Property, Lease, Ownership, Sales, History)
 * into the new restructured names. Keeps deep-links & older callers working
 * after the 2026-04-15 tab restructure.
 */
function _udMapLegacyTab(name) {
  if (!name) return name;
  const n = String(name).trim();
  // Case-insensitive match so legacy callers like "sales"/"history" still resolve.
  switch (n.toLowerCase()) {
    case 'property':         return 'Overview';
    case 'lease':            return 'Rent Roll';
    case 'ownership':        return 'Ownership & CRM';
    // Round 76bj (2026-04-28): clicking a row in Sales/Avail dashboard tables
    // used to land on Deal History tab. Scott wants Overview as the default
    // landing tab regardless of which dashboard table the click came from —
    // user can switch to Deal History manually. This applies to both
    // 'sales' and 'available' alias paths.
    case 'sales':            return 'Overview';
    case 'available':        return 'Overview';
    case 'listing':          return 'Overview';
    case 'history':          return 'Activity Log';
    case 'overview':         return 'Overview';
    case 'rent roll':        return 'Rent Roll';
    case 'operations':       return 'Operations';
    case 'ownership & crm':  return 'Ownership & CRM';
    case 'deal history':     return 'Deal History';
    case 'intel':            return 'Overview';
    case 'activity log':     return 'Activity Log';
    default:                 return n;
  }
}
window._udMapLegacyTab = _udMapLegacyTab;

// ─── CMS FACILITY MATCH (property ↔ medicare_id) ─────────────────────────────
// Backs the Operations tab. When v_property_rankings has no row for a property,
// we call /api/cms-match?action=resolve to fuzzy-match the property address to
// a CMS medicare_id and cache the link in the Dialysis DB (property_cms_link).

function _udDetectOperator(row) {
  const raw = (row && (row.chain_organization || row.operator_name || row.facility_name)) || '';
  const name = String(raw).toLowerCase();
  if (!name) return { label: 'Unknown', key: 'unknown', color: 'var(--text3)' };
  if (/davita/.test(name))                   return { label: 'DaVita',          key: 'davita',  color: '#dc2626' };
  if (/fresenius|fmc|fkc/.test(name))        return { label: 'Fresenius (FMC)', key: 'fmc',     color: '#f59e0b' };
  if (/u\.?s\.?\s*renal|usrc/.test(name))    return { label: 'US Renal',        key: 'usrenal', color: '#3b82f6' };
  if (/satellite/.test(name))                return { label: 'Satellite',       key: 'satellite', color: '#8b5cf6' };
  if (/dialyze\s*direct/.test(name))         return { label: 'Dialyze Direct',  key: 'dialyzedirect', color: '#10b981' };
  return { label: 'Independent', key: 'indy', color: 'var(--text2)' };
}

/** Call /api/cms-match?action=resolve and merge the snapshot into _udCache. */
async function _udResolveCmsFacility(propertyId) {
  if (!_udCache) return null;
  const url = new URL('/api/cms-match', window.location.origin);
  url.searchParams.set('action', 'resolve');
  url.searchParams.set('property_id', propertyId);
  const headers = {};
  if (window._lccApiKey) headers['X-LCC-Key'] = window._lccApiKey;
  let resp;
  try {
    const r = await fetch(url.toString(), { headers, signal: AbortSignal.timeout(25000) });
    if (!r.ok) { console.warn('cms-match resolve http', r.status); resp = { match: null, candidates: [] }; }
    else resp = await r.json();
  } catch (err) {
    console.warn('cms-match resolve fetch failed', err);
    return null;
  }
  // Populate cache
  _udCache.cms = {
    medicare_id: resp.medicare_id || null,
    match_score: resp.match_score || null,
    match_method: resp.match_method || null,
    source: resp.source || null,
    debug: resp.debug || null,
    facility: resp.facility || null,
    quality: resp.quality || null,
    patient: resp.patient || null,
    trends: resp.trends || null,
    payer: resp.payer || null,
    cost: resp.cost || null,
    operator: resp.operator || _udDetectOperator(resp.facility || resp.rankings || {}),
    candidates: resp.candidates || [],
  };
  // If the resolver returned a rankings row, use it so Operations tab renders normally.
  if (resp.rankings) _udCache.rankings = resp.rankings;
  _setUdCache(_udCache);
  return resp;
}

/** Show the Match-facility typeahead card (fallback when auto-match fails). */
function _udRenderMatchFacilityCard() {
  const fb = _udCache?.fallback || {};
  const p  = _udCache?.property || {};
  const cms = _udCache?.cms || {};
  const candidates = cms.candidates || [];
  const addr   = p.address || fb.address || '';
  const city   = p.city || fb.city || '';
  const state  = p.state || fb.state || '';
  const zip    = p.zip_code || p.zip || fb.zip || fb.zip_code || '';
  // Only true when /api/cms-match?action=resolve actually ran (cms.debug
  // is only populated by the resolver). The card was previously claiming
  // "Auto-match tried <addr>" even when the panel was opened with no
  // property_id and the resolver was never called — misleading.
  const autoMatchRan = !!(cms && cms.debug);
  const propertyId = _udCache?.ids?.property_id || _udCache?.property?.property_id || null;

  let html = '<div class="detail-empty" style="text-align:left;padding:24px;background:var(--s2);border-radius:12px">';
  html += '<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">';
  html += '<div style="font-size:24px">&#x1F50D;</div>';
  html += '<div><div style="font-weight:700;color:var(--text)">No CMS facility linked to this property</div>';
  if (autoMatchRan) {
    html += '<div style="font-size:12px;color:var(--text2);margin-top:2px">Auto-match tried <strong>' + esc(addr || '—') + '</strong>' + (zip ? ' (' + esc(zip) + ')' : '') + ' — no confident match found.</div>';
  } else if (!propertyId) {
    html += '<div style="font-size:12px;color:#f59e0b;margin-top:2px">This panel was opened without a linked property record. Linking from here would not persist — search Pipeline / Properties for this address and open it from there to link a CMS facility.</div>';
  } else {
    html += '<div style="font-size:12px;color:var(--text2);margin-top:2px">No auto-match run yet for this property. Use the search below to pick a CMS facility manually.</div>';
  }
  html += '</div></div>';

  // Debug context (visible when all candidates fell below the auto-match threshold)
  if (cms.debug && cms.debug.candidate_count != null) {
    const d = cms.debug;
    const topPct = d.top_score != null ? Math.round(d.top_score * 100) + '%' : '—';
    html += '<div style="margin-top:8px;padding:6px 10px;background:rgba(148,163,184,0.08);border:1px solid var(--border);border-radius:6px;font-size:11px;color:var(--text3)">';
    html += 'Scanned ' + d.candidate_count + ' nearby CMS facility record' + (d.candidate_count === 1 ? '' : 's') + '. ';
    html += 'Best score: <strong class="t-muted2">' + topPct + '</strong> ';
    html += '(needs ≥ ' + Math.round((d.confident_threshold || 0.8) * 100) + '% to auto-link).';
    html += '</div>';
  }

  // Candidate suggestions (from fuzzy match, score ≥ 0.55)
  if (candidates.length > 0) {
    html += '<div style="font-size:11px;color:var(--text3);margin-top:8px;margin-bottom:6px;text-transform:uppercase;letter-spacing:0.5px;font-weight:600">Suggested matches</div>';
    html += '<div style="display:flex;flex-direction:column;gap:6px;margin-bottom:14px">';
    candidates.forEach(c => {
      const scorePct = Math.round((Number(c.match_score) || 0) * 100);
      html += '<div style="display:flex;gap:10px;padding:10px 12px;background:var(--s1);border-radius:8px;border:1px solid var(--border)">';
      html += '<div style="flex:1;min-width:0">';
      html += '<div style="font-weight:600;color:var(--text);font-size:13px">' + esc(c.facility_name || '(unnamed)') + '</div>';
      html += '<div style="font-size:11px;color:var(--text2);margin-top:2px">' + esc(c.address || '') + (c.city ? ', ' + esc(c.city) : '') + (c.state ? ', ' + esc(c.state) : '') + (c.zip ? ' ' + esc(c.zip) : '') + '</div>';
      html += '<div style="font-size:10px;color:var(--text3);margin-top:3px">CCN ' + esc(c.medicare_id) + (c.chain_organization ? ' · ' + esc(c.chain_organization) : '') + '</div>';
      html += '</div>';
      html += '<div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px">';
      html += '<span style="font-size:10px;padding:2px 6px;border-radius:8px;background:' + (scorePct >= 70 ? 'rgba(16,185,129,0.18);color:#10b981' : 'rgba(251,191,36,0.18);color:#f59e0b') + ';font-weight:700">' + scorePct + '% match</span>';
      if (propertyId) {
        html += '<button onclick="_udCmsLinkCandidate(\'' + esc(c.medicare_id) + '\', \'auto:address_zip\')" style="font-size:11px;padding:4px 10px;border-radius:6px;border:1px solid var(--accent);background:var(--accent);color:#fff;font-weight:600;cursor:pointer">Use this</button>';
      } else {
        html += '<button disabled title="Open this record from Pipeline / Properties to link" style="font-size:11px;padding:4px 10px;border-radius:6px;border:1px solid var(--border);background:var(--s2);color:var(--text3);font-weight:600;cursor:not-allowed">Use this</button>';
      }
      html += '</div></div>';
    });
    html += '</div>';
  }

  // Typeahead search
  html += '<div style="margin-top:12px">';
  html += '<div style="font-size:11px;color:var(--text3);margin-bottom:6px;text-transform:uppercase;letter-spacing:0.5px;font-weight:600">Search the CMS facility registry</div>';
  html += '<div style="position:relative">';
  html += '<input id="cmsMatchQuery" type="text" placeholder="Facility name, CCN, or street address…" oninput="_udCmsTypeahead(this.value)" ';
  html += 'style="width:100%;padding:8px 12px;border-radius:8px;border:1px solid var(--border);background:var(--s1);color:var(--text);font-size:13px;box-sizing:border-box" />';
  html += '<div id="cmsMatchResults" style="margin-top:6px;display:flex;flex-direction:column;gap:4px;max-height:280px;overflow-y:auto"></div>';
  html += '</div>';
  if (state || zip) {
    html += '<div style="font-size:10px;color:var(--text3);margin-top:6px">Search scoped to ' + (state ? 'state ' + esc(state) : '') + (state && zip ? ', ' : '') + (zip ? 'zip area ' + esc(String(zip).substring(0,3)) + 'xx' : '') + '.</div>';
  }
  html += '</div></div>';
  return html;
}

// Debounced typeahead search against /api/cms-match?action=search
let _cmsTypeaheadTimer = null;
function _udCmsTypeahead(q) {
  clearTimeout(_cmsTypeaheadTimer);
  const resultsEl = document.getElementById('cmsMatchResults');
  if (!q || q.length < 2) { if (resultsEl) resultsEl.innerHTML = ''; return; }
  _cmsTypeaheadTimer = setTimeout(async () => {
    const p = _udCache?.property || {};
    const fb = _udCache?.fallback || {};
    const state = p.state || fb.state || '';
    const zip = p.zip_code || p.zip || fb.zip || fb.zip_code || '';
    const url = new URL('/api/cms-match', window.location.origin);
    url.searchParams.set('action', 'search');
    url.searchParams.set('q', q);
    if (state) url.searchParams.set('state', state);
    // Scope by zip prefix (3-digit) for broader geographic matching;
    // exact 5-digit zip was too restrictive for nearby facilities
    if (zip && !/^\d/.test(q)) url.searchParams.set('zip', String(zip).substring(0,3));
    url.searchParams.set('limit', '10');
    const headers = {};
    if (window._lccApiKey) headers['X-LCC-Key'] = window._lccApiKey;
    try {
      const r = await fetch(url.toString(), { headers, signal: AbortSignal.timeout(10000) });
      const data = await r.json();
      const rows = (data && data.candidates) || [];
      if (!resultsEl) return;
      if (rows.length === 0) { resultsEl.innerHTML = '<div style="padding:8px;font-size:12px;color:var(--text3)">No facilities found.</div>'; return; }
      const propertyId = _udCache?.ids?.property_id || _udCache?.property?.property_id || null;
      resultsEl.innerHTML = rows.map(c => {
        const line2 = [c.address, c.city, c.state, c.zip_code || c.zip].filter(Boolean).map(esc).join(', ');
        const linkBtn = propertyId
          ? '<button onclick="_udCmsLinkCandidate(\'' + esc(c.medicare_id) + '\', \'manual:typeahead\')" style="font-size:11px;padding:4px 10px;border-radius:6px;border:1px solid var(--accent);background:var(--accent);color:#fff;font-weight:600;cursor:pointer">Link</button>'
          : '<button disabled title="Open this record from Pipeline / Properties to link" style="font-size:11px;padding:4px 10px;border-radius:6px;border:1px solid var(--border);background:var(--s2);color:var(--text3);font-weight:600;cursor:not-allowed">Link</button>';
        return '<div style="display:flex;gap:10px;padding:8px 10px;background:var(--s1);border-radius:6px;border:1px solid var(--border);align-items:center">' +
          '<div style="flex:1;min-width:0">' +
          '<div style="font-weight:600;color:var(--text);font-size:12px">' + esc(c.facility_name || '(unnamed)') + '</div>' +
          '<div style="font-size:11px;color:var(--text2)">' + line2 + '</div>' +
          '<div style="font-size:10px;color:var(--text3);margin-top:1px">CCN ' + esc(c.medicare_id) + (c.chain_organization ? ' · ' + esc(c.chain_organization) : '') + '</div>' +
          '</div>' +
          linkBtn +
        '</div>';
      }).join('');
    } catch (err) {
      console.warn('cms typeahead failed', err);
      if (resultsEl) resultsEl.innerHTML = '<div style="padding:8px;font-size:12px;color:var(--red)">Search failed.</div>';
    }
  }, 250);
}

/** Apply a manual link (from the typeahead or a suggested candidate) and re-render. */
async function _udCmsLinkCandidate(medicareId, method) {
  if (!_udCache) return;
  const propertyId = _udCache.ids?.property_id || _udCache.property?.property_id;
  if (!propertyId) { showToast('Property ID not available', 'error'); return; }
  const bodyEl = document.getElementById('detailBody');
  if (bodyEl) bodyEl.innerHTML = '<div style="text-align:center;padding:32px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Linking CMS facility…</p></div>';
  try {
    const headers = { 'Content-Type': 'application/json' };
    if (window._lccApiKey) headers['X-LCC-Key'] = window._lccApiKey;
    const r = await fetch('/api/cms-match?action=link', {
      method: 'POST', headers,
      body: JSON.stringify({ property_id: propertyId, medicare_id: medicareId, match_method: method || 'manual' }),
      signal: AbortSignal.timeout(15000),
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || ('HTTP ' + r.status));
    // Merge response into cache and re-render
    _udCache.cms = {
      medicare_id: medicareId,
      match_score: data.link?.match_score || null,
      match_method: data.link?.match_method || method,
      source: 'manual',
      facility: data.facility || null,
      quality: data.quality || null,
      patient: data.patient || null,
      trends: data.trends || null,
      payer: data.payer || null,
      cost: data.cost || null,
      operator: data.operator || _udDetectOperator(data.facility || {}),
      candidates: [],
    };
    if (data.rankings) _udCache.rankings = data.rankings;
    _opsExtraCache = null; // invalidate extra cache so next render refetches
    _setUdCache(_udCache);
    showToast('Linked CMS facility ' + medicareId, 'success');
    if (bodyEl) _udRenderOperationsAsync(bodyEl);
  } catch (err) {
    console.error('link failed', err);
    showToast('Link failed: ' + (err.message || 'unknown'), 'error');
    if (bodyEl) bodyEl.innerHTML = _udTabOperations();
  }
}

/** Remove a cached link (admin / correction path). */
async function _udCmsClearLink() {
  if (!_udCache) return;
  const propertyId = _udCache.ids?.property_id || _udCache.property?.property_id;
  if (!propertyId) return;
  if (!confirm('Remove the CMS facility link for this property? The Operations tab will re-run auto-match next open.')) return;
  try {
    const headers = {};
    if (window._lccApiKey) headers['X-LCC-Key'] = window._lccApiKey;
    const r = await fetch('/api/cms-match?action=link&property_id=' + encodeURIComponent(propertyId), {
      method: 'DELETE', headers, signal: AbortSignal.timeout(10000),
    });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    _udCache.cms = null;
    _udCache.rankings = null;
    _opsExtraCache = null;
    _setUdCache(_udCache);
    showToast('CMS link removed', 'success');
    const bodyEl = document.getElementById('detailBody');
    if (bodyEl) _udRenderOperationsAsync(bodyEl);
  } catch (err) {
    showToast('Unlink failed: ' + err.message, 'error');
  }
}

// Export CMS link/search functions for onclick handlers in dynamic HTML
window._udCmsLinkCandidate = _udCmsLinkCandidate;
window._udCmsClearLink = _udCmsClearLink;
window._udCmsTypeahead = _udCmsTypeahead;

/** Lazy-load additional clinic data for the Operations tab, then render */
let _opsExtraCache = null; // { medicare_id, patientHistory, trends, quality, financialDetail, costReports, payerMix, lease }
// Separate cache for gov-domain Operations data (FRPP, OPM workforce, agency
// portfolio, GSA lease timeline). Keyed on property_id so re-opening the
// same property uses the cache. Cleared on openUnifiedDetail.
let _opsGovCache = null; // { property_id, extProperty, frpp, opmRollup, agencyPortfolio, gsaTimeline }

async function _udRenderOperationsAsync(bodyEl) {
  const fb = _udCache.fallback || {};
  const db = _udCache.db;
  const propertyId = _udCache.ids?.property_id || _udCache.property?.property_id;

  // ── GOV BRANCH ──────────────────────────────────────────────────────
  // Lazy-load FRPP + OPM + agency-portfolio + GSA-lease-timeline context
  // for federal government properties. The MVP _udTabOperations already
  // handles the case where this cache is empty; it just won't show the
  // richer panels.
  if (db === 'gov' && propertyId) {
    if (_opsGovCache && _opsGovCache.property_id === propertyId) {
      if (bodyEl) bodyEl.innerHTML = _udTabOperations();
      return;
    }
    if (bodyEl) bodyEl.innerHTML = _opsLoadingSkeleton();

    const gov = { property_id: propertyId, extProperty: null, frpp: null, opmRollup: null, agencyPortfolio: null, gsaTimeline: [] };
    try {
      // Extra property columns not exposed by v_property_detail
      const extPromise = govQuery('properties',
        'property_id,agency,agency_full_name,agency_id,federal_employee_count,opm_headcount,workforce_trend,agency_risk_level,linked_frpp_id,government_type,representing_agency',
        { filter: `property_id=eq.${encodeURIComponent(propertyId)}`, limit: 1 }
      ).catch(() => null);

      // FRPP record — most recent fiscal_year for this property
      const frppPromise = govQuery('frpp_records',
        'frpp_id,fiscal_year,using_agency,reporting_agency,using_bureau,property_type,property_use,utilization,asset_status,num_federal_employees,num_federal_contractors,annual_rent_to_lessor,annual_maintenance,annual_operations,replacement_value,condition_index,repair_needs,building_age,congressional_district,field_office,reduce_footprint,sustainability,rent_psf',
        { filter: `property_id=eq.${encodeURIComponent(propertyId)}`, order: 'fiscal_year.desc.nullslast', limit: 1 }
      ).catch(() => null);

      // GSA lease timeline for any lease_number on this property. Need
      // the lease_numbers first; we already have them in _udCache.leases.
      const leaseNums = (_udCache.leases || [])
        .map(l => l.lease_number)
        .filter(Boolean);
      const timelinePromise = leaseNums.length
        ? govQuery('gsa_lease_timeline',
            'timeline_id,lease_number,first_snapshot_date,last_snapshot_date,snapshots_count,current_annual_rent,current_lease_rsf,current_lessor_name,current_expiration_date,last_change_type,extension_count,landlord_change_count,is_active,bridge_lease_flag',
            { filter: `lease_number=in.(${leaseNums.map(n => encodeURIComponent(n)).join(',')})`, limit: 10 }
          ).catch(() => null)
        : Promise.resolve(null);

      const [extRes, frppRes, timelineRes] = await Promise.all([extPromise, frppPromise, timelinePromise]);
      gov.extProperty = Array.isArray(extRes?.data) ? extRes.data[0] : (Array.isArray(extRes) ? extRes[0] : null);
      gov.frpp        = Array.isArray(frppRes?.data) ? frppRes.data[0] : (Array.isArray(frppRes) ? frppRes[0] : null);
      gov.gsaTimeline = Array.isArray(timelineRes?.data) ? timelineRes.data : (Array.isArray(timelineRes) ? timelineRes : []);

      // Now that we have the resolved agency name + city, fetch OPM
      // workforce rollup + agency portfolio. These are dependent on the
      // extProperty result so they run sequentially after the first
      // parallel batch.
      const agencyName = gov.extProperty?.agency_full_name || gov.extProperty?.agency || _udCache.property?.agency || null;
      const city       = _udCache.property?.city || fb.city || null;

      if (agencyName) {
        const [opmRes, portfolioRes] = await Promise.all([
          city
            ? govQuery('opm_agency_location_rollups',
                'snapshot_month,agency,subagency,state,city,employment_total,hires_total,separations_total,telework_eligible_total,telework_participants_total,retirement_eligible_total,hiring_vs_attrition_ratio',
                {
                  filter:  `agency=ilike.${encodeURIComponent(agencyName)}`,
                  filter2: `city=ilike.${encodeURIComponent(city)}`,
                  order:   'snapshot_month.desc',
                  limit:   1
                }
              ).catch(() => null)
            : Promise.resolve(null),
          govQuery('v_agency_portfolio',
            'agency_name,government_type,cabinet_department,property_count,total_sf,total_annual_rent,avg_rent_psf,active_count,vacating_count',
            { filter: `agency_name=ilike.${encodeURIComponent(agencyName)}`, limit: 1 }
          ).catch(() => null)
        ]);
        gov.opmRollup       = Array.isArray(opmRes?.data) ? opmRes.data[0] : (Array.isArray(opmRes) ? opmRes[0] : null);
        gov.agencyPortfolio = Array.isArray(portfolioRes?.data) ? portfolioRes.data[0] : (Array.isArray(portfolioRes) ? portfolioRes[0] : null);
      }
    } catch (err) {
      console.warn('Gov Operations extra data load error:', err);
    }

    _opsGovCache = gov;
    if (bodyEl) bodyEl.innerHTML = _udTabOperations();
    return;
  }

  // ── DIA BRANCH ──────────────────────────────────────────────────────
  // Resolve the medicare_id in priority order:
  //   1) cached/resolved CMS facility match (property_cms_link)
  //   2) rankings row (v_property_rankings.medicare_id)
  //   3) fallback/search-card clinic identifier
  let clinicId = (_udCache.cms && _udCache.cms.medicare_id)
    || (_udCache.rankings && _udCache.rankings.medicare_id)
    || fb.clinic_id || fb.medicare_id || fb.ccn;

  // If we have no clinicId and no rankings yet, try to auto-match now.
  // This covers the case where the user opens the Operations tab directly
  // on a property that hasn't been resolved yet. (propertyId is already
  // declared above, at the top of _udRenderOperationsAsync, for the gov
  // branch — reuse it here.)
  if (!clinicId && !_udCache.rankings && _udCache.db === 'dia' && propertyId) {
    if (bodyEl) bodyEl.innerHTML = _opsLoadingSkeleton();
    try { await _udResolveCmsFacility(propertyId); } catch (e) { console.warn(e); }
    clinicId = (_udCache.cms && _udCache.cms.medicare_id)
      || (_udCache.rankings && _udCache.rankings.medicare_id)
      || clinicId;
  }

  // If we already loaded extra data for this clinic, just render
  if (_opsExtraCache && _opsExtraCache.medicare_id === clinicId) {
    if (bodyEl) bodyEl.innerHTML = _udTabOperations();
    return;
  }

  // Show loading skeleton
  if (bodyEl) bodyEl.innerHTML = _opsLoadingSkeleton();

  // Fetch additional tables in parallel (graceful — empty array on failure)
  const extras = {};
  try {
    const promises = [];
    if (clinicId) {
      const mFilter = `medicare_id=eq.${encodeURIComponent(clinicId)}`;
      promises.push(diaQuery('facility_patient_counts', '*', { filter: mFilter, order: 'snapshot_date.asc', limit: 100 }).catch(() => []));
      promises.push(diaQuery('clinic_trends', '*', { filter: mFilter, limit: 1 }).catch(() => []));
      promises.push(diaQuery('clinic_quality_metrics', '*', { filter: mFilter, order: 'snapshot_date.desc', limit: 1 }).catch(() => []));
      promises.push(diaQuery('clinic_financial_estimates', '*', { filter: mFilter, filter2: 'is_primary=eq.true', limit: 1 }).catch(() => []));
      promises.push(diaQuery('facility_cost_reports', '*', { filter: mFilter, order: 'fiscal_year_end.desc', limit: 1 }).catch(() => []));
      promises.push(diaQuery('v_clinic_payer_mix', '*', { filter: mFilter, limit: 1 }).catch(() => []));
      promises.push(diaQuery('v_payer_mix_geo_averages', '*', { filter: mFilter, limit: 1 }).catch(() => []));
      // Lease via property_id
      const propId = _udCache.ids?.property_id || _udCache.property?.property_id;
      if (propId) {
        promises.push(diaQuery('leases', '*', { filter: `property_id=eq.${encodeURIComponent(propId)}`, limit: 5 }).catch(() => []));
      } else {
        promises.push(Promise.resolve([]));
      }
      // Hours of operation from medicare_clinics
      promises.push(diaQuery('medicare_clinics', 'medicare_id,weekly_operating_hours,late_shift,hours_json,hours_summary_text,hours_source,hours_confidence,hours_last_checked_at', { filter: mFilter, limit: 1 }).catch(() => []));
      // Competitors: same-county clinics (need county from rankings)
      const county = (_udCache.rankings && _udCache.rankings.county) || null;
      const countyState = (_udCache.rankings && _udCache.rankings.state) || null;
      if (county && countyState) {
        promises.push(diaQuery('medicare_clinics', 'medicare_id,facility_name,city,state,chain_organization,number_of_chairs,latest_estimated_patients,county', { filter: `county=eq.${encodeURIComponent(county)}`, filter2: `state=eq.${encodeURIComponent(countyState)}`, order: 'latest_estimated_patients.desc.nullslast', limit: 25 }).catch(() => []));
      } else {
        promises.push(Promise.resolve([]));
      }
      // Demographics: ZIP-level census (ACS) for catchment / demand context (client export)
      const demoZip = (_udCache.property && (_udCache.property.zip_code || _udCache.property.zip))
        || (_udCache.rankings && _udCache.rankings.zip_code) || null;
      if (demoZip) {
        promises.push(diaQuery('census_zcta_demographics', 'zip_code,total_population,median_household_income,population_65_plus,population_65_plus_pct,uninsured_rate,poverty_rate,data_year', { filter: `zip_code=eq.${encodeURIComponent(String(demoZip).slice(0, 5))}`, limit: 1 }).catch(() => []));
      } else {
        promises.push(Promise.resolve([]));
      }
    }
    const [patientHistory, trends, quality, financialDetail, costReports, payerMixData, geoPayerData, leaseData, hoursData, competitorData, demographicData] = clinicId
      ? await Promise.all(promises)
      : [[], [], [], [], [], [], [], [], [], [], []];

    // R50 — geographic BD bundle (nearby owners / sales / distance competitors).
    // Heavy haversine scan stays in the dia DB; soft-fails to null.
    const _geoPropId = _udCache.ids?.property_id || _udCache.property?.property_id;
    let _geo = null;
    if (_geoPropId) { try { _geo = await _udLoadPropertyGeo('dia', _geoPropId); } catch (_e) { _geo = null; } }

    // Enrich nearby competitors with certification_date so the export can flag
    // newly-opened facilities as a possible demand-shift driver when a clinic's
    // census is declining. Additive + graceful — never blocks the tab.
    if (_geo && Array.isArray(_geo.nearby_competitors) && _geo.nearby_competitors.length) {
      const _nearMids = _geo.nearby_competitors.map(c => c.medicare_id).filter(Boolean);
      if (_nearMids.length) {
        try {
          const _certRows = await diaQuery('medicare_clinics', 'medicare_id,certification_date,facility_name', { filter: `medicare_id=in.(${_nearMids.map(m => encodeURIComponent(m)).join(',')})`, limit: 50 }).catch(() => []);
          const _certMap = {};
          (_certRows || []).forEach(cr => { _certMap[cr.medicare_id] = cr; });
          _geo.nearby_competitors.forEach(c => { const cr = c.medicare_id && _certMap[c.medicare_id]; if (cr) { c.certification_date = cr.certification_date; if (!c.facility_name) c.facility_name = cr.facility_name; } });
        } catch (_ce) { /* additive; never break the tab */ }
      }
    }

    _opsExtraCache = {
      medicare_id: clinicId,
      patientHistory: patientHistory || [],
      trends: (trends || [])[0] || null,
      quality: (quality || [])[0] || null,
      financialDetail: (financialDetail || [])[0] || null,
      costReports: (costReports || [])[0] || null,
      payerMix: (payerMixData || [])[0] || null,
      geoPayerMix: (geoPayerData || [])[0] || null,
      lease: (leaseData || [])[0] || null,
      hours: (hoursData || [])[0] || null,
      competitors: (competitorData || []).filter(c => c.medicare_id !== clinicId),
      demographics: (demographicData || [])[0] || null,
      geo: _geo,
    };
  } catch (err) {
    console.warn('Operations extra data load error:', err);
    _opsExtraCache = { medicare_id: clinicId, patientHistory: [], trends: null, quality: null, financialDetail: null, costReports: null, payerMix: null, geoPayerMix: null, lease: null, hours: null, competitors: [], demographics: null, geo: null };
  }

  if (bodyEl) bodyEl.innerHTML = _udTabOperations();
}

/** Loading skeleton for Operations tab */
function _opsLoadingSkeleton() {
  const skeletonCard = '<div style="background:var(--s2);border-radius:10px;padding:16px;animation:pulse 1.5s ease-in-out infinite"><div style="height:12px;background:var(--s3);border-radius:4px;width:60%;margin-bottom:8px"></div><div style="height:24px;background:var(--s3);border-radius:4px;width:40%"></div></div>';
  return '<style>@keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}</style>' +
    '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:16px">' +
    skeletonCard + skeletonCard + skeletonCard +
    '</div>' +
    '<div style="background:var(--s2);border-radius:10px;padding:20px;margin-bottom:12px;animation:pulse 1.5s ease-in-out infinite"><div style="height:14px;background:var(--s3);border-radius:4px;width:30%;margin-bottom:12px"></div><div style="height:10px;background:var(--s3);border-radius:4px;width:90%;margin-bottom:8px"></div><div style="height:10px;background:var(--s3);border-radius:4px;width:75%;margin-bottom:8px"></div><div style="height:10px;background:var(--s3);border-radius:4px;width:80%"></div></div>' +
    '<div style="background:var(--s2);border-radius:10px;padding:20px;animation:pulse 1.5s ease-in-out infinite"><div style="height:14px;background:var(--s3);border-radius:4px;width:25%;margin-bottom:12px"></div><div style="height:80px;background:var(--s3);border-radius:4px;width:100%"></div></div>';
}

// ============================================================================
// FALLBACK HELPERS — render detail from search card record fields
// ============================================================================

/** Build a synthetic property object from the raw search card record */
function _udSynthPropertyFromFallback(fb, db) {
  if (!fb) return null;
  return {
    address: fb.address || fb.property_address || null,
    city: fb.city || fb.property_city || null,
    state: fb.state || fb.property_state || null,
    zip_code: fb.zip || fb.zip_code || null,
    county: fb.county || null,
    page_title: fb.page_title || fb.tenant_operator || fb.tenant_agency || fb.facility_name || fb.agency || null,
    facility_name: fb.facility_name || null,
    agency_short: fb.tenant_agency || fb.agency || null,
    agency_full: fb.tenant_agency || fb.agency_full || null,
    building_sf: fb.building_sf || fb.rsf || fb.usable_sf || fb.sq_ft || null,
    lease_number: fb.lease_number || null,
    estimated_value: fb.value || fb.estimated_value || fb.annual_rent || null,
    // Gov-specific fields from prospect_leads / ownership_history
    rent_per_sf: fb.rent_per_sf || fb.shell_rent || null,
    annual_rent: fb.annual_rent || null,
    lease_start: fb.lease_start || fb.firm_term_start || null,
    lease_end: fb.lease_end || fb.firm_term_end || null,
    term_remaining: fb.term_remaining || null,
    owner_name: fb.owner_name || fb.lessor_name || fb.grantor || null,
    buyer_name: fb.buyer_name || fb.grantee || null,
    sale_date: fb.sale_date || fb.transfer_date || null,
    sale_price: fb.sale_price || fb.price || null,
    operator_name: fb.operator_name || null,
    _synthetic: true
  };
}

/** Render header for fallback-only records (no property_id) */
function _udRenderFallbackHeader(db, fb) {
  const title = fb.page_title || fb.tenant_operator || fb.tenant_agency || fb.agency || fb.facility_name || fb.address || '(Unknown)';
  const loc = (fb.city || '') + (fb.city && fb.state ? ', ' : '') + (fb.state || '');
  const el = document.getElementById('detailHeader');
  if (!el) return;
  el.innerHTML = `
    <div class="detail-header-info">
      <div style="flex:1">
        <div class="detail-title">${esc(title)}</div>
        <div class="detail-subtitle">${esc(loc)}${fb.county ? ' &middot; ' + esc(fb.county) + ' County' : ''}</div>
      </div>
      <span class="detail-badge" style="background:${db === 'gov' ? 'var(--gov-green)' : 'var(--purple)'};color:#fff">${db === 'gov' ? 'GOV' : 'DIA'}</span>
      <button class="detail-close" onclick="closeDetail()">&times;</button>
    </div>`;
}

// ============================================================================
// TAB RENDERERS
// ============================================================================

// ============================================================================
// Data Completeness rail — Item #6 Phase A (2026-05-17)
// Reads _udCache.completeness ({ completeness_score, completeness_band,
// missing_fields: [{key,label,weight,tab}, ...] }) and renders the rail.
// Click a chip -> switches the active tab to where that field lives.
// ============================================================================
function _udRenderCompletenessRail() {
  const rail = document.getElementById('detailCompletenessRail');
  if (!rail) return;
  const cmp = _udCache && _udCache.completeness;
  if (!cmp || cmp.completeness_score == null) {
    rail.style.display = 'none';
    rail.innerHTML = '';
    return;
  }
  const score = Math.max(0, Math.min(100, Number(cmp.completeness_score) || 0));
  const band = String(cmp.completeness_band || 'poor').toLowerCase();
  let missing = Array.isArray(cmp.missing_fields) ? cmp.missing_fields : [];
  // Defensive: if Postgres returned the jsonb as a string for any reason,
  // try to parse it. (PostgREST normally returns it as a native array.)
  if (!Array.isArray(cmp.missing_fields) && typeof cmp.missing_fields === 'string') {
    try { missing = JSON.parse(cmp.missing_fields) || []; } catch (_) { missing = []; }
  }
  // QA-04 (2026-05-18): The v_property_completeness view emits null entries
  // inside missing_fields[] for fields the property HAS populated (the array
  // is positionally aligned to the field catalog rather than dense). Filter
  // them out — they would crash the chip renderer on f.key.
  missing = missing.filter(f => f && typeof f === 'object' && f.key);
  // Top 6 highest-weight missing fields (already weight-sorted by the view).
  const top = missing.slice(0, 6);

  const parts = [];
  parts.push('<div class="cr-summary">');
  parts.push(  '<span class="cr-label">Completeness</span>');
  parts.push(  '<span class="cr-score">' + score + '</span>');
  parts.push(  '<span class="cr-score-band cr-band-' + esc(band) + '">' + esc(band) + '</span>');
  parts.push('</div>');

  if (top.length === 0) {
    parts.push('<div class="cr-empty">All high-value fields populated</div>');
  } else {
    parts.push('<div class="cr-chips">');
    top.forEach(f => {
      const key = String(f.key || '');
      const label = String(f.label || key);
      const weight = Number(f.weight) || 0;
      const tab = String(f.tab || 'Overview');
      parts.push('<span class="cr-chip" title="Missing — +' + weight + ' if filled. Opens ' + esc(tab) + ' tab." onclick="_udCompletenessChipClick(&quot;' + esc(key) + '&quot;, &quot;' + esc(tab) + '&quot;)">'
        + '+ ' + esc(label)
        + '<span class="cr-chip-weight">+' + weight + '</span>'
        + '</span>');
    });
    if (missing.length > top.length) {
      parts.push('<span class="cr-empty">+' + (missing.length - top.length) + ' more</span>');
    }
    parts.push('</div>');
  }

  rail.innerHTML = parts.join('');
  rail.style.display = '';
}
window._udRenderCompletenessRail = _udRenderCompletenessRail;

function _udCompletenessChipClick(fieldKey, tab) {
  // Switch to the target tab so the broker can fill the gap inline. Future
  // enhancement: focus the specific input inside the rendered tab.
  if (typeof switchUnifiedTab === 'function' && tab) {
    switchUnifiedTab(tab);
  }
  // Telemetry hook reserved — not wired in Phase A.
  console.debug('[Completeness] chip click', fieldKey, '-> tab', tab);
}
window._udCompletenessChipClick = _udCompletenessChipClick;

// Hide the rail when the panel closes so the next open starts clean.
(function _udWireCompletenessRailClose() {
  if (window._udCompletenessRailWired) return;
  window._udCompletenessRailWired = true;
  const origClose = window.closeDetail;
  if (typeof origClose === 'function') {
    window.closeDetail = function () {
      const rail = document.getElementById('detailCompletenessRail');
      if (rail) { rail.style.display = 'none'; rail.innerHTML = ''; }
      const nab = document.getElementById('detailNextActionBar');
      if (nab) { nab.style.display = 'none'; nab.innerHTML = ''; }
      const nstep = document.getElementById('detailNextStep');
      if (nstep) { nstep.style.display = 'none'; nstep.innerHTML = ''; }
      return origClose.apply(this, arguments);
    };
  }
})();

// ============================================================================
// Sticky next-action bar — Item #8 Phase A (2026-05-17)
// Reads _udCache.nextAction (single row from v_next_best_action ordered by
// gap_value DESC). Click anywhere on the bar -> switches to the tab where
// the action lives. Companion to the completeness rail.
// ============================================================================

// Map a gap_type to the detail panel tab where the action is best executed.
function _udNextActionTabForGap(gapType) {
  const t = String(gapType || '');
  if (t === 'missing_recorded_owner') return 'Ownership & CRM';
  if (t === 'llc_research_pending')   return 'Ownership & CRM';
  if (t === 'lease_tenant_drift')     return 'Rent Roll';
  if (t === 'orphan_sale_owner')      return 'Deal History';
  if (t === 'stale_active_listing')   return 'Overview';
  if (t.startsWith('cms_chain_drift:')) return 'Operations';
  return 'Overview';
}

// Item #8 Phase B (2026-05-18): per-gap_type dispatch spec. Returns
// { label, metaSuffix } so the bar can show the right CTA text and
// destination hint without hard-coding into the renderer.
function _udNextActionDispatchFor(gapType) {
  const t = String(gapType || '');
  if (t === 'missing_recorded_owner' || t === 'llc_research_pending') {
    return { label: 'Open SoS →', metaSuffix: 'opens Secretary of State portal' };
  }
  // Item #8 Phase B-2 (2026-05-18): agency_drift gap_types get an
  // inline "Use lease value" PATCH workflow.
  if (t === 'agency_drift:agency_disagreement') {
    return { label: 'Use lease value →', metaSuffix: 'patches properties.agency from active lease' };
  }
  if (t === 'agency_drift:lease_agency_but_property_agency_null') {
    return { label: 'Fill from lease →', metaSuffix: 'fills properties.agency from active lease' };
  }
  // Item #8 Phase B-3 (2026-05-18): orphan_sale_owner — one-click backlink
  // of the most-recent sale to the property's current recorded_owner.
  if (t === 'orphan_sale_owner') {
    return { label: 'Backlink sale →', metaSuffix: "attributes sale to property's current owner" };
  }
  // Item #8 Phase B-4 (2026-05-18): tenant_drift one-click PATCHes (dia-only).
  // lease_tenant_drift: properties.tenant := lease_tenant
  // cms_chain_drift:cms_chain_but_property_tenant_null: properties.tenant := cms_chain
  if (t === 'lease_tenant_drift') {
    return { label: 'Use lease tenant →', metaSuffix: 'patches properties.tenant from active lease' };
  }
  if (t === 'cms_chain_drift:cms_chain_but_property_tenant_null') {
    return { label: 'Use CMS chain →', metaSuffix: 'fills properties.tenant from CMS chain' };
  }
  // cms_chain_drift:operator_transition_candidate stays as tab-switch —
  // it's a judgment call between property tenant and CMS chain.
  // Other gap types: existing tab-switch UX
  return { label: 'Take action →', metaSuffix: 'opens ' + _udNextActionTabForGap(t) };
}

function _udFormatNabValue(n) {
  const v = Number(n);
  if (!Number.isFinite(v) || v === 0) return '';
  const sign = '$';
  if (v >= 1e9) return sign + (v / 1e9).toFixed(1) + 'B';
  if (v >= 1e6) return sign + (v / 1e6).toFixed(v >= 10e6 ? 0 : 1) + 'M';
  if (v >= 1e3) return sign + Math.round(v / 1e3) + 'K';
  return sign + Math.round(v);
}

function _udRenderNextActionBar() {
  const bar = document.getElementById('detailNextActionBar');
  if (!bar) return;
  const next = _udCache && _udCache.nextAction;
  if (!next || !next.gap_type) {
    // No open gap for this property — hide the bar (the completeness rail
    // up top already handles the "fully populated" state).
    bar.style.display = 'none';
    bar.innerHTML = '';
    return;
  }
  const sev = String(next.gap_severity || 'low').toLowerCase();
  const action = String(next.suggested_action || '').trim()
    || String(next.gap_label || '').trim()
    || 'Open next action';
  const valStr = _udFormatNabValue(next.gap_value);
  // Item #8 Phase B (2026-05-18): dispatch UX by gap_type. The button
  // label + meta destination both reflect what clicking the button
  // will actually do, instead of the generic "Take action" + tab name.
  const dispatch = _udNextActionDispatchFor(next.gap_type);
  const meta = [];
  if (valStr) meta.push(valStr + ' value');
  meta.push(dispatch.metaSuffix);
  const metaText = meta.join(' · ');

  const parts = [];
  parts.push('<span class="nab-label">Next action</span>');
  parts.push('<span class="nab-sev-chip nab-sev-' + esc(sev) + '-chip">' + esc(sev.toUpperCase()) + '</span>');
  parts.push('<div class="nab-body">');
  parts.push(  '<div class="nab-action-text" title="' + esc(action) + '">' + esc(action) + '</div>');
  parts.push(  '<div class="nab-meta">' + esc(metaText) + '</div>');
  parts.push('</div>');
  parts.push('<button type="button" class="nab-cta" onclick="event.stopPropagation();_udNextActionClick(&quot;' + esc(next.gap_type) + '&quot;)">' + esc(dispatch.label) + '</button>');

  bar.className = 'next-action-bar nab-sev-' + esc(sev);
  bar.onclick = function () { _udNextActionClick(next.gap_type); };
  bar.innerHTML = parts.join('');
  bar.style.display = '';
}
window._udRenderNextActionBar = _udRenderNextActionBar;

// Item #8 Phase B-2 (2026-05-18): orchestrate the agency_drift resolve.
async function _udNextActionResolveAgencyDrift(gapType) {
  const prop = (_udCache && _udCache.property) || {};
  const propertyId = Number(prop.property_id);
  if (!Number.isFinite(propertyId)) {
    if (typeof showToast === 'function') showToast('Could not identify property_id', 'error');
    return;
  }
  if (_udCache.db !== 'gov') {
    if (typeof showToast === 'function') showToast('Agency drift only applies to gov properties', 'warn');
    return;
  }
  const driftKind = String(gapType).replace(/^agency_drift:/, '');

  const headers = { 'Content-Type': 'application/json' };
  if (LCC_USER.workspace_id) headers['x-lcc-workspace'] = LCC_USER.workspace_id;

  // 1. Fetch the v_gap_agency_drift row for this property to get the
  //    lease's tenant_agency / tenant_agency_full.
  let leaseAgency = null;
  let leaseAgencyFull = null;
  try {
    const r = await govQuery('v_gap_agency_drift', '*', {
      filter: 'property_id=eq.' + propertyId + '&drift_kind=eq.' + encodeURIComponent(driftKind),
      limit: 1,
    });
    const rows = Array.isArray(r) ? r : (r?.data || []);
    if (!rows.length) {
      if (typeof showToast === 'function') showToast('No active drift row found — refresh and try again', 'warn');
      return;
    }
    leaseAgency = rows[0].lease_tenant_agency || null;
    leaseAgencyFull = rows[0].lease_tenant_agency_full || null;
  } catch (e) {
    if (typeof lccReportError === 'function') lccReportError('Fetch agency drift row', e);
    return;
  }

  if (!leaseAgency && !leaseAgencyFull) {
    if (typeof showToast === 'function') showToast('Lease has no tenant_agency to apply', 'warn');
    return;
  }

  // 2. Confirm with the user.
  const display = leaseAgencyFull || leaseAgency;
  let confirmed = true;
  if (typeof asyncConfirm === 'function') {
    confirmed = await asyncConfirm('Set properties.agency to "' + display + '" from the lease?');
  }
  if (!confirmed) return;

  // 3. POST to the resolve endpoint shipped in A-5.
  try {
    const res = await fetch('/api/admin?_route=resolve-agency-drift', {
      method: 'POST', headers,
      body: JSON.stringify({
        property_id:          propertyId,
        resolution:           'use_lease',
        new_agency_canonical: leaseAgency || null,
        new_agency_full:      leaseAgencyFull || null,
      }),
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    if (typeof showToast === 'function') showToast('Updated agency from lease', 'ok');
  } catch (e) {
    if (typeof lccReportError === 'function') lccReportError('Resolve agency drift from bar', e);
    return;
  }

  // 4. Hide the bar (the gap is resolved; next view will show whatever
  //    is next-best-action for this property).
  if (_udCache) {
    _udCache.nextAction = null;
    _setUdCache(_udCache);
  }
  const bar = document.getElementById('detailNextActionBar');
  if (bar) {
    bar.style.display = 'none';
    bar.innerHTML = '';
  }
}
window._udNextActionResolveAgencyDrift = _udNextActionResolveAgencyDrift;

// Item #8 Phase B-3 (2026-05-18): single-row version of the A-1 bulk
// orphan-sale backfill. Triggered from the next-action bar when the top
// gap is orphan_sale_owner.
async function _udNextActionResolveOrphanSale() {
  const prop = (_udCache && _udCache.property) || {};
  const next = (_udCache && _udCache.nextAction) || {};
  const propertyId = Number(prop.property_id);
  // gap_pk for orphan_sale_owner IS the sale_id (text-form per the view).
  const saleId = next.gap_pk || null;
  const domain = _udCache && _udCache.db === 'dia' ? 'dialysis' :
                 (_udCache && _udCache.db === 'gov' ? 'government' : null);

  if (!Number.isFinite(propertyId) || !saleId || !domain) {
    if (typeof showToast === 'function') showToast('Missing property_id / sale_id / domain', 'error');
    return;
  }

  let confirmed = true;
  if (typeof asyncConfirm === 'function') {
    confirmed = await asyncConfirm("Backlink this sale to the property's current recorded_owner? Only works for the most-recent sale per property; earlier sales need ownership_history resolution.");
  }
  if (!confirmed) return;

  const headers = { 'Content-Type': 'application/json' };
  if (LCC_USER.workspace_id) headers['x-lcc-workspace'] = LCC_USER.workspace_id;
  try {
    const res = await fetch('/api/admin?_route=resolve-orphan-sale', {
      method: 'POST', headers,
      body: JSON.stringify({ sale_id: saleId, property_id: propertyId, domain }),
    });
    const payload = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (payload && payload.error === 'not_most_recent_sale') {
        if (typeof showToast === 'function') {
          showToast('Earlier sale — needs ownership_history resolution (most-recent sale_id: ' + payload.most_recent_sale_id + ')', 'warn');
        }
      } else if (payload && payload.error === 'no_owner_to_attribute') {
        if (typeof showToast === 'function') {
          showToast('Property has no recorded_owner yet — resolve missing_recorded_owner first', 'warn');
        }
      } else {
        throw new Error('HTTP ' + res.status);
      }
      return;
    }
    if (typeof showToast === 'function') showToast('Sale backlinked to owner', 'ok');
  } catch (e) {
    if (typeof lccReportError === 'function') lccReportError('Resolve orphan sale from bar', e);
    return;
  }

  // Hide the bar; the gap is resolved.
  if (_udCache) {
    _udCache.nextAction = null;
    _setUdCache(_udCache);
  }
  const bar = document.getElementById('detailNextActionBar');
  if (bar) {
    bar.style.display = 'none';
    bar.innerHTML = '';
  }
}
window._udNextActionResolveOrphanSale = _udNextActionResolveOrphanSale;

// Item #8 Phase B-4 (2026-05-18): lease_tenant_drift resolver (dia-only).
// Fetches lease_tenant from v_gap_lease_tenant_drift, confirms with user,
// POSTs to /api/admin?_route=resolve-lease-tenant-drift, hides the bar.
async function _udNextActionResolveLeaseTenantDrift() {
  const prop = (_udCache && _udCache.property) || {};
  const propertyId = Number(prop.property_id);
  if (!Number.isFinite(propertyId)) {
    if (typeof showToast === 'function') showToast('Missing property_id', 'error');
    return;
  }
  if (_udCache.db !== 'dia') {
    if (typeof showToast === 'function') showToast('Lease-tenant drift only applies to dia properties', 'warn');
    return;
  }

  // Fetch the lease_tenant for this property to preview in the confirm.
  let leaseTenant = null;
  try {
    const r = await diaQuery('v_gap_lease_tenant_drift', '*', {
      filter: 'property_id=eq.' + propertyId,
      limit: 1,
    });
    const rows = Array.isArray(r) ? r : (r?.data || []);
    if (rows.length) leaseTenant = (rows[0].lease_tenant || '').trim();
  } catch (e) {
    if (typeof lccReportError === 'function') lccReportError('Fetch lease-tenant drift row', e);
    return;
  }
  if (!leaseTenant) {
    if (typeof showToast === 'function') showToast('Lease has no tenant to apply', 'warn');
    return;
  }

  let confirmed = true;
  if (typeof asyncConfirm === 'function') {
    confirmed = await asyncConfirm('Set properties.tenant to "' + leaseTenant + '" from the active lease?');
  }
  if (!confirmed) return;

  const headers = { 'Content-Type': 'application/json' };
  if (LCC_USER.workspace_id) headers['x-lcc-workspace'] = LCC_USER.workspace_id;
  try {
    const res = await fetch('/api/admin?_route=resolve-lease-tenant-drift', {
      method: 'POST', headers,
      body: JSON.stringify({ property_id: propertyId }),
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    if (typeof showToast === 'function') showToast('Updated tenant from lease', 'ok');
  } catch (e) {
    if (typeof lccReportError === 'function') lccReportError('Resolve lease-tenant drift', e);
    return;
  }
  if (_udCache) {
    _udCache.nextAction = null;
    _setUdCache(_udCache);
  }
  const bar = document.getElementById('detailNextActionBar');
  if (bar) { bar.style.display = 'none'; bar.innerHTML = ''; }
}
window._udNextActionResolveLeaseTenantDrift = _udNextActionResolveLeaseTenantDrift;

// Item #8 Phase B-4 (2026-05-18): cms_chain_drift resolver for the
// 'cms_chain_but_property_tenant_null' variant only (dia-only).
async function _udNextActionResolveCmsChainDrift() {
  const prop = (_udCache && _udCache.property) || {};
  const propertyId = Number(prop.property_id);
  if (!Number.isFinite(propertyId)) {
    if (typeof showToast === 'function') showToast('Missing property_id', 'error');
    return;
  }
  if (_udCache.db !== 'dia') {
    if (typeof showToast === 'function') showToast('CMS chain drift only applies to dia properties', 'warn');
    return;
  }

  let cmsChain = null;
  try {
    const r = await diaQuery('v_gap_chain_drift', '*', {
      filter: 'property_id=eq.' + propertyId + '&drift_kind=eq.cms_chain_but_property_tenant_null',
      limit: 1,
    });
    const rows = Array.isArray(r) ? r : (r?.data || []);
    if (rows.length) cmsChain = (rows[0].cms_chain || '').trim();
  } catch (e) {
    if (typeof lccReportError === 'function') lccReportError('Fetch cms-chain drift row', e);
    return;
  }
  if (!cmsChain) {
    if (typeof showToast === 'function') showToast('No CMS chain value to apply (or this is the operator_transition_candidate variant — needs manual review)', 'warn');
    return;
  }

  let confirmed = true;
  if (typeof asyncConfirm === 'function') {
    confirmed = await asyncConfirm('Set properties.tenant to "' + cmsChain + '" from CMS chain?');
  }
  if (!confirmed) return;

  const headers = { 'Content-Type': 'application/json' };
  if (LCC_USER.workspace_id) headers['x-lcc-workspace'] = LCC_USER.workspace_id;
  try {
    const res = await fetch('/api/admin?_route=resolve-cms-chain-drift', {
      method: 'POST', headers,
      body: JSON.stringify({ property_id: propertyId }),
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    if (typeof showToast === 'function') showToast('Updated tenant from CMS chain', 'ok');
  } catch (e) {
    if (typeof lccReportError === 'function') lccReportError('Resolve cms-chain drift', e);
    return;
  }
  if (_udCache) {
    _udCache.nextAction = null;
    _setUdCache(_udCache);
  }
  const bar = document.getElementById('detailNextActionBar');
  if (bar) { bar.style.display = 'none'; bar.innerHTML = ''; }
}
window._udNextActionResolveCmsChainDrift = _udNextActionResolveCmsChainDrift;

function _udNextActionClick(gapType) {
  // Item #8 Phase B (2026-05-18): dispatch by gap_type. SoS-portal opens
  // for owner-research gaps; everything else falls through to tab-switch.
  const t = String(gapType || '');

  if (t === 'missing_recorded_owner' || t === 'llc_research_pending') {
    // Pull state + search context from the cached property + next-action row.
    const prop = (_udCache && _udCache.property) || {};
    const fallback = (_udCache && _udCache.fallback) || {};
    const next = (_udCache && _udCache.nextAction) || {};
    const state = prop.state || fallback.state || '';
    // For missing_recorded_owner the gap_label is the address; for
    // llc_research_pending it's the LLC search_name. Either way it's the
    // string we want to bias the SoS / Google search toward.
    const searchName = String(next.gap_label || '').replace(/\s*\[\d+\s*dup records\]\s*$/, '').trim()
      || prop.recorded_owner_name
      || prop.address
      || '';
    // Reuse the SoS portal map from #2B (LLC widget); fall back to Google.
    let url;
    if (typeof _lccSosPortalUrl === 'function') {
      url = _lccSosPortalUrl(state, searchName);
    } else {
      const q = encodeURIComponent('"' + searchName + '" ' + (state ? state + ' ' : '') + 'secretary of state LLC filing');
      url = 'https://www.google.com/search?q=' + q;
    }
    try { window.open(url, '_blank', 'noopener'); } catch (e) {
      console.warn('[NextAction] window.open failed:', e?.message);
    }
    console.debug('[NextAction] click', gapType, '-> SoS portal', url);
    return;
  }

  // Item #8 Phase B-2 (2026-05-18): agency_drift gap_types route to a
  // one-click "Use lease value" PATCH that reuses the resolve endpoint
  // from #A-5.
  if (t === 'agency_drift:agency_disagreement' || t === 'agency_drift:lease_agency_but_property_agency_null') {
    _udNextActionResolveAgencyDrift(gapType).catch(e => console.warn('[NextAction] agency_drift resolve failed:', e?.message));
    return;
  }

  // Item #8 Phase B-3 (2026-05-18): orphan_sale_owner — single-row
  // version of the A-1 bulk backfill. Safety: server-side checks that
  // sale is the most-recent for its property before PATCHing.
  if (t === 'orphan_sale_owner') {
    _udNextActionResolveOrphanSale().catch(e => console.warn('[NextAction] orphan_sale resolve failed:', e?.message));
    return;
  }

  // Item #8 Phase B-4 (2026-05-18): tenant_drift handlers (dia-only).
  if (t === 'lease_tenant_drift') {
    _udNextActionResolveLeaseTenantDrift().catch(e => console.warn('[NextAction] lease_tenant resolve failed:', e?.message));
    return;
  }
  if (t === 'cms_chain_drift:cms_chain_but_property_tenant_null') {
    _udNextActionResolveCmsChainDrift().catch(e => console.warn('[NextAction] cms_chain resolve failed:', e?.message));
    return;
  }
  // cms_chain_drift:operator_transition_candidate falls through to tab-switch.

  // Default: switch to the tab where this gap lives.
  const tab = _udNextActionTabForGap(gapType);
  if (typeof switchUnifiedTab === 'function' && tab) {
    switchUnifiedTab(tab);
  }
  console.debug('[NextAction] click', gapType, '-> tab', tab);
}
window._udNextActionClick = _udNextActionClick;

function _udRenderTab(tab) {
  if (!_udCache) return '<div class="detail-empty">No data loaded</div>';
  // Translate any legacy names so other call sites keep working.
  tab = _udMapLegacyTab(tab);
  switch (tab) {
    case 'Overview':        return _udTabOverview();
    case 'Rent Roll':       return _udTabRentRoll();
    case 'Operations':      return _udTabOperations();
    case 'Ownership & CRM': return _udTabOwnership();
    case 'Deal History':    return _udTabDealHistory();
    case 'Activity Log':    return _udTabActivityLog();
    default: return '<div class="detail-empty">Unknown tab</div>';
  }
}

// ─── PIPELINE STAGE PILL ─────────────────────────────────────────────────────
// Broker pipeline stages, rendered as a one-click stepper at the top of the
// sidebar. Clicking a stage advances the property and, when a Salesforce
// account is linked, fires an SF opportunity upsert via /api/sync?action=outbound.
// Stage persistence is best-effort: we PATCH properties.pipeline_stage but
// tolerate a missing column (older schemas) by falling back to in-memory only.

const _UD_PIPELINE_STAGES = [
  { key: 'prospect',       label: 'Prospect',        color: 'var(--text3)' },
  { key: 'pitched',        label: 'Pitched',         color: 'var(--accent)' },
  { key: 'engaged',        label: 'Engaged',         color: '#8b5cf6' },
  { key: 'listed',         label: 'Listed',          color: '#f59e0b' },
  { key: 'under_contract', label: 'Under Contract',  color: '#10b981' },
  { key: 'sold',           label: 'Sold',            color: 'var(--green)' },
];

/** Derive pipeline stage from whatever cache signals we already have. */
function _udInferPipelineStage() {
  if (!_udCache) return 'prospect';
  // Explicit persisted stage wins (properties.pipeline_stage or intel.pipeline_stage).
  const explicit = _udCache.property?.pipeline_stage
    || _udCache.intel?.pipeline_stage
    || _udCache.fallback?.pipeline_stage;
  if (explicit && _UD_PIPELINE_STAGES.some(s => s.key === explicit)) return explicit;

  const sales = _salesCache && _salesCache.property_id === (_udCache.ids?.property_id || _udCache.property?.property_id)
    ? _salesCache
    : null;

  // Under contract — sale event with status pending or listing marked under_contract
  const underContract = sales && (
    (sales.transactions || []).some(t => ['pending','under_contract'].includes(String(t.status || '').toLowerCase())) ||
    (sales.listings || []).some(l => String(l.status || '').toLowerCase() === 'under_contract')
  );
  if (underContract) return 'under_contract';
  // Listed — any active listing (takes priority over historical sales)
  const listed = sales && (sales.listings || []).some(l => {
    if (l.is_active === true) return true;
    if (l.is_active === false) return false;
    return !l.off_market_date;
  });
  if (listed) return 'listed';
  // Sold — completed sale event (only if NOT currently listed)
  const hasSale = sales && (sales.transactions || []).some(t => t.sale_date);
  if (hasSale) return 'sold';
  // SF-linked owner → Engaged / Pitched heuristic
  const own = _udCache.ownership || {};
  if (own.sf_opportunity_id) return 'engaged';
  if (own.sf_account_id || own.sf_company_id) return 'pitched';
  return 'prospect';
}

/** Render the pipeline-stage pill stepper (horizontal chips). */
function _udRenderPipelinePill() {
  const current = _udInferPipelineStage();
  const currentIdx = Math.max(0, _UD_PIPELINE_STAGES.findIndex(s => s.key === current));

  let html = '<div class="detail-pipeline" id="udPipelinePill" style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;padding:12px 14px;margin:0 0 14px 0;background:var(--s2);border:1px solid var(--border);border-radius:10px">';
  html += '<div style="font-size:10px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:0.6px;margin-right:4px">Pipeline</div>';

  _UD_PIPELINE_STAGES.forEach((s, i) => {
    const isActive = i === currentIdx;
    const isPast = i < currentIdx;
    const bg = isActive ? s.color : (isPast ? 'rgba(46,204,113,0.12)' : 'var(--s1,#0f172a)');
    const fg = isActive ? '#fff' : (isPast ? 'var(--text)' : 'var(--text2)');
    const border = isActive ? s.color : (isPast ? 'rgba(46,204,113,0.3)' : 'var(--border)');
    const weight = isActive ? 700 : 600;
    html += `<button type="button" onclick="_udAdvancePipelineStage('${s.key}')"
      title="${isActive ? 'Current stage' : 'Advance to ' + s.label + ' — creates/updates SF opportunity'}"
      style="padding:4px 10px;border-radius:14px;font-size:11px;font-weight:${weight};cursor:pointer;
      border:1px solid ${border};background:${bg};color:${fg};
      text-transform:uppercase;letter-spacing:0.4px;white-space:nowrap">
      ${esc(s.label)}
    </button>`;
    if (i < _UD_PIPELINE_STAGES.length - 1) {
      html += `<span style="color:var(--text3);font-size:11px">→</span>`;
    }
  });

  html += '</div>';
  return html;
}

/** Kick off a best-effort fetch for pipeline_stage from property_intel. */
async function _udHydratePipelineStage() {
  if (!_udCache) return;
  // Avoid refetching within the same panel session
  if (_udCache._pipelineHydrated) return;
  _udCache._pipelineHydrated = true;
  const propertyId = _udCache.ids?.property_id || _udCache.property?.property_id;
  if (!propertyId) return;
  try {
    const qFn = _udCache.db === 'gov' ? govQuery : diaQuery;
    const res = await qFn('property_intel', 'pipeline_stage', {
      filter: `property_id=eq.${propertyId}`,
      limit: 1,
    });
    const rows = Array.isArray(res) ? res : (res?.data || []);
    const stage = rows[0]?.pipeline_stage;
    if (stage) {
      _udCache.intel = Object.assign({}, _udCache.intel || {}, { pipeline_stage: stage });
      const pillEl = document.getElementById('udPipelinePill');
      if (pillEl) pillEl.outerHTML = _udRenderPipelinePill();
    }
  } catch (e) {
    // property_intel may not have a pipeline_stage column yet — ignore.
  }
}

/**
 * Advance the property to a new pipeline stage.
 *  1. Updates in-memory cache and re-renders the pill
 *  2. Best-effort PATCH of property_intel.pipeline_stage
 *  3. Fires SF opportunity upsert via /api/sync?action=outbound (log_to_sf)
 */
async function _udAdvancePipelineStage(stageKey) {
  if (!_udCache) return;
  const stage = _UD_PIPELINE_STAGES.find(s => s.key === stageKey);
  if (!stage) return;
  const propertyId = _udCache.ids?.property_id || _udCache.property?.property_id;
  if (!propertyId) { showToast('No property ID — cannot advance pipeline', 'error'); return; }

  // 1. Local state
  _udCache.intel = Object.assign({}, _udCache.intel || {}, { pipeline_stage: stage.key });
  const pillEl = document.getElementById('udPipelinePill');
  if (pillEl) pillEl.outerHTML = _udRenderPipelinePill();
  showToast('Pipeline stage → ' + stage.label, 'info');

  // 2. Persist (best-effort)
  try {
    const db = _udCache.db;
    const proxyBase = db === 'gov' ? '/api/gov-query' : '/api/dia-query';
    if (typeof applyInsertWithFallback === 'function') {
      await applyInsertWithFallback({
        proxyBase,
        table: 'property_intel',
        idColumn: 'property_id',
        recordIdentifier: propertyId,
        data: {
          property_id: propertyId,
          pipeline_stage: stage.key,
          pipeline_stage_updated_at: new Date().toISOString(),
        },
        source_surface: db === 'gov' ? 'gov_property_detail' : 'dialysis_property_detail',
        propagation_scope: 'pipeline_stage'
      });
    }
  } catch (e) {
    console.warn('pipeline_stage persist failed (column may not exist yet)', e);
  }

  // 3. SF opportunity upsert — only when the owner has an SF account link.
  const own = _udCache.ownership || {};
  const sfAccountId = own.sf_account_id || own.sf_company_id || null;
  const sfOpportunityId = own.sf_opportunity_id || null;
  try {
    const p = _udCache.property || {};
    const propertyName = p.page_title || p.facility_name || p.address || 'Property ' + propertyId;
    const payload = {
      command: 'upsert_sf_opportunity',
      payload: {
        property_id: propertyId,
        property_name: propertyName,
        sf_account_id: sfAccountId,
        sf_opportunity_id: sfOpportunityId,
        stage: stage.label,
        stage_key: stage.key,
        amount: p.estimated_value || null,
        close_date: stage.key === 'sold' ? new Date().toISOString().split('T')[0] : null,
      }
    };
    const res = await fetch('/api/sync?action=outbound', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (res.ok) {
      showToast('SF opportunity synced: ' + stage.label, 'success');
    } else if (res.status === 404 || res.status === 400) {
      // Round 76et-C (2026-04-29): user previously got NO feedback when the
      // SF backend wasn't handling upsert_sf_opportunity — local pill flipped
      // but Salesforce never saw the change. Now show a soft warning so the
      // user knows the local change happened but didn't sync.
      console.warn('SF opportunity upsert returned', res.status, '— backend handler may be pending');
      showToast(`Stage updated locally. Salesforce sync deferred (handler returned ${res.status}).`, 'warning');
    } else {
      // Other non-OK statuses (5xx, 401/403) — surface as an actual error
      // so the user knows their click didn't fully take effect.
      console.error('SF opportunity upsert returned', res.status);
      showToast(`Salesforce sync failed (HTTP ${res.status}). Local stage updated; retry to sync.`, 'error');
    }
  } catch (e) {
    // Round 76et-C: catch was previously silent. Network errors / DNS
    // failures / aborts now surface a clear toast so the user can retry.
    console.error('SF opportunity upsert failed', e);
    showToast('Salesforce sync error: ' + (e?.message || 'network error') + '. Local stage updated.', 'error');
  }
}

window._udAdvancePipelineStage = _udAdvancePipelineStage;

// ─── OVERVIEW TAB ────────────────────────────────────────────────────────────
// Prepends the pipeline pill + research quick links to the existing
// Property identity/KPI grid.

function _udTabOverview() {
  const pill = _udRenderPipelinePill();
  const body = _udTabProperty();
  const propertyId = _udCache?.ids?.property_id || _udCache?.property?.property_id;

  // Pre-populate the Annual Rent input with the rent-of-record projected to
  // today (same source-tier policy the Rent Roll header uses). Prefer the
  // newest active lease so a CoStar/OM row on an ancient expired lease
  // doesn't leak through as the current figure.
  const _ovLeases = Array.isArray(_udCache?.leases) ? _udCache.leases : [];
  const _ovActiveLease =
    _ovLeases.filter(l => l && String(l.status || '').toLowerCase() === 'active' && l.is_active === true)
             .sort((a, b) => String(b.lease_start || '').localeCompare(String(a.lease_start || '')))[0]
    || _ovLeases[0]
    || null;
  const _ovPicked = typeof _udPickCurrentRent === 'function'
    ? _udPickCurrentRent(_udCache?.property || null, _ovActiveLease, _udCache?.entityMeta || null)
    : null;
  const _ovPrefillRent = _ovPicked && _ovPicked.rent != null
    ? String(Math.round(Number(_ovPicked.rent) * 100) / 100)
    : '';

  let extra = '';

  // ── MARKETING COLLATERAL ────────────────────────────────────────────────
  // One-click access to OM PDF / Flyer / Marketplace (Crexi, LoopNet, …) /
  // broker microsite. Reads from the same fields the listings table uses
  // (intake_artifact_path + intake_artifact_type + source_url + tracked_urls)
  // but surfaces them prominently instead of tucked into a sticky Actions
  // column. Scott 2026-04-23: "I still don't see the section where I can
  // click on the marketing materials or OM."
  {
    const fb = _udCache?.fallback || {};
    const p  = _udCache?.property || {};
    const listingRow = {
      intake_artifact_path: fb.intake_artifact_path || p.intake_artifact_path || null,
      intake_artifact_type: fb.intake_artifact_type || p.intake_artifact_type || null,
      source_url:           fb.source_url           || p.source_url           || null,
      tracked_urls:         fb.tracked_urls         || p.tracked_urls         || null,
      // dia-side field names get normalized via extraUrlFields below
      url:                  fb.url                  || p.url                  || null,
      listing_url:          fb.listing_url          || p.listing_url          || null,
    };
    const hasAnything = !!(listingRow.intake_artifact_path || listingRow.source_url
      || listingRow.url || listingRow.listing_url
      || (Array.isArray(listingRow.tracked_urls) && listingRow.tracked_urls.length));

    if (hasAnything && typeof buildCollateralIcons === 'function') {
      extra += '<div class="detail-section">';
      extra += '<div class="detail-section-title">Marketing Collateral</div>';
      extra += '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:4px">';
      // Compact icon strip (same helper the table uses).
      extra += buildCollateralIcons(listingRow, {
        pdf:            'intake_artifact_path',
        pdfType:        'intake_artifact_type',
        primaryUrl:     'source_url',
        trackedUrls:    'tracked_urls',
        extraUrlFields: ['url', 'listing_url'],
      });
      extra += '</div>';

      // Human-readable accompanying list so the icons are self-describing.
      // Build it from the same fields; skip if nothing to show.
      const descLines = [];
      if (listingRow.intake_artifact_path) {
        const typeLabel = listingRow.intake_artifact_type === 'flyer' ? 'Flyer'
          : listingRow.intake_artifact_type === 'marketing_brochure' ? 'Marketing Brochure'
          : 'Offering Memorandum';
        descLines.push(
          `<li><a href="javascript:void(0)" onclick='openIntakeArtifact(${JSON.stringify(listingRow.intake_artifact_path)})' style="color:var(--accent)">📄 ${esc(typeLabel)} PDF</a>` +
          ` <span style="color:var(--text3);font-size:11px">(mints a 1-hour signed download)</span></li>`
        );
      }
      const urls = [];
      if (listingRow.source_url)  urls.push(listingRow.source_url);
      if (listingRow.url)         urls.push(listingRow.url);
      if (listingRow.listing_url) urls.push(listingRow.listing_url);
      if (Array.isArray(listingRow.tracked_urls)) urls.push(...listingRow.tracked_urls);
      const seenUrl = new Set();
      for (const u of urls) {
        if (!u || seenUrl.has(u)) continue;
        seenUrl.add(u);
        let host = '';
        try { host = new URL(u).hostname.replace(/^www\./,''); } catch (_) { /* */ }
        const label = host.includes('crexi')        ? 'Crexi listing'
                    : host.includes('loopnet')      ? 'LoopNet listing'
                    : host.includes('costar')       ? 'CoStar page'
                    : host.includes('brevitas')     ? 'Brevitas listing'
                    : host.includes('ten-x')        ? 'Ten-X auction'
                    : (host || 'External link');
        descLines.push(`<li><a href="${safeHref(u)}" target="_blank" rel="noopener noreferrer" style="color:var(--accent)">🔗 ${esc(label)}</a> <span style="color:var(--text3);font-size:11px">${esc(host)}</span></li>`);
      }
      if (descLines.length) {
        extra += `<ul style="margin:10px 0 0 0;padding-left:18px;font-size:12px;line-height:1.7">${descLines.join('')}</ul>`;
      }
      extra += '</div>';
    }
  }

  // ── DATA RESOLUTION STATUS ─────────────────────────────────────────────
  // Transparency panel: shows what the LCC pipeline has already wired up
  // for this property and what's still outstanding. Scott 2026-04-23:
  // "I'd like some indicator that ownership resolution has been run and
  // entity registration has been matched and no salesforce has been
  // matched so we need to create a record and open an opportunity."
  //
  // Surfaces (with color-coded chips + action buttons):
  //   1. Ownership resolution — true_owner + recorded_owner names
  //   2. LCC entity registration — entity_id + link
  //   3. Salesforce Account — sf_account_id on true_owner, with deep link
  //   4. Salesforce Opportunity — pipeline_stage proxy + open-in-SF button
  {
    const p   = _udCache?.property || {};
    const fb  = _udCache?.fallback || {};
    const own = _udCache?.ownership || null;
    // Suppress the true_owner if it's a chain-operator shell (see
    // 20260513_dia_purge_cms_operator_owner_pollution). The "Create SF
    // Account" / "Search SF" chips downstream would otherwise offer to
    // mint or look up a Salesforce account named "Fresenius Medical Care"
    // for every dialysis property — actively destructive.
    const _trueOwnerOk = !own?.true_owner_is_operator;
    const trueOwnerId     = _trueOwnerOk ? (p.true_owner_id     || fb.true_owner_id     || own?.true_owner_id     || null) : null;
    const recordedOwnerId = p.recorded_owner_id || fb.recorded_owner_id || own?.recorded_owner_id || null;
    const trueOwnerName   = _trueOwnerOk ? (own?.true_owner_name   || p.true_owner_name   || fb.true_owner_name   || p.assessed_owner || null) : null;
    const recordedName    = own?.recorded_owner_name || p.recorded_owner_name || fb.recorded_owner_name || null;
    const trueSfAccount   = own?.true_sf_acct || p.true_owner_sf_account_id || null;
    const entityMeta      = _udCache?.entityMeta || {};
    const lccEntityId     = entityMeta.entity_id || entityMeta.id || _udCache?.lccEntityId || null;
    const sfOppOpen       = !!(entityMeta.sf_opportunity_id || p.sf_opportunity_id);
    const sfInstanceUrl   = (typeof LCC_CONFIG !== 'undefined' && LCC_CONFIG.sf_instance_url) ||
                            (typeof window !== 'undefined' && window.SF_INSTANCE_URL) || '';

    const chip = (opts) => {
      const palette = {
        ok:      { bg: 'rgba(34,197,94,0.12)',  fg: '#16a34a', label: '✓' },
        warn:    { bg: 'rgba(245,158,11,0.15)', fg: '#d97706', label: '!' },
        missing: { bg: 'rgba(239,68,68,0.12)',  fg: '#dc2626', label: '×' },
      };
      const c = palette[opts.status] || palette.missing;
      return `<div style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:${c.bg};color:${c.fg};border-radius:8px;font-size:12px;flex-wrap:wrap">` +
        `<span style="font-weight:700;font-size:14px;line-height:1">${c.label}</span>` +
        `<div style="flex:1;min-width:0">` +
          `<div style="font-weight:600">${esc(opts.title)}</div>` +
          (opts.detail ? `<div style="font-size:11px;color:var(--text2);opacity:0.9">${opts.detail}</div>` : '') +
        `</div>` +
        (opts.action ? opts.action : '') +
      `</div>`;
    };

    const btn = (onclick, label, variant) => {
      const styles = variant === 'primary'
        ? 'background:var(--accent);color:#fff;border:none'
        : 'background:var(--s2);color:var(--text);border:1px solid var(--border)';
      return `<button onclick="${onclick}" style="padding:4px 10px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;${styles}">${esc(label)}</button>`;
    };

    extra += '<div class="detail-section">';
    extra += '<div class="detail-section-title">Data Resolution Status</div>';
    extra += '<div style="display:grid;grid-template-columns:1fr;gap:6px;margin-top:4px">';

    // 1) Ownership resolution
    if (trueOwnerId || recordedOwnerId) {
      const parts = [];
      if (trueOwnerName)  parts.push(`True: <strong>${esc(trueOwnerName)}</strong>`);
      if (recordedName && recordedName !== trueOwnerName) parts.push(`Recorded: <strong>${esc(recordedName)}</strong>`);
      extra += chip({
        status: 'ok',
        title:  'Ownership Resolved',
        detail: parts.join(' · ') || 'Owner chain linked',
      });
    } else {
      extra += chip({
        status: 'missing',
        title:  'Ownership Not Resolved',
        detail: 'No true_owner or recorded_owner linked yet',
        action: btn(
          `_udBtnGuard(this, function(){_udResolveOwner(${propertyId || 'null'})})`,
          'Resolve owners', 'primary'
        ),
      });
    }

    // 2) LCC entity registration
    if (lccEntityId) {
      extra += chip({
        status: 'ok',
        title:  'LCC Entity Registered',
        detail: `ID: <code style="font-family:'JetBrains Mono',monospace;font-size:10px">${esc(String(lccEntityId).slice(0,8))}…</code>`,
      });
    } else {
      extra += chip({
        status: 'warn',
        title:  'LCC Entity Not Registered',
        detail: 'No canonical entity link yet — run intake promotion or the sidebar pipeline',
      });
    }

    // 3) Salesforce Account match
    if (trueSfAccount) {
      const sfUrl = sfInstanceUrl ? `${sfInstanceUrl.replace(/\/+$/,'')}/lightning/r/Account/${trueSfAccount}/view` : '';
      const openBtn = sfUrl
        ? `<a href="${esc(sfUrl)}" target="_blank" rel="noopener noreferrer" style="padding:4px 10px;border-radius:6px;font-size:11px;font-weight:600;background:var(--s2);color:var(--accent);border:1px solid var(--border);text-decoration:none">Open in SF</a>`
        : '';
      extra += chip({
        status: 'ok',
        title:  'Salesforce Account Matched',
        detail: `ID: ${esc(trueSfAccount)}`,
        action: openBtn,
      });
    } else if (trueOwnerName) {
      extra += chip({
        status: 'missing',
        title:  'No Salesforce Account',
        detail: `Owner "${esc(trueOwnerName)}" is not linked to an SF Account — needs creation`,
        action:
          btn(`_udBtnGuard(this, function(){_udSfCreateAccount(${JSON.stringify(trueOwnerName)}, ${JSON.stringify(trueOwnerId || '')})})`, 'Create SF Account', 'primary') +
          ' ' +
          btn(`_udBtnGuard(this, function(){_udSfFindAccount(${JSON.stringify(trueOwnerName)}, ${JSON.stringify(trueOwnerId || '')})})`, 'Search SF'),
      });
    } else {
      extra += chip({
        status: 'warn',
        title:  'Salesforce Match Pending',
        detail: 'No owner identified yet — resolve ownership first',
      });
    }

    // 4) Salesforce Opportunity
    if (sfOppOpen) {
      extra += chip({
        status: 'ok',
        title:  'Salesforce Opportunity Open',
        detail: 'Tracked in prospecting pipeline',
      });
    } else {
      const canCreate = !!trueSfAccount; // need an SF account first
      extra += chip({
        status: canCreate ? 'warn' : 'missing',
        title:  'No Salesforce Opportunity',
        detail: canCreate
          ? 'SF Account linked — ready to create an Opportunity'
          : 'Create SF Account before opening Opportunity',
        action: canCreate
          ? btn(`_udBtnGuard(this, function(){_udSfCreateOpportunity(${JSON.stringify(trueSfAccount)}, ${propertyId || 'null'})})`, 'Open Opportunity', 'primary')
          : '',
      });
    }

    extra += '</div></div>';
  }

  // ── LOAN / DEBT (moved from Intel tab) ──────────────────────────────────
  if (propertyId) {
    extra += '<div class="detail-section">';
    extra += '<div class="detail-section-title" style="cursor:pointer;user-select:none" onclick="var _el=this.parentElement.querySelector(\'.intel-loan\');if(_el)_el.style.display=_el.style.display===\'none\'?\'block\':\'none\'">Loan / Debt</div>';
    extra += '<div class="intel-loan" style="display:none">';
    extra += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">';
    extra += '<div><label class="t-label">Lender</label>';
    extra += '<input id="intelLender" type="text" placeholder="Bank or fund name" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
    extra += '<div><label class="t-label">Loan Amount ($)</label>';
    extra += '<input id="intelLoanAmount" type="number" placeholder="0" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
    extra += '</div>';
    extra += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">';
    extra += '<div><label class="t-label">Interest Rate (%)</label>';
    extra += '<input id="intelInterestRate" type="number" placeholder="0.00" step="0.01" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
    extra += '<div><label class="t-label">Loan Type</label>';
    extra += '<select id="intelLoanType" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text)">';
    extra += '<option value="">—</option>';
    ['Fixed', 'Variable', 'Bridge', 'CMBS', 'Agency', 'Other'].forEach(t => {
      extra += `<option value="${t}">${t}</option>`;
    });
    extra += '</select></div>';
    extra += '</div>';
    extra += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">';
    extra += '<div><label class="t-label">Origination Date</label>';
    extra += '<input id="intelOrigDate" type="date" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
    extra += '<div><label class="t-label">Maturity Date</label>';
    extra += '<input id="intelMatDate" type="date" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
    extra += '</div>';
    extra += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">';
    extra += '<div><label class="t-label">Amortization (years)</label>';
    extra += '<input id="intelAmortization" type="number" placeholder="0" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
    extra += '<div><label class="t-label">Recourse</label>';
    extra += '<select id="intelRecourse" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text)">';
    extra += '<option value="">—</option>';
    ['Recourse', 'Non-Recourse', 'Partial'].forEach(t => {
      extra += `<option value="${t}">${t}</option>`;
    });
    extra += '</select></div>';
    extra += '</div>';
    extra += '<div style="margin-top:8px"><label class="t-label">LTV (%)</label>';
    extra += '<input id="intelLTV" type="number" placeholder="0.00" step="0.01" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
    extra += '<button onclick="_udBtnGuard(this, _intelSaveLoan)" style="margin-top:10px;width:100%;padding:8px;background:var(--accent);color:#fff;border:none;border-radius:6px;font-weight:600;font-size:12px;cursor:pointer">Save Loan Info</button>';
    extra += '</div></div>';

    // ── CASH FLOW / VALUATION (moved from Intel tab) ────────────────────────
    extra += '<div class="detail-section">';
    extra += '<div class="detail-section-title" style="cursor:pointer;user-select:none" onclick="var _el=this.parentElement.querySelector(\'.intel-cashflow\');if(_el)_el.style.display=_el.style.display===\'none\'?\'block\':\'none\'">Cash Flow / Valuation</div>';
    extra += '<div class="intel-cashflow" style="display:none">';
    extra += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">';
    extra += '<div><label class="t-label">Annual Rent / NOI ($)</label>';
    extra += '<input id="intelAnnualRent" type="number" placeholder="0" value="' + esc(_ovPrefillRent) + '" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
    extra += '<div><label class="t-label">Rent Per SF ($/SF)</label>';
    extra += '<input id="intelRentPerSF" type="number" placeholder="0.00" step="0.01" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
    extra += '</div>';
    extra += '<div style="margin-top:8px"><label class="t-label">Expense Type (NNN, Gross, etc.)</label>';
    extra += '<input id="intelExpenseType" type="text" placeholder="e.g., NNN, Modified Gross" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
    extra += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">';
    extra += '<div><label class="t-label">Estimated Value ($)</label>';
    extra += '<input id="intelEstValue" type="number" placeholder="0" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
    extra += '<div><label class="t-label">Current Cap Rate (%)</label>';
    extra += '<input id="intelCurrentCapRate" type="number" placeholder="0.00" step="0.01" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
    extra += '</div>';
    extra += '<button onclick="_udBtnGuard(this, _intelSaveCashFlow)" style="margin-top:10px;width:100%;padding:8px;background:var(--accent);color:#fff;border:none;border-radius:6px;font-weight:600;font-size:12px;cursor:pointer">Save Cash Flow</button>';
    extra += '</div></div>';

    // ── AI RESEARCH (moved from Intel tab) ──────────────────────────────────
    extra += '<div class="detail-section">';
    extra += '<div class="detail-section-title" style="cursor:pointer;user-select:none" onclick="var _el=this.parentElement.querySelector(\'.overview-ai-research\');if(_el)_el.style.display=_el.style.display===\'none\'?\'block\':\'none\'">AI Research</div>';
    extra += '<div class="overview-ai-research" style="display:none">';
    extra += _udAssistantSection('intel', 'Research Assistant', 'Turn the current notes and property context into a clean analyst summary and recommended next actions.');
    extra += _udResearchIntakeSection();
    extra += '</div></div>';
  }

  return pill + body + extra;
}

// ============================================================================
// DATA RESOLUTION ACTION HANDLERS
// ============================================================================
// These handlers are called from the Data Resolution Status chips on the
// Overview tab. Each is best-effort: on failure they toast the error so the
// user can see what went wrong without losing their place.

/**
 * Kick off owner-resolution for a gov property. Hits the intake-promoter's
 * standalone owner-resolve action, which queries true_owners +
 * recorded_owners by assessed_owner / ILIKE-fuzzy match and PATCHes the
 * property row. Also runs the SF account lookup where configured.
 */
async function _udResolveOwner(propertyId) {
  if (!propertyId) { showToast('No property_id', 'error'); return; }
  try {
    const doFetch = (typeof LCC_AUTH !== 'undefined' && LCC_AUTH.apiFetch) ? LCC_AUTH.apiFetch : fetch;
    // Uses the existing /api/ownership-reconcile endpoint (handled by
    // admin.js handleOwnershipReconcile). That endpoint scans the owner
    // tables by assessed_owner and PATCHes properties.true_owner_id /
    // recorded_owner_id; it also fires the SF account lookup where
    // SF_LOOKUP_WEBHOOK_URL is configured, populating sf_account_id on
    // matching owner rows.
    const res = await doFetch('/api/ownership-reconcile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ property_id: propertyId }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const linked = data?.true_owner_id || data?.recorded_owner_id || data?.resolved;
    showToast(
      linked ? `Owner resolved: ${data.true_owner_name || data.recorded_owner_name || 'linked'}`
             : 'Owner reconcile ran — no confident match found',
      linked ? 'success' : 'info'
    );
    if (_udCache?.db && _udCache?.ids) {
      openUnifiedDetail(_udCache.db, _udCache.ids, _udCache.fallback, window._udTab);
    }
  } catch (err) {
    console.error('[_udResolveOwner]', err);
    showToast('Owner resolution failed: ' + (err?.message || err), 'error');
  }
}

/**
 * Search Salesforce for an Account matching this owner name (via the
 * existing PA proxy). Shows the best candidate in a toast so the broker
 * can eyeball before linking.
 */
async function _udSfFindAccount(ownerName, ownerId) {
  if (!ownerName) { showToast('No owner name', 'error'); return; }
  // Queue a find_account ask for the PA flow. The same flow that performs
  // writes can also do a synchronous LIKE search; until it's polled, we
  // just tell the user the request is enqueued so they know clicks did
  // something. (Owner-reconcile already does a best-effort SF lookup
  // during its run; this button is for "re-try the search" flows.)
  try {
    const doFetch = (typeof LCC_AUTH !== 'undefined' && LCC_AUTH.apiFetch) ? LCC_AUTH.apiFetch : fetch;
    const res = await doFetch('/api/sf-sync-queue', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        kind: 'find_account',
        payload: {
          name:     ownerName,
          owner_id: ownerId || null,
          source:   'detail_pane_status_chip',
        },
      }),
    });
    if (!res.ok) {
      const txt = await res.text().catch(() => '');
      throw new Error(`HTTP ${res.status}${txt ? ': ' + txt.slice(0, 120) : ''}`);
    }
    showToast(`SF search queued for "${ownerName}" — check back in a minute.`, 'info');
  } catch (err) {
    console.error('[_udSfFindAccount]', err);
    showToast('Search failed: ' + (err?.message || err), 'error');
  }
}

/**
 * Request creation of a new Salesforce Account for this owner. Scott's
 * org uses SSO and LCC proxies SF writes via Power Automate, so this
 * dispatches to the sf_sync_flags queue rather than calling SF directly.
 * A follow-up PA flow reads the flag and creates the Account.
 */
async function _udSfCreateAccount(ownerName, ownerId) {
  if (!ownerName) { showToast('No owner name', 'error'); return; }
  try {
    const doFetch = (typeof LCC_AUTH !== 'undefined' && LCC_AUTH.apiFetch) ? LCC_AUTH.apiFetch : fetch;
    const res = await doFetch('/api/sf-sync-queue', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        kind: 'create_account',
        payload: {
          name:     ownerName,
          owner_id: ownerId || null,
          source:   'detail_pane_status_chip',
        },
      }),
    });
    if (!res.ok) {
      const txt = await res.text().catch(() => '');
      throw new Error(`HTTP ${res.status}${txt ? ': ' + txt.slice(0, 120) : ''}`);
    }
    const data = await res.json();
    showToast(
      `Queued SF Account creation for "${ownerName}" (queue ${data?.queue_id?.slice(0,8)}…). Power Automate will pick it up.`,
      'success'
    );
  } catch (err) {
    console.error('[_udSfCreateAccount]', err);
    showToast('Queue failed: ' + (err?.message || err), 'error');
  }
}

/**
 * Open a new Salesforce Opportunity against the matched Account for this
 * property. Goes through the outbound SF sync action that the pipeline
 * pill already uses to log stage changes — giving us a consistent write
 * path whether the broker advances from Prospect → Pitched via the pill
 * or clicks "Open Opportunity" here.
 */
async function _udSfCreateOpportunity(sfAccountId, propertyId) {
  if (!sfAccountId) { showToast('No SF Account linked', 'error'); return; }
  try {
    const doFetch = (typeof LCC_AUTH !== 'undefined' && LCC_AUTH.apiFetch) ? LCC_AUTH.apiFetch : fetch;
    const res = await doFetch('/api/sf-sync-queue', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        kind: 'create_opportunity',
        payload: {
          sf_account_id: sfAccountId,
          property_id:   propertyId || null,
          stage_name:    'Prospecting',
          source:        'detail_pane_status_chip',
        },
      }),
    });
    if (!res.ok) {
      const txt = await res.text().catch(() => '');
      throw new Error(`HTTP ${res.status}${txt ? ': ' + txt.slice(0, 120) : ''}`);
    }
    const data = await res.json();
    showToast(
      `Opportunity creation queued (queue ${data?.queue_id?.slice(0,8)}…). Power Automate will pick it up.`,
      'success'
    );
  } catch (err) {
    console.error('[_udSfCreateOpportunity]', err);
    showToast('Queue failed: ' + (err?.message || err), 'error');
  }
}

if (typeof window !== 'undefined') {
  window._udResolveOwner       = _udResolveOwner;
  window._udSfFindAccount      = _udSfFindAccount;
  window._udSfCreateAccount    = _udSfCreateAccount;
  window._udSfCreateOpportunity = _udSfCreateOpportunity;
}

// ─── RENT ROLL TAB ───────────────────────────────────────────────────────────
// Promotes the Lease → Rent Roll sub-view into a first-class tab. Also surfaces
// the tenant as a clickable link that opens the TenantDrawer.

function _udTabRentRoll() {
  const leases = _udCache.leases || [];
  const em = _udCache.entityMeta || {};
  const schedMap = _udCache.leaseRentSchedule instanceof Map ? _udCache.leaseRentSchedule : new Map();
  const extMap = _udCache.leaseExtensions instanceof Map ? _udCache.leaseExtensions : new Map();
  const optMap = _udCache.leaseOptions instanceof Map ? _udCache.leaseOptions : new Map();

  const hasEntityMeta = !!(em && (em.tenant_name || em.lease_commencement ||
    em.lease_expiration || em.annual_rent || em.rent_per_sf ||
    em.expense_structure || em.renewal_options || em.guarantor ||
    em.rent_escalations));

  if (leases.length === 0 && !hasEntityMeta) {
    return '<div class="detail-empty">No lease data available for Rent Roll</div>';
  }

  const leasesForRoll = leases.length > 0 ? leases : [{}];
  let html = '';
  const property = _udCache.property || {};
  const _rrDb = _udCache.db;   // Phase 4C — for the per-lease drill link

  // ── Group leases by tenant (parent_lease_id chain) ─────────────────────
  // A "chain" is the original lease + all extensions/renewals that share a
  // parent_lease_id. Leases without parent_lease_id that share the same
  // tenant name are also grouped together.
  const tenantGroups = _udGroupLeasesByTenant(leasesForRoll);

  tenantGroups.forEach((group) => {
    const { tenantName, terms, isActive } = group;
    if (!tenantName) return;

    // The "primary" term is the active one (is_active=true), or the latest by expiration
    const activeTerm = terms.find(t => t.is_active === true || t.is_active === 'true')
      || terms.reduce((best, t) => {
        const d = t.lease_expiration || t.expiration_date;
        if (!d) return best;
        if (!best) return t;
        return new Date(d) > new Date(best.lease_expiration || best.expiration_date) ? t : best;
      }, null)
      || terms[0];

    // Earliest commencement across all terms
    const earliestStart = terms.reduce((earliest, t) => {
      const d = t.lease_start || t.lease_commencement;
      if (!d) return earliest;
      if (!earliest) return d;
      return new Date(d) < new Date(earliest) ? d : earliest;
    }, null) || em.lease_commencement;

    // Latest expiration across all terms
    const latestEnd = terms.reduce((latest, t) => {
      const d = t.lease_expiration || t.expiration_date;
      if (!d) return latest;
      if (!latest) return d;
      return new Date(d) > new Date(latest) ? d : latest;
    }, null) || em.lease_expiration;

    const commencement = _fmtDate(earliestStart);
    const expiration = _fmtDate(latestEnd);
    const live = activeTerm.lease_id ? extMap.get(activeTerm.lease_id) : null;

    const picked = _udPickCurrentRent(property, activeTerm, em);
    const baseRent = activeTerm.annual_rent != null ? Number(activeTerm.annual_rent)
                   : (em.annual_rent != null ? Number(em.annual_rent) : null);
    const showBaseHint = picked && baseRent != null && !isNaN(baseRent) && picked.bumps_applied !== 0 &&
      Math.round(baseRent) !== Math.round(picked.rent);
    const rentLabel = picked && picked.bumps_applied !== 0
      ? `Current Rent (${new Date().getUTCFullYear()})`
      : 'Annual Rent';
    const psfLabel = picked && picked.bumps_applied !== 0 ? 'Current Rent / SF' : 'Rent / SF';
    const tierBadge = picked ? (
      picked.tier <= 2 ? { label: 'Anchor', color: 'var(--green,#34d399)' }
      : picked.tier === 3 ? { label: 'Lease Doc', color: 'var(--green,#34d399)' }
      : picked.tier === 4 ? { label: 'OM', color: 'var(--accent,#60a5fa)' }
      : { label: 'CoStar', color: 'var(--text3,#888)' }
    ) : null;
    const rentTooltip = picked
      ? `Tier ${picked.tier} — ${picked.source} · anchor $${fmtN(Math.round(picked.anchor_rent))} as of ${_fmtDate(picked.anchor_date)} · ${picked.bumps_applied} bump(s) applied`
      : '';

    // ── Tenant Header ─────────────────────────────────────────────────────
    html += '<div class="detail-section"><div class="detail-section-title">Tenant</div>';
    html += '<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:6px">';
    html += `<div style="font-size:15px;font-weight:700">${_udTenantLink(tenantName, activeTerm, em)}`;
    if (isActive) {
      html += ' <span style="font-size:9px;padding:2px 7px;border-radius:10px;background:var(--green);color:#fff;font-weight:600;margin-left:6px">Active</span>';
    } else {
      html += ' <span style="font-size:9px;padding:2px 7px;border-radius:10px;background:var(--red);color:#fff;font-weight:600;margin-left:6px">Expired</span>';
    }
    html += '</div>';
    // Phase 4C Unit 2 — zoom into a focused lease sub-detail (full terms,
    // escalations, guarantor, source) on the 4A back-stack.
    if (_rrDb && activeTerm && activeTerm.lease_id != null) {
      const _lid = String(activeTerm.lease_id);
      const _encLid = encodeURIComponent(_lid);
      html += `<a href="javascript:void(0)" class="ud-zoom-link" tabindex="0" data-zoom="lease:${esc(_rrDb)}:${esc(_lid)}" onclick="openSubDetail('lease','${esc(_rrDb)}',decodeURIComponent('${_encLid}'))" style="font-size:11px;font-weight:600;color:var(--accent);text-decoration:none;white-space:nowrap" title="Open lease detail">Open ↗</a>`;
    }
    if (activeTerm.guarantor || em.guarantor) {
      html += `<div class="t-meta3">Guarantor: <span class="t-body">${esc(activeTerm.guarantor || em.guarantor)}</span></div>`;
    }
    html += '</div>';

    // KPI row
    html += '<div style="display:grid;grid-template-columns:repeat(4,minmax(120px,1fr));gap:10px;font-size:12px">';
    if (commencement && commencement !== '—') html += `<div><div style="color:var(--text3);font-size:10px;text-transform:uppercase;letter-spacing:0.5px">Commencement</div><div>${esc(commencement)}</div></div>`;
    if (expiration && expiration !== '—') html += `<div><div style="color:var(--text3);font-size:10px;text-transform:uppercase;letter-spacing:0.5px">Expiration</div><div>${esc(expiration)}</div></div>`;
    if (picked && picked.rent != null) {
      const badge = tierBadge
        ? ` <span style="font-size:9px;padding:1px 5px;border-radius:3px;background:rgba(255,255,255,0.06);color:${tierBadge.color};font-weight:600;margin-left:4px" title="${esc(rentTooltip)}">${esc(tierBadge.label)}</span>`
        : '';
      const baseHint = showBaseHint ? `<div style="color:var(--text3);font-size:10px;margin-top:2px" title="${esc(rentTooltip)}">Base: ${esc(fmt(baseRent))}</div>` : '';
      html += `<div><div style="color:var(--text3);font-size:10px;text-transform:uppercase;letter-spacing:0.5px">${esc(rentLabel)}${badge}</div><div>${esc(fmt(picked.rent))}</div>${baseHint}</div>`;
    }
    if (picked && picked.rent_psf != null) html += `<div><div style="color:var(--text3);font-size:10px;text-transform:uppercase;letter-spacing:0.5px">${esc(psfLabel)}</div><div>${esc(fmt(picked.rent_psf))}</div></div>`;
    if (live) {
      html += `<div><div style="color:var(--text3);font-size:10px;text-transform:uppercase;letter-spacing:0.5px">Extensions</div><div>${fmtN(Number(live.extension_count))}${live.last_extension_date ? ' · ' + esc(_fmtDate(live.last_extension_date)) : ''}</div></div>`;
    }
    html += '</div>';

    // ── Lease Terms Timeline ──────────────────────────────────────────────
    if (terms.length > 1) {
      html += '<div style="margin-top:14px">';
      html += '<div style="font-size:11px;font-weight:600;color:var(--text2);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px">Lease Term History</div>';
      html += '<div style="position:relative;padding-left:20px">';
      html += '<div style="position:absolute;left:6px;top:4px;bottom:4px;width:2px;background:var(--border);border-radius:1px"></div>';

      // Sort terms chronologically
      const sortedTerms = [...terms].sort((a, b) => {
        const da = new Date(a.lease_start || a.lease_commencement || 0);
        const db2 = new Date(b.lease_start || b.lease_commencement || 0);
        return da - db2;
      });

      // Determine lease type + label for each row. Gov and dia use different
      // schemas:
      //   - dia:  term_type / parent_lease_id / term_number (extension chain)
      //   - gov:  is_superseding / is_first_generation / is_renewed flags,
      //           plus tenant_agency + lease_number as the natural ID.
      //
      // For gov rows we derive a human-readable label from the flags (e.g.
      // "Succession" when is_superseding=true, or fall back to the tenant
      // agency name) instead of defaulting every row to "Original (Term 1)",
      // which was the Plano bug the user flagged on 2026-04-23.
      sortedTerms.forEach((t, idx) => {
        // dia-style fields first — if present, use them as-is.
        let tType = t.term_type || (t.parent_lease_id ? 'extension' : null);
        let tNum  = t.term_number || null;

        // gov-style fallback: figure out what this lease represents in a
        // cross-generation tenant timeline.
        if (!tType) {
          if (t.is_first_generation === true) tType = 'original';
          else if (t.is_superseding === true) tType = 'succession';
          else if (t.is_renewed     === true) tType = 'renewal';
          else                                 tType = 'original';
        }
        if (!tNum) tNum = idx + 1;

        const isActiveTerm = t.is_active === true || t.is_active === 'true'
          || (t.is_active === undefined && !t.superseded_at &&
              (!t.expiration_date || new Date(t.expiration_date) >= new Date()));
        const dotColor = isActiveTerm ? 'var(--green)' : 'var(--text3)';

        // Build a readable label. Gov leases benefit from showing the
        // tenant_agency inline so a 17-year GSA timeline with two different
        // agencies doesn't read as two identical "Original (Term 1)" cards.
        const typeLabelMap = {
          original:   'Original',
          extension:  'Extension',
          renewal:    'Renewal',
          succession: 'Succession',
        };
        const typeLabel = typeLabelMap[tType] || (tType.charAt(0).toUpperCase() + tType.slice(1));
        const tenantAgency = t.tenant_agency || t.tenant_agency_full || null;
        const leaseNum     = t.lease_number || null;

        const tStart = _fmtDate(t.lease_start || t.lease_commencement || t.commencement_date);
        const tEnd = _fmtDate(t.lease_expiration || t.expiration_date);
        const tRent = t.annual_rent ? fmt(t.annual_rent) : null;
        const tArea = t.leased_area ? fmtN(t.leased_area) + ' SF' : null;
        const tExpense = t.expense_structure || null;

        html += '<div style="position:relative;margin-bottom:10px">';
        html += `<div style="position:absolute;left:-17px;top:4px;width:8px;height:8px;border-radius:50%;background:${dotColor};border:2px solid var(--bg)"></div>`;
        html += '<div style="background:var(--s2);border-radius:8px;padding:10px 12px;border:1px solid var(--border)">';
        html += `<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;flex-wrap:wrap">`;
        html += `<span style="font-size:11px;font-weight:700;color:${isActiveTerm ? 'var(--green)' : 'var(--text2)'}">${esc(typeLabel)} (Term ${tNum})</span>`;
        if (tenantAgency) html += `<span style="font-size:11px;color:var(--text);font-weight:600">${esc(tenantAgency)}</span>`;
        if (leaseNum)     html += `<span style="font-size:10px;color:var(--text3);font-family:'JetBrains Mono',monospace">${esc(leaseNum)}</span>`;
        if (isActiveTerm) html += '<span style="font-size:9px;padding:1px 5px;border-radius:3px;background:var(--green);color:#fff;font-weight:600">Active</span>';
        if (t.superseded_at) html += `<span style="font-size:9px;color:var(--text3)">Superseded ${esc(_fmtDate(t.superseded_at))}</span>`;
        html += '</div>';
        html += '<div style="font-size:12px;color:var(--text)">';
        if (tStart || tEnd) html += `<span>${esc(tStart || '?')} → ${esc(tEnd || '?')}</span>`;
        if (tRent) html += `<span style="margin-left:12px;color:var(--green)">${esc(tRent)}</span>`;
        if (tArea) html += `<span style="margin-left:12px;color:var(--text2)">${esc(tArea)}</span>`;
        if (tExpense) {
          let expDetail = tExpense;
          // Build LL responsibilities note from lease fields
          const llResp = [];
          if (t.roof_responsibility === 'landlord') llResp.push('Roof');
          if (t.structure_responsibility === 'landlord') llResp.push('Structure');
          if (t.hvac_responsibility === 'landlord') llResp.push('HVAC');
          if (t.parking_responsibility === 'landlord') llResp.push('Parking');
          if (llResp.length) expDetail += ' (LL: ' + llResp.join(', ') + ')';
          html += `<span style="margin-left:12px;color:var(--text3)">${esc(expDetail)}</span>`;
        }
        html += '</div>';
        html += '</div></div>';
      });
      html += '</div></div>';
    }

    // ── Renewal Options ───────────────────────────────────────────────────
    // Collect options from all leases in this chain
    const chainOptions = [];
    terms.forEach(t => {
      const opts = t.lease_id ? (optMap.get(t.lease_id) || []) : [];
      chainOptions.push(...opts);
    });
    // Also check renewal_options text from the lease or entity metadata
    const renewalText = activeTerm.renewal_options || activeTerm.renewal_options_short || em.renewal_options;

    if (chainOptions.length > 0 || renewalText) {
      html += '<div style="margin-top:10px">';
      html += '<div style="font-size:11px;font-weight:600;color:var(--text2);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px">Renewal / Extension Options</div>';
      if (chainOptions.length > 0) {
        chainOptions.forEach(opt => {
          const optType = opt.option_type ? (opt.option_type.charAt(0).toUpperCase() + opt.option_type.slice(1)) : 'Option';
          const optYears = opt.option_term_years ? opt.option_term_years + ' yr' : '';
          const optTerms = opt.option_rent_terms || '';
          const optExercised = opt.exercised_date ? ' — Exercised ' + _fmtDate(opt.exercised_date) : '';
          html += `<div style="font-size:12px;padding:4px 0;color:var(--text)">`;
          html += `<span style="color:var(--accent);font-weight:600">#${opt.option_number || '?'}</span> `;
          html += `${esc(optType)}${optYears ? ' · ' + esc(optYears) : ''}`;
          if (optTerms) html += ` <span class="t-muted3">· ${esc(optTerms)}</span>`;
          if (optExercised) html += `<span style="color:var(--green);font-size:11px">${esc(optExercised)}</span>`;
          html += '</div>';
        });
      } else if (renewalText) {
        html += `<div style="font-size:12px;color:var(--text)">${esc(renewalText)}</div>`;
      }
      html += '</div>';
    }

    html += '</div>'; // close detail-section
  });

  // Structured schedule with bumps (existing renderer).
  html += _udRenderRentRoll(leasesForRoll, schedMap, em);
  return html;
}

/**
 * Group leases into tenant chains based on parent_lease_id or matching tenant name.
 * Returns array of { tenantName, terms: [...leases], isActive }.
 */
function _udGroupLeasesByTenant(leases) {
  if (!Array.isArray(leases) || leases.length === 0) return [];

  // Build parent→child map
  const byId = new Map();
  leases.forEach(l => { if (l.lease_id) byId.set(l.lease_id, l); });

  // Find root lease for each lease (walk up parent chain)
  function findRoot(l) {
    const visited = new Set();
    let current = l;
    while (current.parent_lease_id && byId.has(current.parent_lease_id) && !visited.has(current.parent_lease_id)) {
      visited.add(current.lease_id);
      current = byId.get(current.parent_lease_id);
    }
    return current;
  }

  // Group by root lease_id or by tenant name
  const groups = new Map();
  leases.forEach(l => {
    let groupKey;
    if (l.parent_lease_id || (l.lease_id && leases.some(o => o.parent_lease_id === l.lease_id))) {
      // Part of a parent chain — group by root
      const root = findRoot(l);
      groupKey = 'chain:' + (root.lease_id || root.tenant || '');
    } else {
      // Standalone lease — group by tenant name
      groupKey = 'tenant:' + (l.tenant || '').toLowerCase().trim();
    }
    if (!groups.has(groupKey)) groups.set(groupKey, []);
    groups.get(groupKey).push(l);
  });

  // Convert to output format
  const result = [];
  groups.forEach((terms) => {
    // Determine tenant name from the most prominent lease
    const tenantName = terms.reduce((best, t) => t.tenant || best, '') || '';
    // Check if any term is active
    const isActive = terms.some(t => t.is_active === true || t.is_active === 'true')
      || terms.some(t => {
        const exp = t.lease_expiration || t.expiration_date;
        return exp && new Date(exp) > new Date();
      });
    result.push({ tenantName, terms, isActive });
  });

  // Sort: active tenants first, then alphabetically
  result.sort((a, b) => {
    if (a.isActive !== b.isActive) return a.isActive ? -1 : 1;
    return (a.tenantName || '').localeCompare(b.tenantName || '');
  });

  return result;
}

/** Build a clickable tenant link that opens the TenantDrawer. */
function _udTenantLink(tenantName, leaseRow, em) {
  if (!tenantName) return '<span class="t-muted3">\u2014</span>';
  const ctx = {
    name: tenantName,
    tenant_id: leaseRow?.tenant_id || em?.tenant_id || null,
    sf_contact_id: leaseRow?.tenant_sf_contact_id || null,
    sf_account_id: leaseRow?.tenant_sf_account_id || null,
    property_id: _udCache?.ids?.property_id || null,
    lease_number: leaseRow?.lease_number || _udCache?.ids?.lease_number || null,
    db: _udCache?.db || null,
  };
  const payload = encodeURIComponent(JSON.stringify(ctx));
  return `<span class="tenant-link" role="button" tabindex="0" data-tenant-ctx="${payload}"
    style="color:var(--accent);cursor:pointer;text-decoration:underline;text-decoration-style:dotted;font-weight:600"
    title="View tenant profile, contacts, and activity">${esc(tenantName)}</span>`;
}

/** Build a clickable broker link that opens the BrokerDrawer. */
function _udBrokerLink(brokerName, record) {
  if (!brokerName) return '<span class="t-muted3">\u2014</span>';
  const ctx = {
    name: brokerName,
    broker_firm: record?.broker_firm || null,
    sf_contact_id: record?.broker_sf_contact_id || null,
    sf_account_id: record?.broker_sf_account_id || null,
    property_id: _udCache?.ids?.property_id || null,
    db: _udCache?.db || null,
  };
  const payload = encodeURIComponent(JSON.stringify(ctx));
  return `<span class="broker-link" role="button" tabindex="0" data-broker-ctx="${payload}"
    style="color:var(--accent);cursor:pointer;text-decoration:underline;text-decoration-style:dotted;font-weight:600"
    title="View broker profile and activity">${esc(brokerName)}</span>`;
}

window._udTenantLink = _udTenantLink;
window._udBrokerLink = _udBrokerLink;

// ─── PROPERTY TAB ────────────────────────────────────────────────────────────

function _udTabProperty() {
  const p = _udCache.property;
  if (!p) {
    // Last resort: render raw fallback fields if available
    const fb = _udCache.fallback;
    if (fb) return _udTabFallbackSummary(fb);
    return '<div class="detail-empty">No property data available</div>';
  }

  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">Property Information</div>';
  html += '<div class="detail-grid">';

  html += _row('Address', p.address);
  html += _row('City / State', (p.city || '') + (p.state ? ', ' + p.state : ''));
  html += _row('County', p.county);
  html += _row('Zip Code', p.zip_code);
  html += _rowEditable('Building Size', p.building_sf ? fmtN(p.building_sf) + ' SF' : null, 'building_sf', 'properties');
  html += _rowEditable('Land Size', p.land_acres ? Number(p.land_acres).toFixed(2) + ' acres' : null, 'land_acres', 'properties');
  html += _row('Occupancy Type', p.is_single_tenant === true ? 'Single-Tenant' : p.is_single_tenant === false ? 'Multi-Tenant' : null);
  // Year Built: treat 0 / null / non-positive as "unknown" and offer a
  // ChromeConnector resolve affordance. DB-level the 0 backfill already ran
  // (see sql/20260415_properties_year_built_null_zero.sql), but older cached
  // rows or race conditions can still surface 0 so we guard here too.
  const yb = Number(p.year_built);
  if (p.year_built != null && p.year_built !== '' && yb >= 1600 && yb <= 2100) {
    html += _rowEditable('Year Built', yb, 'year_built', 'properties');
  } else {
    html += _rowResolve('Year Built', 'year_built');
  }
  html += _rowEditable('Building Type', p.building_type, 'building_type', 'properties');
  html += _rowEditable('Building Condition', p.building_condition, 'building_condition', 'properties');

  // Dialysis-specific — canonical field is `stations`. `number_of_chairs` is
  // a legacy alias kept around for compatibility with older CMS-derived rows.
  const stationsValue = p.stations || p.number_of_chairs;
  if (stationsValue) html += _row('Stations', fmtN(stationsValue));

  html += '</div></div>';

  // Investment section
  if (p.investment_score || p.deal_grade || p.estimated_value) {
    html += '<div class="detail-section">';
    html += '<div class="detail-section-title">Investment Summary</div>';
    html += '<div class="detail-grid">';
    html += _row('Investment Score', p.investment_score ? Number(p.investment_score).toFixed(1) : null);
    html += _row('Deal Grade', p.deal_grade);
    html += _rowMoney('Estimated Value', p.estimated_value);
    html += '</div></div>';
  }

  // Government-specific (only show for gov database)
  if (_udCache.db === 'gov' && (p.agency_short || p.agency_full || p.government_type)) {
    html += '<div class="detail-section">';
    html += '<div class="detail-section-title">Government Agency</div>';
    html += '<div class="detail-grid">';
    html += _row('Agency', p.agency_full || p.agency_short);
    html += _row('Short Name', p.agency_short);
    html += _row('Government Type', p.government_type);
    html += '</div></div>';
  }

  // Location risk
  if (p.flood_zone_desc || p.flood_risk_level) {
    html += '<div class="detail-section">';
    html += '<div class="detail-section-title">Site Risk</div>';
    html += '<div class="detail-grid">';
    html += _row('Flood Zone', p.flood_zone_desc);
    html += _row('Flood Risk', p.flood_risk_level);
    html += '</div></div>';
  }

  // ── ACTION BUTTONS ─────────────────────────────────────────────────────────
  html += _udActionButtons();

  // ── RESEARCH QUICK LINKS ──────────────────────────────────────────────────
  html += _udResearchLinks();

  return html;
}

/** Render a summary from the raw fallback record when detail views return empty */
function _udTabFallbackSummary(fb) {
  let html = '';
  if (_udCache._fallbackOnly) {
    html += '<div style="padding:8px 12px;margin-bottom:12px;background:rgba(251,191,36,0.08);border:1px solid rgba(251,191,36,0.2);border-radius:8px;font-size:12px;color:var(--text2)">Showing summary from search record. Detailed views are not yet available for this property.</div>';
  }
  html += '<div class="detail-section"><div class="detail-section-title">Property Summary</div><div class="detail-grid">';
  html += _row('Address', fb.address || fb.property_address);
  html += _row('City / State', (fb.city || '') + (fb.state ? ', ' + fb.state : ''));
  html += _row('County', fb.county);
  html += _row('Zip', fb.zip || fb.zip_code);
  html += _rowHtml('Agency / Tenant', fb.tenant_agency || fb.agency || fb.tenant_operator ? entityLink(fb.tenant_agency || fb.agency || fb.tenant_operator, 'operator', null) : '—');
  html += _row('Lease Number', fb.lease_number);
  html += _row('Building Size', fb.building_sf || fb.rsf || fb.usable_sf || fb.sq_ft ? fmtN(fb.building_sf || fb.rsf || fb.usable_sf || fb.sq_ft) + ' SF' : null);

  // Dialysis-specific fields from search results
  if (fb.facility_name) html += _row('Facility', fb.facility_name);
  if (fb.operator_name) html += _rowHtml('Operator', entityLink(fb.operator_name, 'operator', null));
  if (fb.medicare_npi || fb.npi) html += _row('NPI', fb.medicare_npi || fb.npi);
  if (fb.ccn || fb.clinic_id || fb.medicare_id) html += _row('CCN / Medicare ID', fb.ccn || fb.clinic_id || fb.medicare_id);
  if (fb.latest_total_patients) html += _row('Patients', typeof fmtN === 'function' ? fmtN(fb.latest_total_patients) : fb.latest_total_patients);
  if (fb.stations || fb.number_of_chairs) html += _row('Stations', fb.stations || fb.number_of_chairs);
  if (fb.change_type) html += _row('Inventory Status', fb.change_type);
  if (fb.signal_type) html += _row('NPI Signal', fb.signal_type);
  if (fb.review_type) html += _row('Review Type', fb.review_type);
  html += '</div></div>';

  // Financial section
  if (fb.annual_rent || fb.rent_per_sf || fb.value || fb.estimated_value || fb.sale_price) {
    html += '<div class="detail-section"><div class="detail-section-title">Financial</div><div class="detail-grid">';
    html += _rowMoney('Annual Rent', fb.annual_rent);
    html += _rowMoney('Rent / SF', fb.rent_per_sf || fb.shell_rent);
    html += _rowMoney('Estimated Value', fb.value || fb.estimated_value);
    html += _rowMoney('Sale Price', fb.sale_price || fb.price);
    html += '</div></div>';
  }

  // Lease section
  if (fb.lease_start || fb.lease_end || fb.firm_term_start || fb.firm_term_end || fb.term_remaining) {
    html += '<div class="detail-section"><div class="detail-section-title">Lease Terms</div><div class="detail-grid">';
    html += _row('Lease Start', _fmtDate(fb.lease_start || fb.firm_term_start));
    html += _row('Lease End', _fmtDate(fb.lease_end || fb.firm_term_end));
    html += _row('Term Remaining', fb.term_remaining ? fb.term_remaining + ' years' : null);
    html += '</div></div>';
  }

  // Ownership section
  if (fb.owner_name || fb.lessor_name || fb.grantor || fb.grantee) {
    html += '<div class="detail-section"><div class="detail-section-title">Ownership</div><div class="detail-grid">';
    html += _row('Owner / Lessor', fb.owner_name || fb.lessor_name || fb.grantor);
    html += _row('Buyer / Grantee', fb.buyer_name || fb.grantee);
    html += _row('Transfer Date', _fmtDate(fb.sale_date || fb.transfer_date));
    html += '</div></div>';
  }

  html += _udActionButtons();
  html += _udResearchLinks();
  return html;
}

// ─── LEASE TAB ───────────────────────────────────────────────────────────────

// ── Placeholder-tenant + dedup helpers ────────────────────────────────────
//
// Mirrors the public.is_placeholder_tenant() SQL function from the
// 20260414213000 migration. Keep the two in sync — a placeholder tenant here
// must also be flagged in SQL so the dedup + unique index stays coherent.
const _UD_PLACEHOLDER_TENANTS = new Set([
  'buyerest.', 'buyer est.', 'buyer est', 'buyerest',
  'est.', 'est', 'tbd', 'tbd.', 'unknown', 'n/a', 'na'
]);
const _UD_PLACEHOLDER_DATA_SOURCES = new Set([
  'buyer_est', 'sales_comp_est'
]);

// QA-20 (2026-05-18): _udIsPlaceholderTenant used to return true for null
// tenant. That broke government leases — GSA-tenanted properties typically
// store the agency in `guarantor` / `tenant_agency` and leave `tenant`
// itself NULL. The filter at _udFilterAndDedupeLeases then dropped those
// rows entirely, so every gov property detail panel's Rent Roll tab
// showed "No lease data available" even when v_lease_detail returned a
// real row with annual_rent, lease_start, expiration, etc.
//
// Split into two predicates:
//   _udIsPlaceholderTenant       — for ranking/sorting (null is still
//                                  back-of-the-line so a real-tenant row
//                                  wins when both exist).
//   _udIsKnownPlaceholderTenant  — only flags the explicit placeholder
//                                  strings (TBD, Unknown, BuyerEst, etc.).
//                                  Used by the filter so null tenants
//                                  survive when they're the only row.
function _udIsPlaceholderTenant(t) {
  if (t == null) return true;
  return _udIsKnownPlaceholderTenant(t);
}
function _udIsKnownPlaceholderTenant(t) {
  if (t == null) return false;
  const s = String(t).trim();
  if (!s) return true;
  const lo = s.toLowerCase();
  if (_UD_PLACEHOLDER_TENANTS.has(lo)) return true;
  if (lo.startsWith('buyer est')) return true;
  if (lo.startsWith('buyerest')) return true;
  return false;
}

/**
 * Filter out buyer-estimate / placeholder leases and dedupe remaining rows by
 * (property_id, normalized tenant, lease_start). Mirrors the DB unique index
 * so stale rows in v_lease_detail don't slip through to the UI.
 */
function _udFilterAndDedupeLeases(leases) {
  if (!Array.isArray(leases) || leases.length === 0) return [];

  const kept = [];
  const seen = new Map(); // key -> index into kept[]

  // Sort so that higher-authority rows come first (kept on collision).
  const ranked = leases.slice().sort((a, b) => {
    const tierA = _udIsPlaceholderTenant(a?.tenant) ? 2
                : _UD_PLACEHOLDER_DATA_SOURCES.has(String(a?.data_source || '').toLowerCase()) ? 1 : 0;
    const tierB = _udIsPlaceholderTenant(b?.tenant) ? 2
                : _UD_PLACEHOLDER_DATA_SOURCES.has(String(b?.data_source || '').toLowerCase()) ? 1 : 0;
    if (tierA !== tierB) return tierA - tierB;

    const confRank = (c) => ({ documented: 0, estimated: 1, inferred: 2 })[c] ?? 3;
    const cA = confRank(a?.source_confidence);
    const cB = confRank(b?.source_confidence);
    if (cA !== cB) return cA - cB;

    const aHasRent = (a?.annual_rent != null || a?.rent_psf != null) ? 0 : 1;
    const bHasRent = (b?.annual_rent != null || b?.rent_psf != null) ? 0 : 1;
    if (aHasRent !== bHasRent) return aHasRent - bHasRent;

    return (a?.lease_id || 0) - (b?.lease_id || 0);
  });

  for (const l of ranked) {
    // Filter 1: explicit buyer-estimate data_source
    const ds = String(l?.data_source || '').toLowerCase();
    if (_UD_PLACEHOLDER_DATA_SOURCES.has(ds)) continue;
    // Filter 2: placeholder tenant string (TBD, Unknown, BuyerEst, …).
    // QA-20: only KNOWN placeholders — null/empty tenants are allowed
    // through because gov leases legitimately leave tenant=null and put
    // the agency in guarantor/tenant_agency instead.
    if (_udIsKnownPlaceholderTenant(l?.tenant)) continue;

    const tenantKey = String(l.tenant).trim().toLowerCase();
    const startKey = l.lease_start || '1900-01-01';
    const key = `${l.property_id || ''}|${tenantKey}|${startKey}`;
    // Secondary key: tenant+property without start date. If we already kept
    // a row for this tenant on this property (with a real start date), skip
    // any subsequent row that has no start date (and vice-versa). This
    // collapses "same tenant, one row has commencement, other doesn't" dupes.
    const tenantOnlyKey = `${l.property_id || ''}|${tenantKey}`;
    if (seen.has(key)) continue;
    if (!l.lease_start && seen.has('__tenant__' + tenantOnlyKey)) continue;
    if (l.lease_start && seen.has('__tenant__' + tenantOnlyKey)) {
      // We have a real start date but already kept a no-start-date row.
      // Replace the earlier (weaker) row with this one.
      const prevIdx = seen.get('__tenant__' + tenantOnlyKey);
      if (prevIdx != null && kept[prevIdx] && !kept[prevIdx].lease_start) {
        kept[prevIdx] = l;
        seen.set(key, prevIdx);
        continue;
      }
    }
    seen.set(key, kept.length);
    seen.set('__tenant__' + tenantOnlyKey, kept.length);
    kept.push(l);
  }
  return kept;
}

/**
 * Best-effort fetch of lease_extensions + lease_rent_schedule for the leases
 * currently in the cache. Returns {extensions, schedule} keyed by lease_id.
 * Tolerates missing views (returns empty maps) so the Lease tab still renders
 * before the migration is applied.
 */
async function _udFetchLeaseEnrichment(leases) {
  const extensions = new Map();
  const schedule = new Map();
  if (!Array.isArray(leases) || leases.length === 0) return { extensions, schedule };

  const leaseIds = leases.map(l => l.lease_id).filter(id => id != null);
  if (leaseIds.length === 0) return { extensions, schedule };

  const idList = leaseIds.join(',');
  const filter = `lease_id=in.(${idList})`;

  // Also fetch lease_options for renewal/extension option display
  const propertyIds = [...new Set(leases.map(l => l.property_id).filter(Boolean))];
  const optFilter = propertyIds.length > 0
    ? `property_id=in.(${propertyIds.join(',')})`
    : filter;

  const [extRes, schRes, optRes] = await Promise.allSettled([
    diaQuery('v_lease_extensions_summary', '*', { filter, limit: 100 }).catch(() => []),
    diaQuery('lease_rent_schedule', '*', { filter, order: 'lease_year.asc', limit: 500 }).catch(() => []),
    diaQuery('lease_options', '*', { filter: optFilter, order: 'option_number.asc', limit: 100 }).catch(() => []),
  ]);

  const extract = (r) => {
    if (r.status !== 'fulfilled') return [];
    const v = r.value;
    if (Array.isArray(v)) return v;
    if (v && v.data) return v.data;
    return [];
  };

  for (const row of extract(extRes)) {
    extensions.set(row.lease_id, {
      extension_count: Number(row.extension_count_live ?? 0),
      last_extension_date: row.last_extension_date_live || null,
    });
  }
  for (const row of extract(schRes)) {
    if (!schedule.has(row.lease_id)) schedule.set(row.lease_id, []);
    schedule.get(row.lease_id).push(row);
  }
  // Lease options keyed by lease_id
  const options = new Map();
  for (const row of extract(optRes)) {
    const key = row.lease_id;
    if (!options.has(key)) options.set(key, []);
    options.get(key).push(row);
  }
  return { extensions, schedule, options };
}

// ── Rent source-tier policy ───────────────────────────────────────────────
//
// SINGLE SOURCE OF TRUTH for "what rent to display anywhere in the UI".
//
// Rent-of-record is picked by source tier, not by most recent write. The
// chosen anchor is then projected to the target date (today for "current
// rent", sale_date for a past sale's cap rate) using the property's
// escalation metadata. Math mirrors api/_shared/rent-projection.js
// (projectRentAtDate) — kept inlined because detail.js is a browser
// <script> and can't import the Node ESM module. Port is 1:1; if the
// server version changes, update this one too.
//
// Tier order (lower number = more authoritative):
//   1  properties.anchor_rent with anchor_rent_source='lease_confirmed'
//   2  properties.anchor_rent with anchor_rent_source='om_confirmed'
//   3  leases.annual_rent with source_confidence='documented'
//   4  leases.annual_rent with source_confidence='estimated' (OM intake)
//   5  leases.annual_rent with source_confidence='inferred' (CoStar sidebar)
//   5  properties.anchor_rent with anchor_rent_source='manual_entry'
//        (user-typed via Intel → Cash Flow when the property has no lease row)
//   6  properties.anchor_rent with anchor_rent_source='costar_stated'
//
// properties.last_known_rent is NEVER read as authoritative here — it is
// a user-entered advisory cache written by the Intel → Cash Flow form
// (detail.js _intelSaveCashFlow) that has no provenance link to the
// lease or the anchor. It can silently diverge.

function _udMonthsBetween(earlier, later) {
  let m = (later.getUTCFullYear() - earlier.getUTCFullYear()) * 12
        + (later.getUTCMonth()    - earlier.getUTCMonth());
  if (later.getUTCDate() < earlier.getUTCDate()) m -= 1;
  return m;
}

function _udCoerceDate(v) {
  if (!v) return null;
  if (v instanceof Date) return isNaN(v.getTime()) ? null : v;
  const s = /^\d{4}-\d{2}-\d{2}$/.test(v) ? v + 'T00:00:00Z' : v;
  const d = new Date(s);
  return isNaN(d.getTime()) ? null : d;
}

/** Project anchorRent from anchorDate to targetDate using step escalation
 *  anchored on leaseCommencement (so bumps fall on lease anniversaries).
 *  1:1 port of projectRentAtDate in api/_shared/rent-projection.js. */
function _udProjectRent({ anchorRent, anchorDate, targetDate, bumpPct, bumpIntervalMonths, leaseCommencement }) {
  const anchorD = _udCoerceDate(anchorDate);
  const targetD = _udCoerceDate(targetDate);
  if (anchorRent == null || !anchorD || !targetD || !bumpIntervalMonths) return null;
  const baseD = _udCoerceDate(leaseCommencement) || anchorD;
  const pct = Number(bumpPct || 0);
  const bumps = (d) => {
    const m = _udMonthsBetween(baseD, d);
    return m <= 0 ? 0 : Math.floor(m / bumpIntervalMonths);
  };
  const delta = bumps(targetD) - bumps(anchorD);
  let projected;
  if (pct === 0 || delta === 0)  projected = Number(anchorRent);
  else if (delta > 0)            projected = Number(anchorRent) * Math.pow(1 + pct, delta);
  else                           projected = Number(anchorRent) / Math.pow(1 + pct, -delta);
  return { projected_rent: Math.round(projected * 100) / 100, bumps_applied: delta };
}

/** Pick the rent-of-record for `property`+`lease` at `targetDate` (default: today)
 *  and project it. Returns { rent, rent_psf, tier, source, anchor_date, bumps_applied }
 *  or null if nothing is available. Never reads last_known_rent. */
function _udPickCurrentRent(property, lease, em, targetDate) {
  const p = property || {};
  const l = lease || {};
  const e = em || {};
  const today = targetDate || new Date().toISOString().slice(0, 10);

  const bumpPct      = p.lease_bump_pct != null ? Number(p.lease_bump_pct) : null;
  const bumpInterval = p.lease_bump_interval_mo != null ? Number(p.lease_bump_interval_mo) : null;
  const leaseStart   = l.lease_start || e.lease_commencement || p.lease_commencement || null;
  const leasedSF     = l.leased_area != null ? Number(l.leased_area)
                     : (e.sf_leased != null ? Number(e.sf_leased)
                     : (p.rba != null ? Number(p.rba) : null));

  // Tier 1/2/5/6: property.anchor_rent triplet — canonical cross-sale anchor.
  if (p.anchor_rent != null && p.anchor_rent_date && bumpPct != null && bumpInterval) {
    const src = String(p.anchor_rent_source || '').toLowerCase();
    const tier = src === 'lease_confirmed' ? 1
               : src === 'om_confirmed'    ? 2
               : src === 'manual_entry'    ? 5
               : src === 'costar_stated'   ? 6
               : 3;
    const proj = _udProjectRent({
      anchorRent: Number(p.anchor_rent),
      anchorDate: p.anchor_rent_date,
      targetDate: today,
      bumpPct, bumpIntervalMonths: bumpInterval,
      leaseCommencement: leaseStart || p.anchor_rent_date,
    });
    if (proj && proj.projected_rent != null) {
      return {
        rent:           proj.projected_rent,
        rent_psf:       leasedSF ? Math.round((proj.projected_rent / leasedSF) * 100) / 100 : null,
        tier,
        source:         `anchor:${src || 'unknown'}`,
        anchor_rent:    Number(p.anchor_rent),
        anchor_date:    p.anchor_rent_date,
        bumps_applied:  proj.bumps_applied,
      };
    }
  }

  // Tier 3/4/5: lease-row annual_rent projected from lease_start → today.
  const baseRent = l.annual_rent != null ? Number(l.annual_rent)
                 : (e.annual_rent != null ? Number(e.annual_rent) : null);
  if (baseRent != null && leaseStart) {
    const conf = String(l.source_confidence || '').toLowerCase();
    const tier = conf === 'documented' ? 3
               : conf === 'estimated'  ? 4
               : 5;
    if (bumpPct != null && bumpInterval) {
      const proj = _udProjectRent({
        anchorRent: baseRent,
        anchorDate: leaseStart,
        targetDate: today,
        bumpPct, bumpIntervalMonths: bumpInterval,
        leaseCommencement: leaseStart,
      });
      if (proj && proj.projected_rent != null) {
        return {
          rent:           proj.projected_rent,
          rent_psf:       leasedSF ? Math.round((proj.projected_rent / leasedSF) * 100) / 100 : null,
          tier,
          source:         `lease:${conf || 'unknown'}`,
          anchor_rent:    baseRent,
          anchor_date:    leaseStart,
          bumps_applied:  proj.bumps_applied,
        };
      }
    }
    // No escalation metadata — return the base rent unprojected.
    return {
      rent:           baseRent,
      rent_psf:       leasedSF ? Math.round((baseRent / leasedSF) * 100) / 100 : null,
      tier,
      source:         `lease:${conf || 'unknown'}:unprojected`,
      anchor_rent:    baseRent,
      anchor_date:    leaseStart,
      bumps_applied:  0,
    };
  }

  return null;
}

window._udPickCurrentRent = _udPickCurrentRent;
window._udProjectRent     = _udProjectRent;

// ── Rent escalation parser ────────────────────────────────────────────────
//
// Parses freeform rent-escalation strings into a structured schedule.
// Supported phrasings (case-insensitive):
//   "2% annually"            → { stepPct: 0.02, intervalYears: 1 }
//   "2% per year"            → same
//   "3.5% yearly"            → { stepPct: 0.035, intervalYears: 1 }
//   "10% every 5 years"      → { stepPct: 0.10, intervalYears: 5 }
//   "$0.50/sf per year"      → { stepPsf: 0.50, intervalYears: 1 }
//   "CPI" / "FMV" / unparsed → null (caller falls back to flat rent)
function _udParseRentEscalation(text) {
  if (!text) return null;
  const s = String(text).toLowerCase().replace(/\s+/g, ' ').trim();
  if (!s) return null;
  if (/\bcpi\b/.test(s) || /\bfmv\b/.test(s) || /\bmarket\b/.test(s)) {
    // Index-linked or FMV reset — not a deterministic step, skip.
    return null;
  }
  // "Fixed" rent — explicitly 0% bump.
  if (/\bfixed\b/.test(s) || /\bflat\b/.test(s)) {
    return { stepPct: 0, intervalYears: 1 };
  }

  // "X% every N years"
  let m = s.match(/(\d+(?:\.\d+)?)\s*%\s*every\s*(\d+)\s*year/);
  if (m) return { stepPct: parseFloat(m[1]) / 100, intervalYears: parseInt(m[2], 10) };

  // "X% annually" / "X% per year" / "X% yearly" / "X% / year"
  m = s.match(/(\d+(?:\.\d+)?)\s*%\s*(?:annually|per\s*year|yearly|\/\s*year|a\s*year|p\.?a\.?)/);
  if (m) return { stepPct: parseFloat(m[1]) / 100, intervalYears: 1 };

  // "$X/sf per year" (rent/psf bump in dollars, e.g. "$0.50/SF annually")
  m = s.match(/\$?(\d+(?:\.\d+)?)\s*\/\s*sf\s*(?:annually|per\s*year|yearly)/);
  if (m) return { stepPsf: parseFloat(m[1]), intervalYears: 1 };

  // Bare "X%" with no interval — assume annual (safe default for triple-net).
  m = s.match(/^(\d+(?:\.\d+)?)\s*%$/);
  if (m) return { stepPct: parseFloat(m[1]) / 100, intervalYears: 1 };

  return null;
}

/**
 * Build a structured rent schedule for a lease. Prefers rows from
 * lease_rent_schedule when present; otherwise synthesizes one from the
 * parsed escalation string + base rent + term.
 * Returns an array of { year, period_start, period_end, base_rent, rent_psf,
 * bump_pct, cumulative_rent, is_option_window }.
 */
function _udBuildRentSchedule(lease, storedRows, em) {
  // Resolve leased SF once — needed in both branches to backfill rent_psf when
  // upstream rows carry a base_rent but no rent_psf.
  const prop = _udCache?.property || {};
  let leasedSF = lease?.leased_area != null ? Number(lease.leased_area)
                 : (em?.sf_leased != null ? Number(em.sf_leased) : null);
  if (!leasedSF && prop.rba)           leasedSF = Number(prop.rba);
  if (!leasedSF && prop.building_sf)   leasedSF = Number(prop.building_sf);
  if (!leasedSF && prop.building_size) leasedSF = Number(prop.building_size);
  if (!(leasedSF > 0)) leasedSF = null;

  // Case 1: DB-sourced rows — use as-is (authoritative), but compute rent_psf
  // from base_rent / leasedSF when the stored row has a null rent_psf.
  if (Array.isArray(storedRows) && storedRows.length > 0) {
    let cum = 0;
    return storedRows
      .slice()
      .sort((a, b) => (a.lease_year || 0) - (b.lease_year || 0))
      .map(r => {
        const base = r.base_rent != null ? Number(r.base_rent) : null;
        cum += base || 0;
        let rentPsf = r.rent_psf != null ? Number(r.rent_psf) : null;
        if (rentPsf == null && base != null && leasedSF) {
          rentPsf = Math.round((base / leasedSF) * 100) / 100;
        }
        return {
          year: r.lease_year,
          period_start: r.period_start,
          period_end: r.period_end,
          base_rent: base,
          rent_psf: rentPsf,
          bump_pct: r.bump_pct != null ? Number(r.bump_pct) : null,
          cumulative_rent: r.cumulative_rent != null ? Number(r.cumulative_rent) : cum,
          is_option_window: !!r.is_option_window,
          source: r.source || 'db',
        };
      });
  }

  // Case 2: synthesize from base rent + escalation info.
  const baseRent =
    (lease?.annual_rent != null ? Number(lease.annual_rent) : null) ??
    (em?.annual_rent != null ? Number(em.annual_rent) : null);
  if (!baseRent || baseRent <= 0) return [];

  const start = lease?.lease_start || em?.lease_commencement || prop.lease_commencement;
  const end   = lease?.lease_expiration || em?.lease_expiration;
  if (!start) return [];
  const startD = new Date(start);
  const endD   = end ? new Date(end) : null;
  if (isNaN(startD)) return [];
  let termYears;
  if (endD && !isNaN(endD)) {
    termYears = Math.max(1, Math.round((endD - startD) / (365.25 * 24 * 3600 * 1000)));
  } else if (lease?.initial_term_years) {
    termYears = Math.round(Number(lease.initial_term_years));
  } else {
    termYears = 10; // reasonable default for NNN single-tenant
  }
  termYears = Math.min(termYears, 40); // cap runaway synthesis

  // Escalation source priority: verified lease.rent_cagr → parsed escalation
  // text → property-level lease_bump_pct / lease_bump_interval_mo → 0%.
  let stepPct = 0;
  let intervalYears = 1;
  let stepPsf = 0;
  if (lease?.rent_cagr != null) {
    stepPct = Number(lease.rent_cagr);
    intervalYears = 1;
  } else {
    const parsed =
      _udParseRentEscalation(lease?.renewal_options) ||
      _udParseRentEscalation(em?.rent_escalations);
    if (parsed) {
      stepPct = parsed.stepPct || 0;
      stepPsf = parsed.stepPsf || 0;
      intervalYears = parsed.intervalYears || 1;
    } else if (prop.lease_bump_pct != null) {
      // properties.lease_bump_pct is stored as a decimal (0.02 = 2%);
      // lease_bump_interval_mo is months (60 = every 5 years).
      stepPct = Number(prop.lease_bump_pct);
      const mo = Number(prop.lease_bump_interval_mo);
      intervalYears = Number.isFinite(mo) && mo >= 12 ? Math.max(1, Math.round(mo / 12)) : 1;
    }
  }

  const rows = [];
  let rent = baseRent;
  let cum = 0;
  for (let y = 1; y <= termYears; y++) {
    // Apply step at each interval boundary (y > 1 and (y-1) % interval === 0)
    const bumpThisYear = (y > 1 && (y - 1) % intervalYears === 0);
    if (bumpThisYear) {
      if (stepPct) rent = rent * (1 + stepPct);
      else if (stepPsf && leasedSF) rent = rent + (stepPsf * leasedSF);
    }
    const yearStart = new Date(startD);
    yearStart.setFullYear(startD.getFullYear() + (y - 1));
    const yearEnd = new Date(startD);
    yearEnd.setFullYear(startD.getFullYear() + y);
    yearEnd.setDate(yearEnd.getDate() - 1);
    cum += rent;
    rows.push({
      year: y,
      period_start: yearStart.toISOString().slice(0, 10),
      period_end:   yearEnd.toISOString().slice(0, 10),
      base_rent: Math.round(rent * 100) / 100,
      rent_psf:  leasedSF ? Math.round((rent / leasedSF) * 100) / 100 : null,
      bump_pct:  bumpThisYear ? stepPct : 0,
      cumulative_rent: Math.round(cum * 100) / 100,
      is_option_window: false,
      source: 'parsed_estimate',
    });
  }
  return rows;
}

/**
 * Render a stepped-line SVG chart of annual rent vs lease year.
 * Pure SVG — no external chart library.
 */
function _udRenderRentChart(rows) {
  if (!Array.isArray(rows) || rows.length === 0) {
    return '<div style="min-height:200px;display:flex;align-items:center;justify-content:center;color:var(--text3,#888);font-size:13px;background:var(--s2,#141414);border:1px solid var(--border,#2a2a2a);border-radius:8px">No rent data for chart</div>';
  }
  const allZero = rows.every(r => !r.base_rent);
  if (allZero) {
    return '<div style="min-height:200px;display:flex;align-items:center;justify-content:center;color:var(--text3,#888);font-size:13px;background:var(--s2,#141414);border:1px solid var(--border,#2a2a2a);border-radius:8px">No rent data for chart</div>';
  }
  const W = 560, H = 200, PAD_L = 60, PAD_R = 20, PAD_T = 20, PAD_B = 36;
  const plotW = W - PAD_L - PAD_R;
  const plotH = H - PAD_T - PAD_B;

  const rents = rows.map(r => r.base_rent || 0);
  const minR = Math.min(...rents);
  const maxR = Math.max(...rents);
  const yMin = Math.max(0, minR - (maxR - minR) * 0.1);
  const yMax = maxR + (maxR - minR) * 0.1 || maxR + 1;
  const xFor = (i) => PAD_L + (rows.length === 1 ? plotW / 2 : (i / (rows.length - 1)) * plotW);
  const yFor = (v) => PAD_T + plotH - ((v - yMin) / (yMax - yMin || 1)) * plotH;

  // Build stepped path: move to first point, then for each subsequent year,
  // draw horizontal to the new x, then vertical to the new y.
  let d = '';
  rows.forEach((r, i) => {
    const x = xFor(i);
    const y = yFor(r.base_rent || 0);
    if (i === 0) d += `M ${x.toFixed(1)} ${y.toFixed(1)}`;
    else          d += ` H ${x.toFixed(1)} V ${y.toFixed(1)}`;
  });

  // Y-axis ticks (3 levels)
  const ticks = [yMin, (yMin + yMax) / 2, yMax];
  const yAxisLabels = ticks.map(v => {
    const y = yFor(v);
    const label = '$' + Math.round(v).toLocaleString();
    return `<text x="${PAD_L - 6}" y="${(y + 4).toFixed(1)}" text-anchor="end" font-size="10" fill="var(--text3,#888)">${label}</text>` +
           `<line x1="${PAD_L}" y1="${y.toFixed(1)}" x2="${W - PAD_R}" y2="${y.toFixed(1)}" stroke="var(--border,#2a2a2a)" stroke-dasharray="2,3" stroke-width="1"/>`;
  }).join('');

  // X-axis labels (every few years)
  const xStep = rows.length <= 10 ? 1 : Math.ceil(rows.length / 10);
  const xAxisLabels = rows.map((r, i) => {
    if (i % xStep !== 0 && i !== rows.length - 1) return '';
    const x = xFor(i);
    return `<text x="${x.toFixed(1)}" y="${(H - PAD_B + 16).toFixed(1)}" text-anchor="middle" font-size="10" fill="var(--text3,#888)">Y${r.year}</text>`;
  }).join('');

  return `<div style="min-height:200px"><svg viewBox="0 0 ${W} ${H}" width="100%" height="${H}" style="max-width:100%;min-height:200px;background:var(--s2,#141414);border:1px solid var(--border,#2a2a2a);border-radius:8px">
    ${yAxisLabels}
    <path d="${d}" stroke="var(--purple,#a78bfa)" stroke-width="2" fill="none" stroke-linejoin="miter"/>
    ${rows.map((r, i) => `<circle cx="${xFor(i).toFixed(1)}" cy="${yFor(r.base_rent || 0).toFixed(1)}" r="3" fill="var(--purple,#a78bfa)"><title>Year ${r.year}: $${Math.round(r.base_rent || 0).toLocaleString()}</title></circle>`).join('')}
    ${xAxisLabels}
  </svg></div>`;
}

/**
 * Render the Rent Roll sub-view: stepped line chart + tabular schedule.
 */
function _udRenderRentRoll(leases, storedScheduleMap, em) {
  if (!Array.isArray(leases) || leases.length === 0) {
    return '<div class="detail-empty">No lease data available for Rent Roll</div>';
  }

  let html = '';
  leases.forEach((l, idx) => {
    const title = leases.length === 1 ? 'Rent Schedule' : `Rent Schedule — ${esc(l.tenant || ('Lease ' + (idx + 1)))}`;
    const storedRows = storedScheduleMap?.get(l.lease_id) || null;
    const rows = _udBuildRentSchedule(l, storedRows, em);

    html += '<div class="detail-section">';
    html += `<div class="detail-section-title">${title}</div>`;

    if (rows.length === 0) {
      html += '<div class="detail-empty" style="padding:12px">Not enough data to build a schedule. Need base rent, commencement, and either an escalation term (e.g., "2% annually") or a documented rent_cagr.</div>';
      html += '</div>';
      return;
    }

    const sourceNote = storedRows && storedRows.length
      ? 'Source: lease_rent_schedule (documented)'
      : 'Source: parsed from escalation string — estimate';
    html += `<div style="color:var(--text3,#888);font-size:11px;margin-bottom:8px">${esc(sourceNote)}</div>`;

    html += _udRenderRentChart(rows);

    html += '<div style="overflow-x:auto;margin-top:12px"><table class="detail-table" style="width:100%;border-collapse:collapse;font-size:12px">';
    html += '<thead><tr>' +
      ['Year','Period','Base Rent','Rent / SF','Bump %'].map(h =>
        `<th style="text-align:left;padding:6px 8px;border-bottom:1px solid var(--border,#2a2a2a);color:var(--text3,#888);font-weight:600">${h}</th>`
      ).join('') + '</tr></thead><tbody>';
    const curYear = new Date().getFullYear();
    rows.forEach(r => {
      const calYear = r.period_start ? new Date(r.period_start).getFullYear() : null;
      const isCurrent = calYear === curYear;
      const rowStyle = isCurrent
        ? 'background:rgba(52,211,153,0.12);font-weight:700;border-left:3px solid var(--green,#34d399)'
        : '';
      const yearLabel = isCurrent
        ? `Y${r.year} <span style="font-size:9px;background:var(--green,#34d399);color:#000;padding:1px 5px;border-radius:3px;margin-left:4px;font-weight:600">Current</span>`
        : `Y${r.year}`;
      html += `<tr style="${rowStyle}">` +
        `<td style="padding:6px 8px;border-bottom:1px solid var(--border,#2a2a2a)">${yearLabel}</td>` +
        `<td style="padding:6px 8px;border-bottom:1px solid var(--border,#2a2a2a)">${r.period_start ? _fmtDate(r.period_start) : '—'}${r.period_end ? ' → ' + _fmtDate(r.period_end) : ''}</td>` +
        `<td style="padding:6px 8px;border-bottom:1px solid var(--border,#2a2a2a)">${r.base_rent != null ? '$' + Math.round(r.base_rent).toLocaleString() : '—'}</td>` +
        `<td style="padding:6px 8px;border-bottom:1px solid var(--border,#2a2a2a)">${r.rent_psf != null ? '$' + r.rent_psf.toFixed(2) + '/SF' : '—'}</td>` +
        `<td style="padding:6px 8px;border-bottom:1px solid var(--border,#2a2a2a)">${r.bump_pct ? (r.bump_pct * 100).toFixed(1) + '%' : (r.year === 1 ? '—' : '0.0%')}</td>` +
        '</tr>';
    });
    html += '</tbody></table></div>';
    html += '</div>';
  });
  return html;
}

/** Switch the active sub-view on the Lease tab (Details | Rent Roll). */
function switchLeaseSubView(view) {
  if (!_udCache) return;
  _udCache.leaseSubView = view;
  const body = document.getElementById('detailBody');
  if (body) body.innerHTML = _udRenderTab('Lease');
}
window.switchLeaseSubView = switchLeaseSubView;

/**
 * Compute a friendly term-remaining string from an expiration date.
 * Used on the Lease tab when v_lease_detail has no computed term_remaining_years
 * (e.g. CoStar-sourced estimates on properties with no executed lease document).
 */
function termRemaining(expirationDate) {
  if (!expirationDate) return null;
  const exp = new Date(expirationDate);
  const now = new Date();
  const years = ((exp - now) / (1000 * 60 * 60 * 24 * 365.25)).toFixed(1);
  return parseFloat(years) > 0 ? years + ' yrs remaining' : 'Expired';
}

/** Small amber "Est." badge marking a field as a CoStar estimate. */
function _udEstBadge() {
  return '<span style="display:inline-block;margin-left:6px;padding:1px 6px;border-radius:4px;background:rgba(245,158,11,0.15);color:#f59e0b;border:1px solid rgba(245,158,11,0.35);font-size:10px;font-weight:600;letter-spacing:0.3px;vertical-align:middle" title="Estimated from CoStar metadata — no executed lease document on file">Est.</span>';
}

/** Render a lease row whose value may be a raw-HTML string, with an optional Est. badge. */
function _udLeaseRowH(label, valueHtml, isEst) {
  if (valueHtml == null || valueHtml === '' || valueHtml === '—') return '';
  const badge = isEst ? _udEstBadge() : '';
  return `<div class="detail-row">
    <div class="detail-lbl">${esc(label)}</div>
    <div class="detail-val">${valueHtml}${badge}</div>
  </div>`;
}

function _udTabLease() {
  const leases = _udCache.leases || [];
  const em = _udCache.entityMeta || {};
  const extMap = _udCache.leaseExtensions instanceof Map ? _udCache.leaseExtensions : new Map();
  const schedMap = _udCache.leaseRentSchedule instanceof Map ? _udCache.leaseRentSchedule : new Map();
  const hasEntityMeta = !!(em && (em.tenant_name || em.lease_commencement ||
    em.lease_expiration || em.annual_rent || em.rent_per_sf ||
    em.expense_structure || em.renewal_options || em.guarantor ||
    em.rent_escalations));

  // Sub-view toggle (Details | Rent Roll). Default to Details.
  const subView = _udCache.leaseSubView === 'rentroll' ? 'rentroll' : 'details';
  const subTabBar = `
    <div style="display:flex;gap:8px;padding:8px 0 12px;border-bottom:1px solid var(--border,#2a2a2a);margin-bottom:12px">
      <button class="detail-subtab" onclick="switchLeaseSubView('details')" style="padding:6px 12px;border-radius:6px;border:1px solid ${subView === 'details' ? 'var(--purple,#a78bfa)' : 'var(--border,#2a2a2a)'};background:${subView === 'details' ? 'rgba(167,139,250,0.12)' : 'transparent'};color:${subView === 'details' ? 'var(--purple,#a78bfa)' : 'var(--text,#e5e5e5)'};font-size:12px;font-weight:600;cursor:pointer">Details</button>
      <button class="detail-subtab" onclick="switchLeaseSubView('rentroll')" style="padding:6px 12px;border-radius:6px;border:1px solid ${subView === 'rentroll' ? 'var(--purple,#a78bfa)' : 'var(--border,#2a2a2a)'};background:${subView === 'rentroll' ? 'rgba(167,139,250,0.12)' : 'transparent'};color:${subView === 'rentroll' ? 'var(--purple,#a78bfa)' : 'var(--text,#e5e5e5)'};font-size:12px;font-weight:600;cursor:pointer">Rent Roll</button>
    </div>`;

  if (subView === 'rentroll') {
    if (leases.length === 0 && !hasEntityMeta) {
      return subTabBar + '<div class="detail-empty">No lease data available for Rent Roll</div>';
    }
    const leasesForRoll = leases.length > 0 ? leases : [{}];
    return subTabBar + _udRenderRentRoll(leasesForRoll, schedMap, em);
  }

  // If no lease view data AND no CoStar metadata, try the search fallback record
  if (leases.length === 0 && !hasEntityMeta) {
    const fb = _udCache.fallback;
    if (fb && (fb.lease_start || fb.lease_end || fb.firm_term_start || fb.annual_rent || fb.lease_number)) {
      let html = '<div class="detail-section"><div class="detail-section-title">Lease Details (from search record)</div><div class="detail-grid">';
      html += _row('Lease Number', fb.lease_number);
      html += _row('Tenant', fb.tenant_agency || fb.tenant_operator);
      html += _row('Lease Start', _fmtDate(fb.lease_start || fb.firm_term_start));
      html += _row('Lease End', _fmtDate(fb.lease_end || fb.firm_term_end));
      html += _row('Term Remaining', fb.term_remaining ? fb.term_remaining + ' years' : null);
      html += _rowMoney('Annual Rent', fb.annual_rent);
      html += _rowMoney('Rent / SF', fb.rent_per_sf || fb.shell_rent);
      html += _row('Lessor', fb.lessor_name);
      html += '</div></div>';
      return html;
    }
    return '<div class="detail-empty">No lease data available</div>';
  }

  // If we only have entity metadata (no v_lease_detail rows), synthesize one
  // empty lease so the renderer produces a single estimates-only section.
  const leasesToRender = leases.length > 0 ? leases : [{}];
  const estimatesOnly = leases.length === 0;

  // Details sub-view always prefixed by the sub-tab bar.
  let _outHtml = subTabBar;

  // Pick verified lease field if present, else fall through to the CoStar
  // estimate from entity metadata. Returns { html, est } where est=true when
  // the value came from metadata and should get an "Est." badge.
  const pick = (verified, estimate, format) => {
    if (verified != null && verified !== '') {
      return { html: format ? format(verified) : esc(String(verified)), est: false };
    }
    if (estimate != null && estimate !== '') {
      return { html: format ? format(estimate) : esc(String(estimate)), est: true };
    }
    return { html: null, est: false };
  };
  const dateFmt = (v) => esc(_fmtDate(v));
  const moneyFmt = (v) => esc(fmt(v));

  let html = '';

  leasesToRender.forEach((l, idx) => {
    const isOnly = leasesToRender.length === 1;
    html += '<div class="detail-section">';
    html += `<div class="detail-section-title">${isOnly ? 'Lease Details' : 'Lease ' + (idx + 1)}</div>`;
    html += '<div class="detail-grid">';

    // Term Remaining: prefer verified term_remaining_years from the view,
    // else compute from whichever expiration date we have (verified or estimate).
    let termRow;
    if (l.term_remaining_years != null) {
      const n = Number(l.term_remaining_years);
      termRow = {
        html: n < 0 ? '<span style="color:var(--red)">Expired</span>' : esc(n.toFixed(1) + ' yrs remaining'),
        est: false
      };
    } else {
      const exp = l.lease_expiration || em.lease_expiration;
      const tr = termRemaining(exp);
      termRow = {
        html: tr == null ? null : (tr === 'Expired' ? '<span style="color:var(--red)">Expired</span>' : esc(tr)),
        est: !l.lease_expiration && !!em.lease_expiration
      };
    }

    // Escalations: verified rent_cagr from v_lease_detail takes priority;
    // otherwise fall through to the freeform CoStar escalations string.
    const esc_row = (l.rent_cagr != null)
      ? { html: esc((Number(l.rent_cagr) * 100).toFixed(2) + '%'), est: false }
      : pick(null, em.rent_escalations);

    const dataSourceRow = l.data_source
      ? { html: esc(l.data_source), est: false }
      : (estimatesOnly ? { html: esc('costar_estimate'), est: true } : { html: null, est: false });

    const leaseSections = [
      { label: 'Tenant',            row: pick(l.tenant, em.tenant_name) },
      { label: 'Commencement',      row: pick(l.lease_start, em.lease_commencement, dateFmt) },
      { label: 'Expiration',        row: pick(l.lease_expiration, em.lease_expiration, dateFmt) },
      { label: 'Term Remaining',    row: termRow },
      { label: 'Annual Rent',       row: pick(l.annual_rent, em.annual_rent, moneyFmt) },
      { label: 'Rent PSF',          row: pick(l.rent_psf, em.rent_per_sf, moneyFmt) },
      { label: 'Expense Structure', row: (function() {
        const base = pick(l.expense_structure, em.expense_structure);
        if (!base.html) return base;
        const llR = [];
        if (l.roof_responsibility === 'landlord') llR.push('Roof');
        if (l.structure_responsibility === 'landlord') llR.push('Structure');
        if (l.hvac_responsibility === 'landlord') llR.push('HVAC');
        if (l.parking_responsibility === 'landlord') llR.push('Parking');
        if (llR.length) base.html += ' <span style="color:var(--text3);font-size:11px">(LL: ' + esc(llR.join(', ')) + ')</span>';
        return base;
      })() },
      { label: 'Renewal Options',   row: pick(l.renewal_options, em.renewal_options) },
      { label: 'Guarantor',         row: pick(l.guarantor, em.guarantor) },
      { label: 'Escalations',       row: esc_row },
      { label: 'Data Source',       row: dataSourceRow },
    ];

    for (const s of leaseSections) {
      html += _udLeaseRowH(s.label, s.row.html, s.row.est);
    }

    // Preserve secondary verified-lease fields when we have a real lease record.
    if (!estimatesOnly) {
      html += _row('Guarantor Type', l.guarantor_type);
      html += _row('Original Occupancy', _fmtDate(l.original_occupancy));

      // Extension count + last extension — prefer the LIVE values from
      // v_lease_extensions_summary. Fall back only when the enrichment fetch
      // hasn't landed yet (still loading). Never display a value derived from
      // v_lease_detail's stale columns (which defaulted to 3 and/or the
      // commencement date when unknown).
      const live = extMap.get(l.lease_id);
      if (live) {
        // Authoritative: 0 shows as "0"; date is null when no rows exist,
        // which _row() filters out entirely (no row rendered).
        html += _row('Last Extension', live.last_extension_date ? _fmtDate(live.last_extension_date) : null);
        html += _row('No. of Extensions', fmtN(Number(live.extension_count)));
      } else {
        // Enrichment still loading — leave both rows empty rather than
        // render the stale v_lease_detail values.
      }

      html += _row('Termination', _fmtDate(l.termination_date));
      html += _row('Initial Term', l.initial_term_years ? Number(l.initial_term_years).toFixed(1) + ' yrs' : null);
      html += _row('Total Term', l.total_term_years ? Number(l.total_term_years).toFixed(1) + ' yrs' : null);
      html += _row('No. of Renewals', l.num_renewals);
      html += _rowMoney('Future Rent / SF', l.future_rent_psf);
      html += _row('Lease Structure', l.lease_structure);

      // Flags
      const flags = [];
      if (l.is_renewed) flags.push('Renewed');
      if (l.is_first_generation) flags.push('1st Gen');
      if (l.is_superseding) flags.push('Superseding');
      if (flags.length) html += _row('Flags', flags.join(' · '));
    }

    html += '</div></div>';
  });

  return _outHtml + html;
}

// ─── OPERATIONS TAB ──────────────────────────────────────────────────────────

function _udTabOperations() {
  const db = _udCache.db;
  const rankings = _udCache.rankings;

  // ── GOV operations: agency context, tenant succession, fed-tenant links ─
  // Previously this tab was an empty-state for gov. That left a visible gap
  // on every GSA listing. Surface what we already have from the cache
  // (agency, agency_full, government_type, firm_term_remaining, lease
  // chronology) plus quick-jump links to the federal workforce / budget
  // context tools a broker would normally hit manually (OPM FedScope for
  // employee counts, USAspending for obligations, Beta.SAM for contract
  // history). This is NOT a full build-out (see Task #43) but beats blank.
  if (db === 'gov') {
    const p = _udCache.property || {};
    const fb = _udCache.fallback || {};
    const leases = (_udCache.leases || []).slice().sort((a, b) => {
      const da = new Date(a.commencement_date || a.lease_start || 0);
      const db2 = new Date(b.commencement_date || b.lease_start || 0);
      return da - db2;
    });

    const agency      = p.agency || p.tenant_agency || fb.agency || fb.tenant_agency || null;
    const agencyFull  = p.agency_full_name || p.agency_full || fb.agency_full_name || fb.agency_full || null;
    const govType     = p.government_type || fb.government_type || null;
    const state       = p.state || fb.state || null;
    const city        = p.city  || fb.city  || null;
    const firmTermRem = p.firm_term_remaining != null ? parseFloat(p.firm_term_remaining) : null;
    const termRem     = p.term_remaining != null ? parseFloat(p.term_remaining) : null;
    const representingAgency = p.representing_agency || leases[leases.length - 1]?.representing_agency || null;

    const uniqTenants = new Set(leases.map(l => l.tenant_agency || l.tenant).filter(Boolean));
    const tenantCount = uniqTenants.size;

    const fmtYr = (v) => (v == null ? '—' : parseFloat(v).toFixed(1) + ' yr');
    const fmtMoney = (v) => (v == null ? '—' : '$' + Number(v).toLocaleString('en-US', { maximumFractionDigits: 0 }));
    const fmtNum   = (v) => (v == null ? '—' : Number(v).toLocaleString('en-US'));

    // Pull the lazy-loaded gov cache (FRPP, OPM, agency portfolio, timeline).
    // When absent (cache miss, dia open, or Operations tab never clicked),
    // the extra cards below simply don't render — the MVP agency + chronology
    // sections still show.
    const gov  = (typeof _opsGovCache !== 'undefined' && _opsGovCache && _opsGovCache.property_id === (p.property_id || fb.property_id || _udCache.ids?.property_id))
      ? _opsGovCache : null;
    const ext  = gov?.extProperty || {};
    const frpp = gov?.frpp || null;
    const opm  = gov?.opmRollup || null;
    const agp  = gov?.agencyPortfolio || null;
    const timeline = gov?.gsaTimeline || [];

    // Resolve the best agency name + employee count with the enriched data
    // layered on top.
    const federalEmployees = ext.federal_employee_count ?? (frpp?.num_federal_employees) ?? null;
    const opmHeadcount     = ext.opm_headcount ?? null;
    const workforceTrend   = ext.workforce_trend || null;
    const agencyRiskLevel  = ext.agency_risk_level || null;
    const cabinetDept      = agp?.cabinet_department || null;
    const frppId           = ext.linked_frpp_id || frpp?.real_property_uid || null;

    let h = '';

    // Agency header card
    h += '<div class="detail-section">';
    h += '<div class="detail-section-title">Agency Operation</div>';
    h += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:6px;font-size:13px">';
    const row = (label, val) =>
      `<div><div style="font-size:10px;text-transform:uppercase;letter-spacing:0.5px;color:var(--text3);margin-bottom:2px">${esc(label)}</div>` +
      `<div class="t-body">${val || '<span style=\"color:var(--text3)\">—</span>'}</div></div>`;
    h += row('Agency (Short)', agency ? esc(agency) : null);
    h += row('Agency (Full)', agencyFull ? esc(agencyFull) : null);
    h += row('Cabinet Department', cabinetDept ? esc(cabinetDept) : null);
    h += row('Government Level', govType ? esc(govType.charAt(0).toUpperCase() + govType.slice(1)) : null);
    h += row('Representing Agency', representingAgency ? esc(representingAgency) : null);
    h += row('Agency Risk Level', agencyRiskLevel ? esc(agencyRiskLevel.charAt(0).toUpperCase() + agencyRiskLevel.slice(1)) : null);
    h += row('Firm Term Remaining', firmTermRem != null ? fmtYr(firmTermRem) : null);
    h += row('Total Term Remaining', termRem != null ? fmtYr(termRem) : null);
    h += row('Tenant Succession', tenantCount ? `${tenantCount} tenant${tenantCount > 1 ? 's' : ''} historically at this address` : null);
    h += row('Location', [city, state].filter(Boolean).join(', ') || null);
    h += row('FRPP ID', frppId ? esc(frppId) : null);
    h += '</div></div>';

    // ── Workforce card ──────────────────────────────────────────────
    // Two tiers of data: (a) per-property employee counts from FRPP
    // (num_federal_employees + contractors), (b) agency-level OPM
    // workforce rollup for this city (employment totals, hires/separations,
    // telework eligibility, retirement risk). Hides when no data is
    // available for the agency at this location.
    if (federalEmployees != null || frpp?.num_federal_contractors != null || opm) {
      h += '<div class="detail-section">';
      h += '<div class="detail-section-title">Workforce</div>';
      h += '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-top:6px;font-size:13px">';
      h += row('Federal Employees (this site)', federalEmployees != null ? fmtNum(federalEmployees) : null);
      h += row('Federal Contractors (this site)', frpp?.num_federal_contractors != null ? fmtNum(frpp.num_federal_contractors) : null);
      h += row('Workforce Trend (agency)', workforceTrend ? esc(workforceTrend.charAt(0).toUpperCase() + workforceTrend.slice(1)) : null);

      if (opm) {
        h += row('OPM Employment (agency + city)',
          opm.employment_total != null ? `${fmtNum(opm.employment_total)}` +
            (opm.snapshot_month ? ` <span style="font-size:10px;color:var(--text3)">as of ${esc(_fmtDate(opm.snapshot_month))}</span>` : '') : null);
        h += row('Hires / Separations (YTD)',
          (opm.hires_total != null || opm.separations_total != null)
            ? `${fmtNum(opm.hires_total || 0)} in · ${fmtNum(opm.separations_total || 0)} out` : null);
        h += row('Hire-to-Attrition Ratio',
          opm.hiring_vs_attrition_ratio != null
            ? parseFloat(opm.hiring_vs_attrition_ratio).toFixed(2) +
              (opm.hiring_vs_attrition_ratio > 1 ? ' <span style="color:var(--green);font-size:10px">(growing)</span>'
                : opm.hiring_vs_attrition_ratio < 0.9 ? ' <span style="color:#f59e0b;font-size:10px">(shrinking)</span>'
                : ' <span style="color:var(--text3);font-size:10px">(stable)</span>')
            : null);
        h += row('Telework Participants',
          opm.telework_participants_total != null
            ? `${fmtNum(opm.telework_participants_total)} of ${fmtNum(opm.telework_eligible_total || 0)} eligible` : null);
        h += row('Retirement-Eligible',
          opm.retirement_eligible_total != null
            ? fmtNum(opm.retirement_eligible_total) +
              (opm.employment_total ? ` <span style="font-size:10px;color:var(--text3)">(${Math.round(100 * opm.retirement_eligible_total / opm.employment_total)}%)</span>` : '')
            : null);
      } else if (opmHeadcount != null) {
        h += row('OPM Headcount (agency-wide)', fmtNum(opmHeadcount));
      }
      h += '</div></div>';
    }

    // ── FRPP (Federal Real Property) card ───────────────────────────
    // Per-building asset data from frpp_records: property use, utilization,
    // annual rent to lessor, maintenance + operations spend, replacement
    // value, condition index, building age. These are the fields OMB
    // tracks on the federal real-estate rollup and tell you whether GSA
    // sees this building as a keeper vs. a disposal candidate.
    if (frpp) {
      h += '<div class="detail-section">';
      h += '<div class="detail-section-title">Federal Real Property (FRPP)';
      if (frpp.fiscal_year) h += ` <span style="font-size:11px;color:var(--text3);font-weight:400;margin-left:6px">FY ${esc(frpp.fiscal_year)}</span>`;
      h += '</div>';
      h += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:6px;font-size:13px">';
      h += row('Property Type', frpp.property_type ? esc(frpp.property_type) : null);
      h += row('Property Use', frpp.property_use ? esc(frpp.property_use) : null);
      h += row('Utilization', frpp.utilization ? esc(frpp.utilization) : null);
      h += row('Asset Status', frpp.asset_status ? esc(frpp.asset_status) : null);
      h += row('Building Age', frpp.building_age != null ? `${frpp.building_age} yr` : null);
      h += row('Congressional District', frpp.congressional_district ? esc(frpp.congressional_district) : null);
      h += row('Annual Rent to Lessor', frpp.annual_rent_to_lessor != null ? fmtMoney(frpp.annual_rent_to_lessor) : null);
      h += row('Annual Maintenance', frpp.annual_maintenance != null ? fmtMoney(frpp.annual_maintenance) : null);
      h += row('Annual Operations Spend', frpp.annual_operations != null ? fmtMoney(frpp.annual_operations) : null);
      h += row('Replacement Value', frpp.replacement_value != null ? fmtMoney(frpp.replacement_value) : null);
      h += row('Condition Index', frpp.condition_index != null ? parseFloat(frpp.condition_index).toFixed(2) : null);
      h += row('Repair Backlog', frpp.repair_needs != null ? fmtMoney(frpp.repair_needs) : null);
      h += row('Reduce-the-Footprint Status', frpp.reduce_footprint ? esc(frpp.reduce_footprint) : null);
      h += row('Using Bureau', frpp.using_bureau ? esc(frpp.using_bureau) : null);
      h += '</div></div>';
    }

    // ── GSA lease history card (when snapshot-tracked) ──────────────
    // gsa_lease_timeline tracks how a lease has evolved across GSA's
    // monthly inventory snapshots. Useful signals: extension_count (how
    // many times the tenure has been extended), landlord_change_count
    // (whether the lessor has been flipped), bridge_lease_flag (GSA's
    // "we'll sign a short extension while we figure out what we're
    // really doing" marker — huge tell for upcoming renewal activity).
    if (timeline.length) {
      h += '<div class="detail-section">';
      h += '<div class="detail-section-title">GSA Lease Timeline Snapshots</div>';
      h += '<div style="margin-top:6px;display:flex;flex-direction:column;gap:6px">';
      timeline.forEach(t => {
        h += '<div style="background:var(--s2);border:1px solid var(--border);border-radius:8px;padding:8px 10px;font-size:12px;display:flex;flex-wrap:wrap;gap:10px;align-items:center">';
        h += `<span style="font-weight:700;color:var(--text);font-family:'JetBrains Mono',monospace;min-width:80px">${esc(t.lease_number || '—')}</span>`;
        if (t.current_lessor_name)       h += `<span class="t-body">${esc(t.current_lessor_name)}</span>`;
        if (t.current_annual_rent)       h += `<span style="color:var(--green)">${fmtMoney(t.current_annual_rent)}</span>`;
        if (t.current_lease_rsf)         h += `<span class="t-muted2">${fmtNum(t.current_lease_rsf)} RSF</span>`;
        if (t.current_expiration_date)   h += `<span class="t-muted2">exp. ${esc(_fmtDate(t.current_expiration_date))}</span>`;
        if (t.extension_count > 0)       h += `<span style="color:#f59e0b;font-size:11px">${t.extension_count} extension${t.extension_count > 1 ? 's' : ''}</span>`;
        if (t.landlord_change_count > 0) h += `<span style="color:#8b5cf6;font-size:11px">${t.landlord_change_count} landlord change${t.landlord_change_count > 1 ? 's' : ''}</span>`;
        if (t.bridge_lease_flag)         h += `<span style="color:#ef4444;font-size:11px;font-weight:600">BRIDGE LEASE</span>`;
        if (t.snapshots_count)           h += `<span style="color:var(--text3);font-size:10px">${t.snapshots_count} snapshots</span>`;
        h += '</div>';
      });
      h += '</div></div>';
    }

    // ── Agency portfolio context (scale reference) ──────────────────
    if (agp) {
      h += '<div class="detail-section">';
      h += '<div class="detail-section-title">Agency Portfolio Scale</div>';
      h += '<div style="font-size:11px;color:var(--text3);margin-bottom:8px">Where this property sits in the broader ' + esc(agp.agency_name) + ' portfolio across our dataset.</div>';
      h += '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;font-size:13px">';
      h += row('Properties', agp.property_count != null ? fmtNum(agp.property_count) : null);
      h += row('Total SF', agp.total_sf != null ? fmtNum(agp.total_sf) + ' SF' : null);
      h += row('Total Annual Rent', agp.total_annual_rent != null ? fmtMoney(agp.total_annual_rent) : null);
      h += row('Avg Rent /SF', agp.avg_rent_psf != null ? '$' + parseFloat(agp.avg_rent_psf).toFixed(2) + '/SF' : null);
      h += row('Active Locations', agp.active_count != null ? fmtNum(agp.active_count) : null);
      h += row('Vacating Locations', agp.vacating_count != null ? fmtNum(agp.vacating_count) + (agp.vacating_count > 0 ? ' <span style="color:#f59e0b;font-size:10px">(consolidation signal)</span>' : '') : null);
      h += '</div></div>';
    }

    // Tenant chronology — one line per lease, useful for "who's been here"
    if (leases.length) {
      h += '<div class="detail-section">';
      h += '<div class="detail-section-title">Tenant Chronology</div>';
      h += '<div style="margin-top:6px">';
      leases.forEach(l => {
        const tenant = l.tenant_agency || l.tenant || '(unknown)';
        const start  = l.commencement_date || l.lease_start || null;
        const end    = l.expiration_date   || l.lease_expiration || null;
        const rent   = l.annual_rent != null ? '$' + fmtN(Math.round(parseFloat(l.annual_rent))) : null;
        const psf    = l.rent_psf   != null ? '$' + parseFloat(l.rent_psf).toFixed(2) + '/SF' : null;
        const isSup  = l.is_superseding === true;
        const isFg   = l.is_first_generation === true;
        const isSup2 = !!l.superseded_at;
        const typeLabel = isSup2 ? 'Superseded' : (isSup ? 'Succession' : (isFg ? 'Original' : 'Lease'));
        const typeColor = isSup2 ? 'var(--text3)' : (isSup ? '#f59e0b' : 'var(--green)');
        h += '<div style="display:flex;gap:10px;align-items:center;padding:8px 10px;background:var(--s2);border:1px solid var(--border);border-radius:8px;margin-bottom:6px;flex-wrap:wrap">';
        h += `<span style="font-size:10px;font-weight:700;color:${typeColor};min-width:80px">${esc(typeLabel)}</span>`;
        h += `<span style="flex:1;font-weight:600;font-size:13px">${esc(tenant)}</span>`;
        if (start || end) h += `<span style="font-size:11px;color:var(--text2)">${esc(_fmtDate(start) || '?')} → ${esc(_fmtDate(end) || '?')}</span>`;
        if (rent) h += `<span style="font-size:11px;color:var(--green)">${esc(rent)}</span>`;
        if (psf)  h += `<span style="font-size:11px;color:var(--text2)">${esc(psf)}</span>`;
        h += '</div>';
      });
      h += '</div></div>';
    }

    // Federal-tenant research helpers: deep links to the public tools a
    // broker would use to size the operation (headcount, budget, contracts).
    // Skipped for non-federal (state/local) rows since those sources don't
    // apply. OPM FedScope's URL structure doesn't support per-agency deep
    // links from the public portal, so we fall back to a search URL.
    if ((govType || '').toLowerCase() === 'federal' && agency) {
      const aQ = encodeURIComponent(agencyFull || agency);
      h += '<div class="detail-section">';
      h += '<div class="detail-section-title">Research</div>';
      h += '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px">';
      const link = (url, label) =>
        `<a href="${safeHref(url)}" target="_blank" rel="noopener noreferrer" style="padding:6px 12px;border-radius:6px;background:var(--s2);border:1px solid var(--border);color:var(--accent);font-size:12px;font-weight:600;text-decoration:none">${esc(label)}</a>`;
      h += link(`https://www.fedscope.opm.gov/`, 'OPM FedScope (workforce)');
      h += link(`https://www.usaspending.gov/search/?hash=&filters=${encodeURIComponent('{"recipient_search_text":["' + (agencyFull || agency) + '"]}')}`, 'USAspending (budget)');
      h += link(`https://sam.gov/search/?index=_all&sfm%5Bsimple_search%5D%5BsearchString%5D=${aQ}`, 'SAM.gov (contracts)');
      h += link(`https://www.google.com/search?q=${aQ}+${encodeURIComponent(city || '')}+${encodeURIComponent(state || '')}+employees+headcount`, 'Web search: employees');
      h += '</div>';
      h += '<div style="font-size:11px;color:var(--text3);margin-top:6px">Full agency profile build-out (employee counts, budget appropriation, operational overview) is planned — these links jump to the public data sources a broker would normally pull manually.</div>';
      h += '</div>';
    }

    return h;
  }

  // When v_property_rankings has no row but we have a resolved CMS link, build
  // a synthetic rankings object from the snapshot the resolver returned.
  const cmsLink = _udCache.cms || null;
  let effectiveRankings = rankings;
  if (!effectiveRankings && cmsLink && cmsLink.medicare_id) {
    const f = cmsLink.facility || {};
    const q = cmsLink.quality || {};
    const pm = cmsLink.payer || {};
    const pt = cmsLink.patient || {};
    effectiveRankings = {
      medicare_id:                cmsLink.medicare_id,
      latest_estimated_patients:  pt.total_patients || pt.patient_count || null,
      number_of_chairs:           f.number_of_chairs || f.stations || null,
      stations:                   f.stations || f.number_of_chairs || null,
      star_rating:                q.star_rating != null ? q.star_rating : null,
      payer_mix_medicare_pct:     pm.medicare_pct != null ? pm.medicare_pct : null,
      payer_mix_medicaid_pct:     pm.medicaid_pct != null ? pm.medicaid_pct : null,
      payer_mix_private_pct:      pm.private_pct != null ? pm.private_pct : null,
      chain_organization:         f.chain_organization || null,
      operator_name:              f.operator_name || null,
      offers_in_center_hemodialysis:    f.offers_in_center_hemodialysis || false,
      offers_home_hemodialysis_training: f.offers_home_hemodialysis_training || false,
      offers_peritoneal_dialysis:       f.offers_peritoneal_dialysis || false,
      state:                      f.state || null,
      county:                     f.county || null,
      _synthetic_from_cms_link:   true,
    };
  }

  // If we still have nothing, show the "Match facility" fallback card.
  if (!effectiveRankings) {
    return _udRenderMatchFacilityCard();
  }

  const r = effectiveRankings;
  const ext = _opsExtraCache || {};
  const trends = ext.trends || (cmsLink && cmsLink.trends) || {};
  const quality = ext.quality || (cmsLink && cmsLink.quality) || {};
  const finDetail = ext.financialDetail || {};
  const costRpt = ext.costReports || (cmsLink && cmsLink.cost) || {};
  const payerMixHcris = ext.payerMix || (cmsLink && cmsLink.payer) || null;
  const geoPayerMix = ext.geoPayerMix || null;
  const lease = ext.lease || {};
  const hoursInfo = ext.hours || null;
  const patientHistory = ext.patientHistory || [];
  const operator = (cmsLink && cmsLink.operator) || _udDetectOperator(r);
  let html = '';

  // ── Link provenance banner (only shown when we resolved via cms-match) ──
  if (cmsLink && cmsLink.match_method) {
    const pct = cmsLink.match_score != null ? Math.round(Number(cmsLink.match_score) * 100) + '%' : '—';
    const methodLabel = {
      'auto:address_zip':       'Auto (address + zip)',
      'auto:medicare_clinics':  'Auto (medicare_clinics)',
      'manual':                 'Manually linked',
      'manual:typeahead':       'Manually selected',
    }[cmsLink.match_method] || cmsLink.match_method;
    html += '<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;padding:6px 10px;background:rgba(59,130,246,0.08);border:1px solid rgba(59,130,246,0.2);border-radius:8px;font-size:11px">';
    html += '<span style="color:#3b82f6;font-weight:600">&#x1F517; CMS link:</span>';
    html += '<span class="t-body">CCN ' + esc(String(cmsLink.medicare_id)) + '</span>';
    html += '<span class="t-muted3">·</span>';
    html += '<span class="t-muted2">' + esc(methodLabel) + (cmsLink.match_score != null ? ' · ' + pct + ' confidence' : '') + '</span>';
    html += '<span style="flex:1"></span>';
    html += '<button onclick="_udCmsClearLink()" style="font-size:10px;padding:2px 8px;border-radius:4px;border:1px solid var(--border);background:transparent;color:var(--text2);cursor:pointer">Change</button>';
    html += '</div>';
  }

  // ── Reconcile patient census: prefer latest snapshot over rankings aggregate ──
  const latestSnapshotPt = patientHistory.length > 0
    ? Number(patientHistory[patientHistory.length - 1].total_patients || patientHistory[patientHistory.length - 1].patient_count || 0)
    : 0;
  const bestPatientCount = latestSnapshotPt > 0 ? latestSnapshotPt : (r.latest_estimated_patients ? Number(r.latest_estimated_patients) : null);

  // ── Reconcile operating margin ──
  // Always prefer computing margin from profit / revenue for consistency,
  // since ttm_operating_margin may be stored as a raw ratio (0.008) instead of a percentage (0.8)
  const bestProfit = finDetail.estimated_operating_profit || r.ttm_operating_profit;
  const bestRevenue = finDetail.estimated_annual_revenue || r.estimated_annual_revenue || r.ttm_revenue;
  let margin = null;
  if (bestProfit && bestRevenue && Number(bestRevenue) > 0) {
    margin = (Number(bestProfit) / Number(bestRevenue)) * 100;
  } else if (r.ttm_operating_margin != null) {
    // Fallback: use stored value, converting ratio to percentage if needed
    margin = Number(r.ttm_operating_margin);
    if (Math.abs(margin) > 0 && Math.abs(margin) < 1) margin = margin * 100;
  }

  // ── Export Toolbar ──
  html += '<div style="display:flex;justify-content:flex-end;margin-bottom:8px">';
  html += '<button onclick="_udExportOperations()" style="display:flex;align-items:center;gap:5px;padding:6px 14px;border-radius:8px;border:1px solid #003DA5;background:#003DA5;color:#fff;font-size:12px;font-weight:600;cursor:pointer;transition:all 0.15s;box-shadow:0 1px 4px rgba(0,61,165,0.2)"><span style="font-size:14px">&#x1F4CB;</span> Export Client Report</button>';
  html += '</div>';

  // ════════════════════════════════════════════════════════════════════════════
  // 1. KEY METRICS BANNER — always visible at top
  // ════════════════════════════════════════════════════════════════════════════

  const kpis = [];

  // Round 76et-D (2026-04-29): when a KPI is N/A, the info line now explains
  // WHY (no CMS link / no cost report / aggregate-only) so the user knows
  // whether to take action (re-link CMS, wait for next snapshot, etc.) or
  // accept the gap as legitimate. Previously every N/A looked identical
  // regardless of the underlying cause.
  const cmsLinked = !!(r && (r.medicare_id || r.linked_medicare_facility_id || r.ccn));

  // Revenue KPI
  const estRevenue = finDetail.estimated_annual_revenue || r.estimated_annual_revenue || r.ttm_revenue;
  kpis.push({
    label: 'Est. Annual Revenue',
    value: estRevenue ? '$' + _fmtCompact(estRevenue) : 'N/A',
    color: estRevenue ? '' : 'var(--text3)',
    info: estRevenue
      ? 'Revenue estimated using 4-payer treatment model'
      : (cmsLinked ? 'No payer mix / patient counts on file yet' : 'No CMS link — match the property to a Medicare facility to populate')
  });

  // Operating Margin KPI
  const marginColor = margin != null ? (margin > 12 ? 'var(--green)' : margin >= 5 ? 'var(--yellow)' : 'var(--red)') : 'var(--text3)';
  kpis.push({
    label: 'Operating Margin',
    value: margin != null ? margin.toFixed(1) + '%' : 'N/A',
    color: marginColor,
    info: margin != null
      ? (margin > 12 ? 'Healthy' : margin >= 5 ? 'Caution' : 'Below target')
      : (cmsLinked ? 'No CMS cost report on file for this facility' : 'No CMS link')
  });

  // Patient Census KPI — use reconciled best count
  kpis.push({
    label: 'Patient Census',
    value: bestPatientCount ? fmtN(bestPatientCount) : 'N/A',
    color: '',
    trend: _trendArrow(r.patient_yoy_pct, 'YoY'),
    info: bestPatientCount
      ? (latestSnapshotPt > 0 ? 'From latest CMS snapshot' : 'From rankings aggregate')
      : (cmsLinked ? 'No CMS snapshot on file yet' : 'No CMS link — match facility to populate')
  });

  // Star Rating KPI
  const starVal = quality.star_rating != null ? Number(quality.star_rating) : (r.star_rating != null ? Number(r.star_rating) : null);
  kpis.push({
    label: 'Star Rating',
    value: starVal != null ? _starsCompact(starVal) : 'N/A',
    color: '',
    info: 'CMS Dialysis Facility Compare star rating (1-5)'
  });

  // Trend KPI
  const trendDir = trends.trend_direction || (r.patient_yoy_pct > 2 ? 'growth' : r.patient_yoy_pct < -2 ? 'decline' : 'stable');
  const trendArrowIcon = trendDir === 'growth' ? '&#9650;' : trendDir === 'decline' ? '&#9660;' : '&#9654;';
  const trendColor = trendDir === 'growth' ? 'var(--green)' : trendDir === 'decline' ? 'var(--red)' : 'var(--text3)';
  const trendLabel = trendDir === 'growth' ? 'Growth' : trendDir === 'decline' ? 'Decline' : 'Stable';
  kpis.push({
    label: 'Trend',
    value: '<span style="color:' + trendColor + '">' + trendArrowIcon + ' ' + esc(trendLabel) + '</span>',
    color: '',
    info: trends.trend_confidence ? 'Confidence: ' + trends.trend_confidence : ''
  });

  // Lease Expiration KPI
  let leaseMonths = null;
  if (lease.expiration_date) {
    const expDate = new Date(lease.expiration_date);
    const now = new Date();
    leaseMonths = Math.round((expDate - now) / (1000 * 60 * 60 * 24 * 30.44));
  } else if (_udCache.leases && _udCache.leases.length > 0) {
    // Prefer the active lease (is_active=true); fall back to the lease with latest expiration
    const activeLease = _udCache.leases.find(ll => ll.is_active === true || ll.is_active === 'true')
      || _udCache.leases.reduce((best, ll) => {
        const d = ll.expiration_date || ll.lease_expiration;
        if (!d) return best;
        if (!best) return ll;
        const bestD = best.expiration_date || best.lease_expiration;
        return new Date(d) > new Date(bestD) ? ll : best;
      }, null)
      || _udCache.leases[0];
    const primaryLease = activeLease;
    if (primaryLease.expiration_date || primaryLease.lease_expiration) {
      const expDate = new Date(primaryLease.expiration_date || primaryLease.lease_expiration);
      const now = new Date();
      leaseMonths = Math.round((expDate - now) / (1000 * 60 * 60 * 24 * 30.44));
    }
  }
  const leaseColor = leaseMonths != null ? (leaseMonths < 24 ? 'var(--red)' : leaseMonths < 60 ? 'var(--yellow)' : 'var(--green)') : 'var(--text3)';
  kpis.push({
    label: 'Lease Expiration',
    value: leaseMonths != null ? (leaseMonths > 0 ? leaseMonths + ' mo' : 'Expired') : 'N/A',
    color: leaseColor,
    info: leaseMonths != null && leaseMonths < 24 ? 'Less than 24 months remaining' : ''
  });

  // Render KPI cards
  html += '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:16px">';
  kpis.forEach(k => {
    html += '<div style="background:var(--s2);border-radius:10px;padding:10px 12px;text-align:center;position:relative">';
    if (k.info) html += '<span title="' + esc(k.info) + '" style="position:absolute;top:6px;right:8px;font-size:10px;color:var(--text3);cursor:help;width:14px;height:14px;border:1px solid var(--text3);border-radius:50%;display:inline-flex;align-items:center;justify-content:center">i</span>';
    html += '<div style="font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:3px">' + esc(k.label) + '</div>';
    html += '<div style="font-size:18px;font-weight:700;' + (k.color ? 'color:' + k.color : 'color:var(--text1)') + '">' + k.value + '</div>';
    if (k.trend) html += '<div style="margin-top:2px">' + k.trend + '</div>';
    html += '</div>';
  });
  html += '</div>';

  // ════════════════════════════════════════════════════════════════════════════
  // 1b. CMS FACILITY PROFILE — operator, CCN, QIP, last survey, staffing, treatment count
  // ════════════════════════════════════════════════════════════════════════════

  const facility = (cmsLink && cmsLink.facility) || {};
  const latestPt = (cmsLink && cmsLink.patient) || {};
  const qipScore = quality.quality_incentive_program_score
                ?? quality.qip_total_score
                ?? quality.qip_score
                ?? r.qip_total_score
                ?? r.quality_incentive_program_score
                ?? null;
  const lastSurveyDate = quality.last_survey_date
                      || quality.survey_date
                      || facility.last_survey_date
                      || facility.last_inspection_date
                      || r.last_survey_date
                      || null;
  const totalStaff = facility.total_employees
                  || facility.staff_total
                  || costRpt.total_employees
                  || costRpt.staff_total
                  || r.total_employees
                  || null;
  const latestTreatments = (costRpt.total_medicare_treatments != null ? costRpt.total_medicare_treatments : null)
                        || r.ttm_total_treatments
                        || r.estimated_annual_treatments
                        || null;
  const treatmentYoYPct = r.treatment_yoy_pct != null ? Number(r.treatment_yoy_pct)
                        : (r.patient_yoy_pct != null ? Number(r.patient_yoy_pct) : null);
  const ccn = r.medicare_id || (cmsLink && cmsLink.medicare_id) || facility.medicare_id || '';
  const npi = facility.npi || r.npi || '';
  const stationsVal = r.number_of_chairs || r.stations || facility.number_of_chairs || facility.stations || null;

  html += '<div class="detail-section">';
  html += '<div class="detail-section-title" style="display:flex;align-items:center;gap:8px">';
  html += 'CMS Facility Profile';
  html += '<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:' + operator.color + '22;color:' + operator.color + ';font-size:10px;font-weight:700;letter-spacing:0.3px;text-transform:uppercase">' + esc(operator.label) + '</span>';
  html += '</div>';
  html += '<div class="detail-grid">';
  if (ccn) html += _row('Medicare ID (CCN)', ccn);
  if (npi) html += _row('NPI', npi);
  html += _row('Operator / Chain', r.chain_organization || r.operator_name || facility.chain_organization || facility.operator_name);
  html += _row('Stations', stationsVal != null ? fmtN(stationsVal) : null);
  html += _row('Total Staff', totalStaff != null ? fmtN(totalStaff) : null);
  if (latestTreatments != null) {
    const txTrend = treatmentYoYPct != null
      ? ' <span style="font-size:11px;color:' + (treatmentYoYPct >= 0 ? 'var(--green)' : 'var(--red)') + '">' + (treatmentYoYPct >= 0 ? '&#9650; +' : '&#9660; ') + treatmentYoYPct.toFixed(1) + '% YoY</span>'
      : '';
    html += _rowHtml('Treatments (latest)', fmtN(latestTreatments) + txTrend);
  }
  if (qipScore != null) {
    const qipNum = Number(qipScore);
    const qipColor = qipNum >= 80 ? 'var(--green)' : qipNum >= 60 ? 'var(--yellow)' : 'var(--red)';
    html += _rowHtml('QIP Total Score', '<span style="color:' + qipColor + ';font-weight:600">' + qipNum.toFixed(0) + '</span> <span style="font-size:10px;color:var(--text3)">/ 100</span>');
  }
  const starVal2 = quality.star_rating != null ? Number(quality.star_rating) : (r.star_rating != null ? Number(r.star_rating) : null);
  if (starVal2 != null) html += _rowHtml('5-Star Rating', _starsCompact(starVal2));
  if (lastSurveyDate) html += _row('Last CMS Survey', _fmtDate(lastSurveyDate));
  html += '</div>';
  html += '</div>';

  // ════════════════════════════════════════════════════════════════════════════
  // 2. FINANCIAL SUMMARY
  // ════════════════════════════════════════════════════════════════════════════

  html += '<div class="detail-section">';
  html += '<div class="detail-section-title">Financial Summary</div>';

  // Source badge
  const revSource = finDetail.estimate_source || r.revenue_calc_method || 'CMS Patient Count';
  html += '<div style="margin-bottom:10px"><span style="display:inline-block;font-size:10px;padding:2px 8px;border-radius:10px;background:var(--purple);color:#fff;font-weight:600;letter-spacing:0.3px">' + esc(revSource) + '</span></div>';

  html += '<div class="detail-grid">';
  html += _rowMoney('Est. Annual Revenue', finDetail.estimated_annual_revenue || r.estimated_annual_revenue);

  // ── Reconcile Operating Costs ──
  // Priority: 1) HCRIS cost report (facility-level actual)
  //           2) Derive from finDetail (revenue − profit)
  //           3) ttm_operating_costs from medicare_clinics (CAUTION: often org-level, not clinic-level)
  let bestCosts = null;
  let costSource = '';
  // HCRIS Form 265-11 often reports total_costs == total_patient_revenue (Medicare-allocated).
  // When that happens, prefer deriving costs from revenue − profit for actual profitability.
  const hcrisCost = costRpt && costRpt.total_costs ? Number(costRpt.total_costs) : 0;
  const hcrisRev = costRpt && costRpt.total_patient_revenue ? Number(costRpt.total_patient_revenue) : 0;
  const hcrisCostEqualsRev = hcrisCost > 0 && hcrisRev > 0 && Math.abs(hcrisCost - hcrisRev) < 1;
  if (hcrisCost > 0 && !hcrisCostEqualsRev) {
    bestCosts = hcrisCost;
    costSource = 'HCRIS';
  } else if (finDetail.estimated_annual_revenue && finDetail.estimated_operating_profit) {
    bestCosts = Number(finDetail.estimated_annual_revenue) - Number(finDetail.estimated_operating_profit);
    costSource = 'derived';
  } else if (estRevenue && bestProfit) {
    bestCosts = Number(estRevenue) - Number(bestProfit);
    costSource = 'derived';
  }
  // Fallback to ttm_operating_costs only if it's within a plausible range of revenue
  // (ttm_operating_costs is often org-level data that dwarfs clinic revenue)
  if (!bestCosts && r.ttm_operating_costs) {
    const ttmCost = Number(r.ttm_operating_costs);
    const rev = Number(estRevenue || 0);
    if (rev > 0 && ttmCost / rev < 3) {
      bestCosts = ttmCost;
      costSource = 'ttm';
    }
    // If ratio > 3x, the ttm figure is likely org-level — omit rather than show bad data
  }
  if (bestCosts != null && bestCosts > 0) {
    html += _rowHtml('Total Operating Costs', '$' + _fmtCompact(bestCosts)
      + (costSource === 'HCRIS' ? ' <span style="font-size:10px;color:var(--text3)">(HCRIS)</span>'
        : costSource === 'derived' ? ' <span style="font-size:10px;color:var(--text3)">(derived)</span>'
        : ''));
  } else {
    html += _row('Total Operating Costs', null);
  }

  html += _rowMoney('Operating Profit', finDetail.estimated_operating_profit || r.ttm_operating_profit);
  html += _rowHtml('Operating Margin', margin != null ? _marginBadge(margin) : null);

  // ── Reconcile Treatments / Year ──
  // Priority: 1) HCRIS cost report (actual treatment count)
  //           2) finDetail estimated_treatments_per_year (from primary estimate model)
  //           3) Rankings ttm_total_treatments (actual CMS-reported)
  //           4) Model from patient count (patients × 156) — last resort, often inflated
  const hcrisTx = costRpt && costRpt.total_treatments ? Number(costRpt.total_treatments) : null;
  const finTx = finDetail.estimated_treatments_per_year ? Number(finDetail.estimated_treatments_per_year) : null;
  const rawTx = r.estimated_annual_treatments || r.ttm_total_treatments;
  const modelTx = bestPatientCount ? bestPatientCount * 156 : null; // 3 tx/week × 52 weeks
  let annualTx = null;
  let txLabel = '';
  if (hcrisTx && hcrisTx > 0) {
    annualTx = hcrisTx;
    txLabel = ' <span style="font-size:10px;color:var(--text3)">(HCRIS)</span>';
  } else if (finTx && finTx > 0) {
    annualTx = finTx;
    txLabel = ' <span style="font-size:10px;color:var(--text3)">(estimated)</span>';
  } else if (rawTx && Number(rawTx) > 0) {
    annualTx = Number(rawTx);
    txLabel = ' <span style="font-size:10px;color:var(--text3)">(reported)</span>';
  } else if (modelTx && modelTx > 0) {
    annualTx = modelTx;
    txLabel = ' <span style="font-size:10px;color:var(--text3)">(modeled)</span>';
  }
  if (annualTx && estRevenue) {
    const revPerTx = Number(estRevenue) / annualTx;
    html += _rowHtml('Revenue / Treatment', '$' + fmtN(Math.round(revPerTx)));
  }
  if (annualTx && bestCosts) {
    const costPerTx = bestCosts / annualTx;
    html += _rowHtml('Cost / Treatment', '$' + fmtN(Math.round(costPerTx)));
  }
  html += _rowHtml('Treatments / Year', annualTx ? fmtN(annualTx) + txLabel : null);
  html += '</div>';

  // Payer Mix — 4-level comparison: Clinic → County Avg → State Avg → National (smallest to largest)
  const payerBars = [];
  const _natl = { label: 'National Default', med: 65, mcd: 20, pvt: 11 };
  _natl.oth = Math.max(0, 100 - _natl.med - _natl.mcd - _natl.pvt);

  const clinicState = geoPayerMix ? (geoPayerMix.state || r.state || '') : (r.state || '');
  const clinicCounty = geoPayerMix ? (geoPayerMix.county || r.county || '') : (r.county || '');

  // 1. This Clinic (HCRIS actual or rankings fallback) — first/smallest
  let clinicBar = null;
  if (payerMixHcris && payerMixHcris.medicare_pct != null) {
    const hMed = Number(payerMixHcris.medicare_pct);
    const hMcd = Number(payerMixHcris.medicaid_pct || 0);
    const hPvt = Number(payerMixHcris.private_pct || 0);
    clinicBar = { label: 'This Clinic (HCRIS)', med: hMed, mcd: hMcd, pvt: hPvt, oth: Math.max(0, 100 - hMed - hMcd - hPvt), source: 'revenue' };
  } else if (r.payer_mix_medicare_pct != null) {
    const rMed = Number(r.payer_mix_medicare_pct);
    const rMcd = Number(r.payer_mix_medicaid_pct || 0);
    const rPvt = Number(r.payer_mix_private_pct || 0);
    clinicBar = { label: 'This Clinic', med: rMed, mcd: rMcd, pvt: rPvt, oth: Math.max(0, 100 - rMed - rMcd - rPvt) };
  }
  if (clinicBar) payerBars.push(clinicBar);

  // 2. County average (from geo view)
  if (geoPayerMix && geoPayerMix.county_medicare_pct != null) {
    const cMed = Number(geoPayerMix.county_medicare_pct);
    const cMcd = Number(geoPayerMix.county_medicaid_pct || 0);
    const cPvt = Number(geoPayerMix.county_private_pct || 0);
    const cCount = Number(geoPayerMix.county_clinic_count || 0);
    payerBars.push({ label: clinicCounty ? clinicCounty + ' Co. Avg' : 'County Avg', med: cMed, mcd: cMcd, pvt: cPvt, oth: Math.max(0, 100 - cMed - cMcd - cPvt), note: cCount + ' clinic' + (cCount !== 1 ? 's' : '') });
  }

  // 3. State average (from geo view)
  if (geoPayerMix && geoPayerMix.state_medicare_pct != null) {
    const sMed = Number(geoPayerMix.state_medicare_pct);
    const sMcd = Number(geoPayerMix.state_medicaid_pct || 0);
    const sPvt = Number(geoPayerMix.state_private_pct || 0);
    const sCount = Number(geoPayerMix.state_clinic_count || 0);
    payerBars.push({ label: clinicState ? clinicState + ' State Avg' : 'State Avg', med: sMed, mcd: sMcd, pvt: sPvt, oth: Math.max(0, 100 - sMed - sMcd - sPvt), note: sCount + ' clinics' });
  }

  // 4. National Default — last/largest
  payerBars.push(_natl);

  // Determine the "active" payer mix for revenue estimates (prefer clinic-specific > national)
  const activePayer = clinicBar || _natl;
  const payerIsDefault = activePayer === _natl;

  html += '<div style="margin-top:14px">';
  html += '<div style="font-size:12px;color:var(--text2);margin-bottom:8px;font-weight:600">Payer Mix Comparison</div>';

  // Render each bar
  payerBars.forEach(bar => {
    const isNatl = bar === _natl;
    html += '<div style="margin-bottom:10px">';
    html += '<div style="font-size:10px;color:var(--text3);margin-bottom:3px;display:flex;justify-content:space-between">';
    html += '<span>' + esc(bar.label) + (bar.source === 'revenue' ? ' <span style="font-size:9px;opacity:0.7">revenue-based</span>' : '') + (bar.note ? ' <span style="font-size:9px;opacity:0.6">(' + esc(bar.note) + ')</span>' : '') + '</span>';
    if (bar === activePayer && payerIsDefault) html += '<span style="font-size:9px;padding:1px 5px;border-radius:6px;background:var(--text3);color:var(--bg);font-weight:700">In Use</span>';
    if (bar === activePayer && !payerIsDefault) html += '<span style="font-size:9px;padding:1px 5px;border-radius:6px;background:var(--green);color:var(--bg);font-weight:700">In Use</span>';
    html += '</div>';
    html += '<div style="display:flex;height:14px;border-radius:3px;overflow:hidden;font-size:0">';
    if (bar.med) html += '<div style="width:' + bar.med + '%;background:#3b82f6" title="Medicare ' + bar.med.toFixed(1) + '%"></div>';
    if (bar.mcd) html += '<div style="width:' + bar.mcd + '%;background:#8b5cf6" title="Medicaid ' + bar.mcd.toFixed(1) + '%"></div>';
    if (bar.pvt) html += '<div style="width:' + bar.pvt + '%;background:#10b981" title="Commercial ' + bar.pvt.toFixed(1) + '%"></div>';
    if (bar.oth > 0.5) html += '<div style="width:' + bar.oth + '%;background:var(--text3)" title="Other ' + bar.oth.toFixed(1) + '%"></div>';
    html += '</div>';
    // Inline percentages
    html += '<div style="display:flex;gap:8px;font-size:10px;color:var(--text3);margin-top:2px">';
    html += '<span>Med ' + bar.med.toFixed(0) + '%</span>';
    html += '<span>Mcd ' + bar.mcd.toFixed(0) + '%</span>';
    html += '<span>Pvt ' + bar.pvt.toFixed(0) + '%</span>';
    if (bar.oth > 0.5) html += '<span>Oth ' + bar.oth.toFixed(0) + '%</span>';
    html += '</div>';
    html += '</div>';
  });

  // Legend (shared)
  html += '<div style="display:flex;gap:12px;flex-wrap:wrap;font-size:11px;margin-top:4px">';
  html += '<span><span style="display:inline-block;width:8px;height:8px;border-radius:2px;background:#3b82f6;margin-right:3px"></span>Medicare</span>';
  html += '<span><span style="display:inline-block;width:8px;height:8px;border-radius:2px;background:#8b5cf6;margin-right:3px"></span>Medicaid</span>';
  html += '<span><span style="display:inline-block;width:8px;height:8px;border-radius:2px;background:#10b981;margin-right:3px"></span>Commercial</span>';
  html += '<span><span style="display:inline-block;width:8px;height:8px;border-radius:2px;background:var(--text3);margin-right:3px"></span>Other</span>';
  html += '</div>';

  // Payer mix dollar estimates using active payer
  if (estRevenue) {
    const rev = Number(estRevenue);
    html += '<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:4px 12px;margin-top:8px;font-size:12px;color:var(--text2)">';
    html += '<div>Medicare</div><div style="text-align:right;font-weight:600">$' + _fmtCompact(rev * activePayer.med / 100) + '</div>';
    html += '<div>Medicaid</div><div style="text-align:right;font-weight:600">$' + _fmtCompact(rev * activePayer.mcd / 100) + '</div>';
    html += '<div>Commercial</div><div style="text-align:right;font-weight:600">$' + _fmtCompact(rev * activePayer.pvt / 100) + '</div>';
    if (activePayer.oth > 0.5) html += '<div>Other</div><div style="text-align:right;font-weight:600">$' + _fmtCompact(rev * activePayer.oth / 100) + '</div>';
    html += '</div>';
  }
  html += '</div>';

  // HCRIS Modeled vs Actual comparison callout
  if (costRpt && costRpt.total_patient_revenue && estRevenue) {
    const actual = Number(costRpt.total_patient_revenue);
    const modeled = Number(estRevenue);
    const absVar = Math.abs(((modeled - actual) / actual * 100));
    const variance = ((modeled - actual) / actual * 100).toFixed(1);
    const isLargeGap = absVar >= 25;
    const borderColor = isLargeGap ? 'rgba(239,68,68,0.35)' : (absVar >= 10 ? 'rgba(251,191,36,0.3)' : 'rgba(59,130,246,0.2)');
    const bgColor = isLargeGap ? 'rgba(239,68,68,0.06)' : (absVar >= 10 ? 'rgba(251,191,36,0.06)' : 'rgba(59,130,246,0.08)');
    const varColor = absVar < 10 ? 'var(--green)' : (absVar < 25 ? 'var(--yellow)' : '#ef4444');
    html += '<div style="margin-top:14px;padding:10px 12px;background:' + bgColor + ';border:1px solid ' + borderColor + ';border-radius:8px">';
    html += '<div style="font-size:11px;font-weight:700;color:var(--text2);margin-bottom:6px">' + (isLargeGap ? '&#x26A0;&#xFE0F;' : '&#x1F4CA;') + ' Modeled vs. HCRIS Actual (FY' + (costRpt.fiscal_year || '?') + ')</div>';
    html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;font-size:12px">';
    html += '<div class="t-muted3">Modeled Revenue</div><div style="text-align:right;font-weight:600">$' + _fmtCompact(modeled) + '</div>';
    html += '<div class="t-muted3">HCRIS Actual</div><div style="text-align:right;font-weight:600">$' + _fmtCompact(actual) + '</div>';
    html += '<div class="t-muted3">Variance</div><div style="text-align:right;font-weight:600;color:' + varColor + '">' + (variance > 0 ? '+' : '') + variance + '%</div>';
    html += '</div>';
    if (isLargeGap) {
      // Determine which source is more trustworthy
      const hcrisConf = costRpt.confidence_score ? Number(costRpt.confidence_score) : null;
      // Check quality flags on both the cost report AND the financial estimate model
      const allFlags = [costRpt.data_quality_flags, finDetail.data_quality_flags].filter(Boolean).map(f => String(f)).join(',');
      const hasChainFlag = allFlags.includes('chain');
      const hasAnomaly = costRpt.is_anomaly === true || finDetail.is_anomaly === true || allFlags.includes('anomal');
      let explanation = '';
      if (hasChainFlag || hasAnomaly) {
        explanation = 'HCRIS data is flagged as potentially unreliable' + (hasChainFlag ? ' \u2014 costs appear to be allocated from the parent chain rather than facility-specific' : '') + '. ';
        explanation += 'For underwriting, prefer TTM reported actuals or the modeled estimate with a wider confidence band.';
      } else if (modeled > actual * 1.25) {
        explanation = 'The model may be overestimating revenue. Verify against recent OM data or operator financials before using the modeled figure for underwriting.';
      } else {
        explanation = 'The model estimate is significantly below HCRIS actuals. HCRIS may include non-recurring items or multi-facility allocations. Cross-reference with TTM actuals.';
      }
      html += '<div style="margin-top:8px;padding:8px 10px;background:rgba(239,68,68,0.05);border-radius:6px;font-size:11px;color:var(--text2);line-height:1.5">';
      html += '<strong style="color:#ef4444">Data Quality Flag:</strong> ' + esc(explanation);
      html += '</div>';
    }
    html += '</div>';
  }

  html += '</div>';

  // ════════════════════════════════════════════════════════════════════════════
  // 3. PATIENT CENSUS & TRENDS
  // ════════════════════════════════════════════════════════════════════════════

  html += '<div class="detail-section">';
  html += '<div class="detail-section-title">Patient Census & Trends</div>';

  // Sparkline chart from patient history
  if (patientHistory.length >= 2) {
    html += _opsSparkline(patientHistory);
  }

  // Trend direction badge
  const trendConf = trends.trend_confidence || '';
  html += '<div style="display:flex;gap:8px;align-items:center;margin:10px 0">';
  html += '<span style="display:inline-block;padding:3px 10px;border-radius:12px;font-size:11px;font-weight:700;background:' + trendColor + '22;color:' + trendColor + '">' + trendArrowIcon + ' ' + esc(trendLabel) + '</span>';
  if (trendConf) html += '<span class="t-meta3">Confidence: ' + esc(String(trendConf)) + '</span>';
  html += '</div>';

  html += '<div class="detail-grid">';
  html += _row('Current Patients', bestPatientCount ? fmtN(bestPatientCount) : null);
  if (r.patients_last_year) html += _rowTrend('Last Year', fmtN(r.patients_last_year), r.patient_yoy_pct);
  if (r.patients_two_years_ago) html += _row('Two Years Ago', fmtN(r.patients_two_years_ago));
  if (r.patient_3yr_avg) html += _rowTrend('3-Year Average', fmtN(r.patient_3yr_avg), r.patient_vs_3yr_avg_pct);

  // Annualized growth rate (CAGR)
  const cagr = trends.annualized_growth_rate;
  if (cagr != null) {
    const cagrColor = Number(cagr) > 0 ? 'var(--green)' : Number(cagr) < 0 ? 'var(--red)' : 'var(--text3)';
    html += _rowHtml('Annualized Growth (CAGR)', '<span style="color:' + cagrColor + ';font-weight:600">' + (Number(cagr) > 0 ? '+' : '') + Number(cagr).toFixed(1) + '%</span>');
  }
  // Regression slope
  if (trends.regression_slope != null) {
    const slope = Number(trends.regression_slope);
    html += _row('Regression Slope', (slope > 0 ? '+' : '') + slope.toFixed(1) + ' patients/yr');
  }
  if (trends.regression_r_squared != null) {
    html += _row('R\u00B2', Number(trends.regression_r_squared).toFixed(3));
  }
  // Projections — recalculate revenue from projected patients × per-patient revenue
  // (database projected_revenue can be inconsistent with flat/declining patient trends)
  const projPt1 = trends.projected_patients_1yr != null ? Math.round(Number(trends.projected_patients_1yr)) : null;
  const projPt3 = trends.projected_patients_3yr != null ? Math.round(Number(trends.projected_patients_3yr)) : null;
  if (projPt1 != null) html += _row('Projected Patients (1yr)', fmtN(projPt1));
  if (projPt3 != null) html += _row('Projected Patients (3yr)', fmtN(projPt3));
  // Revenue projections: derive from patient growth rate applied to current revenue (+ 3% annual inflation)
  // CAUTION: bestPatientCount is total CMS census (all modalities), not just in-center.
  // Using revenue / patients directly inflates per-patient cost if many patients are home/PD.
  // Instead, apply the patient growth RATE to current revenue for more stable projections.
  if (estRevenue && bestPatientCount && bestPatientCount > 0) {
    const rev = Number(estRevenue);
    if (projPt1 != null && projPt1 > 0) {
      const growthRate1 = projPt1 / bestPatientCount;
      const projRev1 = rev * growthRate1 * 1.03;
      html += _rowMoney('Projected Revenue (1yr)', projRev1);
    }
    if (projPt3 != null && projPt3 > 0) {
      const growthRate3 = projPt3 / bestPatientCount;
      const projRev3 = rev * growthRate3 * Math.pow(1.03, 3);
      html += _rowMoney('Projected Revenue (3yr)', projRev3);
    }
  }
  html += '</div>';

  // Modality breakdown (if data available from rankings or medicare_clinics)
  const hasModality = r.offers_in_center_hemodialysis || r.offers_home_hemodialysis_training || r.offers_peritoneal_dialysis;
  if (hasModality) {
    html += '<div style="margin-top:12px;font-size:12px;color:var(--text2);font-weight:600;margin-bottom:6px">Treatment Modalities</div>';
    html += '<div style="display:flex;gap:6px;flex-wrap:wrap">';
    if (r.offers_in_center_hemodialysis) html += '<span style="padding:3px 8px;border-radius:6px;background:rgba(59,130,246,0.12);color:#3b82f6;font-size:11px;font-weight:600">In-Center HD</span>';
    if (r.offers_home_hemodialysis_training) html += '<span style="padding:3px 8px;border-radius:6px;background:rgba(16,185,129,0.12);color:#10b981;font-size:11px;font-weight:600">Home HD</span>';
    if (r.offers_peritoneal_dialysis) html += '<span style="padding:3px 8px;border-radius:6px;background:rgba(139,92,246,0.12);color:#8b5cf6;font-size:11px;font-weight:600">Peritoneal</span>';
    html += '</div>';
  }

  html += '</div>';

  // ════════════════════════════════════════════════════════════════════════════
  // 4. CAPACITY & UTILIZATION
  // ════════════════════════════════════════════════════════════════════════════

  html += '<div class="detail-section">';
  html += '<div class="detail-section-title">Capacity & Utilization</div>';
  html += '<div class="detail-grid">';
  html += _row('Dialysis Stations/Chairs', r.number_of_chairs ? fmtN(r.number_of_chairs) : (r.stations ? fmtN(r.stations) : null));
  html += _row('Estimated Capacity', r.estimated_capacity ? fmtN(r.estimated_capacity) + ' patients' : (r.max_patient_capacity ? fmtN(r.max_patient_capacity) + ' patients' : null));
  html += _rowHtml('Capacity Utilization', r.capacity_utilization_pct != null ? _utilBar(Number(r.capacity_utilization_pct)) : null);
  if (bestPatientCount && r.number_of_chairs) {
    html += _row('Patients / Chair', (bestPatientCount / Number(r.number_of_chairs)).toFixed(1));
  }
  html += _row('Operator', r.operator_name);
  html += _row('Chain', r.chain_organization);
  html += '</div></div>';

  // ════════════════════════════════════════════════════════════════════════════
  // 4b. HOURS OF OPERATION
  // ════════════════════════════════════════════════════════════════════════════

  html += '<div class="detail-section">';
  html += '<div class="detail-section-title">Hours of Operation</div>';
  if (hoursInfo && hoursInfo.hours_json) {
    const hj = hoursInfo.hours_json;
    const dayOrder = ['mon','tue','wed','thu','fri','sat','sun'];
    const dayNames = { mon: 'Monday', tue: 'Tuesday', wed: 'Wednesday', thu: 'Thursday', fri: 'Friday', sat: 'Saturday', sun: 'Sunday' };
    html += '<div style="display:grid;grid-template-columns:90px 1fr;gap:4px 12px;font-size:13px">';
    dayOrder.forEach(d => {
      const slots = hj[d];
      const label = dayNames[d];
      const isToday = new Date().toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase() === label.toLowerCase();
      const fontWeight = isToday ? '700' : '400';
      const todayDot = isToday ? '<span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:var(--green);margin-left:4px;vertical-align:middle"></span>' : '';
      if (!slots || slots.length === 0) {
        html += '<div style="color:var(--text3);font-weight:' + fontWeight + '">' + label + todayDot + '</div>';
        html += '<div style="color:var(--text3);font-style:italic">Closed</div>';
      } else {
        const formatted = slots.map(s => {
          const [open, close] = s.split('-');
          return _fmt12h(open) + ' – ' + _fmt12h(close);
        }).join(', ');
        html += '<div style="color:var(--text2);font-weight:' + fontWeight + '">' + label + todayDot + '</div>';
        html += '<div class="t-body">' + formatted + '</div>';
      }
    });
    html += '</div>';
    // Summary stats row
    html += '<div style="display:flex;gap:16px;margin-top:10px;padding-top:8px;border-top:1px solid var(--s3);font-size:12px;color:var(--text2)">';
    if (hoursInfo.weekly_operating_hours) {
      html += '<span><strong>' + Number(hoursInfo.weekly_operating_hours).toFixed(0) + '</strong> hrs/week</span>';
    }
    if (hoursInfo.late_shift != null) {
      html += '<span>' + (hoursInfo.late_shift ? '&#x1F319; Late shift offered' : 'No late shift') + '</span>';
    }
    if (hoursInfo.hours_source) {
      html += '<span class="t-muted3">Source: ' + esc(hoursInfo.hours_source) + '</span>';
    }
    if (hoursInfo.hours_last_checked_at) {
      html += '<span class="t-muted3">Updated: ' + _fmtDate(hoursInfo.hours_last_checked_at) + '</span>';
    }
    html += '</div>';
  } else {
    html += '<div style="color:var(--text3);font-size:13px;padding:8px 0">Hours not available for this facility. Data is sourced from Google Places and covers ~36% of tracked clinics.</div>';
  }
  html += '</div>';

  // ════════════════════════════════════════════════════════════════════════════
  // 5. QUALITY & RISK — two panels side by side
  // ════════════════════════════════════════════════════════════════════════════

  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:4px">';

  // ── Quality Metrics Panel ──
  html += '<div class="detail-section" style="margin-bottom:0">';
  html += '<div class="detail-section-title">Quality Metrics</div>';
  html += '<div class="detail-grid">';
  html += _rowHtml('CMS Star Rating', starVal != null ? _stars(starVal) : null);
  // Quality metrics with national benchmarks (per 100 patient-years, CMS DFC benchmarks)
  const mortRate = quality.mortality_rate != null ? Number(quality.mortality_rate) : (r.mortality_rate != null ? Number(r.mortality_rate) : null);
  html += _rowHtml('Mortality Rate', mortRate != null ? _qualityBenchmark(mortRate, 15.0, 'lower') : null);
  const hospRate = quality.hospitalization_rate != null ? Number(quality.hospitalization_rate) : null;
  html += _rowHtml('Hospitalization Rate', hospRate != null ? _qualityBenchmark(hospRate, 150.0, 'lower') : null);
  const readmRate = quality.readmission_rate != null ? Number(quality.readmission_rate) : null;
  html += _rowHtml('Readmission Rate', readmRate != null ? _qualityBenchmark(readmRate, 25.0, 'lower') : null);
  html += _row('Infection Ratio', quality.infection_ratio != null ? Number(quality.infection_ratio).toFixed(2) : null);
  html += _row('Transplant Waitlist', quality.transplant_waitlist_ratio != null ? Number(quality.transplant_waitlist_ratio).toFixed(2) : null);
  html += _row('Deficiency Count', r.deficiency_count != null ? fmtN(r.deficiency_count) : null);
  html += '</div></div>';

  // ── Risk Assessment Panel ──
  html += '<div class="detail-section" style="margin-bottom:0">';
  html += '<div class="detail-section-title">Risk Assessment</div>';

  // Compute composite lease risk score (0-100)
  const riskScores = _computeLeaseRisk(r, trends, quality, lease, leaseMonths, margin);
  const riskLevel = riskScores.total <= 25 ? 'Low' : riskScores.total <= 50 ? 'Moderate' : riskScores.total <= 75 ? 'High' : 'Critical';
  const riskColor = riskScores.total <= 25 ? 'var(--green)' : riskScores.total <= 50 ? 'var(--yellow)' : riskScores.total <= 75 ? 'var(--orange)' : 'var(--red)';

  // Gauge visual
  html += '<div style="text-align:center;margin-bottom:10px">';
  html += '<div style="position:relative;width:80px;height:40px;margin:0 auto;overflow:hidden">';
  html += '<div style="width:80px;height:80px;border-radius:50%;border:6px solid var(--s3);border-bottom-color:transparent;border-left-color:transparent;transform:rotate(225deg);box-sizing:border-box"></div>';
  html += '<div style="position:absolute;top:0;left:0;width:80px;height:80px;border-radius:50%;border:6px solid ' + riskColor + ';border-bottom-color:transparent;border-left-color:transparent;transform:rotate(' + (225 + riskScores.total * 1.8) + 'deg);box-sizing:border-box;clip-path:inset(0 0 50% 0)"></div>';
  html += '<div style="position:absolute;bottom:0;left:50%;transform:translateX(-50%);font-size:16px;font-weight:700;color:' + riskColor + '">' + riskScores.total + '</div>';
  html += '</div>';
  html += '<span style="display:inline-block;padding:2px 10px;border-radius:10px;font-size:11px;font-weight:700;background:' + riskColor + '22;color:' + riskColor + '">' + riskLevel + ' Risk</span>';
  html += '</div>';

  // Component breakdown
  html += '<div class="t-meta3">';
  const riskComponents = [
    { label: 'Patient Trend', value: riskScores.patientTrend, weight: '30%' },
    { label: 'Financial', value: riskScores.financial, weight: '25%' },
    { label: 'Quality', value: riskScores.quality, weight: '20%' },
    { label: 'Lease Expiration', value: riskScores.leaseExp, weight: '15%' },
    { label: 'Market', value: riskScores.market, weight: '10%' }
  ];
  riskComponents.forEach(rc => {
    const rcColor = rc.value <= 25 ? 'var(--green)' : rc.value <= 50 ? 'var(--yellow)' : rc.value <= 75 ? 'var(--orange)' : 'var(--red)';
    html += '<div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">';
    html += '<span style="width:90px;flex-shrink:0">' + rc.label + ' (' + rc.weight + ')</span>';
    html += '<div style="flex:1;height:4px;background:var(--s3);border-radius:2px;overflow:hidden"><div style="width:' + rc.value + '%;height:100%;background:' + rcColor + ';border-radius:2px"></div></div>';
    html += '<span style="width:20px;text-align:right;font-weight:600;color:' + rcColor + '">' + rc.value + '</span>';
    html += '</div>';
  });
  html += '</div>';

  html += '</div>';
  html += '</div>'; // end side-by-side grid

  // ── COMPETITIVE LANDSCAPE ──
  // -- NEARBY (geographic): owners + sales cohort (R50) --
  try { html += _udRenderGeoSection(ext.geo, 'dia'); } catch (_e) { /* additive; never break the tab */ }

  // -- COMPETITIVE LANDSCAPE (R50: distance-ranked; same-county fallback) --
  const geoComps = (ext.geo && ext.geo.subject_geocoded && Array.isArray(ext.geo.nearby_competitors)) ? ext.geo.nearby_competitors : [];
  if (geoComps.length > 0) {
    html += '<div class="detail-section">';
    html += '<div class="detail-section-title">Competitive Landscape — nearest within ' + ((ext.geo.radius && ext.geo.radius.competitors) || 10) + ' mi</div>';
    const gOpCounts = {};
    geoComps.forEach(c => { const op = c.operator || c.chain_canonical || 'Independent'; gOpCounts[op] = (gOpCounts[op] || 0) + 1; });
    const gOpSummary = Object.entries(gOpCounts).sort((a, b) => b[1] - a[1]).map(([op, ct]) => op + ' (' + ct + ')').join(', ');
    const gSameOp = geoComps.filter(c => c.same_operator).length;
    html += '<div style="font-size:12px;color:var(--text3);margin-bottom:6px">' + geoComps.length + ' nearest dialysis facilities · ' + gSameOp + ' same operator (replacement-risk)</div>';
    html += '<div style="font-size:11px;color:var(--text3);margin-bottom:10px"><strong class="t-muted2">Operators:</strong> ' + gOpSummary + '</div>';
    html += '<div style="overflow-x:auto;max-height:300px;overflow-y:auto"><table style="width:100%;border-collapse:collapse;font-size:11px">';
    html += '<thead style="position:sticky;top:0;background:var(--bg)"><tr style="border-bottom:2px solid var(--s3)">';
    html += '<th style="text-align:left;padding:4px 8px;color:var(--text3);font-weight:700">Address</th>';
    html += '<th style="text-align:left;padding:4px 8px;color:var(--text3);font-weight:700">City</th>';
    html += '<th style="text-align:right;padding:4px 8px;color:var(--text3);font-weight:700">Dist</th>';
    html += '<th style="text-align:left;padding:4px 8px;color:var(--text3);font-weight:700">Operator</th>';
    html += '<th style="text-align:left;padding:4px 8px;color:var(--text3);font-weight:700">Tenant</th>';
    html += '</tr></thead><tbody>';
    geoComps.forEach(c => {
      html += '<tr style="border-bottom:1px solid var(--s3)">';
      html += '<td style="padding:4px 8px;white-space:nowrap">' + (c.address || '—') + '</td>';
      html += '<td style="padding:4px 8px">' + (c.city || '') + (c.state ? ', ' + c.state : '') + '</td>';
      html += '<td style="padding:4px 8px;text-align:right">' + (c.distance_miles != null ? Number(c.distance_miles).toFixed(2) + ' mi' : '—') + '</td>';
      html += '<td style="padding:4px 8px">' + (c.operator || c.chain_canonical || 'Independent') + (c.same_operator ? ' ●' : '') + '</td>';
      html += '<td style="padding:4px 8px">' + (c.tenant || '—') + '</td>';
      html += '</tr>';
    });
    html += '</tbody></table></div>';
    html += '<div style="font-size:10px;color:var(--text3);margin-top:6px">Distance-ranked from the geocoded dialysis book; same-county CMS list is the fallback when the subject is ungeocoded.</div>';
    html += '</div>';
  } else {
  const competitors = ext.competitors || [];
  if (competitors.length > 0) {
    html += '<div class="detail-section">';
    html += '<div class="detail-section-title">Competitive Landscape \u2014 ' + (r.county || '') + ' County</div>';
    // Operator summary
    const opCounts = {};
    let totalChairs = 0, totalPts = 0;
    competitors.forEach(c => {
      const op = c.chain_organization || 'Independent';
      opCounts[op] = (opCounts[op] || 0) + 1;
      if (c.number_of_chairs) totalChairs += Number(c.number_of_chairs);
      if (c.latest_estimated_patients) totalPts += Number(c.latest_estimated_patients);
    });
    const opSummary = Object.entries(opCounts).sort((a, b) => b[1] - a[1]).map(([op, ct]) => op + ' (' + ct + ')').join(', ');
    html += '<div style="font-size:12px;color:var(--text3);margin-bottom:10px">' + competitors.length + ' competing facilities &nbsp;\u00B7&nbsp; ' + totalChairs + ' total chairs &nbsp;\u00B7&nbsp; ' + fmtN(totalPts) + ' patients</div>';
    html += '<div style="font-size:11px;color:var(--text3);margin-bottom:10px"><strong class="t-muted2">Operators:</strong> ' + opSummary + '</div>';
    // Table
    html += '<div style="overflow-x:auto;max-height:300px;overflow-y:auto">';
    html += '<table style="width:100%;border-collapse:collapse;font-size:11px">';
    html += '<thead style="position:sticky;top:0;background:var(--bg)">';
    html += '<tr style="border-bottom:2px solid var(--s3)">';
    html += '<th style="text-align:left;padding:4px 8px;color:var(--text3);font-weight:700">Facility</th>';
    html += '<th style="text-align:left;padding:4px 8px;color:var(--text3);font-weight:700">City</th>';
    html += '<th style="text-align:left;padding:4px 8px;color:var(--text3);font-weight:700">Operator</th>';
    html += '<th style="text-align:right;padding:4px 8px;color:var(--text3);font-weight:700">Chairs</th>';
    html += '<th style="text-align:right;padding:4px 8px;color:var(--text3);font-weight:700">Patients</th>';
    html += '</tr></thead><tbody>';
    competitors.forEach(c => {
      html += '<tr style="border-bottom:1px solid var(--s3)">';
      html += '<td style="padding:4px 8px;white-space:nowrap">' + (c.facility_name || '') + '</td>';
      html += '<td style="padding:4px 8px">' + (c.city || '') + '</td>';
      html += '<td style="padding:4px 8px">' + (c.chain_organization || 'Independent') + '</td>';
      html += '<td style="padding:4px 8px;text-align:right">' + (c.number_of_chairs || '\u2014') + '</td>';
      html += '<td style="padding:4px 8px;text-align:right">' + (c.latest_estimated_patients ? Number(c.latest_estimated_patients).toLocaleString() : '\u2014') + '</td>';
      html += '</tr>';
    });
    html += '</tbody></table></div>';
    html += '</div>';
  }
  }

  // ── COMPARATIVE RANKINGS ──
  html += '<div class="detail-section">';
  html += '<div class="detail-section-title">Comparative Rankings</div>';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:0 16px">';
  html += '<div style="font-size:11px;color:var(--text3);font-weight:700;margin-bottom:6px;text-transform:uppercase;letter-spacing:0.5px">By Patients</div>';
  html += '<div style="font-size:11px;color:var(--text3);font-weight:700;margin-bottom:6px;text-transform:uppercase;letter-spacing:0.5px">By Revenue</div>';
  html += '</div>';
  const rankScopes = [
    { label: 'County', patRank: r.county_patient_rank, revRank: r.county_revenue_rank, total: r.county_total, ctx: r.county },
    { label: 'State', patRank: r.state_patient_rank, revRank: r.state_revenue_rank, total: r.state_total, ctx: r.state },
    { label: 'Operator', patRank: r.operator_patient_rank, revRank: r.operator_revenue_rank, total: r.operator_total, ctx: r.operator_name },
    { label: 'National', patRank: r.national_patient_rank, revRank: r.national_revenue_rank, total: r.national_total, ctx: null }
  ];
  rankScopes.forEach(rs => {
    if (!rs.patRank && !rs.revRank) return;
    html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:0 16px">';
    html += '<div>' + _rankingBar(rs.label, rs.patRank, rs.total, rs.ctx) + '</div>';
    html += '<div>' + (rs.revRank ? _rankingBar(rs.label, rs.revRank, rs.total, rs.ctx) : '<div style="color:var(--text3);font-size:11px;padding:8px 0">N/A</div>') + '</div>';
    html += '</div>';
  });
  html += '</div>';

  // ════════════════════════════════════════════════════════════════════════════
  // 6. METHODOLOGY & SOURCES FOOTER
  // ════════════════════════════════════════════════════════════════════════════

  html += '<div class="detail-section" style="border-top:1px solid var(--s3);padding-top:12px">';
  html += '<div onclick="this.nextElementSibling.style.display=this.nextElementSibling.style.display===\'none\'?\'block\':\'none\';this.querySelector(\'span\').textContent=this.nextElementSibling.style.display===\'none\'?\'\\u25B6\':\'\\u25BC\'" style="cursor:pointer;font-size:12px;font-weight:700;color:var(--text2);display:flex;align-items:center;gap:6px">';
  html += '<span>&#x25B6;</span> Methodology & Data Sources</div>';
  html += '<div style="display:none;margin-top:10px;font-size:11px;color:var(--text3);line-height:1.6">';

  html += '<p style="margin:0 0 8px">Revenue estimates use a 4-payer blended rate (~$357/tx): Medicare $279/tx, Medicaid $225/tx, Commercial $1,100/tx, Other $250/tx, at 156 treatments/year (3x/week). Chair-based model (chairs × 3 shifts × 5.5 days × 52 wks × 65% utilization) is primary where station data is available (validated median 1.00x vs TTM, n=7,115). Concurrent-ratio model (annual patients × 0.245 × 156 tx/yr) used as fallback. TTM-reported and 10-K filing data preferred over modeled estimates.</p>';

  html += '<p style="margin:0 0 8px"><strong class="t-muted2">Risk Score Components:</strong></p>';
  html += '<p style="margin:0 0 4px;padding-left:8px"><strong class="t-muted2">Patient Trend (30%):</strong> Measures YoY patient growth/decline and regression trend direction. Declining census signals potential revenue erosion and operator dissatisfaction.</p>';
  html += '<p style="margin:0 0 4px;padding-left:8px"><strong class="t-muted2">Financial Health (25%):</strong> Based on operating margin. Margins above 15% are healthy; below 3% indicate financial stress and higher risk of closure or relocation.</p>';
  html += '<p style="margin:0 0 4px;padding-left:8px"><strong class="t-muted2">Quality Metrics (20%):</strong> CMS star rating (1-5). Lower ratings correlate with regulatory scrutiny, patient attrition, and potential operator exit.</p>';
  html += '<p style="margin:0 0 4px;padding-left:8px"><strong class="t-muted2">Lease Expiration (15%):</strong> Remaining months on lease. Shorter terms increase vacancy risk and reduce investor certainty.</p>';
  html += '<p style="margin:0 0 8px;padding-left:8px"><strong class="t-muted2">Market Conditions (10%):</strong> Uses capacity utilization as a demand proxy. High utilization (85%+) signals strong market demand; low utilization suggests oversupply.</p>';

  html += '<p style="margin:0 0 8px"><strong class="t-muted2">Quality Benchmarks:</strong> Mortality, hospitalization, and readmission rates are per 100 patient-years. Figures are compared against national CMS Dialysis Facility Compare averages (mortality ~15, hospitalization ~150, readmission ~25). Lower is better for all three metrics.</p>';

  // Data freshness
  const latestSnapshot = patientHistory.length > 0 ? patientHistory[patientHistory.length - 1].snapshot_date : null;
  const qualityDate = quality.snapshot_date || null;
  html += '<p style="margin:0 0 8px"><strong class="t-muted2">Data Freshness:</strong> ';
  html += 'Patient data as of ' + (latestSnapshot ? _fmtDate(latestSnapshot) : 'N/A') + '. ';
  html += 'Quality metrics as of ' + (qualityDate ? _fmtDate(qualityDate) : 'N/A') + '.</p>';

  html += '<p style="margin:0"><strong class="t-muted2">Sources:</strong> CMS Dialysis Facility Compare, USRDS, DaVita 10-K, MedPAC Reports, Census ACS, CDC PLACES.</p>';
  html += '</div>';
  html += '</div>';

  return html;
}

/** Northmarq brand constants — extracted from northmarq.com live site */
const NMQ_BRAND = {
  blue:       '#003DA5',  // primary — links, CTA bg, header accents
  navy:       '#001159',  // deep navy — dark headers, hover states
  lightBlue:  '#62B5E5',  // secondary accent
  blueTint:   '#E0E8F4',  // light blue background tint
  warmWhite:  '#FAF9F5',  // warm off-white background
  bodyText:   '#3D4A54',  // body copy
  darkText:   '#191919',  // headings
  muted:      '#6A748C',  // secondary text
  border:     '#D8DFDF',  // borders, dividers
  headingFont: "'futura-pt', 'Trebuchet MS', 'Arial', sans-serif",
  bodyFont:    "'Open Sans', 'Segoe UI', system-ui, sans-serif",
  logoUrl:     'https://www.northmarq.com/themes/custom/northmarq/logo.svg',
};

/** Export Operations tab as a Northmarq-branded client-deliverable HTML report */
function _udExportOperations() {
  const rankings = _udCache.rankings;
  const cmsLink = _udCache.cms || null;
  const property = _udCache.property || {};
  const fb = _udCache.fallback || {};
  const ext = _opsExtraCache || {};
  const r = rankings || {};
  const finDetail = ext.financialDetail || {};
  const costRpt = ext.costReports || {};
  const quality = ext.quality || {};
  const trends = ext.trends || {};
  const lease = ext.lease || {};
  const hoursInfo = ext.hours || null;
  const patientHistory = ext.patientHistory || [];
  const payerMix = ext.payerMix || {};
  const competitors = ext.competitors || [];
  const operator = (cmsLink && cmsLink.operator) || _udDetectOperator(r);
  const B = NMQ_BRAND;

  // Derive key values (same logic as _udTabOperations)
  // Financial basis — present ONE consistent basis. The prior export mixed
  // estimated_annual_revenue (a chair-CAPACITY model that overstates revenue for
  // under-utilized clinics) with the HCRIS actual operating profit, producing a
  // nonsensical margin (e.g. $7.6M est. revenue ÷ $522k HCRIS profit = 6.9%, and
  // $1,156/treatment). Prefer HCRIS actuals (reflect real treatment volume); else
  // the estimated model kept internally consistent (its own revenue + profit).
  const _ttmMargin = (r.ttm_operating_margin != null) ? (Math.abs(Number(r.ttm_operating_margin)) < 1 ? Number(r.ttm_operating_margin) : Number(r.ttm_operating_margin) / 100) : null;
  const _ttmProfit = (r.ttm_operating_profit != null) ? Number(r.ttm_operating_profit) : null;
  const _estRev = (finDetail.estimated_annual_revenue != null) ? Number(finDetail.estimated_annual_revenue) : (r.estimated_annual_revenue != null ? Number(r.estimated_annual_revenue) : null);
  const _estProfit = (finDetail.estimated_operating_profit != null) ? Number(finDetail.estimated_operating_profit)
        : (finDetail.estimated_annual_profit != null) ? Number(finDetail.estimated_annual_profit)
        : (r.estimated_annual_profit != null) ? Number(r.estimated_annual_profit) : null;
  let finBasis, estRevenue, bestProfit, margin;
  if (_ttmProfit != null && _ttmMargin != null && _ttmMargin > 0) {
    finBasis = 'hcris';
    estRevenue = _ttmProfit / _ttmMargin;   // the revenue base the HCRIS margin is computed against
    bestProfit = _ttmProfit;
    margin = _ttmMargin * 100;
  } else if (_estRev != null && _estProfit != null && _estRev > 0) {
    finBasis = 'estimated';
    estRevenue = _estRev; bestProfit = _estProfit; margin = (_estProfit / _estRev) * 100;
  } else {
    finBasis = 'partial';
    estRevenue = (_estRev != null) ? _estRev : (r.ttm_revenue != null ? Number(r.ttm_revenue) : null);
    bestProfit = (_ttmProfit != null) ? _ttmProfit : _estProfit;
    margin = (bestProfit != null && estRevenue) ? (Number(bestProfit) / Number(estRevenue)) * 100 : (_ttmMargin != null ? _ttmMargin * 100 : null);
  }
  const latestSnapshotPt = patientHistory.length > 0 ? Number(patientHistory[patientHistory.length - 1].total_patients || 0) : 0;
  const bestPatientCount = latestSnapshotPt > 0 ? latestSnapshotPt : (r.latest_estimated_patients ? Number(r.latest_estimated_patients) : null);
  const starVal = quality.star_rating != null ? Number(quality.star_rating) : (r.star_rating != null ? Number(r.star_rating) : null);
  const ccn = r.medicare_id
    || (cmsLink && cmsLink.medicare_id)
    || property.linked_medicare_facility_id
    || property.medicare_id
    || '';
  const _esc = s => (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const facilityName = _esc(r.facility_name || property.facility_name || property.page_title || (cmsLink && cmsLink.facility_name) || fb.facility_name || 'Dialysis Facility');
  // Address fields are not on v_property_rankings — pull from the
  // merged property (v_property_detail + properties supplemental fetch),
  // then fall back to the search-card record. Without this, the export
  // subtitle was rendering empty for every clinic.
  const addrLine = property.address || fb.address || '';
  const cityVal  = property.city || fb.city || r.city || '';
  const stateVal = property.state || fb.state || r.state || '';
  const zipVal   = property.zip_code || property.zip || fb.zip_code || fb.zip || '';
  const propertyId = property.property_id || _udCache.ids?.property_id || '';
  const address = _esc([addrLine, cityVal, stateVal, zipVal].filter(Boolean).join(', ') || '');
  const stationsVal = r.number_of_chairs || property.number_of_chairs || r.stations || null;
  const buildingSize = property.building_size || null;
  const yearBuilt    = property.year_built || null;
  const yearReno     = property.year_renovated || null;
  const landArea     = property.land_area || property.lot_sf || null;
  const buildingType = property.building_type || '';
  const trendDir = trends.trend_direction || (r.patient_yoy_pct > 2 ? 'Growth' : r.patient_yoy_pct < -2 ? 'Decline' : 'Stable');
  let leaseExp = 'N/A';
  if (lease.expiration_date) { const d = new Date(lease.expiration_date); leaseExp = d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' }); }

  // Costs & treatments follow the chosen basis so revenue / treatments / margin
  // all reconcile (costs = revenue − profit on the SAME basis).
  const bestCosts = (estRevenue != null && bestProfit != null) ? Number(estRevenue) - Number(bestProfit) : null;
  const hcrisTx = costRpt && costRpt.total_treatments ? Number(costRpt.total_treatments) : null;
  const finTxExp = finDetail.estimated_treatments_per_year ? Number(finDetail.estimated_treatments_per_year) : null;
  let annualTx;
  if (finBasis === 'estimated') {
    annualTx = (r.estimated_annual_treatments != null) ? Number(r.estimated_annual_treatments) : (finTxExp || hcrisTx || (bestPatientCount ? bestPatientCount * 156 : null));
  } else {
    // hcris / partial basis → actual reported treatment volume
    annualTx = (r.ttm_total_treatments != null) ? Number(r.ttm_total_treatments) : (hcrisTx || finTxExp || (bestPatientCount ? bestPatientCount * 156 : null));
  }
  const revPerTx = (estRevenue && annualTx) ? (Number(estRevenue) / annualTx) : null;

  // ── Client-export specifics (net-lease framing) ──
  // Headline census = concurrent (point-in-time) figure, which reconciles with
  // chairs / utilization / treatments. The CMS annual snapshot count is a
  // cumulative facility figure kept separate to avoid the 158-vs-31 contradiction
  // the prior export shipped.
  const concurrentCensus = (r.latest_estimated_patients != null) ? Number(r.latest_estimated_patients)
        : (finDetail.patient_count != null ? Number(finDetail.patient_count) : null);
  const cmsAnnualPatients = latestSnapshotPt > 0 ? latestSnapshotPt : null;
  const censusHeadline = concurrentCensus != null ? concurrentCensus : bestPatientCount;
  const utilPct = r.capacity_utilization_pct != null ? Number(r.capacity_utilization_pct) : null;
  const demo = ext.demographics || null;
  // Composite risk (reuse the in-app model so screen + export agree)
  let leaseMonths = null;
  if (lease.expiration_date) { const _ld = new Date(lease.expiration_date); leaseMonths = Math.round((_ld - new Date()) / (1000 * 60 * 60 * 24 * 30.44)); }
  let riskScores = null, riskLevel = '', riskColor = B.muted;
  try {
    if (typeof _computeLeaseRisk === 'function') {
      // The risk model's Patient-Trend factor reads r.patient_yoy_pct, which the
      // pipeline computes from mismatched concurrent-vs-annual counts (can read
      // −80%+ and peg the factor at max). Feed it the clean 3-yr trend annualized
      // (÷3) so the gauge isn't distorted by that artifact. Export-only.
      const _rRisk = Object.assign({}, r, { patient_yoy_pct: (r.patient_trend_3yr != null && isFinite(Number(r.patient_trend_3yr))) ? Number(r.patient_trend_3yr) / 3 : r.patient_yoy_pct });
      riskScores = _computeLeaseRisk(_rRisk, trends, quality, lease, leaseMonths, margin);
      riskLevel = riskScores.total <= 25 ? 'Low' : riskScores.total <= 50 ? 'Moderate' : riskScores.total <= 75 ? 'High' : 'Critical';
      riskColor = riskScores.total <= 25 ? '#2E7D32' : riskScores.total <= 50 ? '#B26A00' : riskScores.total <= 75 ? '#C75300' : '#B3261E';
    }
  } catch (_re) { riskScores = null; }
  // Comparative rankings → percentile (higher = larger). County rank in
  // v_property_rankings groups by county NAME only (ignores state), so it is
  // intentionally excluded from the client export.
  const _pctile = (rank, total) => (rank && total && total > 0) ? Math.max(1, Math.round(((total - rank) / total) * 100)) : null;
  const _ord = n => { if (n == null) return ''; const s = ['th', 'st', 'nd', 'rd'], v = n % 100; return n + (s[(v - 20) % 10] || s[v] || s[0]); };
  // State full-name map — the benchmarking scope label was previously hardcoded
  // to "Tennessee" regardless of the property's actual state.
  const _US_STATES = { AL:'Alabama',AK:'Alaska',AZ:'Arizona',AR:'Arkansas',CA:'California',CO:'Colorado',CT:'Connecticut',DE:'Delaware',DC:'District of Columbia',FL:'Florida',GA:'Georgia',HI:'Hawaii',ID:'Idaho',IL:'Illinois',IN:'Indiana',IA:'Iowa',KS:'Kansas',KY:'Kentucky',LA:'Louisiana',ME:'Maine',MD:'Maryland',MA:'Massachusetts',MI:'Michigan',MN:'Minnesota',MS:'Mississippi',MO:'Missouri',MT:'Montana',NE:'Nebraska',NV:'Nevada',NH:'New Hampshire',NJ:'New Jersey',NM:'New Mexico',NY:'New York',NC:'North Carolina',ND:'North Dakota',OH:'Ohio',OK:'Oklahoma',OR:'Oregon',PA:'Pennsylvania',RI:'Rhode Island',SC:'South Carolina',SD:'South Dakota',TN:'Tennessee',TX:'Texas',UT:'Utah',VT:'Vermont',VA:'Virginia',WA:'Washington',WV:'West Virginia',WI:'Wisconsin',WY:'Wyoming',PR:'Puerto Rico' };
  const stateLabel = _US_STATES[String(stateVal || '').toUpperCase()] || (stateVal || 'State');
  const rankRows = [
    { scope: stateLabel, patRank: r.state_patient_rank, revRank: r.state_revenue_rank, total: r.state_total },
    { scope: 'National', patRank: r.national_patient_rank, revRank: r.national_revenue_rank, total: r.national_total },
  ].filter(x => (x.patRank && x.total) || (x.revRank && x.total));
  const operatorName = _esc(r.chain_organization || r.operator_name || (operator && operator.label) || 'N/A');

  // ── Census trend (consistent definition) ──
  // The pipeline's patient_yoy_pct compares this year's CONCURRENT census (e.g. 47)
  // against last year's ANNUAL/cumulative CMS count (e.g. 297) — mismatched
  // definitions that can read a misleading −80%+. Prefer the clean 3-yr trend;
  // else derive an annual YoY from year-over-year CMS snapshots (same definition),
  // dropping the order-of-magnitude glitch rows.
  function _annualSnapshotYoY(hist) {
    if (!Array.isArray(hist) || hist.length < 2) return null;
    const ys = {};
    hist.forEach(function(h){ const d = String(h.snapshot_date || ''); const v = Number(h.total_patients || 0); if (!d || !(v > 0)) return; const y = d.slice(0,4); const ye = /-12-31$/.test(d); if (!ys[y] || (ye && !ys[y].ye) || (ye === ys[y].ye && d >= ys[y].d)) ys[y] = { d:d, v:v, ye:ye }; });
    const years = Object.keys(ys).sort();
    if (years.length < 2) return null;
    let i = years.length - 1;
    while (i >= 1 && ys[years[i]].v === ys[years[i-1]].v && Number(years[i]) >= new Date().getFullYear()) i--;
    if (i < 1) return null;
    const cur = ys[years[i]].v, prev = ys[years[i-1]].v;
    if (!(prev > 0) || cur > prev * 4 || cur < prev / 4) return null;
    return { pct: ((cur - prev) / prev) * 100, curYear: years[i], prevYear: years[i-1] };
  }
  const trend3yr = (r.patient_trend_3yr != null && isFinite(Number(r.patient_trend_3yr))) ? Number(r.patient_trend_3yr) : null;
  const annualYoY = _annualSnapshotYoY(patientHistory);
  const censusTrendPct = (trend3yr != null) ? trend3yr : (annualYoY ? annualYoY.pct : null);
  const censusTrendLabel = (trend3yr != null) ? 'over 3 yr' : (annualYoY ? 'YoY' : '');
  const trendDirClean = (censusTrendPct == null)
    ? String(trends.trend_direction || trendDir || 'stable').toLowerCase()
    : (censusTrendPct > 2 ? 'growth' : censusTrendPct < -2 ? 'decline' : 'stable');
  const trendDirDisp = trendDirClean.charAt(0).toUpperCase() + trendDirClean.slice(1);
  const isDecline = (censusTrendPct != null && censusTrendPct <= -8);
  // Newly-opened nearby facilities (possible demand-shift driver) — within ~10 mi,
  // certified within ~36 months. certification_date is enriched onto the geo
  // competitors in the ops loader.
  const recentNearby = (ext.geo && Array.isArray(ext.geo.nearby_competitors)) ? ext.geo.nearby_competitors.filter(function(c){
    if (!c.certification_date) return false;
    var cd = new Date(c.certification_date); if (isNaN(cd.getTime())) return false;
    var months = (Date.now() - cd.getTime()) / (1000*60*60*24*30.44);
    return months >= 0 && months <= 36 && (c.distance_miles == null || Number(c.distance_miles) <= 10);
  }).sort(function(a,b){ return (Number(a.distance_miles)||0) - (Number(b.distance_miles)||0); }).slice(0,3) : [];

  // Hours
  let hoursBlock = '<p style="color:' + B.muted + ';font-style:italic">Hours data not available for this facility.</p>';
  if (hoursInfo && hoursInfo.hours_json) {
    const hj = hoursInfo.hours_json;
    const dayOrder = ['mon','tue','wed','thu','fri','sat','sun'];
    const dayNames = { mon: 'Monday', tue: 'Tuesday', wed: 'Wednesday', thu: 'Thursday', fri: 'Friday', sat: 'Saturday', sun: 'Sunday' };
    hoursBlock = '<table style="border-collapse:collapse;font-size:13px">';
    dayOrder.forEach(d => {
      const slots = hj[d];
      const timeStr = (!slots || slots.length === 0) ? '<em style="color:' + B.muted + '">Closed</em>' : slots.map(s => { const [o,c] = s.split('-'); return _fmt12h(o) + ' \u2013 ' + _fmt12h(c); }).join(', ');
      hoursBlock += '<tr><td style="padding:3px 16px 3px 0;font-weight:600;color:' + B.bodyText + '">' + dayNames[d] + '</td><td style="padding:3px 0;color:' + B.darkText + '">' + timeStr + '</td></tr>';
    });
    hoursBlock += '</table>';
    if (hoursInfo.weekly_operating_hours) hoursBlock += '<p style="margin:6px 0 0;font-size:12px;color:' + B.muted + '"><strong style="color:' + B.bodyText + '">' + Number(hoursInfo.weekly_operating_hours).toFixed(0) + ' hours/week</strong>' + (hoursInfo.late_shift ? ' \u00B7 Late shift offered' : '') + '</p>';
  }

  const fmtDollar = v => v ? '$' + Number(v).toLocaleString('en-US', { maximumFractionDigits: 0 }) : 'N/A';
  const fmtPct = v => v != null ? Number(v).toFixed(1) + '%' : 'N/A';
  const fmtSf = v => v ? Number(v).toLocaleString('en-US', { maximumFractionDigits: 0 }) + ' SF' : 'N/A';
  // Land area is stored in acres for some properties and SF for others —
  // <= 50 implies acres, otherwise SF (50 acres = 2.18M SF, well above any
  // single-clinic site). Conservative heuristic; surface both when possible.
  const fmtLand = v => {
    if (v == null) return 'N/A';
    const n = Number(v);
    if (!Number.isFinite(n) || n <= 0) return 'N/A';
    if (n <= 50) return n.toFixed(2) + ' acres';
    return n.toLocaleString('en-US', { maximumFractionDigits: 0 }) + ' SF (' + (n / 43560).toFixed(2) + ' acres)';
  };
  const today = new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });

  const doc = `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>${facilityName} \u2014 Net-Lease Asset Profile | Northmarq</title>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&display=swap" rel="stylesheet">
<style>
  @media print {
    body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .no-print { display:none !important; }
    .page-break { page-break-before: always; }
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: ${B.bodyFont}; color: ${B.bodyText}; max-width: 860px; margin: 0 auto; padding: 0; line-height: 1.55; background: #fff; }

  /* ── Header bar ── */
  .nmq-header { background: ${B.navy}; color: #fff; padding: 24px 40px; display: flex; align-items: center; justify-content: space-between; }
  .nmq-header img { height: 28px; filter: brightness(0) invert(1); }
  .nmq-header .report-type { font-family: ${B.headingFont}; font-size: 13px; letter-spacing: 1.5px; text-transform: uppercase; opacity: 0.8; }

  /* ── Title section ── */
  .title-section { padding: 28px 40px 20px; border-bottom: 3px solid ${B.blue}; }
  .title-section h1 { font-family: ${B.headingFont}; font-size: 26px; font-weight: 700; color: ${B.navy}; margin: 0 0 4px; letter-spacing: -0.3px; }
  .title-section .subtitle { font-size: 14px; color: ${B.muted}; }

  /* ── Content area ── */
  .content { padding: 0 40px 32px; }

  /* ── KPI banner ── */
  .kpi-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin: 24px 0; }
  .kpi { background: ${B.warmWhite}; border-radius: 6px; padding: 16px; text-align: center; border: 1px solid ${B.border}; }
  .kpi-label { font-size: 9px; text-transform: uppercase; letter-spacing: 1px; color: ${B.muted}; margin-bottom: 6px; font-weight: 600; }
  .kpi-value { font-family: ${B.headingFont}; font-size: 22px; font-weight: 700; color: ${B.navy}; }

  /* ── Section headers ── */
  h2 { font-family: ${B.headingFont}; font-size: 14px; text-transform: uppercase; letter-spacing: 1.2px; color: ${B.blue}; border-bottom: 2px solid ${B.blueTint}; padding-bottom: 6px; margin: 28px 0 14px; font-weight: 700; }

  /* ── Data tables ── */
  .data-table { width: 100%; border-collapse: collapse; font-size: 13px; margin-bottom: 16px; }
  .data-table tr:nth-child(even) { background: ${B.warmWhite}; }
  .data-table td { padding: 8px 14px; border-bottom: 1px solid ${B.border}; }
  .data-table td:first-child { color: ${B.muted}; font-weight: 600; width: 210px; }
  .data-table td:last-child { color: ${B.darkText}; font-weight: 500; }

  /* ── Methodology box ── */
  .methodology { background: ${B.blueTint}; border-left: 4px solid ${B.blue}; border-radius: 0 6px 6px 0; padding: 18px 20px; font-size: 12px; color: ${B.bodyText}; line-height: 1.7; margin-top: 24px; }
  .methodology strong { color: ${B.navy}; }

  /* ── Footer ── */
  .nmq-footer { margin-top: 32px; padding: 20px 40px; background: ${B.navy}; color: rgba(255,255,255,0.7); font-size: 11px; display: flex; justify-content: space-between; align-items: center; }
  .nmq-footer strong { color: #fff; }
  .nmq-footer .sources { font-size: 10px; max-width: 50%; text-align: right; }

  /* ── Print button ── */
  .print-btn { position:fixed; top:16px; right:16px; padding:10px 24px; background:${B.blue}; color:white; border:none; border-radius:6px; font-size:14px; font-weight:600; cursor:pointer; font-family:${B.bodyFont}; box-shadow:0 2px 8px rgba(0,61,165,0.3); }
  .print-btn:hover { background:${B.navy}; }

  .star { color: #E97132; }
  .star-empty { color: ${B.border}; }
  .highlight { color: ${B.blue}; font-weight: 700; }

  /* ── Net-lease export additions ── */
  .snap { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin: 22px 0 8px; }
  .sk { background: ${B.warmWhite}; border: 1px solid ${B.border}; border-radius: 6px; padding: 13px 14px; }
  .sk .l { font-size: 8.5px; text-transform: uppercase; letter-spacing: .9px; color: ${B.muted}; font-weight: 700; margin-bottom: 5px; }
  .sk .v { font-family: ${B.headingFont}; font-size: 19px; font-weight: 700; color: ${B.navy}; line-height: 1.1; }
  .sk .v small { font-size: 11px; font-weight: 600; color: ${B.muted}; }
  .sk.accent { background: ${B.blue}; border-color: ${B.blue}; }
  .sk.accent .l { color: rgba(255,255,255,.8); }
  .sk.accent .v { color: #fff; }
  .ctx { display: block; color: ${B.muted}; font-weight: 400; font-size: 11px; margin-top: 2px; }
  h2 .note { float: right; text-transform: none; letter-spacing: 0; font-size: 10.5px; color: ${B.muted}; font-weight: 600; font-family: ${B.bodyFont}; }
  .grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
  .card { border: 1px solid ${B.border}; border-radius: 6px; overflow: hidden; margin-bottom: 6px; }
  .card .ch { background: ${B.blueTint}; color: ${B.navy}; font-family: ${B.headingFont}; font-weight: 700; font-size: 12px; text-transform: uppercase; letter-spacing: .8px; padding: 8px 14px; border-bottom: 1px solid ${B.border}; }
  .card .data-table { margin: 0; }
  .card .data-table td:first-child { width: 140px; }
  .bar { display: inline-block; width: 120px; height: 9px; background: ${B.border}; border-radius: 5px; overflow: hidden; vertical-align: middle; margin-right: 8px; }
  .bar i { display: block; height: 100%; background: ${B.blue}; }
  .pill { display: inline-block; font-size: 10.5px; font-weight: 700; padding: 2px 8px; border-radius: 10px; letter-spacing: .3px; }
  .pill.good { background: #E5F1E6; color: #2E7D32; }
  .pill.warn { background: #FBF0DF; color: #B26A00; }
  .pill.bad  { background: #FBE6E4; color: #B3261E; }
  .pill.neutral { background: ${B.blueTint}; color: ${B.blue}; }
  .callout { background: ${B.blueTint}; border-left: 4px solid ${B.blue}; border-radius: 0 6px 6px 0; padding: 12px 16px; font-size: 12.5px; margin: 10px 0 4px; }
  .callout b { color: ${B.navy}; }
  .rank-row { display: flex; align-items: center; gap: 10px; margin-bottom: 9px; font-size: 12.5px; }
  .rank-row .rl { width: 74px; flex-shrink: 0; color: ${B.muted}; font-weight: 600; }
  .rank-track { flex: 1; height: 18px; background: ${B.warmWhite}; border: 1px solid ${B.border}; border-radius: 4px; position: relative; overflow: hidden; }
  .rank-track i { position: absolute; left: 0; top: 0; bottom: 0; background: ${B.lightBlue}; opacity: .55; }
  .rank-track span { position: absolute; left: 8px; top: 0; line-height: 18px; font-size: 11px; color: ${B.navy}; font-weight: 600; }
  .rank-pct { width: 120px; flex-shrink: 0; text-align: right; color: ${B.bodyText}; font-weight: 600; font-size: 11.5px; }
  .risk-wrap { display: grid; grid-template-columns: 200px 1fr; gap: 18px; align-items: center; }
  .rcmp { display: flex; align-items: center; gap: 8px; margin-bottom: 7px; font-size: 12px; }
  .rcmp .rcl { width: 158px; flex-shrink: 0; color: ${B.muted}; font-weight: 600; }
  .rcmp .rct { flex: 1; height: 6px; background: ${B.warmWhite}; border: 1px solid ${B.border}; border-radius: 3px; overflow: hidden; }
  .rcmp .rct i { display: block; height: 100%; }
  .rcmp .rcv { width: 26px; text-align: right; font-weight: 700; }
  .comp-table { width: 100%; border-collapse: collapse; font-size: 12px; margin-top: 4px; }
  .comp-table th { background: ${B.blueTint}; color: ${B.navy}; border-bottom: 2px solid ${B.blue}; padding: 8px 12px; }
  .comp-table td { padding: 6px 12px; border-bottom: 1px solid ${B.border}; }
</style></head><body>

<button class="print-btn no-print" onclick="window.print()">\u{1F5A8} Print / Save PDF</button>

<!-- Northmarq branded header -->
<div class="nmq-header">
  <img src="${B.logoUrl}" alt="Northmarq" onerror="this.parentElement.innerHTML='<span style=\\'font-family:${B.headingFont};font-size:20px;font-weight:700;letter-spacing:1px\\'>NORTHMARQ</span><span class=\\'report-type\\'>Dialysis Net-Lease &middot; Asset Profile</span>'">
  <div class="report-type">Dialysis Net-Lease &middot; Asset Profile</div>
</div>

<!-- Title -->
<div class="title-section">
  <h1>${facilityName}</h1>
  <div class="subtitle">${address}${operatorName && operatorName !== 'N/A' ? ' &nbsp;\u00B7&nbsp; ' + operatorName : ''}${ccn ? ' &nbsp;\u00B7&nbsp; CCN ' + ccn : ''} &nbsp;\u00B7&nbsp; ${today}</div>
</div>

<div class="content">

<!-- Investment snapshot -->
<div class="snap">
  <div class="sk accent"><div class="l">Operator / Tenant</div><div class="v" style="font-size:15px">${operatorName}</div></div>
  <div class="sk"><div class="l">Asset Type</div><div class="v" style="font-size:14px">${_esc(property.property_type || 'Single-tenant medical')}${buildingSize ? '<br><small>' + Number(buildingSize).toLocaleString() + ' SF</small>' : ''}</div></div>
  <div class="sk"><div class="l">Capacity Utilization</div><div class="v">${utilPct != null ? utilPct.toFixed(1) + '%' : 'N/A'}</div></div>
  <div class="sk"><div class="l">Est. Annual Revenue</div><div class="v">${estRevenue ? '$' + (Number(estRevenue) / 1e6).toFixed(2) + 'M' : 'N/A'}</div></div>
  <div class="sk"><div class="l">Est. Operating Margin</div><div class="v">${fmtPct(margin)}</div></div>
  <div class="sk"><div class="l">Dialysis Stations</div><div class="v">${stationsVal ? Number(stationsVal).toLocaleString() : 'N/A'} <small>chairs</small></div></div>
  <div class="sk"><div class="l">CMS Star Rating</div><div class="v">${starVal != null ? '<span class="star">' + '\u2605'.repeat(Math.floor(starVal)) + '</span><span class="star-empty">' + '\u2606'.repeat(5 - Math.floor(starVal)) + '</span>' : 'N/A'}</div></div>
  <div class="sk"><div class="l">Census Trend</div><div class="v">${trendDirDisp}</div></div>
</div>

<div class="callout"><b>At a glance &mdash;</b> A ${stationsVal ? stationsVal + '-station ' : ''}${operatorName && operatorName !== 'N/A' ? operatorName + ' ' : ''}in-center hemodialysis facility${utilPct != null ? ' running at <b>' + utilPct.toFixed(1) + '% of modeled operating capacity</b>' : ''}${(competitors.length === 0 && r.county) ? ', and the <b>only CMS-certified dialysis provider in ' + _esc(r.county) + ' County' + (stateVal ? ', ' + _esc(stateVal) : '') + '</b>' : ''}. Estimated facility revenue is <b>${fmtDollar(estRevenue)}</b>${annualTx ? ' on ~' + annualTx.toLocaleString() + ' annual treatments' : ''}${(payerMix.private_pct != null || r.payer_mix_private_pct != null) ? ', with a commercial/private payer share of <b>' + Number(payerMix.private_pct != null ? payerMix.private_pct : r.payer_mix_private_pct).toFixed(1) + '%</b>' : ''}.</div>

<!-- Tenant & Operator -->
<h2>Tenant &amp; Operator <span class="note">Source: CMS &middot; operator SEC filings</span></h2>
<table class="data-table">
  <tr><td>Operator</td><td>${operatorName}</td></tr>
  <tr><td>Service Modality</td><td>In-center hemodialysis</td></tr>
  ${stationsVal ? '<tr><td>Dialysis Stations</td><td>' + Number(stationsVal).toLocaleString() + '</td></tr>' : ''}
</table>

<!-- Facility Financial Performance -->
<h2>Facility Financial Performance <span class="note">Source: CMS/HCRIS &middot; operator filings</span></h2>
<table class="data-table">
  <tr><td>Est. Facility Revenue (annual)</td><td>${fmtDollar(estRevenue)}<span class="ctx">${finBasis === 'hcris' ? 'Derived from CMS/HCRIS reported actuals (treatment volume &times; net revenue).' : finBasis === 'estimated' ? 'Estimated (chair-capacity model).' : 'Estimated.'}</span></td></tr>
  <tr><td>Revenue / Treatment (blended)</td><td>${revPerTx ? '$' + revPerTx.toFixed(0) : 'N/A'}<span class="ctx">Weighted by this facility's payer mix.</span></td></tr>
  <tr><td>Est. Operating Profit</td><td>${fmtDollar(bestProfit)}</td></tr>
  <tr><td>Operating Margin</td><td>${fmtPct(margin)}${finBasis === 'estimated' ? (r.ttm_operating_margin != null ? '<span class="ctx">Estimated model; CMS/HCRIS TTM margin ' + (Number(r.ttm_operating_margin) * (Math.abs(Number(r.ttm_operating_margin)) < 1 ? 100 : 1)).toFixed(1) + '%.</span>' : '') : '<span class="ctx">CMS/HCRIS reported actuals (operating profit &divide; net patient revenue).</span>'}</td></tr>
  <tr><td>Annual Treatments</td><td>${annualTx ? annualTx.toLocaleString() : 'N/A'}<span class="ctx">${finBasis === 'estimated' ? 'Modeled at chair capacity.' : 'CMS/HCRIS reported.'}</span></td></tr>
</table>

<!-- Demand & Capacity -->
<h2>Demand &amp; Capacity <span class="note">Source: CMS &middot; HCRIS-derived estimates</span></h2>
<div class="grid2">
  <div class="card">
    <div class="ch">Treatment Demand</div>
    <table class="data-table">
      <tr><td>Dialysis Stations</td><td>${stationsVal ? Number(stationsVal).toLocaleString() : 'N/A'}</td></tr>
      <tr><td>Patients in Treatment <span style="font-size:11px;color:${B.muted}">(concurrent)</span></td><td><strong>${censusHeadline != null ? censusHeadline.toLocaleString() : 'N/A'}</strong></td></tr>
      <tr><td>Patients / Chair</td><td>${(censusHeadline != null && stationsVal) ? (censusHeadline / Number(stationsVal)).toFixed(1) : 'N/A'}</td></tr>
      <tr><td>Capacity Utilization</td><td>${utilPct != null ? '<span class="bar"><i style="width:' + Math.min(100, utilPct).toFixed(0) + '%"></i></span>' + utilPct.toFixed(1) + '%' : 'N/A'}</td></tr>
      <tr><td>Treatments / Year</td><td>${annualTx ? annualTx.toLocaleString() : 'N/A'}</td></tr>
    </table>
  </div>
  <div class="card">
    <div class="ch">Catchment Context</div>
    <table class="data-table">
      <tr><td>CMS Reported Patients <span style="font-size:11px;color:${B.muted}">(annual)</span></td><td>${cmsAnnualPatients != null ? cmsAnnualPatients.toLocaleString() : 'N/A'}<span class="ctx">Cumulative distinct patients per CMS reporting &mdash; not a point-in-time count (see definitions).</span></td></tr>
      <tr><td>Census Trend</td><td>${trendDirDisp}${censusTrendPct != null ? ' (' + (censusTrendPct >= 0 ? '+' : '') + censusTrendPct.toFixed(1) + '% ' + censusTrendLabel + ')' : ''}</td></tr>
      ${(competitors.length === 0 && r.county) ? '<tr><td>County Competition</td><td>Sole facility in ' + _esc(r.county) + ' County</td></tr>' : ''}
    </table>
  </div>
</div>
${(cmsAnnualPatients != null && censusHeadline != null && cmsAnnualPatients > censusHeadline * 1.5) ? '<div class="callout"><b>Reconciling the two patient figures &mdash;</b> The facility treats roughly <b>' + censusHeadline.toLocaleString() + ' patients at a time</b> &mdash; the figure that reconciles with chairs, utilization, and annual treatments. CMS separately reports <b>' + cmsAnnualPatients.toLocaleString() + '</b> distinct patients served over its annual reporting window, a cumulative count (new starts, transfers, short-stay) shown here as catchment depth, not chair load.</div>' : ''}
${(isDecline && recentNearby.length > 0) ? ('<div class="callout"><b>Census context &mdash;</b> The CMS-reported patient base has declined approximately ' + Math.abs(censusTrendPct).toFixed(0) + '% ' + censusTrendLabel + '. Newly-certified dialysis capacity has opened nearby during this period, which can redistribute catchment demand: ' + recentNearby.map(function(c){ var nm = _esc(c.facility_name || c.tenant || c.address || 'a nearby facility'); var cd = new Date(c.certification_date); var when = cd.toLocaleDateString('en-US', { month:'short', year:'numeric' }); var mi = (c.distance_miles != null) ? Number(c.distance_miles).toFixed(1) + ' mi' : ''; return nm + ' (certified ' + when + (mi ? ', ' + mi : '') + ')'; }).join('; ') + '.</div>') : ''}

<h2>Hours of Operation</h2>
${hoursBlock}

<h2>Quality Metrics</h2>
<table class="data-table">
  <tr><td>CMS Star Rating</td><td>${starVal != null ? starVal + ' / 5' : 'N/A'}</td></tr>
  <tr><td>Mortality Rate</td><td>${quality.mortality_rate != null ? Number(quality.mortality_rate).toFixed(1) + ' (national avg: 15.0)' : 'N/A'}</td></tr>
  <tr><td>Hospitalization Rate</td><td>${quality.hospitalization_rate != null ? Number(quality.hospitalization_rate).toFixed(1) + ' (national avg: 150.0)' : 'N/A'}</td></tr>
  <tr><td>Readmission Rate</td><td>${quality.readmission_rate != null ? Number(quality.readmission_rate).toFixed(1) + ' (national avg: 25.0)' : 'N/A'}</td></tr>
  <tr><td>Infection Ratio</td><td>${quality.infection_ratio != null ? Number(quality.infection_ratio).toFixed(2) : 'N/A'}</td></tr>
  <tr><td>Deficiency Count</td><td>${r.deficiency_count != null ? r.deficiency_count : 'N/A'}</td></tr>
</table>

<h2>Payer Mix</h2>
<table class="data-table">
  <tr><td>Medicare</td><td>${payerMix.medicare_pct != null ? Number(payerMix.medicare_pct).toFixed(1) + '%' : (r.payer_mix_medicare_pct != null ? Number(r.payer_mix_medicare_pct).toFixed(1) + '%' : 'N/A')}</td></tr>
  <tr><td>Medicaid</td><td>${payerMix.medicaid_pct != null ? Number(payerMix.medicaid_pct).toFixed(1) + '%' : (r.payer_mix_medicaid_pct != null ? Number(r.payer_mix_medicaid_pct).toFixed(1) + '%' : 'N/A')}</td></tr>
  <tr><td>Commercial / Private</td><td>${payerMix.private_pct != null ? Number(payerMix.private_pct).toFixed(1) + '%' : (r.payer_mix_private_pct != null ? Number(r.payer_mix_private_pct).toFixed(1) + '%' : 'N/A')}</td></tr>
</table>

<div class="page-break"></div>
${rankRows.length > 0 ? ('<h2>Comparative Benchmarking <span class="note">Source: CMS' + (r.national_total ? ' &middot; ' + Number(r.national_total).toLocaleString() + ' U.S. facilities' : '') + '</span></h2><p style="font-size:12px;color:' + B.muted + ';margin-bottom:10px">Percentile shows where this facility ranks among peers (higher = larger).' + ((competitors.length === 0 && r.county) ? ' County-level ranking is omitted where the facility is the only one in its county.' : '') + '</p>' + rankRows.map(function(rs){ var out=''; var pp=_pctile(rs.patRank, rs.total); var rp=_pctile(rs.revRank, rs.total); if (pp!=null) out += '<div class="rank-row"><div class="rl">' + rs.scope + '</div><div class="rank-track"><i style="width:' + pp + '%"></i><span>By patients &middot; #' + Number(rs.patRank).toLocaleString() + ' of ' + Number(rs.total).toLocaleString() + '</span></div><div class="rank-pct">' + _ord(pp) + ' pctile</div></div>'; if (rp!=null) out += '<div class="rank-row"><div class="rl"></div><div class="rank-track"><i style="width:' + rp + '%;background:' + B.blue + ';opacity:.45"></i><span>By revenue &middot; #' + Number(rs.revRank).toLocaleString() + ' of ' + Number(rs.total).toLocaleString() + '</span></div><div class="rank-pct">' + _ord(rp) + ' pctile</div></div>'; return out; }).join('')) : ''}

${riskScores ? ('<h2>Risk Assessment <span class="note">Composite lease-renewal model &middot; 0 (low) \u2013 100 (high)</span></h2><div class="risk-wrap"><div style="text-align:center"><svg width="190" height="112" viewBox="0 0 190 112"><path d="M 22 96 A 73 73 0 0 1 168 96" fill="none" stroke="' + B.blueTint + '" stroke-width="14" stroke-linecap="round"/><path d="M 22 96 A 73 73 0 0 1 168 96" fill="none" stroke="' + riskColor + '" stroke-width="14" stroke-linecap="round" stroke-dasharray="' + (Math.max(0, Math.min(100, riskScores.total)) / 100 * 229.3).toFixed(1) + ' 229.3"/><text x="95" y="86" text-anchor="middle" font-family="' + B.headingFont + '" font-size="34" font-weight="700" fill="' + riskColor + '">' + riskScores.total + '</text><text x="95" y="104" text-anchor="middle" font-family="' + B.bodyFont + '" font-size="11" fill="' + B.muted + '">out of 100</text></svg><div style="margin-top:6px"><span class="pill ' + (riskScores.total <= 25 ? 'good' : riskScores.total <= 50 ? 'warn' : 'bad') + '">' + riskLevel + ' Risk</span></div></div><div>' + [['Patient Trend (30%)', riskScores.patientTrend], ['Financial Health (25%)', riskScores.financial], ['Quality Metrics (20%)', riskScores.quality], ['Lease Expiration (15%)', riskScores.leaseExp], ['Market Conditions (10%)', riskScores.market]].map(function(p){ var val=p[1]; var c = val <= 25 ? '#2E7D32' : val <= 50 ? '#B26A00' : val <= 75 ? '#C75300' : '#B3261E'; return '<div class="rcmp"><div class="rcl">' + p[0] + '</div><div class="rct"><i style="width:' + val + '%;background:' + c + '"></i></div><div class="rcv" style="color:' + c + '">' + val + '</div></div>'; }).join('') + '<p style="font-size:11px;color:' + B.muted + ';margin-top:6px">Lower component scores indicate lower risk; see definitions for inputs.</p></div></div>') : ''}

${demo ? ('<h2>Demand Demographics' + (demo.zip_code ? ' &mdash; ZIP ' + _esc(String(demo.zip_code)) : '') + ' <span class="note">Source: U.S. Census ACS' + (demo.data_year ? ' (' + demo.data_year + ')' : '') + '</span></h2><table class="data-table">' + (demo.total_population != null ? '<tr><td>Catchment Population</td><td>' + Number(demo.total_population).toLocaleString() + '</td></tr>' : '') + (demo.population_65_plus_pct != null ? '<tr><td>Population Age 65+</td><td>' + (demo.population_65_plus != null ? Number(demo.population_65_plus).toLocaleString() + ' &middot; ' : '') + Number(demo.population_65_plus_pct).toFixed(1) + '%<span class="ctx">ESRD prevalence rises sharply with age; the 65+ share is a structural demand indicator.</span></td></tr>' : '') + (demo.median_household_income != null ? '<tr><td>Median Household Income</td><td>$' + Number(demo.median_household_income).toLocaleString() + '</td></tr>' : '') + (demo.uninsured_rate != null ? '<tr><td>Uninsured Rate</td><td>' + Number(demo.uninsured_rate).toFixed(1) + '%</td></tr>' : '') + (demo.poverty_rate != null ? '<tr><td>Poverty Rate</td><td>' + Number(demo.poverty_rate).toFixed(1) + '%</td></tr>' : '') + '</table>') : ''}

${(function(){ var geoComps = (ext.geo && ext.geo.subject_geocoded && Array.isArray(ext.geo.nearby_competitors)) ? ext.geo.nearby_competitors : []; var useGeo = geoComps.length > 0; var list = useGeo ? geoComps : competitors; var h = '<h2>Market Position <span class="note">Source: CMS Provider of Services</span></h2>'; h += '<table class="data-table"><tr><td>In-County Competition</td><td>' + (competitors.length === 0 ? ('None &mdash; sole CMS-certified dialysis facility' + (r.county ? ' in ' + _esc(r.county) + ' County' : '')) : (competitors.length + ' other ' + (competitors.length === 1 ? 'facility' : 'facilities') + (r.county ? ' in ' + _esc(r.county) + ' County' : ''))) + '</td></tr></table>'; if (list.length > 0) { var rows = list.map(function(c){ var name = useGeo ? (c.address || c.facility_name || '\u2014') : (c.facility_name || ''); var city = (c.city || '') + (useGeo && c.state ? ', ' + c.state : ''); var op = c.operator || c.chain_canonical || c.chain_organization || 'Independent'; var chairs = c.number_of_chairs != null ? Number(c.number_of_chairs).toLocaleString() : '\u2014'; var pts = c.latest_estimated_patients != null ? Number(c.latest_estimated_patients).toLocaleString() : '\u2014'; var dist = (c.distance_miles != null) ? Number(c.distance_miles).toFixed(1) + ' mi' : '—'; var rent = (c.rent_psf != null) ? '$' + Number(c.rent_psf).toFixed(2) : '\u2014'; return '<tr><td>' + name + '</td><td>' + city + '</td><td style="text-align:right;white-space:nowrap">' + dist + '</td><td>' + op + '</td><td style="text-align:right">' + chairs + '</td><td style="text-align:right">' + pts + '</td><td style="text-align:right">' + rent + '</td></tr>'; }).join(''); h += '<table class="comp-table"><thead><tr><th style="text-align:left">' + (useGeo ? 'Nearest Facility' : 'Facility') + '</th><th style="text-align:left">City</th><th style="text-align:right">Distance</th><th style="text-align:left">Operator</th><th style="text-align:right">Chairs</th><th style="text-align:right">Patients</th><th style="text-align:right">Rent PSF</th></tr></thead><tbody>' + rows + '</tbody></table><p style="font-size:11px;color:' + B.muted + ';margin-top:6px">Rent / PSF is shown where a confirmed lease comp exists.</p>'; } else if (competitors.length === 0) { h += '<p style="font-size:12px;color:' + B.muted + ';margin-top:6px">No competing dialysis facility operates within the county; nearest facilities are in adjacent counties.</p>'; } return h; })()}

<h2>Property Details</h2>
<table class="data-table">
  <tr><td>Address</td><td>${_esc([addrLine, cityVal, stateVal, zipVal].filter(Boolean).join(', ') || 'N/A')}</td></tr>
  <tr><td>Building Size</td><td>${fmtSf(buildingSize)}</td></tr>
  <tr><td>Land Area</td><td>${fmtLand(landArea)}</td></tr>
  <tr><td>Property Type</td><td>${_esc(property.property_type || buildingType || 'N/A')}</td></tr>
  <tr><td>Year Built</td><td>${yearBuilt ? _esc(String(yearBuilt)) + (yearReno ? ' (renovated ' + _esc(String(yearReno)) + ')' : '') : 'N/A'}</td></tr>
</table>

<div class="methodology">
  <strong>Methodology & Data Sources</strong><br><br>
  <strong style="color:${B.navy}">Revenue Estimation</strong><br>
  Revenue estimates are derived from a 4-payer blended reimbursement model applied to estimated annual treatment volume. Payer-specific rates reflect current CMS reimbursement schedules: Medicare ~$279/treatment, Medicaid ~$225/treatment, Commercial/Private ~$1,100/treatment, and Other ~$250/treatment. The blended average is approximately $357/treatment. Treatment volume assumes 156 treatments per patient per year (3x weekly, 52 weeks).<br><br>
  <strong style="color:${B.navy}">Treatment Volume</strong><br>
  Annual treatment counts follow a data-priority hierarchy: (1) HCRIS cost report actuals, (2) XGBoost primary financial model estimates, (3) CMS-reported trailing twelve month totals, (4) modeled from patient census (patients \u00D7 156). The chair-based capacity model (stations \u00D7 3 shifts \u00D7 5.5 days \u00D7 52 weeks \u00D7 65% utilization) has been validated against reported figures with a median accuracy of 1.00x across 7,115 facilities.<br><br>
  <strong style="color:${B.navy}">Capacity Utilization</strong><br>
  Capacity Utilization is a modeled estimate of treatment volume against the facility's estimated operating capacity (stations &times; shifts &times; operating days &times; a standard utilization factor) &mdash; <em>not</em> a real-time occupancy reading. A figure near 90% indicates the facility is modeled to run close to its practical chair throughput; it does not mean that share of chairs is filled at any single moment.<br><br>
  <strong style="color:${B.navy}">Patient Counts</strong><br>
  "Patients in Treatment (concurrent)" is the estimated point-in-time census (HCRIS-derived) and is the figure that reconciles with chairs, utilization, and annual treatments. "CMS Reported Patients (annual)" is the cumulative count of distinct patients served over CMS's reporting window and is typically several times larger; it is shown as catchment depth only.<br><br>
  <strong style="color:${B.navy}">Comparative Benchmarking</strong><br>
  Percentile rank among CMS-certified dialysis facilities by estimated patient volume and revenue, within the state and nationally (higher percentile = larger facility). County-level ranking is omitted where the facility is the only one in its county.<br><br>
  <strong style="color:${B.navy}">Operating Costs & Margins</strong><br>
  Operating costs are sourced from: (1) CMS HCRIS facility cost reports (actual facility-level data), or (2) derived from revenue minus operating profit where HCRIS data is unavailable or reflects known Medicare-only allocation quirks. Margins are calculated as operating profit divided by revenue.<br><br>
  <strong style="color:${B.navy}">Revenue Projections</strong><br>
  Projected revenue uses a growth-rate approach: current revenue is scaled by the ratio of projected-to-current patient census, plus 3% annual inflation compounding. This avoids per-patient revenue inflation caused by multi-modality census counts (in-center HD, home HD, peritoneal dialysis) that differ in reimbursement rates. Patient projections are derived from regression analysis of historical CMS enrollment snapshots.<br><br>
  <strong style="color:${B.navy}">Quality & Risk Metrics</strong><br>
  Quality data sourced from CMS Dialysis Facility Compare. Mortality, hospitalization, and readmission rates are per 100 patient-years, benchmarked against national averages (mortality ~15, hospitalization ~150, readmission ~25). The composite lease renewal risk score (0\u2013100) weights five factors: Patient Trend (30%), Financial Health (25%), Quality Metrics (20%), Lease Expiration (15%), and Market Conditions (10%).<br><br>
  <strong style="color:${B.navy}">Competitive Landscape</strong><br>
  Competitor data includes all CMS-certified dialysis facilities in the same county, sourced from the CMS Provider of Services file. Patient counts reflect the most recent CMS enrollment snapshot. Geocoded distance-based analysis will be available in a future release.<br><br>
  <strong style="color:${B.navy}">Data Sources</strong><br>
  CMS Dialysis Facility Compare, CMS HCRIS Cost Reports, CMS Provider of Services, USRDS Annual Data Report, MedPAC Payment Reports, DaVita/Fresenius 10-K SEC Filings, U.S. Census ACS Demographics, CDC PLACES Health Data, Google Places API (hours of operation).
</div>

</div><!-- end content -->

<!-- Northmarq branded footer -->
<div class="nmq-footer">
  <div><strong>Northmarq</strong> &nbsp;\u00B7&nbsp; Confidential &nbsp;\u00B7&nbsp; ${today}</div>
  <div class="sources">Sources: CMS Dialysis Facility Compare, CMS HCRIS, CMS Provider of Services, USRDS, MedPAC, operator 10-K filings, U.S. Census ACS, Google Places</div>
</div>

</body></html>`;

  const blob = new Blob([doc], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  window.open(url, '_blank');
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}
window._udExportOperations = _udExportOperations;

/** Compact star display for KPI card */
function _starsCompact(n) {
  if (n == null) return 'N/A';
  const full = Math.floor(n);
  const color = n >= 4 ? 'var(--green)' : n >= 3 ? 'var(--yellow)' : 'var(--red)';
  return '<span style="color:' + color + ';letter-spacing:1px">' +
    '&#9733;'.repeat(full) +
    '<span class="t-muted3">' + '&#9734;'.repeat(5 - full) + '</span>' +
    '</span>';
}

/** Patient history sparkline (inline SVG) */
function _opsSparkline(history) {
  if (!history || history.length < 2) return '';
  const pts = history.map(h => Number(h.total_patients || h.patient_count || 0)).filter(v => v > 0);
  if (pts.length < 2) return '';

  const w = 280, h = 50, pad = 4;
  const min = Math.min(...pts), max = Math.max(...pts);
  const range = max - min || 1;

  const points = pts.map((v, i) => {
    const x = pad + (i / (pts.length - 1)) * (w - 2 * pad);
    const y = pad + (1 - (v - min) / range) * (h - 2 * pad);
    return x.toFixed(1) + ',' + y.toFixed(1);
  });

  const lastVal = pts[pts.length - 1];
  const firstVal = pts[0];
  const trendColor = lastVal >= firstVal ? 'var(--green)' : 'var(--red)';

  let svg = '<div style="margin-bottom:8px">';
  svg += '<div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text3);margin-bottom:2px">';
  svg += '<span>' + (history[0].snapshot_date ? _fmtDate(history[0].snapshot_date) : '') + '</span>';
  svg += '<span>Patient Census History</span>';
  svg += '<span>' + (history[history.length - 1].snapshot_date ? _fmtDate(history[history.length - 1].snapshot_date) : '') + '</span>';
  svg += '</div>';
  svg += '<svg width="100%" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" preserveAspectRatio="none" style="display:block">';
  // Fill area
  svg += '<polygon points="' + pad + ',' + h + ' ' + points.join(' ') + ' ' + (w - pad) + ',' + h + '" fill="' + trendColor + '" fill-opacity="0.08"/>';
  // Line
  svg += '<polyline points="' + points.join(' ') + '" fill="none" stroke="' + trendColor + '" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>';
  // Endpoint dot
  const lastPt = points[points.length - 1].split(',');
  svg += '<circle cx="' + lastPt[0] + '" cy="' + lastPt[1] + '" r="3" fill="' + trendColor + '"/>';
  svg += '</svg>';
  svg += '<div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text2)">';
  svg += '<span>' + fmtN(firstVal) + ' patients</span>';
  svg += '<span style="font-weight:600;color:' + trendColor + '">' + fmtN(lastVal) + ' patients</span>';
  svg += '</div>';
  svg += '</div>';
  return svg;
}

/** Compute composite lease risk score (0-100) */
function _computeLeaseRisk(r, trends, quality, lease, leaseMonths, margin) {
  // Patient Trend Risk (30%)
  let ptRisk = 50; // default moderate
  if (r.patient_yoy_pct != null) {
    const yoy = Number(r.patient_yoy_pct);
    ptRisk = yoy > 5 ? 10 : yoy > 0 ? 25 : yoy > -5 ? 60 : yoy > -10 ? 80 : 95;
  }
  if (trends.trend_direction === 'growth') ptRisk = Math.min(ptRisk, 20);
  if (trends.trend_direction === 'decline') ptRisk = Math.max(ptRisk, 70);

  // Financial Risk (25%)
  let finRisk = 50;
  if (margin != null) {
    finRisk = margin > 15 ? 10 : margin > 8 ? 25 : margin > 3 ? 50 : margin > 0 ? 75 : 95;
  }

  // Quality Risk (20%)
  let qRisk = 50;
  const stars = quality.star_rating != null ? Number(quality.star_rating) : (r.star_rating != null ? Number(r.star_rating) : null);
  if (stars != null) {
    qRisk = stars >= 4 ? 15 : stars >= 3 ? 35 : stars >= 2 ? 65 : 90;
  }

  // Lease Expiration Risk (15%)
  let leaseRisk = 50;
  if (leaseMonths != null) {
    leaseRisk = leaseMonths > 84 ? 10 : leaseMonths > 60 ? 20 : leaseMonths > 36 ? 40 : leaseMonths > 24 ? 60 : leaseMonths > 12 ? 80 : 95;
  }

  // Market Risk (10%) — use utilization as proxy
  let mktRisk = 50;
  if (r.capacity_utilization_pct != null) {
    const util = Number(r.capacity_utilization_pct);
    mktRisk = util >= 85 ? 15 : util >= 70 ? 35 : util >= 50 ? 60 : 85;
  }

  const total = Math.round(ptRisk * 0.30 + finRisk * 0.25 + qRisk * 0.20 + leaseRisk * 0.15 + mktRisk * 0.10);
  return {
    total: Math.min(100, Math.max(0, total)),
    patientTrend: Math.round(ptRisk),
    financial: Math.round(finRisk),
    quality: Math.round(qRisk),
    leaseExp: Math.round(leaseRisk),
    market: Math.round(mktRisk)
  };
}

/** Quality metric with national benchmark comparison */
function _qualityBenchmark(value, natlAvg, direction) {
  // direction: 'lower' = lower is better, 'higher' = higher is better
  const v = Number(value);
  const ratio = v / natlAvg;
  let color, label;
  if (direction === 'lower') {
    color = ratio <= 0.9 ? 'var(--green)' : ratio <= 1.15 ? 'var(--yellow)' : 'var(--red)';
    label = ratio <= 0.9 ? 'Better' : ratio <= 1.15 ? 'Near Avg' : 'Above Avg';
  } else {
    color = ratio >= 1.1 ? 'var(--green)' : ratio >= 0.85 ? 'var(--yellow)' : 'var(--red)';
    label = ratio >= 1.1 ? 'Better' : ratio >= 0.85 ? 'Near Avg' : 'Below Avg';
  }
  return '<span style="font-weight:600">' + v.toFixed(1) + '</span>' +
    ' <span style="font-size:10px;color:var(--text3)">vs ' + natlAvg.toFixed(0) + ' avg</span>' +
    ' <span style="font-size:9px;padding:1px 5px;border-radius:6px;background:' + color + '22;color:' + color + ';font-weight:600">' + label + '</span>';
}

/** Format large numbers compactly ($1.2M, $450K) */
function _fmtCompact(n) {
  const v = Number(n);
  if (v >= 1e6) return (v / 1e6).toFixed(1) + 'M';
  if (v >= 1e3) return (v / 1e3).toFixed(0) + 'K';
  return fmtN(v);
}

/** Trend arrow with optional label */
function _trendArrow(pct, label) {
  if (pct == null) return '';
  const v = Number(pct);
  const arrow = v > 0 ? '&#9650;' : v < 0 ? '&#9660;' : '&#9654;';
  const color = v > 0 ? 'var(--green)' : v < 0 ? 'var(--red)' : 'var(--text3)';
  return '<span style="font-size:12px;color:' + color + '">' + arrow + ' ' + (v > 0 ? '+' : '') + v.toFixed(1) + '%' + (label ? ' <span class="t-muted3">' + esc(label) + '</span>' : '') + '</span>';
}

/** Trend badge (colored pill) */
function _trendBadge(pct, label) {
  if (pct == null) return '';
  const v = Number(pct);
  const color = v > 0 ? 'var(--green)' : v < 0 ? 'var(--red)' : 'var(--text3)';
  return '<span style="display:inline-block;font-size:10px;padding:1px 6px;border-radius:8px;background:' + color + '22;color:' + color + '">' + (v > 0 ? '+' : '') + v.toFixed(1) + '% ' + esc(label) + '</span>';
}

/** Compare TTM to estimated with trend arrow */
function _trendCompare(actual, estimate, label) {
  if (!estimate || Number(estimate) === 0) return '';
  const diff = ((Number(actual) - Number(estimate)) / Number(estimate) * 100).toFixed(1);
  return _trendArrow(diff, label);
}

/** Row with trend indicator */
function _rowTrend(label, value, pctChange) {
  if (!value) return '';
  return '<div class="detail-row"><span class="detail-label">' + esc(label) + '</span><span class="detail-value">' + value + (pctChange != null ? ' ' + _trendArrow(pctChange) : '') + '</span></div>';
}

/** Utilization bar with color coding */
function _utilBar(pct) {
  const color = pct >= 85 ? 'var(--green)' : pct >= 65 ? 'var(--yellow)' : 'var(--red)';
  return '<span style="display:inline-flex;align-items:center;gap:8px">' + pct.toFixed(1) + '%' +
    '<span style="display:inline-block;width:60px;height:6px;background:var(--s2);border-radius:3px;overflow:hidden;vertical-align:middle">' +
    '<span style="display:block;width:' + Math.min(pct, 100) + '%;height:100%;background:' + color + ';border-radius:3px"></span></span></span>';
}

/** Margin badge with color */
function _marginBadge(margin) {
  const color = margin >= 12 ? 'var(--green)' : margin >= 0 ? 'var(--yellow)' : 'var(--red)';
  return '<span style="color:' + color + ';font-weight:600">' + margin.toFixed(1) + '%</span>';
}

/** Render a ranking bar with visual indicator */
function _rankingBar(label, rank, total, context) {
  if (!rank || !total) return '';
  const pct = ((total - rank + 1) / total * 100).toFixed(0);
  const color = pct >= 75 ? 'var(--green)' : pct >= 50 ? 'var(--yellow)' : pct >= 25 ? 'var(--orange)' : 'var(--red)';
  return `
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
        <span style="font-size:12px;color:var(--text2)">${esc(label)}${context ? ' · ' + esc(String(context)) : ''}</span>
        <span style="font-size:13px;font-weight:600;color:${color}">#${fmtN(Number(rank))} of ${fmtN(Number(total))}</span>
      </div>
      <div style="background:var(--s2);border-radius:4px;height:6px;overflow:hidden">
        <div style="width:${pct}%;height:100%;background:${color};border-radius:4px;transition:width 0.3s"></div>
      </div>
      <div style="text-align:right;font-size:11px;color:var(--text3);margin-top:2px">Top ${100 - Number(pct)}%</div>
    </div>`;
}

// ─── OWNERSHIP + CRM TAB ────────────────────────────────────────────────────

/**
 * Dedup ownership_history rows for the chain timeline.
 * Merges entries that point at the same owner_entity (recorded_owner_id,
 * true_owner_id, or normalized recorded_owner_name) so that the same shell
 * LLC doesn't appear as both the current owner AND a historical owner.
 * Earliest transfer_date wins; latest ownership_end wins; counts how many
 * source rows were merged so the UI can surface it.
 */
function _udDedupChain(chain, currentOwn) {
  if (!Array.isArray(chain) || chain.length === 0) return [];

  // Belt-and-suspenders alongside the dia_purge_operator_owner_links() purge
  // and v_ownership_current.true_owner_is_operator: drop CMS chain-org rows
  // tagged ownership_source='cms_operator_chain' by Round 76aj
  // (20260428030000). That tag is reserved for synthetic operator-presence
  // shims from CMS ingestion (DaVita / Fresenius / etc.) — they are not
  // ownership transfers and don't belong on the timeline. Note we drop
  // unconditionally on the source tag: Round 76aj Step 2 inherited a
  // recorded_owner_id from any linked sale, and prior CMS-chain ingestion
  // may have left a synthetic true_owner_id pointing at the chain
  // operator's entity in true_owners (e.g. 10505 Jones Rd, Houston shows
  // ✓Salesforce on its Fresenius shim despite having no real deed). The
  // FK is itself synthetic when the source is cms_operator_chain — trust
  // the source tag.
  chain = chain.filter((h) => {
    if (!h) return false;
    const src = String(h.ownership_source || '').toLowerCase();
    if (src === 'cms_operator_chain') return false;
    return true;
  });
  if (chain.length === 0) return [];

  // Normalize a name so "Mds Dv Victorville, LLC." == "mds dv victorville llc"
  // R5-DQ-2 (2026-05-20): also strip the same " by <Brokerage>" suffix the
  // sidebar pipeline now sanitizes on write, so any chain rows that still
  // carry the old suffixed text (older sidebar/legacy data) dedup against
  // their cleaned-up cousins.
  const _BROKER_SUFFIX_RE = /\s+by\s+(northmarq|cbre|jll|colliers( international)?|newmark|cushman( & wakefield)?|marcus( & millichap)?|matthews( real estate)?|matthews|berkadia|hanley|capital pacific|nai( [a-z]+)?|stream realty|kw commercial|trinity|avison( young)?|stan johnson( company)?|sjc)\.?\s*$/i;
  const _normName = (s) => {
    if (!s) return '';
    return String(s).toLowerCase()
      .replace(_BROKER_SUFFIX_RE, '')
      .replace(/[.,]/g, ' ')
      .replace(/\b(llc|inc|l\.p\.|lp|corp|corporation|company|co|ltd|trust)\b/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  };

  // Collect every identity hint on a row — any of these matching another row
  // means they reference the same owner entity.
  const _candidateKeys = (h) => {
    const keys = [];
    // Primary: owner_entity_id (the true canonical entity key)
    if (h.owner_entity_id) keys.push('id:' + h.owner_entity_id);
    // All other id columns live in the SAME namespace so cross-column matches
    // (e.g. chain.recorded_owner_id === currentOwn.true_owner_id) still merge.
    if (h.recorded_owner_id) keys.push('id:' + h.recorded_owner_id);
    if (h.true_owner_id)     keys.push('id:' + h.true_owner_id);
    // Name fallback (normalized, so "LLC" suffix differences don't split).
    const names = [h.recorded_owner_name, h.to_owner, h.true_owner_name, h.name]
      .map(_normName).filter(Boolean);
    names.forEach(function(n) { keys.push('nm:' + n); });
    // R5-DQ-4 (2026-05-20): also key on (sale_id) and (sale_price + transfer
    // year) so phantom ownership_history rows that were back-filled from a
    // sale before the sidebar pipeline rebuilt the row collapse onto the
    // canonical entry, even when the owner-id linkage diverges. Example:
    // property 23146 had a 2022 Northmarq sale rendered twice (dated
    // ownership_id 14287 with recorded_owner_id; undated 317 with
    // true_owner_id pointing at a now-merged variant).
    if (h.sale_id != null) keys.push('sale:' + h.sale_id);
    const _price = h.sale_price != null ? Math.round(Number(h.sale_price)) : null;
    if (_price && _price > 0) {
      const _year = h.transfer_date ? String(h.transfer_date).slice(0, 4) : '';
      // Use price+year (yearless OK) — same price within the same year is a
      // strong fingerprint for the same deal even if one row has no date.
      keys.push('pxyr:' + _price + ':' + _year);
    }
    return keys;
  };

  const _ts = (s) => { if (!s) return null; const t = new Date(s).getTime(); return isNaN(t) ? null : t; };

  const groups = [];     // array of group objects
  const keyToGroup = new Map(); // key → group reference

  for (const h of chain) {
    const keys = _candidateKeys(h);
    // Find any existing group that shares at least one key with this row.
    let group = null;
    for (const k of keys) {
      if (keyToGroup.has(k)) { group = keyToGroup.get(k); break; }
    }
    if (!group) {
      group = Object.assign({}, h);
      group._merged_count = 1;
      group._keys = new Set(keys);
      groups.push(group);
    } else {
      group._merged_count = (group._merged_count || 1) + 1;
      // Earliest transfer_date wins
      const t1 = _ts(group.transfer_date), t2 = _ts(h.transfer_date);
      if (t2 != null && (t1 == null || t2 < t1)) group.transfer_date = h.transfer_date;
      // R5-DQ-4 (2026-05-20): only prefer null ownership_end when the
      // incoming row also has a real transfer_date — a row with null
      // transfer_date AND null ownership_end is a phantom backfill
      // signal (no data), not a "still owned" signal, and must not
      // clobber a sibling row's real closed-end date.
      if (h.ownership_end == null && _ts(h.transfer_date) != null) {
        group.ownership_end = null;
      } else if (h.ownership_end != null && group.ownership_end != null) {
        const e1 = _ts(group.ownership_end), e2 = _ts(h.ownership_end);
        if (e2 != null && (e1 == null || e2 > e1)) group.ownership_end = h.ownership_end;
      } else if (h.ownership_end != null && group.ownership_end == null
                 && _ts(group.transfer_date) == null) {
        // Group's null end came from a phantom; promote the real end-date.
        group.ownership_end = h.ownership_end;
      }
      // Backfill any missing fields from later rows
      ['sale_price','cap_rate','ownership_type','ownership_source','principal_names',
       'true_owner_name','true_owner_id','recorded_owner_name','recorded_owner_id',
       'owner_entity_id','sf_account_id','sf_company_id','sf_contact_id',
       'from_owner','to_owner','state_of_incorporation','recorded_owner_state',
       'annual_rent','square_feet','research_status'].forEach(function(f) {
        if (group[f] == null && h[f] != null) group[f] = h[f];
      });
      keys.forEach(function(k) { group._keys.add(k); });
    }
    // Index every key onto this group so later rows can find it.
    keys.forEach(function(k) { keyToGroup.set(k, group); });
  }

  // If the current owner (from v_ownership_current) matches a chain group,
  // mark that group as "is open" so the timeline shows "Present" correctly.
  if (currentOwn) {
    const curKeys = [];
    if (currentOwn.owner_entity_id)   curKeys.push('id:' + currentOwn.owner_entity_id);
    if (currentOwn.recorded_owner_id) curKeys.push('id:' + currentOwn.recorded_owner_id);
    if (currentOwn.true_owner_id)     curKeys.push('id:' + currentOwn.true_owner_id);
    [currentOwn.recorded_owner, currentOwn.true_owner]
      .map(_normName).filter(Boolean)
      .forEach(function(n) { curKeys.push('nm:' + n); });
    for (const k of curKeys) {
      if (keyToGroup.has(k)) { keyToGroup.get(k).ownership_end = null; break; }
    }
  }

  // Strip internal fields and re-sort by transfer_date desc (most recent first).
  return groups.map(function(g) { const c = Object.assign({}, g); delete c._keys; return c; })
    .sort(function(a, b) {
      const ta = _ts(a.transfer_date) || 0;
      const tb = _ts(b.transfer_date) || 0;
      return tb - ta;
    });
}

/**
 * One-click resolver for Data Gap chips on the Ownership tab.
 * Routes the chip's action to the appropriate input or workflow.
 */
function _udResolveGap(action) {
  if (!action) return;
  if (action.indexOf('focus:') === 0) {
    const id = action.slice('focus:'.length);
    const el = document.getElementById(id);
    if (el) {
      // Make sure the Resolve Ownership form is on screen
      const sec = el.closest('.detail-section');
      if (sec) sec.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setTimeout(function() { try { el.focus(); el.select && el.select(); } catch (e) {} }, 280);
    } else {
      showToast('Open the Resolve Ownership section to fill this in', 'info');
    }
    return;
  }
  if (action === 'sf-lookup') {
    // Try to resolve the owner → sf_account_id via the shared helper first.
    // If we find a match, open that account directly. Otherwise fall back to
    // the SF global search.
    const own = _udCache && _udCache.ownership;
    // Prefer canonical names so SF search hits the parent entity, not a casing variant.
    const name = (own && (own.true_owner_canonical || own.true_owner || own.recorded_owner_canonical || own.recorded_owner)) || '';
    if (!name) { showToast('Enter the owner name first', 'info'); return; }
    (async function () {
      try {
        const ctx = _ownerCtxFromCurrent(own, _udCache.db, 'true') || _ownerCtxFromCurrent(own, _udCache.db, 'recorded');
        const resolved = ctx ? await _resolveSfAccountId(ctx) : null;
        if (resolved && resolved.sf_account_id) {
          const url = _SF_BASE + '/lightning/r/Account/' + resolved.sf_account_id + '/view';
          window.open(url, '_blank', 'noopener');
          showToast('Linked to SF Account: ' + (resolved.company_name || name), 'success');
        } else {
          const url = _SF_BASE + '/lightning/o/Account/list?filterName=Recent&searchKey=' + encodeURIComponent(name);
          window.open(url, '_blank', 'noopener');
          showToast('No SF match yet — searching Salesforce for "' + name + '"', 'info');
        }
      } catch (e) {
        console.warn('sf-lookup failed', e);
        const url = _SF_BASE + '/lightning/o/Account/list?filterName=Recent&searchKey=' + encodeURIComponent(name);
        window.open(url, '_blank', 'noopener');
      }
    })();
    return;
  }
  if (action === 'add-contact') {
    // Route straight to the OwnerDrawer's Add Contact flow scoped to the
    // current owner so contact name/email/phone gaps can be resolved inline.
    _udFeedAddContact();
    return;
  }
  if (action === 'create-sf-account') {
    _udFeedCreateSfAccount();
    return;
  }
  if (action === 'research-history') {
    // Jump the user to the Research Quick Links section if present
    const ql = document.querySelector('.ql-grid');
    if (ql) {
      ql.scrollIntoView({ behavior: 'smooth', block: 'start' });
      showToast('Use Research Quick Links to fetch ownership history (CoStar, Reonomy, county recorder)', 'info');
    } else {
      showToast('No research links available for this property', 'info');
    }
    return;
  }
  console.warn('_udResolveGap: unknown action', action);
}

window._udResolveGap = _udResolveGap;

// ── Reusable action-oriented empty state (UX move #4, 2026-05-31) ──────────
// Replaces the flat '.detail-empty' gray text for high-traffic gaps. Turns
// 'nothing here' into 'here is the one thing to do.' actions = array of
// { label, onclick, primary } objects; onclick is a JS expression string.
function _udEmptyState(headline, sub, actions) {
  actions = Array.isArray(actions) ? actions : [];
  let h = '<div class="ud-empty">';
  h += '<div class="ud-empty-headline">' + esc(headline || '') + '</div>';
  if (sub) h += '<div class="ud-empty-sub">' + esc(sub) + '</div>';
  if (actions.length) {
    h += '<div class="ud-empty-actions">';
    actions.forEach(function (a) {
      const cls = a.primary ? 'ud-empty-btn ud-empty-btn-primary' : 'ud-empty-btn';
      h += '<button type="button" class="' + cls + '" onclick="' + (a.onclick || '') + '">' + esc(a.label || '') + '</button>';
    });
    h += '</div>';
  }
  h += '</div>';
  return h;
}
window._udEmptyState = _udEmptyState;

/** Sync & Begin Prospecting: search SF for this owner, set prospecting_status, open owner drawer. */
async function _udOwnerBeginProspecting(trueOwnerId, ownerName) {
  if (!trueOwnerId) { showToast('No true owner linked — resolve ownership first', 'info'); return; }
  const db = _udCache?.db || 'dia';
  const qFn = db === 'gov' ? govQuery : diaQuery;
  showToast('Searching Salesforce for "' + ownerName + '"...', 'info');
  try {
    // 1. Try to cross-reference with Salesforce via unified_contacts
    const ctx = { true_owner_id: trueOwnerId, name: ownerName, db };
    const resolved = await _resolveSfAccountId(ctx).catch(() => null);
    if (resolved && resolved.sf_account_id) {
      // Link the SF account to the true_owner record
      await qFn('true_owners', null, {
        method: 'PATCH',
        filter: 'true_owner_id=eq.' + trueOwnerId,
        body: { salesforce_id: resolved.sf_account_id, prospecting_status: 'active' }
      }).catch(e => console.warn('PATCH true_owners failed', e));
      showToast('Linked to SF Account: ' + (resolved.company_name || ownerName) + ' — prospecting started', 'success');
    } else {
      // No SF match — set prospecting status anyway and prompt user
      await qFn('true_owners', null, {
        method: 'PATCH',
        filter: 'true_owner_id=eq.' + trueOwnerId,
        body: { prospecting_status: 'active' }
      }).catch(e => console.warn('PATCH true_owners failed', e));
      showToast('No SF match found for "' + ownerName + '" — marked as actively prospecting. Create SF Account when ready.', 'info');
    }
    // 2. Refresh the Ownership tab to show updated status
    const bodyEl = document.getElementById('detailBody');
    // Re-fetch chain data to pick up the updated prospecting_status.
    // QA-08 (2026-05-18): gov v_ownership_chain has no property_id column
    // (its keys are ownership_id / lease_number / address). Using
    // property_id=eq.X on gov returned 400 (column does not exist) and
    // silently emptied _udCache.chain on every Begin Prospecting click.
    // Mirror the dispatch at line ~222 — gov→lease_number, dia→property_id.
    const propId   = _udCache?.ids?.property_id   || _udCache?.property?.property_id;
    const leaseNum = _udCache?.ids?.lease_number  || _udCache?.property?.lease_number;
    const chainFilter = (db === 'gov' && leaseNum)
      ? 'lease_number=eq.' + encodeURIComponent(leaseNum)
      : (propId ? 'property_id=eq.' + propId : null);
    if (chainFilter) {
      const chainRes = await qFn('v_ownership_chain', '*', { filter: chainFilter, order: 'transfer_date.desc', limit: 50 }).catch(() => []);
      _udCache.chain = Array.isArray(chainRes) ? chainRes : (chainRes?.data || []);
    }
    if (bodyEl) bodyEl.innerHTML = _udTabOwnership();
  } catch (e) {
    console.warn('Begin Prospecting failed:', e);
    showToast('Error: ' + (e.message || 'unknown'), 'error');
  }
}
window._udOwnerBeginProspecting = _udOwnerBeginProspecting;

/**
 * Dedup ownership_history rows for the chain timeline.
 * Merges entries that point at the same owner_entity (recorded_owner_id,
 * true_owner_id, or normalized recorded_owner_name) so that the same shell
 * LLC doesn't appear as both the current owner AND a historical owner.
 * Earliest transfer_date wins; latest ownership_end wins; counts how many
 * source rows were merged so the UI can surface it.
 */
// ============================================================================
// Property Intelligence Phase 4 + 8 — read-only UI (PR1, 2026-05-30)
// Ownership de-anonymization ladder + ranked prospecting feed.
// Reads only; the Create-lead / Add-to-cadence actions call operations.js
// sub-routes (create_lead / initiate_cadence) that ship in PR2 — until then
// they surface a toast. See audit/data-flow-2026-05-30/ drafts + apply guide.
// ============================================================================

async function _udEnrichOwnershipSignals() {
  if (!_udCache || !_udCache.ownership) return;
  const own = _udCache.ownership;
  const db = _udCache.db;
  const qFn = db === 'gov' ? govQuery : diaQuery;
  if (own.true_owner_id && _udCache.ownerConf === undefined) {
    try {
      const res = await qFn('true_owners', 'true_owner_id,owner_role,owner_role_confidence,owner_role_source', {
        filter: 'true_owner_id=eq.' + encodeURIComponent(own.true_owner_id), limit: 1,
      });
      const row = Array.isArray(res) ? res[0] : (res && res.data ? res.data[0] : null);
      if (row) {
        const num = row.owner_role_confidence == null ? null : Number(row.owner_role_confidence);
        _udCache.ownerConf = { value: (num != null && !isNaN(num)) ? num : null, role: row.owner_role || null, source: row.owner_role_source || null };
      } else { _udCache.ownerConf = null; }
    } catch (_e) { _udCache.ownerConf = null; }
  }
  if (_udCache.ownerDivergence === undefined) {
    if (db === 'gov') {
      const pid = (_udCache.ids && _udCache.ids.property_id) || own.property_id;
      if (pid != null) {
        try {
          const res = await qFn('v_recorded_vs_assessor_owner_divergence',
            'property_id,recorded_owner_name,assessor_owner_name', {
              filter: 'property_id=eq.' + encodeURIComponent(pid), limit: 1 });
          const row = Array.isArray(res) ? res[0] : (res && res.data ? res.data[0] : null);
          _udCache.ownerDivergence = row
            ? { kind: 'assessor', a: row.recorded_owner_name, b: row.assessor_owner_name } : null;
        } catch (_e) { _udCache.ownerDivergence = null; }
      } else { _udCache.ownerDivergence = null; }
    } else {
      const rec = own.recorded_owner_canonical || own.recorded_owner;
      const tru = own.true_owner_canonical || own.true_owner;
      _udCache.ownerDivergence = (rec && tru && rec !== tru && !own.true_owner_is_operator)
        ? { kind: 'true', a: rec, b: tru } : null;
    }
  }
  // Owner-contact link status (FL SOS engine). gov-side; keyed on recorded_owner_id.
  if (db === 'gov' && own.recorded_owner_id && _udCache.ownerLink === undefined) {
    try {
      const res = await qFn('v_recorded_owner_link_status',
        'recorded_owner_id,link_count,linked_count,pending_count,first_linked_sf_account_id', {
          filter: 'recorded_owner_id=eq.' + encodeURIComponent(own.recorded_owner_id), limit: 1 });
      const row = Array.isArray(res) ? res[0] : (res && res.data ? res.data[0] : null);
      _udCache.ownerLink = row
        ? { linked: Number(row.linked_count) || 0, pending: Number(row.pending_count) || 0, sf: row.first_linked_sf_account_id || null }
        : null;
    } catch (_e) { _udCache.ownerLink = null; }
  }
  if (typeof _setUdCache === 'function') _setUdCache(_udCache);
}

function _udOwnershipLadder(own, db) {
  const recDisplay = own.recorded_owner_canonical || own.recorded_owner || '';
  const trueDisplay = own.true_owner_canonical || own.true_owner || '';
  const trueIsOperator = !!own.true_owner_is_operator;
  const trueResolved = trueDisplay && !trueIsOperator;
  const conf = _udCache.ownerConf || null;
  const divergence = _udCache.ownerDivergence || null;
  const _sfAccId = own.sf_account_id || own.sf_company_id;
  let h = '';
  h += '<div style="display:grid;grid-template-columns:1fr 26px 1fr;gap:0;align-items:stretch;margin-bottom:12px">';
  // Recorded owner
  h += '<div style="background:var(--s2);border:1px solid var(--border);border-radius:10px;padding:14px 16px">';
  h += '<div style="font-size:10px;text-transform:uppercase;letter-spacing:0.5px;color:var(--text3);margin-bottom:6px">Recorded Owner (deed)</div>';
  if (recDisplay) {
    h += '<div style="font-size:15px;font-weight:700;color:var(--text);margin-bottom:4px">' + _ownerLink(recDisplay, _ownerCtxFromCurrent(own, db, 'recorded')) + '</div>';
    if (own.recorded_owner_type || own.owner_type) h += '<div style="font-size:11px;color:var(--text2)">' + esc(own.recorded_owner_type || own.owner_type) + '</div>';
    const llcBits = [];
    if (own.manager_name) llcBits.push('Mgr: ' + esc(own.manager_name));
    if (own.registered_agent_name) llcBits.push('Agent: ' + esc(own.registered_agent_name));
    const filingState = own.state_of_incorporation || own.filing_state || own.recorded_owner_state;
    if (filingState) llcBits.push('Filed: ' + esc(filingState));
    if (llcBits.length) h += '<div style="font-size:11px;color:var(--text3);margin-top:4px">' + llcBits.join(' · ') + '</div>';
    if (_sfAccId) h += '<a href="' + _SF_BASE + '/Account/' + esc(_sfAccId) + '/view" target="_blank" rel="noopener" style="font-size:11px;color:#00a1e0;display:inline-block;margin-top:6px">View in Salesforce →</a>';
    // BD-flow signal (2026-05-31): surface the SOS owner-contact link status
    // at the point of decision so the user knows if this owner is CRM-linked
    // or has links waiting in the Review Console — the connective tissue
    // between enrichment and BD action.
    const _lk = _udCache.ownerLink;
    if (_lk && _lk.linked > 0) {
      h += '<div style="margin-top:6px;font-size:11px;font-weight:600;color:var(--green)">\u2713 Linked to CRM contact' + (_lk.linked > 1 ? ' (' + _lk.linked + ')' : '')
        + (_lk.sf ? ' <a href="' + _SF_BASE + '/Account/' + esc(_lk.sf) + '/view" target="_blank" rel="noopener" style="color:#00a1e0;font-weight:600">view \u2192</a>' : '') + '</div>';
    } else if (_lk && _lk.pending > 0) {
      h += '<div style="margin-top:6px;font-size:11px;font-weight:600;color:var(--yellow);cursor:pointer" onclick="navTo(\'pageReviewConsole\');setTimeout(renderSosLinkWorklist,400)" title="Confirm in Review Console">\u29D6 ' + _lk.pending + ' contact link' + (_lk.pending > 1 ? 's' : '') + ' pending review \u2192</div>';
    }
  } else {
    h += '<div style="font-size:15px;font-weight:700;color:var(--red);margin-bottom:4px">— not on file —</div>';
    h += '<div class="t-meta3">No recorded owner. Pull from county deed / CoStar / RCA.</div>';
  }
  h += '</div>';
  h += '<div style="display:flex;align-items:center;justify-content:center;color:var(--purple);font-size:18px">→</div>';
  // True owner
  const trueStepBg = trueResolved
    ? 'linear-gradient(135deg,rgba(165,94,234,0.08),rgba(165,94,234,0.04));border:1px solid rgba(165,94,234,0.3)'
    : 'var(--s2);border:1px solid var(--border)';
  h += '<div style="background:' + trueStepBg + ';border-radius:10px;padding:14px 16px">';
  h += '<div style="font-size:10px;text-transform:uppercase;letter-spacing:0.5px;color:var(--purple);margin-bottom:6px">True Owner / Decision Maker</div>';
  if (trueResolved) {
    h += '<div style="font-size:15px;font-weight:700;color:var(--text);margin-bottom:4px">' + _ownerLink(trueDisplay, _ownerCtxFromCurrent(own, db, 'true')) + '</div>';
    if (own.true_owner_type) h += '<div style="font-size:11px;color:var(--text2)">' + esc(own.true_owner_type) + '</div>';
    if (conf && conf.value != null) {
      const pct = Math.round(conf.value * 100);
      const band = conf.value >= 0.8 ? 'var(--green)' : conf.value >= 0.5 ? 'var(--yellow)' : 'var(--red)';
      h += '<div style="display:flex;align-items:center;gap:6px;margin-top:6px;font-size:11px;font-weight:600;color:var(--text2)">Confidence'
         + '<span style="display:inline-block;width:54px;height:6px;border-radius:3px;background:var(--s3);overflow:hidden">'
         + '<span style="display:block;height:100%;width:' + pct + '%;background:' + band + '"></span></span>'
         + '<span style="color:' + band + '">' + pct + '%</span>'
         + (conf.role ? '<span style="color:var(--text3);font-weight:400">· ' + esc(conf.role) + '</span>' : '') + '</div>';
    } else {
      h += '<div style="margin-top:6px;font-size:11px;color:var(--text3)">Confidence: unscored</div>';
    }
    if (own.true_owner_sec_cik) h += '<a href="https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=' + esc(own.true_owner_sec_cik) + '" target="_blank" rel="noopener" style="font-size:11px;color:#62B5E5;display:inline-block;margin-top:6px">SEC filings →</a>';
  } else if (trueIsOperator) {
    h += '<div style="font-size:15px;font-weight:700;color:var(--text);margin-bottom:4px">' + esc(trueDisplay) + '</div>';
    h += '<div style="font-size:11px;color:var(--yellow)">Operator-owner — verify this is the real-estate owner, not the chain operator.</div>';
  } else {
    h += '<div style="font-size:15px;font-weight:700;color:var(--red);margin-bottom:4px">— unresolved —</div>';
    h += '<div class="t-meta3">Beneficial owner not yet identified. Queue LLC / SoS research.</div>';
  }
  h += '</div>';
  h += '</div>';
  if (divergence) {
    const label = divergence.kind === 'assessor' ? 'Assessor disagrees' : 'Recorded vs true differ';
    h += '<div style="display:flex;align-items:center;gap:10px;background:rgba(251,191,36,0.10);border:1px solid rgba(251,191,36,0.30);border-radius:8px;padding:9px 12px;margin:0 0 12px;font-size:12px">';
    h += '<span style="font-weight:700;color:var(--yellow)">⚠ ' + esc(label) + '</span>';
    h += '<span class="t-muted2">' + esc(divergence.a || '—') + '  vs  <b>' + esc(divergence.b || '—') + '</b></span>';
    h += '</div>';
  }
  h += '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:4px">';
  if (trueResolved) {
    h += '<button onclick="_udBtnGuard(this,_udCreateLeadFromProperty)" style="padding:8px 13px;background:var(--accent);color:#fff;border:none;border-radius:7px;font-weight:600;font-size:12.5px;cursor:pointer">Create lead</button>';
    h += '<button onclick="_udBtnGuard(this,_udAddToCadence)" style="padding:8px 13px;background:var(--s2);border:1px solid var(--border);color:var(--text);border-radius:7px;font-weight:600;font-size:12.5px;cursor:pointer">Add to cadence</button>';
  } else {
    h += '<button onclick="_udResolveGap(\'focus:udOwnTrue\')" style="padding:8px 13px;background:var(--accent);color:#fff;border:none;border-radius:7px;font-weight:600;font-size:12.5px;cursor:pointer">Resolve owner</button>';
    h += '<button onclick="_udResolveGap(\'focus:udOwnRecorded\')" style="padding:8px 13px;background:var(--s2);border:1px solid var(--border);color:var(--text);border-radius:7px;font-weight:600;font-size:12.5px;cursor:pointer">Pull recorded owner</button>';
  }
  h += '</div>';
  return h;
}

function _udBandClass(band) {
  const b = String(band || '').toUpperCase();
  if (b === 'P0') return { bg: '#7A1020', label: 'P0' };
  if (b === 'P0.5') return { bg: 'var(--red)', label: 'P0.5' };
  if (b === 'P1') return { bg: 'var(--yellow)', label: 'P1' };
  if (b === 'P2' || b === 'P3') return { bg: 'var(--purple)', label: b };
  return { bg: 'var(--text3)', label: b || '—' };
}
function _udResearchCta(researchType) {
  const t = String(researchType || '');
  if (t.indexOf('missing_recorded_owner') !== -1) return { label: 'Pull recorded owner →', tab: 'Ownership & CRM' };
  if (t.indexOf('llc') !== -1 || t.indexOf('true_owner') !== -1) return { label: 'Resolve true owner →', tab: 'Ownership & CRM' };
  if (t.indexOf('lease') !== -1) return { label: 'Confirm lease →', tab: 'Rent Roll' };
  if (t.indexOf('sale') !== -1) return { label: 'Review sale →', tab: 'Deal History' };
  return { label: 'Take action →', tab: 'Ownership & CRM' };
}
function _udResearchTitle(r) {
  const t = String(r.research_type || '');
  if (t.indexOf('missing_recorded_owner') !== -1) return 'Pull recorded owner';
  if (t.indexOf('llc') !== -1) return 'Resolve LLC / true owner';
  if (t.indexOf('true_owner') !== -1) return 'Resolve true owner';
  if (t.indexOf('lease') !== -1) return 'Confirm lease / expiration';
  if (t.indexOf('sale') !== -1) return 'Review sale record';
  return t.replace(/_/g, ' ').replace(/\b\w/g, function (c) { return c.toUpperCase(); }) || 'Research action';
}

async function _udFetchProspectingFeed(limit) {
  limit = limit || 6;
  if (!_udCache) return [];
  const db = _udCache.db;
  const qFn = db === 'gov' ? govQuery : diaQuery;
  const pid = (_udCache.ids && _udCache.ids.property_id) || (_udCache.property && _udCache.property.property_id);
  if (pid == null) { _udCache.researchFeed = []; return []; }
  try {
    const res = await qFn('v_next_best_research', 'research_type,entity_kind,entity_id,label,priority,instructions,domain', {
      filter: 'entity_kind=eq.property&entity_id=eq.' + encodeURIComponent(String(pid)),
      order: 'priority.desc.nullslast', limit: limit });
    const rows = Array.isArray(res) ? res : (res && res.data ? res.data : []);
    _udCache.researchFeed = rows || [];
  } catch (_e) { _udCache.researchFeed = []; }
  // R26 Unit 2: for a gov property with a recorded-owner research gap, resolve
  // the county recorder portal (county comes from the R26 Unit 1 backfill) so
  // the feed can render a one-click "Look up owner →" link. Best-effort; a
  // missing county / authority simply yields no link.
  try {
    const feedRows = _udCache.researchFeed || [];
    const hasRecordedOwnerGap = feedRows.some(function (r) {
      return String(r.research_type || '').indexOf('missing_recorded_owner') !== -1;
    });
    if (db === 'gov' && hasRecordedOwnerGap && _udCache.recorderPortal === undefined) {
      const doFetch = (window.LCC_AUTH && window.LCC_AUTH.apiFetch) ? window.LCC_AUTH.apiFetch : fetch;
      const pr = await doFetch('/api/admin?_route=recorder-portal&domain=gov&property_id=' + encodeURIComponent(pid));
      if (pr && pr.ok) {
        const pd = await pr.json();
        _udCache.recorderPortal = (pd && pd.portal_url) ? pd : null;
      } else { _udCache.recorderPortal = null; }
    }
  } catch (_e) { _udCache.recorderPortal = null; }
  if (typeof _setUdCache === 'function') _setUdCache(_udCache);
  return _udCache.researchFeed;
}

async function _udFetchPriorityBand() {
  if (!_udCache) return null;
  if (_udCache.priorityBand !== undefined) return _udCache.priorityBand;
  const db = _udCache.db;
  const pid = (_udCache.ids && _udCache.ids.property_id) || (_udCache.property && _udCache.property.property_id);
  if (pid == null) { _udCache.priorityBand = null; return null; }
  try {
    const doFetch = (window.LCC_AUTH && window.LCC_AUTH.apiFetch) ? window.LCC_AUTH.apiFetch : fetch;
    const res = await doFetch('/api/priority-band?domain=' + encodeURIComponent(db) + '&property_id=' + encodeURIComponent(pid));
    if (res && res.ok) {
      const data = await res.json();
      _udCache.priorityBand = (data && data.priority_band) ? data : null;
      // The priority-band endpoint also resolves the owner's open BD opportunity
      // + cadence (keyed on the queue's entity_id). Trust it only when the
      // backend actually resolved an owner entity (data.entity_id present) — a
      // property with no queue row carries no entity, so the asset-entity
      // fallback below must run instead. (Bug c, 2026-06-03)
      if (data && data.entity_id && data.open_opportunity != null) {
        _udCache.ownerOpp = { open: !!data.open_opportunity, cadence_next_touch_due: data.cadence_next_touch_due || null };
      }
    } else { _udCache.priorityBand = null; }
  } catch (_e) { _udCache.priorityBand = null; }
  // Fallback: if the property's owner has dropped out of the priority queue
  // (e.g. led but no longer due) the by-property band carries no opportunity
  // signal. Resolve it directly from the asset entity id captured at load.
  if (_udCache.ownerOpp === undefined) {
    const own = _udCache.ownership || {};
    const eid = own.owner_entity_id || null;
    if (eid) {
      try {
        const doFetch2 = (window.LCC_AUTH && window.LCC_AUTH.apiFetch) ? window.LCC_AUTH.apiFetch : fetch;
        const r2 = await doFetch2('/api/priority-band?entity_id=' + encodeURIComponent(eid));
        if (r2 && r2.ok) {
          const d2 = await r2.json();
          if (d2 && d2.open_opportunity != null) {
            _udCache.ownerOpp = { open: !!d2.open_opportunity, cadence_next_touch_due: d2.cadence_next_touch_due || null };
          } else { _udCache.ownerOpp = null; }
        } else { _udCache.ownerOpp = null; }
      } catch (_e) { _udCache.ownerOpp = null; }
    } else { _udCache.ownerOpp = null; }
  }
  if (typeof _setUdCache === 'function') _setUdCache(_udCache);
  return _udCache.priorityBand;
}

// Per-property 'Next step' banner (self-propelling contract, Move 2, 2026-06-03).
// Surfaces the SINGLE next action for THIS property at the top of the detail,
// with a 4-node progress trail (Owner -> Link -> Lead -> Cadence). Computed from
// the spine state already in _udCache; advances live as the user acts.
function _udRenderNextStep() {
  const bar = document.getElementById('detailNextStep');
  if (!bar) return;
  if (!_udCache) { bar.style.display = 'none'; bar.innerHTML = ''; return; }
  const own = _udCache.ownership || {};
  const pid = (_udCache.ids && _udCache.ids.property_id) || own.property_id || null;
  const lk = _udCache.ownerLink || null;
  const band = _udCache.priorityBand || null;
  const recordedOwner = own.recorded_owner_canonical || own.recorded_owner || own.recorded_owner_id || null;
  const trueResolved = own.true_owner_id || own.true_owner_canonical || own.true_owner || own.owner_entity_id || null;
  const linkPending = !!(lk && lk.pending > 0 && !(lk.linked > 0));
  const linked = !!(lk && lk.linked > 0);
  // Persisted lead/cadence truth for this owner entity (Bug c, 2026-06-03):
  // an open BD opportunity / cadence resolved from LCC on load. This survives
  // reopens — the priority band alone went stale (P0.5 "needs a lead") once the
  // lead was created, and the domain ownership row never carried owner_entity_id,
  // so the banner kept re-offering "Create the lead" on already-led properties.
  const oo = _udCache.ownerOpp || null;
  const hasOpenOpp = !!(oo && oo.open);
  // Authoritative negative (E2E#6 follow-up, 2026-06-03): the priority-band check
  // resolved an owner entity but found NO open opportunity (open === false). That
  // means there genuinely is no lead yet, so re-offer "Create the lead" even
  // though owner_entity_id is now populated from lookup_asset on load — otherwise
  // the banner wrongly shows "Lead is live / Add to cadence".
  const leadResolvedAbsent = !!(oo && oo.open === false);
  const needsLead = !hasOpenOpp
    && (leadResolvedAbsent
        || !!(band && band.reason === 'open_bd_opportunity_needed')
        || !own.owner_entity_id);
  // Is the owner already on a cadence? Either the persisted check found one, we
  // just seeded one via create_lead (stashed in _udCache.cadence), or the
  // priority band is one of the cadence-driven bands (P0 developer-overdue, P6
  // onboarding-step-due, P7 steady-state) which only exist when a cadence is due.
  const cad = _udCache.cadence || null;
  const bandIsCadence = !!(band && ['P0', 'P6', 'P7'].indexOf(band.priority_band) !== -1);
  const onCadence = !!(oo && oo.cadence_next_touch_due) || !!(cad && cad.seeded) || bandIsCadence;
  const cadenceNextTouch = (oo && oo.cadence_next_touch_due) || (cad && cad.next_touch_due) || (band && band.next_touch_due) || null;
  // R59 Unit 1 — signal continuity: if an open BD signal routed the operator
  // here (or one is open on direct nav), render its banner above the spine and
  // make the NEXT STEP the signal's action. suspected_sale + owner_source_conflict
  // OVERRIDE the spine step; loan_maturity reframes it once the owner is resolved.
  const _sigUI = (function () {
    try { return _udBdSignalUI({ recordedOwner: recordedOwner, onCadence: onCadence, needsLead: needsLead }); }
    catch (_e) { return { banner: '', step: null }; }
  })();
  // First unmet step in the spine = the single next action.
  let step;
  if (_sigUI.step) {
    step = _sigUI.step;
  } else if (!recordedOwner) {
    step = { label: 'Pull the recorded owner', sub: 'No deed owner on file yet.', cta: 'Resolve owner',
      onclick: pid ? '_udBtnGuard(this,function(){_udResolveOwner(' + pid + ')})' : null };
  } else if (linkPending) {
    step = { label: 'Confirm the owner\u2192contact link', sub: 'A CRM match is waiting for review.', cta: 'Review link \u2192',
      onclick: 'navTo(&quot;pageReviewConsole&quot;);setTimeout(renderSosLinkWorklist,400)' };
  } else if (!trueResolved) {
    step = { label: 'Resolve the true owner', sub: 'Recorded owner known; decision-maker not resolved.', cta: 'Open Ownership \u2192',
      onclick: 'switchUnifiedTab(&quot;Ownership &amp; CRM&quot;)' };
  } else if (band && (band.priority_band === 'P0.4' || band.reason === 'resolve_ownership_control') && band.resolve_is_connected === false) {
    // R6: the owner is resolved but the control structure isn't CONNECTED yet
    // (no Salesforce account / contact). Doctrine: connect first \u2014 the lead is
    // not the next action. Kept consistent with the queue's P0.4 verdict.
    step = { label: 'Resolve ownership & control',
      sub: band.resolve_true_owner_name
        ? ('True owner: ' + band.resolve_true_owner_name + ' \u2014 link a Salesforce account / contact before opening a lead.')
        : 'Identify the true owner/parent and link a CRM account / contact before opening a lead.',
      cta: 'Open Ownership \u2192', onclick: 'switchUnifiedTab(&quot;Ownership &amp; CRM&quot;)' };
  } else if (needsLead) {
    step = { label: 'Create the lead', sub: 'Owner resolved' + (linked ? ' & CRM-linked' : '') + '. Open a BD opportunity.', cta: 'Create lead',
      onclick: '_udBtnGuard(this,_udCreateLeadFromProperty)' };
  } else if (onCadence) {
    // Terminal state: cadence already seeded (auto-seeded on BD-opp creation).
    // No redundant action — just show the next touch.
    step = { label: 'On cadence ✓', sub: cadenceNextTouch ? ('Next touch ' + _fmtDate(cadenceNextTouch)) : 'Owner is on a touch cadence.',
      cta: null, onclick: null };
  } else {
    // Recovery path: lead exists but no cadence yet (entity without one).
    step = { label: 'Advance the outreach', sub: 'Lead is live. Put this owner on a touch cadence.', cta: 'Add to cadence',
      onclick: '_udBtnGuard(this,_udAddToCadence)' };
  }
  // Progress trail node states (honest: unknown stays 'todo', not 'done').
  const stOwner = trueResolved ? 'done' : (recordedOwner ? 'next' : 'todo');
  const stLink = linked ? 'done' : (linkPending ? 'next' : (lk ? 'todo' : 'na'));
  const stLead = (hasOpenOpp || (own.owner_entity_id && !needsLead)) ? 'done' : 'todo';
  const trail = [['Owner', stOwner], ['Link', stLink], ['Lead', stLead], ['Cadence', onCadence ? 'done' : 'todo']];
  let h = _sigUI.banner || '';
  h += '<div class="dns-row">';
  h += '<span class="dns-flag">\u25B6 Next step</span>';
  h += '<div class="dns-text"><div class="dns-label">' + esc(step.label) + '</div><div class="dns-sub">' + esc(step.sub) + '</div></div>';
  if (step.onclick) h += '<button type="button" class="dns-cta" onclick="event.stopPropagation();' + step.onclick + '">' + esc(step.cta) + '</button>';
  h += '</div>';
  const nodes = trail.filter(function (t) { return t[1] !== 'na'; }).map(function (t) {
    return '<span class="dns-node dns-' + t[1] + '">' + (t[1] === 'done' ? '\u2713 ' : '') + esc(t[0]) + '</span>';
  });
  h += '<div class="dns-trail">' + nodes.join('<span class="dns-sep">\u203A</span>') + '</div>';
  bar.innerHTML = h;
  bar.style.display = '';
}
window._udRenderNextStep = _udRenderNextStep;

function _udRenderProspectingFeed() {
  const bar = document.getElementById('detailNextActionBar');
  if (!bar) return;
  const band = _udCache && _udCache.priorityBand;
  const feed = (_udCache && _udCache.researchFeed) || [];
  const legacy = _udCache && _udCache.nextAction;
  if (!band && feed.length === 0 && (!legacy || !legacy.gap_type)) { bar.style.display = 'none'; bar.innerHTML = ''; return; }
  const rows = [];
  rows.push('<div class="prospect-feed-header"><span class="nab-label">What to do about this property</span>'
    + (band && band.is_cross_vertical ? '<span class="nab-xv-chip" title="Owner holds assets in both verticals">cross-vertical</span>' : '') + '</div>');
  if (band && band.priority_band) {
    const bc = _udBandClass(band.priority_band);
    const conf = band.owner_role_confidence != null ? Number(band.owner_role_confidence) : null;
    const why = esc(band.reason || 'BD priority') + (band.total_property_count ? ' · ' + esc(String(band.total_property_count)) + ' properties' : '');
    rows.push('<div class="prospect-row">');
    rows.push('<span class="prospect-band" style="background:' + bc.bg + '">' + esc(bc.label) + '</span>');
    rows.push('<div class="prospect-why"><b>Owner: ' + esc(band.owner_name || (_udCache.ownership && (_udCache.ownership.true_owner || _udCache.ownership.recorded_owner)) || '—') + '</b>'
      + '<div class="prospect-sub">' + why + (conf != null && !isNaN(conf) ? ' · role conf ' + Math.round(conf * 100) + '%' : '') + '</div></div>');
    var _ol = _udCache && _udCache.ownerLink;
    var _linkPending = _ol && (_ol.pending > 0) && !(_ol.linked > 0);
    var _leadBtn = _linkPending
      ? '<button type="button" class="prospect-cta" title="Confirm the owner\u2192contact link before creating a lead" onclick="event.stopPropagation();navTo(&quot;pageReviewConsole&quot;);setTimeout(renderSosLinkWorklist,400)">Confirm owner link first \u2192</button>'
      : '<button type="button" class="prospect-cta-primary" onclick="event.stopPropagation();_udBtnGuard(this,_udCreateLeadFromProperty)">Create lead</button>';
    rows.push('<div class="prospect-actions">' + _leadBtn
      + '<button type="button" class="prospect-cta" onclick="event.stopPropagation();_udBtnGuard(this,_udAddToCadence)">Add to cadence</button></div>');
    rows.push('</div>');
  }
  const portal = _udCache && _udCache.recorderPortal;
  feed.forEach(function (r) {
    const cta = _udResearchCta(r.research_type);
    rows.push('<div class="prospect-row">');
    rows.push('<span class="prospect-rank" title="priority score">' + esc(String(r.priority != null ? r.priority : '—')) + '</span>');
    rows.push('<div class="prospect-why"><b>' + esc(_udResearchTitle(r)) + '</b><div class="prospect-sub">' + esc(r.instructions || r.label || '') + '</div></div>');
    // R26 Unit 2: one-click county-recorder lookup on recorded-owner gaps.
    const isRecordedOwner = String(r.research_type || '').indexOf('missing_recorded_owner') !== -1;
    let portalLink = '';
    if (isRecordedOwner && portal && portal.portal_url) {
      portalLink = '<a class="prospect-cta" href="' + esc(portal.portal_url) + '" target="_blank" rel="noopener noreferrer" onclick="event.stopPropagation()" title="Open the county portal to research the recorded owner">Look up owner → ' + esc(portal.portal_label || 'county recorder') + '</a>';
    }
    rows.push('<div class="prospect-actions">' + portalLink + '<button type="button" class="prospect-cta" onclick="event.stopPropagation();switchUnifiedTab(&quot;' + esc(cta.tab) + '&quot;)">' + esc(cta.label) + '</button></div>');
    rows.push('</div>');
  });
  if (feed.length === 0 && legacy && legacy.gap_type) {
    const dispatch = (typeof _udNextActionDispatchFor === 'function') ? _udNextActionDispatchFor(legacy.gap_type) : { label: 'Take action →' };
    const valStr = (typeof _udFormatNabValue === 'function') ? _udFormatNabValue(legacy.gap_value) : '';
    rows.push('<div class="prospect-row">');
    rows.push('<span class="prospect-rank">' + esc(String(legacy.gap_severity || '').toUpperCase()) + '</span>');
    rows.push('<div class="prospect-why"><b>' + esc(legacy.suggested_action || legacy.gap_label || 'Next action') + '</b>' + (valStr ? '<div class="prospect-sub">' + esc(valStr) + ' value</div>' : '') + '</div>');
    rows.push('<div class="prospect-actions"><button type="button" class="prospect-cta" onclick="event.stopPropagation();_udNextActionClick(&quot;' + esc(legacy.gap_type) + '&quot;)">' + esc(dispatch.label) + '</button></div>');
    rows.push('</div>');
  }
  bar.className = 'prospect-feed';
  bar.onclick = null;
  bar.innerHTML = rows.join('');
  bar.style.display = '';
}

async function _udApiPost(path, body) {
  const headers = { 'Content-Type': 'application/json' };
  if (window.LCC_USER && window.LCC_USER.workspace_id) headers['x-lcc-workspace'] = window.LCC_USER.workspace_id;
  const doFetch = (window.LCC_AUTH && window.LCC_AUTH.apiFetch) ? window.LCC_AUTH.apiFetch : fetch;
  const res = await doFetch(path, { method: 'POST', headers: headers, body: JSON.stringify(body) });
  const text = await res.text();
  let data = null; try { data = text ? JSON.parse(text) : null; } catch (_e) { data = { error: text }; }
  if (!res.ok && data && data.ok === undefined) data.ok = false;
  return data;
}

async function _udApiGet(path) {
  const headers = {};
  if (window.LCC_USER && window.LCC_USER.workspace_id) headers['x-lcc-workspace'] = window.LCC_USER.workspace_id;
  const doFetch = (window.LCC_AUTH && window.LCC_AUTH.apiFetch) ? window.LCC_AUTH.apiFetch : fetch;
  const res = await doFetch(path, { method: 'GET', headers: headers });
  const text = await res.text();
  let data = null; try { data = text ? JSON.parse(text) : null; } catch (_e) { data = { error: text }; }
  if (!res.ok && data && data.ok === undefined) data.ok = false;
  return data;
}

// R50 — load the geographic BD bundle (nearby owners / sales / competitors) for
// a property from the LCC property_geo endpoint (heavy haversine scan stays in
// the domain DB). Soft-fails to null so the detail page degrades cleanly.
async function _udLoadPropertyGeo(domain, propertyId) {
  if (!domain || !propertyId) return null;
  const d = (domain === 'gov' || domain === 'government') ? 'gov'
    : (domain === 'dia' || domain === 'dialysis') ? 'dia' : null;
  if (!d) return null;
  try {
    const data = await _udApiGet('/api/operations?action=property_geo&domain=' + d +
      '&property_id=' + encodeURIComponent(propertyId));
    if (data && data.ok) return data;
  } catch (_e) { /* soft */ }
  return null;
}

// R59 Unit 1 — load the open BD signal(s) for this property and stash the
// primary on _udCache so the NEXT STEP card can render a signal banner + make
// the step the signal's action. Works on ANY entry point (worklist route OR
// direct navigation) — the route param is only an instant hint; this fetch is
// the authoritative, POST-ready source. Soft-fails (no signal → spine as usual).
async function _udLoadBdSignals(domain, propertyId) {
  if (!_udCache || !domain || !propertyId) return;
  const d = (domain === 'gov' || domain === 'government') ? 'gov'
    : (domain === 'dia' || domain === 'dialysis') ? 'dia' : null;
  if (!d) return;
  try {
    const data = await _udApiGet('/api/operations?action=property_signals&domain=' + d +
      '&property_id=' + encodeURIComponent(propertyId));
    if (data && data.ok && data.signals && data.primary && data.signals[data.primary]) {
      _udCache.bdSignals = data.signals;
      _udCache.bdSignal = data.signals[data.primary];
    } else {
      // Authoritative "no open signal" — clear any route-param hint.
      _udCache.bdSignals = {};
      _udCache.bdSignal = null;
    }
  } catch (_e) { /* soft — keep any hint */ }
}

// Re-fetch signals + re-render the NEXT STEP after a verdict that resolves one.
async function _udRefreshBdSignals() {
  const pid = (_udCache && _udCache.ids && _udCache.ids.property_id) || null;
  const dom = _udCache && _udCache.db;
  if (dom && pid) await _udLoadBdSignals(dom, pid);
  try { _udRenderNextStep(); } catch (_e) {}
}

// R59 Unit 1 — confirm a SUSPECTED sale inline (R53 machinery). The operator
// MUST supply a price (we never fabricate); the date defaults to when the
// ownership change was seen. Posts the same federated decision-verdict the
// Decision Center "Suspected sales" lane uses.
async function _udConfirmSuspectedSale() {
  const sig = _udCache && _udCache.bdSignal;
  if (!sig || sig.type !== 'suspected_sale' || !sig.subject) return;
  const c = sig.subject.context || {};
  const ctx = (c.address ? c.address + (c.state ? ' ' + c.state : '') + ' — ' : '')
    + '"' + (c.suspected_grantor || '?') + '" → "' + (c.suspected_grantee || '?') + '"';
  const promptFn = (typeof window.lccPrompt === 'function') ? window.lccPrompt
    : (msg, def) => Promise.resolve(typeof prompt === 'function' ? prompt(msg, def) : null);
  const pv = await promptFn('Confirm this sale.\n\n' + ctx + '\n\nEnter the SALE PRICE (numbers only — we never guess):', '');
  if (pv == null) return;
  const price = Number(String(pv).replace(/[^0-9.]/g, ''));
  if (!isFinite(price) || price < 50000) { showToast('Enter a real price (≥ $50k)', 'error'); return; }
  const defDate = c.suspected_sale_date ? String(c.suspected_sale_date).slice(0, 10) : '';
  const dv = await promptFn('Sale date (YYYY-MM-DD):', defDate);
  if (dv == null) return;
  const saleDate = String(dv).trim() || defDate;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(saleDate)) { showToast('Enter a valid date (YYYY-MM-DD)', 'error'); return; }
  const resp = await _udApiPost('/api/decision-verdict', {
    type: 'suspected_sale', subject: sig.subject, verdict: 'confirm_sale',
    payload: { sold_price: price, sale_date: saleDate, buyer: c.suspected_grantee || null, seller: c.suspected_grantor || null },
  });
  if (resp && resp.ok) { showToast('Sale recorded ✓', 'success'); await _udRefreshBdSignals(); }
  else { showToast('Could not record: ' + ((resp && (resp.error || resp.message)) || 'unknown'), 'error'); }
}
window._udConfirmSuspectedSale = _udConfirmSuspectedSale;

async function _udNotASale() {
  const sig = _udCache && _udCache.bdSignal;
  if (!sig || sig.type !== 'suspected_sale' || !sig.subject) return;
  const resp = await _udApiPost('/api/decision-verdict', { type: 'suspected_sale', subject: sig.subject, verdict: 'not_a_sale' });
  if (resp && resp.ok) { showToast('Marked not a sale', 'success'); await _udRefreshBdSignals(); }
  else { showToast('Action failed', 'error'); }
}
window._udNotASale = _udNotASale;

// R59 Unit 1 — reconcile an owner-source conflict inline (R51 machinery). Deed
// grantee (legal title) wins; broker-as-owner clears the broker. keep_current
// confirms the recorded owner. Posts the federated owner_source_conflict verdict.
async function _udReconcileOwner(verdict) {
  const sig = _udCache && _udCache.bdSignal;
  if (!sig || sig.type !== 'owner_source_conflict' || !sig.subject) return;
  const resp = await _udApiPost('/api/decision-verdict', { type: 'owner_source_conflict', subject: sig.subject, verdict: verdict });
  if (resp && resp.ok) {
    showToast(verdict === 'keep_current' ? 'Kept current owner' : 'Deed owner set ✓', 'success');
    await _udRefreshBdSignals();
    // accept_deed changes the recorded owner — refresh the ownership spine too.
    if (verdict !== 'keep_current') { try { await _udFetchPriorityBand(); } catch (_e) {} try { _udRenderNextStep(); } catch (_e) {} }
  } else { showToast('Could not reconcile: ' + ((resp && (resp.error || resp.message)) || 'unknown'), 'error'); }
}
window._udReconcileOwner = _udReconcileOwner;

// R59 Unit 1 — dismiss a loan-maturity BD trigger as not relevant (R54).
async function _udLoanMaturityDismiss() {
  const sig = _udCache && _udCache.bdSignal;
  if (!sig || sig.type !== 'loan_maturity' || !sig.subject) return;
  const resp = await _udApiPost('/api/decision-verdict', { type: 'loan_maturity', subject: sig.subject, verdict: 'not_relevant' });
  if (resp && resp.ok) { showToast('Maturity dismissed', 'success'); await _udRefreshBdSignals(); }
  else { showToast('Action failed', 'error'); }
}
window._udLoanMaturityDismiss = _udLoanMaturityDismiss;

// R59 Unit 1 — build the signal banner HTML + the step override for the NEXT
// STEP card. Returns { banner, step } where step (when non-null) replaces the
// spine's computed step. Pure presentation off _udCache.bdSignal.
function _udBdSignalUI(ctxState) {
  const sig = _udCache && _udCache.bdSignal;
  if (!sig || !sig.type) return { banner: '', step: null };
  const c = (sig.subject && sig.subject.context) || sig.context || {};
  const fmtDate = (x) => { if (!x) return ''; try { return (typeof _fmtDate === 'function') ? _fmtDate(x) : String(x).slice(0, 10); } catch (_e) { return String(x).slice(0, 10); } };
  const money = (x) => (x == null || x === '') ? '' : '$' + Number(x).toLocaleString(undefined, { maximumFractionDigits: 0 });
  const wrap = (title, body, danger) => '<div class="dns-signal" style="border-left:3px solid '
    + (danger ? 'var(--danger,#c0392b)' : 'var(--gov-green,#2e7d32)')
    + ';background:var(--s2,#f4f6f8);padding:8px 12px;border-radius:6px;margin-bottom:8px">'
    + '<div style="font-size:11px;font-weight:700;letter-spacing:.04em;color:' + (danger ? 'var(--danger,#c0392b)' : 'var(--text2)') + '">' + esc(title) + '</div>'
    + '<div style="font-size:12px;color:var(--text)">' + body + '</div></div>';

  if (sig.type === 'suspected_sale') {
    const body = '<b>' + esc(c.suspected_grantor || '?') + '</b> → <b>' + esc(c.suspected_grantee || '?') + '</b>'
      + (c.suspected_sale_date ? ' (' + esc(fmtDate(c.suspected_sale_date)) + ')' : '')
      + ' · <a href="#" onclick="event.preventDefault();event.stopPropagation();_udNotASale()" style="color:var(--text3)">not a sale</a>';
    return {
      banner: wrap('⚡ Suspected sale', body, true),
      step: { label: 'Confirm the sale — record price/date', sub: 'An ownership change with no recorded sale. Confirm with the real price (we never guess).',
        cta: 'Confirm sale', onclick: '_udBtnGuard(this,_udConfirmSuspectedSale)' },
    };
  }
  if (sig.type === 'owner_source_conflict') {
    const isBroker = c.conflict_kind === 'broker_as_owner' || c.is_broker_owner === true;
    const body = 'Deed grantee <b>' + esc(c.latest_deed_grantee || '?') + '</b>'
      + ' ≠ recorded owner <b>' + esc(c.recorded_owner_name || '—') + '</b>'
      + (c.conflict_kind ? ' <span style="color:var(--text3)">(' + esc(c.conflict_kind) + ')</span>' : '')
      + ' · <a href="#" onclick="event.preventDefault();event.stopPropagation();_udReconcileOwner(\'keep_current\')" style="color:var(--text3)">keep current</a>';
    return {
      banner: wrap('⚠ Owner conflict', body, false),
      step: { label: 'Reconcile the owner', sub: isBroker ? 'The recorded owner looks like a broker. Clear it and set the deed grantee.' : 'The recorded deed grantee (legal title) should win.',
        cta: isBroker ? 'Clear broker → set deed owner' : 'Accept deed owner →',
        onclick: isBroker ? '_udBtnGuard(this,function(){_udReconcileOwner(\'broker_not_owner\')})' : '_udBtnGuard(this,function(){_udReconcileOwner(\'accept_deed\')})' },
    };
  }
  if (sig.type === 'loan_maturity') {
    const matured = (typeof c.months_to_maturity === 'number' && c.months_to_maturity < 0);
    const who = c.owner_name || c.true_owner_name || c.recorded_owner_name || '';
    const lbl = (matured ? 'Loan MATURED ' : 'Loan matures ') + esc(fmtDate(c.maturity_date))
      + (!matured && typeof c.months_to_maturity === 'number' ? ' (' + c.months_to_maturity + ' mo)' : '');
    const bal = (c.loan_balance != null) ? ' · ' + money(c.loan_balance) : '';
    const distress = c.is_distressed ? ' · ⚠ ' + esc(c.distress_reason || 'distressed') : '';
    const body = lbl + bal + distress
      + ' · <a href="#" onclick="event.preventDefault();event.stopPropagation();_udLoanMaturityDismiss()" style="color:var(--text3)">not a lead</a>';
    // Only override the step when the owner is resolved enough to act on (the
    // outreach IS the opening of the owner opportunity / cadence). Otherwise let
    // the spine run (resolve owner first) — the banner still shows the trigger.
    let step = null;
    if (ctxState && ctxState.recordedOwner) {
      step = ctxState.onCadence
        ? { label: 'Refi / disposition outreach', sub: (who ? who + ' — ' : '') + 'maturity wall — work the cadence.',
            cta: 'Work cadence →', onclick: 'navTo(&quot;pagePriorityQueue&quot;);setTimeout(renderCadenceDashboard,300)' }
        : { label: 'Refi / disposition outreach', sub: (who ? who + ' — ' : '') + 'maturity wall forces a refinance or sale. Open the owner opportunity.',
            cta: ctxState.needsLead ? 'Open opportunity' : 'Add to cadence',
            onclick: ctxState.needsLead ? '_udBtnGuard(this,_udCreateLeadFromProperty)' : '_udBtnGuard(this,_udAddToCadence)' };
    }
    return { banner: wrap((matured || c.is_distressed) ? '⚠ Loan maturity — BD trigger' : 'Loan maturity — BD trigger', body, matured || c.is_distressed), step: step };
  }
  return { banner: '', step: null };
}
window._udBdSignalUI = _udBdSignalUI;

// R50 — render the nearby-owners + nearby-sales geographic section (shared by
// the dia operations tab + the gov detail body). Competitors are rendered by
// each domain's own competitor block (dia switches county->distance). Returns
// '' when there is nothing geocoded to show.
function _udRenderGeoSection(geo, domain) {
  if (!geo) return '';
  const _money = (x) => (x == null || x === '') ? '—' : '$' + Number(x).toLocaleString(undefined, { maximumFractionDigits: 0 });
  const _cap = (x, src) => {
    if (x == null || x === '') return '—';
    const pct = (Number(x) * 100).toFixed(2) + '%';
    return src ? (pct + ' <span style="color:var(--text3);font-size:9px">' + String(src).split(':')[0] + '</span>') : pct;
  };
  const _d = (x) => (x == null) ? '—' : Number(x).toFixed(2) + ' mi';
  const _dt = (x) => { if (!x) return '—'; try { return (typeof _fmtDate === 'function') ? _fmtDate(x) : String(x).slice(0, 10); } catch (_e) { return String(x).slice(0, 10); } };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));

  const owners = Array.isArray(geo.nearby_owners) ? geo.nearby_owners : [];
  const sales = Array.isArray(geo.nearby_sales) ? geo.nearby_sales : [];

  // ── R54: loan-maturity BD signal (independent of geocoding) ──
  let matHtml = '';
  const m = geo.loan_maturity;
  if (m && m.maturity_date) {
    const matured = (typeof m.months_to_maturity === 'number' && m.months_to_maturity < 0);
    const lbl = matured ? 'Loan MATURED ' + _dt(m.maturity_date)
      : 'Loan matures ' + _dt(m.maturity_date)
        + (typeof m.months_to_maturity === 'number' ? ' (' + m.months_to_maturity + ' mo)' : '');
    const bal = (m.loan_balance != null) ? ' · ' + _money(m.loan_balance) : '';
    const distress = m.is_distressed ? ' · ⚠ ' + esc(m.distress_reason || 'distressed') : '';
    matHtml = '<div class="detail-section">' +
      '<div class="detail-section-title">Loan Maturity — BD trigger</div>' +
      '<div style="font-size:12px;font-weight:600;color:' + (matured || m.is_distressed ? 'var(--danger,#c0392b)' : 'var(--text)') + '">' +
      esc(lbl) + bal + distress + '</div>' +
      '<div style="font-size:11px;color:var(--text3);margin-top:2px">A maturity wall forces the owner to refinance or sell — work this via the Decision Center “Loan maturities” lane.</div></div>';
  }

  if (!geo.subject_geocoded) {
    return matHtml + '<div class="detail-section">' +
      '<div class="detail-section-title">Nearby (geographic)</div>' +
      '<div style="font-size:11px;color:var(--text3)">Subject property is not geocoded — distance-based nearby owners / sales are unavailable for this record. ' +
      'This is the ~' + (domain === 'dia' ? '13.6%' : '3.4%') + ' ungeocoded tail, not an error.</div></div>';
  }
  if (owners.length === 0 && sales.length === 0) return matHtml;

  let html = matHtml;

  // ── Nearby owner cohort ──
  if (owners.length > 0) {
    html += '<div class="detail-section">';
    html += '<div class="detail-section-title">Nearby Owner Cohort — same owner within ' + (geo.radius && geo.radius.owners || 25) + ' mi</div>';
    html += '<div style="font-size:11px;color:var(--text3);margin-bottom:8px">' + owners.length + ' nearby propert' + (owners.length === 1 ? 'y' : 'ies') + ' held by the same owner — outreach cohort.</div>';
    html += '<div style="overflow-x:auto;max-height:260px;overflow-y:auto"><table style="width:100%;border-collapse:collapse;font-size:11px">';
    html += '<thead style="position:sticky;top:0;background:var(--bg)"><tr style="border-bottom:2px solid var(--s3)">';
    html += '<th style="text-align:left;padding:4px 8px;color:var(--text3)">Address</th><th style="text-align:left;padding:4px 8px;color:var(--text3)">City</th>';
    html += '<th style="text-align:right;padding:4px 8px;color:var(--text3)">Dist</th><th style="text-align:left;padding:4px 8px;color:var(--text3)">Owner</th>';
    html += domain === 'gov'
      ? '<th style="text-align:right;padding:4px 8px;color:var(--text3)">Rent</th>'
      : '<th style="text-align:left;padding:4px 8px;color:var(--text3)">Operator</th>';
    html += '</tr></thead><tbody>';
    owners.forEach(o => {
      html += '<tr style="border-bottom:1px solid var(--s3)">';
      html += '<td style="padding:4px 8px;white-space:nowrap">' + esc(o.address) + '</td>';
      html += '<td style="padding:4px 8px">' + esc(o.city) + (o.state ? ', ' + esc(o.state) : '') + '</td>';
      html += '<td style="padding:4px 8px;text-align:right">' + _d(o.distance_miles) + '</td>';
      html += '<td style="padding:4px 8px">' + esc(o.owner_name) + '</td>';
      html += domain === 'gov'
        ? '<td style="padding:4px 8px;text-align:right">' + _money(o.annual_rent) + '</td>'
        : '<td style="padding:4px 8px">' + esc(o.operator || o.tenant) + '</td>';
      html += '</tr>';
    });
    html += '</tbody></table></div></div>';
  }

  // ── Nearby sales (comp / price anchor) ──
  if (sales.length > 0) {
    html += '<div class="detail-section">';
    html += '<div class="detail-section-title">Nearby Sales — within ' + (geo.radius && geo.radius.sales || 10) + ' mi / ' + (geo.radius && geo.radius.months || 36) + ' mo</div>';
    html += '<div style="font-size:11px;color:var(--text3);margin-bottom:8px">' + sales.length + ' recent comparable sale' + (sales.length === 1 ? '' : 's') + ' — price / cap-rate anchor.</div>';
    html += '<div style="overflow-x:auto;max-height:280px;overflow-y:auto"><table style="width:100%;border-collapse:collapse;font-size:11px">';
    html += '<thead style="position:sticky;top:0;background:var(--bg)"><tr style="border-bottom:2px solid var(--s3)">';
    html += '<th style="text-align:left;padding:4px 8px;color:var(--text3)">Address</th><th style="text-align:right;padding:4px 8px;color:var(--text3)">Dist</th>';
    html += '<th style="text-align:left;padding:4px 8px;color:var(--text3)">Date</th><th style="text-align:right;padding:4px 8px;color:var(--text3)">Price</th>';
    html += '<th style="text-align:right;padding:4px 8px;color:var(--text3)">Cap</th><th style="text-align:left;padding:4px 8px;color:var(--text3)">Buyer</th>';
    html += '</tr></thead><tbody>';
    sales.forEach(s => {
      html += '<tr style="border-bottom:1px solid var(--s3)">';
      html += '<td style="padding:4px 8px;white-space:nowrap">' + esc(s.address) + (s.city ? ' <span style="color:var(--text3)">' + esc(s.city) + (s.state ? ', ' + esc(s.state) : '') + '</span>' : '') + '</td>';
      html += '<td style="padding:4px 8px;text-align:right">' + _d(s.distance_miles) + '</td>';
      html += '<td style="padding:4px 8px">' + _dt(s.sale_date) + '</td>';
      html += '<td style="padding:4px 8px;text-align:right">' + _money(s.sold_price) + '</td>';
      html += '<td style="padding:4px 8px;text-align:right">' + _cap(s.cap_rate, s.cap_rate_source) + '</td>';
      html += '<td style="padding:4px 8px">' + esc(s.buyer) + '</td>';
      html += '</tr>';
    });
    html += '</tbody></table></div></div>';
  }

  return html;
}

// Resolve/create the canonical owner entity by creating the lead, and stash
// the returned entity_id back into the ownership cache so cadence (and any
// other entity-scoped action) can chain off it without re-resolving.
async function _udResolveEntityViaCreateLead() {
  if (!_udCache) return { ok: false, error: 'no context' };
  const own = _udCache.ownership || {};
  const db = _udCache.db;
  const pid = (_udCache.ids && _udCache.ids.property_id) || own.property_id;
  if (!pid) return { ok: false, error: 'No property id in context' };
  // BD outreach targets the landlord, never the tenant. When the dialysis
  // "true owner" resolves to the OPERATOR (operator-chain model — flagged on
  // the ownership cache by true_owner_is_operator), do NOT pass it as the
  // owner anchor: send true_owner_name=null and surface the flag so
  // bridgeCreateLead anchors on the recorded owner (the landlord) instead.
  // (Bug a, 2026-06-03 — prop 26502 was anchoring to DaVita, the operator.)
  const trueIsOperator = !!own.true_owner_is_operator;
  const body = {
    domain: db, property_id: pid, entity_id: own.owner_entity_id || null,
    owner_name: own.recorded_owner_canonical || own.recorded_owner || null,
    true_owner_name: trueIsOperator ? null : (own.true_owner_canonical || own.true_owner || null),
    true_owner_is_operator: trueIsOperator,
    owner_role: own.owner_type || null,
    label: (_udCache.property && _udCache.property.address) || (_udCache.fallback && _udCache.fallback.address) || null,
    property_address: (_udCache.property && _udCache.property.address) || null,
    source: 'property_flow',
  };
  const resp = await _udApiPost('/api/operations?action=create_lead', body);
  // R5: repeat-buyer refusal — no lead/opp was created, so do NOT cache an open
  // opportunity. Pass the structured refusal back to the caller untouched.
  if (resp && resp.blocked === 'repeat_buyer_spe') {
    return resp;
  }
  if (resp && resp.ok && resp.entity_id) {
    _udCache.ownership = _udCache.ownership || {};
    _udCache.ownership.owner_entity_id = resp.entity_id;
    // Record the persisted open-opportunity truth so the banner advances live
    // and survives a reopen without re-offering "Create the lead" (Bug c). The
    // bridge is idempotent (Bug b): a repeat click returns already_open=true on
    // the existing opportunity rather than duplicating it.
    _udCache.ownerOpp = { open: true, cadence_next_touch_due: resp.cadence_next_touch_due || null };
    // The BD opp auto-seeds an onboarding cadence; stash that so the next-step
    // banner shows "On cadence ✓" instead of offering "Add to cadence" again
    // (Nit 2). Clear the cached priority band — it was P0.5 (needs a lead) and
    // is now stale; leaving it would re-trigger the "Create the lead" step.
    if (resp.cadence_seeded) {
      _udCache.cadence = { seeded: true, next_touch_due: resp.cadence_next_touch_due || null };
      _udCache.priorityBand = null;
    }
  }
  return resp || { ok: false, error: 'no response' };
}

async function _udCreateLeadFromProperty() {
  if (!_udCache) return;
  const own = _udCache.ownership || {};
  const pid = (_udCache.ids && _udCache.ids.property_id) || own.property_id;
  if (!pid) { showToast('No property id in context', 'error'); return; }
  try {
    const resp = await _udResolveEntityViaCreateLead();
    // R5: the owner reconciles to a repeat-buyer parent — buyers are prospected
    // buy-side (showings + buy-side outreach), not with a standard prospect
    // lead. Offer the one allowed action: a Government Buyer opportunity on the
    // PARENT account.
    if (resp && resp.blocked === 'repeat_buyer_spe') {
      const pn = resp.parent_name || 'a top repeat buyer';
      if (resp.parent_entity_id && window.confirm('This owner is an SPE of ' + pn
          + ' — a top repeat buyer.\n\nBuyers are prospected buy-side (showings + buy-side outreach), '
          + 'not with a standard prospect lead.\n\nOpen a Government Buyer opportunity on ' + pn + ' instead?')) {
        const gb = await _udApiPost('/api/operations?action=open_government_buyer', { entity_id: resp.parent_entity_id });
        if (gb && gb.ok) {
          showToast((gb.already_open ? 'Government Buyer already open on ' : 'Government Buyer opportunity opened on ') + pn
            + (gb.needs_sf_mapping ? ' · SF mapping research task logged' : ''), 'success');
        } else {
          showToast('Could not open Government Buyer: ' + ((gb && gb.error) || 'unknown'), 'error');
        }
      } else {
        showToast('SPE of ' + pn + ' — prospect buy-side, not as a standard lead.', 'info');
      }
      try { _udRenderNextStep(); } catch (_e) {}
      return;
    }
    if (resp && resp.ok) {
      const msg = resp.already_open
        ? 'Lead already live · BD opportunity already open'
        : 'Lead created' + (resp.bd_opportunity_id ? ' · BD opportunity opened' : '');
      showToast(msg, 'success');
      try { _udRenderNextStep(); } catch (_e) {}
    }
    else { showToast('Create lead failed: ' + ((resp && resp.error) || 'unknown'), 'error'); }
  } catch (e) { showToast('Create lead error: ' + e.message, 'error'); }
}

async function _udAddToCadence() {
  if (!_udCache) return;
  const own = _udCache.ownership || {};
  const db = _udCache.db;
  let entityId = own.owner_entity_id || null;
  const pid = (_udCache.ids && _udCache.ids.property_id) || own.property_id;
  // Recovery (break #6): if the owner isn't resolved yet, create the lead
  // first (which resolves/creates the canonical entity), then attach the
  // cadence. No dead-end — one click does both.
  if (!entityId) {
    showToast('Creating lead to anchor the owner first…', 'info');
    const lead = await _udResolveEntityViaCreateLead();
    if (!lead || !lead.ok || !lead.entity_id) {
      showToast('Could not resolve the owner: ' + ((lead && lead.error) || 'unknown'), 'error');
      return;
    }
    entityId = lead.entity_id;
  }
  const body = { entity_id: entityId, property_id: pid, property_address: (_udCache.property && _udCache.property.address) || null, domain: db, phase: 'onboarding', priority_tier: 'B' };
  try {
    const resp = await _udApiPost('/api/operations?action=initiate_cadence', body);
    if (resp && resp.ok) { showToast('Added to onboarding cadence', 'success'); try { _udRenderNextStep(); } catch (_e) {} }
    else { showToast('Add to cadence failed: ' + ((resp && resp.error) || 'unknown'), 'error'); }
  } catch (e) { showToast('Cadence error: ' + e.message, 'error'); }
}

window._udCreateLeadFromProperty = _udCreateLeadFromProperty;
window._udAddToCadence = _udAddToCadence;
window._udRenderProspectingFeed = _udRenderProspectingFeed;
window._udFetchProspectingFeed = _udFetchProspectingFeed;
window._udFetchPriorityBand = _udFetchPriorityBand;
window._udEnrichOwnershipSignals = _udEnrichOwnershipSignals;
window._udOwnershipLadder = _udOwnershipLadder;
// ============================================================================

function _udTabOwnership() {
  const own = _udCache.ownership;
  const chain = _udCache.chain || [];
  const db = _udCache.db;

  let html = '';

  // If no ownership data but fallback has ownership fields, show them
  if (!own && chain.length === 0) {
    const fb = _udCache.fallback;
    if (fb && (fb.owner_name || fb.lessor_name || fb.grantor || fb.grantee || fb.buyer_name)) {
      html += '<div class="detail-section"><div class="detail-section-title">Ownership (from search record)</div><div class="detail-grid">';
      html += _row('Owner / Lessor', fb.owner_name || fb.lessor_name || fb.grantor);
            html += _rowHtml('Buyer / Grantee', (fb.buyer_name || fb.grantee) && fb.buyer_id ? entityLink(fb.buyer_name || fb.grantee, 'contact', fb.buyer_id, db) : esc(fb.buyer_name || fb.grantee || ''));
      html += _row('Transfer Date', _fmtDate(fb.sale_date || fb.transfer_date));
      html += _rowMoney('Sale Price', fb.sale_price || fb.price);
      html += _row('Cap Rate', _fmtCapRate(fb.cap_rate));
      html += '</div></div>';
      return html;
    }
  }

  // ── DATA GAP INDICATOR ──────────────────────────────────────────────
  // Each gap badge is a one-click resolver that focuses the relevant input
  // or triggers a lookup action.
  const gaps = [];
  if (!own) gaps.push({ label: 'ownership record', action: 'focus:udOwnRecorded' });
  else {
    // Treat operator-flagged true_owner as missing for gap-detection: a
    // chain-operator masquerading as owner is worse than a NULL because it
    // gives false confidence that the row is researched.
    const _trueOwnerTrusted = own.true_owner && !own.true_owner_is_operator;
    if (!_trueOwnerTrusted && !own.recorded_owner) gaps.push({ label: 'owner name', action: 'focus:udOwnRecorded' });
    // Contact fields: offer one-click Add Contact inline (writes to
    // unified_contacts scoped to this owner) instead of just focusing a
    // form field that's downstream of the Resolve Ownership flow.
    if (!own.contact_email) gaps.push({ label: 'contact email', action: 'add-contact' });
    if (!own.contact_phone) gaps.push({ label: 'contact phone', action: 'add-contact' });
    if (!own.contact_name && !own.contact_1_name) gaps.push({ label: 'contact name', action: 'add-contact' });
    // Salesforce link: resolve sf_account_id on the fly; if still unknown,
    // offer to create the SF Account inline.
    if (!own.sf_contact_id && !own.salesforce_id && !own.sf_account_id && !own.sf_company_id) {
      gaps.push({ label: 'Salesforce link', action: 'sf-lookup' });
    }
    if (db === 'gov' && !_trueOwnerTrusted) gaps.push({ label: 'true owner (behind LLC)', action: 'focus:udOwnTrue' });
    if (db === 'gov' && !own.true_owner_state) gaps.push({ label: 'true owner state', action: 'focus:udOwnState' });
  }
  if (chain.length === 0) gaps.push({ label: 'ownership history', action: 'research-history' });

  if (gaps.length > 0) {
    const gapId = '_udGapPanel_' + Date.now();
    html += '<div style="margin-bottom: 16px;">';
    html += '<button onclick="var p=document.getElementById(\'' + gapId + '\');if(p){p.style.display=p.style.display===\'none\'?\'block\':\'none\';this.querySelector(\'span.gap-arrow\').textContent=p.style.display===\'none\'?\'\\u25B6\':\'\\u25BC\'}" style="background:rgba(251,191,36,0.08);border:1px solid rgba(251,191,36,0.25);border-radius:8px;padding:8px 14px;font-size:12px;color:var(--yellow);cursor:pointer;display:flex;align-items:center;gap:6px;width:auto">';
    html += '<span class="gap-arrow" style="font-size:10px">&#x25B6;</span>';
    html += '<span style="font-weight:600">Resolve Data Gaps</span>';
    html += '<span style="background:var(--yellow);color:#000;font-size:10px;font-weight:700;padding:1px 6px;border-radius:10px;min-width:16px;text-align:center">' + gaps.length + '</span>';
    html += '</button>';
    html += '<div id="' + gapId + '" style="display:none;background:rgba(251,191,36,0.1);border:1px solid rgba(251,191,36,0.3);border-radius:0 0 10px 10px;padding:12px 16px;margin-top:-1px">';
    html += '<div style="font-size:12px;color:var(--text2);line-height:1.6">';
    html += gaps.map(function(g) {
      const safeAction = String(g.action).replace(/'/g, "\\'");
      return '<span class="gap-chip" onclick="_udResolveGap(\'' + safeAction + '\')" style="display:inline-block;background:var(--s2);padding:2px 8px;border-radius:4px;margin:2px 4px 2px 0;font-size:11px;cursor:pointer;border:1px solid transparent;transition:all 0.15s" onmouseover="this.style.background=\'var(--s3)\';this.style.borderColor=\'var(--yellow)\'" onmouseout="this.style.background=\'var(--s2)\';this.style.borderColor=\'transparent\'" title="Click to resolve this gap">' + esc(g.label) + ' \u2192</span>';
    }).join('');
    html += '</div></div></div>';
  }

  html += _udAssistantSection('ownership', 'Ownership Assistant', 'Summarize the ownership picture, identify the likely owner or decision-maker, and suggest the next research steps.');

  // ── CURRENT OWNERSHIP ──────────────────────────────────────────────
  if (!own) {
    html += '<div class="detail-section">';
    html += '<div class="detail-section-title">Current Ownership</div>';
    html += _udEmptyState(
      'No owner on file yet',
      'This property has no recorded or true owner. Resolving it is the next best action - pull the deed, then log who really owns it.',
      [
        { label: 'Pull recorded owner', onclick: "_udResolveGap('focus:udOwnRecorded')", primary: true },
        { label: 'Open Secretary of State', onclick: "_udResolveGap('focus:udOwnTrue')" }
      ]
    );
    html += '</div>';
  } else {
    html += '<div class="detail-section">';
    html += '<div class="detail-section-title">Current Ownership</div>';
    html += '<div class="detail-grid">';

    // ── SIDE-BY-SIDE OWNER CARDS ──────────────────────────────────────
    // true_owner_is_operator is set by 20260513_dia_purge_cms_operator_owner_pollution
    // and exposed via v_ownership_current. Hide the True Owner card when set:
    // the true_owner is a chain operator (DaVita, Fresenius, ...) wrongly
    // stamped as decision-maker by a stale ingest. Belt-and-suspenders alongside
    // the data cleanup so any future re-introduction of the bug doesn't slip
    // through to the CRM.
    //
    // recorded_owner_canonical / true_owner_canonical come from
    // 20260513150000_dia_layer_h2a_canonical_owner_name_mapping. They
    // collapse casing / suffix / SPE variants of the same entity to a
    // single display string (e.g. "Smfg" + "Sumitomo Bank Leasing And
    // Finance Inc" + 9 other SMBC variants -> "SMBC Leasing & Finance
    // Inc"). Prefer canonical in display contexts; the Resolve Ownership
    // form below keeps the raw deed text so edits preserve verbatim names.
    // (display vars now computed inside _udOwnershipLadder — PR1)
    html += '</div></div>'; // close detail-grid opened above — we'll use cards instead
    html += _udOwnershipLadder(own, db);

    // Additional details below cards
    html += '<div class="detail-grid" style="margin-bottom:0">';
    if (db === 'dia') {
      html += _rowHtml('Contact 1', own.contact_1_name && own.contact_1_id ? entityLink(own.contact_1_name, 'contact', own.contact_1_id, db) : esc(own.contact_1_name || ''));
      html += _rowHtml('Contact 2', own.contact_2_name && own.contact_2_id ? entityLink(own.contact_2_name, 'contact', own.contact_2_id, db) : esc(own.contact_2_name || ''));
      html += _rowLink('Email', own.contact_email, own.contact_email ? _outlookSearchUrl(own.contact_email) : null);
      html += _rowLink('Phone', own.contact_phone, own.contact_phone ? 'tel:' + own.contact_phone : null);
      html += _row('Priority', own.priority_level);
      html += _row('Developer', own.developer_flag ? 'Yes' + (own.developer_tier ? ' \u00b7 Tier ' + own.developer_tier : '') : null);
      html += _row('Total Properties', own.total_properties_owned ? fmtN(own.total_properties_owned) : null);
      html += _row('Current Count', own.current_property_count ? fmtN(own.current_property_count) : null);
      html += _row('Is Prospect', own.is_prospect ? 'Yes' : 'No');
    } else {
      html += _rowHtml('Contact', own.contact_name && own.contact_id ? entityLink(own.contact_name, 'contact', own.contact_id, db) : esc(own.contact_name || ''));
      html += _rowLink('Email', own.contact_email, own.contact_email ? _outlookSearchUrl(own.contact_email) : null);
      html += _rowLink('Phone', own.contact_phone, own.contact_phone ? 'tel:' + own.contact_phone : null);
    }
    html += '</div></div>';

    // ── SALESFORCE + SYSTEM LINKS ──────────────────────────────────────────
    html += _udSystemLinks(own);

    // Notes
    if (own.latest_note_summary) {
      html += '<div class="detail-section">';
      html += '<div class="detail-section-title">Latest Notes</div>';
      html += `<div class="detail-notes">${esc(own.latest_note_summary)}</div>`;
      html += '</div>';
    }
  }

  // ── RESOLVE OWNERSHIP FORM ──────────────────────────────────────
  html += '<div class="detail-section">';
  html += '<div class="detail-section-title">Resolve Ownership</div>';
  html += '<div style="font-size:11px;color:var(--text3);margin-bottom:10px">Update or create the ownership record for this property. Traces the chain back to the developer.</div>';

  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">';
  html += '<div><label class="t-label">Recorded Owner</label>';
  html += `<input id="udOwnRecorded" type="text" value="${esc(own?.recorded_owner || '')}" placeholder="Entity name on deed" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>`;
  html += '<div><label class="t-label">True Owner / Developer</label>';
  html += `<input id="udOwnTrue" type="text" value="${esc(own?.true_owner || '')}" placeholder="Parent entity, developer, fund" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>`;
  html += '</div>';

  html += '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:8px">';
  html += '<div><label class="t-label">Owner Type</label>';
  html += '<select id="udOwnType" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text)">';
  html += '<option value="">—</option>';
  ['individual','llc','reit','developer','fund','operator','other'].forEach(t => {
    html += `<option value="${t}" ${own?.owner_type === t ? 'selected' : ''}>${t.charAt(0).toUpperCase() + t.slice(1)}</option>`;
  });
  html += '</select></div>';
  html += '<div><label class="t-label">Contact Name</label>';
  html += `<input id="udOwnContact" type="text" value="${esc(own?.contact_1_name || own?.contact_name || '')}" placeholder="" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>`;
  html += '<div><label class="t-label">Contact Phone</label>';
  html += `<input id="udOwnPhone" type="tel" value="${esc(own?.contact_phone || '')}" placeholder="" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>`;
  html += '</div>';

  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">';
  html += '<div><label class="t-label">Contact Email</label>';
  html += `<input id="udOwnEmail" type="email" value="${esc(own?.contact_email || '')}" placeholder="" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>`;
  html += '<div><label class="t-label">State of Incorporation</label>';
  html += `<input id="udOwnState" type="text" value="${esc(own?.recorded_owner_state || own?.true_owner_state || '')}" placeholder="" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>`;
  html += '</div>';

  html += '<div style="margin-top:8px"><label class="t-label">Notes</label>';
  html += '<textarea id="udOwnNotes" rows="2" placeholder="Research notes..." style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);resize:vertical;font-family:inherit;box-sizing:border-box"></textarea></div>';

  html += `<button onclick="_udBtnGuard(this, _udSaveOwnership)" style="margin-top:10px;width:100%;padding:10px;background:var(--accent);color:#fff;border:none;border-radius:8px;font-weight:600;font-size:13px;cursor:pointer">Save Ownership Resolution</button>`;
  html += '</div>';

  // ── OWNERSHIP HISTORY (CHAIN) ──────────────────────────────────────
  // Dedup: collapse repeat rows that point at the same owner_entity_id /
  // recorded_owner_id / true_owner_id. This prevents "Mds Dv Victorville"
  // from appearing as both the current owner AND a 2015–2016 historical
  // owner. Earliest transfer_date and latest ownership_end win.
  const dedupedChain = _udDedupChain(chain, own);
  html += '<div class="detail-section">';
  html += `<div class="detail-section-title">Ownership History <span style="font-size:11px;color:var(--text3);font-weight:400;margin-left:8px">${dedupedChain.length} records</span></div>`;

  if (dedupedChain.length === 0) {
    html += '<div class="detail-empty" style="font-size:13px">No ownership transfer history found for this property. Check the History tab or use Research Quick Links to trace prior owners.</div>';
  } else {
    // Determine if the most recent chain entry should be treated as "current".
    // An entry is current when its ownership_end is NULL, OR (fallback) when the
    // ownership_end is within 90 days of today and no more recent entry exists.
    // This guards against stale ownership_end dates on the current record.
    const _NINETY_DAYS_MS = 90 * 24 * 60 * 60 * 1000;
    const _nowMs = Date.now();
    const _isChainEntryCurrent = (entry, isMostRecent) => {
      if (!isMostRecent) return false;
      if (!entry.ownership_end) return true;
      const endMs = new Date(entry.ownership_end).getTime();
      if (isNaN(endMs)) return true;
      return Math.abs(_nowMs - endMs) <= _NINETY_DAYS_MS;
    };

    html += '<div class="detail-timeline">';
    dedupedChain.forEach((h, idx) => {
      const isFirst = idx === 0;

      if (db === 'gov') {
        const statusClass = isFirst ? 'green' : '';
        const govOwnerName = h.to_owner || h.recorded_owner_name || h.true_owner_name || '';
        html += `<div class="detail-timeline-item ${statusClass}">`;
        html += `<div class="detail-card-date">${esc(_fmtDate(h.transfer_date) || 'Unknown date')}</div>`;
        html += `<div class="detail-card-title">${govOwnerName ? _ownerLink(govOwnerName, _ownerCtxFromChain(h, db)) : '\u2014'}</div>`;
        html += '<div class="detail-card-body">';
        if (h.from_owner) html += `<span class="t-meta3-sm">From:</span> ${esc(h.from_owner)}<br>`;
        if (h.sale_price) html += `Sale: <span class="mono" style="color:var(--green)">${fmt(h.sale_price)}</span><br>`;
        if (h.cap_rate) html += `Cap Rate: ${_fmtCapRate(h.cap_rate)}<br>`;
        if (h.annual_rent) html += `Rent: ${fmt(h.annual_rent)}<br>`;
        if (h.square_feet) html += `SF: ${fmtN(h.square_feet)}<br>`;
        if (h.recorded_owner_name && h.recorded_owner_name !== govOwnerName) html += `<span class="t-meta3-sm">Recorded:</span> ${_ownerLink(h.recorded_owner_name, _ownerCtxFromChain(h, db))}<br>`;
        if (h.true_owner_name && h.true_owner_name !== govOwnerName) html += `<span class="t-meta3-sm">True Owner:</span> ${_ownerLink(h.true_owner_name, Object.assign(_ownerCtxFromChain(h, db), { name: h.true_owner_name }))}<br>`;
        if (h.principal_names) html += `<span class="t-meta3-sm">Principals:</span> ${esc(h.principal_names)}<br>`;
        if (h._merged_count > 1) html += `<span class="detail-badge" style="background:var(--s3);color:var(--text2);margin-top:4px">${h._merged_count} entries merged</span>`;
        if (h.research_status) html += `<span class="detail-badge">${esc(cleanLabel(h.research_status))}</span>`;
        html += '</div>';
        html += '</div>';
      } else {
        // Dia: timeline row — [Owner]  start → end | sale price | cap rate
        // R5-DQ-4 (2026-05-20): defensive suffix strip \u2014 the SQL data fix
        // covers existing rows but a still-suffixed string could ride in
        // from a partial-sync. Strip on render too so the NM badge is
        // the only place "Northmarq" surfaces in the row.
        const _BROKER_SUFFIX_RE_R5 = /\s+by\s+(northmarq|cbre|jll|colliers( international)?|newmark|cushman( & wakefield)?|marcus( & millichap)?|matthews( real estate)?|matthews|berkadia|hanley|capital pacific|nai( [a-z]+)?|stream realty|kw commercial|trinity|avison( young)?|stan johnson( company)?|sjc)\.?\s*$/i;
        const _cleanOwnerName = (s) => s ? String(s).replace(_BROKER_SUFFIX_RE_R5, '').trim() : s;
        const ownerLabel = _cleanOwnerName(h.recorded_owner_name || h.true_owner_name) || '\u2014';
        // R5-DQ-4: surface brokerage / suspect-cap meta as chips. The
        // old "by Northmarq" pattern shoved broker text into the owner
        // name string, which then broke owner dedup.
        const nmBadge = h.is_northmarq
          ? ' <span class="detail-badge" style="background:#0c4a6e;color:#7dd3fc;border:1px solid #075985;margin-left:6px;font-size:9px;padding:2px 7px;border-radius:10px;font-weight:600" title="Brokered by Northmarq">NM</span>'
          : '';
        const suspectBadge = (h.cap_rate_confidence === 'suspect' || h.exclude_from_market_metrics === true)
          ? ' <span class="detail-badge" style="background:rgba(251,191,36,0.10);color:var(--yellow);border:1px solid rgba(251,191,36,0.35);margin-left:6px;font-size:9px;padding:2px 7px;border-radius:10px;font-weight:600" title="Cap rate outside the dialysis NNN band (0.5%-10%); excluded from market metrics">Suspect</span>'
          : '';
        const isCurrent = _isChainEntryCurrent(h, isFirst);
        const statusClass = isCurrent ? 'green' : '';
        const startStr = _fmtDate(h.transfer_date) || 'Unknown';
        const endStr = isCurrent ? 'Present' : (_fmtDate(h.ownership_end) || 'Unknown');
        const priceStr = h.sale_price
          ? '$' + Number(h.sale_price).toLocaleString(undefined, { maximumFractionDigits: 0 })
          : 'Not Disclosed';
        // Cap rate: prefer stated, fall back to calculated
        const capVal = h.stated_cap_rate || h.calculated_cap_rate || h.cap_rate || null;
        const capStr = capVal ? _fmtCapRate(capVal) : '\u2014';
        const capSource = h.stated_cap_rate ? 'stated' : (h.calculated_cap_rate ? 'calc' : '');

        // Prospecting status badge
        let prospectBadge = '';
        if (isCurrent && h.prospecting_status) {
          const ps = String(h.prospecting_status).toLowerCase();
          const daysSinceContact = h.last_contact_date
            ? Math.floor((Date.now() - new Date(h.last_contact_date).getTime()) / (1000 * 60 * 60 * 24))
            : null;
          let badgeColor, badgeLabel;
          if (ps === 'active' && daysSinceContact != null && daysSinceContact > 180) {
            badgeColor = 'var(--yellow)'; badgeLabel = 'Stale (' + daysSinceContact + 'd)';
          } else if (ps === 'active') {
            badgeColor = 'var(--green)'; badgeLabel = 'Active' + (daysSinceContact != null ? ' (' + daysSinceContact + 'd ago)' : '');
          } else if (ps === 'passive') {
            badgeColor = 'var(--yellow)'; badgeLabel = 'Passive';
          } else if (ps === 'do_not_contact') {
            badgeColor = 'var(--red)'; badgeLabel = 'Do Not Contact';
          } else {
            badgeColor = 'var(--text3)'; badgeLabel = 'Not Prospecting';
          }
          prospectBadge = ` <span style="font-size:9px;padding:2px 7px;border-radius:10px;background:rgba(255,255,255,0.06);color:${badgeColor};border:1px solid ${badgeColor};font-weight:600;margin-left:6px;white-space:nowrap" title="Prospecting: ${esc(ps)}${daysSinceContact != null ? ' · Last contact ' + daysSinceContact + ' days ago' : ''}">${esc(badgeLabel)}</span>`;
        } else if (isCurrent && !h.prospecting_status) {
          prospectBadge = ' <span style="font-size:9px;padding:2px 7px;border-radius:10px;background:rgba(251,191,36,0.08);color:var(--yellow);border:1px solid rgba(251,191,36,0.25);font-weight:600;margin-left:6px" title="No prospecting status set">No Status</span>';
        }

        html += `<div class="detail-timeline-item ${statusClass}">`;
        html += `<div class="detail-card-date">${esc(startStr)} \u2192 ${esc(endStr)}${isCurrent ? ' <span class="detail-badge" style="background:var(--green);color:#fff;margin-left:6px">Current</span>' : ''}${prospectBadge}</div>`;
        html += `<div class="detail-card-title">${_ownerLink(ownerLabel, _ownerCtxFromChain(h, db))}${nmBadge}${suspectBadge}</div>`;
        html += '<div class="detail-card-body">';
        if (h.true_owner_name && h.recorded_owner_name && h.true_owner_name !== h.recorded_owner_name) {
          const _tn = _cleanOwnerName(h.true_owner_name);
          html += `<span class="t-meta3-sm">True Owner:</span> ${_ownerLink(_tn, Object.assign(_ownerCtxFromChain(h, db), { name: _tn }))}<br>`;
        }
        html += `<div style="font-size:12px">Sale price: <span class="mono" style="color:var(--green)">${esc(priceStr)}</span> <span class="t-muted3">|</span> Cap rate: <span${capSource ? ' title="' + esc(capSource) + '"' : ''}>${esc(capStr)}</span></div>`;
        if (h.listing_broker) html += `<div style="font-size:11px;color:var(--text2);margin-top:2px">Listing Broker: ${esc(h.listing_broker)}</div>`;
        if (h.procuring_broker) html += `<div style="font-size:11px;color:var(--text2)">Procuring Broker: ${esc(h.procuring_broker)}</div>`;
        if (h.buyer_name) html += `<div style="font-size:11px;color:var(--text2)">Buyer: ${esc(_cleanOwnerName(h.buyer_name))}</div>`;
        if (h.seller_name) html += `<div style="font-size:11px;color:var(--text2)">Seller: ${esc(_cleanOwnerName(h.seller_name))}</div>`;
        if (h.ownership_type) html += `<div style="font-size:11px;color:var(--text3);margin-top:2px">Type: ${esc(h.ownership_type)}</div>`;
        if (h.ownership_source) html += `<div class="t-meta3">Source: ${esc(h.ownership_source)}</div>`;
        if (h._merged_count > 1) html += `<div style="margin-top:4px"><span class="detail-badge" style="background:var(--s3);color:var(--text2)">${h._merged_count} entries merged</span></div>`;
        // CRM coverage bar — shows what intel we have on this owner
        {
          const checks = [];
          checks.push({ label: 'Identified', ok: !!h.true_owner_id });
          checks.push({ label: 'Salesforce', ok: !!h.salesforce_id });
          checks.push({ label: 'Prospecting', ok: !!h.prospecting_status });
          checks.push({ label: 'Contacted', ok: !!h.last_contact_date });
          const covered = checks.filter(c => c.ok).length;
          const pct = Math.round((covered / checks.length) * 100);
          const barColor = pct >= 75 ? 'var(--green,#34d399)' : pct >= 50 ? 'var(--yellow,#fbbf24)' : pct >= 25 ? '#f59e0b' : 'var(--red,#ef4444)';
          html += '<div style="margin-top:6px;padding-top:5px;border-top:1px solid var(--border,#2a2a2a)">';
          html += '<div style="display:flex;align-items:center;gap:6px;margin-bottom:3px">';
          html += '<span style="font-size:10px;color:var(--text3);font-weight:600">CRM Coverage</span>';
          html += `<span style="font-size:9px;color:${barColor};font-weight:700">${pct}%</span>`;
          html += '</div>';
          html += '<div style="display:flex;gap:1px;height:4px;border-radius:2px;overflow:hidden;background:var(--s3,#1a1a1a)">';
          checks.forEach(c => {
            html += `<div style="flex:1;background:${c.ok ? barColor : 'transparent'}" title="${esc(c.label)}: ${c.ok ? 'Yes' : 'Missing'}"></div>`;
          });
          html += '</div>';
          html += '<div style="display:flex;gap:8px;margin-top:3px;flex-wrap:wrap">';
          checks.forEach(c => {
            html += `<span style="font-size:9px;color:${c.ok ? 'var(--text2)' : 'var(--text3,#555)'}">${c.ok ? '\u2713' : '\u2717'} ${c.label}</span>`;
          });
          html += '</div>';
          // "Sync & Begin Prospecting" button when owner lacks SF link
          if (!h.salesforce_id && h.true_owner_id) {
            const ownerName = h.true_owner_name || h.recorded_owner_name || h.to_owner || 'this owner';
            const escapedName = esc(ownerName).replace(/'/g, "\\'");
            html += `<button onclick="_udOwnerBeginProspecting('${esc(h.true_owner_id)}', '${escapedName}')" style="margin-top:6px;padding:5px 12px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;border:1px solid #a55eea;background:rgba(165,94,234,0.1);color:#a55eea;width:100%">\u2192 Sync &amp; Begin Prospecting</button>`;
          }
          html += '</div>';
        }
        html += '</div>';
        html += '</div>';
      }
    });
    html += '</div>';
  }
  html += '</div>';

  // ── RECENT TOUCHPOINTS (loaded async) ─────────────────────────────
  html += '<div id="udTouchpoints"><div style="text-align:center;padding:16px;color:var(--text3)"><span class="spinner"></span> Loading touchpoints...</div></div>';

  // ── SALESFORCE ACTIVITY FEED (loaded async) ────────────────────────
  html += '<div id="udActivityFeed"><div style="text-align:center;padding:24px;color:var(--text3)"><span class="spinner"></span> Loading activity feed...</div></div>';

  // ── INLINE LOG CALL FORM ──────────────────────────────────────────────
  html += '<div class="detail-section">';
  html += '<div class="detail-section-title">Log Call / Activity</div>';

  const sfCid = own?.salesforce_id || own?.sf_contact_id || '';
  const sfCoId = own?.sf_company_id || '';
  const ownerName = own?.true_owner_canonical || own?.true_owner || own?.recorded_owner_canonical || own?.recorded_owner || own?.contact_1_name || '';

  html += '<div class="detail-form" id="udLogCallForm">';
  html += `<div style="font-size:12px;color:var(--text2);margin-bottom:8px">Logging for: <strong>${esc(ownerName || 'Unknown')}</strong></div>`;

  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">';
  html += '<div>';
  html += '<label>Activity Type</label>';
  html += '<select id="udLogType">';
  html += '<option value="Client Outreach">Client Outreach</option>';
  html += '<option value="Introduction Call">Introduction Call</option>';
  html += '<option value="Follow-up">Follow-up</option>';
  html += '<option value="Property Discussion">Property Discussion</option>';
  html += '<option value="Email Correspondence">Email Correspondence</option>';
  html += '<option value="Market Update">Market Update</option>';
  html += '</select>';
  html += '</div>';

  html += '<div>';
  html += '<label>Outcome</label>';
  html += '<select id="udLogOutcome">';
  html += '<option value="connected">Connected</option>';
  html += '<option value="voicemail">Voicemail</option>';
  html += '<option value="no_answer">No Answer</option>';
  html += '<option value="email_sent">Email Sent</option>';
  html += '<option value="meeting_set">Meeting Set</option>';
  html += '</select>';
  html += '</div>';
  html += '</div>';

  html += '<label>Date</label>';
  html += `<input type="date" id="udLogDate" value="${new Date().toISOString().split('T')[0]}">`;

  html += '<label>Notes</label>';
  html += '<textarea id="udLogNotes" placeholder="Call notes, key takeaways, next steps..." style="min-height:80px"></textarea>';

  html += '<div style="display:flex;gap:8px;margin-top:12px">';
  html += `<button class="act-btn primary" id="udLogSubmit" onclick="_udSubmitLogCall(decodeURIComponent('${encodeURIComponent(sfCid)}'),decodeURIComponent('${encodeURIComponent(sfCoId)}'))">&#x260E; Log Activity</button>`;
  if (own?.contact_phone) html += `<a href="tel:${encodeURIComponent(own.contact_phone)}" class="act-btn">&#x1F4DE; Call</a>`;
  if (own?.contact_email) html += `<a href="mailto:${encodeURIComponent(own.contact_email)}" class="act-btn">&#x2709; Quick Email</a>`;
  html += '</div>';
  html += '</div></div>';

  // ── DRAFT EMAIL SECTION (LCC Template Engine) ──────────────────────
  html += '<div class="detail-section">';
  html += '<div class="detail-section-title">Draft Email</div>';
  html += '<div class="detail-form">';

  // Template selector + Draft button row
  html += '<div style="display:flex;gap:8px;align-items:flex-end">';
  html += '<div style="flex:1">';
  html += '<label>Template</label>';
  html += '<select id="udDraftTemplate">';
  html += '<option value="auto">Auto-select best template</option>';
  html += '<option value="T-001">First Touch (intro + report + BOV offer)</option>';
  html += '<option value="T-002">Follow-Up (cadence touchpoint)</option>';
  html += '<option value="T-003">Capital Markets Update (quarterly)</option>';
  html += '<option value="T-013">GSA Lease Award Congratulations</option>';
  html += '</select>';
  html += '</div>';
  html += '<button class="act-btn primary" id="udDraftBtn" onclick="_udGenerateDraft()" style="white-space:nowrap;height:36px">Draft Email</button>';
  html += '</div>';

  // Draft preview area (hidden until generated)
  html += '<div id="udDraftPreview" style="display:none;margin-top:16px">';
  html += '<label>Subject</label>';
  html += '<input type="text" id="udDraftSubject" style="font-size:13px;width:100%;margin-bottom:8px">';
  html += '<label>Body <span class="t-meta3">(editable — your changes will be tracked for template improvement)</span></label>';
  html += '<textarea id="udDraftBody" style="font-size:12px;min-height:240px;line-height:1.6;font-family:inherit;width:100%"></textarea>';
  html += '<div style="font-size:11px;color:var(--text3);margin-top:4px" id="udDraftMeta"></div>';
  html += '<div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">';
  if (own?.contact_email) {
    html += `<button class="act-btn primary" onclick="_udSendDraft()">Open in Email Client</button>`;
  }
  html += '<button class="act-btn" onclick="_udActionBtnGuard(this, _udCopyDraft)">Copy to Clipboard</button>';
  html += '<button class="act-btn" onclick="_udRecordDraftSend()" id="udRecordSendBtn" style="display:none">Log as Sent</button>';
  html += '</div>';
  html += '</div>';

  // Legacy template fallback (hidden, loads from Dia DB)
  html += '<div id="udLegacyTemplates" style="margin-top:16px;display:none">';
  html += '<div style="font-size:11px;color:var(--text3);margin-bottom:4px">Legacy templates (Dialysis DB)</div>';
  html += '<select id="udTemplateSelect" onchange="_udPreviewTemplate()" style="font-size:12px">';
  html += '<option value="">— Select —</option>';
  html += '</select>';
  html += '<div id="udTemplatePreview" style="display:none;margin-top:8px">';
  html += '<div id="udTemplateSubject" style="font-size:12px;padding:6px 10px;background:var(--s2);border-radius:6px;color:var(--text);margin-bottom:6px"></div>';
  html += '<div id="udTemplateBody" style="font-size:11px;padding:10px;background:var(--s2);border-radius:6px;color:var(--text2);max-height:160px;overflow-y:auto;line-height:1.4"></div>';
  html += '<div style="display:flex;gap:8px;margin-top:8px">';
  html += '<button class="act-btn" style="font-size:11px" onclick="_udSendTemplate()">Open in Client</button>';
  html += '<button class="act-btn" style="font-size:11px" onclick="_udActionBtnGuard(this, _udCopyTemplate)">Copy</button>';
  html += '</div></div></div>';

  html += '</div></div>';

  // ── RESEARCH NOTES (moved from Intel tab) ────────────────────────────────
  const _ownPropertyId = _udCache?.ids?.property_id || _udCache?.property?.property_id;
  if (_ownPropertyId) {
    html += '<div class="detail-section">';
    html += '<div class="detail-section-title" style="cursor:pointer;user-select:none" onclick="var _el=this.parentElement.querySelector(\'.intel-notes\');if(_el)_el.style.display=_el.style.display===\'none\'?\'block\':\'none\'">Research Notes</div>';
    html += '<div class="intel-notes" style="display:none">';
    html += '<textarea id="intelResearchNotes" rows="4" placeholder="Free-form research notes..." style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);resize:vertical;font-family:inherit;box-sizing:border-box;margin-bottom:8px"></textarea>';
    html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">';
    html += '<div><label class="t-label">Source / Date</label>';
    html += '<input id="intelResearchSource" type="text" placeholder="e.g., Website, Call, Loopnet" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
    html += '<div><label class="t-label">Date Found</label>';
    html += '<input id="intelResearchDate" type="date" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
    html += '</div>';
    html += '<button onclick="_udBtnGuard(this, _intelSaveNotes)" style="margin-top:10px;width:100%;padding:8px;background:var(--accent);color:#fff;border:none;border-radius:6px;font-weight:600;font-size:12px;cursor:pointer">Save Notes</button>';
    html += '</div></div>';
  }

  // Async loads after DOM renders
  _loadEmailTemplates(own);
  _loadTouchpoints(own);
  _loadActivityFeed(own);

  return html;
}

/**
 * Shared helper: walk an owner context → Salesforce Account ID.
 *
 * Covers the shell-LLC case (e.g. recorded_owner="Mds Dv Victorville" whose
 * true_owner is "Davita Inc.") by querying unified_contacts keyed on the
 * true_owner_id / recorded_owner_id / owner_entity_id hierarchy. Falls back
 * to a normalized company_name ilike lookup when no FK is available.
 *
 * Returns { sf_account_id, company_name, sf_contact_id } or null.
 * The caller is responsible for catching exceptions — this function logs
 * but does not throw.
 */
async function _resolveSfAccountId(ctx) {
  if (!ctx) return null;
  if (ctx.sf_account_id) {
    return { sf_account_id: ctx.sf_account_id, company_name: ctx.parent_account_name || ctx.name || null, sf_contact_id: ctx.sf_contact_id || null };
  }

  const _pick = function (rows) {
    return (rows || []).find(function (r) { return r && r.sf_account_id; }) || null;
  };
  const _fetch = async function (url) {
    try {
      const res = await _entityApiFetch(url);
      return (res && res.data) || [];
    } catch (e) {
      console.warn('_resolveSfAccountId fetch failed', url, e);
      return [];
    }
  };

  // Step 1 — FK-based lookups against unified_contacts. Ordered most-specific
  // first so we match the TRUE owner (parent account) before a shell LLC.
  const idCandidates = [
    { col: 'owner_entity_id',   val: ctx.owner_entity_id },
    { col: 'true_owner_id',     val: ctx.true_owner_id },
    { col: 'recorded_owner_id', val: ctx.recorded_owner_id }
  ].filter(function (c) { return c.val; });

  for (const { col, val } of idCandidates) {
    const rows = await _fetch('/api/data-query?_source=gov&table=unified_contacts&select=sf_account_id,company_name,sf_contact_id&filter=' + col + '%3Deq.' + encodeURIComponent(val) + '&limit=5');
    const hit = _pick(rows);
    if (hit) return { sf_account_id: hit.sf_account_id, company_name: hit.company_name || null, sf_contact_id: hit.sf_contact_id || null };
  }

  // Step 2 — name-based fuzzy lookup. Normalize the owner name so suffix
  // drift ("LLC", "Inc.", commas) doesn't sink the match.
  const rawName = ctx.true_owner_name || ctx.recorded_owner_name || ctx.name || '';
  if (rawName) {
    const stripped = String(rawName)
      .replace(/[.,]/g, ' ')
      .replace(/\b(llc|inc|l\.?p\.?|corp|corporation|company|co|ltd|trust)\b/gi, '')
      .replace(/\s+/g, ' ')
      .trim();
    const variants = [rawName, stripped].filter(function (v) { return v && v.length >= 3; });
    for (const v of variants) {
      const like = encodeURIComponent('*' + v + '*');
      const rows = await _fetch('/api/data-query?_source=gov&table=unified_contacts&select=sf_account_id,company_name,sf_contact_id&filter=company_name%3Dilike.' + like + '&limit=10');
      const hit = _pick(rows);
      if (hit) return { sf_account_id: hit.sf_account_id, company_name: hit.company_name || null, sf_contact_id: hit.sf_contact_id || null };
    }
  }

  return null;
}

window._resolveSfAccountId = _resolveSfAccountId;

/** Async load of SF activity feed (inserted into DOM after tab renders) */
async function _loadActivityFeed(own) {
  // Small delay to ensure DOM is ready
  await new Promise(r => setTimeout(r, 50));

  const feedEl = document.getElementById('udActivityFeed');
  if (!feedEl) return;

  const db = _udCache.db;

  try {
    let activities = [];
    let resolvedAccountId = own?.sf_account_id || own?.sf_company_id || null;
    let resolvedAccountName = null;

    // Step 1: Resolve to a Salesforce Account ID via the shared helper —
    // walks the shell-LLC → true_owner → unified_contacts FK chain, then
    // falls back to normalized company_name fuzzy match. This is how we
    // find Davita Inc.'s SF Account from a "Mds Dv Victorville" recorded
    // owner.
    if (!resolvedAccountId && own) {
      const resolved = await _resolveSfAccountId({
        owner_entity_id:   own.owner_entity_id   || null,
        true_owner_id:     own.true_owner_id     || null,
        recorded_owner_id: own.recorded_owner_id || null,
        true_owner_name:   own.true_owner        || null,
        recorded_owner_name: own.recorded_owner  || null,
        // Search SF using canonical form so SMBC variants all resolve to one Account.
        name:              own.true_owner_canonical || own.true_owner || own.recorded_owner_canonical || own.recorded_owner || null
      });
      if (resolved) {
        resolvedAccountId = resolved.sf_account_id;
        resolvedAccountName = resolved.company_name;
      }
    }

    // Step 2: Query v_sf_activity_feed by SF Account ID first (covers all
    // contacts on that account, even when the recorded owner is a shell LLC).
    if (resolvedAccountId) {
      try {
        activities = await diaQuery('v_sf_activity_feed', '*', {
          filter: 'sf_account_id=eq.' + encodeURIComponent(resolvedAccountId),
          order: 'activity_date.desc',
          limit: 25
        });
        if (Array.isArray(activities) && activities.length === 0) {
          // Some deployments expose the SF Account FK as sf_company_id
          activities = await diaQuery('v_sf_activity_feed', '*', {
            filter: 'sf_company_id=eq.' + encodeURIComponent(resolvedAccountId),
            order: 'activity_date.desc',
            limit: 25
          });
        }
      } catch (e) { console.warn('activity feed: sf_account_id query failed', e); }
    }

    // Step 3: Legacy fallback paths — sf_contact_id, true_owner_id, contact_id
    if (!activities || activities.length === 0) {
      const sfId = own?.sf_contact_id || own?.salesforce_id;
      const toId = own?.true_owner_id;
      const cId = own?.contact_id;
      if (sfId) {
        activities = await diaQuery('v_sf_activity_feed', '*', { filter: 'sf_contact_id=eq.' + encodeURIComponent(sfId), order: 'activity_date.desc', limit: 25 });
      } else if (toId) {
        activities = await diaQuery('v_sf_activity_feed', '*', { filter: 'true_owner_id=eq.' + encodeURIComponent(toId), order: 'activity_date.desc', limit: 25 });
      } else if (cId && db === 'dia') {
        activities = await diaQuery('v_sf_activity_feed', '*', { filter: 'contact_id=eq.' + encodeURIComponent(cId), order: 'activity_date.desc', limit: 25 });
      }
    }

    if (!activities || activities.length === 0) {
      let emptyHtml = '<div class="detail-section"><div class="detail-section-title">Salesforce Activity Feed</div>';
      emptyHtml += '<div class="detail-empty">No CRM activity found for this owner';
      if (resolvedAccountName) emptyHtml += ' <span class="t-muted3">(searched ' + esc(resolvedAccountName) + ')</span>';
      emptyHtml += '</div>';
      if (!resolvedAccountId) {
        emptyHtml += '<div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">';
        emptyHtml += '<button class="act-btn primary" onclick="_udFeedCreateSfAccount()">+ Create Salesforce Account</button>';
        emptyHtml += '<button class="act-btn" onclick="_udFeedAddContact()">+ Add Contact</button>';
        emptyHtml += '</div>';
      }
      emptyHtml += '</div>';
      feedEl.innerHTML = emptyHtml;
      return;
    }

    let html = '<div class="detail-section">';
    html += `<div class="detail-section-title">Salesforce Activity Feed <span style="font-size:11px;color:var(--text3);font-weight:400;margin-left:8px">${activities.length} activities</span></div>`;

    activities.forEach(a => {
      const typeColor = a.feed_type === 'task' ? 'var(--yellow)' :
                        a.feed_type === 'call_outcome' ? 'var(--green)' : 'var(--accent)';
      html += '<div class="detail-card">';
      html += '<div class="detail-card-header">';
      html += `<div class="detail-card-title">${esc(a.subject || a.activity_type || 'Activity')}</div>`;
      html += `<div class="detail-card-date">${esc(_fmtDate(a.activity_date))}</div>`;
      html += '</div>';
      html += '<div class="detail-card-body">';
      html += `<span style="display:inline-block;font-size:10px;padding:2px 6px;border-radius:4px;background:${typeColor};color:#fff;margin-bottom:4px">${esc(a.feed_type || '')}</span>`;
      if (a.activity_type) html += ` <span style="font-size:12px;color:var(--text2)">${esc(a.activity_type)}</span>`;
      if (a.status) html += `<br><span class="t-meta3-sm">Status: ${esc(a.status)}</span>`;
      if (a.assigned_to) html += `<br><span class="t-meta3-sm">Assigned: ${esc(a.assigned_to)}</span>`;
      if (a.notes) html += `<br><span style="font-size:12px;color:var(--text2);white-space:pre-wrap">${esc(a.notes.substring(0, 200))}${a.notes.length > 200 ? '...' : ''}</span>`;
      html += '</div></div>';
    });

    html += '</div>';
    feedEl.innerHTML = html;

  } catch (err) {
    console.error('Activity feed error:', err);
    showToast('Failed to load activity feed', 'error');
    feedEl.innerHTML = '<div class="detail-section"><div class="detail-section-title">Salesforce Activity Feed</div><div class="detail-empty">Error loading activity feed</div></div>';
  }
}

/** Empty-state action: open the SF "New Account" form prefilled with the current owner. */
function _udFeedCreateSfAccount() {
  const own = _udCache && _udCache.ownership;
  // Prefill the new SF Account with the canonical entity name (Layer H.2.a) —
  // we want one SF Account per entity, not one per casing variant.
  const name = (own && (own.true_owner_canonical || own.true_owner || own.recorded_owner_canonical || own.recorded_owner)) || '';
  const url = _SF_BASE + '/lightning/o/Account/new?defaultFieldValues=Name=' + encodeURIComponent(name);
  window.open(url, '_blank', 'noopener');
  showToast('Opening Salesforce \u2014 New Account (' + (name || 'Owner') + ')', 'info');
}

/** Empty-state action: open the OwnerDrawer's Add Contact prompt scoped to the current owner. */
function _udFeedAddContact() {
  const own = _udCache && _udCache.ownership;
  const db = _udCache && _udCache.db;
  if (!own) { showToast('No owner record loaded', 'error'); return; }
  const ctx = _ownerCtxFromCurrent(own, db, 'recorded') || _ownerCtxFromCurrent(own, db, 'true');
  if (!ctx) return;
  // Stash a temporary cache so _ownerDrawerAddContact() can reuse its prompts
  _ownerDrawerCache = Object.assign({ contacts: [], open_activities: [], activity_history: [] }, ctx);
  _ownerDrawerAddContact();
}

window._udFeedCreateSfAccount = _udFeedCreateSfAccount;
window._udFeedAddContact = _udFeedAddContact;

// ─── INTEL TAB ────────────────────────────────────────────────────────────────

function _udTabIntel() {
  if (!_udCache) return '<div class="detail-empty">No data loaded</div>';
  const propertyId = _udCache.ids?.property_id;
  if (!propertyId) return '<div class="detail-empty">No property ID</div>';

  let html = '';

  html += _udAssistantSection('intel', 'Research Assistant', 'Turn the current notes and property context into a clean analyst summary and recommended next actions.');
  html += _udResearchIntakeSection();

  // ── PRIOR SALE SECTION ──────────────────────────────────────────────────────
  // Read-only summary. The editable form was removed — property_sale_events
  // is now the single source of truth. To record a new sale, use the Sales
  // tab "+ Add" form, which writes directly to property_sale_events and lets
  // the DB trigger mark concurrent listings Sold.
  html += '<div class="detail-section">';
  html += '<div class="detail-section-title" style="cursor:pointer;user-select:none" onclick="var _el=this.parentElement.querySelector(\'.intel-prior-sale\');if(_el)_el.style.display=_el.style.display===\'none\'?\'block\':\'none\'">Prior Sale</div>';
  html += '<div class="intel-prior-sale" style="display:block">';
  html += '<div id="intelPriorSaleSummary" style="font-size:12px;color:var(--text2)"><span class="spinner"></span> Loading latest sale…</div>';
  html += '<div style="margin-top:10px;font-size:11px;color:var(--text3);font-style:italic">Sale details are managed on the Sales tab. Open Sales → “+ Add” to record a new transaction.</div>';
  html += '</div></div>';

  // ── LOAN / DEBT SECTION ─────────────────────────────────────────────────────
  html += '<div class="detail-section">';
  html += '<div class="detail-section-title" style="cursor:pointer;user-select:none" onclick="var _el=this.parentElement.querySelector(\'.intel-loan\');if(_el)_el.style.display=_el.style.display===\'none\'?\'block\':\'none\'">Loan / Debt</div>';
  html += '<div class="intel-loan" style="display:block">';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">';
  html += '<div><label class="t-label">Lender</label>';
  html += '<input id="intelLender" type="text" placeholder="Bank or fund name" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
  html += '<div><label class="t-label">Loan Amount ($)</label>';
  html += '<input id="intelLoanAmount" type="number" placeholder="0" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
  html += '</div>';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">';
  html += '<div><label class="t-label">Interest Rate (%)</label>';
  html += '<input id="intelInterestRate" type="number" placeholder="0.00" step="0.01" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
  html += '<div><label class="t-label">Loan Type</label>';
  html += '<select id="intelLoanType" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text)">';
  html += '<option value="">—</option>';
  ['Fixed', 'Variable', 'Bridge', 'CMBS', 'Agency', 'Other'].forEach(t => {
    html += `<option value="${t}">${t}</option>`;
  });
  html += '</select></div>';
  html += '</div>';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">';
  html += '<div><label class="t-label">Origination Date</label>';
  html += '<input id="intelOrigDate" type="date" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
  html += '<div><label class="t-label">Maturity Date</label>';
  html += '<input id="intelMatDate" type="date" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
  html += '</div>';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">';
  html += '<div><label class="t-label">Amortization (years)</label>';
  html += '<input id="intelAmortization" type="number" placeholder="0" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
  html += '<div><label class="t-label">Recourse</label>';
  html += '<select id="intelRecourse" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text)">';
  html += '<option value="">—</option>';
  ['Recourse', 'Non-Recourse', 'Partial'].forEach(t => {
    html += `<option value="${t}">${t}</option>`;
  });
  html += '</select></div>';
  html += '</div>';
  html += '<div style="margin-top:8px"><label class="t-label">LTV (%)</label>';
  html += '<input id="intelLTV" type="number" placeholder="0.00" step="0.01" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
  html += '<button onclick="_udBtnGuard(this, _intelSaveLoan)" style="margin-top:10px;width:100%;padding:8px;background:var(--accent);color:#fff;border:none;border-radius:6px;font-weight:600;font-size:12px;cursor:pointer">Save Loan Info</button>';
  html += '</div></div>';

  // ── CASH FLOW / VALUATION SECTION ───────────────────────────────────────────
  html += '<div class="detail-section">';
  html += '<div class="detail-section-title" style="cursor:pointer;user-select:none" onclick="var _el=this.parentElement.querySelector(\'.intel-cashflow\');if(_el)_el.style.display=_el.style.display===\'none\'?\'block\':\'none\'">Cash Flow / Valuation</div>';
  html += '<div class="intel-cashflow" style="display:block">';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">';
  html += '<div><label class="t-label">Annual Rent / NOI ($)</label>';
  html += '<input id="intelAnnualRent" type="number" placeholder="0" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
  html += '<div><label class="t-label">Rent Per SF ($/SF)</label>';
  html += '<input id="intelRentPerSF" type="number" placeholder="0.00" step="0.01" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
  html += '</div>';
  html += '<div style="margin-top:8px"><label class="t-label">Expense Type (NNN, Gross, etc.)</label>';
  html += '<input id="intelExpenseType" type="text" placeholder="e.g., NNN, Modified Gross" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">';
  html += '<div><label class="t-label">Estimated Value ($)</label>';
  html += '<input id="intelEstValue" type="number" placeholder="0" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
  html += '<div><label class="t-label">Current Cap Rate (%)</label>';
  html += '<input id="intelCurrentCapRate" type="number" placeholder="0.00" step="0.01" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
  html += '</div>';
  html += '<button onclick="_udBtnGuard(this, _intelSaveCashFlow)" style="margin-top:10px;width:100%;padding:8px;background:var(--accent);color:#fff;border:none;border-radius:6px;font-weight:600;font-size:12px;cursor:pointer">Save Cash Flow</button>';
  html += '</div></div>';

  // ── RESEARCH NOTES SECTION ──────────────────────────────────────────────────
  html += '<div class="detail-section">';
  html += '<div class="detail-section-title" style="cursor:pointer;user-select:none" onclick="var _el=this.parentElement.querySelector(\'.intel-notes\');if(_el)_el.style.display=_el.style.display===\'none\'?\'block\':\'none\'">Research Notes</div>';
  html += '<div class="intel-notes" style="display:block">';
  html += '<textarea id="intelResearchNotes" rows="4" placeholder="Free-form research notes..." style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);resize:vertical;font-family:inherit;box-sizing:border-box;margin-bottom:8px"></textarea>';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">';
  html += '<div><label class="t-label">Source / Date</label>';
  html += '<input id="intelResearchSource" type="text" placeholder="e.g., Website, Call, Loopnet" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
  html += '<div><label class="t-label">Date Found</label>';
  html += '<input id="intelResearchDate" type="date" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);box-sizing:border-box"></div>';
  html += '</div>';
  html += '<button onclick="_udBtnGuard(this, _intelSaveNotes)" style="margin-top:10px;width:100%;padding:8px;background:var(--accent);color:#fff;border:none;border-radius:6px;font-weight:600;font-size:12px;cursor:pointer">Save Notes</button>';
  html += '</div></div>';

  return html;
}

// ─── SALES TAB ──────────────────────────────────────────────────────────────
//
// Canonical data source: property_sale_events
//   - Sales tab, Ownership History, and Intel → Prior Sale summary all read
//     from this table. sales_transactions remains as a legacy compat source
//     that the backfill migration has already mirrored into
//     property_sale_events. Going forward new writes land in the canonical
//     table and a DB trigger marks any concurrent active listings Sold.

let _salesCache = null; // { property_id, db, transactions: [], listings: [] }
let _salesFilter = 'all'; // 'all' | 'listings' | 'sales'

async function _udRenderSalesAsync(bodyEl) {
  const propertyId = _udCache.ids?.property_id || _udCache.property?.property_id;
  const db = _udCache.db;

  // If already loaded for this property, just render
  if (_salesCache && _salesCache.property_id === propertyId && _salesCache.db === db) {
    if (bodyEl) bodyEl.innerHTML = _udTabSales();
    return;
  }

  // Show loading spinner
  if (bodyEl) bodyEl.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading sales history...</p></div>';

  const qFn = db === 'gov' ? govQuery : diaQuery;
  let transactions = [];
  let listings = [];

  if (propertyId) {
    try {
      const propId = encodeURIComponent(propertyId);
      // Prefer the canonical property_sale_events table. If it isn't yet
      // reachable (older environments), fall back to sales_transactions so
      // the tab never goes empty during rollout.
      const saleRes = await qFn('property_sale_events', '*', {
        filter: `property_id=eq.${propId}`,
        order: 'sale_date.desc.nullslast',
        limit: 100
      }).catch(() => null);
      // diaQuery/govQuery swallow errors and return [], so .catch() above
      // never fires and a nominally-present-but-empty response would suppress
      // the sales_transactions fallback entirely. Gate the fallback on actual
      // row presence, not just non-null.
      const saleRows = Array.isArray(saleRes) ? saleRes : (saleRes?.data || null);
      const hasSaleRows = Array.isArray(saleRows) && saleRows.length > 0;
      const [listRes, txnRes] = await Promise.all([
        qFn('available_listings', '*', {
          filter: `property_id=eq.${propId}`,
          order: 'listing_date.desc.nullslast',
          limit: 50
        }).catch(() => []),
        hasSaleRows
          ? Promise.resolve(saleRows)
          : qFn('sales_transactions', '*', {
              filter: `property_id=eq.${propId}`,
              order: 'sale_date.desc',
              limit: 100
            }).catch(() => [])
      ]);
      const rawListings = Array.isArray(listRes) ? listRes : (listRes?.data || []);
      // Round 76eg: drop rows the consolidation function has retired so
      // they don't pad the timeline counts or render as phantom listings.
      listings = rawListings.filter((l) => {
        if (l.exclude_from_market_metrics === true) return false;
        const status = String(l.status || '').toLowerCase();
        return status !== 'superseded';
      });
      const rawTxns = Array.isArray(txnRes) ? txnRes : (txnRes?.data || []);
      // Normalize both sources to a common shape so renderers don't care
      // which table the row came from.
      transactions = rawTxns.map(_salesNormalizeSaleRow);
    } catch (e) {
      console.warn('Sales history fetch error:', e);
    }
  }

  _salesCache = { property_id: propertyId, db, transactions, listings };
  if (bodyEl) bodyEl.innerHTML = _udTabSales();
}

// Normalize rows from either property_sale_events OR sales_transactions into
// a single shape: { sale_date, price, cap_rate, buyer_name, seller_name,
// broker_name, source, notes, sale_event_id?, sale_id? }. This is what all
// _salesRender* helpers expect.
function _salesNormalizeSaleRow(r) {
  if (!r || typeof r !== 'object') return r;
  const price = r.price != null ? r.price : (r.sold_price != null ? r.sold_price : r.sale_price);
  return Object.assign({}, r, {
    price,
    buyer_name: r.buyer_name || r.buyer || null,
    seller_name: r.seller_name || r.seller || null,
    broker_name: r.broker_name || r.listing_broker || null,
  });
}

function _udTabSales() {
  const txns = _salesCache ? (_salesCache.transactions || []) : [];
  const listings = _salesCache ? (_salesCache.listings || []) : [];
  const propertyId = _udCache.ids?.property_id || _udCache.property?.property_id;

  // Build a unified chronological timeline that pairs listings with their
  // corresponding sale where off_market_date ≈ sale_date (±30 days).
  const allEvents = _salesBuildTimeline(listings, txns);

  let html = '';

  if (allEvents.length === 0) {
    html += '<div class="detail-empty" style="text-align:center;padding:40px 20px">';
    html += '<div style="font-size:18px;margin-bottom:8px;color:var(--text2)">No listing or sales history</div>';
    html += '<div style="font-size:13px;color:var(--text3);margin-bottom:16px">Add a sales comp to start building the transaction history.</div>';
    if (propertyId) {
      html += `<button class="btn-accent" onclick="_salesToggleForm()" style="padding:8px 18px;border-radius:8px;font-size:13px;cursor:pointer;border:none;background:var(--accent);color:#fff">+ Add Transaction</button>`;
    }
    html += '</div>';
    html += `<div id="salesAddForm" style="display:none">${_salesFormHtml()}</div>`;
    return html;
  }

  // Filter chips replace the old "X listings · Y sales" counter.
  const filter = _salesFilter || 'all';
  const events = allEvents.filter((e) => {
    // Hide excluded/duplicate sales entirely
    if (e.sale && e.sale.exclude_from_market_metrics === true) return false;
    // Round 76eg: same treatment for listings collapsed by the
    // consolidation function. They're kept in the DB for forensics but
    // would otherwise inflate the timeline with phantom rows.
    if (e.listing && (
      e.listing.exclude_from_market_metrics === true ||
      String(e.listing.status || '').toLowerCase() === 'superseded'
    )) return false;
    if (filter === 'listings') return !!e.listing;
    if (filter === 'sales') return !!e.sale;
    return true;
  });

  html += '<div class="detail-section">';
  html += `<div class="detail-section-title" style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">`;
  html += `<span>Sales &amp; Listing History</span>`;
  if (propertyId) {
    html += `<button class="btn-accent" onclick="_salesToggleForm()" style="padding:5px 14px;border-radius:6px;font-size:12px;cursor:pointer;border:none;background:var(--accent);color:#fff">+ Add</button>`;
  }
  html += '</div>';

  // Filter chips row
  const chips = [
    { key: 'all',      label: 'All' },
    { key: 'listings', label: 'Listings' },
    { key: 'sales',    label: 'Sales' },
  ];
  html += '<div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0 12px 0">';
  chips.forEach((c) => {
    const isActive = filter === c.key;
    const bg = isActive ? 'var(--accent)' : 'var(--s2)';
    const fg = isActive ? '#fff' : 'var(--text2)';
    const border = isActive ? 'var(--accent)' : 'var(--border)';
    html += `<button onclick="_salesSetFilter('${c.key}')" style="padding:4px 12px;border-radius:14px;font-size:11px;font-weight:600;cursor:pointer;border:1px solid ${border};background:${bg};color:${fg};text-transform:uppercase;letter-spacing:0.4px">${esc(c.label)}</button>`;
  });
  html += '</div>';

  if (events.length === 0) {
    html += `<div class="detail-empty" style="font-size:13px;padding:16px 8px">No ${filter === 'sales' ? 'sales' : 'listings'} match this filter.</div>`;
    html += '</div>';
    html += `<div id="salesAddForm" style="display:none">${_salesFormHtml()}</div>`;
    return html;
  }

  // Timeline
  html += '<div style="position:relative;padding-left:24px">';
  html += '<div style="position:absolute;left:8px;top:4px;bottom:4px;width:2px;background:var(--border);border-radius:1px"></div>';

  events.forEach((ev, idx) => {
    const isFirst = idx === 0;
    const dotColor = ev.sale ? 'var(--green)' : (ev.listing && _salesListingIsActive(ev.listing) ? 'var(--accent)' : 'var(--text3)');

    html += '<div style="position:relative;margin-bottom:16px">';
    html += `<div style="position:absolute;left:-20px;top:4px;width:10px;height:10px;border-radius:50%;background:${dotColor};border:2px solid var(--bg)${isFirst ? ';box-shadow:0 0 0 3px rgba(46,204,113,0.15)' : ''}"></div>`;
    html += '<div style="background:var(--s2);border-radius:10px;padding:14px;border:1px solid var(--border)">';

    if (ev.listing && ev.sale) {
      html += _salesRenderCombined(ev.listing, ev.sale);
    } else if (ev.sale) {
      html += _salesRenderSale(ev.sale);
    } else if (ev.listing) {
      html += _salesRenderListing(ev.listing);
    }

    html += '</div></div>';
  });

  html += '</div></div>';

  html += `<div id="salesAddForm" style="display:none">${_salesFormHtml()}</div>`;
  return html;
}

function _salesSetFilter(f) {
  _salesFilter = (f === 'listings' || f === 'sales') ? f : 'all';
  const bodyEl = document.getElementById('detailBody');
  if (bodyEl) bodyEl.innerHTML = _udTabSales();
}

// ─── Sales tab helpers ──────────────────────────────────────────────────────

function _salesParseDate(d) {
  if (!d) return null;
  const t = Date.parse(d);
  return isNaN(t) ? null : t;
}

function _salesListingIsActive(l) {
  if (l.is_active === true) return true;
  if (l.is_active === false) return false;
  // Fallback: active if no off_market_date
  return !l.off_market_date;
}

// Tier 6: notes-dedup state for the Deal History timeline. WeakMap keyed by
// the sale/listing row object (so we don't mutate the source row); value is
// the human label of the FIRST event that carried this notes blob. Reset on
// every _udTabDealHistory() call. Renderers consult _dhNotesDupLabel(obj).
let _dhNotesDup = new WeakMap();
function _dhNormalizeNotes(s) {
  return String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();
}
function _dhEventLabelForNotes(ev) {
  if (ev.kind === 'sale') {
    if (ev.sale && ev.sale.sale_date) return _fmtDate(ev.sale.sale_date) + ' sale';
    if (ev.listing && ev.listing.listing_date) return _fmtDate(ev.listing.listing_date) + ' listing';
  }
  return 'earlier event';
}
function _dhNotesDupLabel(obj) {
  if (!obj || !_dhNotesDup) return null;
  return _dhNotesDup.get(obj) || null;
}
function _dhRenderNotesOrDup(obj) {
  if (!obj || !obj.notes) return '';
  const dup = _dhNotesDupLabel(obj);
  if (dup) {
    return `<div style="font-size:11px;color:var(--text3);margin-top:4px;border-top:1px solid var(--border);padding-top:6px;font-style:italic">Same notes as ${esc(dup)} — collapsed</div>`;
  }
  return `<div style="font-size:12px;color:var(--text2);margin-top:4px;border-top:1px solid var(--border);padding-top:6px">${esc(obj.notes)}</div>`;
}

// Tier 5: detect listings that the 76eg auto-close trigger
// (fn_listing_close_if_sold) closed against a pre-existing sale. The trigger
// appends a signature to listing.notes and stamps off_market_date to the
// sale_date — which, when sale_date < listing_date, makes the card read
// "Listed May 6 → Sold May 5" (off_market preceded listing). Detect via either
// the notes signature or the date inversion so we can re-label honestly.
const _DH_AUTOCLOSE_SIGNATURE = /\[(?:fn_listing_close_if_sold|Round 76eg backfill)\b/i;
function _salesListingAutoClosedAgainstPriorSale(l) {
  if (!l) return false;
  const notes = String(l.notes || '');
  if (_DH_AUTOCLOSE_SIGNATURE.test(notes)) return true;
  // Fallback: off_market_date strictly before listing_date is otherwise
  // nonsensical and only happens when the trigger back-stamps an earlier
  // sale_date onto a re-ingested listing.
  if (l.listing_date && l.off_market_date) {
    const lm = new Date(l.listing_date).getTime();
    const om = new Date(l.off_market_date).getTime();
    if (!isNaN(lm) && !isNaN(om) && om < lm) return true;
  }
  return false;
}

function _salesListingStatus(l, matchedSale) {
  const raw = (l && l.status ? String(l.status) : '').toLowerCase();
  if (matchedSale || raw === 'sold') return { label: 'Sold',      color: 'var(--green)' };
  if (raw === 'withdrawn')           return { label: 'Withdrawn', color: 'var(--yellow)' };
  if (raw === 'expired')             return { label: 'Expired',   color: 'var(--text3)' };
  if (_salesListingIsActive(l))      return { label: 'Active',    color: 'var(--accent)' };
  if (l.off_market_date)             return { label: 'Withdrawn', color: 'var(--yellow)' };
  return { label: 'Inactive', color: 'var(--text3)' };
}

function _salesBuildTimeline(listings, txns) {
  const listingArr = Array.isArray(listings) ? listings.slice() : [];
  const saleArr = Array.isArray(txns) ? txns.slice() : [];
  const THIRTY_DAYS = 30 * 24 * 60 * 60 * 1000;
  const NINETY_DAYS = 90 * 24 * 60 * 60 * 1000;
  const usedSaleIdx = new Set();
  const excludedSaleIdx = new Set();
  const events = [];

  // Mark excluded/duplicate sales so they are skipped during pairing
  saleArr.forEach((sale, i) => {
    if (sale.exclude_from_market_metrics === true) excludedSaleIdx.add(i);
  });

  listingArr.forEach(listing => {
    const offMs = _salesParseDate(listing.off_market_date);
    let matchIdx = -1;
    let matchDiff = Infinity;

    if (offMs != null) {
      // First pass: try 30-day window against non-excluded sales
      saleArr.forEach((sale, i) => {
        if (usedSaleIdx.has(i) || excludedSaleIdx.has(i)) return;
        const saleMs = _salesParseDate(sale.sale_date);
        if (saleMs == null) return;
        const diff = Math.abs(saleMs - offMs);
        if (diff <= THIRTY_DAYS && diff < matchDiff) {
          matchIdx = i;
          matchDiff = diff;
        }
      });
      // Second pass: wider 90-day window if no 30-day match found
      // (handles CoStar contract-vs-recorded date splits)
      if (matchIdx < 0) {
        saleArr.forEach((sale, i) => {
          if (usedSaleIdx.has(i) || excludedSaleIdx.has(i)) return;
          const saleMs = _salesParseDate(sale.sale_date);
          if (saleMs == null) return;
          const diff = Math.abs(saleMs - offMs);
          if (diff <= NINETY_DAYS && diff < matchDiff) {
            matchIdx = i;
            matchDiff = diff;
          }
        });
      }
    }

    if (matchIdx >= 0) {
      usedSaleIdx.add(matchIdx);
      const sale = saleArr[matchIdx];
      events.push({
        listing,
        sale,
        sortKey: _salesParseDate(sale.sale_date) || offMs || _salesParseDate(listing.listing_date) || 0
      });
    } else {
      events.push({
        listing,
        sale: null,
        sortKey: offMs || _salesParseDate(listing.listing_date) || 0
      });
    }
  });

  // Add remaining unmatched, non-excluded sales as standalone entries
  saleArr.forEach((sale, i) => {
    if (usedSaleIdx.has(i) || excludedSaleIdx.has(i)) return;
    events.push({
      listing: null,
      sale,
      sortKey: _salesParseDate(sale.sale_date) || 0
    });
  });

  events.sort((a, b) => (b.sortKey || 0) - (a.sortKey || 0));
  return events;
}

// UI Phase 4C Unit 1 — uniform "View source ↗" affordance for a sub-record row
// (sale / lease / listing / deed / document). Surfaces ONLY sources already
// present ON the record — never fabricates a URL — and returns '' when there is
// no real source, so a dead "View source" button never renders. Each link
// stops propagation so it never triggers a row-level drill (Unit 2).
//   • intake_artifact_path → openIntakeArtifact (1-hour signed download)
//   • source_url / listing_url / url / deed_url / document_url / tracked_urls[0]
//     → external doc / listing page in a new tab
//   • a Salesforce Account id on the record → SF Lightning deep-link
function _udSourceLink(record) {
  if (!record) return '';
  const linkStyle = 'font-size:11px;color:var(--accent);text-decoration:none;white-space:nowrap';
  const stop = 'event.stopPropagation()';
  const links = [];

  // 1) Staged artifact (OM / flyer / lease PDF).
  const artifact = record.intake_artifact_path || null;
  if (artifact && typeof openIntakeArtifact === 'function') {
    const label = record.intake_artifact_type === 'flyer' ? 'Flyer'
      : record.intake_artifact_type === 'marketing_brochure' ? 'Brochure'
      : record.intake_artifact_type === 'lease' ? 'Lease doc'
      : 'Source doc';
    links.push(`<a href="javascript:void(0)" onclick="${stop};openIntakeArtifact(${JSON.stringify(artifact).replace(/"/g, '&quot;')})" style="${linkStyle}" title="Open the staged document (1-hour signed link)">📄 ${esc(label)} ↗</a>`);
  }

  // 2) First real https document / listing / deed URL on the record.
  const urlCandidates = [];
  ['source_url', 'listing_url', 'url', 'deed_url', 'document_url', 'costar_url', 'page_url'].forEach(f => {
    if (record[f]) urlCandidates.push(record[f]);
  });
  if (Array.isArray(record.tracked_urls)) urlCandidates.push(...record.tracked_urls);
  let firstUrl = null;
  for (const u of urlCandidates) {
    if (u && /^https?:\/\//i.test(String(u).trim())) { firstUrl = String(u).trim(); break; }
  }
  if (firstUrl) {
    let host = '';
    try { host = new URL(firstUrl).hostname.replace(/^www\./, ''); } catch (_) { /* */ }
    const label = host.includes('crexi') ? 'Crexi'
      : host.includes('loopnet') ? 'LoopNet'
      : host.includes('costar') ? 'CoStar'
      : host.includes('sharepoint') ? 'SharePoint'
      : (host || 'Source');
    links.push(`<a href="${safeHref(firstUrl)}" target="_blank" rel="noopener noreferrer" onclick="${stop}" style="${linkStyle}" title="${esc(firstUrl)}">🔗 ${esc(label)} ↗</a>`);
  }

  // 3) Salesforce Account deep-link, when an id is already on the record.
  const sfAcct = record.sf_account_id || record.sf_company_id || record.salesforce_id || null;
  if (sfAcct && typeof _SF_BASE === 'string') {
    links.push(`<a href="${_SF_BASE}/Account/${encodeURIComponent(sfAcct)}/view" target="_blank" rel="noopener noreferrer" onclick="${stop}" style="font-size:11px;color:#00a1e0;text-decoration:none;white-space:nowrap" title="Open in Salesforce">☁ Salesforce ↗</a>`);
  }

  if (!links.length) return '';
  return `<span class="ud-source-links" style="display:inline-flex;gap:12px;flex-wrap:wrap;align-items:center">${links.join('')}</span>`;
}

function _salesRenderListing(l) {
  const status = _salesListingStatus(l, null);
  const autoClosed = _salesListingAutoClosedAgainstPriorSale(l);
  let html = '';

  html += '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">';
  html += `<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:${status.color};padding:2px 8px;border-radius:10px;background:rgba(255,255,255,0.04);border:1px solid ${status.color}">${esc(status.label)}</span>`;
  html += `<span class="t-meta3">Listing${autoClosed ? ' · auto-matched to prior sale' : ''}</span>`;
  html += '</div>';

  // Dates row. For auto-closed listings, off_market_date is a back-stamp of the
  // pre-existing sale_date and renders as "Listed May 6 / Off Market May 5"
  // (date inversion), so label that field explicitly as the matched-sale date
  // rather than the listing's own off-market event.
  const dateBits = [];
  if (l.listing_date) dateBits.push(`<span class="t-muted3">On Market:</span> <span class="t-body">${esc(_fmtDate(l.listing_date))}</span>`);
  if (l.off_market_date) {
    if (autoClosed) {
      dateBits.push(`<span class="t-muted3">Matched sale on:</span> <span class="t-body">${esc(_fmtDate(l.off_market_date))}</span>`);
    } else {
      dateBits.push(`<span class="t-muted3">Off Market:</span> <span class="t-body">${esc(_fmtDate(l.off_market_date))}</span>`);
    }
  }
  if (dateBits.length) {
    html += `<div style="font-size:12px;margin-bottom:8px;display:flex;gap:14px;flex-wrap:wrap">${dateBits.join('')}</div>`;
  }

  // Asking prices
  const initial = l.initial_price != null ? l.initial_price : l.asking_price;
  const last = l.last_price != null ? l.last_price : null;
  if (initial != null || last != null) {
    html += '<div style="display:flex;gap:16px;margin-bottom:8px;flex-wrap:wrap">';
    if (initial != null) {
      html += `<div><div class="t-cap">Original Ask</div><div style="font-size:16px;font-weight:700;color:var(--accent)">${fmt(initial)}</div></div>`;
    }
    if (last != null && Number(last) !== Number(initial)) {
      html += `<div><div class="t-cap">Last Price</div><div style="font-size:16px;font-weight:700;color:var(--accent)">${fmt(last)}</div></div>`;
    }
    html += '</div>';
  }

  if (l.listing_broker) {
    html += `<div style="font-size:12px;margin-bottom:2px"><span class="t-muted3">Broker:</span> <span class="t-body">${esc(l.listing_broker)}</span></div>`;
  }

  // OM artifact icon — surface the staged OM PDF on the property detail
  // page so it's reachable without going to the Sales/Available view.
  // Same buildCollateralIcons() helper as dialysis.js uses, only fires
  // when the listing has an intake_artifact_path populated.
  if (l.intake_artifact_path && typeof buildCollateralIcons === 'function') {
    html += '<div style="margin-top:8px;display:flex;gap:6px;align-items:center">';
    html += '<span style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:0.5px">Marketing:</span>';
    html += buildCollateralIcons(l, {
      pdf:            'intake_artifact_path',
      pdfType:        'intake_artifact_type',
      primaryUrl:     'url',
      extraUrlFields: ['listing_url'],
    });
    html += '</div>';
  }

  // Notes (Tier 6 dedup applies for the Deal History timeline; harmless
  // pass-through on the Sales tab where _dhNotesDup is empty).
  html += _dhRenderNotesOrDup(l);

  return html;
}

function _salesRenderSale(s) {
  let html = '';

  const txnType = s.transaction_type ? String(s.transaction_type) : 'Sale';
  const isExcluded = s.exclude_from_market_metrics === true;
  const price = s.price != null ? s.price : (s.sold_price != null ? s.sold_price : s.sale_price);

  html += '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;gap:8px;flex-wrap:wrap">';
  html += `<div style="display:flex;gap:6px;flex-wrap:wrap">`;
  html += `<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:var(--green);padding:2px 8px;border-radius:10px;background:rgba(255,255,255,0.04);border:1px solid var(--green)">${esc(txnType)}</span>`;
  if (isExcluded) {
    html += `<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:var(--text3);padding:2px 8px;border-radius:10px;background:rgba(255,255,255,0.04);border:1px solid var(--text3)">Excluded</span>`;
  }
  html += `</div>`;
  if (s.sale_date) {
    html += `<span class="t-meta3">${esc(_fmtDate(s.sale_date))}</span>`;
  }
  html += '</div>';

  if (price != null) {
    html += `<div style="font-size:18px;font-weight:700;color:var(--green);margin-bottom:6px">${fmt(price)}</div>`;
  }

  const metrics = [];
  const _bestCap = s.stated_cap_rate || s.calculated_cap_rate || s.cap_rate || null;
  if (_bestCap != null) metrics.push(`${_fmtCapRate(_bestCap) || '—'} Cap`);
  if (s.price_psf != null) metrics.push(`$${Number(s.price_psf).toFixed(0)}/SF`);
  if (metrics.length) {
    html += `<div style="font-size:13px;color:var(--text2);margin-bottom:8px">${esc(metrics.join(' · '))}</div>`;
  }

  const buyer = s.buyer_name || s.buyer;
  const seller = s.seller_name || s.seller;
  const broker = s.broker_name || s.listing_broker;
  const procBroker = s.procuring_broker || null;
  if (buyer)  html += `<div style="font-size:12px;margin-bottom:2px"><span class="t-muted3">Buyer:</span> <span class="t-body">${esc(buyer)}</span></div>`;
  if (seller) html += `<div style="font-size:12px;margin-bottom:2px"><span class="t-muted3">Seller:</span> <span class="t-body">${esc(seller)}</span></div>`;
  if (broker) html += `<div style="font-size:12px;margin-bottom:2px"><span class="t-muted3">Listing Broker:</span> <span class="t-body">${esc(broker)}</span></div>`;
  if (procBroker) html += `<div style="font-size:12px;margin-bottom:2px"><span class="t-muted3">Procuring Broker:</span> <span class="t-body">${esc(procBroker)}</span></div>`;
  if (s.source) {
    html += `<div style="font-size:11px;color:var(--text3);margin-top:6px;font-style:italic">${esc(s.source)}</div>`;
  }
  // Phase 4C Unit 1 — open the actual source doc/record when one is on file.
  const _srcLink = _udSourceLink(s);
  if (_srcLink) html += `<div style="margin-top:6px">${_srcLink}</div>`;
  html += _dhRenderNotesOrDup(s);

  return html;
}

function _salesRenderCombined(l, s) {
  const initial = l.initial_price != null ? l.initial_price : l.asking_price;
  const last = l.last_price != null ? l.last_price : null;
  const soldPrice = s.price != null ? s.price : (s.sold_price != null ? s.sold_price : s.sale_price);
  const txnType = s.transaction_type ? String(s.transaction_type) : 'Sale';
  const isExcluded = s.exclude_from_market_metrics === true;
  const autoClosed = _salesListingAutoClosedAgainstPriorSale(l);

  let html = '';

  // Header: Sold badge + transaction type + excluded tag + sale date
  html += '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;gap:8px;flex-wrap:wrap">';
  html += `<div style="display:flex;gap:6px;flex-wrap:wrap">`;
  html += `<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:var(--green);padding:2px 8px;border-radius:10px;background:rgba(255,255,255,0.04);border:1px solid var(--green)">Sold</span>`;
  if (txnType && txnType.toLowerCase() !== 'sale') {
    html += `<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:var(--text2);padding:2px 8px;border-radius:10px;background:rgba(255,255,255,0.04);border:1px solid var(--border)">${esc(txnType)}</span>`;
  }
  if (isExcluded) {
    html += `<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:var(--text3);padding:2px 8px;border-radius:10px;background:rgba(255,255,255,0.04);border:1px solid var(--text3)">Excluded</span>`;
  }
  if (autoClosed) {
    html += `<span style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;color:var(--yellow);padding:2px 8px;border-radius:10px;background:rgba(255,255,255,0.04);border:1px solid var(--yellow)" title="The 76eg trigger auto-closed this listing against a sale that was already recorded. The listing was created after the sale closed (re-ingestion artifact).">Auto-matched</span>`;
  }
  html += '</div>';
  if (s.sale_date) {
    html += `<span class="t-meta3">${esc(_fmtDate(s.sale_date))}</span>`;
  }
  html += '</div>';

  // Narrative line. For auto-closed listings (sale predates listing — created
  // by the 76eg trigger when a re-ingested listing matched a pre-existing
  // sale), the "Listed X → Sold Y" arrow reads backwards. Render an honest
  // line instead.
  const _bestCap2 = s.stated_cap_rate || s.calculated_cap_rate || s.cap_rate || null;
  if (autoClosed) {
    let line = '<span class="t-muted2">Sale recorded';
    if (s.sale_date) line += ` ${esc(_fmtDate(s.sale_date))}`;
    if (soldPrice != null) line += ` at <span style="color:var(--green);font-weight:600">${fmt(soldPrice)}</span>`;
    if (_bestCap2 != null) line += ` <span class="t-muted3">/</span> <span style="color:var(--green);font-weight:600">${_fmtCapRate(_bestCap2)} Cap</span>`;
    line += '</span>';
    html += `<div style="font-size:13px;margin-bottom:6px;line-height:1.7">${line}</div>`;
    if (l.listing_date) {
      html += `<div style="font-size:11px;color:var(--text3);margin-bottom:10px;font-style:italic">Listing record arrived later (${esc(_fmtDate(l.listing_date))}) and was auto-matched to this sale.</div>`;
    }
  } else {
    // Normal "Listed → [price] → Sold [date] at [price]/[cap rate]"
    const parts = [];
    if (l.listing_date) {
      parts.push(`<span class="t-muted2">Listed ${esc(_fmtDate(l.listing_date))}</span>`);
    } else {
      parts.push(`<span class="t-muted2">Listed</span>`);
    }
    if (initial != null) {
      parts.push(`<span style="color:var(--accent);font-weight:600">${fmt(initial)}</span>`);
    }
    if (last != null && Number(last) !== Number(initial) && (soldPrice == null || Math.abs(Number(last) - Number(soldPrice)) > 1)) {
      parts.push(`<span style="color:var(--accent);font-weight:600">${fmt(last)}</span>`);
    }
    const soldBits = ['Sold'];
    if (s.sale_date) soldBits.push(esc(_fmtDate(s.sale_date)));
    let soldTail = soldBits.join(' ');
    if (soldPrice != null) soldTail += ` at ${fmt(soldPrice)}`;
    if (_bestCap2 != null) soldTail += ` / ${_fmtCapRate(_bestCap2)} Cap`;
    parts.push(`<span style="color:var(--green);font-weight:600">${soldTail}</span>`);

    html += `<div style="font-size:13px;margin-bottom:10px;line-height:1.7">${parts.join(' <span class="t-muted3">→</span> ')}</div>`;
  }

  // Price grid — suppress "Final Ask" if it equals sold price (CoStar last_price = sold price, not last asking)
  const showFinalAsk = last != null && Number(last) !== Number(initial) && (soldPrice == null || Math.abs(Number(last) - Number(soldPrice)) > 1);
  html += '<div style="display:flex;gap:16px;margin-bottom:8px;flex-wrap:wrap">';
  if (initial != null) {
    html += `<div><div class="t-cap">Original Ask</div><div style="font-size:14px;font-weight:600;color:var(--text)">${fmt(initial)}</div></div>`;
  }
  if (showFinalAsk) {
    html += `<div><div class="t-cap">Final Ask</div><div style="font-size:14px;font-weight:600;color:var(--text)">${fmt(last)}</div></div>`;
  }
  if (soldPrice != null) {
    html += `<div><div class="t-cap">Sold Price</div><div style="font-size:16px;font-weight:700;color:var(--green)">${fmt(soldPrice)}</div></div>`;
  }
  if (_bestCap2 != null) {
    const _capSrc2 = s.stated_cap_rate ? ' (stated)' : (s.calculated_cap_rate ? ' (calc)' : '');
    html += `<div><div class="t-cap">Cap Rate</div><div style="font-size:14px;font-weight:600;color:var(--text)">${_fmtCapRate(_bestCap2)}${_capSrc2 ? '<span style="font-size:9px;color:var(--text3)">' + _capSrc2 + '</span>' : ''}</div></div>`;
  }
  html += '</div>';

  // Dates row (on/off market). Suppress entirely for auto-closed listings —
  // off_market_date is just a back-stamp of sale_date (already in the header)
  // and listing_date is already shown in the italic "arrived later" line, so
  // re-rendering both produces the misleading "Listed May 6 / Off Market May 5"
  // inversion the trigger creates.
  if (!autoClosed) {
    const dateBits = [];
    if (l.listing_date) dateBits.push(`<span class="t-muted3">On Market:</span> <span class="t-body">${esc(_fmtDate(l.listing_date))}</span>`);
    if (l.off_market_date) dateBits.push(`<span class="t-muted3">Off Market:</span> <span class="t-body">${esc(_fmtDate(l.off_market_date))}</span>`);
    if (dateBits.length) {
      html += `<div style="font-size:12px;margin-bottom:6px;display:flex;gap:14px;flex-wrap:wrap">${dateBits.join('')}</div>`;
    }
  }

  // Parties
  const buyer = s.buyer_name || s.buyer;
  const seller = s.seller_name || s.seller;
  if (buyer) {
    html += `<div style="font-size:12px;margin-bottom:2px"><span class="t-muted3">Buyer:</span> <span class="t-body">${esc(buyer)}</span></div>`;
  }
  if (seller) {
    html += `<div style="font-size:12px;margin-bottom:2px"><span class="t-muted3">Seller:</span> <span class="t-body">${esc(seller)}</span></div>`;
  }

  // Broker: prefer sale record, fall back to listing
  const broker = s.broker_name || s.listing_broker || l.listing_broker;
  const procBroker2 = s.procuring_broker || null;
  if (broker) {
    html += `<div style="font-size:12px;margin-bottom:2px"><span class="t-muted3">Listing Broker:</span> <span class="t-body">${esc(broker)}</span></div>`;
  }
  if (procBroker2) {
    html += `<div style="font-size:12px;margin-bottom:2px"><span class="t-muted3">Procuring Broker:</span> <span class="t-body">${esc(procBroker2)}</span></div>`;
  }

  if (s.source) {
    html += `<div style="font-size:11px;color:var(--text3);margin-top:6px;font-style:italic">${esc(s.source)}</div>`;
  }
  // Phase 4C Unit 1 — source doc/record from the sale, else the listing.
  const _srcLinkC = _udSourceLink(s) || _udSourceLink(l);
  if (_srcLinkC) html += `<div style="margin-top:6px">${_srcLinkC}</div>`;
  // Render sale notes (Tier 6 dedup applies). When the sale has no notes but
  // the listing does (rare on combined cards), surface those instead.
  if (s.notes) {
    html += _dhRenderNotesOrDup(s);
  } else if (l && l.notes) {
    html += _dhRenderNotesOrDup(l);
  }

  return html;
}

function _salesFormHtml() {
  return `
  <div class="detail-section" style="margin-top:12px">
    <div class="detail-section-title">Add Transaction</div>
    <div class="detail-grid" style="grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="t-meta3">Sale Date</label><input id="salesFDate" type="date" style="width:100%;padding:7px 10px;border-radius:6px;border:1px solid var(--border);background:var(--s2);color:var(--text);font-size:13px"></div>
      <div><label class="t-meta3">Sale Price ($)</label><input id="salesFPrice" type="number" placeholder="0" style="width:100%;padding:7px 10px;border-radius:6px;border:1px solid var(--border);background:var(--s2);color:var(--text);font-size:13px"></div>
      <div><label class="t-meta3">Buyer</label><input id="salesFBuyer" type="text" placeholder="Buyer name" style="width:100%;padding:7px 10px;border-radius:6px;border:1px solid var(--border);background:var(--s2);color:var(--text);font-size:13px"></div>
      <div><label class="t-meta3">Seller</label><input id="salesFSeller" type="text" placeholder="Seller name" style="width:100%;padding:7px 10px;border-radius:6px;border:1px solid var(--border);background:var(--s2);color:var(--text);font-size:13px"></div>
      <div><label class="t-meta3">Price/SF</label><input id="salesFPsf" type="number" step="0.01" placeholder="0.00" style="width:100%;padding:7px 10px;border-radius:6px;border:1px solid var(--border);background:var(--s2);color:var(--text);font-size:13px"></div>
      <div><label class="t-meta3">Cap Rate (%)</label><input id="salesFCap" type="number" step="0.01" placeholder="0.00" style="width:100%;padding:7px 10px;border-radius:6px;border:1px solid var(--border);background:var(--s2);color:var(--text);font-size:13px"></div>
      <div><label class="t-meta3">Source</label><input id="salesFSource" type="text" placeholder="CoStar, County Records, etc." style="width:100%;padding:7px 10px;border-radius:6px;border:1px solid var(--border);background:var(--s2);color:var(--text);font-size:13px"></div>
      <div style="grid-column:1/-1"><label class="t-meta3">Notes</label><textarea id="salesFNotes" rows="2" placeholder="Optional notes" style="width:100%;padding:7px 10px;border-radius:6px;border:1px solid var(--border);background:var(--s2);color:var(--text);font-size:13px;resize:vertical"></textarea></div>
    </div>
    <div style="display:flex;gap:8px;margin-top:12px;justify-content:flex-end">
      <button onclick="_salesToggleForm()" style="padding:7px 16px;border-radius:6px;font-size:12px;cursor:pointer;border:1px solid var(--border);background:var(--s2);color:var(--text)">Cancel</button>
      <button onclick="_udBtnGuard(this, _salesSaveTransaction)" style="padding:7px 16px;border-radius:6px;font-size:12px;cursor:pointer;border:none;background:var(--accent);color:#fff">Save Transaction</button>
    </div>
  </div>`;
}

function _salesToggleForm() {
  const el = document.getElementById('salesAddForm');
  if (el) el.style.display = el.style.display === 'none' ? 'block' : 'none';
}

// C1 (2026-06-06): from the Overview "no sale recorded" banner, jump to the
// Deal History tab and reveal the Add Transaction form. Deal History renders
// async, so poll briefly for the form element before showing it.
function _udAddFirstSale() {
  if (typeof switchUnifiedTab === 'function') switchUnifiedTab('Deal History');
  let tries = 0;
  const iv = setInterval(function () {
    const el = document.getElementById('salesAddForm');
    if (el) {
      el.style.display = 'block';
      try { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (_) {}
      clearInterval(iv);
    } else if (++tries > 40) {
      clearInterval(iv);
    }
  }, 75);
}
window._udAddFirstSale = _udAddFirstSale;

async function _salesSaveTransaction() {
  const propertyId = _udCache.ids?.property_id || _udCache.property?.property_id;
  if (!propertyId) { alert('No property ID — cannot save transaction.'); return; }

  const db = _udCache.db;

  // Writes land in the canonical property_sale_events table. The DB trigger
  // then flips any concurrent active listings to status='Sold' automatically,
  // so the Sales tab filter chips and Ownership History stay in sync.
  const payload = {
    property_id: String(propertyId),
    sale_date:  document.getElementById('salesFDate')?.value || null,
    price:      _dpf(document.getElementById('salesFPrice')?.value),
    cap_rate:   _dpf(document.getElementById('salesFCap')?.value),
    buyer_name: document.getElementById('salesFBuyer')?.value?.trim() || null,
    seller_name:document.getElementById('salesFSeller')?.value?.trim() || null,
    source:     document.getElementById('salesFSource')?.value?.trim() || null,
    notes:      document.getElementById('salesFNotes')?.value?.trim() || null,
  };

  const proxyBase = db === 'gov' ? '/api/gov-query' : '/api/dia-query';
  const url = `${proxyBase}?table=property_sale_events&method=POST`;
  const resp = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!resp.ok) {
    const errText = await resp.text();
    console.error('Save transaction failed:', errText);
    alert('Failed to save transaction. Check console for details.');
    return;
  }

  // Invalidate cache and reload
  _salesCache = null;
  const bodyEl = document.getElementById('detailBody');
  _udRenderSalesAsync(bodyEl);
}

// ─── DEAL HISTORY TAB ────────────────────────────────────────────────────────
// Combines the legacy Sales timeline (property_sale_events + available_listings)
// with the Ownership History chain (v_ownership_chain) into one chronological
// ribbon. Each row links out to the Owner/Tenant/Broker drawer when relevant.

async function _udRenderDealHistoryAsync(bodyEl) {
  if (!bodyEl) return;
  // Ensure sales cache is populated (reuse the existing async loader).
  const propertyId = _udCache.ids?.property_id || _udCache.property?.property_id;
  const db = _udCache.db;
  const sameSales = _salesCache && _salesCache.property_id === propertyId && _salesCache.db === db;
  if (!sameSales) {
    // _udRenderSalesAsync fetches and paints — but we want to paint ourselves.
    // Spin while it loads, then re-render.
    bodyEl.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading deal history...</p></div>';
    try {
      // Fetch by mimicking _udRenderSalesAsync's data calls, but without rendering Sales.
      const qFn = db === 'gov' ? govQuery : diaQuery;
      const propId = encodeURIComponent(propertyId || '');
      const saleRes = propertyId ? await qFn('property_sale_events', '*', {
        filter: `property_id=eq.${propId}`,
        order: 'sale_date.desc.nullslast',
        limit: 100
      }).catch(() => null) : null;
      const [listRes, txnRes] = propertyId ? await Promise.all([
        qFn('available_listings', '*', { filter: `property_id=eq.${propId}`, order: 'listing_date.desc.nullslast', limit: 50 }).catch(() => []),
        (Array.isArray(saleRes) && saleRes.length > 0) ? Promise.resolve(saleRes) : qFn('sales_transactions', '*', { filter: `property_id=eq.${propId}`, order: 'sale_date.desc.nullslast', limit: 50 }).catch(() => [])
      ]) : [[], []];
      const txnArr = Array.isArray(txnRes) ? txnRes : (txnRes && txnRes.data) || [];
      const listArr = Array.isArray(listRes) ? listRes : (listRes && listRes.data) || [];
      _salesCache = { property_id: propertyId, db, transactions: txnArr, listings: listArr };
    } catch (e) {
      console.warn('Deal History: sales fetch failed', e);
      _salesCache = { property_id: propertyId, db, transactions: [], listings: [] };
    }
  }

  bodyEl.innerHTML = _udTabDealHistory();
  _intelRenderPriorSaleSummaryAsync();
}

function _udTabDealHistory() {
  const txns = _salesCache ? (_salesCache.transactions || []) : [];
  const rawListings = _salesCache ? (_salesCache.listings || []) : [];
  const chain = _udCache?.chain || [];
  const db = _udCache?.db;
  const propertyId = _udCache?.ids?.property_id || _udCache?.property?.property_id;

  // Honor the same consolidation filters as the Sales tab: drop listings the
  // 76eg consolidation function retired (exclude_from_market_metrics=true or
  // status='superseded') so re-ingestion dupes don't pad the timeline.
  const listings = rawListings.filter((l) => {
    if (!l) return false;
    if (l.exclude_from_market_metrics === true) return false;
    return String(l.status || '').toLowerCase() !== 'superseded';
  });

  // Apply the same dedup as the Ownership/CRM tab so chain-operator relics
  // (Fresenius/DaVita CMS-chain rows tagged ownership_source='cms_operator_chain')
  // and shell-LLC duplicates collapse here too. Flag the most-recent entry as
  // currently open using the 90-day-or-NULL rule that mirrors
  // _isChainEntryCurrent on the Ownership/CRM timeline.
  const dedupedChain = _udDedupChain(chain, _udCache?.ownership);
  const _DH_NINETY_DAYS_MS = 90 * 24 * 60 * 60 * 1000;
  const _dhNowMs = Date.now();
  const _dhIsOpen = (entry, isMostRecent) => {
    if (!isMostRecent) return false;
    if (!entry.ownership_end) return true;
    const endMs = new Date(entry.ownership_end).getTime();
    if (isNaN(endMs)) return true;
    return Math.abs(_dhNowMs - endMs) <= _DH_NINETY_DAYS_MS;
  };

  // Build unified timeline
  const saleEvents = _salesBuildTimeline(listings, txns)
    .filter(ev => !(ev.sale && ev.sale.exclude_from_market_metrics === true)
              && !(ev.listing && (ev.listing.exclude_from_market_metrics === true ||
                                  String(ev.listing.status || '').toLowerCase() === 'superseded')))
    .map(ev => Object.assign({}, ev, { kind: 'sale', date: ev.sortKey }));
  const ownerEvents = dedupedChain.map((h, idx) => ({
    kind: 'ownership',
    chain: h,
    isCurrent: _dhIsOpen(h, idx === 0),
    date: _salesParseDate(h.transfer_date) || _salesParseDate(h.recording_date) || _salesParseDate(h.ownership_start) || 0,
  }));

  // Deduplicate: if a sale event and ownership event share the same date+price, merge them
  const mergedSaleEvents = [...saleEvents];
  const dedupedOwnerEvents = ownerEvents.filter(oe => {
    const oDate = oe.date;
    const oPrice = parseFloat(oe.chain?.sale_price || oe.chain?.price || 0);
    if (!oDate && !oPrice) return true; // keep if no date/price to match on
    const matchIdx = mergedSaleEvents.findIndex(se => {
      const sDate = se.date;
      const sPrice = parseFloat(se.sale?.sale_price || se.sale?.price || 0);
      // Match if dates are within 1 day and prices match (or one is zero)
      return sDate && oDate && Math.abs(sDate - oDate) < 86400000 && (oPrice === 0 || sPrice === 0 || Math.abs(oPrice - sPrice) < 1);
    });
    if (matchIdx >= 0) {
      // Merge ownership chain data into the sale event
      mergedSaleEvents[matchIdx] = Object.assign({}, mergedSaleEvents[matchIdx], { chain: oe.chain });
      return false; // remove this ownership event
    }
    return true;
  });

  // Sort chronologically oldest-first (timeline reads top-to-bottom as history)
  const events = [...mergedSaleEvents, ...dedupedOwnerEvents].sort((a, b) => (a.date || 0) - (b.date || 0));

  // Tier 6: dedup duplicate sale-notes blobs across the timeline. The same
  // listing memo (EDGE Realty / Avison Young / Cushman copy-paste) often
  // appears verbatim on multiple sale or listing cards from re-ingestion.
  // Walk events oldest-first; first occurrence renders the full notes, later
  // occurrences render a "Same notes as <origin> — collapsed" pointer.
  // _dhNotesDup is a WeakMap keyed by the sale/listing OBJECT so we don't
  // mutate the source row. Renderers read it via _dhNotesDupLabel().
  _dhNotesDup = new WeakMap();
  {
    const seen = new Map(); // normalized notes hash -> origin label string
    for (const ev of events) {
      if (ev.kind !== 'sale') continue;
      // Check the sale row first (combined cards prefer sale notes), then the
      // listing row. Either may carry the duplicate blob.
      for (const candidate of [ev.sale, ev.listing]) {
        if (!candidate || !candidate.notes) continue;
        const norm = _dhNormalizeNotes(candidate.notes);
        // Skip short notes (single-line annotations are often legitimately
        // repeated, e.g. "Refi @ 5.5%"). Threshold tuned to catch listing
        // memos, which run hundreds of characters.
        if (norm.length < 120) continue;
        if (seen.has(norm)) {
          _dhNotesDup.set(candidate, seen.get(norm));
        } else {
          seen.set(norm, _dhEventLabelForNotes(ev));
        }
      }
    }
  }

  let html = '';

  // ── PRIOR SALE SUMMARY (moved from Intel tab) ─────────────────────────────
  // Read-only summary populated async by _intelRenderPriorSaleSummaryAsync().
  if (propertyId) {
    html += '<div class="detail-section">';
    html += '<div class="detail-section-title" style="cursor:pointer;user-select:none" onclick="var _el=this.parentElement.querySelector(\'.intel-prior-sale\');if(_el)_el.style.display=_el.style.display===\'none\'?\'block\':\'none\'">Prior Sale</div>';
    html += '<div class="intel-prior-sale" style="display:block">';
    html += '<div id="intelPriorSaleSummary" style="font-size:12px;color:var(--text2)"><span class="spinner"></span> Loading latest sale\u2026</div>';
    html += '<div style="margin-top:10px;font-size:11px;color:var(--text3);font-style:italic">Sale details are managed on the Deal History tab. Use \u201c+ Add Transaction\u201d below to record a new sale.</div>';
    html += '</div></div>';
  }

  if (events.length === 0) {
    html += '<div class="detail-empty" style="text-align:center;padding:40px 20px">';
    html += '<div style="font-size:18px;margin-bottom:8px;color:var(--text2)">No deal history</div>';
    html += '<div style="font-size:13px;color:var(--text3);margin-bottom:16px">No listings, sales, or ownership transfers on record.</div>';
    if (propertyId) {
      html += `<button class="btn-accent" onclick="_salesToggleForm()" style="padding:8px 18px;border-radius:8px;font-size:13px;cursor:pointer;border:none;background:var(--accent);color:#fff">+ Add Transaction</button>`;
    }
    html += '</div>';
    html += `<div id="salesAddForm" style="display:none">${_salesFormHtml()}</div>`;
    return html;
  }

  // Filter chips
  const filter = _salesFilter || 'all';
  const filtered = events.filter(e => {
    if (filter === 'listings') return e.kind === 'sale' && !!e.listing;
    if (filter === 'sales')    return e.kind === 'sale' && !!e.sale;
    if (filter === 'ownership') return e.kind === 'ownership' || (e.kind === 'sale' && !!e.chain);
    return true;
  });

  html += '<div class="detail-section">';
  html += `<div class="detail-section-title" style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">`;
  html += `<span>Deal History</span>`;
  if (propertyId) {
    html += `<button class="btn-accent" onclick="_salesToggleForm()" style="padding:5px 14px;border-radius:6px;font-size:12px;cursor:pointer;border:none;background:var(--accent);color:#fff">+ Add</button>`;
  }
  html += '</div>';

  // Count events per filter category
  const countListings = events.filter(e => e.kind === 'sale' && !!e.listing).length;
  const countSales = events.filter(e => e.kind === 'sale' && !!e.sale).length;
  const countOwnership = events.filter(e => e.kind === 'ownership' || (e.kind === 'sale' && !!e.chain)).length;
  const chips = [
    { key: 'all',       label: 'All',       count: events.length },
    { key: 'listings',  label: 'Listings',  count: countListings },
    { key: 'sales',     label: 'Sales',     count: countSales },
    { key: 'ownership', label: 'Ownership', count: countOwnership },
  ];
  html += '<div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0 12px 0">';
  chips.forEach((c) => {
    const isActive = filter === c.key;
    const bg = isActive ? 'var(--accent)' : 'var(--s2)';
    const fg = isActive ? '#fff' : 'var(--text2)';
    const border = isActive ? 'var(--accent)' : 'var(--border)';
    html += `<button onclick="_dealHistorySetFilter('${c.key}')" style="padding:4px 12px;border-radius:14px;font-size:11px;font-weight:600;cursor:pointer;border:1px solid ${border};background:${bg};color:${fg};text-transform:uppercase;letter-spacing:0.4px">${esc(c.label)} <span style="opacity:0.7">${c.count}</span></button>`;
  });
  html += '</div>';

  // Unified timeline
  html += '<div style="position:relative;padding-left:24px">';
  html += '<div style="position:absolute;left:8px;top:4px;bottom:4px;width:2px;background:var(--border);border-radius:1px"></div>';

  filtered.forEach((ev, idx) => {
    const isFirst = idx === filtered.length - 1; // highlight most recent event (last in oldest-first order)
    let dotColor = 'var(--text3)';
    if (ev.kind === 'sale') {
      dotColor = ev.sale ? 'var(--green)' : (ev.listing && _salesListingIsActive(ev.listing) ? 'var(--accent)' : 'var(--text3)');
    } else if (ev.kind === 'ownership') {
      dotColor = '#a55eea';
    }

    html += '<div style="position:relative;margin-bottom:16px">';
    html += `<div style="position:absolute;left:-20px;top:4px;width:10px;height:10px;border-radius:50%;background:${dotColor};border:2px solid var(--bg)${isFirst ? ';box-shadow:0 0 0 3px rgba(46,204,113,0.15)' : ''}"></div>`;
    html += '<div style="background:var(--s2);border-radius:10px;padding:14px;border:1px solid var(--border)">';

    if (ev.kind === 'sale') {
      if (ev.listing && ev.sale) html += _udDealRenderCombined(ev.listing, ev.sale);
      else if (ev.sale) html += _udDealRenderSale(ev.sale);
      else if (ev.listing) html += _udDealRenderListing(ev.listing);
      // Phase 4C Unit 2 — a sale row zooms into a focused sale sub-detail
      // (parties, price, cap-rate provenance, source) on the 4A back-stack.
      if (ev.sale && db && (ev.sale.sale_id != null || ev.sale.id != null)) {
        const _sid = String(ev.sale.sale_id != null ? ev.sale.sale_id : ev.sale.id);
        const _encSid = encodeURIComponent(_sid);
        html += `<div style="margin-top:10px;text-align:right"><a href="javascript:void(0)" class="ud-zoom-link" tabindex="0" data-zoom="sale:${esc(db)}:${esc(_sid)}" onclick="openSubDetail('sale','${esc(db)}',decodeURIComponent('${_encSid}'))" style="font-size:11px;font-weight:600;color:var(--accent);text-decoration:none" title="Open sale detail">Open detail ↗</a></div>`;
      }
    } else {
      html += _udDealRenderOwnership(ev.chain, db, ev.isCurrent === true);
    }

    html += '</div></div>';
  });

  html += '</div></div>';
  html += `<div id="salesAddForm" style="display:none">${_salesFormHtml()}</div>`;
  return html;
}

function _dealHistorySetFilter(f) {
  _salesFilter = (['all', 'listings', 'sales', 'ownership'].includes(f)) ? f : 'all';
  const bodyEl = document.getElementById('detailBody');
  if (bodyEl) {
    bodyEl.innerHTML = _udTabDealHistory();
    _intelRenderPriorSaleSummaryAsync(); // re-populate Prior Sale section
  }
}
window._dealHistorySetFilter = _dealHistorySetFilter;

// Listing/sale renderers that upgrade broker/buyer/seller names to links.
function _udDealRenderListing(l) {
  let html = _salesRenderListing(l);
  if (l.listing_broker) {
    html = html.replace(
      new RegExp('(<span style="color:var\\(--text3\\)">Broker:</span> )<span style="color:var\\(--text\\)">' + _reEsc(esc(l.listing_broker)) + '</span>'),
      '$1' + _udBrokerLink(l.listing_broker, l)
    );
  }
  return html;
}

function _udDealRenderSale(s) {
  let html = _salesRenderSale(s);
  const buyer = s.buyer_name || s.buyer;
  const seller = s.seller_name || s.seller;
  const broker = s.broker_name || s.listing_broker;
  const procBroker = s.procuring_broker;
  if (buyer) {
    html = html.replace(
      new RegExp('(<span style="color:var\\(--text3\\)">Buyer:</span> )<span style="color:var\\(--text\\)">' + _reEsc(esc(buyer)) + '</span>'),
      '$1' + entityLink(buyer, 'buyer', null, _udCache?.db)
    );
  }
  if (seller) {
    html = html.replace(
      new RegExp('(<span style="color:var\\(--text3\\)">Seller:</span> )<span style="color:var\\(--text\\)">' + _reEsc(esc(seller)) + '</span>'),
      '$1' + entityLink(seller, 'seller', null, _udCache?.db)
    );
  }
  if (broker) {
    html = html.replace(
      new RegExp('(<span style="color:var\\(--text3\\)">Listing Broker:</span> )<span style="color:var\\(--text\\)">' + _reEsc(esc(broker)) + '</span>'),
      '$1' + _udBrokerLink(broker, s)
    );
  }
  if (procBroker) {
    html = html.replace(
      new RegExp('(<span style="color:var\\(--text3\\)">Procuring Broker:</span> )<span style="color:var\\(--text\\)">' + _reEsc(esc(procBroker)) + '</span>'),
      '$1' + _udBrokerLink(procBroker, s)
    );
  }
  return html;
}

function _udDealRenderCombined(l, s) {
  let html = _salesRenderCombined(l, s);
  const buyer = s.buyer_name || s.buyer;
  const seller = s.seller_name || s.seller;
  const broker = s.broker_name || s.listing_broker || l.listing_broker;
  const procBroker = s.procuring_broker;
  if (buyer) {
    html = html.replace(
      new RegExp('(<span style="color:var\\(--text3\\)">Buyer:</span> )<span style="color:var\\(--text\\)">' + _reEsc(esc(buyer)) + '</span>'),
      '$1' + entityLink(buyer, 'buyer', null, _udCache?.db)
    );
  }
  if (seller) {
    html = html.replace(
      new RegExp('(<span style="color:var\\(--text3\\)">Seller:</span> )<span style="color:var\\(--text\\)">' + _reEsc(esc(seller)) + '</span>'),
      '$1' + entityLink(seller, 'seller', null, _udCache?.db)
    );
  }
  if (broker) {
    html = html.replace(
      new RegExp('(<span style="color:var\\(--text3\\)">Listing Broker:</span> )<span style="color:var\\(--text\\)">' + _reEsc(esc(broker)) + '</span>'),
      '$1' + _udBrokerLink(broker, s)
    );
  }
  if (procBroker) {
    html = html.replace(
      new RegExp('(<span style="color:var\\(--text3\\)">Procuring Broker:</span> )<span style="color:var\\(--text\\)">' + _reEsc(esc(procBroker)) + '</span>'),
      '$1' + _udBrokerLink(procBroker, s)
    );
  }
  return html;
}

function _udDealRenderOwnership(h, db, isCurrent) {
  const ownerName = h.recorded_owner_name || h.true_owner_name || h.to_owner || h.new_owner || h.owner_name || h.buyer || '—';
  const transferDate = _fmtDate(h.transfer_date) || '—';
  // Only show "Present" when this row is genuinely the current owner. A NULL
  // ownership_end on a non-current row is unknown data, not an open tenancy —
  // rendering it as "Present" makes operator-chain relics or stale rows look
  // like the current owner. Mirrors _isChainEntryCurrent on the Ownership/CRM
  // timeline.
  let endDate;
  if (isCurrent) {
    endDate = 'Present';
  } else if (h.ownership_end) {
    endDate = _fmtDate(h.ownership_end) || 'Unknown';
  } else {
    endDate = 'Unknown';
  }
  let html = '';

  html += '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;gap:8px;flex-wrap:wrap">';
  html += '<span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:#a55eea;padding:2px 8px;border-radius:10px;background:rgba(255,255,255,0.04);border:1px solid #a55eea">Ownership</span>';
  html += `<span class="t-meta3">${esc(transferDate)} → ${esc(endDate)}</span>`;
  html += '</div>';

  html += `<div style="font-size:14px;font-weight:700;margin-bottom:6px">${_ownerLink(ownerName, _ownerCtxFromChain(h, db))}</div>`;

  if (h.true_owner_name && h.recorded_owner_name && h.true_owner_name !== h.recorded_owner_name) {
    html += `<div style="font-size:12px;color:var(--text2);margin-bottom:4px"><span class="t-muted3">True Owner:</span> ${_ownerLink(h.true_owner_name, Object.assign(_ownerCtxFromChain(h, db), { name: h.true_owner_name }))}</div>`;
  }
  if (h.from_owner || h.seller_name) html += `<div style="font-size:12px;margin-bottom:2px"><span class="t-muted3">From:</span> <span class="t-body">${esc(h.from_owner || h.seller_name)}</span></div>`;
  if (h.buyer_name && h.buyer_name !== (h.recorded_owner_name || h.true_owner_name)) html += `<div style="font-size:12px;margin-bottom:2px"><span class="t-muted3">Buyer:</span> <span class="t-body">${esc(h.buyer_name)}</span></div>`;
  if (h.sale_price) html += `<div style="font-size:12px;margin-bottom:2px"><span class="t-muted3">Sale:</span> <span class="mono" style="color:var(--green)">${fmt(h.sale_price)}</span></div>`;
  const _capVal = h.stated_cap_rate || h.calculated_cap_rate || h.cap_rate || null;
  const _capSrc = h.stated_cap_rate ? 'stated' : (h.calculated_cap_rate ? 'calc' : null);
  if (_capVal) html += `<div style="font-size:12px;margin-bottom:2px"><span class="t-muted3">Cap Rate:</span> <span class="t-body">${_fmtCapRate(_capVal)}</span>${_capSrc ? ' <span style="font-size:9px;color:var(--text3)">(' + _capSrc + ')</span>' : ''}</div>`;
  if (h.listing_broker) html += `<div style="font-size:12px;margin-bottom:2px"><span class="t-muted3">Listing Broker:</span> <span class="t-body">${esc(h.listing_broker)}</span></div>`;
  if (h.procuring_broker) html += `<div style="font-size:12px;margin-bottom:2px"><span class="t-muted3">Procuring Broker:</span> <span class="t-body">${esc(h.procuring_broker)}</span></div>`;
  if (h.ownership_type) html += `<div style="font-size:11px;color:var(--text3);margin-top:4px">Type: ${esc(h.ownership_type)}</div>`;
  if (h.ownership_source) html += `<div class="t-meta3">Source: ${esc(h.ownership_source)}</div>`;

  return html;
}

function _reEsc(s) { return String(s || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

// ─── ACTIVITY LOG TAB ────────────────────────────────────────────────────────
// Unified chronological event stream. Pulls from:
//   - v_sf_activity_feed        (SF tasks, events, emails, calls)
//   - property_sale_events      (sales)
//   - available_listings        (listing status changes)
//   - v_ownership_chain         (ownership changes)
//   - v_lease_extensions_summary (lease amendments)
//   - (best-effort) CMS survey history via property_cms_link.last_survey_date

async function _udRenderActivityLogAsync(bodyEl) {
  if (!bodyEl) return;
  bodyEl.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading activity log...</p></div>';

  const propertyId = _udCache.ids?.property_id || _udCache.property?.property_id;
  const db = _udCache.db;
  const own = _udCache.ownership || {};
  const sfAccountId = own.sf_account_id || own.sf_company_id || null;
  const sfContactId = own.sf_contact_id || own.salesforce_id || null;
  const qFn = db === 'gov' ? govQuery : diaQuery;

  const events = [];

  // Ensure sales cache populated (reuse Deal History loader).
  if (!(_salesCache && _salesCache.property_id === propertyId && _salesCache.db === db)) {
    try { await _udRenderDealHistoryAsync({ innerHTML: '' }); } catch (_) { /* ignore */ }
  }

  // 1. Sales + listing events (always present)
  (_salesCache?.transactions || []).forEach(t => {
    if (!t.sale_date) return;
    if (t.exclude_from_market_metrics === true) return; // skip excluded/duplicate sales
    events.push({
      kind: 'sale',
      date: t.sale_date,
      title: (t.transaction_type || 'Sale') + (t.price ? ' · ' + fmt(t.price) : ''),
      detail: [t.buyer_name && 'Buyer ' + t.buyer_name, t.seller_name && 'Seller ' + t.seller_name, t.broker_name && 'Broker ' + t.broker_name].filter(Boolean).join(' · '),
      color: 'var(--green)'
    });
  });
  (_salesCache?.listings || []).forEach(l => {
    if (l.listing_date) {
      events.push({
        kind: 'listing',
        date: l.listing_date,
        title: 'Listed for sale' + (l.initial_price ? ' · ' + fmt(l.initial_price) : ''),
        detail: l.listing_broker ? 'Broker ' + l.listing_broker : '',
        color: 'var(--accent)'
      });
    }
    if (l.off_market_date) {
      events.push({
        kind: 'listing_status',
        date: l.off_market_date,
        title: 'Listing off-market' + (l.status ? ' · ' + l.status : ''),
        detail: '',
        color: 'var(--yellow)'
      });
    }
  });

  // 2. Ownership chain — pass through _udDedupChain so the timeline matches
  // what the Ownership/CRM and Deal History tabs show (operator-chain shims
  // dropped, shell-LLC duplicates collapsed). Layer D (20260513120000)
  // already filters operator rows at the view; this is belt-and-suspenders
  // for the dedup of repeat-owner rows.
  _udDedupChain(_udCache.chain || [], _udCache.ownership).forEach(h => {
    events.push({
      kind: 'ownership',
      date: h.transfer_date,
      title: 'Ownership transfer to ' + (h.recorded_owner_name || h.true_owner_name || h.to_owner || h.new_owner || h.owner_name || h.buyer || 'Unknown'),
      detail: [h.from_owner && 'From ' + h.from_owner, h.sale_price && fmt(h.sale_price)].filter(Boolean).join(' · '),
      color: '#a55eea',
      ownerCtx: _ownerCtxFromChain(h, db)
    });
  });

  // 3. SF activity feed (tasks, events, emails, calls)
  try {
    let actRes = [];
    if (sfAccountId) {
      actRes = await qFn('v_sf_activity_feed', '*', { filter: 'sf_account_id=eq.' + encodeURIComponent(sfAccountId), order: 'activity_date.desc', limit: 200 });
    } else if (sfContactId) {
      actRes = await qFn('v_sf_activity_feed', '*', { filter: 'sf_contact_id=eq.' + encodeURIComponent(sfContactId), order: 'activity_date.desc', limit: 200 });
    }
    // Fallback: search by entity name if no SF IDs matched
    if ((!sfAccountId && !sfContactId) || (Array.isArray(actRes) ? actRes : (actRes && actRes.data) || []).length === 0) {
      const ownerName = own.recorded_owner_name || own.true_owner_name || own.owner_name || null;
      if (ownerName) {
        actRes = await qFn('v_sf_activity_feed', '*', { filter: 'account_name=ilike.*' + encodeURIComponent(ownerName) + '*', order: 'activity_date.desc', limit: 200 });
      }
    }
    const sfAll = Array.isArray(actRes) ? actRes : (actRes && actRes.data) || [];
    sfAll.forEach(a => {
      const feedType = (a.feed_type || a.activity_type || '').toLowerCase();
      let color = 'var(--accent)';
      if (feedType.includes('call')) color = 'var(--green)';
      else if (feedType.includes('email')) color = '#3b82f6';
      else if (feedType.includes('task')) color = 'var(--yellow)';
      events.push({
        kind: 'sf_' + (feedType || 'activity'),
        date: a.activity_date,
        title: a.subject || a.activity_type || 'Activity',
        detail: [a.feed_type, a.status, a.contact_name && 'Contact ' + a.contact_name, a.assigned_to && 'Owner ' + a.assigned_to].filter(Boolean).join(' · '),
        notes: a.notes || null,
        color
      });
    });
  } catch (e) { console.warn('Activity Log: SF feed load failed', e); }

  // 4. Lease amendments (v_lease_extensions_summary)
  try {
    if (propertyId && db === 'dia') {
      const extRes = await qFn('v_lease_extensions_summary', '*', { filter: `property_id=eq.${encodeURIComponent(propertyId)}`, limit: 50 });
      const extArr = Array.isArray(extRes) ? extRes : (extRes && extRes.data) || [];
      extArr.forEach(e => {
        if (!e.last_extension_date) return;
        events.push({
          kind: 'lease_amendment',
          date: e.last_extension_date,
          title: 'Lease amendment / extension',
          detail: (e.extension_count ? fmtN(e.extension_count) + ' extensions on file' : ''),
          color: '#8b5cf6'
        });
      });
    }
  } catch (e) { /* v_lease_extensions_summary may not be available */ }

  // 5. CMS survey (last inspection date)
  try {
    const cms = _udCache.cms?.facility || _udCache.cms || null;
    const surveyDate = cms?.last_survey_date || cms?.survey_date;
    if (surveyDate) {
      events.push({
        kind: 'cms_survey',
        date: surveyDate,
        title: 'CMS survey completed',
        detail: cms.deficiency_count != null ? fmtN(cms.deficiency_count) + ' deficiencies' : '',
        color: '#ef4444'
      });
    }
  } catch (_) {}

  // 6. LCC activity_events — OM intake, outbound calls/emails, pipeline stage
  //    advances, etc. These live in lcc_opps and are fetched via the
  //    retrieve-entity-context Copilot action (which returns
  //    recent_interactions from activity_events + memory).
  //    Scott 2026-04-23: without this the Activity Log never shows OM
  //    intake events even though intake-promoter writes one.
  try {
    const entityName =
      _udCache.property?.address ||
      _udCache.fallback?.address ||
      _udCache.entityMeta?.name ||
      null;
    if (entityName) {
      const doFetch = (typeof LCC_AUTH !== 'undefined' && LCC_AUTH.apiFetch) ? LCC_AUTH.apiFetch : fetch;
      const lccRes = await doFetch('/api/context/retrieve-entity', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          entity_name:        entityName,
          entity_type:        'property',
          window_days:        730,
          interaction_limit:  100,
        }),
      });
      if (lccRes.ok) {
        const lccData = await lccRes.json();
        const interactions = lccData?.recent_interactions || [];
        interactions.forEach(it => {
          // De-dupe against events we already emitted from _salesCache
          // (same source_type='sale'/'listing' would double up).
          const srcType = (it.source_type || it.type || '').toLowerCase();
          if (srcType === 'sale' || srcType === 'listing') return;

          const colorMap = {
            intake_om:        'var(--accent)',
            email_received:   '#3b82f6',
            email_sent:       '#3b82f6',
            call_logged:      'var(--green)',
            meeting:          '#8b5cf6',
            pipeline_advance: 'var(--yellow)',
            note:             'var(--text3)',
          };
          events.push({
            kind:   'lcc_' + (srcType || 'activity'),
            date:   it.occurred_at || it.created_at || it.date,
            title:  it.title || it.subject || it.source_type || 'LCC activity',
            detail: [
              it.summary || it.description || null,
              it.actor_name   ? 'By ' + it.actor_name   : null,
              it.source_surface ? 'Surface: ' + it.source_surface : null,
            ].filter(Boolean).join(' · '),
            color: colorMap[srcType] || 'var(--accent)',
          });
        });
      }
    }
  } catch (e) {
    console.warn('Activity Log: LCC interactions feed load failed', e);
  }

  // Sort oldest → newest (chronological)
  events.sort((a, b) => {
    const ta = Date.parse(a.date || '') || 0;
    const tb = Date.parse(b.date || '') || 0;
    return ta - tb;
  });

  bodyEl.innerHTML = _udRenderActivityLog(events);

  // Pagination: show first 30 with "Show more" button
  if (events.length > 30) {
    const timelineEl = bodyEl.querySelector('[data-activity-timeline]');
    if (timelineEl) {
      const cards = timelineEl.querySelectorAll(':scope > [data-activity-item]');
      let shown = 30;
      cards.forEach((c, i) => { if (i >= 30) c.style.display = 'none'; });
      const moreBtn = bodyEl.querySelector('[data-activity-show-more]');
      if (moreBtn) {
        moreBtn.style.display = '';
        moreBtn.onclick = () => {
          const next = Math.min(shown + 30, cards.length);
          for (let i = shown; i < next; i++) cards[i].style.display = '';
          shown = next;
          moreBtn.querySelector('span').textContent = `Show more (${cards.length - shown} remaining)`;
          if (shown >= cards.length) moreBtn.style.display = 'none';
        };
      }
    }
  }
}

function _udRenderActivityLog(events) {
  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">Activity Log <span style="font-size:11px;color:var(--text3);font-weight:400;margin-left:8px">' + events.length + ' events</span></div>';

  if (events.length === 0) {
    html += '<div class="detail-empty">No activity on record. As you log calls, send emails, list the property, or record ownership changes, they will appear here.</div>';
    html += '</div>';
    return html;
  }

  html += '<div data-activity-timeline style="position:relative;padding-left:24px">';
  html += '<div style="position:absolute;left:8px;top:4px;bottom:4px;width:2px;background:var(--border);border-radius:1px"></div>';

  events.forEach(ev => {
    html += '<div data-activity-item style="position:relative;margin-bottom:14px">';
    html += `<div style="position:absolute;left:-20px;top:4px;width:10px;height:10px;border-radius:50%;background:${ev.color};border:2px solid var(--bg)"></div>`;
    html += '<div style="background:var(--s2);border-radius:8px;padding:10px 12px;border:1px solid var(--border)">';
    html += '<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-bottom:4px">';
    html += `<span style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:${ev.color};padding:1px 6px;border-radius:10px;border:1px solid ${ev.color}">${esc((ev.kind || 'event').replace(/_/g, ' '))}</span>`;
    html += `<span class="t-meta3">${esc(_fmtDate(ev.date))}</span>`;
    html += '</div>';
    html += `<div style="font-size:13px;font-weight:600;color:var(--text)">${ev.ownerCtx ? _ownerLink(ev.title.replace(/^Ownership transfer to /, ''), ev.ownerCtx) : esc(ev.title || '')}</div>`;
    if (ev.detail) html += `<div style="font-size:12px;color:var(--text2);margin-top:2px">${esc(ev.detail)}</div>`;
    if (ev.notes) html += `<div style="font-size:11px;color:var(--text3);margin-top:4px;white-space:pre-wrap">${esc(String(ev.notes).substring(0, 240))}${ev.notes.length > 240 ? '…' : ''}</div>`;
    html += '</div></div>';
  });

  html += '</div>';
  // "Show more" button (hidden by default, activated by JS if >30 events)
  if (events.length > 30) {
    html += '<div data-activity-show-more style="text-align:center;padding:8px 0"><button class="btn btn-secondary btn-sm" style="font-size:12px;cursor:pointer"><span>Show more (' + (events.length - 30) + ' remaining)</span></button></div>';
  }
  html += '</div>';
  return html;
}

function _udTabActivityLog() {
  // Synchronous fallback — called only when navigator lacks async path.
  return '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading activity log...</p></div>';
}

// ─── HISTORY TAB (legacy, retained as fallback) ──────────────────────────────

function _udTabHistory() {
  const chain = _udCache.chain;
  const db = _udCache.db;

  if (!chain || chain.length === 0) {
    return '<div class="detail-empty">No ownership history available</div>';
  }

  let html = '<div class="detail-section">';
  html += `<div class="detail-section-title">Ownership History <span style="font-size:11px;color:var(--text3);font-weight:400;margin-left:8px">${chain.length} records</span></div>`;
  html += '<div class="detail-timeline">';

  chain.forEach((h, idx) => {
    const isFirst = idx === 0;
    const statusClass = isFirst ? 'green' : '';

    html += `<div class="detail-timeline-item ${statusClass}">`;
    html += `<div class="detail-card-date">${esc(_fmtDate(h.transfer_date) || 'Unknown date')}</div>`;

    if (db === 'gov') {
      html += `<div class="detail-card-title">${esc(h.to_owner || '—')}</div>`;
      html += '<div class="detail-card-body">';
      if (h.from_owner) html += `<span class="t-meta3-sm">From:</span> ${esc(h.from_owner)}<br>`;
      if (h.sale_price) html += `Sale: <span class="mono" style="color:var(--green)">${fmt(h.sale_price)}</span><br>`;
      if (h.cap_rate) html += `Cap Rate: ${_fmtCapRate(h.cap_rate)}<br>`;
      if (h.annual_rent) html += `Rent: ${fmt(h.annual_rent)}<br>`;
      if (h.square_feet) html += `SF: ${fmtN(h.square_feet)}<br>`;
      if (h.recorded_owner_name) html += `<span class="t-meta3-sm">Recorded:</span> ${esc(h.recorded_owner_name)}<br>`;
      if (h.true_owner_name) html += `<span class="t-meta3-sm">True Owner:</span> ${esc(h.true_owner_name)}<br>`;
      if (h.principal_names) html += `<span class="t-meta3-sm">Principals:</span> ${esc(h.principal_names)}<br>`;
      if (h.research_status) html += `<span class="detail-badge">${esc(cleanLabel(h.research_status))}</span>`;
      html += '</div>';
    } else {
      // Dia
      const ownerLabel = h.recorded_owner_name || h.true_owner_name || '—';
      html += `<div class="detail-card-title">${esc(ownerLabel)}</div>`;
      html += '<div class="detail-card-body">';
      if (h.true_owner_name && h.recorded_owner_name && h.true_owner_name !== h.recorded_owner_name) {
        html += `<span class="t-meta3-sm">True Owner:</span> ${esc(h.true_owner_name)}<br>`;
      }
      if (h.sale_price) html += `Sale: <span class="mono" style="color:var(--green)">${fmt(h.sale_price)}</span><br>`;
      if (h.cap_rate) html += `Cap Rate: ${_fmtCapRate(h.cap_rate)}<br>`;
      if (h.rent) html += `Rent: ${fmt(h.rent)}<br>`;
      if (h.ownership_type) html += `<span class="t-meta3-sm">Type:</span> ${esc(h.ownership_type)}<br>`;
      if (h.ownership_source) html += `<span class="t-meta3-sm">Source:</span> ${esc(h.ownership_source)}<br>`;
      if (h.ownership_end) html += `<span class="t-meta3-sm">End:</span> ${esc(_fmtDate(h.ownership_end))}<br>`;
      html += '</div>';
    }
    html += '</div>';
  });

  html += '</div></div>';
  return html;
}

// ============================================================================
// RESEARCH QUICK LINKS
// ============================================================================

/** State Secretary of State business entity search URLs */
const _SOS_URLS = {
  AL: 'https://arc-sos.state.al.us/cgi/corpname.mbr/output',
  AK: 'https://www.commerce.alaska.gov/cbp/main/search/entities',
  AZ: 'https://ecorp.azcc.gov/EntitySearch/Index',
  AR: 'https://www.sos.arkansas.gov/corps/search_all.php',
  CA: 'https://bizfileonline.sos.ca.gov/search/business',
  CO: 'https://www.sos.state.co.us/biz/BusinessEntityCriteriaExt.do',
  CT: 'https://service.ct.gov/business/s/onlinebusinesssearch',
  DE: 'https://icis.corp.delaware.gov/ecorp/entitysearch/namesearch.aspx',
  FL: 'https://search.sunbiz.org/Inquiry/CorporationSearch/ByName',
  GA: 'https://ecorp.sos.ga.gov/BusinessSearch',
  HI: 'https://hbe.ehawaii.gov/documents/search.html',
  ID: 'https://sosbiz.idaho.gov/search/business',
  IL: 'https://www.ilsos.gov/corporatellc/',
  IN: 'https://bsd.sos.in.gov/publicbusinesssearch',
  IA: 'https://sos.iowa.gov/search/business/(S(0))/search.aspx',
  KS: 'https://www.sos.ks.gov/business/business-entities.html',
  KY: 'https://web.sos.ky.gov/bussearchnprofile/(S(0))/search.aspx',
  LA: 'https://coraweb.sos.la.gov/commercialsearch/CommercialSearchAnon.aspx',
  ME: 'https://icrs.informe.org/nei-sos-icrs/ICRS',
  MD: 'https://egov.maryland.gov/BusinessExpress/EntitySearch',
  MA: 'https://corp.sec.state.ma.us/CorpWeb/CorpSearch/CorpSearch.aspx',
  MI: 'https://cofs.lara.state.mi.us/SearchApi/Search/Search',
  MN: 'https://mblsportal.sos.state.mn.us/Business/Search',
  MS: 'https://corp.sos.ms.gov/corp/portal/c/page/corpBusinessIdSearch/portal.aspx',
  MO: 'https://bsd.sos.mo.gov/BusinessEntity/BESearch.aspx',
  MT: 'https://biz.sosmt.gov/search',
  NE: 'https://www.nebraska.gov/sos/corp/corpsearch.cgi',
  NV: 'https://esos.nv.gov/EntitySearch/OnlineEntitySearch',
  NH: 'https://quickstart.sos.nh.gov/online/BusinessInquire',
  NJ: 'https://www.njportal.com/DOR/BusinessNameSearch',
  NM: 'https://portal.sos.state.nm.us/BFS/online/CorporationBusinessSearch',
  NY: 'https://appext20.dos.ny.gov/corp_public/CORPSEARCH.ENTITY_SEARCH_ENTRY',
  NC: 'https://www.sosnc.gov/online_services/search/by_title/_Business_Registration',
  ND: 'https://firststop.sos.nd.gov/search/business',
  OH: 'https://www.sos.state.oh.us/businesses/information-on-a-business/',
  OK: 'https://www.sos.ok.gov/corp/corpInquiryFind.aspx',
  OR: 'https://sos.oregon.gov/business/pages/find.aspx',
  PA: 'https://www.corporations.pa.gov/search/corpsearch',
  RI: 'https://business.sos.ri.gov/CorpWeb/CorpSearch/CorpSearch.aspx',
  SC: 'https://search.scsos.com/search',
  SD: 'https://sosenterprise.sd.gov/BusinessServices/Business/FilingSearch.aspx',
  TN: 'https://tnbear.tn.gov/Ecommerce/FilingSearch.aspx',
  TX: 'https://mycpa.cpa.state.tx.us/coa/coaSearchBtn',
  UT: 'https://secure.utah.gov/bes/index.html',
  VT: 'https://bizfilings.vermont.gov/online/BusinessInquire',
  VA: 'https://cis.scc.virginia.gov/EntitySearch/Index',
  WA: 'https://ccfs.sos.wa.gov/#/AdvancedSearch',
  WV: 'https://apps.wv.gov/SOS/BusinessEntity/',
  WI: 'https://www.wdfi.org/apps/CorpSearch/Search.aspx',
  WY: 'https://wyobiz.wyo.gov/Business/FilingSearch.aspx',
  DC: 'https://corponline.dcra.dc.gov/BizEntity.aspx/Search'
};

/** Full state names for display */
const _STATE_NAMES = {
  AL:'Alabama',AK:'Alaska',AZ:'Arizona',AR:'Arkansas',CA:'California',CO:'Colorado',
  CT:'Connecticut',DE:'Delaware',FL:'Florida',GA:'Georgia',HI:'Hawaii',ID:'Idaho',
  IL:'Illinois',IN:'Indiana',IA:'Iowa',KS:'Kansas',KY:'Kentucky',LA:'Louisiana',
  ME:'Maine',MD:'Maryland',MA:'Massachusetts',MI:'Michigan',MN:'Minnesota',MS:'Mississippi',
  MO:'Missouri',MT:'Montana',NE:'Nebraska',NV:'Nevada',NH:'New Hampshire',NJ:'New Jersey',
  NM:'New Mexico',NY:'New York',NC:'North Carolina',ND:'North Dakota',OH:'Ohio',OK:'Oklahoma',
  OR:'Oregon',PA:'Pennsylvania',RI:'Rhode Island',SC:'South Carolina',SD:'South Dakota',
  TN:'Tennessee',TX:'Texas',UT:'Utah',VT:'Vermont',VA:'Virginia',WA:'Washington',
  WV:'West Virginia',WI:'Wisconsin',WY:'Wyoming',DC:'District of Columbia'
};

/** Salesforce Lightning base URL */
const _SF_BASE = 'https://northmarqcapital.lightning.force.com/lightning/r';

/** Build a styled quick-link button */
function _qlBtn(label, url, icon, color) {
  if (!url) return '';
  return `<a href="${esc(url).replace(/"/g, '&quot;')}" target="_blank" rel="noopener" class="ql-btn" style="--ql-color:${color}" title="${esc(label)}">
    <span class="ql-icon">${icon}</span>
    <span class="ql-label">${esc(label)}</span>
  </a>`;
}

function _udAssistantSection(mode, title, subtitle) {
  const state = _udAssistantState[mode] || { loading: false, reply: '', error: '' };
  let body = '<div class="assistant-status">No analysis generated yet.</div>';
  if (state.loading) {
    body = '<div class="assistant-status"><span class="spinner" style="width:14px;height:14px"></span> Working...</div>';
  } else if (state.error) {
    body = `<div class="assistant-status assistant-error">${esc(state.error)}</div>`;
  } else if (state.reply) {
    body = `<div class="assistant-copy">${typeof formatCopilotText === 'function' ? formatCopilotText(state.reply) : esc(state.reply)}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
        <button class="q-action" onclick="_udActionBtnGuard(this, _udCopyAssistantReply, '${mode}')">Copy</button>
        ${mode === 'ownership' ? `<button class="q-action" onclick="_udActionBtnGuard(this, _udApplyAssistantFields, '${mode}')">Apply Extracted Facts to Fields</button>` : ''}
        ${mode === 'ownership' ? `<button class="q-action primary" onclick="_udBtnGuard(this, _udSaveReviewedOwnership)">Save Reviewed Ownership</button>` : ''}
        <button class="q-action primary" onclick="_udActionBtnGuard(this, _udApplyAssistantReply, '${mode}')">${mode === 'ownership' ? 'Apply to Ownership Notes' : 'Apply to Research Notes'}</button>
      </div>`;
  }

  return `<div class="detail-section">
    <div class="detail-section-title">${esc(title)}</div>
    <div style="font-size:12px;color:var(--text3);margin-bottom:10px">${esc(subtitle)}</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px">
      <button class="q-action primary" onclick="_udActionBtnGuard(this, _udAskAssistant, '${mode}')">Assist</button>
      <button class="q-action" onclick="_udActionBtnGuard(this, ${mode === 'ownership' ? 'openResearchInChatGPT' : 'openResearchInClaude'})">${mode === 'ownership' ? 'Export to ChatGPT' : 'Export to Claude'}</button>
    </div>
    <div id="udAssistantPanel_${mode}" class="assistant-panel">${body}</div>
  </div>`;
}

function _udBuildAssistantPrompt(mode) {
  if (!_udCache || !_udCache.property) return '';
  const p = _udCache.property || {};
  const own = _udCache.ownership || {};
  const fallback = _udCache.fallback || {};
  const ownNotes = document.getElementById('udOwnNotes')?.value?.trim() || '';
  const intelNotes = document.getElementById('intelResearchNotes')?.value?.trim() || '';

  if (mode === 'ownership') {
    return [
      'You are assisting with an ownership resolution workflow in commercial real estate.',
      'Focus on who likely owns the asset, who to contact, and what remains unresolved.',
      '',
      `Property: ${p.page_title || p.facility_name || p.address || 'Unknown property'}`,
      `Address: ${p.address || 'N/A'}, ${p.city || 'N/A'}, ${p.state || 'N/A'}`,
      `County: ${p.county || 'Unknown'}`,
      `Recorded owner: ${own.recorded_owner_canonical || own.recorded_owner || fallback.recorded_owner || 'Unknown'}`,
      `True owner: ${own.true_owner_canonical || own.true_owner || fallback.true_owner || 'Unknown'}`,
      `Owner type: ${own.owner_type || fallback.owner_type || 'Unknown'}`,
      `Contact name: ${own.contact_1_name || own.contact_name || 'Unknown'}`,
      `Contact email: ${own.contact_email || 'Unknown'}`,
      `Contact phone: ${own.contact_phone || 'Unknown'}`,
      `Research notes: ${ownNotes || 'None entered'}`,
      '',
      'Return in this format:',
      '1. Ownership summary',
      '2. Likely best contact',
      '3. Evidence and gaps',
      '4. Recommended next 3 actions',
      '5. Draft ownership note to save',
      '6. Structured ownership facts JSON',
      'For section 6, return only valid JSON inside a ```json fenced block with this shape:',
      '{',
      '  "ownership": {',
      '    "recorded_owner": "string or null",',
      '    "true_owner": "string or null",',
      '    "owner_type": "individual|llc|reit|developer|fund|operator|other|null",',
      '    "contact_name": "string or null",',
      '    "contact_phone": "string or null",',
      '    "contact_email": "string or null",',
      '    "state_of_incorporation": "string or null"',
      '  }',
      '}',
    ].join('\n');
  }

  return [
    'You are assisting with a property research workflow in commercial real estate.',
    'Use the current property context and notes to produce a concise analyst update.',
    '',
    `Property: ${p.page_title || p.facility_name || p.address || 'Unknown property'}`,
    `Address: ${p.address || 'N/A'}, ${p.city || 'N/A'}, ${p.state || 'N/A'}`,
    `Domain: ${_udCache.db || 'unknown'}`,
    `Lease number: ${p.lease_number || fallback.lease_number || 'Unknown'}`,
    `Estimated value: ${p.estimated_value || 'Unknown'}`,
    `Current notes: ${intelNotes || 'None entered'}`,
    '',
    'Return in this format:',
    '1. Executive summary',
    '2. Key facts captured',
    '3. Missing facts still needed',
    '4. Recommended next 3 actions',
    '5. Draft research note to save',
  ].join('\n');
}

function _udRenderAssistantState(mode) {
  const panel = document.getElementById(`udAssistantPanel_${mode}`);
  if (!panel) return;
  const state = _udAssistantState[mode] || { loading: false, reply: '', error: '' };
  if (state.loading) {
    panel.innerHTML = '<div class="assistant-status"><span class="spinner" style="width:14px;height:14px"></span> Working...</div>';
    return;
  }
  if (state.error) {
    panel.innerHTML = `<div class="assistant-status assistant-error">${esc(state.error)}</div>`;
    return;
  }
  if (state.reply) {
    panel.innerHTML = `<div class="assistant-copy">${typeof formatCopilotText === 'function' ? formatCopilotText(state.reply) : esc(state.reply)}</div>`;
    return;
  }
  panel.innerHTML = '<div class="assistant-status">No analysis generated yet.</div>';
}

function _udResearchIntakeSection() {
  const intake = _udIntakeState || {};
  const meta = [intake.fileName, intake.fileType].filter(Boolean).join(' • ');
  return `<div class="detail-section">
    <div class="detail-section-title">Research Intake</div>
    <div style="font-size:12px;color:var(--text3);margin-bottom:10px">Paste copied research text or load a text-based file, then generate a clean analyst readout before saving notes.</div>
    <div class="intake-box">
      <div class="intake-meta">${esc(meta || 'No file loaded. Text-based files can be read locally in-browser.')}</div>
      ${intake.notice ? `<div class="intake-notice">${esc(intake.notice)}</div>` : ''}
      <input type="file" accept=".txt,.md,.csv,.json,.log,.html,.htm,.xml,.yaml,.yml,.rtf,.pdf,image/*" onchange="_intelHandleIntakeFile(this)" style="width:100%;margin-bottom:10px">
      ${intake.imageDataUrl ? `<div class="intake-preview"><img src="${esc(intake.imageDataUrl)}" alt="Research intake screenshot preview"></div>` : ''}
      <textarea id="intelIntakeText" rows="8" placeholder="Paste copied text, OCR output, broker notes, call notes, listing text, or extracted document text. You can also paste a screenshot directly into this box." oninput="_intelUpdateIntakeText(this.value)" onpaste="_intelHandleIntakePaste(event)" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid var(--border);border-radius:6px;background:var(--s2);color:var(--text);resize:vertical;font-family:inherit;box-sizing:border-box">${esc(intake.text || '')}</textarea>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
        <button class="q-action primary" onclick="_intelAnalyzeIntake()"${intake.loading ? ' disabled style="opacity:0.6"' : ''}>
          ${intake.loading ? '<span class="spinner" style="width:12px;height:12px;margin-right:4px"></span>Analyzing\u2026' : 'Analyze Intake'}
        </button>
        <button class="q-action" onclick="_intelClearIntake()"${intake.loading ? ' disabled' : ''}>Clear</button>
      </div>
    </div>
    ${_intelRenderIntakeAnalysis()}
  </div>`;
}

function _intelRenderIntakeAnalysis() {
  const intake = _udIntakeState || {};
  let body = '<div class="assistant-status">No intake analysis generated yet.</div>';
  if (intake.loading) {
    body = '<div class="assistant-status"><span class="spinner" style="width:14px;height:14px"></span> Working...</div>';
  } else if (intake.error) {
    body = `<div class="assistant-status assistant-error">${esc(intake.error)}</div>`;
  } else if (intake.analysis) {
    body = `<div class="assistant-copy">${typeof formatCopilotText === 'function' ? formatCopilotText(intake.analysis) : esc(intake.analysis)}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
        <button class="q-action" onclick="_udActionBtnGuard(this, _intelCopyIntakeAnalysis)">Copy</button>
        <button class="q-action" onclick="_udActionBtnGuard(this, _intelApplyIntakeFields)">Apply Extracted Facts</button>
        <button class="q-action primary" onclick="_udBtnGuard(this, _intelSaveReviewed)">Save Reviewed Intel</button>
        <button class="q-action primary" onclick="_udActionBtnGuard(this, _intelApplyIntakeAnalysis)">Apply to Notes</button>
      </div>`;
  }
  return `<div id="intelIntakeAnalysisPanel" class="assistant-panel" style="margin-top:12px">${body}</div>`;
}

function _intelUpdateIntakeText(value) {
  _udIntakeState.text = value || '';
}

function _intelReadFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result || '');
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

async function _intelHandleIntakeFile(input) {
  const file = input?.files?.[0];
  if (!file) return;

  _udIntakeState.fileName = file.name || '';
  _udIntakeState.fileType = file.type || '';
  _udIntakeState.notice = '';
  _udIntakeState.error = '';

  const lowerName = (file.name || '').toLowerCase();
  const textExtensions = ['.txt', '.md', '.csv', '.json', '.log', '.html', '.htm', '.xml', '.yaml', '.yml', '.rtf'];
  const isTextFile = textExtensions.some((ext) => lowerName.endsWith(ext)) || (file.type && file.type.startsWith('text/'));
  const isPdf = lowerName.endsWith('.pdf') || file.type === 'application/pdf';
  const isImage = (file.type || '').startsWith('image/');

  if (isPdf) {
    _udIntakeState.notice = 'This file type is not extracted in-browser yet. Paste OCR or copied text into the box below, then analyze.';
    _udIntakeState.imageDataUrl = '';
    refreshDetailPanel();
    return;
  }

  if (isImage) {
    try {
      _udIntakeState.imageDataUrl = await _intelReadFileAsDataUrl(file);
      _udIntakeState.notice = 'Screenshot loaded for review-first analysis. Add any copied text below if you want the assistant to combine both.';
      _udIntakeState.error = '';
    } catch (e) {
      _udIntakeState.imageDataUrl = '';
      _udIntakeState.error = `Could not read ${file.name}: ${e.message}`;
    }
    refreshDetailPanel();
    return;
  }

  if (!isTextFile) {
    _udIntakeState.notice = 'This file type is not supported for local extraction yet. Paste copied text into the box below to continue.';
    _udIntakeState.imageDataUrl = '';
    refreshDetailPanel();
    return;
  }

  try {
    _udIntakeState.text = await file.text();
    _udIntakeState.notice = `Loaded ${file.name} for local review.`;
    _udIntakeState.imageDataUrl = '';
  } catch (e) {
    _udIntakeState.notice = '';
    _udIntakeState.error = `Could not read ${file.name}: ${e.message}`;
  }

  refreshDetailPanel();
}

async function _intelHandleIntakePaste(event) {
  const items = Array.from(event?.clipboardData?.items || []);
  const imageItem = items.find((item) => item.type && item.type.startsWith('image/'));
  if (!imageItem) return;

  const file = imageItem.getAsFile();
  if (!file) return;
  event.preventDefault();

  _udIntakeState.fileName = file.name || 'clipboard-image.png';
  _udIntakeState.fileType = file.type || 'image/png';
  _udIntakeState.error = '';

  try {
    _udIntakeState.imageDataUrl = await _intelReadFileAsDataUrl(file);
    _udIntakeState.notice = 'Pasted screenshot loaded for review-first analysis. Add copied text below if you want the assistant to combine both.';
  } catch (e) {
    _udIntakeState.imageDataUrl = '';
    _udIntakeState.error = `Could not read pasted screenshot: ${e.message}`;
  }

  refreshDetailPanel();
}

function _intelBuildIntakePrompt() {
  if (!_udCache?.property) return '';
  const p = _udCache.property || {};
  const fallback = _udCache.fallback || {};
  const intakeText = (_udIntakeState.text || '').trim();
  const hasImage = !!_udIntakeState.imageDataUrl;
  if (!intakeText && !hasImage) return '';

  return [
    'You are assisting with a research intake workflow in commercial real estate.',
    'Review the provided intake material and turn it into a concise analyst-ready output.',
    'Do not invent facts. Call out uncertainty clearly.',
    '',
    `Property: ${p.page_title || p.facility_name || p.address || 'Unknown property'}`,
    `Address: ${p.address || 'N/A'}, ${p.city || 'N/A'}, ${p.state || 'N/A'}`,
    `Domain: ${_udCache.db || 'unknown'}`,
    `Lease number: ${p.lease_number || fallback.lease_number || 'Unknown'}`,
    `Loaded file: ${_udIntakeState.fileName || 'None'}`,
    `Screenshot attached: ${hasImage ? 'Yes' : 'No'}`,
    '',
    hasImage ? 'A screenshot is attached. Use it as a review artifact, but note any ambiguity caused by image quality or missing context.' : '',
    intakeText ? 'Intake material:' : '',
    intakeText || '',
    '',
    'Return in this format:',
    '1. Executive summary',
    '2. Key extracted facts',
    '3. Potentially unreliable or unclear items',
    '4. Recommended next 3 actions',
    '5. Draft research note to save',
    '6. Structured facts JSON',
    'For section 6, return only valid JSON inside a ```json fenced block with this shape:',
    '{',
    '  "prior_sale": {',
    '    "sale_date": "YYYY-MM-DD or null",',
    '    "sale_price": number or null,',
    '    "cap_rate_sale": number or null,',
    '    "buyer": "string or null",',
    '    "seller": "string or null"',
    '  },',
    '  "loan": {',
    '    "lender": "string or null",',
    '    "loan_amount": number or null,',
    '    "interest_rate": number or null,',
    '    "loan_type": "Fixed|Variable|Bridge|CMBS|Agency|Other|null",',
    '    "origination_date": "YYYY-MM-DD or null",',
    '    "maturity_date": "YYYY-MM-DD or null",',
    '    "amortization_years": integer or null,',
    '    "recourse": "Recourse|Non-Recourse|Partial|null",',
    '    "ltv": number or null',
    '  },',
    '  "cash_flow": {',
    '    "annual_rent": number or null,',
    '    "rent_per_sf": number or null,',
    '    "expense_type": "string or null",',
    '    "estimated_value": number or null,',
    '    "current_cap_rate": number or null',
    '  }',
    '}',
  ].join('\n');
}

async function _intelAnalyzeIntake() {
  const prompt = _intelBuildIntakePrompt();
  if (!prompt) {
    showToast('Add intake text before analyzing', 'error');
    return;
  }

  _udIntakeState.loading = true;
  _udIntakeState.analysis = '';
  _udIntakeState.error = '';
  refreshDetailPanel();

  try {
    const reply = await invokeLccAssistant({
      message: prompt,
      context: {
        feature: 'detail_intake_assistant',
        property_id: _udCache.ids?.property_id || null,
        lease_number: _udCache.ids?.lease_number || null,
        domain: _udCache.db || null,
        file_name: _udIntakeState.fileName || null,
      },
      attachments: _udIntakeState.imageDataUrl ? [{
        type: 'image',
        mime_type: _udIntakeState.fileType || 'image/png',
        name: _udIntakeState.fileName || 'research-intake.png',
        data_url: _udIntakeState.imageDataUrl,
      }] : [],
      feature: 'detail_intake_assistant',
    });
    _udIntakeState.analysis = reply;
  } catch (e) {
    _udIntakeState.error = e.message;
  }

  _udIntakeState.loading = false;
  refreshDetailPanel();
}

async function _intelCopyIntakeAnalysis() {
  const analysis = _udIntakeState.analysis || '';
  if (!analysis) {
    showToast('No intake analysis to copy', 'error');
    return;
  }
  try {
    await navigator.clipboard.writeText(analysis);
    showToast('Intake analysis copied', 'success');
  } catch {
    showToast('Copy failed', 'error');
  }
}

function _intelApplyIntakeAnalysis() {
  const analysis = _udIntakeState.analysis || '';
  if (!analysis) {
    showToast('No intake analysis to apply', 'error');
    return;
  }
  const target = document.getElementById('intelResearchNotes');
  if (!target) {
    showToast('Research notes field not available', 'error');
    return;
  }
  const draft = _udExtractAssistantSection(analysis, 5) || _udExtractAssistantSection(analysis, 1) || analysis;
  target.value = [target.value?.trim(), draft].filter(Boolean).join(target.value?.trim() ? '\n\n' : '');
  _udFormDirty = true;
  showToast('Research notes updated from intake analysis', 'success');
}

function _intelExtractStructuredFacts(text) {
  if (!text) return null;
  const fenced = text.match(/```json\s*([\s\S]*?)```/i);
  const raw = fenced?.[1]?.trim();
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function _intelSetFieldValue(id, value) {
  if (value === null || value === undefined || value === '') return false;
  const el = document.getElementById(id);
  if (!el) return false;
  el.value = String(value);
  return true;
}

function _intelApplyIntakeFields() {
  const analysis = _udIntakeState.analysis || '';
  if (!analysis) {
    showToast('No intake analysis to apply', 'error');
    return;
  }

  const facts = _intelExtractStructuredFacts(analysis);
  if (!facts) {
    showToast('No structured facts found in intake analysis', 'error');
    return;
  }

  let updated = 0;
  const priorSale = facts.prior_sale || {};
  const loan = facts.loan || {};
  const cashFlow = facts.cash_flow || {};

  updated += _intelSetFieldValue('intelSaleDate', priorSale.sale_date) ? 1 : 0;
  updated += _intelSetFieldValue('intelSalePrice', priorSale.sale_price) ? 1 : 0;
  updated += _intelSetFieldValue('intelCapRateSale', priorSale.cap_rate_sale) ? 1 : 0;
  updated += _intelSetFieldValue('intelBuyer', priorSale.buyer) ? 1 : 0;
  updated += _intelSetFieldValue('intelSeller', priorSale.seller) ? 1 : 0;

  updated += _intelSetFieldValue('intelLender', loan.lender) ? 1 : 0;
  updated += _intelSetFieldValue('intelLoanAmount', loan.loan_amount) ? 1 : 0;
  updated += _intelSetFieldValue('intelInterestRate', loan.interest_rate) ? 1 : 0;
  updated += _intelSetFieldValue('intelLoanType', loan.loan_type) ? 1 : 0;
  updated += _intelSetFieldValue('intelOrigDate', loan.origination_date) ? 1 : 0;
  updated += _intelSetFieldValue('intelMatDate', loan.maturity_date) ? 1 : 0;
  updated += _intelSetFieldValue('intelAmortization', loan.amortization_years) ? 1 : 0;
  updated += _intelSetFieldValue('intelRecourse', loan.recourse) ? 1 : 0;
  updated += _intelSetFieldValue('intelLTV', loan.ltv) ? 1 : 0;

  updated += _intelSetFieldValue('intelAnnualRent', cashFlow.annual_rent) ? 1 : 0;
  updated += _intelSetFieldValue('intelRentPerSF', cashFlow.rent_per_sf) ? 1 : 0;
  updated += _intelSetFieldValue('intelExpenseType', cashFlow.expense_type) ? 1 : 0;
  updated += _intelSetFieldValue('intelEstValue', cashFlow.estimated_value) ? 1 : 0;
  updated += _intelSetFieldValue('intelCurrentCapRate', cashFlow.current_cap_rate) ? 1 : 0;

  if (!updated) {
    showToast('Structured facts were present but no fields were populated', 'error');
    return;
  }

  _udFormDirty = true;
  showToast(`Applied ${updated} extracted field${updated === 1 ? '' : 's'} for review`, 'success');
}

function _intelClearIntake() {
  _udIntakeState = {
    fileName: '',
    fileType: '',
    notice: '',
    text: '',
    imageDataUrl: '',
    loading: false,
    analysis: '',
    error: '',
  };
  refreshDetailPanel();
}

function _udExtractAssistantSection(text, headingNumber) {
  if (!text) return '';
  const pattern = new RegExp(`(?:^|\\n)${headingNumber}\\.\\s+[^\\n]*\\n([\\s\\S]*?)(?=\\n\\d+\\.\\s+|$)`, 'i');
  const match = text.match(pattern);
  return (match?.[1] || '').trim();
}

function _udExtractStructuredFacts(text) {
  if (!text) return null;
  const fenced = text.match(/```json\s*([\s\S]*?)```/i);
  const raw = fenced?.[1]?.trim();
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function _udSetFieldValue(id, value) {
  if (value === null || value === undefined || value === '') return false;
  const el = document.getElementById(id);
  if (!el) return false;
  el.value = String(value);
  return true;
}

async function _udAskAssistant(mode) {
  // Guard against double-submit while request is in flight
  if (_udAssistantState[mode]?.loading) return;

  const prompt = _udBuildAssistantPrompt(mode);
  if (!prompt) {
    showToast('No record loaded', 'error');
    return;
  }

  _udAssistantState[mode] = { loading: true, reply: '', error: '' };
  _udRenderAssistantState(mode);

  try {
    const reply = await invokeLccAssistant({
      message: prompt,
      context: {
        feature: mode === 'ownership' ? 'detail_ownership_assistant' : 'detail_intel_assistant',
        property_id: _udCache.ids?.property_id || null,
        lease_number: _udCache.ids?.lease_number || null,
        domain: _udCache.db || null,
      },
      feature: mode === 'ownership' ? 'detail_ownership_assistant' : 'detail_intel_assistant',
    });
    _udAssistantState[mode] = { loading: false, reply, error: '' };
  } catch (e) {
    _udAssistantState[mode] = { loading: false, reply: '', error: e.message };
  }

  _udRenderAssistantState(mode);
}

async function _udCopyAssistantReply(mode) {
  const reply = _udAssistantState[mode]?.reply || '';
  if (!reply) {
    showToast('No assistant reply to copy', 'error');
    return;
  }
  try {
    await navigator.clipboard.writeText(reply);
    showToast('Assistant reply copied', 'success');
  } catch {
    showToast('Copy failed', 'error');
  }
}

function _udApplyAssistantReply(mode) {
  const reply = _udAssistantState[mode]?.reply || '';
  if (!reply) {
    showToast('No assistant reply to apply', 'error');
    return;
  }

  const draft = _udExtractAssistantSection(reply, 5) || _udExtractAssistantSection(reply, 1) || reply;
  if (mode === 'ownership') {
    const target = document.getElementById('udOwnNotes');
    if (!target) {
      showToast('Ownership notes field not available', 'error');
      return;
    }
    target.value = [target.value?.trim(), draft].filter(Boolean).join(target.value?.trim() ? '\n\n' : '');
    showToast('Ownership notes updated from assistant', 'success');
    return;
  }

  const target = document.getElementById('intelResearchNotes');
  if (!target) {
    showToast('Research notes field not available', 'error');
    return;
  }
  target.value = [target.value?.trim(), draft].filter(Boolean).join(target.value?.trim() ? '\n\n' : '');
  showToast('Research notes updated from assistant', 'success');
}

function _udApplyAssistantFields(mode) {
  const reply = _udAssistantState[mode]?.reply || '';
  if (!reply) {
    showToast('No assistant reply to apply', 'error');
    return;
  }

  const facts = _udExtractStructuredFacts(reply);
  if (!facts) {
    showToast('No structured facts found in assistant reply', 'error');
    return;
  }

  if (mode !== 'ownership') {
    showToast('Structured field apply is not configured for this workflow', 'error');
    return;
  }

  const ownership = facts.ownership || {};
  let updated = 0;
  updated += _udSetFieldValue('udOwnRecorded', ownership.recorded_owner) ? 1 : 0;
  updated += _udSetFieldValue('udOwnTrue', ownership.true_owner) ? 1 : 0;
  updated += _udSetFieldValue('udOwnType', ownership.owner_type) ? 1 : 0;
  updated += _udSetFieldValue('udOwnContact', ownership.contact_name) ? 1 : 0;
  updated += _udSetFieldValue('udOwnPhone', ownership.contact_phone) ? 1 : 0;
  updated += _udSetFieldValue('udOwnEmail', ownership.contact_email) ? 1 : 0;
  updated += _udSetFieldValue('udOwnState', ownership.state_of_incorporation) ? 1 : 0;

  if (!updated) {
    showToast('Structured facts were present but no fields were populated', 'error');
    return;
  }

  showToast(`Applied ${updated} ownership field${updated === 1 ? '' : 's'} for review`, 'success');
}

function _qlActionBtn(label, onclick, icon, color) {
  if (!onclick) return '';
  return `<button type="button" class="ql-btn" style="--ql-color:${color};cursor:pointer" title="${esc(label)}" onclick="${esc(onclick)}">
    <span class="ql-icon">${icon}</span>
    <span class="ql-label">${esc(label)}</span>
  </button>`;
}

/** Research Quick Links — property-level research shortcuts */
/** Action buttons for advancing records through the pipeline */
function _udActionButtons() {
  if (!_udCache) return '';
  const db = _udCache.db;
  const fb = _udCache.fallback || {};
  const p = _udCache.property || {};

  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">Actions</div>';
  html += '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:8px">';

  if (db === 'gov') {
    html += `<button class="q-action primary" onclick="_udActionBtnGuard(this, _udAction, 'add_to_pipeline')" style="padding:8px 16px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer">Add to Pipeline</button>`;
    html += `<button class="q-action" onclick="_udActionBtnGuard(this, _udAction, 'log_touchpoint')" style="padding:8px 16px;border-radius:8px;font-size:12px;cursor:pointer">Log Touchpoint</button>`;
    html += `<button class="q-action" onclick="_udActionBtnGuard(this, _udAction, 'create_task')" style="padding:8px 16px;border-radius:8px;font-size:12px;cursor:pointer">Create Task</button>`;
  } else if (db === 'dia') {
    html += `<button class="q-action primary" onclick="_udActionBtnGuard(this, _udAction, 'mark_lead')" style="padding:8px 16px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer">Mark as Lead</button>`;
    html += `<button class="q-action" onclick="_udActionBtnGuard(this, _udAction, 'add_to_pipeline')" style="padding:8px 16px;border-radius:8px;font-size:12px;cursor:pointer">Add to Pipeline</button>`;
    html += `<button class="q-action" onclick="_udActionBtnGuard(this, _udAction, 'log_touchpoint')" style="padding:8px 16px;border-radius:8px;font-size:12px;cursor:pointer">Log Touchpoint</button>`;
    html += `<button class="q-action" onclick="_udActionBtnGuard(this, _udAction, 'create_task')" style="padding:8px 16px;border-radius:8px;font-size:12px;cursor:pointer">Create Task</button>`;
  }

  html += '</div></div>';
  return html;
}

async function _udAction(action) {
  if (!_udCache) return;
  const db = _udCache.db;
  const fb = _udCache.fallback || {};
  const p = _udCache.property || {};
  const id = p.property_id || fb.property_id || fb.clinic_id || fb.lead_id || fb.id;
  const title = p.page_title || p.facility_name || fb.tenant_operator || fb.tenant_agency || fb.facility_name || fb.address || 'Unknown';

  if (action === 'add_to_pipeline' && db === 'gov') {
    try {
      const headers = { 'Content-Type': 'application/json' };
      if (typeof LCC_USER !== 'undefined' && LCC_USER.workspace_id) headers['x-lcc-workspace'] = LCC_USER.workspace_id;
      const res = await fetch('/api/gov-write?endpoint=lead-research', {
        method: 'POST', headers,
        body: JSON.stringify({ property_id: id, pipeline_status: 'prospect', address: p.address || fb.address, source_app: 'lcc' })
      });
      if (res.ok) { showToast('Added to pipeline!', 'success'); return; }
      const err = await res.json().catch(() => ({}));
      showToast('Could not add: ' + (err.error || res.status), 'error');
    } catch (e) { showToast('Error: ' + e.message, 'error'); }
    return;
  }

  if (action === 'mark_lead' && db === 'dia') {
    try {
      const qFn = typeof diaQuery === 'function' ? diaQuery : null;
      if (!qFn) { showToast('Dialysis query not available', 'error'); return; }
      await qFn('research_queue_outcomes', null, {
        method: 'POST',
        body: { clinic_id: fb.clinic_id || fb.medicare_id, queue_type: 'lead', status: 'prospect', source_bucket: 'manual', notes: 'Marked as lead from detail panel' }
      });
      showToast('Marked as lead!', 'success');
    } catch (e) { showToast('Error: ' + e.message, 'error'); }
    return;
  }

  if (action === 'log_touchpoint') {
    const notes = await lccPrompt('Touchpoint notes:');
    if (!notes) return;
    try {
      const headers = { 'Content-Type': 'application/json' };
      if (typeof LCC_USER !== 'undefined' && LCC_USER.workspace_id) headers['x-lcc-workspace'] = LCC_USER.workspace_id;
      const res = await fetch('/api/actions', {
        method: 'POST', headers,
        body: JSON.stringify({ action_type: 'log_activity', title: 'Touchpoint: ' + title, domain: db === 'gov' ? 'government' : 'dialysis', notes, entity_id: id })
      });
      if (!res.ok) throw new Error('Server returned ' + res.status);
      showToast('Touchpoint logged!', 'success');
    } catch (e) { showToast('Error: ' + e.message, 'error'); }
    return;
  }

  if (action === 'create_task') {
    const taskTitle = await lccPrompt('Task description:', 'Follow up on ' + title);
    if (!taskTitle) return;
    try {
      const headers = { 'Content-Type': 'application/json' };
      if (typeof LCC_USER !== 'undefined' && LCC_USER.workspace_id) headers['x-lcc-workspace'] = LCC_USER.workspace_id;
      const res = await fetch('/api/actions', {
        method: 'POST', headers,
        body: JSON.stringify({ action_type: 'create_task', title: taskTitle, domain: db === 'gov' ? 'government' : 'dialysis', entity_id: id, status: 'open' })
      });
      if (!res.ok) throw new Error('Server returned ' + res.status);
      showToast('Task created!', 'success');
    } catch (e) { showToast('Error: ' + e.message, 'error'); }
    return;
  }
}
window._udAction = _udAction;

function _udResearchLinks() {
  if (!_udCache || !_udCache.property) return '';
  const p = _udCache.property;
  const own = _udCache.ownership;
  const db = _udCache.db;

  const county = p.county || '';
  const state = (p.state || '').toUpperCase().trim();
  const city = p.city || '';
  const address = p.address || '';
  const fullAddr = address + (city ? ', ' + city : '') + (state ? ', ' + state : '');

  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">Research Quick Links</div>';
  html += '<div class="ql-grid">';

  // ── COUNTY RESEARCH ──
  if (county && state) {
    const countyQ = encodeURIComponent(county + ' County ' + (_STATE_NAMES[state] || state));
    html += _qlBtn(
      county + ' Co. Appraiser',
      'https://www.google.com/search?q=' + countyQ + '+property+appraiser+records&btnI=1',
      '🏛', '#6c8cff'
    );
    html += _qlBtn(
      county + ' Co. GIS',
      'https://www.google.com/search?q=' + countyQ + '+GIS+parcel+map&btnI=1',
      '🗺', '#4ecdc4'
    );
  }

  // ── PROPERTY STATE SOS ──
  if (state && _SOS_URLS[state]) {
    html += _qlBtn(
      state + ' Sec. of State',
      _SOS_URLS[state],
      '📋', '#f7b731'
    );
  }

  // ── OWNER HOME STATE SOS (LLC/SPE) ──
  let ownerState = null;
  if (own) {
    // Gov has recorded_owner_state / true_owner_state; Dia has recorded_owner_state / true_owner_state
    ownerState = (own.true_owner_state || own.recorded_owner_state || '').toUpperCase().trim();
  }
  // Also check ownership_history state_of_incorporation from fallback
  const incorpState = (_udCache.fallback?.state_of_incorporation || '').toUpperCase().trim();
  const sosState = incorpState || ownerState;

  if (sosState && sosState !== state && _SOS_URLS[sosState]) {
    html += _qlBtn(
      sosState + ' SOS (Owner)',
      _SOS_URLS[sosState],
      '🏢', '#e056a0'
    );
  }

  // ── GOOGLE MAPS / STREET VIEW ──
  if (address && city) {
    const mapsQ = encodeURIComponent(fullAddr);
    html += _qlBtn(
      'Google Maps',
      'https://www.google.com/maps/search/' + mapsQ,
      '📍', '#34a853'
    );
    if (p.latitude && p.longitude) {
      html += _qlBtn(
        'Street View',
        `https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=${p.latitude},${p.longitude}`,
        '👁', '#4285f4'
      );
    }
  }

  // ── SALESFORCE LINKS ──
  const sfContactId = own?.sf_contact_id || own?.salesforce_id || '';
  const sfOppId = own?.sf_opportunity_id || '';
  const sfCompanyId = own?.sf_company_id || '';

  if (sfContactId) {
    html += _qlBtn('SF Contact', `${_SF_BASE}/Contact/${sfContactId}/view`, '👤', '#00a1e0');
  }
  if (sfOppId) {
    html += _qlBtn('SF Opportunity', `${_SF_BASE}/Opportunity/${sfOppId}/view`, '💰', '#ff9f43');
  }
  if (sfCompanyId) {
    html += _qlBtn('SF Account', `${_SF_BASE}/Account/${sfCompanyId}/view`, '🏬', '#a55eea');
  }

  // ── THIRD PARTY SEARCH ──
  if (address && city) {
    const costarQ = encodeURIComponent(fullAddr);
    html += _qlBtn(
      'CoStar Lookup',
      'https://www.costar.com/search?q=' + costarQ,
      '⭐', '#ff6348'
    );
    html += _qlBtn(
      'LoopNet',
      'https://www.loopnet.com/search/commercial-real-estate/' + encodeURIComponent(city + '-' + state) + '/for-sale/',
      '🔄', '#1e90ff'
    );
  }

  // ── OWNER WEBSITE / GOOGLE LOOKUP ──
  // Canonical names produce better Google hits than casing variants.
  const ownerName = own?.true_owner_canonical || own?.true_owner || own?.recorded_owner_canonical || own?.recorded_owner || '';
  if (ownerName) {
    html += _qlBtn(
      'Owner Search',
      'https://www.google.com/search?q=' + encodeURIComponent('"' + ownerName + '" real estate'),
      '🔍', '#95afc0'
    );
  }

  html += _qlActionBtn('ChatGPT Brief', 'openResearchInChatGPT()', '🤖', '#10a37f');
  html += _qlActionBtn('Claude Brief', 'openResearchInClaude()', '✦', '#d97706');

  html += '</div></div>';
  return html;
}

function buildResearchAssistantPrompt(provider = 'chatgpt') {
  if (!_udCache || !_udCache.property) return '';

  const p = _udCache.property || {};
  const own = _udCache.ownership || {};
  const fallback = _udCache.fallback || {};
  const ownershipNotes = document.getElementById('udOwnNotes')?.value?.trim() || '';
  const intelNotes = document.getElementById('intelResearchNotes')?.value?.trim() || '';
  const lines = [
    `You are helping with commercial real estate research inside Life Command Center.`,
    `Create a concise analyst-ready output for this property.`,
    '',
    'Property',
    `- Address: ${p.address || 'N/A'}`,
    `- City/State: ${p.city || 'N/A'}, ${p.state || 'N/A'}`,
    `- County: ${p.county || 'Unknown'}`,
    `- Domain: ${_udCache.db || 'unknown'}`,
    `- Property ID: ${p.property_id || fallback.property_id || 'N/A'}`,
    `- Lease Number: ${p.lease_number || fallback.lease_number || 'N/A'}`,
    '',
    'Ownership Context',
    `- Recorded owner: ${own.recorded_owner_canonical || own.recorded_owner || fallback.recorded_owner || 'Unknown'}`,
    `- True owner: ${own.true_owner_canonical || own.true_owner || fallback.true_owner || 'Unknown'}`,
    `- Owner type: ${own.recorded_owner_type || own.owner_type || fallback.owner_type || 'Unknown'}`,
    `- State of incorporation: ${fallback.state_of_incorporation || own.true_owner_state || own.recorded_owner_state || 'Unknown'}`,
    '',
    'Existing Notes',
    `- Ownership notes: ${ownershipNotes || 'None entered'}`,
    `- Research notes: ${intelNotes || 'None entered'}`,
    '',
    'Return in this format:',
    '1. Executive summary',
    '2. Most likely owner / decision-maker',
    '3. Evidence and unresolved questions',
    '4. Recommended next 3 research steps',
    '5. Draft CRM-safe follow-up note',
  ];

  if (provider === 'claude') {
    lines.push('Keep the output direct and analyst-friendly. Avoid filler.');
  }

  return lines.join('\n');
}

async function exportResearchToAssistant(provider) {
  const prompt = buildResearchAssistantPrompt(provider);
  if (!prompt) {
    showToast('No property loaded', 'error');
    return;
  }

  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(prompt);
    }
  } catch (e) {
    console.warn('Clipboard export warning:', e);
  }

  const target = provider === 'claude' ? 'https://claude.ai/chats' : 'https://chatgpt.com/';
  window.open(target, '_blank', 'noopener');
  showToast(`Research brief copied. Paste it into ${provider === 'claude' ? 'Claude' : 'ChatGPT'}.`, 'success');
}

async function openResearchInChatGPT() {
  await exportResearchToAssistant('chatgpt');
}

async function openResearchInClaude() {
  await exportResearchToAssistant('claude');
}

/** System links — Salesforce records + email for the Ownership tab */
function _udSystemLinks(own) {
  if (!own) return '';

  const sfContactId = own.sf_contact_id || own.salesforce_id || '';
  const sfOppId = own.sf_opportunity_id || '';
  const sfCompanyId = own.sf_company_id || '';
  const contactEmail = own.contact_email || '';

  // Only show if we have at least one link
  if (!sfContactId && !sfOppId && !sfCompanyId && !contactEmail) return '';

  let html = '<div class="detail-section">';
  html += '<div class="detail-section-title">System Links</div>';
  html += '<div class="ql-grid">';

  if (sfContactId) {
    html += _qlBtn('SF Contact', `${_SF_BASE}/Contact/${sfContactId}/view`, '👤', '#00a1e0');
  }
  if (sfOppId) {
    html += _qlBtn('SF Opportunity', `${_SF_BASE}/Opportunity/${sfOppId}/view`, '💰', '#ff9f43');
  }
  if (sfCompanyId) {
    html += _qlBtn('SF Account', `${_SF_BASE}/Account/${sfCompanyId}/view`, '🏬', '#a55eea');
  }

  // Email — open in Outlook Web (search for contact)
  if (contactEmail) {
    const owlSearch = `https://outlook.office.com/mail/search/id//?query=${encodeURIComponent(contactEmail)}`;
    html += _qlBtn('Email History', owlSearch, '📧', '#0078d4');
  }

  html += '</div></div>';
  return html;
}

/** Build Outlook Web App search URL for email history with a contact */
function _outlookSearchUrl(email) {
  return `https://outlook.office.com/mail/search/id//?query=${encodeURIComponent(email)}`;
}

// ============================================================================
// SHARED HELPERS
// ============================================================================

function _row(label, value) {
  if (value == null || value === '' || value === '—') return '';
  return `<div class="detail-row">
    <div class="detail-lbl">${esc(label)}</div>
    <div class="detail-val">${esc(String(value))}</div>
  </div>`;
}

/**
 * Row that renders an em-dash placeholder with an inline "Resolve via
 * ChromeConnector" link. Used for fields like year_built that CoStar
 * sometimes omits — lets the user jump back to the source page so the
 * extension can repopulate the missing field.
 */
function _rowResolve(label, field) {
  const handler = `_udResolveViaConnector('${esc(field)}')`;
  return `<div class="detail-row">
    <div class="detail-lbl">${esc(label)}</div>
    <div class="detail-val t-muted3">—
      <a href="#" onclick="event.preventDefault();${handler}" style="margin-left:8px;font-size:11px;color:var(--accent);text-decoration:none;border-bottom:1px dashed var(--accent)">Resolve via ChromeConnector</a>
    </div>
  </div>`;
}

/**
 * Editable row: double-click the value to edit inline.
 * @param {string} label  - display label
 * @param {*}      value  - current display value
 * @param {string} field  - DB column name (e.g. 'year_built')
 * @param {string} table  - DB table name (e.g. 'properties')
 */
function _rowEditable(label, value, field, table) {
  if (value == null || value === '' || value === '—') return '';
  const propertyId = _udCache?.ids?.property_id || _udCache?.property?.property_id || '';
  return `<div class="detail-row">
    <div class="detail-lbl">${esc(label)}</div>
    <div class="detail-val"><span class="inline-editable" data-field="${esc(field)}" data-table="${esc(table)}" data-id="${esc(String(propertyId))}" ondblclick="_udInlineEdit(this)" title="Double-click to edit" style="border-bottom:1px dashed var(--text3);cursor:pointer">${esc(String(value))}</span></div>
  </div>`;
}

/**
 * Inline-edit handler: replaces a span with an input, saves on blur/Enter.
 */
function _udInlineEdit(el) {
  if (el.querySelector('input')) return; // already editing
  const origValue = el.textContent.trim();
  const field = el.dataset.field;
  const table = el.dataset.table;
  const id = el.dataset.id;
  const input = document.createElement('input');
  input.type = 'text';
  input.value = origValue;
  input.style.cssText = 'width:100%;font-size:12px;padding:4px 6px;border:1px solid var(--accent);border-radius:4px;background:var(--s2);color:var(--text);box-sizing:border-box;outline:none';
  el.textContent = '';
  el.appendChild(input);
  input.focus();
  input.select();

  const save = async () => {
    const newVal = input.value.trim();
    el.textContent = newVal || origValue;
    if (newVal === origValue || !newVal) return;
    try {
      const qFn = _udCache?.db === 'gov' ? govQuery : diaQuery;
      await qFn(table, null, {
        method: 'PATCH',
        filter: `property_id=eq.${encodeURIComponent(id)}`,
        body: { [field]: newVal }
      });
      showToast(`Updated ${field.replace(/_/g, ' ')}`, 'success');
      // Update local cache so re-render shows new value
      if (_udCache?.property) _udCache.property[field] = newVal;
    } catch (e) {
      console.error('Inline edit error:', e);
      showToast('Save failed: ' + e.message, 'error');
      el.textContent = origValue;
    }
  };

  input.addEventListener('blur', save);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
    if (e.key === 'Escape') { el.textContent = origValue; }
  });
}
window._udInlineEdit = _udInlineEdit;

/**
 * Deep-link to CoStar (or the last-known source URL) for the current
 * property so the ChromeConnector extension's content script can re-extract
 * a missing field. Extension auto-POSTs back into the sidebar pipeline.
 */
function _udResolveViaConnector(field) {
  const p = _udCache && _udCache.property || {};
  const fb = _udCache && _udCache.fallback || {};
  const sourceUrl = p.costar_url || p.source_url || p.page_url || fb.costar_url || fb.source_url || null;
  const addr = p.address || fb.address || '';
  const target = sourceUrl
    || (addr ? 'https://product.costar.com/home/search?q=' + encodeURIComponent(addr) : null);

  if (!target) {
    if (typeof showToast === 'function') showToast('No source URL on file — open CoStar/LoopNet manually to resolve ' + field, 'warn');
    return;
  }
  if (typeof showToast === 'function') showToast('Opening source — ChromeConnector will re-extract ' + field, 'info');
  window.open(target, '_blank', 'noopener');
}

/** Row with raw HTML value (for utilization bars, trend arrows, margin badges, etc.) */
function _rowHtml(label, value) {
  if (value == null || value === '') return '';
  return `<div class="detail-row">
    <div class="detail-lbl">${esc(label)}</div>
    <div class="detail-val">${value}</div>
  </div>`;
}

function _rowMoney(label, value) {
  if (value == null) return '';
  return `<div class="detail-row">
    <div class="detail-lbl">${esc(label)}</div>
    <div class="detail-val money">${fmt(value)}</div>
  </div>`;
}

function _rowLink(label, text, href) {
  if (!text) return '';
  const display = esc(String(text));
  const link = href ? `<a href="${esc(href).replace(/"/g, '&quot;')}">${display}</a>` : display;
  return `<div class="detail-row">
    <div class="detail-lbl">${esc(label)}</div>
    <div class="detail-val">${link}</div>
  </div>`;
}

// ============================================================================
// CROSS-ENTITY NAVIGATION HELPERS
// Turn entity references into clickable links that open detail views
// ============================================================================

/**
 * Navigate to a property detail view
 * @param {number} propertyId - Property ID to navigate to
 * @param {string} db - Database: 'dialysis' or 'gov' (default: 'dialysis')
 */
window.navToProperty = function(propertyId, db) {
  db = db || 'dialysis';
  openUnifiedDetail(db, { property_id: propertyId });
};

/**
 * Navigate to a contact/owner detail view
 * @param {number} contactId - Contact ID to navigate to
 * @param {string} db - Database: 'dialysis' or 'gov' (default: 'dialysis')
 */
window.navToContact = function(contactId, db) {
  openContactDetail(String(contactId));
};

/**
 * Navigate to a transaction/sale detail view
 * @param {number} saleId - Sale ID to navigate to
 */
window.navToTransaction = function(saleId) {
  // Find sale record and open sale detail
  if (typeof renderSaleDetailBody === 'function' && window.diaSalesComps) {
    const rec = window.diaSalesComps.find(r => r.sale_id === saleId);
    if (rec) {
      window._saleRecord = rec;
      renderSaleDetailBody(rec);
      return;
    }
  }
  showToast('Transaction not found in current data', 'info');
};

/**
 * Navigate to operator view
 * @param {string} operatorName - Operator name to filter by
 */
window.navToOperator = function(operatorName) {
  openEntityDetailByName(operatorName);
};

/**
 * Navigate to state view
 * @param {string} stateName - State name to filter by
 */
window.navToState = function(stateName) {
  window._pendingOpFilter = { type: 'state', value: stateName };
  if (typeof goToDiaTab === 'function') {
    window.diaPlayersView = 'operators';
    goToDiaTab('players');
  } else {
    showToast('Navigate to Dialysis → Players tab to view state: ' + stateName, 'info');
  }
};

/**
 * Generate a clickable entity link
 * Renders as styled span with onclick handler to navigate to entity detail view
 * @param {string} text - Display text (will be escaped)
 * @param {string} type - Entity type: 'property', 'contact', 'transaction', 'operator', 'state'
 * @param {number|string} id - Entity ID (for property/contact/transaction)
 * @param {string} db - Database context: 'dialysis' or 'gov'
 * @returns {string} HTML span element with onclick handler
 */
window.entityLink = function(text, type, id, db) {
  if (!text) return '—';
  var style = 'color:var(--accent);cursor:pointer;text-decoration:underline;text-decoration-style:dotted;';
  switch (type) {
    case 'property':
      if (!id) return esc(text);
      return '<span style="' + style + '" onclick="navToProperty(' + id + ',\'' + (db || 'dialysis') + '\')" title="View property details">' + esc(text) + '</span>';
    case 'contact':
      if (!id) return '<span style="' + style + '" onclick="openContactDetailByName(\'' + esc(text).replace(/'/g, "\\'") + '\')" title="View contact">' + esc(text) + '</span>';
      return '<span style="' + style + '" onclick="openContactDetail(' + JSON.stringify(String(id)) + ')" title="View contact details">' + esc(text) + '</span>';
    case 'entity':
      if (!id) return '<span style="' + style + '" onclick="openEntityDetailByName(\'' + esc(text).replace(/'/g, "\\'") + '\')" title="View entity">' + esc(text) + '</span>';
      return '<span style="' + style + '" onclick="openEntityDetail(' + JSON.stringify(String(id)) + ')" title="View entity details">' + esc(text) + '</span>';
    case 'transaction':
      if (!id) return esc(text);
      return '<span style="' + style + '" onclick="navToTransaction(' + id + ')" title="View transaction details">' + esc(text) + '</span>';
    case 'tenant': {
      const ctxPayload = encodeURIComponent(JSON.stringify({ name: text, db: db || null }));
      return '<span class="tenant-link" role="button" tabindex="0" data-tenant-ctx="' + ctxPayload +
        '" style="' + style + ';font-weight:600" title="View tenant profile">' + esc(text) + '</span>';
    }
    case 'broker': {
      const ctxPayload = encodeURIComponent(JSON.stringify({ name: text, db: db || null }));
      return '<span class="broker-link" role="button" tabindex="0" data-broker-ctx="' + ctxPayload +
        '" style="' + style + ';font-weight:600" title="View broker profile">' + esc(text) + '</span>';
    }
    case 'operator':
    case 'owner':
    case 'buyer':
    case 'seller':
    case 'investor':
      return '<span style="' + style + '" onclick="openEntityDetailByName(\'' + esc(text).replace(/'/g, "\\'") + '\')" title="View entity">' + esc(text) + '</span>';
    case 'state':
      return '<span style="' + style + '" onclick="navToState(\'' + esc(text).replace(/'/g, "\\'") + '\')" title="View state properties">' + esc(text) + '</span>';
    default:
      return esc(text);
  }
};



/** Convert 24h time string "HH:MM" to 12h format "H:MM AM/PM" */
function _fmt12h(t) {
  if (!t || typeof t !== 'string') return t;
  const parts = t.split(':');
  let h = parseInt(parts[0], 10);
  const m = parts[1] || '00';
  const ampm = h >= 12 ? 'PM' : 'AM';
  if (h === 0) h = 12;
  else if (h > 12) h -= 12;
  return h + ':' + m + ' ' + ampm;
}

function _fmtDate(d) {
  if (!d) return '—';
  try {
    const date = new Date(d);
    if (isNaN(date)) return String(d);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  } catch (e) { return String(d); }
}

function _stars(n) {
  if (n == null) return '—';
  const full = Math.floor(n);
  const half = n - full >= 0.5 ? 1 : 0;
  const empty = 5 - full - half;
  return '<span style="color:var(--yellow);letter-spacing:2px">' +
    '&#9733;'.repeat(full) +
    (half ? '&#9734;' : '') +
    '<span class="t-muted3">' + '&#9734;'.repeat(empty) + '</span>' +
    '</span> <span style="font-size:12px;color:var(--text2)">' + n.toFixed(1) + '</span>';
}

// ============================================================================
// BRIDGE: Extract IDs from existing record objects and open unified detail
// ============================================================================

/**
 * Called from existing onclick handlers.
 * Extracts property_id and lease_number from any record shape and opens unified detail.
 */
function showUnifiedDetail(record, source, initialTab) {
  const db = source.startsWith('gov') ? 'gov' : 'dia';

  const ids = {
    property_id: record.property_id || null,
    lease_number: record.lease_number || null
  };

  openUnifiedDetail(db, ids, record, initialTab);
}

// ============================================================================
// CRM: INLINE LOG CALL
// ============================================================================

async function _udSubmitLogCall(sfContactId, sfCompanyId) {
  const btn = document.getElementById('udLogSubmit');
  if (!btn) return;
  btn.disabled = true;
  btn.textContent = 'Logging...';

  const actType = document.getElementById('udLogType')?.value || 'Client Outreach';
  const outcome = document.getElementById('udLogOutcome')?.value || 'connected';
  const actDate = document.getElementById('udLogDate')?.value || new Date().toISOString().split('T')[0];
  const notes = document.getElementById('udLogNotes')?.value || '';

  if (!sfContactId && !sfCompanyId) {
    showToast('No Salesforce contact or company ID available.', 'error');
    btn.disabled = false;
    btn.textContent = '\u260E Log Activity';
    return;
  }

  const API = 'https://zqzrriwuavgrquhisnoa.supabase.co/functions/v1/ai-copilot';

  try {
    // ── GENERIC SF PAYLOAD ──
    // Salesforce gets only a generic activity description — no deal-specific
    // notes, no client engagement details. This ensures compliance with rules
    // of engagement while keeping proprietary intel in Supabase only.
    const _SF_GENERIC_MAP = {
      'Client Outreach': 'Investment Sales - Client Touch',
      'Introduction Call': 'Investment Sales - Introduction',
      'Follow-up': 'Investment Sales - Follow-up',
      'Property Discussion': 'Investment Sales - Property Research',
      'Email Correspondence': 'Investment Sales - Email Correspondence',
      'Market Update': 'Investment Sales - Market Update'
    };
    const sfSubject = _SF_GENERIC_MAP[actType] || 'Investment Sales - Activity';

    const payload = {
      sf_contact_id: sfContactId || undefined,
      sf_company_id: sfCompanyId || undefined,
      activity_type: actType,
      activity_date: actDate,
      outcome: outcome,
      // Redacted: SF only sees generic subject, no notes
      notes: sfSubject,
      force: true
    };

    // 1. Log to Salesforce (generic)
    const res = await fetch('/api/sync?action=outbound', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command: 'log_to_sf', payload })
    });
    if (!res.ok) throw new Error('Server returned ' + res.status);
    const data = await res.json();

    if (data.status === 'completed' || data.success) {
      showToast('Activity logged (SF generic + private notes saved)', 'success');
      const udNotesEl = document.getElementById('udLogNotes');
      if (udNotesEl) udNotesEl.value = '';
      // 2. Log FULL details to outbound_activities in Supabase (private)
      try {
        await _udLogOutbound(sfContactId, sfCompanyId, actType, actDate, outcome, notes);
      } catch (e) { console.warn('Outbound log fallback error:', e); }
      // 3. Bridge to canonical model
      canonicalBridge('log_call', {
        subject: actType,
        notes,
        outcome,
        domain: _udCache?.db || null,
        external_id: _udCache?.property?.property_id ? String(_udCache.property.property_id) : null,
        source_system: _udCache?.db === 'gov' ? 'gov' : 'dia',
        sf_contact_id: sfContactId,
        sf_company_id: sfCompanyId,
        activity_date: actDate
      });
    } else if (data.warning) {
      showToast(`Warning: ${data.message || 'Recent activity detected'}`, 'error');
    } else {
      showToast(`Error: ${data.error || 'Unknown error'}`, 'error');
    }
  } catch (e) {
    showToast(`Network error: ${e.message}`, 'error');
  }

  btn.disabled = false;
  btn.textContent = '\u260E Log Activity';
}

/** Write FULL private activity details to outbound_activities (Supabase only — never SF) */
async function _udLogOutbound(sfContactId, sfCompanyId, actType, actDate, outcome, notes) {
  try {
    await applyInsertWithFallback({
      proxyBase: '/api/dia-query',
      table: 'outbound_activities',
      data: {
        sf_contact_id: sfContactId || null,
        sf_company_id: sfCompanyId || null,
        activity_type: actType,
        activity_date: actDate,
        status: outcome,
        notes: notes || null,
        user_name: (typeof LCC_USER !== 'undefined' && LCC_USER.display_name) || 'unknown',
        ref_id: _udCache?.property?.property_id ? String(_udCache.property.property_id) : null
      },
      source_surface: 'detail_outbound_activity',
      propagation_scope: 'outbound_activity'
    });
  } catch (e) {
    console.warn('_udLogOutbound error:', e);
  }
}

// ============================================================================
// CRM: EMAIL TEMPLATES
// ============================================================================

let _udTemplates = [];

async function _loadEmailTemplates(own) {
  await new Promise(r => setTimeout(r, 80));
  const sel = document.getElementById('udTemplateSelect');
  if (!sel) return;

  try {
    _udTemplates = await diaQuery('bd_email_templates', '*', { order: 'name.asc', limit: 20 });

    if (!_udTemplates || _udTemplates.length === 0) {
      sel.innerHTML = '<option value="">No templates available</option>';
      return;
    }

    let opts = '<option value="">— Select a template —</option>';
    _udTemplates.forEach((t, i) => {
      opts += `<option value="${i}">${esc(t.name)} (${esc(t.template_type)})</option>`;
    });
    sel.innerHTML = opts;
  } catch (e) {
    console.error('Template load error:', e);
    showToast('Failed to load email templates', 'error');
    sel.innerHTML = '<option value="">Error loading templates</option>';
  }
}

function _udPreviewTemplate() {
  const sel = document.getElementById('udTemplateSelect');
  const preview = document.getElementById('udTemplatePreview');
  if (!sel || !preview) return;

  const idx = sel.value;
  if (idx === '' || !_udTemplates[idx]) {
    preview.style.display = 'none';
    return;
  }

  const tmpl = _udTemplates[idx];
  const merged = _udMergeFields(tmpl);

  const subjectEl = document.getElementById('udTemplateSubject');
  const bodyEl = document.getElementById('udTemplateBody');
  if (subjectEl) subjectEl.textContent = merged.subject;
  if (bodyEl) bodyEl.innerHTML = merged.bodyHtml;
  preview.style.display = 'block';
}

function _udMergeFields(tmpl) {
  const prop = _udCache?.property || {};
  const own = _udCache?.ownership || {};

  // Escape field values before merging into HTML templates to prevent XSS
  const contactName = esc(own.contact_1_name || own.contact_name || own.true_owner_canonical || own.true_owner || own.recorded_owner_canonical || own.recorded_owner || 'there');
  const propertyName = esc(prop.page_title || prop.address || 'the property');
  const cityState = esc((prop.city || '') + (prop.state ? ', ' + prop.state : ''));
  const annualRent = prop.annual_rent ? esc(fmt(prop.annual_rent)) : '';
  const askingPrice = prop.asking_price ? esc(fmt(prop.asking_price)) : '';
  const capRate = prop.cap_rate ? esc(_fmtCapRate(prop.cap_rate) || '') : '';
  const agency = esc(prop.agency_full || prop.agency_short || '');
  const leaseTerm = '';

  const merge = (str) => {
    if (!str) return '';
    return str
      .replace(/\{\{contact_name\}\}/g, contactName)
      .replace(/\{\{property_name\}\}/g, propertyName)
      .replace(/\{\{city_state\}\}/g, cityState)
      .replace(/\{\{annual_rent\}\}/g, annualRent)
      .replace(/\{\{asking_price\}\}/g, askingPrice)
      .replace(/\{\{cap_rate\}\}/g, capRate)
      .replace(/\{\{agency\}\}/g, agency)
      .replace(/\{\{lease_term\}\}/g, leaseTerm);
  };

  return {
    subject: merge(tmpl.subject_template),
    bodyHtml: merge(tmpl.html_body_template),
    bodyText: _htmlToText(merge(tmpl.html_body_template))
  };
}

/** Strip HTML to plain text for mailto body */
function _htmlToText(html) {
  if (!html) return '';
  return html
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/p>/gi, '\n\n')
    .replace(/<\/div>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&#39;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function _udSendTemplate() {
  const sel = document.getElementById('udTemplateSelect');
  const idx = sel?.value;
  if (idx === '' || !_udTemplates[idx]) { showToast('Select a template first'); return; }

  const tmpl = _udTemplates[idx];
  const merged = _udMergeFields(tmpl);
  const own = _udCache?.ownership || {};
  const toEmail = own.contact_email || '';

  const mailto = `mailto:${encodeURIComponent(toEmail)}?subject=${encodeURIComponent(merged.subject)}&body=${encodeURIComponent(merged.bodyText)}`;
  window.open(mailto, '_blank', 'noopener');
}

async function _udCopyTemplate() {
  const sel = document.getElementById('udTemplateSelect');
  const idx = sel?.value;
  if (idx === '' || !_udTemplates[idx]) { showToast('Select a template first'); return; }

  const tmpl = _udTemplates[idx];
  const merged = _udMergeFields(tmpl);

  try {
    await navigator.clipboard.writeText(merged.bodyText);
    showToast('Template copied to clipboard!', 'success');
  } catch (e) {
    // Fallback
    const ta = document.createElement('textarea');
    ta.value = merged.bodyText;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
    showToast('Template copied!', 'success');
  }
}

// ============================================================================
// DRAFT EMAIL ENGINE — LCC Template System (v3)
// ============================================================================

/** Current draft state — holds the API response for record_send tracking */
let _udCurrentDraft = null;

/** Cached cadence state for current property — avoids re-fetching on each draft */
let _udCadenceCache = null;

/**
 * Generate a draft email using the LCC template engine.
 * Reads property/ownership from _udCache, fetches cadence state from the server,
 * uses the cadence recommendation for auto-select, builds context, calls the API,
 * and populates the editable preview area.
 */
async function _udGenerateDraft() {
  const btn = document.getElementById('udDraftBtn');
  if (btn) { btn.disabled = true; btn.textContent = 'Drafting…'; btn.style.opacity = '0.6'; }

  try {
    const prop = _udCache?.property || {};
    const own = _udCache?.ownership || {};
    const chain = _udCache?.chain || [];
    const db = _udCache?.db || '';

    // Determine domain from DB source
    const domain = db === 'gov' ? 'government' : db === 'dia' ? 'dialysis' : '';

    // Resolve contact name — owner, not tenant
    const contactName = own.contact_1_name || own.contact_name || own.true_owner
      || own.recorded_owner || chain[0]?.contact_name || '';

    // Resolve tenant (the government agency or dialysis operator)
    const tenant = prop.agency_full || prop.agency_short || prop.tenant
      || prop.facility_name || prop.operator || '';

    // City, State
    const city = prop.city || '';
    const state = prop.state || '';
    const cityState = city + (state ? ', ' + state : '');

    // Contact identifiers for cadence lookup
    const cadenceIds = {
      entity_id: own.entity_id || null,
      sf_contact_id: own.salesforce_id || own.sf_contact_id || null,
      contact_id: own.contact_id || null
    };

    const propertyId = _udCache?.ids?.property_id || prop.property_id || null;

    // ── Fetch cadence state (server-side) ────────────────────────────────
    let cadenceInfo = null;
    if (cadenceIds.entity_id || cadenceIds.sf_contact_id || cadenceIds.contact_id) {
      try {
        const fetchFn = (typeof LCC_AUTH !== 'undefined' && LCC_AUTH.isAuthenticated) ? LCC_AUTH.apiFetch : fetch;
        const cadResp = await fetchFn('/api/operations?_route=draft&action=cadence', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...cadenceIds,
            property_id: propertyId,
            property_address: prop.address || '',
            domain
          })
        });
        cadenceInfo = await cadResp.json();
        if (cadenceInfo.ok) {
          _udCadenceCache = cadenceInfo;
          _udRenderCadenceStatus(cadenceInfo);
        }
      } catch (err) {
        console.warn('[DraftEmail] Cadence lookup failed (non-blocking):', err.message);
      }
    }

    // Build context payload matching server-side enrichDraftContext expectations
    const context = {
      contact: {
        full_name: contactName,
        first_name: (contactName || '').split(' ')[0] || '',
        company: own.company_name || own.owner_entity || chain[0]?.company_name || '',
        email: own.contact_email || ''
      },
      property: {
        tenant,
        address: prop.address || '',
        city,
        state,
        city_state: cityState,
        domain,
        property_id: propertyId,
        sf_leased: prop.sf_leased || prop.rba || prop.building_size || '',
        annual_rent: prop.annual_rent || prop.noi || '',
        asking_price: prop.asking_price || '',
        cap_rate: prop.cap_rate || '',
        lease_expiration: prop.lease_expiration || prop.firm_term_expiry || '',
        page_title: prop.page_title || '',
        agency_short: prop.agency_short || '',
        agency_full: prop.agency_full || '',
        facility_name: prop.facility_name || '',
        government_type: prop.government_type || ''
      },
      domain
    };

    // Template selection — use cadence recommendation if auto
    let templateId = document.getElementById('udDraftTemplate')?.value || 'auto';

    if (templateId === 'auto') {
      if (cadenceInfo?.ok && cadenceInfo.recommendation?.template) {
        // Server-side cadence engine recommends the template
        templateId = cadenceInfo.recommendation.template;
        // If recommended type is 'phone', show guidance instead of generating email
        if (cadenceInfo.recommendation.type === 'phone') {
          _udShowPhoneGuidance(cadenceInfo.recommendation, contactName, tenant, cityState, domain);
          return;
        }
      } else {
        // Fallback to local heuristic if cadence unavailable
        templateId = _udAutoSelectTemplate(prop, own, domain);
      }
    }

    // Call the LCC draft API with cadence IDs for context flag injection
    const fetchFn = (typeof LCC_AUTH !== 'undefined' && LCC_AUTH.isAuthenticated) ? LCC_AUTH.apiFetch : fetch;
    const resp = await fetchFn('/api/operations?_route=draft&action=generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        template_id: templateId,
        context,
        cadence_ids: cadenceIds
      })
    });

    const result = await resp.json();

    if (!result.ok) {
      showToast(result.error || 'Failed to generate draft', 'error');
      console.error('[DraftEmail] API error:', result);
      return;
    }

    // Store draft state for record_send (includes cadence info + report attachment)
    _udCurrentDraft = {
      template_id: result.draft.template_id,
      template_version: result.draft.template_version,
      template_name: result.draft.template_name,
      rendered_subject: result.draft.subject,
      rendered_body: result.draft.body,
      entity_id: own.salesforce_id || own.sf_contact_id || own.contact_id || null,
      domain,
      unresolved: result.draft.unresolved_variables || [],
      cadence_id: result.cadence?.id || _udCadenceCache?.cadence?.id || null,
      report_attachment: result.report_attachment || null,
      context: context  // Stored so _udSendDraft can re-render via Graph with attachment
    };

    // Populate the preview
    const previewEl = document.getElementById('udDraftPreview');
    const subjectEl = document.getElementById('udDraftSubject');
    const bodyEl = document.getElementById('udDraftBody');
    const metaEl = document.getElementById('udDraftMeta');
    const recordBtn = document.getElementById('udRecordSendBtn');

    if (subjectEl) subjectEl.value = result.draft.subject || '';
    if (bodyEl) bodyEl.value = result.draft.body || '';
    if (previewEl) previewEl.style.display = 'block';
    if (recordBtn) recordBtn.style.display = 'inline-flex';

    // Show metadata with cadence context
    if (metaEl) {
      const unresolvedCount = _udCurrentDraft.unresolved.length;
      let meta = `Template: ${esc(result.draft.template_name)} (${result.draft.template_id} v${result.draft.template_version})`;
      if (result.cadence) {
        const c = result.cadence;
        meta += ` · Touch ${c.current_touch + 1}/7 · Tier ${esc(c.priority_tier)}`;
        if (c.phase === 'maintenance') meta += ' · Quarterly';
      }
      if (unresolvedCount > 0) {
        meta += ` · <span style="color:var(--yellow,#f59e0b)">${unresolvedCount} unresolved var${unresolvedCount > 1 ? 's' : ''}</span>`;
      }
      if (result.report_attachment?.filename) {
        meta += ` · <span style="color:var(--accent,#2563eb)">📎 Attach: ${esc(result.report_attachment.filename)}</span>`;
      }
      metaEl.innerHTML = meta;
    }

    showToast('Draft generated — review and edit before sending', 'success');

  } catch (err) {
    console.error('[DraftEmail] Error:', err);
    showToast('Error generating draft: ' + err.message, 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Draft Email'; btn.style.opacity = ''; }
  }
}

/**
 * Render cadence status bar above the draft preview.
 * Shows current phase, touch position, tier, and next recommendation.
 */
function _udRenderCadenceStatus(cadenceInfo) {
  let statusEl = document.getElementById('udCadenceStatus');
  if (!statusEl) {
    // Create it above the draft preview
    const previewEl = document.getElementById('udDraftPreview');
    if (!previewEl) return;
    statusEl = document.createElement('div');
    statusEl.id = 'udCadenceStatus';
    statusEl.style.cssText = 'margin-top:12px;padding:10px 12px;background:var(--s2);border-radius:8px;font-size:11px;line-height:1.6;color:var(--text2)';
    previewEl.parentNode.insertBefore(statusEl, previewEl);
  }

  const c = cadenceInfo.cadence;
  const rec = cadenceInfo.recommendation;
  if (!c) { statusEl.style.display = 'none'; return; }

  // Build progress bar for prospecting phase
  let progressHtml = '';
  if (c.phase === 'prospecting') {
    const pct = Math.round((c.current_touch / 7) * 100);
    progressHtml = `<div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">` +
      `<div style="flex:1;height:4px;background:var(--s3);border-radius:2px;overflow:hidden">` +
      `<div style="width:${pct}%;height:100%;background:var(--accent);border-radius:2px"></div></div>` +
      `<span style="font-size:10px;font-weight:600;white-space:nowrap">${c.current_touch}/7 touches</span></div>`;
  }

  // Tier badge colors
  const tierColors = { A: 'var(--red,#ef4444)', B: 'var(--accent,#3b82f6)', C: 'var(--text3)' };
  const tierColor = tierColors[c.priority_tier] || 'var(--text3)';

  // Next action
  let nextHtml = '';
  if (rec && !rec.blocked) {
    const typeIcon = rec.type === 'phone' ? '&#x1F4DE;' : '&#x2709;';
    const overdue = rec.is_overdue ? ` <span style="color:var(--red,#ef4444);font-weight:600">(${rec.overdue_days}d overdue)</span>` : '';
    nextHtml = `<div style="margin-top:4px">${typeIcon} Next: <strong>${esc(rec.label)}</strong>${overdue}</div>`;
    if (rec.is_escalation) {
      nextHtml = `<div style="margin-top:4px;color:var(--yellow,#f59e0b)">&#x26A0; Escalation: <strong>${esc(rec.label)}</strong></div>`;
    }
  } else if (rec?.blocked) {
    nextHtml = `<div style="margin-top:4px;color:var(--text3)">&#x23F8; ${esc(rec.reason || rec.label)}</div>`;
  }

  // Engagement stats
  let statsHtml = '';
  const stats = [];
  if (c.emails_sent > 0) stats.push(`${c.emails_sent} sent`);
  if (c.emails_opened > 0) stats.push(`${c.emails_opened} opened`);
  if (c.emails_replied > 0) stats.push(`${c.emails_replied} replied`);
  if (c.calls_made > 0) stats.push(`${c.calls_made} calls`);
  if (stats.length > 0) statsHtml = `<div style="margin-top:4px;color:var(--text3)">${stats.join(' · ')}</div>`;

  statusEl.innerHTML =
    progressHtml +
    `<div><span style="display:inline-block;padding:1px 6px;border-radius:4px;font-size:10px;font-weight:700;color:white;background:${tierColor}">Tier ${esc(c.priority_tier)}</span> ` +
    `<span style="margin-left:6px">${esc(c.phase === 'prospecting' ? 'Prospecting' : c.phase === 'maintenance' ? 'Quarterly Maintenance' : c.phase)}</span></div>` +
    nextHtml + statsHtml;

  statusEl.style.display = 'block';
}

/**
 * Show phone call guidance when cadence recommends a phone touch instead of email.
 */
function _udShowPhoneGuidance(recommendation, contactName, tenant, cityState, domain) {
  const previewEl = document.getElementById('udDraftPreview');
  const subjectEl = document.getElementById('udDraftSubject');
  const bodyEl = document.getElementById('udDraftBody');
  const metaEl = document.getElementById('udDraftMeta');

  const firstName = (contactName || '').split(' ')[0] || 'there';
  const domainLabel = domain === 'government' ? 'government-leased' : 'dialysis/medical';

  // Generate voicemail script based on touch number
  let script = '';
  if (recommendation.touch_number === 2) {
    script = `Hi ${firstName}, this is Scott Briggs from Northmarq. I sent you an email last week with our latest capital markets update for ${domainLabel} properties — wanted to make sure you received it. I'm specifically interested in your ${tenant}-leased asset in ${cityState} and would love to share some recent comps and market insights. Could we grab 15 minutes on the phone this week? Let me know what works best — I'm flexible.`;
  } else if (recommendation.touch_number === 4) {
    script = `Hi ${firstName}, Scott Briggs again from Northmarq. Following up on that quarterly report I sent about a week and a half ago — it includes some really relevant comp data for ${domainLabel} properties like yours. If you've had a chance to look at it, I'd love to walk through a few of the highlights. Do you have 20 minutes on your calendar this month?`;
  } else if (recommendation.touch_number === 6) {
    script = `Hi ${firstName}, Scott from Northmarq. Just wanted to follow up on that recent close I sent you last week — it's a solid comp for your portfolio in ${cityState}. Cap rates have shifted in that market, and I think a conversation about your positioning might be timely. Can we grab 20 minutes? I'm flexible with scheduling.`;
  } else {
    script = `Hi ${firstName}, this is Scott Briggs from Northmarq. I wanted to follow up regarding your ${tenant}-leased property in ${cityState}. Would you have 15–20 minutes for a quick call this week?`;
  }

  if (subjectEl) subjectEl.value = `Phone Touch ${recommendation.touch_number}: ${contactName}`;
  if (bodyEl) bodyEl.value = `VOICEMAIL SCRIPT\n${'─'.repeat(40)}\n\n${script}\n\n${'─'.repeat(40)}\nCALL TIPS\n• Call between 9am–11am or 2pm–4pm local time\n• Keep under 30 seconds\n• Leave your direct number\n• Log the outcome after the call`;
  if (previewEl) previewEl.style.display = 'block';
  if (metaEl) metaEl.innerHTML = `<span style="color:var(--yellow,#f59e0b)">&#x1F4DE; Cadence recommends a phone touch</span> · ${esc(recommendation.label)}`;

  showToast('Cadence recommends a phone call — voicemail script ready', 'info');
}

/**
 * Fallback auto-select when cadence API is unavailable.
 * Uses local DOM heuristics (prior touchpoint rows) + property signals.
 */
function _udAutoSelectTemplate(prop, own, domain) {
  // T-013: GSA Lease Award congratulations
  if (domain === 'government' && prop.government_type === 'Federal') {
    const leaseStart = prop.lease_commencement || prop.lease_start;
    if (leaseStart) {
      const startDate = new Date(leaseStart);
      const sixMonthsAgo = new Date();
      sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
      if (startDate >= sixMonthsAgo) return 'T-013';
    }
  }

  // Check DOM for prior touchpoints
  const touchpointEl = document.getElementById('udTouchpoints');
  const hasPriorTouches = touchpointEl && touchpointEl.querySelector('.detail-card');

  if (hasPriorTouches) {
    const touchCards = touchpointEl.querySelectorAll('.detail-card');
    if (touchCards.length >= 6) return 'T-003';
    return 'T-002';
  }

  return 'T-001';
}

/**
 * Open the draft in the user's email client via mailto: link.
 * Uses the (potentially edited) subject and body from the preview fields.
 */
async function _udSendDraft() {
  const subject = document.getElementById('udDraftSubject')?.value || '';
  const body = document.getElementById('udDraftBody')?.value || '';
  const own = _udCache?.ownership || {};
  const toEmail = own.contact_email || '';

  if (!body.trim()) {
    showToast('Generate a draft first', 'error');
    return;
  }

  const recordBtn = document.getElementById('udRecordSendBtn');

  // Try Graph-based Outlook draft first — real attachment + signature
  if (toEmail && _udCurrentDraft?.template_id) {
    try {
      const fetchFn = (typeof LCC_AUTH !== 'undefined' && LCC_AUTH.isAuthenticated) ? LCC_AUTH.apiFetch : fetch;
      // Re-use the already-rendered (and possibly user-edited) subject/body by
      // sending them as the context's pre_rendered override. For now we just
      // kick off create_outlook_draft which re-renders from the template —
      // the attachment path is the main win.
      const graphResp = await fetchFn('/api/operations?_route=draft&action=create_outlook_draft', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          template_id: _udCurrentDraft.template_id,
          context: _udCurrentDraft.context || {},
          to: toEmail
        })
      });
      const gj = await graphResp.json();
      if (gj.ok && gj.web_link) {
        window.open(gj.web_link, '_blank');
        const attachNote = gj.has_attachment
          ? ' with ' + (gj.report_attachment?.filename || 'attachment')
          : (gj.attachment_error ? ' (no attachment: ' + gj.attachment_error + ')' : '');
        showToast('✅ Draft created in Outlook' + attachNote, 'success', 10000);
        if (recordBtn) recordBtn.style.display = 'inline-flex';
        return;
      }
      console.warn('[detail._udSendDraft] Graph unavailable, falling back to mailto:', gj.error);
    } catch (e) {
      console.warn('[detail._udSendDraft] Graph attempt failed, falling back:', e.message);
    }
  }

  // Fallback: mailto with attachment reminder
  const mailto = `mailto:${encodeURIComponent(toEmail)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  window.open(mailto, '_blank', 'noopener');

  if (_udCurrentDraft?.report_attachment?.filename) {
    const rpt = _udCurrentDraft.report_attachment;
    if (typeof _showAttachmentReminder === 'function') {
      _showAttachmentReminder(rpt);
    } else {
      showToast('Attach: ' + rpt.filename + ' (' + (rpt.quarter || '') + ')', 'info', 15000);
    }
  }

  if (recordBtn) recordBtn.style.display = 'inline-flex';
}

/**
 * Copy the draft body to clipboard.
 */
async function _udCopyDraft() {
  const body = document.getElementById('udDraftBody')?.value || '';
  if (!body.trim()) {
    showToast('Generate a draft first', 'error');
    return;
  }

  try {
    await navigator.clipboard.writeText(body);
    showToast('Draft copied to clipboard!', 'success');
  } catch (e) {
    // Fallback for older browsers
    const ta = document.createElement('textarea');
    ta.value = body;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
    showToast('Draft copied!', 'success');
  }
}

/**
 * Record that the draft was sent — tracks template performance.
 * Captures the final (edited) version so we can measure edit distance
 * and improve templates over time.
 */
async function _udRecordDraftSend() {
  if (!_udCurrentDraft) {
    showToast('No draft to record — generate one first', 'error');
    return;
  }

  const btn = document.getElementById('udRecordSendBtn');
  if (btn) { btn.disabled = true; btn.textContent = 'Logging…'; btn.style.opacity = '0.6'; }

  try {
    const finalSubject = document.getElementById('udDraftSubject')?.value || '';
    const finalBody = document.getElementById('udDraftBody')?.value || '';

    const payload = {
      template_id: _udCurrentDraft.template_id,
      template_version: _udCurrentDraft.template_version,
      entity_id: _udCurrentDraft.entity_id,
      domain: _udCurrentDraft.domain,
      rendered_subject: _udCurrentDraft.rendered_subject,
      rendered_body: _udCurrentDraft.rendered_body,
      final_subject: finalSubject,
      final_body: finalBody,
      original_draft: _udCurrentDraft.rendered_body,
      sent_text: finalBody,
      cadence_id: _udCurrentDraft.cadence_id || null
    };

    const fetchFn = (typeof LCC_AUTH !== 'undefined' && LCC_AUTH.isAuthenticated) ? LCC_AUTH.apiFetch : fetch;
    const resp = await fetchFn('/api/operations?_route=draft&action=record_send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const result = await resp.json();

    if (result.ok) {
      // Show next recommendation if cadence advanced
      let toastMsg = 'Send recorded — template performance tracked';
      if (result.cadence_advanced && result.next_recommendation) {
        const next = result.next_recommendation;
        const typeIcon = next.type === 'phone' ? '📞' : '✉️';
        toastMsg += `. Next: ${typeIcon} ${next.label}`;
      }
      showToast(toastMsg, 'success');
      // Reset draft state
      _udCurrentDraft = null;
      _udCadenceCache = null;
      if (btn) btn.style.display = 'none';
      // Hide cadence status
      const statusEl = document.getElementById('udCadenceStatus');
      if (statusEl) statusEl.style.display = 'none';
      // Refresh touchpoints to show the new activity
      const own = _udCache?.ownership || {};
      _loadTouchpoints(own);
    } else {
      showToast(result.error || 'Failed to record send', 'error');
    }
  } catch (err) {
    console.error('[DraftEmail] Record send error:', err);
    showToast('Error recording send: ' + err.message, 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Log as Sent'; btn.style.opacity = ''; }
  }
}

// ============================================================================
// CRM: TOUCHPOINT HISTORY
// ============================================================================

async function _loadTouchpoints(own) {
  await new Promise(r => setTimeout(r, 60));
  const el = document.getElementById('udTouchpoints');
  if (!el) return;

  const sfId = own?.salesforce_id || own?.sf_contact_id || '';
  const sfCoId = own?.sf_company_id || '';

  if (!sfId && !sfCoId) {
    el.innerHTML = '';
    return;
  }

  try {
    const filter = sfId ? `sf_contact_id=eq.${sfId}` : `sf_company_id=eq.${sfCoId}`;
    const rows = await diaQuery('outbound_activities', '*', {
      filter: filter,
      order: 'activity_date.desc',
      limit: 10
    });

    if (!rows || rows.length === 0) {
      el.innerHTML = '';
      return;
    }

    let html = '<div class="detail-section">';
    html += `<div class="detail-section-title">Recent Touchpoints <span style="font-size:11px;color:var(--text3);font-weight:400;margin-left:8px">${rows.length} logged</span></div>`;

    rows.forEach(r => {
      const statusColors = {
        connected: 'var(--green)',
        voicemail: 'var(--yellow)',
        no_answer: 'var(--red)',
        email_sent: 'var(--accent)',
        meeting_set: 'var(--purple)'
      };
      const color = statusColors[r.status] || 'var(--text3)';

      html += '<div class="detail-card">';
      html += '<div class="detail-card-header">';
      html += `<div class="detail-card-title" style="display:flex;align-items:center;gap:6px">`;
      html += `<span style="width:8px;height:8px;border-radius:50%;background:${color};flex-shrink:0"></span>`;
      html += `${esc(r.activity_type || 'Activity')}`;
      html += '</div>';
      html += `<div class="detail-card-date">${esc(_fmtDate(r.activity_date))}</div>`;
      html += '</div>';
      html += '<div class="detail-card-body">';
      html += `<span style="font-size:11px;color:${color}">${esc(cleanLabel(r.status || ''))}</span>`;
      if (r.user_name) html += ` <span class="t-meta3">by ${esc(r.user_name)}</span>`;
      html += '</div></div>';
    });

    html += '</div>';
    el.innerHTML = html;
  } catch (e) {
    console.error('Touchpoints load error:', e);
    showToast('Failed to load touchpoints', 'error');
    el.innerHTML = '';
  }
}

/**
 * Refresh the current detail panel without re-opening.
 * Re-fetches data and re-renders the active tab.
 */
function refreshDetailPanel() {
  if (!_udCache) return;
  // Clear dirty flag on refresh (data is being reloaded — edits are either saved or intentionally discarded)
  _udFormDirty = false;
  const db = _udCache.db;
  const ids = _udCache.ids;
  const fallback = _udCache.fallback || _udCache;
  if (db && ids) {
    // Brief flash to signal data refresh
    const body = document.getElementById('detailBody');
    if (body) {
      body.style.opacity = '0.3';
      body.style.transition = 'opacity 0.15s ease-out';
      setTimeout(() => { body.style.opacity = '1'; }, 150);
    }
    openUnifiedDetail(db, ids, fallback);
  }
}

/**
 * Save ownership resolution from the unified detail Ownership tab form
 * Upserts to: recorded_owners, true_owners, contacts, research_queue_outcomes
 * Patches properties to link the owner IDs
 */
async function _udSaveOwnership(options = {}) {
  const refresh = options.refresh !== false;
  const silent = options.silent === true;
  if (!_udCache) { showToast('No record loaded', 'error'); return; }
  const db = _udCache.db;
  const propertyId = _udCache.ids?.property_id;
  if (!propertyId) { showToast('No property ID — cannot save ownership', 'error'); return; }

  const recordedOwner = document.getElementById('udOwnRecorded')?.value?.trim() || null;
  const trueOwner = document.getElementById('udOwnTrue')?.value?.trim() || null;
  const ownerType = document.getElementById('udOwnType')?.value || null;
  const contactName = document.getElementById('udOwnContact')?.value?.trim() || null;
  const contactPhone = document.getElementById('udOwnPhone')?.value?.trim() || null;
  const contactEmail = document.getElementById('udOwnEmail')?.value?.trim() || null;
  const incState = document.getElementById('udOwnState')?.value?.trim() || null;
  const notes = document.getElementById('udOwnNotes')?.value?.trim() || null;

  const _anyOwnField = [recordedOwner, trueOwner, ownerType, contactName, contactPhone, contactEmail, incState, notes].some(v => v !== null && v !== undefined && String(v).trim() !== '');
  if (!_anyOwnField) { showToast('Please fill in at least one ownership field', 'info'); return; }

  const proxyBase = db === 'gov' ? '/api/gov-query' : '/api/dia-query';
  let recordedOwnerId = _udCache.ids?.recorded_owner_id || null;
  let trueOwnerId = _udCache.ids?.true_owner_id || null;
  let contactId = _udCache.ids?.contact_id || null;

  try {
    // ── Government domain: use closed-loop write service ──
    if (db === 'gov') {
      const writeResult = await govWriteService('ownership', {
        property_id: propertyId,
        recorded_owner: recordedOwner,
        true_owner: trueOwner,
        owner_type: ownerType
      });

      if (!silent) showToast('Ownership resolution saved!', 'success');
      _udFormDirty = false;

      // Bridge to canonical model with gov change metadata
      canonicalBridge('save_ownership', {
        domain: 'government',
        external_id: String(propertyId),
        source_system: 'gov',
        source_type: 'asset',
        user_name: (typeof LCC_USER !== 'undefined' && LCC_USER.display_name) || 'unknown',
        owner_name: recordedOwner,
        true_owner_name: trueOwner,
        owner_type: ownerType,
        contact_name: contactName,
        notes: notes,
        gov_change_event_id: writeResult.change_event_id,
        gov_correlation_id: writeResult.correlation_id,
        source_record_id: propertyId,
        source_table: 'properties'
      });

      // Ensure canonical entity link exists for this gov property
      canonicalBridge('update_entity', {
        external_id: String(propertyId),
        source_system: 'gov',
        source_type: 'asset',
        fields: {
          name: _udCache.property?.address || _udCache.property?.page_title || `Property ${propertyId}`,
          address: _udCache.property?.address || null,
          city: _udCache.property?.city || null,
          state: _udCache.property?.state || null,
          asset_type: 'government_leased'
        }
      });

      if (refresh) refreshDetailPanel();
      return;
    }

    // ── Dialysis domain: keep existing direct-write flow ──
    let _ownPartialWarns = [];
    // 1. Upsert recorded_owners table
    if (recordedOwner) {
      const recordedOwnerPayload = {
        name: recordedOwner,
        state_of_incorporation: incState || null,
        normalized_name: recordedOwner.toLowerCase()
      };

      if (recordedOwnerId) {
        // PATCH existing via mutation service
        const patchResult = await applyChangeWithFallback({
          proxyBase,
          table: 'recorded_owners',
          idColumn: 'recorded_owner_id',
          idValue: recordedOwnerId,
          data: recordedOwnerPayload,
          source_surface: 'clinic_workspace'
        });
        if (!patchResult.ok) { console.error('Error patching recorded_owner:', (patchResult.errors || []).join(', ')); _ownPartialWarns.push('recorded owner'); }
      } else {
        const res = await applyInsertWithFallback({
          proxyBase,
          table: 'recorded_owners',
          data: recordedOwnerPayload,
          source_surface: 'ownership_detail',
          propagation_scope: 'ownership_helper_record'
        });
        if (res.ok) {
          const created = Array.isArray(res.rows) && res.rows.length > 0 ? res.rows[0] : null;
          if (created) recordedOwnerId = created.recorded_owner_id;
        } else {
          console.error('Error creating recorded_owner:', res.errors || []); _ownPartialWarns.push('recorded owner');
        }
      }
    }

    // 2. Upsert true_owners table
    if (trueOwner) {
      const trueOwnerPayload = {
        name: trueOwner,
        owner_type: ownerType || null,
        contact_1_name: contactName || null,
        notes: notes || null
      };

      if (trueOwnerId) {
        // PATCH existing via mutation service
        const patchResult = await applyChangeWithFallback({
          proxyBase,
          table: 'true_owners',
          idColumn: 'true_owner_id',
          idValue: trueOwnerId,
          data: trueOwnerPayload,
          source_surface: 'clinic_workspace'
        });
        if (!patchResult.ok) { console.error('Error patching true_owner:', (patchResult.errors || []).join(', ')); _ownPartialWarns.push('true owner'); }
      } else {
        const res = await applyInsertWithFallback({
          proxyBase,
          table: 'true_owners',
          data: trueOwnerPayload,
          source_surface: 'ownership_detail',
          propagation_scope: 'ownership_helper_record'
        });
        if (res.ok) {
          const created = Array.isArray(res.rows) && res.rows.length > 0 ? res.rows[0] : null;
          if (created) trueOwnerId = created.true_owner_id;
        } else {
          console.error('Error creating true_owner:', res.errors || []); _ownPartialWarns.push('true owner');
        }
      }
    }

    // 3. Upsert contacts table for contact info
    if (contactName || contactEmail || contactPhone) {
      const contactPayload = {
        name: contactName || null,
        email: contactEmail || null,
        phone: contactPhone || null,
        contact_type: 'owner'
      };

      if (contactId) {
        // PATCH existing via mutation service
        const patchResult = await applyChangeWithFallback({
          proxyBase,
          table: 'contacts',
          idColumn: 'contact_id',
          idValue: contactId,
          data: contactPayload,
          source_surface: 'clinic_workspace'
        });
        if (!patchResult.ok) { console.error('Error patching contact:', (patchResult.errors || []).join(', ')); _ownPartialWarns.push('contact'); }
      } else {
        const res = await applyInsertWithFallback({
          proxyBase,
          table: 'contacts',
          data: contactPayload,
          source_surface: 'ownership_detail',
          propagation_scope: 'ownership_contact_record'
        });
        if (res.ok) {
          const created = Array.isArray(res.rows) && res.rows.length > 0 ? res.rows[0] : null;
          if (created) contactId = created.contact_id;
        } else {
          console.error('Error creating contact:', res.errors || []); _ownPartialWarns.push('contact');
        }
      }
    }

    // 4. PATCH properties to link the owner IDs via mutation service
    if (recordedOwnerId || trueOwnerId) {
      const propertyPayload = {};
      if (recordedOwnerId) propertyPayload.recorded_owner_id = recordedOwnerId;
      if (trueOwnerId) propertyPayload.true_owner_id = trueOwnerId;

      const propResult = await applyChangeWithFallback({
        proxyBase,
        table: 'properties',
        idColumn: 'property_id',
        idValue: propertyId,
        data: propertyPayload,
        source_surface: 'clinic_workspace',
        notes: 'Ownership resolution — linking owner IDs'
      });
      if (!propResult.ok) { console.error('Error patching property owner links:', (propResult.errors || []).join(', ')); _ownPartialWarns.push('property links'); }
    }

    // 5. Save to research_queue_outcomes as a log entry
    const clinicId = _udCache.fallback?.clinic_id || _udCache.fallback?.medicare_id || null;
    if (clinicId) {
      const payload = {
        queue_type: 'ownership_resolution',
        clinic_id: clinicId,
        status: 'completed',
        notes: [
          recordedOwner ? 'Recorded Owner: ' + recordedOwner : null,
          trueOwner ? 'True Owner: ' + trueOwner : null,
          ownerType ? 'Type: ' + ownerType : null,
          contactName ? 'Contact: ' + contactName : null,
          contactPhone ? 'Phone: ' + contactPhone : null,
          contactEmail ? 'Email: ' + contactEmail : null,
          incState ? 'Inc. State: ' + incState : null,
          notes ? 'Notes: ' + notes : null
        ].filter(Boolean).join(' | '),
        selected_property_id: propertyId,
        assigned_at: new Date().toISOString()
      };
      const res = await applyInsertWithFallback({
        proxyBase,
        table: 'research_queue_outcomes',
        idColumn: 'clinic_id',
        recordIdentifier: clinicId,
        data: payload,
        source_surface: db === 'gov' ? 'gov_ownership_detail' : 'dialysis_ownership_detail',
        propagation_scope: 'research_queue_outcome'
      });
      if (!res.ok) { console.error('Error creating research_queue_outcome:', res.errors || []); _ownPartialWarns.push('outcome log'); }
    }

    if (_ownPartialWarns.length) {
      if (!silent) showToast('Saved with warnings — failed: ' + _ownPartialWarns.join(', '), 'error');
    } else {
      if (!silent) showToast('Ownership resolution saved!', 'success');
    }
    _udFormDirty = false;
    canonicalBridge('save_ownership', {
      domain: 'dialysis',
      external_id: String(propertyId),
      source_system: 'dia',
      source_type: 'asset',
      user_name: (typeof LCC_USER !== 'undefined' && LCC_USER.display_name) || 'unknown',
      owner_name: recordedOwner,
      true_owner_name: trueOwner,
      owner_type: ownerType,
      contact_name: contactName,
      notes: notes
    });
    if (refresh) refreshDetailPanel();
  } catch (e) {
    console.error('Ownership save error:', e);
    showToast('Error saving ownership: ' + e.message, 'error');
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// INTEL TAB SAVE FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════════

// Read-only summary of the most recent sale for this property. Renders into
// the #intelPriorSaleSummary slot on the Intel tab. Data source is the
// canonical property_sale_events table (falls back to v_property_latest_sale
// if the row already got there via a view).
async function _intelRenderPriorSaleSummaryAsync() {
  const slot = document.getElementById('intelPriorSaleSummary');
  if (!slot) return;
  const propertyId = _udCache?.ids?.property_id || _udCache?.property?.property_id;
  if (!propertyId) {
    slot.innerHTML = '<span class="t-muted3">No property ID — cannot load sale history.</span>';
    return;
  }
  const db = _udCache.db;
  const qFn = db === 'gov' ? govQuery : diaQuery;
  const propId = encodeURIComponent(propertyId);

  let latest = null;
  try {
    const res = await qFn('property_sale_events', '*', {
      filter: `property_id=eq.${propId}`,
      order: 'sale_date.desc.nullslast',
      limit: 1,
    }).catch(() => null);
    const rows = Array.isArray(res) ? res : (res?.data || []);
    latest = rows[0] || null;
  } catch (e) {
    console.warn('Prior sale summary fetch error:', e);
  }

  // Fall back to legacy sales_transactions when property_sale_events is empty.
  // Otherwise the Prior Sale banner reads "No sale recorded for this property
  // yet." while the Deal History timeline directly below it shows SALE cards
  // sourced from sales_transactions. Skip rows marked
  // exclude_from_market_metrics so consolidation-retired sales don't surface.
  if (!latest) {
    try {
      // exclude_from_market_metrics is nullable; downstream views treat NULL
      // as not-excluded (COALESCE(...,FALSE)=FALSE). `not.is.true` matches
      // FALSE OR NULL, mirroring that semantic. The query proxy parses one
      // condition per param, so the second filter goes through `filter2`.
      const stRes = await qFn('sales_transactions', '*', {
        filter: `property_id=eq.${propId}`,
        filter2: 'exclude_from_market_metrics=not.is.true',
        order: 'sale_date.desc.nullslast',
        limit: 1,
      }).catch(() => null);
      const stRows = Array.isArray(stRes) ? stRes : (stRes?.data || []);
      const st = stRows[0];
      if (st) {
        latest = {
          sale_date: st.sale_date,
          price: st.sold_price != null ? st.sold_price : st.price,
          cap_rate: st.cap_rate || null,
          buyer_name: st.buyer_name || st.buyer || null,
          seller_name: st.seller_name || st.seller || null,
          broker_name: st.broker_name || st.listing_broker || null,
          source: 'sales_transactions',
          notes: st.notes || null,
        };
      }
    } catch (e) {
      console.warn('Prior sale fallback (sales_transactions) error:', e);
    }
  }

  // Final fallback: ownership chain sale data (only for entries with a
  // populated sale_price; skip operator-chain relics which never carry one).
  if (!latest) {
    const chain = _udCache?.chain || [];
    const chainSale = chain.find(h => h.sale_price && h.sale_price > 0 &&
      String(h.ownership_source || '').toLowerCase() !== 'cms_operator_chain');
    if (chainSale) {
      latest = {
        sale_date: chainSale.transfer_date,
        price: chainSale.sale_price,
        cap_rate: chainSale.stated_cap_rate || chainSale.calculated_cap_rate || chainSale.cap_rate || null,
        buyer_name: chainSale.recorded_owner_name || chainSale.true_owner_name || chainSale.to_owner || chainSale.new_owner || null,
        seller_name: chainSale.seller_name || chainSale.from_owner || null,
        broker_name: chainSale.listing_broker || null,
        source: 'Ownership chain',
        notes: null
      };
    }
  }

  if (!latest) {
    // C1 (2026-06-06): offer the next action instead of dead-ending — jump to
    // the Deal History tab and open the Add Transaction form.
    slot.innerHTML = '<span class="t-muted3">No sale recorded for this property yet.</span> '
      + '<a href="javascript:void(0)" onclick="_udAddFirstSale()" style="color:var(--accent);font-weight:600">Add first sale →</a>';
    return;
  }

  const price = latest.price != null ? latest.price : latest.sold_price;
  const bits = [];
  if (latest.sale_date) bits.push(`<span class="t-muted3">Date:</span> <span class="t-body">${esc(_fmtDate(latest.sale_date))}</span>`);
  if (price != null)    bits.push(`<span class="t-muted3">Price:</span> <span class="mono" style="color:var(--green);font-weight:600">${fmt(price)}</span>`);
  if (latest.cap_rate != null) bits.push(`<span class="t-muted3">Cap:</span> <span style="color:var(--text);font-weight:600">${_fmtCapRate(latest.cap_rate)}</span>`);
  if (latest.buyer_name)  bits.push(`<span class="t-muted3">Buyer:</span> <span class="t-body">${esc(latest.buyer_name)}</span>`);
  if (latest.seller_name) bits.push(`<span class="t-muted3">Seller:</span> <span class="t-body">${esc(latest.seller_name)}</span>`);
  if (latest.broker_name) bits.push(`<span class="t-muted3">Broker:</span> <span class="t-body">${esc(latest.broker_name)}</span>`);

  let html = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px 14px;font-size:12px">';
  html += bits.map(b => `<div>${b}</div>`).join('');
  html += '</div>';
  if (latest.source) {
    html += `<div style="font-size:11px;color:var(--text3);margin-top:6px;font-style:italic">Source: ${esc(latest.source)}</div>`;
  }
  if (latest.notes) {
    html += `<div style="font-size:12px;color:var(--text2);margin-top:4px;border-top:1px solid var(--border);padding-top:6px">${esc(latest.notes)}</div>`;
  }
  slot.innerHTML = html;
}

async function _intelSavePriorSale(options = {}) {
  const refresh = options.refresh !== false;
  const silent = options.silent === true;
  if (!_udCache) { showToast('No record loaded', 'error'); return; }
  const propertyId = _udCache.ids?.property_id;
  if (!propertyId) { showToast('No property ID', 'error'); return; }
  const db = _udCache.db;
  const proxyBase = db === 'gov' ? '/api/gov-query' : '/api/dia-query';

  const saleDate = document.getElementById('intelSaleDate')?.value || null;
  const salePrice = document.getElementById('intelSalePrice')?.value || null;
  const capRate = document.getElementById('intelCapRateSale')?.value || null;
  const buyer = document.getElementById('intelBuyer')?.value?.trim() || null;
  const seller = document.getElementById('intelSeller')?.value?.trim() || null;

  const _anySaleField = [saleDate, salePrice, capRate, buyer, seller].some(v => v !== null && v !== undefined && String(v).trim() !== '');
  if (!_anySaleField) { showToast('Please fill in at least one sale field', 'info'); return; }

  try {
    // Canonical target: property_sale_events. The legacy sales_transactions
    // sink has been retired for write paths — the backfill migration mirrors
    // old rows forward and new rows always land in property_sale_events so
    // the DB trigger can mark concurrent listings Sold.
    const payload = {
      property_id: String(propertyId),
      sale_date: saleDate || null,
      price: _dpf(salePrice),
      cap_rate: _dpf(capRate),
      buyer_name: buyer,
      seller_name: seller
    };
    const res = await applyInsertWithFallback({
      proxyBase,
      table: 'property_sale_events',
      idColumn: 'property_id',
      recordIdentifier: propertyId,
      data: payload,
      source_surface: db === 'gov' ? 'gov_intel_detail' : 'dialysis_intel_detail',
      propagation_scope: 'prior_sale_record'
    });
    if (!res.ok) {
      // Round 76et-A: when called with silent=true (composite Save Reviewed Intel),
      // we MUST throw so the composite's try/catch knows the sub-save failed.
      // Previously this returned silently after the error toast, which let the
      // composite show "Saved reviewed Intel" even when prior-sale save failed.
      console.error('Sale save error:', res.errors || []);
      if (!silent) showToast('Error saving sale', 'error');
      throw new Error('prior sale: ' + (res.errors?.join('; ') || 'save failed'));
    }
    _udFormDirty = false;
    if (!silent) showToast('Prior sale saved!', 'success');
    canonicalBridge('log_activity', {
      title: 'Prior sale recorded',
      domain: db === 'gov' ? 'government' : 'dialysis',
      source_system: db === 'gov' ? 'gov' : 'dia',
      external_id: String(propertyId),
      user_name: (typeof LCC_USER !== 'undefined' && LCC_USER.display_name) || 'unknown',
      property_name: _udCache.property?.page_title || _udCache.property?.facility_name || _udCache.property?.address || null,
      metadata: { sale_date: saleDate, sale_price: salePrice, buyer: buyer, seller: seller }
    });
    if (refresh) refreshDetailPanel();
  } catch (e) {
    console.error('Prior sale save error:', e);
    // Round 76et-A: when called silently (composite), rethrow so the caller's
    // try/catch knows this sub-save failed; otherwise surface the error toast.
    if (silent) throw e;
    showToast('Error: ' + e.message, 'error');
  }
}

async function _intelSaveLoan(options = {}) {
  const refresh = options.refresh !== false;
  const silent = options.silent === true;
  if (!_udCache) { showToast('No record loaded', 'error'); return; }
  const propertyId = _udCache.ids?.property_id;
  if (!propertyId) { showToast('No property ID', 'error'); return; }
  const db = _udCache.db;
  const proxyBase = db === 'gov' ? '/api/gov-query' : '/api/dia-query';

  const lender = document.getElementById('intelLender')?.value?.trim() || null;
  const loanAmount = document.getElementById('intelLoanAmount')?.value || null;
  const interestRate = document.getElementById('intelInterestRate')?.value || null;
  const loanType = document.getElementById('intelLoanType')?.value || null;
  const origDate = document.getElementById('intelOrigDate')?.value || null;
  const matDate = document.getElementById('intelMatDate')?.value || null;
  const amortization = document.getElementById('intelAmortization')?.value || null;
  const recourse = document.getElementById('intelRecourse')?.value || null;
  const ltv = document.getElementById('intelLTV')?.value || null;

  const _anyLoanField = [lender, loanAmount, interestRate, loanType, origDate, matDate, amortization, recourse, ltv].some(v => v !== null && v !== undefined && String(v).trim() !== '');
  if (!_anyLoanField) { showToast('Please fill in at least one loan field', 'info'); return; }

  try {
    const payload = {
      property_id: propertyId,
      lender_name: lender,
      loan_amount: _dpf(loanAmount),
      interest_rate_percent: _dpf(interestRate),
      loan_type: loanType || null,
      origination_date: origDate || null,
      maturity_date: matDate || null,
      loan_term: amortization ? parseInt(amortization, 10) : null,
      recourse: recourse || null,
      loan_to_value: _dpf(ltv)
    };
    const res = await applyInsertWithFallback({
      proxyBase,
      table: 'loans',
      idColumn: 'property_id',
      recordIdentifier: propertyId,
      data: payload,
      source_surface: db === 'gov' ? 'gov_intel_detail' : 'dialysis_intel_detail',
      propagation_scope: 'loan_record'
    });
    if (!res.ok) {
      // Round 76et-A: bubble error so composite Save Reviewed Intel sees the failure.
      console.error('Loan save error:', res.errors || []);
      if (!silent) showToast('Error saving loan', 'error');
      throw new Error('loan: ' + (res.errors?.join('; ') || 'save failed'));
    }
    _udFormDirty = false;
    if (!silent) showToast('Loan info saved!', 'success');
    canonicalBridge('log_activity', {
      title: 'Loan recorded',
      domain: db === 'gov' ? 'government' : 'dialysis',
      source_system: db === 'gov' ? 'gov' : 'dia',
      external_id: String(propertyId),
      user_name: (typeof LCC_USER !== 'undefined' && LCC_USER.display_name) || 'unknown',
      property_name: _udCache.property?.page_title || _udCache.property?.facility_name || _udCache.property?.address || null,
      metadata: { lender: lender, loan_amount: loanAmount, loan_type: loanType, maturity_date: matDate }
    });
    if (refresh) refreshDetailPanel();
  } catch (e) {
    console.error('Loan save error:', e);
    if (silent) throw e;
    showToast('Error: ' + e.message, 'error');
  }
}

async function _intelSaveCashFlow(options = {}) {
  const refresh = options.refresh !== false;
  const silent = options.silent === true;
  if (!_udCache) { showToast('No record loaded', 'error'); return; }
  const propertyId = _udCache.ids?.property_id;
  if (!propertyId) { showToast('No property ID', 'error'); return; }
  const db = _udCache.db;
  const proxyBase = db === 'gov' ? '/api/gov-query' : '/api/dia-query';

  const annualRent = document.getElementById('intelAnnualRent')?.value || null;
  const rentPerSF = document.getElementById('intelRentPerSF')?.value || null;
  const expenseType = document.getElementById('intelExpenseType')?.value?.trim() || null;
  const estValue = document.getElementById('intelEstValue')?.value || null;
  const currentCapRate = document.getElementById('intelCurrentCapRate')?.value || null;

  const _anyCfField = [annualRent, rentPerSF, expenseType, estValue, currentCapRate].some(v => v !== null && v !== undefined && String(v).trim() !== '');
  if (!_anyCfField) { showToast('Please fill in at least one cash flow field', 'info'); return; }

  const annualRentN = _dpf(annualRent);
  const estValueN = _dpf(estValue);
  const partialWarns = [];
  let rentTarget = null; // 'lease' | 'anchor' | null

  try {
    // ── 1) ANNUAL RENT — route through leases (if active) else properties.anchor_rent.
    //    Never writes properties.last_known_rent: that legacy column has no
    //    provenance link and is never displayed as authoritative. See the
    //    rent-of-record policy in _udPickCurrentRent.
    if (annualRentN != null) {
      const activeLease = (_udCache.leases || [])
        .filter(l => l && l.lease_id
                  && String(l.status || '').toLowerCase() === 'active'
                  && l.is_active === true)
        .sort((a, b) => String(b.lease_start || '').localeCompare(String(a.lease_start || '')))[0];

      if (activeLease) {
        rentTarget = 'lease';
        const leasePayload = { annual_rent: annualRentN };
        // Don't downgrade from 'documented' — only promote null/inferred/estimated.
        if (String(activeLease.source_confidence || '').toLowerCase() !== 'documented') {
          leasePayload.source_confidence = 'estimated';
        }
        const leaseRes = await applyChangeWithFallback({
          proxyBase,
          table: 'leases',
          idColumn: 'lease_id',
          idValue: activeLease.lease_id,
          data: leasePayload,
          source_surface: 'clinic_workspace',
          notes: 'Intel → Cash Flow rent update'
        });
        if (!leaseRes.ok) {
          console.error('Lease rent update error:', (leaseRes.errors || []).join(', '));
          partialWarns.push('lease rent');
        }

        // Tier-guarded provenance write. If an existing tier-1 lease_document
        // rent exists, the RPC rejects the write and the denormalized column
        // change above is cosmetic — the provenance table still protects
        // downstream readers that consult lease_field_provenance.
        try {
          const url = new URL(proxyBase, window.location.origin);
          url.searchParams.set('table', 'rpc/upsert_lease_field');
          const rpcRes = await fetch(url.toString(), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              p_lease_id:      activeLease.lease_id,
              p_field_name:    'rent',
              p_field_value:   String(annualRentN),
              p_source_tier:   4,
              p_source_label:  'broker_package',
              p_captured_by:   'intel_form',
              p_source_file:   null,
              p_source_detail: null,
              p_notes:         'Intel → Cash Flow form'
            })
          });
          if (!rpcRes.ok) {
            const errText = await rpcRes.text();
            console.warn('upsert_lease_field non-OK:', rpcRes.status, errText);
          }
        } catch (e) {
          console.warn('upsert_lease_field call failed:', e);
        }
      } else {
        // No active lease row on the property — seed properties.anchor_rent so
        // _udPickCurrentRent has something to project. 'manual_entry' is tier 5
        // in the rent-of-record tier map (below documented lease rent, above
        // costar_stated anchors).
        rentTarget = 'anchor';
        const today = new Date().toISOString().slice(0, 10);
        const anchorRes = await applyChangeWithFallback({
          proxyBase,
          table: 'properties',
          idColumn: 'property_id',
          idValue: propertyId,
          data: {
            anchor_rent:        annualRentN,
            anchor_rent_date:   today,
            anchor_rent_source: 'manual_entry'
          },
          source_surface: 'clinic_workspace',
          notes: 'Intel → Cash Flow manual anchor rent'
        });
        if (!anchorRes.ok) {
          console.error('Anchor rent update error:', (anchorRes.errors || []).join(', '));
          partialWarns.push('anchor rent');
        }
      }
    }

    // ── 2) ESTIMATED VALUE — stays on properties.current_value_estimate.
    if (estValueN != null) {
      const propResult = await applyChangeWithFallback({
        proxyBase,
        table: 'properties',
        idColumn: 'property_id',
        idValue: propertyId,
        data: { current_value_estimate: estValueN },
        source_surface: 'clinic_workspace',
        notes: 'Cash flow / valuation update'
      });
      if (!propResult.ok) {
        console.error('Estimated value update error:', (propResult.errors || []).join(', '));
        partialWarns.push('estimated value');
      }
    }

    _udFormDirty = false;
    // Round 76et-A: when called silently and partial warnings exist, throw so
    // the composite Save Reviewed Intel sees the partial failure. The non-silent
    // path keeps the original "saved with issues" toast.
    if (!silent) {
      if (partialWarns.length > 0) {
        showToast('Cash flow saved with issues: ' + partialWarns.join(', '), 'error');
      } else {
        showToast('Cash flow / valuation saved!', 'success');
      }
    } else if (partialWarns.length > 0) {
      throw new Error('cash flow: ' + partialWarns.join(', ') + ' failed');
    }
    canonicalBridge('log_activity', {
      title: 'Cash flow estimate saved',
      domain: db === 'gov' ? 'government' : 'dialysis',
      source_system: db === 'gov' ? 'gov' : 'dia',
      external_id: String(propertyId),
      user_name: (typeof LCC_USER !== 'undefined' && LCC_USER.display_name) || 'unknown',
      property_name: _udCache.property?.page_title || _udCache.property?.facility_name || _udCache.property?.address || null,
      metadata: { annual_rent: annualRent, rent_target: rentTarget, estimated_value: estValue, cap_rate: currentCapRate }
    });
    if (refresh) refreshDetailPanel();
  } catch (e) {
    console.error('Cash flow save error:', e);
    if (silent) throw e;
    showToast('Error: ' + e.message, 'error');
  }
}

async function _intelSaveNotes(options = {}) {
  const refresh = options.refresh !== false;
  const silent = options.silent === true;
  if (!_udCache) { showToast('No record loaded', 'error'); return; }
  const propertyId = _udCache.ids?.property_id;
  if (!propertyId) { showToast('No property ID', 'error'); return; }
  const db = _udCache.db;
  const proxyBase = db === 'gov' ? '/api/gov-query' : '/api/dia-query';

  const notes = document.getElementById('intelResearchNotes')?.value?.trim() || null;
  const source = document.getElementById('intelResearchSource')?.value?.trim() || null;
  const dateFound = document.getElementById('intelResearchDate')?.value || null;

  if (!notes) { showToast('Please enter some research notes', 'error'); return; }

  try {
    const clinicId = _udCache.fallback?.clinic_id || _udCache.fallback?.medicare_id || null;
    const payload = {
      queue_type: 'intel_research',
      clinic_id: clinicId || null,
      status: 'completed',
      notes: [
        notes,
        source ? 'Source: ' + source : null,
        dateFound ? 'Date: ' + dateFound : null
      ].filter(Boolean).join(' | '),
      selected_property_id: propertyId,
      assigned_at: new Date().toISOString()
    };
    const res = await applyInsertWithFallback({
      proxyBase,
      table: 'research_queue_outcomes',
      idColumn: clinicId ? 'clinic_id' : 'selected_property_id',
      recordIdentifier: clinicId || propertyId,
      data: payload,
      source_surface: db === 'gov' ? 'gov_intel_detail' : 'dialysis_intel_detail',
      propagation_scope: 'research_queue_outcome'
    });
    if (!res.ok) {
      // Round 76et-A: bubble error so composite Save Reviewed Intel sees it.
      console.error('Notes save error:', res.errors || []);
      if (!silent) showToast('Error saving notes', 'error');
      throw new Error('notes: ' + (res.errors?.join('; ') || 'save failed'));
    }
    _udFormDirty = false;
    if (!silent) showToast('Research notes saved!', 'success');
    canonicalBridge('log_activity', {
      title: 'Research notes updated',
      domain: db === 'gov' ? 'government' : 'dialysis',
      source_system: db === 'gov' ? 'gov' : 'dia',
      external_id: String(propertyId),
      user_name: (typeof LCC_USER !== 'undefined' && LCC_USER.display_name) || 'unknown',
      property_name: _udCache.property?.page_title || _udCache.property?.facility_name || _udCache.property?.address || null,
      metadata: { notes: notes, source: source, date_found: dateFound }
    });
    if (refresh) refreshDetailPanel();
  } catch (e) {
    console.error('Notes save error:', e);
    if (silent) throw e;
    showToast('Error: ' + e.message, 'error');
  }
}

function _intelHasReviewedSectionValues() {
  return {
    priorSale: ['intelSaleDate', 'intelSalePrice', 'intelCapRateSale', 'intelBuyer', 'intelSeller'].some((id) => document.getElementById(id)?.value?.trim()),
    loan: ['intelLender', 'intelLoanAmount', 'intelInterestRate', 'intelLoanType', 'intelOrigDate', 'intelMatDate', 'intelAmortization', 'intelRecourse', 'intelLTV'].some((id) => document.getElementById(id)?.value?.trim()),
    cashFlow: ['intelAnnualRent', 'intelRentPerSF', 'intelExpenseType', 'intelEstValue', 'intelCurrentCapRate'].some((id) => document.getElementById(id)?.value?.trim()),
    notes: ['intelResearchNotes'].some((id) => document.getElementById(id)?.value?.trim()),
  };
}

async function _intelSaveReviewed() {
  const sections = _intelHasReviewedSectionValues();
  const planned = [
    sections.priorSale ? 'prior sale' : null,
    sections.loan ? 'loan' : null,
    sections.cashFlow ? 'cash flow' : null,
    sections.notes ? 'notes' : null,
  ].filter(Boolean);

  if (!planned.length) {
    showToast('No reviewed Intel fields to save', 'error');
    return;
  }

  try {
    if (sections.priorSale) await _intelSavePriorSale({ refresh: false, silent: true });
    if (sections.loan) await _intelSaveLoan({ refresh: false, silent: true });
    if (sections.cashFlow) await _intelSaveCashFlow({ refresh: false, silent: true });
    if (sections.notes) await _intelSaveNotes({ refresh: false, silent: true });
    showToast(`Saved reviewed Intel: ${planned.join(', ')}`, 'success');
    refreshDetailPanel();
  } catch (e) {
    console.error('Reviewed Intel save error:', e);
    showToast('Error saving reviewed Intel: ' + e.message, 'error');
  }
}

async function _udSaveReviewedOwnership() {
  const hasOwnershipValues = ['udOwnRecorded', 'udOwnTrue', 'udOwnType', 'udOwnContact', 'udOwnPhone', 'udOwnEmail', 'udOwnState', 'udOwnNotes']
    .some((id) => document.getElementById(id)?.value?.trim());
  if (!hasOwnershipValues) {
    showToast('No reviewed ownership fields to save', 'error');
    return;
  }
  await _udSaveOwnership({ refresh: true, silent: false });
}

// Expose to global scope
window._udBtnGuard = _udBtnGuard;
window._udActionBtnGuard = _udActionBtnGuard;
window.openUnifiedDetail = openUnifiedDetail;
window.switchUnifiedTab = switchUnifiedTab;

// ============================================================
// UI Phase 4C — sub-record drill (lease / sale) on the 4A back-stack
// ============================================================
// A focused, read-only view of one lease or sale, opened from a Rent Roll lease
// row or a Deal History sale row. It rides the SAME hash + back-stack substrate
// as property/entity details: opening PUSHes a `?d=sub:<kind>:<db>:<id>` history
// entry, "← Back" / the breadcrumb ascend to the parent property, and the iOS
// back-gesture pops one level (history.back → applyRoute reconciles). The record
// is resolved from the parent's in-memory caches when drilled in-app (no fetch);
// a cold deep-link best-effort fetches it. The parent `_udCache` is left intact
// so ascending re-renders the property without a reload.

function _udSubResolveFromCache(kind, db, id) {
  const sid = String(id);
  if (kind === 'lease') {
    const leases = (_udCache && Array.isArray(_udCache.leases)) ? _udCache.leases : [];
    return leases.find(l => l && String(l.lease_id) === sid) || null;
  }
  if (kind === 'sale') {
    const txns = (typeof _salesCache !== 'undefined' && _salesCache && Array.isArray(_salesCache.transactions))
      ? _salesCache.transactions : [];
    return txns.find(s => s && String(s.sale_id != null ? s.sale_id : s.id) === sid) || null;
  }
  return null;
}

async function _udSubFetch(kind, db, id) {
  const qFn = db === 'gov' ? govQuery : diaQuery;
  const enc = encodeURIComponent(id);
  if (kind === 'lease') {
    const r = await qFn('v_lease_detail', '*', { filter: `lease_id=eq.${enc}`, limit: 1 });
    const arr = Array.isArray(r) ? r : (r && r.data) || [];
    return arr[0] || null;
  }
  if (kind === 'sale') {
    let r = await qFn('sales_transactions', '*', { filter: `sale_id=eq.${enc}`, limit: 1 }).catch(() => null);
    let arr = Array.isArray(r) ? r : (r && r.data) || [];
    if (!arr.length) {
      r = await qFn('property_sale_events', '*', { filter: `id=eq.${enc}`, limit: 1 }).catch(() => null);
      arr = Array.isArray(r) ? r : (r && r.data) || [];
    }
    return arr[0] || null;
  }
  return null;
}

function _udSubLabel(kind, rec, id) {
  if (kind === 'lease') {
    const t = rec && (rec.tenant || rec.tenant_name);
    return t ? 'Lease — ' + t : 'Lease ' + id;
  }
  if (kind === 'sale') {
    const d = rec && rec.sale_date ? _fmtDate(rec.sale_date) : null;
    const p = rec ? (rec.price != null ? rec.price : (rec.sold_price != null ? rec.sold_price : rec.sale_price)) : null;
    if (p != null) return 'Sale — ' + fmt(p) + (d ? ' · ' + d : '');
    return d ? 'Sale — ' + d : 'Sale ' + id;
  }
  return String(id);
}

function _udRenderLeaseSubDetail(l, db) {
  const em = (_udCache && _udCache.entityMeta) || {};
  let html = '<div class="detail-section"><div class="detail-section-title">Lease Terms</div><div class="detail-grid">';
  html += _row('Tenant', l.tenant || l.tenant_name || em.tenant_name);
  html += _row('Commencement', _fmtDate(l.lease_start || l.lease_commencement || em.lease_commencement));
  html += _row('Expiration', _fmtDate(l.lease_expiration || em.lease_expiration));
  if (l.term_remaining_years != null) {
    const n = Number(l.term_remaining_years);
    html += _udLeaseRowH('Term Remaining', n < 0 ? '<span style="color:var(--red)">Expired</span>' : esc(n.toFixed(1) + ' yrs remaining'));
  } else {
    const tr = termRemaining(l.lease_expiration || em.lease_expiration);
    if (tr) html += _udLeaseRowH('Term Remaining', tr === 'Expired' ? '<span style="color:var(--red)">Expired</span>' : esc(tr));
  }
  html += _rowMoney('Annual Rent', l.annual_rent != null ? l.annual_rent : em.annual_rent);
  html += _rowMoney('Rent / SF', l.rent_psf != null ? l.rent_psf : em.rent_per_sf);
  html += _row('Expense Structure', l.expense_structure || em.expense_structure);
  html += _row('Renewal Options', l.renewal_options || em.renewal_options);
  html += _row('Guarantor', l.guarantor || em.guarantor);
  html += _row('Guarantor Type', l.guarantor_type);
  const escVal = (l.rent_cagr != null) ? esc((Number(l.rent_cagr) * 100).toFixed(2) + '%')
    : (em.rent_escalations ? esc(String(em.rent_escalations)) : null);
  html += _udLeaseRowH('Escalations', escVal);
  html += _row('Initial Term', l.initial_term_years ? Number(l.initial_term_years).toFixed(1) + ' yrs' : null);
  html += _row('Total Term', l.total_term_years ? Number(l.total_term_years).toFixed(1) + ' yrs' : null);
  html += _row('Termination', _fmtDate(l.termination_date));
  html += _row('Data Source', l.data_source);
  html += '</div></div>';
  const srcLink = _udSourceLink(l);
  if (srcLink) html += `<div class="detail-section"><div class="detail-section-title">Source Document</div>${srcLink}</div>`;
  return html;
}

function _udRenderSaleSubDetail(s, db) {
  // Reuse the entity-linked sale card (buyer/seller/broker become links).
  let html = '<div class="detail-section">';
  html += (typeof _udDealRenderSale === 'function') ? _udDealRenderSale(s) : _salesRenderSale(s);
  html += '</div>';

  // Cap-rate provenance (R59 / 76ek): quality + the NOI source table.
  const quality = s.cap_rate_quality || null;
  const noiTable = s.cap_rate_noi_source_table || null;
  if (quality || noiTable) {
    html += '<div class="detail-section"><div class="detail-section-title">Cap-Rate Provenance</div><div class="detail-grid">';
    if (quality) html += _row('Quality', quality);
    if (noiTable) html += _row('NOI Source', noiTable);
    html += '</div></div>';
  }

  const srcLink = _udSourceLink(s);
  if (srcLink) html += `<div class="detail-section"><div class="detail-section-title">Source Document</div>${srcLink}</div>`;
  return html;
}

async function openSubDetail(recordKind, db, id, record) {
  if (db === 'dialysis') db = 'dia';
  if (db === 'government') db = 'gov';
  if (!recordKind || id == null || id === '') return;

  const panel = document.getElementById('detailPanel');
  const overlay = document.getElementById('detailOverlay');
  const headerEl = document.getElementById('detailHeader');
  const tabsEl = document.getElementById('detailTabs');
  const bodyEl = document.getElementById('detailBody');
  if (!panel || !overlay || !bodyEl) return;
  panel.style.display = 'block';
  overlay.classList.add('open');

  // Resolve from the parent's caches first (drill-in-app — no fetch).
  let rec = record || _udSubResolveFromCache(recordKind, db, id);
  const label0 = _udSubLabel(recordKind, rec, id);

  if (headerEl) headerEl.innerHTML = `
    <button class="detail-back" onclick="detailBack()">&#x2190;<span>Back</span></button>
    <div class="detail-header-info">
      <div style="flex:1;min-width:0">
        <div class="detail-title" id="udSubTitle">${esc(label0)}</div>
        <div class="detail-subtitle">${recordKind === 'lease' ? 'Lease detail' : 'Sale detail'}</div>
      </div>
      <span class="detail-badge" style="background:${db === 'gov' ? 'var(--gov-green)' : 'var(--purple)'};color:#fff">${db === 'gov' ? 'GOV' : 'DIA'}</span>
    </div>
    <button class="detail-close" onclick="closeDetail()">&times;</button>`;
  if (tabsEl) tabsEl.innerHTML = '';   // a sub-detail is a single focused view — no tab bar

  // Hash PUSH + back-stack reconcile (one stack level == one ?d= history entry).
  if (typeof _routeSetDetailHash === 'function') {
    _routeSetDetailHash({ kind: 'sub', recordKind, db, id: String(id) });
  }
  if (typeof _detailStackSync === 'function') {
    _detailStackSync({ kind: 'sub', recordKind, db, id: String(id) }, label0);
  }

  if (rec) {
    bodyEl.innerHTML = recordKind === 'lease' ? _udRenderLeaseSubDetail(rec, db) : _udRenderSaleSubDetail(rec, db);
    return;
  }

  // Cold deep-link: best-effort fetch (the top descriptor is all the hash carries).
  bodyEl.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading…</p></div>';
  try { rec = await _udSubFetch(recordKind, db, id); } catch (_) { rec = null; }
  if (rec) {
    const label1 = _udSubLabel(recordKind, rec, id);
    const titleEl = document.getElementById('udSubTitle');
    if (titleEl) titleEl.textContent = label1;
    if (typeof _detailStackSetLabel === 'function') {
      _detailStackSetLabel({ kind: 'sub', recordKind, db, id: String(id) }, label1);
    }
    bodyEl.innerHTML = recordKind === 'lease' ? _udRenderLeaseSubDetail(rec, db) : _udRenderSaleSubDetail(rec, db);
  } else {
    bodyEl.innerHTML = `<div class="detail-empty" style="padding:36px;text-align:center">
      <div style="font-size:14px;color:var(--text2);margin-bottom:8px">This ${esc(recordKind)} isn't loaded.</div>
      <div style="font-size:12px;color:var(--text3)">Open it from its property's ${recordKind === 'lease' ? 'Rent Roll' : 'Deal History'} tab.</div>
    </div>`;
  }
}
window.openSubDetail = openSubDetail;

// Phase 4C Unit 3 — keyboard zoom-in: Enter/Space on a focused drill row opens
// its sub-detail (mirrors the owner/tenant-link keyboard pattern). Esc (zoom-out)
// is handled by the global Escape→detailBack handler in app.js.
document.addEventListener('keydown', function (e) {
  if (e.key !== 'Enter' && e.key !== ' ') return;
  const el = e.target && e.target.closest && e.target.closest('.ud-zoom-link[data-zoom]');
  if (!el) return;
  e.preventDefault();
  try {
    const parts = String(el.getAttribute('data-zoom') || '').split(':');
    if (parts.length >= 3) openSubDetail(parts[0], parts[1], parts.slice(2).join(':'));
  } catch (_) { /* ignore */ }
});

window.showUnifiedDetail = showUnifiedDetail;
window.refreshDetailPanel = refreshDetailPanel;
window._udSubmitLogCall = _udSubmitLogCall;
window._udPreviewTemplate = _udPreviewTemplate;
window._udSendTemplate = _udSendTemplate;
window._udCopyTemplate = _udCopyTemplate;
window._udGenerateDraft = _udGenerateDraft;
window._udSendDraft = _udSendDraft;
window._udCopyDraft = _udCopyDraft;
window._udRecordDraftSend = _udRecordDraftSend;
window._udSaveOwnership = _udSaveOwnership;
window._intelSavePriorSale = _intelSavePriorSale;
window._intelSaveLoan = _intelSaveLoan;
window._intelSaveCashFlow = _intelSaveCashFlow;
window._intelSaveNotes = _intelSaveNotes;
window._intelSaveReviewed = _intelSaveReviewed;
window._intelHandleIntakeFile = _intelHandleIntakeFile;
window._intelUpdateIntakeText = _intelUpdateIntakeText;
window._intelAnalyzeIntake = _intelAnalyzeIntake;
window._intelHandleIntakePaste = _intelHandleIntakePaste;
window._intelCopyIntakeAnalysis = _intelCopyIntakeAnalysis;
window._intelApplyIntakeFields = _intelApplyIntakeFields;
window._intelApplyIntakeAnalysis = _intelApplyIntakeAnalysis;
window._intelClearIntake = _intelClearIntake;
window._udAskAssistant = _udAskAssistant;
window._udCopyAssistantReply = _udCopyAssistantReply;
window._udApplyAssistantFields = _udApplyAssistantFields;
window._udApplyAssistantReply = _udApplyAssistantReply;
window._udSaveReviewedOwnership = _udSaveReviewedOwnership;

// ============================================================================
// ENTITY & CONTACT DETAIL VIEWS
// ============================================================================

let _entityDetailCache = null;

/** Helper: build headers for ops API calls */
function _entityApiHeaders() {
  const h = { 'Content-Type': 'application/json' };
  if (typeof LCC_USER !== 'undefined' && LCC_USER.workspace_id) h['x-lcc-workspace'] = LCC_USER.workspace_id;
  return h;
}

/** Helper: fetch JSON from ops API with error handling */
async function _entityApiFetch(url) {
  const fetchFn = (typeof LCC_AUTH !== 'undefined' && LCC_AUTH.isAuthenticated) ? LCC_AUTH.apiFetch : fetch;
  const res = await fetchFn(url, { headers: _entityApiHeaders() });
  if (!res.ok) return null;
  return res.json();
}

/**
 * Open entity detail panel by entity ID (from ops DB).
 */
// UI Phase 4B — owner/entity detail parity. The owner is a first-class zoom
// object: it renders the SAME slide-over shell as the property detail
// (openUnifiedDetail) — a real tab bar (Overview · Portfolio · Contacts ·
// Activity), the shared completeness rail + Next-Step banner, and it rides the
// SAME 4A back-stack/breadcrumb. The portfolio is sourced from the
// authoritative BD spine (lcc_entity_portfolio_facts via /api/entities?action=
// portfolio), NOT a fuzzy v_ownership_current name-match, and the Next-Step
// reads v_priority_queue_enriched (the SAME truth as the Priority Queue /
// Decision Center). `initialTab` lets a reload / deep-link restore the open tab.
// Contact 360 tab grammar. "Ownership" = the BD portfolio (owns/former) + the
// developed edges; "Activity" is the unified LCC+SF timeline (broker-labeled);
// "Engagement" is the unified_contacts + marketing signals; "ROE" is the
// Rules-of-Engagement detail. The compact ROE verdict banner rides ABOVE every
// tab (so you can't step on another broker at a glance).
// The union of every entity-detail tab (used only for the initial deep-link
// validation before the role is known). The ACTUAL tab set is role-driven —
// see _entityTabsForRole. Broker mode swaps Ownership→Deals and drops Contacts.
const ENTITY_DETAIL_TABS = ['Overview', 'Ownership', 'Deals', 'Activity', 'Engagement', 'ROE', 'Contacts'];

/**
 * Role-aware tab set. Owner/buyer get Ownership (their portfolio); a broker gets
 * Deals (deal-intelligence) instead — no Ownership. The Contacts tab (the linked
 * people at an org) is shown ONLY for organization entities — never for a person
 * or broker, where it was the ~50 unrelated contacts (item #3).
 */
function _entityTabsForRole(role, entityType) {
  if (role === 'broker') return ['Overview', 'Deals', 'Activity', 'Engagement', 'ROE'];
  const tabs = ['Overview'];
  if (role === 'owner' || role === 'buyer') tabs.push('Ownership');
  tabs.push('Activity', 'Engagement', 'ROE');
  if (entityType === 'organization') tabs.push('Contacts');
  return tabs;
}

async function openEntityDetail(entityId, initialTab) {
  _entityDetailCache = null;
  // A fresh entity open resets any stale companion property dock (it's anchored
  // to the previously-open contact/owner).
  if (typeof closeCompanion === 'function') closeCompanion();
  const panel = document.getElementById('detailPanel');
  const overlay = document.getElementById('detailOverlay');
  if (!panel || !overlay) return;

  panel.style.display = 'block';
  overlay.classList.add('open');

  const activeTab = ENTITY_DETAIL_TABS.includes(initialTab) ? initialTab : ENTITY_DETAIL_TABS[0];

  // Client routing (UI Phase 1 + 4B): mirror the open entity + tab into the hash
  // so a reload / deep-link re-opens this exact view. Loop-guarded.
  if (typeof _routeSetDetailHash === 'function') {
    _routeSetDetailHash({ kind: 'entity', id: entityId, tab: activeTab });
  }
  // UI Phase 4: reconcile the back-stack (entity is a first-class zoom level).
  if (typeof _detailStackSync === 'function') {
    _detailStackSync({ kind: 'entity', id: entityId, tab: activeTab });
  }

  const headerEl = document.getElementById('detailHeader');
  const tabsEl = document.getElementById('detailTabs');
  const bodyEl = document.getElementById('detailBody');

  // Reset the shared rail / Next-Step / next-action chrome so a prior property's
  // content never lingers under the entity panel while it loads.
  _entityHideRailChrome();

  // Loading state
  if (headerEl) headerEl.innerHTML = `
    <button class="detail-back" onclick="detailBack()">&#x2190;<span>Back</span></button>
    <div class="detail-header-info">
      <div style="flex:1;min-width:0">
        <div class="detail-title">Loading entity...</div>
        <div class="detail-subtitle"></div>
      </div>
      <span class="detail-badge" style="background:var(--accent);color:#fff">ENTITY</span>
    </div>
    <button class="detail-close" onclick="closeDetail()">&times;</button>`;
  if (tabsEl) tabsEl.innerHTML = '';
  if (bodyEl) bodyEl.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading entity details...</p></div>';

  try {
    // Contact 360 — ONE aggregating fetch composes the entity (+ identities /
    // relationships), the BD portfolio, the unified LCC+SF timeline, engagement,
    // marketing signals, the SF-account owner, and the ROE verdict. The priority
    // band (Next-Step) + the contacts list load in the same parallel round (band
    // stays in its dedicated route; contacts drive the Contacts tab CTA).
    const [c360, contactsData, band] = await Promise.all([
      _entityApiFetch('/api/entities?action=contact360&id=' + encodeURIComponent(entityId)).catch(() => null),
      _entityApiFetch('/api/contacts?action=list&entity_id=' + encodeURIComponent(entityId) + '&limit=50').catch(() => null),
      _entityApiFetch('/api/priority-band?entity_id=' + encodeURIComponent(entityId)).catch(() => null)
    ]);

    const entity = c360?.entity || null;
    if (!entity) {
      if (bodyEl) bodyEl.innerHTML = '<div class="detail-empty">Entity not found</div>';
      return;
    }

    const contacts = contactsData?.contacts || [];
    const portfolio = (c360 && c360.portfolio && Array.isArray(c360.portfolio.properties)) ? c360.portfolio.properties : [];
    const rollup = (c360 && c360.portfolio && c360.portfolio.rollup) || null;

    // Role drives the whole layout (owner-portfolio vs broker deal-intel + which
    // tabs render + whether the owner BD-queue chrome shows). From contact360.
    const role = (c360 && c360.role) || 'contact';
    const tabs = _entityTabsForRole(role, entity.entity_type);
    // A person contact with direct/affiliated ownership gets an Ownership tab so
    // the person-level linked-properties section (Contact 360 refinement) is reachable.
    const _ownedP = (c360 && c360.owned_properties) || null;
    const _hasOwned = _ownedP && ((_ownedP.direct && _ownedP.direct.length) || (_ownedP.affiliated && _ownedP.affiliated.properties && _ownedP.affiliated.properties.length));
    if (_hasOwned && !tabs.includes('Ownership')) tabs.splice(1, 0, 'Ownership');
    const effectiveTab = tabs.includes(activeTab) ? activeTab : tabs[0];

    _entityDetailCache = {
      entity, entityId, contacts, portfolio, rollup, band, type: 'entity',
      role, tabs,
      brokerIntel: (c360 && c360.broker_intel) || null,
      emailRel: (c360 && c360.email_relationship) || null,
      // Contact 360 blocks
      timeline: (c360 && c360.timeline) || [],
      engagement: (c360 && c360.engagement) || null,
      marketing: (c360 && c360.marketing) || [],
      openTasks: (c360 && c360.open_tasks) || [],
      ownedProperties: (c360 && c360.owned_properties) || null,
      developed: (c360 && c360.developed) || [],
      accountOwner: (c360 && c360.account_owner) || null,
      roe: (c360 && c360.roe) || null,
      subject: (c360 && c360.subject) || null,
      // Back-compat: some render paths read `activities`; the unified timeline
      // supersedes it (LCC events are the source-'lcc' items).
      activities: (c360 && c360.timeline) || [],
    };

    // Render header
    const typeBadge = (entity.entity_type || 'org').toUpperCase();
    const statusColor = entity.status === 'active' ? 'var(--green)' : 'var(--text3)';
    // UI Phase 4: refine this level's breadcrumb crumb to the loaded entity name.
    if (typeof _detailStackSetLabel === 'function' && entity.name) {
      _detailStackSetLabel({ kind: 'entity', id: entityId }, entity.name);
    }
    if (headerEl) headerEl.innerHTML = `
      <button class="detail-back" onclick="detailBack()">&#x2190;<span>Back</span></button>
      <div class="detail-header-info">
        <div style="flex:1;min-width:0">
          <div class="detail-title">${esc(entity.name)}</div>
          <div class="detail-subtitle">${esc((entity.city || '') + (entity.city && entity.state ? ', ' : '') + (entity.state || ''))}</div>
          <div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap">
            <span style="font-size:10px;padding:2px 8px;border-radius:10px;background:var(--accent);color:#fff;font-weight:600">${esc(typeBadge)}</span>
            ${entity.domain ? '<span style="font-size:10px;padding:2px 8px;border-radius:10px;background:var(--s3);color:var(--text2)">' + esc(entity.domain) + '</span>' : ''}
            <span style="font-size:10px;padding:2px 8px;border-radius:10px;color:${statusColor};border:1px solid ${statusColor}">${esc(entity.status || 'active')}</span>
          </div>
        </div>
        <span class="detail-badge" style="background:var(--accent);color:#fff">ENTITY</span>
      </div>
      <button class="detail-close" onclick="closeDetail()">&times;</button>`;

    // Render tabs (property-detail grammar) — role-driven set.
    if (tabsEl) tabsEl.innerHTML = tabs.map(t =>
      '<button class="detail-tab ' + (t === effectiveTab ? 'active' : '') + '" onclick="switchEntityTab(decodeURIComponent(\'' + encodeURIComponent(t) + '\'))">' + esc(t) + '</button>'
    ).join('');

    // Shared rail + Next-Step are the OWNER BD-queue chrome (connection/portfolio
    // completeness + the priority-band next action) — only meaningful for
    // owner/buyer entities. A broker/plain contact leaves them hidden (item #5).
    if (role === 'owner' || role === 'buyer') {
      _entityRenderCompletenessRail();
      _entityRenderNextStep();
    }

    if (bodyEl) bodyEl.innerHTML = _renderEntityTab(effectiveTab);
  } catch (err) {
    console.error('Entity detail error:', err);
    if (bodyEl) bodyEl.innerHTML = '<div class="detail-empty">Error loading entity: ' + esc(err.message) + '</div>';
  }
}
window.openEntityDetail = openEntityDetail;

// ── Contact 360 — the ONE reusable trigger (Deals cards, Contacts view, the
// coming Marketing tab). Takes a contact/entity id and opens the canonical
// Contact 360 panel. Works for any contact:
//   • an owner ENTITY id (or opts.kind==='entity' / opts.entity_id) → opens directly
//   • a unified_contacts row → resolve its entity_id, then open the entity panel
//   • a plain person/broker contact with NO entity → fall back to the lighter
//     openContactDetail drawer (contacts-ui.js) so a broker still resolves.
async function openContact360(id, opts = {}) {
  if (!id) return;
  const tab = opts.tab || 'Overview';
  // Caller already knows the entity id.
  if (opts.entity_id) { openEntityDetail(opts.entity_id, tab); return; }
  if (opts.kind === 'entity') { openEntityDetail(id, tab); return; }

  // Resolve a unified_contacts row → its owning/self person entity.
  try {
    const data = await _entityApiFetch('/api/contacts?action=get&id=' + encodeURIComponent(id)).catch(() => null);
    const eid = data && data.contact && data.contact.entity_id;
    if (eid) { openEntityDetail(eid, tab); return; }
    // A real contact row with no linked entity → the lighter drawer resolves it.
    if (data && data.contact && typeof openContactDetail === 'function') { openContactDetail(id); return; }
  } catch (_) { /* fall through */ }

  // Not a unified_contacts row (or lookup failed): the light drawer if present,
  // else best-effort open as an entity.
  if (typeof openContactDetail === 'function') { openContactDetail(id); return; }
  openEntityDetail(id, tab);
}
window.openContact360 = openContact360;

/** Open entity detail by name search (when only name is available) */
async function openEntityDetailByName(name) {
  if (!name) return;
  const panel = document.getElementById('detailPanel');
  const overlay = document.getElementById('detailOverlay');
  if (!panel || !overlay) return;

  panel.style.display = 'block';
  overlay.classList.add('open');

  const headerEl = document.getElementById('detailHeader');
  const bodyEl = document.getElementById('detailBody');
  const tabsEl = document.getElementById('detailTabs');

  if (headerEl) headerEl.innerHTML = `
    <button class="detail-back" onclick="closeDetail()">&#x2190;<span>Back</span></button>
    <div class="detail-header-info">
      <div style="flex:1;min-width:0">
        <div class="detail-title">${esc(name)}</div>
        <div class="detail-subtitle">Searching...</div>
      </div>
      <span class="detail-badge" style="background:var(--accent);color:#fff">ENTITY</span>
    </div>
    <button class="detail-close" onclick="closeDetail()">&times;</button>`;
  if (bodyEl) bodyEl.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Looking up entity...</p></div>';
  if (tabsEl) tabsEl.innerHTML = '';

  try {
    const data = await _entityApiFetch('/api/entities?action=search&q=' + encodeURIComponent(name));
    const entities = data?.entities || [];

    if (entities.length === 1) {
      // Exact single match — open it
      openEntityDetail(entities[0].id);
      return;
    }

    if (entities.length > 1) {
      // Multiple matches — show list to pick from
      let html = '<div class="detail-section"><div class="detail-section-title">Multiple entities found for "' + esc(name) + '"</div>';
      html += '<div style="display:flex;flex-direction:column;gap:6px;margin-top:8px">';
      for (const e of entities) {
        const loc = (e.city || '') + (e.city && e.state ? ', ' : '') + (e.state || '');
        html += '<div onclick="openEntityDetail(\'' + esc(e.id) + '\')" style="padding:10px 12px;background:var(--s2);border:1px solid var(--border);border-radius:8px;cursor:pointer;display:flex;gap:12px;align-items:center">';
        html += '<div style="flex:1;min-width:0"><div style="font-weight:600;color:var(--text)">' + esc(e.name) + '</div>';
        html += '<div style="font-size:11px;color:var(--text2)">' + esc(e.entity_type || '') + (loc ? ' · ' + esc(loc) : '') + '</div></div>';
        html += '<span style="font-size:10px;padding:2px 8px;border-radius:10px;background:var(--s3);color:var(--text2)">' + esc(e.entity_type || 'org') + '</span>';
        html += '</div>';
      }
      html += '</div></div>';
      if (bodyEl) bodyEl.innerHTML = html;
      return;
    }

    // No matches — show not found with helpful message
    if (bodyEl) bodyEl.innerHTML = '<div class="detail-empty">No entity found matching "' + esc(name) + '".<br><span class="t-meta3-sm">Try the Entities page to search or create one.</span></div>';
  } catch (err) {
    console.error('Entity lookup error:', err);
    if (bodyEl) bodyEl.innerHTML = '<div class="detail-empty">Error searching entities: ' + esc(err.message) + '</div>';
  }
}

/** Open contact detail panel by contact ID */
async function openContactDetail(contactId) {
  _entityDetailCache = null;
  const panel = document.getElementById('detailPanel');
  const overlay = document.getElementById('detailOverlay');
  if (!panel || !overlay) return;

  panel.style.display = 'block';
  overlay.classList.add('open');

  const headerEl = document.getElementById('detailHeader');
  const tabsEl = document.getElementById('detailTabs');
  const bodyEl = document.getElementById('detailBody');

  if (headerEl) headerEl.innerHTML = `
    <button class="detail-back" onclick="closeDetail()">&#x2190;<span>Back</span></button>
    <div class="detail-header-info">
      <div style="flex:1;min-width:0">
        <div class="detail-title">Loading contact...</div>
      </div>
      <span class="detail-badge" style="background:var(--purple);color:#fff">CONTACT</span>
    </div>
    <button class="detail-close" onclick="closeDetail()">&times;</button>`;
  if (bodyEl) bodyEl.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading contact details...</p></div>';

  try {
    const data = await _entityApiFetch('/api/contacts?action=get&id=' + encodeURIComponent(contactId));
    const contact = data?.contact || null;
    if (!contact) {
      if (bodyEl) bodyEl.innerHTML = '<div class="detail-empty">Contact not found</div>';
      return;
    }

    // Fetch activities if contact has a linked entity
    let activities = [];
    if (contact.entity_id) {
      try {
        const actData = await _entityApiFetch('/api/activities?entity_id=' + encodeURIComponent(contact.entity_id) + '&order=occurred_at.desc&limit=20');
        activities = actData?.activities || [];
      } catch (_) { /* ignore */ }
    }

    _entityDetailCache = { contact, activities, type: 'contact' };

    // Render header
    if (headerEl) headerEl.innerHTML = `
      <div class="detail-header-info">
        <div style="flex:1;min-width:0">
          <div class="detail-title">${esc(contact.full_name || contact.display_name || 'Unknown')}</div>
          <div class="detail-subtitle">${esc(contact.title || '')}${contact.title && contact.company_name ? ' at ' : ''}${esc(contact.company_name || '')}</div>
        </div>
        <span class="detail-badge" style="background:var(--purple);color:#fff">CONTACT</span>
        <button class="detail-close" onclick="closeDetail()">&times;</button>
      </div>`;

    // Tabs for contacts
    if (tabsEl) tabsEl.innerHTML = '<button class="detail-tab active" onclick="_switchContactTab(\'Details\')">Details</button><button class="detail-tab" onclick="_switchContactTab(\'Activity\')">Activity</button>';

    if (bodyEl) bodyEl.innerHTML = _renderContactTab(contact);
  } catch (err) {
    console.error('Contact detail error:', err);
    if (bodyEl) bodyEl.innerHTML = '<div class="detail-empty">Error loading contact: ' + esc(err.message) + '</div>';
  }
}

/** Open contact detail by name search */
async function openContactDetailByName(name) {
  if (!name) return;
  const panel = document.getElementById('detailPanel');
  const overlay = document.getElementById('detailOverlay');
  if (!panel || !overlay) return;

  panel.style.display = 'block';
  overlay.classList.add('open');

  const headerEl = document.getElementById('detailHeader');
  const bodyEl = document.getElementById('detailBody');
  const tabsEl = document.getElementById('detailTabs');

  if (headerEl) headerEl.innerHTML = `
    <button class="detail-back" onclick="closeDetail()">&#x2190;<span>Back</span></button>
    <div class="detail-header-info">
      <div style="flex:1;min-width:0">
        <div class="detail-title">${esc(name)}</div>
        <div class="detail-subtitle">Searching...</div>
      </div>
      <span class="detail-badge" style="background:var(--purple);color:#fff">CONTACT</span>
    </div>
    <button class="detail-close" onclick="closeDetail()">&times;</button>`;
  if (bodyEl) bodyEl.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Looking up contact...</p></div>';
  if (tabsEl) tabsEl.innerHTML = '';

  try {
    const data = await _entityApiFetch('/api/contacts?action=list&q=' + encodeURIComponent(name) + '&limit=10');
    const contacts = data?.contacts || [];

    if (contacts.length === 1) {
      openContactDetail(contacts[0].id);
      return;
    }

    if (contacts.length > 1) {
      let html = '<div class="detail-section"><div class="detail-section-title">Multiple contacts found for "' + esc(name) + '"</div>';
      html += '<div style="display:flex;flex-direction:column;gap:6px;margin-top:8px">';
      for (const c of contacts) {
        html += '<div onclick="openContactDetail(\'' + esc(c.id) + '\')" style="padding:10px 12px;background:var(--s2);border:1px solid var(--border);border-radius:8px;cursor:pointer">';
        html += '<div style="font-weight:600;color:var(--text)">' + esc(c.full_name || c.display_name || 'Unknown') + '</div>';
        html += '<div style="font-size:11px;color:var(--text2)">' + esc(c.title || '') + (c.company_name ? ' · ' + esc(c.company_name) : '') + '</div>';
        html += '</div>';
      }
      html += '</div></div>';
      if (bodyEl) bodyEl.innerHTML = html;
      return;
    }

    if (bodyEl) bodyEl.innerHTML = '<div class="detail-empty">No contact found matching "' + esc(name) + '"</div>';
  } catch (err) {
    console.error('Contact lookup error:', err);
    if (bodyEl) bodyEl.innerHTML = '<div class="detail-empty">Error searching contacts: ' + esc(err.message) + '</div>';
  }
}

// ── Entity Tab Switching (UI Phase 4B — mirrors switchUnifiedTab) ──
function switchEntityTab(tabName) {
  if (!_entityDetailCache || _entityDetailCache.type !== 'entity') return;
  // Guard against a tab not in this entity's role-driven set (e.g. a legacy
  // deep-link to Ownership on a broker) — fall back to the first tab.
  const tabs = _entityDetailCache.tabs;
  if (Array.isArray(tabs) && tabs.length && !tabs.includes(tabName)) tabName = tabs[0];
  // Mirror the tab into the hash (replace, so reload keeps it / no history noise),
  // exactly like the property detail's switchUnifiedTab.
  if (typeof _routeUpdateTabHash === 'function') _routeUpdateTabHash(tabName);
  document.querySelectorAll('#detailTabs .detail-tab').forEach(t => {
    t.classList.toggle('active', t.textContent.trim() === tabName);
  });
  const bodyEl = document.getElementById('detailBody');
  if (bodyEl) bodyEl.innerHTML = _renderEntityTab(tabName);
}
window.switchEntityTab = switchEntityTab;
// Back-compat alias (older onclick handlers referenced the underscore form).
function _switchEntityTab(tabName) { return switchEntityTab(tabName); }

function _renderEntityTab(tab) {
  if (!_entityDetailCache) return '<div class="detail-empty">No data loaded</div>';
  // The ROE verdict banner rides above every tab so the "don't step on another
  // broker" signal is always visible.
  const banner = _entityRoeBanner();
  let body;
  switch (tab) {
    case 'Overview': body = _entityTabOverview(); break;
    case 'Ownership': body = _entityTabPortfolio(); break;
    case 'Portfolio': body = _entityTabPortfolio(); break; // legacy alias
    case 'Deals': body = _entityTabBrokerDeals(); break;
    case 'Contacts': body = _entityTabContacts(); break;
    case 'Activity': body = _entityTabActivity(); break;
    case 'Engagement': body = _entityTabEngagement(); break;
    case 'ROE': body = _entityTabRoe(); break;
    default: body = '<div class="detail-empty">Unknown tab</div>';
  }
  return banner + body;
}

// ── ROE verdict banner (shared across tabs) ──
function _entityRoeColors(verdict) {
  if (verdict === 'do_not_call') return { bg: 'rgba(239,68,68,0.12)', bd: 'var(--red,#ef4444)', fg: 'var(--red,#ef4444)', icon: '\u{1F6D1}' };
  if (verdict === 'caution') return { bg: 'rgba(234,179,8,0.12)', bd: 'var(--yellow,#eab308)', fg: 'var(--yellow,#eab308)', icon: '\u{26A0}️' };
  return { bg: 'rgba(34,197,94,0.10)', bd: 'var(--green,#22c55e)', fg: 'var(--green,#22c55e)', icon: '\u{2705}' };
}
function _entityRoeBanner() {
  const roe = _entityDetailCache && _entityDetailCache.roe;
  if (!roe) return '';
  const col = _entityRoeColors(roe.verdict);
  const clickable = 'onclick="switchEntityTab(&quot;ROE&quot;)" style="cursor:pointer;';
  return '<div ' + clickable
    + 'display:flex;align-items:center;gap:8px;margin:0 0 12px;padding:8px 12px;border-radius:8px;'
    + 'background:' + col.bg + ';border:1px solid ' + col.bd + '">'
    + '<span style="font-size:15px">' + col.icon + '</span>'
    + '<div style="flex:1;min-width:0"><div style="font-weight:700;font-size:12px;color:' + col.fg + '">'
    + esc(roe.headline || 'Rules of Engagement') + '</div>'
    + (roe.reasons && roe.reasons.length
        ? '<div style="font-size:11px;color:var(--text2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + esc(roe.reasons[0]) + '</div>'
        : '')
    + '</div><span style="font-size:10px;color:var(--text3)">details ›</span></div>';
}

// Plain-language label + colour for a detected BD role (item #1 — the panel
// says what KIND of contact this is, prominently).
const _ENTITY_ROLE_META = {
  owner:   { label: 'Owner',   color: 'var(--accent)' },
  broker:  { label: 'Broker',  color: 'var(--amber, #d98c00)' },
  buyer:   { label: 'Buyer',   color: 'var(--purple)' },
  contact: { label: 'Contact', color: 'var(--text3)' },
};
function _entityRoleMeta(role) { return _ENTITY_ROLE_META[role] || _ENTITY_ROLE_META.contact; }

// ── Entity Overview Tab ──
function _entityTabOverview() {
  const c = _entityDetailCache;
  const e = c.entity;
  const role = c.role || 'contact';
  const rm = _entityRoleMeta(role);
  const contacts = c.contacts || [];
  const rollup = c.rollup || null;
  const propCount = rollup && rollup.total_property_count != null
    ? Number(rollup.total_property_count) : (c.portfolio?.length || 0);

  let html = '';

  // Role banner — the panel is no longer owner-framed; it states the role.
  html += '<div style="display:flex;align-items:center;gap:8px;margin:0 0 12px;padding:8px 12px;border-radius:8px;background:var(--s2);border-left:3px solid ' + rm.color + '">'
    + '<span style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.04em;color:' + rm.color + '">' + esc(rm.label) + '</span>';
  if (role === 'broker' && c.brokerIntel) {
    const bi = c.brokerIntel;
    html += '<span style="font-size:11px;color:var(--text2)">' + Number(bi.total_deals || 0) + ' deal' + (Number(bi.total_deals) === 1 ? '' : 's') + ' brokered in our markets</span>';
  } else if ((role === 'owner' || role === 'buyer') && propCount) {
    html += '<span style="font-size:11px;color:var(--text2)">' + propCount + ' propert' + (propCount === 1 ? 'y' : 'ies') + ' in the BD portfolio</span>';
  }
  html += '</div>';

  // Entity info section
  html += '<div class="detail-section"><div class="detail-section-title">Entity Information</div><div class="detail-grid">';
  html += _row('Name', e.name);
  html += _row('Role', rm.label);
  html += _row('Type', e.entity_type);
  html += _row('Domain', e.domain);
  html += _row('Org Type', e.org_type);
  if (e.email) html += _rowLink('Email', e.email, 'mailto:' + e.email);
  if (e.phone) html += _rowLink('Phone', e.phone, 'tel:' + e.phone);
  if (e.address) html += _row('Address', e.address);
  html += _row('City / State', (e.city || '') + (e.city && e.state ? ', ' : '') + (e.state || ''));
  html += '</div></div>';

  // External identities
  const extIds = e.external_identities || [];
  if (extIds.length) {
    html += '<div class="detail-section"><div class="detail-section-title">Linked Systems</div>';
    html += '<div style="display:flex;flex-wrap:wrap;gap:6px">';
    for (const ext of extIds) {
      html += '<span style="font-size:10px;padding:3px 8px;border-radius:6px;background:var(--s3);color:var(--text2);border:1px solid var(--border)">';
      html += esc(ext.source_system || '') + (ext.source_type ? ' · ' + esc(ext.source_type) : '');
      html += '</span>';
    }
    html += '</div></div>';
  }

  // Quick stats — role-aware. A broker shows deal-intelligence tiles (deals +
  // buyers/sellers represented), NOT owner-portfolio + the 50 unrelated contacts.
  const stat = (val, label, color, onclick) =>
    '<div style="text-align:center;padding:12px;background:var(--s2);border-radius:8px' + (onclick ? ';cursor:pointer' : '') + '"'
    + (onclick ? ' onclick="' + onclick + '"' : '') + '>'
    + '<div style="font-size:' + (String(val).length > 6 ? 16 : 20) + 'px;font-weight:700;color:' + color + '">' + val + '</div>'
    + '<div class="t-meta3">' + label + '</div></div>';
  const actTile = stat(c.timeline?.length || 0, 'Activities', 'var(--yellow, #eab308)', 'switchEntityTab(\'Activity\')');
  html += '<div class="detail-section"><div class="detail-section-title">Summary</div>';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px;margin-top:4px">';
  if (role === 'broker') {
    const bi = c.brokerIntel || {};
    html += stat(Number(bi.total_deals || 0), 'Deals brokered', 'var(--accent)', 'switchEntityTab(\'Deals\')');
    html += stat(Number(bi.represents_sellers || 0), 'Repr. sellers', 'var(--green)', 'switchEntityTab(\'Deals\')');
    html += stat(Number(bi.represents_buyers || 0), 'Repr. buyers', 'var(--purple)', 'switchEntityTab(\'Deals\')');
    html += actTile;
  } else {
    const rollupRent = rollup && rollup.current_annual_rent_total != null ? Number(rollup.current_annual_rent_total) : null;
    html += stat(propCount, 'Properties', 'var(--accent)', 'switchEntityTab(\'Ownership\')');
    html += stat(rollupRent ? _entityFmtMoney(rollupRent) : '—', 'Portfolio Rent', 'var(--green)', null);
    // Contacts tile only when the Contacts tab exists (org entities).
    if ((c.tabs || []).includes('Contacts')) html += stat(contacts.length, 'Contacts', 'var(--purple)', 'switchEntityTab(\'Contacts\')');
    html += actTile;
  }
  html += '</div></div>';

  // Open Tasks + Marketing follow-ups (Contact 360 refinement) — mirror the
  // Pipeline card "Open Tasks (N)" pattern; each links to its detail tab. The
  // linked deal/opportunity shows in the marketing follow-ups (deal_name).
  const _openN = (c.openTasks || []).length;
  const _mktN = (c.marketing || []).length;
  if (_openN || _mktN) {
    html += '<div class="detail-section"><div style="display:flex;gap:10px;flex-wrap:wrap">';
    html += '<div onclick="switchEntityTab(\'Activity\')" style="flex:1;min-width:130px;cursor:pointer;padding:10px 12px;background:var(--s2);border:1px solid var(--border);border-radius:8px">'
      + '<div style="font-size:16px;font-weight:700;color:var(--accent)">' + _openN + '</div>'
      + '<div class="t-meta3">Open Tasks →</div></div>';
    html += '<div onclick="switchEntityTab(\'Engagement\')" style="flex:1;min-width:130px;cursor:pointer;padding:10px 12px;background:var(--s2);border:1px solid var(--border);border-radius:8px">'
      + '<div style="font-size:16px;font-weight:700;color:var(--purple)">' + _mktN + '</div>'
      + '<div class="t-meta3">Marketing follow-ups →</div></div>';
    html += '</div></div>';
  }

  // Row-level action — Draft & Log (Topic F engine: renders a draft to Outlook,
  // logs a completed SF activity, advances the cadence — one call, honest status).
  const em = (c.subject && c.subject.email) || e.email || '';
  html += '<div class="detail-section"><div class="detail-section-title">Outreach</div>';
  html += '<button class="dns-cta" onclick="_entityDraftAndLog(this)">\u{270D}️ Draft &amp; Log →</button>';
  if (!em) html += '<div style="font-size:11px;color:var(--text3);margin-top:6px">No email on file — the draft opens without a recipient for you to fill.</div>';
  html += '<div id="entityDraftHost" style="margin-top:10px"></div>';
  html += '</div>';

  return html;
}

// Row-level Draft & Log for the panel subject — the Topic F engine
// (?action=draft_and_log), NOT the older _draftFromPipeline / log_to_sf split.
async function _entityDraftAndLog(btn) {
  const c = _entityDetailCache;
  if (!c || !c.entityId) return;
  const em = (c.subject && c.subject.email) || (c.entity && c.entity.email) || '';
  const name = (c.entity && c.entity.name) || '';
  const domain = (c.entity && c.entity.domain) || '';
  if (btn) { btn.disabled = true; btn.textContent = 'Drafting & logging…'; }
  const res = await _udApiPost('/api/operations?action=draft_and_log', {
    template_id: 'T-001',
    entity_id: c.entityId,
    context: { contact: { name: name, full_name: name }, property: { domain: domain }, domain: domain },
    domain: domain || null,
    name: name || null,
    to: em || null,
    mode: 'bd'
  });
  if (btn) { btn.disabled = false; btn.textContent = '\u{270D}️ Draft & Log →'; }
  const host = document.getElementById('entityDraftHost');
  if (!res || res.ok === false || !res.ok && res.error) {
    if (host) host.innerHTML = '<div style="color:var(--red,#ef4444);font-size:12px">Draft & Log failed: ' + esc((res && res.error) || 'unknown') + '</div>';
    return;
  }
  const d = res.draft || {};
  const sf = res.sf || {};
  const subject = d.subject || '';
  const bodyText = d.body || '';
  const status = [];
  if (d.created) status.push('✓ Draft in Outlook');
  else if (d.reason === 'no_recipient') status.push('⚠ add a recipient to draft in Outlook');
  else status.push('Draft ready — copy/paste below');
  if (sf.logged) status.push('✓ logged to Salesforce');
  else if (sf.reason === 'no_sf_contact') status.push('no SF contact — SF log skipped');
  else if (sf.reason === 'sf_not_configured') status.push('SF logging not configured yet');
  else status.push('SF log pending');
  if (res.cadence && res.cadence.advanced) status.push('cadence advanced');
  const mailto = 'mailto:' + encodeURIComponent(em) + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(bodyText);
  const openDraftBtn = d.web_link ? '<a class="dns-cta" href="' + esc(d.web_link) + '" target="_blank" rel="noopener">Open Outlook draft</a>' : '';
  if (host) host.innerHTML =
    (em ? '<div style="font-size:12px;margin-bottom:4px"><b>To:</b> ' + esc(em) + '</div>' : '')
    + '<div style="font-size:12px;margin-bottom:4px"><b>Subject:</b> ' + esc(subject) + '</div>'
    + '<textarea rows="8" style="width:100%;margin:4px 0;font-size:12px" id="entityDraftBody">' + esc(bodyText) + '</textarea>'
    + '<div style="display:flex;gap:8px;flex-wrap:wrap">'
    + '<button class="dns-cta" onclick="_entityCopyDraft()">Copy</button>'
    + '<a class="dns-cta" href="' + esc(mailto) + '" target="_blank" rel="noopener">Open in mail</a>'
    + openDraftBtn + '</div>'
    + '<div style="font-size:11px;color:var(--text3);margin-top:6px">' + esc(status.join(' · ')) + '</div>';
}
window._entityDraftAndLog = _entityDraftAndLog;

function _entityCopyDraft() {
  const ta = document.getElementById('entityDraftBody');
  if (ta && navigator.clipboard) navigator.clipboard.writeText(ta.value).then(() => {
    if (typeof showToast === 'function') showToast('Draft copied', 'success');
  }).catch(() => {});
}
window._entityCopyDraft = _entityCopyDraft;

// Compact $ formatter for the entity rollup figures.
function _entityFmtMoney(n) {
  const v = Number(n);
  if (!Number.isFinite(v) || v === 0) return '—';
  if (v >= 1e9) return '$' + (v / 1e9).toFixed(1) + 'B';
  if (v >= 1e6) return '$' + (v / 1e6).toFixed(v >= 10e6 ? 0 : 1) + 'M';
  if (v >= 1e3) return '$' + Math.round(v / 1e3) + 'K';
  return '$' + Math.round(v);
}

// ── Companion property dock (dual-panel, item #6) ─────────────────────────────
// Opens a focused property card BESIDE the contact/owner panel so both are
// visible at once. The row summary is looked up from the entity cache by index
// (no re-fetch, no escaping-in-onclick, no failure mode). "Open full ↗" promotes
// it to the main detail panel (the existing zoom path). On screens too narrow for
// two panels it falls back to the full single-panel open (existing behavior).
const DUAL_DOCK_MIN_WIDTH = 980;
let _companionState = null;

function _dualCapable() {
  return typeof window !== 'undefined' && window.innerWidth >= DUAL_DOCK_MIN_WIDTH;
}

// Drill a property clicked INSIDE a contact/owner panel. `source` selects the
// cache array (portfolio | developed | deal), `idx` the row. Dual-docks beside
// the contact when there's room; else the full single-panel open.
function _entityDrillProperty(db, propertyId, source, idx) {
  const c = _entityDetailCache || {};
  let row = {};
  if (source === 'portfolio') row = (c.portfolio || [])[idx] || {};
  else if (source === 'developed') row = (c.developed || [])[idx] || {};
  const summary = {
    address: row.address || row.name || null,
    city: row.city || null,
    state: row.state || null,
    tenant: row.tenant || null,
    rent: row.annual_rent != null ? _entityFmtMoney(row.annual_rent) : null,
    is_current: row.is_current,
  };
  if (_dualCapable()) { openCompanionProperty(db, propertyId, summary); return; }
  if (typeof openUnifiedDetail === 'function') openUnifiedDetail(db, { property_id: propertyId });
}
window._entityDrillProperty = _entityDrillProperty;

function openCompanionProperty(db, propertyId, summary = {}) {
  db = (db === 'gov' || db === 'government') ? 'gov' : 'dia';
  const panel = document.getElementById('companionPanel');
  const header = document.getElementById('companionHeader');
  const body = document.getElementById('companionBody');
  const minTab = document.getElementById('companionMin');
  if (!panel || !header || !body) { if (typeof openUnifiedDetail === 'function') openUnifiedDetail(db, { property_id: propertyId }); return; }
  if (minTab) minTab.classList.remove('open');
  panel.classList.add('open');
  panel.style.display = 'block';
  _companionState = { db, propertyId };

  const addr = summary.address || '(property)';
  const loc = (summary.city || '') + (summary.city && summary.state ? ', ' : '') + (summary.state || '');
  const badge = db.toUpperCase();
  header.innerHTML =
    '<div class="detail-header-info" style="width:100%">'
    + '<div style="flex:1;min-width:0"><div class="detail-title" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + esc(addr) + '</div>'
    + '<div class="detail-subtitle">' + esc(loc) + '</div></div>'
    + '<span class="detail-badge" style="background:' + (db === 'gov' ? 'var(--gov-green)' : 'var(--purple)') + ';color:#fff">' + esc(badge) + '</span>'
    + '<button class="detail-close" title="Minimize" onclick="minimizeCompanion()" style="margin:0 2px">&#8211;</button>'
    + '<button class="detail-close" title="Close" onclick="closeCompanion()">&times;</button>'
    + '</div>';

  const rows = [];
  const addRow = (l, v) => { if (v != null && v !== '') rows.push('<div style="display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid var(--border)"><span class="t-meta3">' + l + '</span><span style="font-size:12px;color:var(--text);text-align:right">' + esc(String(v)) + '</span></div>'); };
  addRow('Address', summary.address);
  addRow('City / State', loc);
  addRow(db === 'gov' ? 'Agency / Tenant' : 'Tenant', summary.tenant);
  addRow('Annual rent', summary.rent);
  if (summary.is_current === false) addRow('Status', 'Former');

  body.innerHTML =
    '<div class="detail-section"><div class="detail-section-title">Property</div>' + (rows.join('') || '<div class="detail-empty">No details.</div>') + '</div>'
    + '<div class="detail-section"><button class="dns-cta" onclick="_companionOpenFull()">Open full detail ↗</button>'
    + '<div style="font-size:11px;color:var(--text3);margin-top:6px">Full property panel — replaces this dock.</div></div>';
}
window.openCompanionProperty = openCompanionProperty;

function _companionOpenFull() {
  const s = _companionState;
  if (!s) return;
  closeCompanion();
  if (typeof openUnifiedDetail === 'function') openUnifiedDetail(s.db, { property_id: s.propertyId });
}
window._companionOpenFull = _companionOpenFull;

function minimizeCompanion() {
  const panel = document.getElementById('companionPanel');
  const minTab = document.getElementById('companionMin');
  if (panel) panel.classList.remove('open');
  if (minTab && _companionState) minTab.classList.add('open');
}
window.minimizeCompanion = minimizeCompanion;

function restoreCompanion() {
  const panel = document.getElementById('companionPanel');
  const minTab = document.getElementById('companionMin');
  if (minTab) minTab.classList.remove('open');
  if (panel && _companionState) { panel.classList.add('open'); panel.style.display = 'block'; }
}
window.restoreCompanion = restoreCompanion;

function closeCompanion() {
  const panel = document.getElementById('companionPanel');
  const minTab = document.getElementById('companionMin');
  if (panel) { panel.classList.remove('open'); panel.style.display = 'none'; }
  if (minTab) minTab.classList.remove('open');
  _companionState = null;
}
window.closeCompanion = closeCompanion;

// ── Entity Activity Tab ──
function _entityTabActivity() {
  const cache = _entityDetailCache || {};
  const timeline = cache.timeline || cache.activities || [];
  const activities = timeline;
  const entityId = cache.entityId || (cache.entity && cache.entity.id) || '';

  // Cortex W3 \u2014 unified relationship: email summary + recent thread sits ABOVE the
  // structured activity_events timeline (which carries calls/SF/meetings/etc.).
  let html = _renderEmailRelationshipCard(cache.emailRel, entityId);

  // Open Tasks (non-completed SF tasks) \u2014 Contact 360 refinement. dia carries no
  // WhatId, so the account (company_name) is the link; the opportunity/deal shows
  // under Marketing follow-ups (Engagement tab).
  const openTasks = cache.openTasks || [];
  if (openTasks.length) {
    html += '<div class="detail-section"><div class="detail-section-title">\u{1F4CC} Open Tasks (' + openTasks.length + ')</div>';
    html += '<div style="display:flex;flex-direction:column;gap:6px;margin-top:6px">';
    for (const t of openTasks) {
      html += '<div style="padding:8px 10px;background:var(--s2);border:1px solid var(--border);border-radius:8px">';
      html += '<div style="display:flex;justify-content:space-between;gap:8px"><div style="font-weight:600;font-size:12px;color:var(--text)">' + esc(t.subject || '(task)') + '</div><div style="font-size:10px;color:var(--text3)">' + esc(_fmtDate(t.date)) + '</div></div>';
      html += '<div style="font-size:10px;color:var(--text3);margin-top:3px;display:flex;gap:8px;flex-wrap:wrap">';
      if (t.status) html += '<span style="padding:1px 6px;border-radius:8px;background:var(--s3)">' + esc(t.status) + '</span>';
      if (t.account) html += '<span>Account: ' + esc(t.account) + '</span>';
      if (t.assigned_to) html += '<span>' + esc(t.assigned_to) + '</span>';
      html += '</div></div>';
    }
    html += '</div></div>';
  }

  if (!activities.length) {
    // Broker mode: a broker outside our firm often has no logged LCC/SF touch \u2014
    // surface their brokered-deal intelligence as the activity (item #4).
    if (cache.role === 'broker' && cache.brokerIntel && Number(cache.brokerIntel.total_deals)) {
      const bi = cache.brokerIntel;
      html += '<div class="detail-section"><div class="detail-section-title">Brokered-deal activity</div>';
      html += '<div style="font-size:12px;color:var(--text2);margin:4px 0 8px">No logged LCC / Salesforce touches \u2014 this broker\u2019s activity in our markets is the '
        + Number(bi.total_deals) + ' deal' + (Number(bi.total_deals) === 1 ? '' : 's') + ' they brokered ('
        + Number(bi.represents_sellers || 0) + ' seller-side \u00b7 ' + Number(bi.represents_buyers || 0) + ' buyer-side).</div>';
      html += '<button class="dns-cta" onclick="switchEntityTab(\'Deals\')">See brokered deals \u2192</button></div>';
      return html;
    }
    html += '<div class="detail-empty">No activity yet \u2014 LCC or Salesforce.</div>';
    return html;
  }

  const catIcon = { call: '\u{1F4DE}', email: '\u{1F4E7}', meeting: '\u{1F4C5}', note: '\u{1F4DD}', status_change: '\u{1F504}', assignment: '\u{1F464}', sync: '\u{1F500}', research: '\u{1F50D}', system: '\u{2699}\uFE0F' };

  html += '<div class="detail-section"><div class="detail-section-title">Activity Timeline (' + activities.length + ')</div>';
  html += '<div style="display:flex;flex-direction:column;gap:2px;margin-top:4px">';

  for (const a of activities) {
    // Unified rows carry {source,ts,category,title,body,broker,via,status}; a
    // legacy activity_events row (fallback) carries {occurred_at,category,users,source_type}.
    const date = _fmtDate(a.ts || a.occurred_at || a.created_at);
    const cat = a.category || '';
    const icon = catIcon[cat] || '\u{1F4CB}';
    const isSf = a.source === 'sf';
    const srcColor = isSf ? 'var(--purple)' : 'var(--accent)';
    const catLabel = cat ? cat.replace(/_/g, ' ') : '';
    const broker = a.broker || a.users?.display_name || '';
    // Highlight non-Team-Briggs (other NM broker) activity in amber \u2014 the ROE tell.
    const isTeam = /\b(briggs|sjc)\b/i.test(broker);
    const brokerColor = broker ? (isTeam ? 'var(--green)' : 'var(--amber, #d98c00)') : '';
    const via = a.via || a.source_type || '';

    html += '<div style="padding:10px 12px;border-left:3px solid ' + srcColor + ';margin-left:8px;position:relative">';
    html += '<div style="position:absolute;left:-10px;top:12px;width:14px;height:14px;border-radius:50%;background:var(--s1);border:2px solid ' + srcColor + ';font-size:8px;display:flex;align-items:center;justify-content:center">' + icon + '</div>';
    html += '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px">';
    html += '<div style="flex:1;min-width:0">';
    html += '<div style="font-weight:600;font-size:13px;color:var(--text)">' + esc(a.title || '(untitled)') + '</div>';
    if (a.body) html += '<div style="font-size:12px;color:var(--text2);margin-top:2px;white-space:pre-wrap;max-height:80px;overflow:hidden">' + esc(a.body) + '</div>';
    html += '<div style="font-size:10px;color:var(--text3);margin-top:4px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">';
    html += '<span style="padding:1px 6px;border-radius:8px;background:' + (isSf ? 'rgba(150,90,220,.16)' : 'var(--s3)') + ';font-weight:600">' + (isSf ? 'SF' : 'LCC') + '</span>';
    if (catLabel) html += '<span style="padding:1px 6px;border-radius:8px;background:var(--s3);text-transform:capitalize">' + esc(catLabel) + '</span>';
    if (broker) html += '<span style="padding:1px 6px;border-radius:8px;background:' + (isTeam ? 'rgba(60,170,90,.16)' : 'rgba(217,140,0,.16)') + ';color:' + brokerColor + ';font-weight:600">' + esc(broker) + '</span>';
    if (a.status) html += '<span>' + esc(a.status) + '</span>';
    if (via && via !== 'manual') html += '<span>via ' + esc(via) + '</span>';
    html += '</div></div>';
    html += '<div style="flex-shrink:0;font-size:11px;color:var(--text3);white-space:nowrap">' + esc(date) + '</div>';
    html += '</div></div>';
  }

  html += '</div></div>';
  return html;
}

// \u2500\u2500 Entity Engagement Tab (Contact 360) \u2500\u2500
// unified_contacts engagement summary + this contact's marketing_leads signals
// (aggregated onto the entity). marketing_leads has no viewed/clicked columns \u2014
// we surface source / activity_type / touchpoint_count / status honestly.
function _entityTabEngagement() {
  const c = _entityDetailCache || {};
  const eng = c.engagement || null;
  const marketing = c.marketing || [];

  let html = '';

  if (eng) {
    const score = eng.score != null ? Number(eng.score) : (eng.engagement_score != null ? Number(eng.engagement_score) : null);
    const touches = eng.total_touches != null ? Number(eng.total_touches) : (eng.total_touchpoints != null ? Number(eng.total_touchpoints) : null);
    const lastAct = eng.last_activity || eng.last_activity_at || eng.last_email || eng.last_call || null;
    const txns = eng.total_transactions != null ? Number(eng.total_transactions) : null;
    const vol = eng.total_volume != null ? Number(eng.total_volume) : null;
    html += '<div class="detail-section"><div class="detail-section-title">\u{1F4CA} Engagement</div>';
    html += '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin:8px 0">';
    html += '<div style="text-align:center;padding:10px;background:var(--s2);border-radius:8px"><div style="font-size:18px;font-weight:700;color:var(--accent)">' + (score != null ? score : '\u2014') + '</div><div class="t-meta3">Score</div></div>';
    html += '<div style="text-align:center;padding:10px;background:var(--s2);border-radius:8px"><div style="font-size:18px;font-weight:700;color:var(--text)">' + (touches != null ? touches : '\u2014') + '</div><div class="t-meta3">Touchpoints</div></div>';
    html += '<div style="text-align:center;padding:10px;background:var(--s2);border-radius:8px"><div style="font-size:13px;font-weight:600;color:var(--text)">' + (lastAct ? esc(_fmtDate(lastAct)) : '\u2014') + '</div><div class="t-meta3">Last activity</div></div>';
    html += '</div>';
    if (txns != null || vol != null) {
      html += '<div style="display:flex;gap:16px;font-size:11px;color:var(--text3)">';
      if (txns != null) html += '<span>Transactions: <strong style="color:var(--text2)">' + txns + '</strong></span>';
      if (vol != null) html += '<span>Volume: <strong style="color:var(--text2)">' + _entityFmtMoney(vol) + '</strong></span>';
      html += '</div>';
    }
    html += '</div>';
  }

  html += '<div class="detail-section"><div class="detail-section-title">\u{1F4E3} Marketing signals (' + marketing.length + ')</div>';
  if (!marketing.length) {
    html += '<div class="detail-empty" style="margin-top:6px">No marketing_leads signals on this contact.</div>';
  } else {
    html += '<div style="display:flex;flex-direction:column;gap:6px;margin-top:6px">';
    for (const m of marketing) {
      html += '<div style="padding:8px 10px;background:var(--s2);border-radius:8px">';
      html += '<div style="display:flex;justify-content:space-between;gap:8px"><div style="font-weight:600;font-size:12px;color:var(--text)">' + esc(m.deal_name || m.activity_type || m.source || '(signal)') + '</div><div style="font-size:10px;color:var(--text3)">' + esc(_fmtDate(m.lead_date)) + '</div></div>';
      html += '<div style="font-size:10px;color:var(--text3);margin-top:3px;display:flex;gap:8px;flex-wrap:wrap">';
      if (m.source) html += '<span style="padding:1px 6px;border-radius:8px;background:var(--s3)">' + esc(m.source) + '</span>';
      if (m.activity_type) html += '<span style="padding:1px 6px;border-radius:8px;background:var(--s3)">' + esc(m.activity_type) + '</span>';
      if (m.status) html += '<span>' + esc(m.status) + '</span>';
      if (m.touchpoint_count != null) html += '<span>' + Number(m.touchpoint_count) + ' touches</span>';
      if (m.assigned_to) html += '<span>' + esc(m.assigned_to) + '</span>';
      html += '</div>';
      if (m.activity_detail) html += '<div style="font-size:11px;color:var(--text2);margin-top:3px;max-height:40px;overflow:hidden">' + esc(m.activity_detail) + '</div>';
      html += '</div>';
    }
    html += '</div>';
  }
  html += '</div>';
  return html;
}

// \u2500\u2500 Entity Rules-of-Engagement Tab (Contact 360, Slice 2) \u2500\u2500
// The full ROE verdict + the assessment grid + the "why" reasons, from the
// contact360 endpoint's roe block (computed in api/_shared/roe.js).
function _entityTabRoe() {
  const c = _entityDetailCache || {};
  const roe = c.roe || null;

  if (!roe) {
    return '<div class="detail-empty">Rules of Engagement not available for this contact.</div>';
  }

  const col = _entityRoeColors(roe.verdict);
  let html = '';

  // The headline banner (same colours as the top-of-panel ROE banner).
  html += '<div class="detail-section">';
  html += '<div style="padding:14px 16px;border-radius:10px;background:' + col.bg + ';border:1px solid ' + col.bd + '">';
  html += '<div style="font-size:16px;font-weight:800;color:' + col.fg + '">' + esc(roe.headline || '') + '</div>';
  if (roe.assigned_broker) html += '<div style="font-size:12px;color:var(--text2);margin-top:4px">Assigned broker: <strong>' + esc(roe.assigned_broker) + '</strong>' + (roe.assigned_broker_source ? ' <span style="color:var(--text3)">(' + esc(roe.assigned_broker_source) + ')</span>' : '') + '</div>';
  html += '</div></div>';

  // Assessment grid.
  html += '<div class="detail-section"><div class="detail-section-title">Assessment</div>';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:6px">';
  const cell = (label, val) => '<div style="padding:10px;background:var(--s2);border-radius:8px"><div class="t-meta3">' + label + '</div><div style="font-size:13px;font-weight:600;color:var(--text);margin-top:2px">' + (val ? esc(val) : '\u2014') + '</div></div>';
  html += cell('Verdict', roe.verdict);
  html += cell('Account status', roe.account_status);
  html += cell('Assigned broker', roe.assigned_broker);
  html += cell('Broker class', roe.assigned_broker_class);
  if (roe.last_firm_touch) {
    const lt = roe.last_firm_touch;
    html += cell('Most recent firm touch', (lt.broker ? lt.broker + ' \u00B7 ' : '') + (lt.date ? _fmtDate(lt.date) : ''));
  }
  html += '</div></div>';

  // The "why" reasons.
  if (Array.isArray(roe.reasons) && roe.reasons.length) {
    html += '<div class="detail-section"><div class="detail-section-title">Why</div>';
    html += '<ul style="margin:6px 0 0 0;padding-left:18px;color:var(--text2);font-size:12px;line-height:1.7">';
    for (const r of roe.reasons) html += '<li>' + esc(r) + '</li>';
    html += '</ul></div>';
  }

  // Honest tip when there is no captured SF OwnerId (verdict rests on the
  // inferred deal-level / classifier signal, not a hard account assignment).
  if (roe.assigned_broker_source !== 'sf_owner') {
    html += '<div class="detail-section"><div style="font-size:11px;color:var(--text3);padding:8px 10px;background:var(--s2);border-radius:8px">No Salesforce account OwnerId on file for this contact yet \u2014 the verdict is inferred from deal-level activity. It sharpens once OwnerId is captured on the SF sync.</div></div>';
  }

  return html;
}

// ── Cortex W3 — Email Relationship card (corrected direction + recent thread) ──
function _renderEmailRelationshipCard(rel, entityId) {
  if (!rel || !rel.email) return '';  // no email on file → nothing to show
  const s = rel.summary || {};
  const total = Number(s.total || 0);
  const sent = Number(s.sent || 0);
  const received = Number(s.received || 0);
  const span = (s.first_at && s.last_at)
    ? _fmtDate(s.first_at) + ' → ' + _fmtDate(s.last_at) : '';

  let html = '<div class="detail-section"><div class="detail-section-title">\u{1F4E7} Email Relationship</div>';

  if (total > 0) {
    html += '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin:8px 0">';
    html += '<div style="text-align:center;padding:10px;background:var(--s2);border-radius:8px"><div style="font-size:18px;font-weight:700;color:var(--accent)">' + total + '</div><div class="t-meta3">Total</div></div>';
    html += '<div style="text-align:center;padding:10px;background:var(--s2);border-radius:8px"><div style="font-size:18px;font-weight:700;color:var(--green)">' + sent + '</div><div class="t-meta3">You sent</div></div>';
    html += '<div style="text-align:center;padding:10px;background:var(--s2);border-radius:8px"><div style="font-size:18px;font-weight:700;color:var(--purple)">' + received + '</div><div class="t-meta3">Received</div></div>';
    html += '</div>';
    if (span) html += '<div style="font-size:11px;color:var(--text3);margin-bottom:8px">' + esc(rel.email) + ' · ' + esc(span) + '</div>';
  } else {
    html += '<div style="font-size:12px;color:var(--text2);margin:6px 0">No email history pulled yet for ' + esc(rel.email) + '.</div>';
  }

  html += '<button id="cortexPullBtn" onclick="_cortexPullHistory(\'' + esc(entityId) + '\')" style="font-size:11px;padding:6px 12px;border-radius:8px;border:1px solid var(--accent);background:transparent;color:var(--accent);cursor:pointer;font-weight:600">\u{1F50D} Pull more from Outlook</button>';

  const recent = rel.recent || [];
  if (recent.length) {
    html += '<div style="display:flex;flex-direction:column;gap:1px;margin-top:10px">';
    for (const m of recent) {
      const out = m.dir === 'out';
      const arrow = out ? '<span style="color:var(--green)">↗ sent</span>' : '<span style="color:var(--purple)">↙ recv</span>';
      html += '<div style="padding:8px 10px;border-left:3px solid ' + (out ? 'var(--green)' : 'var(--purple)') + ';margin-left:6px">';
      html += '<div style="display:flex;justify-content:space-between;gap:8px"><div style="font-weight:600;font-size:12px;color:var(--text);flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(m.subject || '(no subject)') + '</div><div style="font-size:10px;color:var(--text3);white-space:nowrap">' + esc(_fmtDate(m.received_at)) + '</div></div>';
      html += '<div style="font-size:10px;color:var(--text3);margin-top:2px">' + arrow + (m.from_name ? ' · ' + esc(m.from_name) : '') + '</div>';
      if (m.preview) html += '<div style="font-size:11px;color:var(--text2);margin-top:3px;max-height:34px;overflow:hidden">' + esc(m.preview) + '</div>';
      html += '</div>';
    }
    html += '</div>';
  }

  html += '</div>';
  return html;
}

async function _cortexPullHistory(entityId) {
  const btn = document.getElementById('cortexPullBtn');
  if (btn) { btn.disabled = true; btn.textContent = 'Queuing…'; }
  try {
    const fetchFn = (typeof LCC_AUTH !== 'undefined' && LCC_AUTH.isAuthenticated) ? LCC_AUTH.apiFetch : fetch;
    const res = await fetchFn('/api/email-relationship?entity_id=' + encodeURIComponent(entityId), { method: 'POST', headers: _entityApiHeaders() });
    const d = await res.json().catch(() => ({}));
    if (btn) btn.textContent = d.queued ? '✓ Queued — pulls on next sync' : (d.error || 'Unable to queue');
  } catch (e) {
    if (btn) { btn.textContent = 'Error — try again'; btn.disabled = false; }
  }
}
window._cortexPullHistory = _cortexPullHistory;

// ── Entity Deals Tab (Broker mode) ──
// Replaces owner-portfolio for a broker: how many deals brokered in our target
// markets + who they represent (SELLERS via listing_broker / BUYERS via
// buyer_broker — the signal is on the LCC `brokers` edge, no cross-DB name-match).
function _entityTabBrokerDeals() {
  const c = _entityDetailCache || {};
  const bi = c.brokerIntel || null;
  if (!bi || !Number(bi.total_deals)) {
    return '<div class="detail-empty">No brokered deals linked to this broker in our target markets yet.</div>';
  }

  let html = '';

  // Headline tiles: total deals + representation split.
  html += '<div class="detail-section"><div class="detail-section-title">Deals brokered — our markets</div>';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-top:4px">';
  const tile = (v, l, col) => '<div style="text-align:center;padding:12px;background:var(--s2);border-radius:8px"><div style="font-size:20px;font-weight:700;color:' + col + '">' + v + '</div><div class="t-meta3">' + l + '</div></div>';
  html += tile(Number(bi.total_deals || 0), 'Deals', 'var(--accent)');
  html += tile(Number(bi.represents_sellers || 0), 'Represents sellers', 'var(--green)');
  html += tile(Number(bi.represents_buyers || 0), 'Represents buyers', 'var(--purple)');
  html += '</div>';
  if (Number(bi.represents_unknown)) {
    html += '<div style="font-size:11px;color:var(--text3);margin-top:6px">' + Number(bi.represents_unknown) + ' deal(s) with unrecorded side.</div>';
  }
  html += '</div>';

  // Target markets (states of the brokered assets).
  const markets = Array.isArray(bi.markets) ? bi.markets : [];
  if (markets.length) {
    html += '<div class="detail-section"><div class="detail-section-title">Target markets</div>';
    html += '<div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:4px">';
    for (const m of markets) {
      html += '<span style="font-size:11px;padding:3px 9px;border-radius:8px;background:var(--s3);color:var(--text2);border:1px solid var(--border)">'
        + esc(m.state) + ' <strong style="color:var(--text)">' + Number(m.count) + '</strong></span>';
    }
    html += '</div></div>';
  }

  // Recent brokered deals.
  const recent = Array.isArray(bi.recent_deals) ? bi.recent_deals : [];
  if (recent.length) {
    html += '<div class="detail-section"><div class="detail-section-title">Recent deals (' + recent.length + ')</div>';
    html += '<div style="display:flex;flex-direction:column;gap:6px;margin-top:4px">';
    for (const d of recent) {
      const loc = (d.city || '') + (d.city && d.state ? ', ' : '') + (d.state || '');
      const sideColor = d.role === 'seller' ? 'var(--green)' : d.role === 'buyer' ? 'var(--purple)' : 'var(--text3)';
      const sideLabel = d.role === 'seller' ? 'listing (seller)' : d.role === 'buyer' ? 'procuring (buyer)' : 'side n/a';
      html += '<div style="padding:9px 11px;background:var(--s2);border:1px solid var(--border);border-radius:8px">';
      html += '<div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start">';
      html += '<div style="flex:1;min-width:0"><div style="font-weight:600;font-size:12px;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + esc(d.name || '(property)') + '</div>';
      if (loc) html += '<div style="font-size:11px;color:var(--text2)">' + esc(loc) + '</div>';
      html += '</div>';
      html += '<span style="font-size:10px;padding:1px 7px;border-radius:8px;background:var(--s3);color:' + sideColor + ';font-weight:600;white-space:nowrap">' + esc(sideLabel) + '</span>';
      html += '</div></div>';
    }
    html += '</div></div>';
  }

  return html;
}

// ── Entity Portfolio Tab (UI Phase 4B — authoritative BD-spine portfolio) ──
// Sourced from lcc_entity_portfolio_facts ⋈ lcc_property_attributes (via
// /api/entities?action=portfolio), NOT a fuzzy v_ownership_current name-match.
// A rollup header (count / Σ rent / domains) over a per-property list where each
// row is a 4A zoom target — openUnifiedDetail PUSHes onto the back-stack.
function _entityTabPortfolio() {
  const c = _entityDetailCache;
  const portfolio = c?.portfolio || [];
  const rollup = c?.rollup || null;

  let html = '';

  // Rollup header (matches the queue/P-BUYER rollup the owner ranks on).
  if (rollup) {
    const total = rollup.total_property_count != null ? Number(rollup.total_property_count) : portfolio.length;
    const current = rollup.current_property_count != null ? Number(rollup.current_property_count) : null;
    const rent = rollup.current_annual_rent_total != null ? Number(rollup.current_annual_rent_total) : null;
    const domains = [];
    if (rollup.dia_property_count) domains.push(Number(rollup.dia_property_count) + ' DIA');
    if (rollup.gov_property_count) domains.push(Number(rollup.gov_property_count) + ' GOV');
    html += '<div class="detail-section"><div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">';
    html += '<div style="text-align:center;padding:10px;background:var(--s2);border-radius:8px"><div style="font-size:18px;font-weight:700;color:var(--accent)">' + total + '</div><div class="t-meta3">Properties' + (current != null && current !== total ? ' (' + current + ' current)' : '') + '</div></div>';
    html += '<div style="text-align:center;padding:10px;background:var(--s2);border-radius:8px"><div style="font-size:16px;font-weight:700;color:var(--green)">' + _entityFmtMoney(rent) + '</div><div class="t-meta3">Annual Rent</div></div>';
    html += '<div style="text-align:center;padding:10px;background:var(--s2);border-radius:8px"><div style="font-size:13px;font-weight:600;color:var(--text)">' + (domains.length ? esc(domains.join(' · ')) : '—') + '</div><div class="t-meta3">Mix</div></div>';
    html += '</div></div>';
  }

  // Developed section (Contact 360) — properties this owner is recorded as having
  // DEVELOPED (the `developed` relationship / ownership-chain / owner_parent),
  // resolved to names by the contact360 endpoint. Distinct from current ownership.
  const developed = c?.developed || [];
  if (developed.length) {
    html += '<div class="detail-section"><div class="detail-section-title">\u{1F3D7}️ Developed (' + developed.length + ')</div>';
    html += '<div style="display:flex;flex-direction:column;gap:6px;margin-top:6px">';
    for (let di = 0; di < developed.length; di++) {
      const d = developed[di];
      const db = (d.source_domain === 'gov' || d.source_domain === 'government') ? 'gov' : (d.source_domain === 'dia' || d.source_domain === 'dialysis' ? 'dia' : '');
      const pid = d.property_id != null ? d.property_id : d.source_property_id;
      const nm = d.name || d.address || d.label || '(property)';
      // Prefer opening the linked entity (developed edges resolve to entities);
      // fall back to a companion property dock when a property id is present.
      let onclick = '';
      if (d.entity_id) onclick = 'openContact360(\'' + esc(String(d.entity_id)) + '\', {kind:\'entity\'})';
      else if (db && pid != null) onclick = '_entityDrillProperty(\'' + esc(db) + '\', \'' + esc(String(pid)) + '\', \'developed\', ' + di + ')';
      const clickable = !!onclick;
      html += '<div style="padding:8px 10px;background:var(--s2);border:1px solid var(--border);border-radius:8px;' + (clickable ? 'cursor:pointer' : '') + '"';
      if (clickable) html += ' onclick="' + onclick + '"';
      html += '>';
      html += '<div style="font-weight:600;font-size:12px;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + esc(nm) + '</div>';
      if (d.city || d.state) html += '<div style="font-size:11px;color:var(--text2)">' + esc((d.city || '') + (d.city && d.state ? ', ' : '') + (d.state || '')) + '</div>';
      html += '</div>';
    }
    html += '</div></div>';
  }

  // Person-level ownership / linked properties (Contact 360 refinement) — a person
  // usually owns via their affiliated org, not directly. Show direct owner edges +
  // the affiliated org's BD portfolio (resolved by the contact360 endpoint).
  const owned = c?.ownedProperties || null;
  if (owned && ((owned.direct && owned.direct.length) || (owned.affiliated && owned.affiliated.properties && owned.affiliated.properties.length))) {
    if (owned.direct && owned.direct.length) {
      html += '<div class="detail-section"><div class="detail-section-title">\u{1F511} Owns directly (' + owned.direct.length + ')</div>';
      html += '<div style="display:flex;flex-direction:column;gap:6px;margin-top:6px">';
      for (const d of owned.direct) {
        const onclick = d.entity_id ? 'openContact360(\'' + esc(String(d.entity_id)) + '\', {kind:\'entity\'})' : '';
        html += '<div style="padding:8px 10px;background:var(--s2);border:1px solid var(--border);border-radius:8px' + (onclick ? ';cursor:pointer' : '') + '"' + (onclick ? ' onclick="' + onclick + '"' : '') + '>';
        html += '<div style="font-weight:600;font-size:12px;color:var(--text)">' + esc(d.name || '(property)') + '</div>';
        if (d.city || d.state) html += '<div style="font-size:11px;color:var(--text2)">' + esc((d.city || '') + (d.city && d.state ? ', ' : '') + (d.state || '')) + '</div>';
        html += '</div>';
      }
      html += '</div></div>';
    }
    const aff = owned.affiliated;
    if (aff && aff.properties && aff.properties.length) {
      const orgClick = aff.org_entity_id ? ' onclick="openContact360(\'' + esc(String(aff.org_entity_id)) + '\', {kind:\'entity\'})" style="cursor:pointer"' : '';
      html += '<div class="detail-section"><div class="detail-section-title"' + orgClick + '>\u{1F3E2} Via ' + esc(aff.org_name || 'affiliated company') + ' (' + aff.properties.length + ')</div>';
      html += '<div style="display:flex;flex-direction:column;gap:6px;margin-top:6px">';
      for (const p of aff.properties) {
        const db = (p.source_domain === 'gov' || p.source_domain === 'government') ? 'gov' : 'dia';
        const pid = p.source_property_id;
        const nm = p.address || p.tenant_label || p.tenant_short || '(property)';
        const onclick = pid != null ? 'openUnifiedDetail(\'' + db + '\', {property_id:\'' + esc(String(pid)) + '\'})' : '';
        html += '<div style="padding:8px 10px;background:var(--s2);border:1px solid var(--border);border-radius:8px' + (onclick ? ';cursor:pointer' : '') + '"' + (onclick ? ' onclick="' + onclick + '"' : '') + '>';
        html += '<div style="font-weight:600;font-size:12px;color:var(--text)">' + esc(nm) + '</div>';
        if (p.city || p.state) html += '<div style="font-size:11px;color:var(--text2)">' + esc((p.city || '') + (p.city && p.state ? ', ' : '') + (p.state || '')) + '</div>';
        html += '</div>';
      }
      html += '</div></div>';
    }
  }

  if (!portfolio.length) {
    // A person with no BD-portfolio rollup still shows their direct/affiliated
    // ownership above; only show the empty note when there's truly nothing.
    if (!owned || (!(owned.direct && owned.direct.length) && !(owned.affiliated && owned.affiliated.properties && owned.affiliated.properties.length))) {
      html += '<div class="detail-empty">No properties in the BD portfolio yet.</div>';
    }
    return html;
  }

  html += '<div class="detail-section"><div class="detail-section-title">Properties (' + portfolio.length + ')</div>';
  html += '<div style="display:flex;flex-direction:column;gap:6px">';

  for (let pi = 0; pi < portfolio.length; pi++) {
    const p = portfolio[pi];
    const addr = p.address || '(No address)';
    const loc = (p.city || '') + (p.city && p.state ? ', ' : '') + (p.state || '');
    const db = (p.source_domain === 'gov' || p.source_domain === 'government') ? 'gov' : 'dia';
    const pid = p.source_property_id;
    const tenant = p.tenant || '';
    const rent = p.annual_rent != null ? _entityFmtMoney(p.annual_rent) : '';
    const badge = db.toUpperCase();
    const dim = p.is_current === false ? 'opacity:0.6;' : '';

    html += '<div style="padding:10px 12px;background:var(--s2);border:1px solid var(--border);border-radius:8px;' + dim + (pid != null ? 'cursor:pointer' : '') + '"';
    // Dual-dock the property BESIDE this contact panel (item #6); narrow screens
    // fall back to the full single-panel open inside _entityDrillProperty.
    if (pid != null) html += ' onclick="_entityDrillProperty(\'' + esc(db) + '\', \'' + esc(String(pid)) + '\', \'portfolio\', ' + pi + ')"';
    html += '>';
    html += '<div style="display:flex;gap:12px;align-items:flex-start">';
    html += '<div style="flex:1;min-width:0">';
    html += '<div style="font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + esc(addr) + '</div>';
    html += '<div style="font-size:11px;color:var(--text2)">' + esc(loc) + (tenant ? ' · ' + esc(tenant) : '') + (p.is_current === false ? ' · former' : '') + '</div>';
    html += '</div>';
    html += '<div style="text-align:right;font-size:11px;flex-shrink:0">';
    html += '<div><span style="font-size:9px;padding:1px 6px;border-radius:8px;background:' + (db === 'gov' ? 'var(--gov-green)' : 'var(--purple)') + ';color:#fff">' + badge + '</span></div>';
    if (rent) html += '<div style="color:var(--green);margin-top:3px">' + rent + '</div>';
    html += '</div></div></div>';
  }

  html += '</div></div>';
  return html;
}

// ── Entity Contacts Tab (UI Phase 4B) ──
// Lists the people at this owner; when there are none, surfaces the
// acquire-contact CTA that reuses the P-CONTACT / buyer picker endpoints
// (?action=buyer_contacts → select_prospecting_contact). This is where Phase 5's
// "owner missing a contact" gets resolved.
function _entityTabContacts() {
  const c = _entityDetailCache;
  const contacts = c?.contacts || [];

  let html = '';
  if (contacts.length) {
    html += '<div class="detail-section"><div class="detail-section-title">Contacts (' + contacts.length + ')</div>';
    html += '<div style="display:flex;flex-direction:column;gap:8px">';
    for (const ct of contacts) {
      html += '<div style="padding:10px 12px;background:var(--s2);border:1px solid var(--border);border-radius:8px;cursor:pointer" onclick="openContact360(\'' + esc(ct.id) + '\')">';
      html += '<div style="display:flex;align-items:center;gap:8px">';
      html += '<div style="width:32px;height:32px;border-radius:50%;background:var(--purple);color:#fff;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:600">';
      html += esc((ct.full_name || ct.display_name || '?')[0].toUpperCase());
      html += '</div>';
      html += '<div style="flex:1;min-width:0">';
      html += '<div style="font-weight:600;color:var(--text)">' + esc(ct.full_name || ct.display_name || 'Unknown') + '</div>';
      html += '<div style="font-size:11px;color:var(--text2)">' + esc(ct.title || '') + '</div>';
      html += '</div>';
      html += '<div style="text-align:right;font-size:11px;color:var(--text3)">';
      if (ct.email) html += '<div>' + esc(ct.email) + '</div>';
      if (ct.phone) html += '<div>' + esc(ct.phone) + '</div>';
      html += '</div></div></div>';
    }
    html += '</div>';
    html += '<div style="margin-top:10px"><button class="dns-cta" onclick="_entityAcquireContact()">+ Add / acquire contact →</button></div>';
    html += '</div>';
  } else {
    html += '<div class="detail-section"><div class="detail-section-title">Contacts</div>';
    html += '<div style="color:var(--text3);font-size:12px;padding:8px 0 12px">No contacts linked to this owner yet — acquire one to make outreach actionable.</div>';
    html += '<button class="dns-cta" onclick="_entityAcquireContact()">Select / acquire contact →</button>';
    html += '</div>';
  }
  // Host for the inline picker (rendered by _entityAcquireContact).
  html += '<div id="entityContactPickerHost"></div>';
  return html;
}

// ============================================================================
// UI Phase 4B — owner-level completeness rail + Next-Step (shared chrome)
// Mirrors the property detail's _udRenderCompletenessRail / _udRenderNextStep,
// but reads the entity cache. Both write the SAME persistent DOM elements
// (#detailCompletenessRail / #detailNextStep) so the owner zooms identically.
// ============================================================================

// Hide the shared rail / Next-Step / next-action chrome (a fresh entity open, so
// a prior property's rail never lingers under the entity panel).
function _entityHideRailChrome() {
  ['detailCompletenessRail', 'detailNextStep', 'detailNextActionBar'].forEach(function (id) {
    const el = document.getElementById(id);
    if (el) { el.style.display = 'none'; el.innerHTML = ''; }
  });
}

// Connection chips: SF Account link · ≥1 linked contact · portfolio value known.
function _entityRenderCompletenessRail() {
  const rail = document.getElementById('detailCompletenessRail');
  if (!rail) return;
  const c = _entityDetailCache;
  if (!c || c.type !== 'entity') { rail.style.display = 'none'; rail.innerHTML = ''; return; }
  const e = c.entity || {};
  const extIds = e.external_identities || [];
  const hasSf = extIds.some(x => String(x.source_system || '').toLowerCase() === 'salesforce'
    && String(x.source_type || '').toLowerCase() === 'account');
  const hasContact = (c.contacts || []).length > 0;
  const rollupRent = c.rollup && c.rollup.current_annual_rent_total != null ? Number(c.rollup.current_annual_rent_total) : 0;
  const hasValue = rollupRent > 0;

  const done = [hasSf, hasContact, hasValue].filter(Boolean).length;
  const chip = (label, ok, onclick) =>
    '<span class="cr-chip" ' + (ok ? 'style="cursor:default"' : (onclick ? 'onclick="' + onclick + '"' : '')) + '>'
      + (ok ? '✓ ' : '+ ') + esc(label) + '</span>';

  const parts = [];
  parts.push('<div class="cr-summary"><span class="cr-label">Connections</span>'
    + '<span class="cr-score">' + done + '</span><span class="cr-score-band cr-band-'
    + (done >= 2 ? 'good' : done === 1 ? 'fair' : 'poor') + '">of 3</span></div>');
  parts.push('<div class="cr-chips">');
  parts.push(chip('Salesforce account', hasSf, null));
  parts.push(chip('Contact', hasContact, 'switchEntityTab(&quot;Contacts&quot;)'));
  parts.push(chip('Portfolio value', hasValue, 'switchEntityTab(&quot;Portfolio&quot;)'));
  parts.push('</div>');
  rail.innerHTML = parts.join('');
  rail.style.display = '';
}

// Next-action at the owner level — reads the entity's priority band (the SAME
// v_priority_queue_enriched truth as the Priority Queue / Decision Center).
function _entityRenderNextStep() {
  const bar = document.getElementById('detailNextStep');
  if (!bar) return;
  const c = _entityDetailCache;
  if (!c || c.type !== 'entity') { bar.style.display = 'none'; bar.innerHTML = ''; return; }
  const band = c.band || null;
  const pb = band && band.priority_band ? String(band.priority_band).toUpperCase() : null;
  const reason = band ? String(band.reason || '') : '';
  const oppOpen = !!(band && band.open_opportunity);
  const cadenceDue = band && band.cadence_next_touch_due ? band.cadence_next_touch_due : null;
  const trueOwner = band && band.resolve_true_owner_name ? band.resolve_true_owner_name : null;
  const connected = band ? band.resolve_is_connected : null;

  let step;
  if (pb === 'P0.4' || reason === 'resolve_ownership_control') {
    step = {
      label: 'Resolve ownership & control',
      sub: trueOwner ? ('True owner: ' + trueOwner + ' — link a Salesforce account / contact.')
                     : 'Identify the true owner/parent and link a CRM account / contact.',
      cta: 'Select contact →', onclick: 'switchEntityTab(&quot;Contacts&quot;);_entityAcquireContact()'
    };
  } else if (pb === 'P-BUYER' || /^repeat_buyer/.test(reason)) {
    step = {
      label: 'Open Government Buyer opportunity',
      sub: 'Repeat buyer — pursue on the parent account, then pick the prospecting contact.',
      cta: 'Open Government Buyer →', onclick: '_entityOpenGovBuyer()'
    };
  } else if (pb === 'P-CONTACT' || reason === 'select_prospecting_contact') {
    step = {
      label: 'Select prospecting contact',
      sub: 'No reachable contact yet — acquire one to make outreach actionable.',
      cta: 'Select contact →', onclick: 'switchEntityTab(&quot;Contacts&quot;);_entityAcquireContact()'
    };
  } else if (pb === 'P0.5' || reason === 'open_bd_opportunity_needed') {
    step = {
      label: 'Open a BD opportunity', sub: 'Owner resolved & connected — open the lead.',
      cta: null, onclick: null
    };
  } else if (cadenceDue) {
    step = { label: 'Cadence touch due', sub: 'Next touch ' + _fmtDate(cadenceDue) + '.', cta: null, onclick: null };
  } else if (oppOpen) {
    step = { label: 'Lead is live ✓', sub: 'Open BD opportunity on this owner.', cta: null, onclick: null };
  } else if (pb) {
    step = { label: _entityBandLabel(reason), sub: 'BD priority for this owner.', cta: null, onclick: null };
  } else {
    step = { label: 'Connected — no action', sub: 'No active BD action for this owner right now.', cta: null, onclick: null };
  }

  let h = '<div class="dns-row">';
  h += '<span class="dns-flag">▶ Next step</span>';
  h += '<div class="dns-text"><div class="dns-label">' + esc(step.label) + '</div><div class="dns-sub">' + esc(step.sub) + '</div></div>';
  if (step.cta && step.onclick) h += '<button type="button" class="dns-cta" onclick="event.stopPropagation();' + step.onclick + '">' + esc(step.cta) + '</button>';
  h += '</div>';
  bar.innerHTML = h;
  bar.style.display = '';
}

// Plain-language label for a band reason (mirrors ops.js _pqReason essentials).
function _entityBandLabel(reason) {
  const map = {
    developer_overdue: 'Onboarding touch overdue (developer)',
    resolve_ownership_control: 'Resolve ownership & control',
    open_bd_opportunity_needed: 'Needs a BD opportunity opened',
    select_prospecting_contact: 'No reachable contact — select one',
    onboarding_cadence_due: 'Onboarding touch due',
    steady_state_cadence_due: 'Steady-state touch overdue',
    recent_acquisition_streak: 'Active acquirer (recent buying streak)',
    aging_building: 'Aging building (replacement candidate)'
  };
  const r = String(reason || '');
  if (map[r]) return map[r];
  return r ? r.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()) : 'BD priority';
}

// ── Entity contact acquire (reuses the P-CONTACT / buyer picker endpoints) ──
async function _entityAcquireContact() {
  const c = _entityDetailCache;
  if (!c || !c.entityId) return;
  // Ensure the Contacts tab is showing so the host element exists.
  const activeTab = document.querySelector('#detailTabs .detail-tab.active');
  if (!activeTab || activeTab.textContent.trim() !== 'Contacts') switchEntityTab('Contacts');
  const host = document.getElementById('entityContactPickerHost');
  if (host) host.innerHTML = '<div style="padding:12px;color:var(--text2)"><span class="spinner"></span> Loading candidate contacts…</div>';
  const data = await _udApiGet('/api/operations?action=buyer_contacts&entity_id=' + encodeURIComponent(c.entityId));
  if (!data || data.ok === false) {
    if (host) host.innerHTML = '<div style="padding:12px;color:var(--red,#ef4444)">Could not load contacts.</div>';
    return;
  }
  _entityDetailCache._contactCandidates = data;
  if (host) host.innerHTML = _entityContactPickerHTML(data);
}
window._entityAcquireContact = _entityAcquireContact;

function _entityContactPickerHTML(d) {
  let h = '<div class="detail-section" style="margin-top:12px;border:1px solid var(--border);border-radius:8px;padding:12px">';
  h += '<div class="detail-section-title">Who is the prospecting contact?</div>';
  const sec = (title, rows, kind) => {
    if (!rows || !rows.length) return '';
    let s = '<div style="font-size:11px;font-weight:600;color:var(--text3);margin:8px 0 4px;text-transform:uppercase">' + esc(title) + '</div>';
    rows.forEach((cn, i) => {
      const sub = [cn.title, cn.email].filter(Boolean).join(' · ');
      s += '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;padding:6px 0;border-top:1px solid var(--border)">'
        + '<div style="min-width:0"><b>' + esc(cn.name || 'Unnamed') + '</b>'
        + (sub ? ' <span style="font-size:11px;color:var(--text2)">' + esc(sub) + '</span>' : '') + '</div>'
        + '<button class="dns-cta" onclick="_entityContactPick(&quot;' + kind + '&quot;,' + i + ')">Select</button></div>';
    });
    return s;
  };
  h += sec('Linked to this account', d.related, 'related');
  if (d.sf_contacts && d.sf_contacts.length) {
    h += sec('Salesforce contacts', d.sf_contacts, 'sf');
  } else {
    const msg = {
      no_account: 'Not yet mapped to a Salesforce account.',
      not_configured: 'Salesforce lookup not configured.',
      unavailable: 'Salesforce contact lookup unavailable — add the contact manually.',
      no_contacts: 'No Salesforce contacts on this account yet.'
    }[d.sf_status];
    if (msg) h += '<div style="font-size:11px;color:var(--text3);margin-top:6px">' + esc(msg) + '</div>';
  }
  h += sec('Name-matched humans (link on select)', d.name_matches, 'name');
  h += '<div style="margin-top:10px"><button class="dns-cta" onclick="_entityContactAddNew()">+ Add new contact…</button></div>';
  h += '</div>';
  return h;
}

function _entityContactPick(kind, i) {
  const d = (_entityDetailCache && _entityDetailCache._contactCandidates) || {};
  const arr = kind === 'related' ? d.related : kind === 'sf' ? d.sf_contacts : d.name_matches;
  const cn = (arr || [])[i];
  if (!cn) return;
  const payload = (kind === 'sf')
    ? { sf_contact_id: cn.sf_contact_id, contact_name: cn.name }
    : { contact_entity_id: cn.entity_id, contact_name: cn.name };
  _entityContactSubmit(payload, cn.name);
}
window._entityContactPick = _entityContactPick;

async function _entityContactAddNew() {
  const nm = (typeof lccPrompt === 'function')
    ? await lccPrompt('Add a new prospecting contact at this owner.\n\nFull name:', '')
    : (typeof prompt === 'function' ? prompt('New contact name:') : '');
  if (nm == null) return;
  const v = String(nm || '').trim();
  if (!v) { if (typeof showToast === 'function') showToast('Enter the contact name.', 'error'); return; }
  _entityContactSubmit({ new_contact_name: v }, v);
}
window._entityContactAddNew = _entityContactAddNew;

async function _entityContactSubmit(payload, displayName) {
  const c = _entityDetailCache;
  if (!c || !c.entityId) return;
  const body = Object.assign({ entity_id: c.entityId }, payload);
  const res = await _udApiPost('/api/operations?action=select_prospecting_contact', body);
  // The endpoint links person→entity FIRST (which connects the owner), then
  // tries to stamp the contact onto an active cadence. A connect-band owner
  // often has NO cadence yet, so the link succeeds but the endpoint returns
  // `no_active_cadence`. That's a soft success here — the connect (the owner-
  // detail goal) happened; the cadence stamp is a bonus only when one exists.
  const linked = res && (res.ok || res.error === 'no_active_cadence');
  if (linked) {
    const note = (res && res.error === 'no_active_cadence') ? ' (no active cadence to attach)' : '';
    if (typeof showToast === 'function') showToast('Contact ' + (res.contact_name || displayName || '') + ' linked' + note, 'success');
    // Reopen the owner on the Contacts tab so contacts + band + rail refresh.
    openEntityDetail(c.entityId, 'Contacts');
  } else {
    if (typeof showToast === 'function') showToast('Could not select contact: ' + ((res && res.error) || 'unknown'), 'error');
  }
}

// Open a Government Buyer opportunity on the parent (reuses the existing op),
// then route to the contact step (the buy-side next action).
async function _entityOpenGovBuyer() {
  const c = _entityDetailCache;
  if (!c || !c.entityId) return;
  const res = await _udApiPost('/api/operations?action=open_government_buyer', { entity_id: c.entityId });
  if (res && (res.ok || res.already_open)) {
    if (typeof showToast === 'function') showToast(res.already_open ? 'Government Buyer opportunity already open' : 'Government Buyer opportunity opened', 'success');
    switchEntityTab('Contacts');
    _entityAcquireContact();
  } else {
    if (typeof showToast === 'function') showToast('Could not open opportunity: ' + ((res && res.error) || 'unknown'), 'error');
  }
}
window._entityOpenGovBuyer = _entityOpenGovBuyer;

// ── Contact Detail Tab ──
function _renderContactTab(contact) {
  const c = contact;
  let html = '';

  // Contact info card
  html += '<div class="detail-section"><div class="detail-section-title">Contact Information</div><div class="detail-grid">';
  html += _row('Name', c.full_name || c.display_name);
  html += _row('Title', c.title);
  html += _row('Company', c.company_name);
  if (c.contact_class) html += _row('Type', c.contact_class);
  html += '</div></div>';

  // Communication details
  html += '<div class="detail-section"><div class="detail-section-title">Communication</div><div class="detail-grid">';
  if (c.email) html += _rowLink('Email', c.email, 'mailto:' + c.email);
  if (c.phone) html += _rowLink('Phone', c.phone, 'tel:' + c.phone);
  if (c.mobile_phone) html += _rowLink('Mobile', c.mobile_phone, 'tel:' + c.mobile_phone);
  if (c.linkedin_url) html += _rowLink('LinkedIn', 'Profile', c.linkedin_url);
  html += '</div></div>';

  // Address
  if (c.city || c.state || c.address) {
    html += '<div class="detail-section"><div class="detail-section-title">Address</div><div class="detail-grid">';
    if (c.address) html += _row('Street', c.address);
    html += _row('City / State', (c.city || '') + (c.city && c.state ? ', ' : '') + (c.state || ''));
    if (c.zip) html += _row('Zip', c.zip);
    html += '</div></div>';
  }

  // Linked entity
  if (c.entity_id) {
    html += '<div class="detail-section"><div class="detail-section-title">Linked Entity</div>';
    html += '<div onclick="openEntityDetail(\'' + esc(c.entity_id) + '\')" style="padding:10px 12px;background:var(--s2);border:1px solid var(--border);border-radius:8px;cursor:pointer;display:flex;align-items:center;gap:8px">';
    html += '<span style="color:var(--accent);font-size:16px">🏢</span>';
    html += '<div><div style="font-weight:600;color:var(--accent)">' + esc(c.company_name || c.entity_id) + '</div>';
    html += '<div class="t-meta3">Click to view entity details</div></div>';
    html += '</div></div>';
  }

  // Source info
  if (c.source_system || c.created_at) {
    html += '<div class="detail-section"><div class="detail-section-title">Source</div><div class="detail-grid">';
    if (c.source_system) html += _row('Source', c.source_system);
    if (c.created_at) html += _row('Created', _fmtDate(c.created_at));
    if (c.updated_at) html += _row('Updated', _fmtDate(c.updated_at));
    if (c.last_activity_date) html += _row('Last Activity', _fmtDate(c.last_activity_date));
    html += '</div></div>';
  }

  return html;
}

// ── Contact Tab Switching ──
function _switchContactTab(tabName) {
  if (!_entityDetailCache || _entityDetailCache.type !== 'contact') return;
  document.querySelectorAll('#detailTabs .detail-tab').forEach(t => {
    t.classList.toggle('active', t.textContent.trim() === tabName);
  });
  const bodyEl = document.getElementById('detailBody');
  if (!bodyEl) return;
  if (tabName === 'Activity') {
    bodyEl.innerHTML = _contactTabActivity();
  } else {
    bodyEl.innerHTML = _renderContactTab(_entityDetailCache.contact);
  }
}

// ── Contact Activity Tab ──
function _contactTabActivity() {
  const activities = _entityDetailCache?.activities || [];
  if (!activities.length) {
    const hasEntity = _entityDetailCache?.contact?.entity_id;
    return '<div class="detail-empty">' + (hasEntity ? 'No activity history found.' : 'No linked entity — activity tracking requires an entity association.') + '</div>';
  }

  const catIcon = { call: '\u{1F4DE}', email: '\u{1F4E7}', meeting: '\u{1F4C5}', note: '\u{1F4DD}', status_change: '\u{1F504}', assignment: '\u{1F464}', sync: '\u{1F500}', research: '\u{1F50D}', system: '\u{2699}\uFE0F' };

  let html = '<div class="detail-section"><div class="detail-section-title">Activity Timeline (' + activities.length + ')</div>';
  html += '<div style="display:flex;flex-direction:column;gap:2px;margin-top:4px">';

  for (const a of activities) {
    const date = _fmtDate(a.occurred_at || a.created_at);
    const icon = catIcon[a.category] || '\u{1F4CB}';
    const actor = a.users?.display_name || '';
    const cat = a.category ? a.category.replace(/_/g, ' ') : '';

    html += '<div style="padding:10px 12px;border-left:3px solid var(--purple);margin-left:8px;position:relative">';
    html += '<div style="position:absolute;left:-10px;top:12px;width:14px;height:14px;border-radius:50%;background:var(--s1);border:2px solid var(--purple);font-size:8px;display:flex;align-items:center;justify-content:center">' + icon + '</div>';
    html += '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px">';
    html += '<div style="flex:1;min-width:0">';
    html += '<div style="font-weight:600;font-size:13px;color:var(--text)">' + esc(a.title || '(untitled)') + '</div>';
    if (a.body) html += '<div style="font-size:12px;color:var(--text2);margin-top:2px;white-space:pre-wrap;max-height:80px;overflow:hidden">' + esc(a.body) + '</div>';
    html += '<div style="font-size:10px;color:var(--text3);margin-top:4px;display:flex;gap:8px;flex-wrap:wrap">';
    if (cat) html += '<span style="padding:1px 6px;border-radius:8px;background:var(--s3);text-transform:capitalize">' + esc(cat) + '</span>';
    if (actor) html += '<span>' + esc(actor) + '</span>';
    if (a.source_type && a.source_type !== 'manual') html += '<span>via ' + esc(a.source_type) + '</span>';
    html += '</div></div>';
    html += '<div style="flex-shrink:0;font-size:11px;color:var(--text3);white-space:nowrap">' + esc(date) + '</div>';
    html += '</div></div>';
  }

  html += '</div></div>';
  return html;
}

// Window exports for entity/contact detail functions
window.openEntityDetail = openEntityDetail;
window.openEntityDetailByName = openEntityDetailByName;
window.openContactDetail = openContactDetail;
window.openContactDetailByName = openContactDetailByName;
window._switchEntityTab = _switchEntityTab;

// ============================================================================
// OWNER DRAWER — Click-through panel for ownership_history / current owner
// ============================================================================
//
// Opens over the existing detail panel and shows the unified owner profile:
// - Company: address, state of incorp, entity type, parent (true owner)
// - Contacts: name, title, phone, email
// - Open Activities: incomplete SF tasks for this owner's SF Account
// - Activity History: completed SF activities for this owner's SF Account
// - Begin Prospecting: creates SF task + scrolls Log Activity / Draft Email
//
// Resolves shell LLCs ("Mds Dv Victorville") to their parent SF Account
// (Davita Inc.) by walking true_owner_id -> unified_contacts.sf_account_id.
//
// Empty state (no SF match): shows "Create Salesforce Account" + "Add Contact".

let _ownerDrawerCache = null;
let _ownerDrawerNavStack = [];

/**
 * Build a clickable owner-name link that opens the OwnerDrawer.
 * Accepts a context object with whatever owner identity hints we have.
 * Always renders the display text — only the click handler differs.
 *
 * Uses a data-owner-ctx attribute + document-level delegated click listener
 * so the link keeps working even if the span is moved, cloned, or re-wrapped.
 * This avoids inline-onclick JS-string quoting fragility when owner names
 * contain apostrophes, backslashes, or non-ASCII characters.
 */
function _ownerLink(displayName, ctx) {
  if (!displayName) return '<span class="t-muted3">\u2014</span>';
  const ctxObj = ctx || { name: displayName };
  // Encode payload for safe embedding in the HTML attribute. Double-encoded
  // (JSON → URI) so ampersands, quotes, and braces can't break the attribute
  // or the eventual JSON.parse.
  const payload = encodeURIComponent(JSON.stringify(ctxObj));
  const style = 'color:var(--accent);cursor:pointer;text-decoration:underline;text-decoration-style:dotted;font-weight:600';
  return '<span class="owner-link" role="button" tabindex="0" data-owner-ctx="' + payload +
    '" style="' + style + '" title="View owner profile, contacts, and SF activity">' +
    esc(displayName) + '</span>';
}

// Delegated click handler — runs for every .owner-link on the page, regardless
// of how/where it was rendered. Keyboard-accessible via Enter/Space.
document.addEventListener('click', function (e) {
  const el = e.target && e.target.closest && e.target.closest('.owner-link[data-owner-ctx]');
  if (!el) return;
  e.preventDefault();
  e.stopPropagation();
  try {
    const raw = decodeURIComponent(el.getAttribute('data-owner-ctx') || '');
    if (raw) openOwnerDrawer(raw);
  } catch (err) {
    console.warn('owner-link click: bad payload', err);
  }
});
document.addEventListener('keydown', function (e) {
  if (e.key !== 'Enter' && e.key !== ' ') return;
  const el = e.target && e.target.closest && e.target.closest('.owner-link[data-owner-ctx]');
  if (!el) return;
  e.preventDefault();
  try {
    const raw = decodeURIComponent(el.getAttribute('data-owner-ctx') || '');
    if (raw) openOwnerDrawer(raw);
  } catch (err) { /* ignore */ }
});

/**
 * Build an owner context object from a v_ownership_chain row.
 * Standardizes fields across gov/dia rows and current ownership.
 */
function _ownerCtxFromChain(h, db) {
  const recordedName = h.recorded_owner_name || h.to_owner || h.new_owner || '';
  const trueName = h.true_owner_name || '';
  return {
    name: recordedName || trueName,
    recorded_owner_name: recordedName,
    recorded_owner_id: h.recorded_owner_id || null,
    true_owner_name: trueName,
    true_owner_id: h.true_owner_id || null,
    sf_account_id: h.sf_account_id || h.sf_company_id || null,
    sf_contact_id: h.sf_contact_id || null,
    state_of_incorporation: h.state_of_incorporation || h.recorded_owner_state || null,
    entity_type: h.ownership_type || h.owner_type || null,
    transfer_date: h.transfer_date || null,
    ownership_end: h.ownership_end || null,
    db: db || null
  };
}

/** Build owner context from a v_ownership_current row (own object). */
function _ownerCtxFromCurrent(own, db, which) {
  if (!own) return null;
  if (which === 'true' && own.true_owner) {
    return {
      name: own.true_owner,
      recorded_owner_name: null,
      recorded_owner_id: null,
      true_owner_name: own.true_owner,
      true_owner_id: own.true_owner_id || null,
      sf_account_id: own.sf_account_id || own.sf_company_id || null,
      sf_contact_id: own.sf_contact_id || own.salesforce_id || null,
      state_of_incorporation: own.true_owner_state || null,
      entity_type: own.true_owner_type || own.owner_type || null,
      address: own.recorded_owner_address || null,
      city: own.true_owner_city || null,
      is_current: true,
      db: db || null
    };
  }
  return {
    name: own.recorded_owner || own.true_owner,
    recorded_owner_name: own.recorded_owner,
    recorded_owner_id: own.recorded_owner_id || null,
    true_owner_name: own.true_owner || null,
    true_owner_id: own.true_owner_id || null,
    sf_account_id: own.sf_account_id || own.sf_company_id || null,
    sf_contact_id: own.sf_contact_id || own.salesforce_id || null,
    state_of_incorporation: own.recorded_owner_state || own.true_owner_state || null,
    entity_type: own.owner_type || own.recorded_owner_type || null,
    address: own.recorded_owner_address || null,
    city: own.recorded_owner_city || null,
    contact_name: own.contact_1_name || own.contact_name || null,
    contact_email: own.contact_email || null,
    contact_phone: own.contact_phone || null,
    is_current: true,
    db: db || null
  };
}

/**
 * Public entry: open the OwnerDrawer for a given owner context.
 * ctxJson may be a JSON string (from the inline onclick) or an object.
 */
async function openOwnerDrawer(ctxJson) {
  let ctx;
  try {
    ctx = (typeof ctxJson === 'string') ? JSON.parse(ctxJson) : ctxJson;
  } catch (e) {
    console.error('OwnerDrawer: bad ctx', e);
    return;
  }
  if (!ctx) return;

  const panel = document.getElementById('detailPanel');
  const overlay = document.getElementById('detailOverlay');
  if (!panel || !overlay) return;

  const headerEl = document.getElementById('detailHeader');
  const tabsEl = document.getElementById('detailTabs');
  const bodyEl = document.getElementById('detailBody');

  // Save current panel state to nav stack so Back restores it
  if (headerEl && bodyEl && bodyEl.innerHTML) {
    _ownerDrawerNavStack.push({
      header: headerEl.innerHTML,
      tabs: tabsEl ? tabsEl.innerHTML : '',
      body: bodyEl.innerHTML,
      detailRecord: window._detailRecord || null,
      detailSource: window._detailSource || null,
      detailTab: window._detailTab || null,
      ownerDrawerCache: _ownerDrawerCache
    });
  }

  panel.style.display = 'block';
  overlay.classList.add('open');

  if (headerEl) headerEl.innerHTML =
    '<button class="detail-back" onclick="_ownerDrawerGoBack()">&#x2190;<span>Back</span></button>' +
    '<div class="detail-header-info">' +
      '<div style="flex:1;min-width:0">' +
        '<div class="detail-title">' + esc(ctx.name || 'Owner') + '</div>' +
        '<div class="detail-subtitle">Loading owner profile...</div>' +
      '</div>' +
      '<span class="detail-badge" style="background:#a55eea;color:#fff">OWNER</span>' +
    '</div>' +
    '<button class="detail-close" onclick="closeDetail(); _ownerDrawerNavStack=[];">&times;</button>';
  if (tabsEl) tabsEl.innerHTML = '';
  if (bodyEl) bodyEl.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Resolving owner &amp; loading Salesforce activity...</p></div>';

  try {
    const resolved = await _resolveOwnerProfile(ctx);
    _ownerDrawerCache = resolved;

    const parentNote = (resolved.parent_account_name && resolved.parent_account_name !== resolved.name)
      ? '<div style="font-size:11px;color:var(--text3);margin-top:2px">Shell LLC \u2192 ' + esc(resolved.parent_account_name) + '</div>'
      : '';
    const sfBadge = resolved.sf_account_id
      ? '<span style="font-size:10px;padding:2px 8px;border-radius:10px;background:#00a1e0;color:#fff;margin-left:6px">SF linked</span>'
      : '<span style="font-size:10px;padding:2px 8px;border-radius:10px;background:var(--s3);color:var(--text2);margin-left:6px">No SF match</span>';
    if (headerEl) headerEl.innerHTML =
      '<button class="detail-back" onclick="_ownerDrawerGoBack()">&#x2190;<span>Back</span></button>' +
      '<div class="detail-header-info">' +
        '<div style="flex:1;min-width:0">' +
          '<div class="detail-title">' + esc(resolved.name || 'Owner') + sfBadge + '</div>' +
          '<div class="detail-subtitle">' + esc((resolved.entity_type || 'Owner Entity').toString().toUpperCase()) +
            (resolved.state_of_incorporation ? ' &middot; ' + esc(resolved.state_of_incorporation) : '') +
          '</div>' +
          parentNote +
        '</div>' +
        '<span class="detail-badge" style="background:#a55eea;color:#fff">OWNER</span>' +
      '</div>' +
      '<button class="detail-close" onclick="closeDetail(); _ownerDrawerNavStack=[];">&times;</button>';

    const tabs = ['Overview', 'Contacts', 'Open Activities', 'Activity History', 'Portfolio'];
    if (tabsEl) tabsEl.innerHTML = tabs.map(function(t, i) {
      return '<button class="detail-tab ' + (i === 0 ? 'active' : '') + '" onclick="_switchOwnerDrawerTab(\'' + t + '\')">' + t + '</button>';
    }).join('');

    if (bodyEl) bodyEl.innerHTML = _renderOwnerDrawerTab('Overview');
  } catch (err) {
    console.error('OwnerDrawer error:', err);
    if (bodyEl) bodyEl.innerHTML = '<div class="detail-empty">Error loading owner profile: ' + esc(err.message || String(err)) + '</div>';
  }
}

/**
 * Resolve the owner identity into a single profile bundle:
 * walks shell LLC -> true_owner -> unified_contacts.sf_account_id, then
 * loads contacts, open activities, and activity history scoped to that
 * SF Account id.
 */
async function _resolveOwnerProfile(ctx) {
  const out = Object.assign({}, ctx);
  out.contacts = [];
  out.open_activities = [];
  out.activity_history = [];
  out.parent_account_name = null;

  // Step 1: Resolve sf_account_id via the shared helper (shell-LLC → true
  // owner → unified_contacts chain, with normalized company_name fallback).
  if (!out.sf_account_id) {
    const resolved = await _resolveSfAccountId(out);
    if (resolved) {
      out.sf_account_id = resolved.sf_account_id;
      out.parent_account_name = resolved.company_name;
      if (!out.sf_contact_id && resolved.sf_contact_id) out.sf_contact_id = resolved.sf_contact_id;
    }
  }

  // Step 2: Activity feed by sf_account_id
  if (out.sf_account_id) {
    try {
      const actRes = await diaQuery('v_sf_activity_feed', '*', {
        filter: 'sf_account_id=eq.' + encodeURIComponent(out.sf_account_id),
        order: 'activity_date.desc',
        limit: 100
      });
      const all = Array.isArray(actRes) ? actRes : (actRes && actRes.data) || [];
      out.open_activities = all.filter(function(a) {
        return a.is_completed === false || a.status === 'Open' || a.status === 'open' || a.status === 'In Progress';
      });
      out.activity_history = all.filter(function(a) {
        return !(a.is_completed === false || a.status === 'Open' || a.status === 'open' || a.status === 'In Progress');
      });
    } catch (e) { console.warn('OwnerDrawer: activity feed by sf_account_id failed', e); }
  }
  // Fallback: legacy by sf_contact_id / true_owner_id
  if (out.activity_history.length === 0 && out.open_activities.length === 0) {
    try {
      let actRes = [];
      if (out.sf_contact_id) {
        actRes = await diaQuery('v_sf_activity_feed', '*', { filter: 'sf_contact_id=eq.' + encodeURIComponent(out.sf_contact_id), order: 'activity_date.desc', limit: 100 });
      } else if (out.true_owner_id) {
        actRes = await diaQuery('v_sf_activity_feed', '*', { filter: 'true_owner_id=eq.' + encodeURIComponent(out.true_owner_id), order: 'activity_date.desc', limit: 100 });
      }
      const all = Array.isArray(actRes) ? actRes : (actRes && actRes.data) || [];
      out.open_activities = all.filter(function(a) {
        return a.is_completed === false || a.status === 'Open' || a.status === 'open' || a.status === 'In Progress';
      });
      out.activity_history = all.filter(function(a) {
        return !(a.is_completed === false || a.status === 'Open' || a.status === 'open' || a.status === 'In Progress');
      });
    } catch (e) { console.warn('OwnerDrawer: legacy activity fallback failed', e); }
  }

  // Step 3: Contacts
  if (out.sf_account_id) {
    try {
      const cRes = await _entityApiFetch('/api/data-query?_source=gov&table=unified_contacts&select=unified_id,full_name,first_name,last_name,title,email,phone,mobile_phone,sf_contact_id,company_name&filter=sf_account_id%3Deq.' + encodeURIComponent(out.sf_account_id) + '&order=engagement_score.desc.nullslast&limit=25');
      out.contacts = (cRes && cRes.data) || [];
    } catch (e) { console.warn('OwnerDrawer: contacts load failed', e); }
  }
  if (out.contacts.length === 0) {
    try {
      const lookupName = out.parent_account_name || out.true_owner_name || out.recorded_owner_name || out.name;
      if (lookupName) {
        const like = encodeURIComponent('*' + lookupName + '*');
        const cRes = await _entityApiFetch('/api/data-query?_source=gov&table=unified_contacts&select=unified_id,full_name,first_name,last_name,title,email,phone,mobile_phone,sf_contact_id,company_name&filter=company_name%3Dilike.' + like + '&limit=25');
        out.contacts = (cRes && cRes.data) || [];
      }
    } catch (e) { console.warn('OwnerDrawer: contacts company_name fallback failed', e); }
  }

  // Step 4: Recorded owner address / state of incorp / entity type backfill
  if ((!out.address || !out.state_of_incorporation || !out.entity_type) && out.recorded_owner_id) {
    try {
      const src = (out.db === 'gov') ? 'gov' : 'dia';
      const roRes = await _entityApiFetch('/api/data-query?_source=' + src + '&table=recorded_owners&select=*&filter=recorded_owner_id%3Deq.' + encodeURIComponent(out.recorded_owner_id) + '&limit=1');
      const ro = ((roRes && roRes.data) || [])[0];
      if (ro) {
        out.address = out.address || ro.address || ro.recorded_owner_address || null;
        out.city = out.city || ro.city || null;
        out.state_of_incorporation = out.state_of_incorporation || ro.state || ro.recorded_owner_state || null;
        out.entity_type = out.entity_type || ro.type || ro.owner_type || null;
      }
    } catch (e) { /* ignore */ }
  }

  return out;
}

function _renderOwnerDrawerTab(tab) {
  const c = _ownerDrawerCache;
  if (!c) return '<div class="detail-empty">No owner data loaded</div>';
  switch (tab) {
    case 'Overview': return _ownerDrawerOverview(c);
    case 'Contacts': return _ownerDrawerContacts(c);
    case 'Open Activities': return _ownerDrawerActivities(c, 'open');
    case 'Activity History': return _ownerDrawerActivities(c, 'history');
    case 'Portfolio': return _ownerDrawerPortfolio(c);
    default: return '<div class="detail-empty">Unknown tab</div>';
  }
}

function _switchOwnerDrawerTab(tabName) {
  if (!_ownerDrawerCache) return;
  document.querySelectorAll('#detailTabs .detail-tab').forEach(function(t) {
    t.classList.toggle('active', t.textContent.trim() === tabName);
  });
  const bodyEl = document.getElementById('detailBody');
  if (bodyEl) bodyEl.innerHTML = _renderOwnerDrawerTab(tabName);
}

function _ownerDrawerOverview(c) {
  let html = '';

  html += '<div class="detail-section"><div class="detail-section-title">Company Profile</div><div class="detail-grid">';
  html += _row('Name', c.name);
  if (c.parent_account_name && c.parent_account_name !== c.name) html += _row('Parent (SF Account)', c.parent_account_name);
  html += _row('Entity Type', c.entity_type);
  html += _row('State of Incorporation', c.state_of_incorporation);
  html += _row('Address', c.address);
  if (c.city) html += _row('City', c.city);
  if (c.transfer_date) html += _row('Owned Since', _fmtDate(c.transfer_date));
  if (c.ownership_end) html += _row('Owned Through', _fmtDate(c.ownership_end));
  html += '</div></div>';

  if (!c.sf_account_id) {
    html += '<div class="detail-section">';
    html += '<div class="detail-section-title">Salesforce</div>';
    html += '<div style="background:rgba(0,161,224,0.08);border:1px solid rgba(0,161,224,0.3);border-radius:10px;padding:14px 16px">';
    html += '<div style="font-size:13px;color:var(--text);margin-bottom:8px">No Salesforce match found for <strong>' + esc(c.name || 'this owner') + '</strong>.</div>';
    html += '<div style="font-size:12px;color:var(--text2);margin-bottom:12px">Create the SF Account so future activities and contacts can be tracked here.</div>';
    html += '<div style="display:flex;gap:8px;flex-wrap:wrap">';
    html += '<button class="act-btn primary" onclick="_ownerDrawerCreateSfAccount()">+ Create Salesforce Account</button>';
    html += '<button class="act-btn" onclick="_ownerDrawerAddContact()">+ Add Contact</button>';
    html += '</div></div></div>';
  } else {
    html += '<div class="detail-section"><div class="detail-section-title">Salesforce</div>';
    html += '<div class="ql-grid">';
    html += _qlBtn('SF Account', _SF_BASE + '/Account/' + c.sf_account_id + '/view', '\uD83C\uDFEC', '#a55eea');
    html += '</div></div>';
  }

  html += '<div class="detail-section">';
  html += '<div class="detail-section-title">Prospecting</div>';
  html += '<div style="background:linear-gradient(135deg,rgba(165,94,234,0.12),rgba(0,161,224,0.08));border:1px solid rgba(165,94,234,0.25);border-radius:10px;padding:14px 16px">';
  html += '<div style="font-size:13px;color:var(--text);margin-bottom:6px;font-weight:600">Begin Prospecting</div>';
  html += '<div style="font-size:12px;color:var(--text2);margin-bottom:12px">Creates a Salesforce task on this account, then jumps to Log Activity / Draft Email scoped to <strong>' + esc(c.name) + '</strong>.</div>';
  html += '<button class="act-btn primary" onclick="_ownerDrawerBeginProspecting()" style="background:#a55eea;color:#fff">\u2192 Begin Prospecting</button>';
  html += '</div></div>';

  html += '<div class="detail-section"><div class="detail-section-title">Engagement Snapshot</div>';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">';
  html += '<div style="text-align:center;padding:12px;background:var(--s2);border-radius:8px"><div style="font-size:20px;font-weight:700;color:var(--purple)">' + (c.contacts ? c.contacts.length : 0) + '</div><div class="t-meta3">Contacts</div></div>';
  html += '<div style="text-align:center;padding:12px;background:var(--s2);border-radius:8px"><div style="font-size:20px;font-weight:700;color:var(--accent)">' + c.open_activities.length + '</div><div class="t-meta3">Open Tasks</div></div>';
  html += '<div style="text-align:center;padding:12px;background:var(--s2);border-radius:8px"><div style="font-size:20px;font-weight:700;color:var(--green)">' + c.activity_history.length + '</div><div class="t-meta3">Activities Logged</div></div>';
  html += '</div></div>';

  return html;
}

function _ownerDrawerContacts(c) {
  if (!c.contacts || c.contacts.length === 0) {
    let html = '<div class="detail-section"><div class="detail-section-title">Contacts</div>';
    html += '<div class="detail-empty">No contacts linked to this owner yet.</div>';
    html += '<div style="margin-top:12px"><button class="act-btn primary" onclick="_ownerDrawerAddContact()">+ Add Contact</button></div>';
    html += '</div>';
    return html;
  }
  let html = '<div class="detail-section"><div class="detail-section-title">Contacts (' + c.contacts.length + ')</div>';
  html += '<div style="display:flex;flex-direction:column;gap:6px">';
  c.contacts.forEach(function(ct) {
    const name = ct.full_name || ((ct.first_name || '') + ' ' + (ct.last_name || '')).trim() || 'Unknown';
    const initial = (name[0] || '?').toUpperCase();
    html += '<div style="padding:10px 12px;background:var(--s2);border:1px solid var(--border);border-radius:8px;cursor:pointer" onclick="openContactDetail(decodeURIComponent(\'' + encodeURIComponent(ct.unified_id || ct.sf_contact_id || '') + '\'))">';
    html += '<div style="display:flex;align-items:center;gap:10px">';
    html += '<div style="width:32px;height:32px;border-radius:50%;background:var(--purple);color:#fff;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:600">' + esc(initial) + '</div>';
    html += '<div style="flex:1;min-width:0">';
    html += '<div style="font-weight:600;color:var(--text)">' + esc(name) + '</div>';
    html += '<div class="t-meta3">' + esc(ct.title || '') + '</div>';
    html += '</div>';
    html += '<div style="text-align:right;font-size:11px">';
    if (ct.email) html += '<div><a href="mailto:' + esc(ct.email) + '" onclick="event.stopPropagation()" style="color:var(--accent)">' + esc(ct.email) + '</a></div>';
    if (ct.phone || ct.mobile_phone) html += '<div><a href="tel:' + esc(ct.phone || ct.mobile_phone) + '" onclick="event.stopPropagation()" class="t-muted2">' + esc(ct.phone || ct.mobile_phone) + '</a></div>';
    html += '</div></div></div>';
  });
  html += '</div></div>';
  html += '<div style="margin-top:12px"><button class="act-btn" onclick="_ownerDrawerAddContact()">+ Add Contact</button></div>';
  return html;
}

function _ownerDrawerActivities(c, mode) {
  const list = (mode === 'open') ? c.open_activities : c.activity_history;
  const title = (mode === 'open') ? 'Open Activities' : 'Activity History';
  if (!list || list.length === 0) {
    let html = '<div class="detail-section"><div class="detail-section-title">' + title + '</div>';
    if (!c.sf_account_id) {
      html += '<div class="detail-empty">No SF Account linked yet \u2014 create one to see activities.</div>';
      html += '<div style="margin-top:12px"><button class="act-btn primary" onclick="_ownerDrawerCreateSfAccount()">+ Create Salesforce Account</button></div>';
    } else {
      html += '<div class="detail-empty">No ' + title.toLowerCase() + ' for this owner.</div>';
    }
    html += '</div>';
    return html;
  }
  let html = '<div class="detail-section"><div class="detail-section-title">' + title + ' (' + list.length + ')</div>';
  list.forEach(function(a) {
    const typeColor = (a.feed_type === 'task' || mode === 'open') ? 'var(--yellow)'
      : (a.feed_type === 'call_outcome') ? 'var(--green)' : 'var(--accent)';
    html += '<div class="detail-card">';
    html += '<div class="detail-card-header">';
    html += '<div class="detail-card-title">' + esc(a.subject || a.activity_type || 'Activity') + '</div>';
    html += '<div class="detail-card-date">' + esc(_fmtDate(a.activity_date)) + '</div>';
    html += '</div>';
    html += '<div class="detail-card-body">';
    html += '<span style="display:inline-block;font-size:10px;padding:2px 6px;border-radius:4px;background:' + typeColor + ';color:#fff;margin-bottom:4px">' + esc(a.feed_type || a.activity_type || '') + '</span>';
    if (a.activity_type) html += ' <span style="font-size:12px;color:var(--text2)">' + esc(a.activity_type) + '</span>';
    if (a.status) html += '<br><span class="t-meta3-sm">Status: ' + esc(a.status) + '</span>';
    if (a.assigned_to) html += '<br><span class="t-meta3-sm">Assigned: ' + esc(a.assigned_to) + '</span>';
    if (a.contact_name) html += '<br><span class="t-meta3-sm">Contact: ' + esc(a.contact_name) + '</span>';
    if (a.notes) html += '<br><span style="font-size:12px;color:var(--text2);white-space:pre-wrap">' + esc(String(a.notes).substring(0, 220)) + (a.notes.length > 220 ? '...' : '') + '</span>';
    html += '</div></div>';
  });
  html += '</div>';
  return html;
}

/** Portfolio tab: shows other properties owned by this entity. Loads async then replaces placeholder. */
function _ownerDrawerPortfolio(c) {
  const ownerName = c.parent_account_name || c.true_owner_name || c.recorded_owner_name || c.name || '';
  if (!ownerName) {
    return '<div class="detail-section"><div class="detail-section-title">Ownership Portfolio</div><div class="detail-empty">No owner name to search portfolio.</div></div>';
  }
  const placeholderId = '_odPortfolio_' + Date.now();
  // Fire async load
  setTimeout(function() { _loadOwnerPortfolio(ownerName, c.db, placeholderId); }, 0);
  return '<div class="detail-section"><div class="detail-section-title">Ownership Portfolio</div>' +
    '<div id="' + placeholderId + '" style="text-align:center;padding:24px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:8px">Loading portfolio for ' + esc(ownerName) + '...</p></div></div>';
}

async function _loadOwnerPortfolio(ownerName, db, elId) {
  const el = document.getElementById(elId);
  if (!el) return;
  try {
    const like = encodeURIComponent('*' + ownerName + '*');
    const src = db || 'gov';
    // Query v_ownership_current for properties matching this owner as true_owner or recorded_owner
    const [trueRes, recRes] = await Promise.all([
      _entityApiFetch('/api/data-query?_source=' + src + '&table=v_ownership_current&select=property_name,address,city,state,recorded_owner,true_owner,sale_price,transfer_date,sf_account_id&filter=true_owner%3Dilike.' + like + '&order=transfer_date.desc.nullslast&limit=50'),
      _entityApiFetch('/api/data-query?_source=' + src + '&table=v_ownership_current&select=property_name,address,city,state,recorded_owner,true_owner,sale_price,transfer_date,sf_account_id&filter=recorded_owner%3Dilike.' + like + '&order=transfer_date.desc.nullslast&limit=50')
    ]);
    const trueArr = (trueRes && trueRes.data) || [];
    const recArr = (recRes && recRes.data) || [];
    // Deduplicate by address
    const seen = new Set();
    const all = [];
    trueArr.concat(recArr).forEach(function(p) {
      const key = (p.address || p.property_name || '').toLowerCase().trim();
      if (key && !seen.has(key)) { seen.add(key); all.push(p); }
    });

    if (all.length === 0) {
      el.innerHTML = '<div class="detail-empty">No other properties found for this owner.</div>';
      return;
    }

    let html = '<div style="font-size:12px;color:var(--text2);margin-bottom:10px">' + all.length + ' properties found</div>';
    html += '<div style="display:flex;flex-direction:column;gap:6px">';
    all.forEach(function(p) {
      const propName = p.property_name || p.address || 'Unknown';
      const loc = [p.city, p.state].filter(Boolean).join(', ');
      html += '<div style="padding:10px 12px;background:var(--s2);border:1px solid var(--border);border-radius:8px">';
      html += '<div style="font-weight:600;color:var(--text);font-size:13px">' + esc(propName) + '</div>';
      if (p.address && p.address !== propName) html += '<div style="font-size:11px;color:var(--text2)">' + esc(p.address) + '</div>';
      if (loc) html += '<div class="t-meta3">' + esc(loc) + '</div>';
      html += '<div style="display:flex;gap:12px;margin-top:4px;font-size:11px;color:var(--text3)">';
      if (p.sale_price) html += '<span>Sale: <span class="mono" style="color:var(--green)">' + fmt(p.sale_price) + '</span></span>';
      if (p.transfer_date) html += '<span>' + esc(_fmtDate(p.transfer_date)) + '</span>';
      html += '</div>';
      if (p.recorded_owner && p.true_owner && p.recorded_owner !== p.true_owner) {
        html += '<div style="font-size:10px;color:var(--text3);margin-top:2px">' + esc(p.recorded_owner) + ' \u2192 ' + esc(p.true_owner) + '</div>';
      }
      html += '</div>';
    });
    html += '</div>';
    el.innerHTML = html;
  } catch (e) {
    console.warn('Portfolio load failed', e);
    el.innerHTML = '<div class="detail-empty">Failed to load portfolio: ' + esc(e.message || String(e)) + '</div>';
  }
}

/** Begin Prospecting: create a SF task on this owner's account + scroll to Log Activity. */
async function _ownerDrawerBeginProspecting() {
  const c = _ownerDrawerCache;
  if (!c) return;

  if (!c.sf_account_id) {
    showToast('No SF Account linked yet \u2014 create the account first.', 'info');
    return;
  }

  try {
    const payload = {
      sf_company_id: c.sf_account_id,
      sf_contact_id: c.sf_contact_id || undefined,
      activity_type: 'Client Outreach',
      activity_date: new Date().toISOString().split('T')[0],
      outcome: 'no_answer',
      notes: 'Investment Sales - Prospecting opened',
      force: true
    };
    const res = await fetch('/api/sync?action=outbound', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command: 'log_to_sf', payload })
    });
    if (!res.ok) throw new Error('Server returned ' + res.status);
    showToast('Prospecting task created on ' + (c.parent_account_name || c.name), 'success');
  } catch (e) {
    console.warn('Begin Prospecting: SF task creation failed', e);
    showToast('Could not create SF task: ' + e.message, 'error');
  }

  closeDetail();
  setTimeout(function() {
    const logForm = document.getElementById('udLogCallForm');
    if (logForm) {
      logForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
      const notes = document.getElementById('udLogNotes');
      if (notes) {
        notes.value = 'Prospecting ' + (c.parent_account_name || c.name) + ' \u2014 ';
        notes.focus();
      }
    }
  }, 250);
}

/** Open SF account creation in a new tab, prefilled with this owner's name. */
function _ownerDrawerCreateSfAccount() {
  const c = _ownerDrawerCache;
  if (!c) return;
  const name = c.parent_account_name || c.true_owner_name || c.recorded_owner_name || c.name || '';
  const sfNewUrl = _SF_BASE + '/lightning/o/Account/new?defaultFieldValues=Name=' + encodeURIComponent(name);
  window.open(sfNewUrl, '_blank', 'noopener');
  showToast('Opening Salesforce \u2014 New Account form (' + name + ')', 'info');
}

/** Inline Add Contact: writes to unified_contacts via /api/data-query. */
async function _ownerDrawerAddContact() {
  const c = _ownerDrawerCache;
  if (!c) return;
  // A3 (2026-06-06): styled, escapable lccPrompt modals instead of native
  // window.prompt — validated, themed, focus-trapped. Name is required; the
  // rest are optional and Cancel on any optional step just leaves it blank.
  const _ask = typeof lccPrompt === 'function'
    ? (msg, def) => lccPrompt(msg, def)
    : (msg, def) => window.prompt(msg, def);
  const companyForCtx = c.parent_account_name || c.true_owner_name || c.recorded_owner_name || c.name || '';
  const fullNameRaw = await _ask('Add a contact' + (companyForCtx ? ' at ' + companyForCtx : '') + '.\n\nFull name:', '');
  if (fullNameRaw == null) return;
  const fullName = String(fullNameRaw).trim();
  if (!fullName) { showToast('Contact name is required.', 'error'); return; }
  const email = (await _ask('Email (optional — leave blank to skip):', '')) || '';
  const phone = (await _ask('Phone (optional — leave blank to skip):', '')) || '';
  const title = (await _ask('Title (optional — leave blank to skip):', '')) || '';

  const parts = fullName.trim().split(/\s+/);
  const firstName = parts[0] || '';
  const lastName = parts.slice(1).join(' ') || '';
  const companyName = c.parent_account_name || c.true_owner_name || c.recorded_owner_name || c.name || '';

  try {
    const body = {
      first_name: firstName,
      last_name: lastName,
      email: email || null,
      phone: phone || null,
      title: title || null,
      company_name: companyName,
      contact_class: 'business',
      contact_type: 'owner',
      sf_account_id: c.sf_account_id || null,
      true_owner_id: c.true_owner_id || null,
      recorded_owner_id: c.recorded_owner_id || null,
      match_method: 'manual',
      match_confidence: 1.0
    };
    const res = await fetch('/api/data-query?_source=gov&table=unified_contacts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Prefer': 'return=representation' },
      body: JSON.stringify(body)
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    showToast('Contact added to ' + companyName, 'success');
    openOwnerDrawer(c);
  } catch (e) {
    console.error('Add Contact failed', e);
    showToast('Add Contact failed: ' + e.message, 'error');
  }
}

/** Navigate back from OwnerDrawer — pops from the nav stack to restore previous panel content. */
function _ownerDrawerGoBack() {
  if (_ownerDrawerNavStack.length === 0) {
    // Nothing on stack — fall back to closing the panel
    closeDetail();
    return;
  }
  const prev = _ownerDrawerNavStack.pop();
  const headerEl = document.getElementById('detailHeader');
  const tabsEl = document.getElementById('detailTabs');
  const bodyEl = document.getElementById('detailBody');
  if (headerEl) headerEl.innerHTML = prev.header;
  if (tabsEl) tabsEl.innerHTML = prev.tabs;
  if (bodyEl) bodyEl.innerHTML = prev.body;
  // Restore detail state so tab switching works if we're back on a property detail
  if (prev.detailRecord) window._detailRecord = prev.detailRecord;
  if (prev.detailSource) window._detailSource = prev.detailSource;
  if (prev.detailTab) window._detailTab = prev.detailTab;
  _ownerDrawerCache = prev.ownerDrawerCache || null;
}

window._ownerDrawerGoBack = _ownerDrawerGoBack;
window.openOwnerDrawer = openOwnerDrawer;
window._switchOwnerDrawerTab = _switchOwnerDrawerTab;
window._ownerDrawerBeginProspecting = _ownerDrawerBeginProspecting;
window._ownerDrawerCreateSfAccount = _ownerDrawerCreateSfAccount;
window._ownerDrawerAddContact = _ownerDrawerAddContact;
window._ownerLink = _ownerLink;
window._ownerCtxFromCurrent = _ownerCtxFromCurrent;
window._ownerCtxFromChain = _ownerCtxFromChain;
window._switchContactTab = _switchContactTab;

// ============================================================================
// TENANT DRAWER — Click-through panel for tenant names on Rent Roll / Leases
// ============================================================================
//
// Lightweight sibling to OwnerDrawer. Resolves the tenant into a contact
// profile (unified_contacts / available SF contact) and shows:
// - Overview: tenant name, lease summary, firm, SF badge
// - Contacts: unified_contacts linked to tenant company_name / sf_account_id
// - Activities: v_sf_activity_feed scoped to tenant sf_account_id/sf_contact_id
// - Begin Prospecting: creates SF task on the tenant account.

let _tenantDrawerCache = null;

async function openTenantDrawer(ctxJson) {
  let ctx;
  try { ctx = (typeof ctxJson === 'string') ? JSON.parse(ctxJson) : ctxJson; }
  catch (e) { console.error('TenantDrawer: bad ctx', e); return; }
  if (!ctx) return;

  const panel = document.getElementById('detailPanel');
  const overlay = document.getElementById('detailOverlay');
  if (!panel || !overlay) return;
  panel.style.display = 'block';
  overlay.classList.add('open');

  const headerEl = document.getElementById('detailHeader');
  const tabsEl = document.getElementById('detailTabs');
  const bodyEl = document.getElementById('detailBody');

  if (headerEl) headerEl.innerHTML =
    '<button class="detail-back" onclick="closeDetail()">&#x2190;<span>Back</span></button>' +
    '<div class="detail-header-info">' +
      '<div style="flex:1;min-width:0">' +
        '<div class="detail-title">' + esc(ctx.name || 'Tenant') + '</div>' +
        '<div class="detail-subtitle">Loading tenant profile...</div>' +
      '</div>' +
      '<span class="detail-badge" style="background:#3b82f6;color:#fff">TENANT</span>' +
    '</div>' +
    '<button class="detail-close" onclick="closeDetail()">&times;</button>';
  if (tabsEl) tabsEl.innerHTML = '';
  if (bodyEl) bodyEl.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading tenant profile...</p></div>';

  try {
    const resolved = await _resolveTenantProfile(ctx);
    _tenantDrawerCache = resolved;

    const sfBadge = resolved.sf_account_id
      ? '<span style="font-size:10px;padding:2px 8px;border-radius:10px;background:#00a1e0;color:#fff;margin-left:6px">SF linked</span>'
      : '<span style="font-size:10px;padding:2px 8px;border-radius:10px;background:var(--s3);color:var(--text2);margin-left:6px">No SF match</span>';
    if (headerEl) headerEl.innerHTML =
      '<button class="detail-back" onclick="closeDetail()">&#x2190;<span>Back</span></button>' +
      '<div class="detail-header-info">' +
        '<div style="flex:1;min-width:0">' +
          '<div class="detail-title">' + esc(resolved.name || 'Tenant') + sfBadge + '</div>' +
          '<div class="detail-subtitle">Tenant · Lease ' + esc(resolved.lease_number || '—') + '</div>' +
        '</div>' +
        '<span class="detail-badge" style="background:#3b82f6;color:#fff">TENANT</span>' +
      '</div>' +
      '<button class="detail-close" onclick="closeDetail()">&times;</button>';

    const tabs = ['Overview', 'Contacts', 'Activities'];
    if (tabsEl) tabsEl.innerHTML = tabs.map(function(t, i) {
      return '<button class="detail-tab ' + (i === 0 ? 'active' : '') + '" onclick="_switchTenantDrawerTab(\'' + t + '\')">' + t + '</button>';
    }).join('');

    if (bodyEl) bodyEl.innerHTML = _renderTenantDrawerTab('Overview');
  } catch (err) {
    console.error('TenantDrawer error:', err);
    if (bodyEl) bodyEl.innerHTML = '<div class="detail-empty">Error loading tenant profile: ' + esc(err.message || String(err)) + '</div>';
  }
}

async function _resolveTenantProfile(ctx) {
  const out = Object.assign({}, ctx);
  out.contacts = [];
  out.activities = [];

  // Activity feed by sf_account_id or sf_contact_id
  try {
    let actRes = [];
    if (out.sf_account_id) {
      actRes = await diaQuery('v_sf_activity_feed', '*', { filter: 'sf_account_id=eq.' + encodeURIComponent(out.sf_account_id), order: 'activity_date.desc', limit: 100 });
    } else if (out.sf_contact_id) {
      actRes = await diaQuery('v_sf_activity_feed', '*', { filter: 'sf_contact_id=eq.' + encodeURIComponent(out.sf_contact_id), order: 'activity_date.desc', limit: 100 });
    }
    out.activities = Array.isArray(actRes) ? actRes : (actRes && actRes.data) || [];
  } catch (e) { console.warn('TenantDrawer: activity feed failed', e); }

  // Contacts by company name match
  try {
    if (out.name) {
      const like = encodeURIComponent('*' + out.name + '*');
      const cRes = await _entityApiFetch('/api/data-query?_source=gov&table=unified_contacts&select=unified_id,full_name,first_name,last_name,title,email,phone,mobile_phone,sf_contact_id,company_name&filter=company_name%3Dilike.' + like + '&limit=25');
      out.contacts = (cRes && cRes.data) || [];
    }
  } catch (e) { console.warn('TenantDrawer: contacts lookup failed', e); }

  return out;
}

function _renderTenantDrawerTab(tab) {
  const c = _tenantDrawerCache;
  if (!c) return '<div class="detail-empty">No tenant data loaded</div>';
  switch (tab) {
    case 'Overview':   return _tenantDrawerOverview(c);
    case 'Contacts':   return _ownerDrawerContacts(c); // reuse: same shape
    case 'Activities': return _tenantDrawerActivities(c);
    default: return '<div class="detail-empty">Unknown tab</div>';
  }
}

function _switchTenantDrawerTab(tabName) {
  if (!_tenantDrawerCache) return;
  document.querySelectorAll('#detailTabs .detail-tab').forEach(function(t) {
    t.classList.toggle('active', t.textContent.trim() === tabName);
  });
  const bodyEl = document.getElementById('detailBody');
  if (bodyEl) bodyEl.innerHTML = _renderTenantDrawerTab(tabName);
}

function _tenantDrawerOverview(c) {
  let html = '<div class="detail-section"><div class="detail-section-title">Tenant</div><div class="detail-grid">';
  html += _row('Name', c.name);
  if (c.lease_number) html += _row('Lease Number', c.lease_number);
  if (c.property_id) html += _row('Property ID', c.property_id);
  html += '</div></div>';

  if (!c.sf_account_id && !c.sf_contact_id) {
    html += '<div class="detail-section"><div class="detail-section-title">Salesforce</div>';
    html += '<div style="background:rgba(0,161,224,0.08);border:1px solid rgba(0,161,224,0.3);border-radius:10px;padding:14px 16px">';
    html += '<div style="font-size:13px;color:var(--text);margin-bottom:8px">No Salesforce match found for <strong>' + esc(c.name || 'this tenant') + '</strong>.</div>';
    html += '<div style="font-size:12px;color:var(--text2);margin-bottom:12px">Create the SF Account so tenant-level activities can be tracked.</div>';
    html += '<button class="act-btn primary" onclick="_tenantDrawerCreateSfAccount()">+ Create Salesforce Account</button>';
    html += '</div></div>';
  }

  html += '<div class="detail-section"><div class="detail-section-title">Prospecting</div>';
  html += '<div style="background:linear-gradient(135deg,rgba(59,130,246,0.12),rgba(0,161,224,0.08));border:1px solid rgba(59,130,246,0.25);border-radius:10px;padding:14px 16px">';
  html += '<div style="font-size:13px;color:var(--text);margin-bottom:6px;font-weight:600">Begin Prospecting</div>';
  html += '<div style="font-size:12px;color:var(--text2);margin-bottom:12px">Creates a Salesforce task on <strong>' + esc(c.name) + '</strong> and opens the activity log.</div>';
  html += '<button class="act-btn primary" onclick="_tenantDrawerBeginProspecting()" style="background:#3b82f6;color:#fff">\u2192 Begin Prospecting</button>';
  html += '</div></div>';

  html += '<div class="detail-section"><div class="detail-section-title">Engagement Snapshot</div>';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">';
  html += '<div style="text-align:center;padding:12px;background:var(--s2);border-radius:8px"><div style="font-size:20px;font-weight:700;color:var(--purple)">' + (c.contacts?.length || 0) + '</div><div class="t-meta3">Contacts</div></div>';
  html += '<div style="text-align:center;padding:12px;background:var(--s2);border-radius:8px"><div style="font-size:20px;font-weight:700;color:var(--green)">' + (c.activities?.length || 0) + '</div><div class="t-meta3">Activities</div></div>';
  html += '</div></div>';

  return html;
}

function _tenantDrawerActivities(c) {
  const list = c.activities || [];
  if (list.length === 0) {
    return '<div class="detail-section"><div class="detail-section-title">Activities</div><div class="detail-empty">No activity on file for this tenant.</div></div>';
  }
  let html = '<div class="detail-section"><div class="detail-section-title">Activities (' + list.length + ')</div>';
  list.forEach(function(a) {
    const typeColor = (a.feed_type === 'task') ? 'var(--yellow)'
      : (a.feed_type === 'call_outcome') ? 'var(--green)' : 'var(--accent)';
    html += '<div class="detail-card">';
    html += '<div class="detail-card-header">';
    html += '<div class="detail-card-title">' + esc(a.subject || a.activity_type || 'Activity') + '</div>';
    html += '<div class="detail-card-date">' + esc(_fmtDate(a.activity_date)) + '</div>';
    html += '</div><div class="detail-card-body">';
    html += '<span style="display:inline-block;font-size:10px;padding:2px 6px;border-radius:4px;background:' + typeColor + ';color:#fff;margin-bottom:4px">' + esc(a.feed_type || a.activity_type || '') + '</span>';
    if (a.notes) html += '<br><span style="font-size:12px;color:var(--text2);white-space:pre-wrap">' + esc(String(a.notes).substring(0, 220)) + (a.notes.length > 220 ? '...' : '') + '</span>';
    html += '</div></div>';
  });
  html += '</div>';
  return html;
}

async function _tenantDrawerBeginProspecting() {
  const c = _tenantDrawerCache;
  if (!c) return;
  try {
    const payload = {
      sf_company_id: c.sf_account_id || undefined,
      sf_contact_id: c.sf_contact_id || undefined,
      activity_type: 'Tenant Outreach',
      activity_date: new Date().toISOString().split('T')[0],
      outcome: 'no_answer',
      notes: 'Tenant prospecting opened for ' + c.name,
      force: true
    };
    const res = await fetch('/api/sync?action=outbound', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command: 'log_to_sf', payload })
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    showToast('Prospecting task created for ' + c.name, 'success');
  } catch (e) {
    showToast('Could not create SF task: ' + e.message, 'error');
  }
}

function _tenantDrawerCreateSfAccount() {
  const c = _tenantDrawerCache;
  if (!c) return;
  const sfNewUrl = _SF_BASE + '/lightning/o/Account/new?defaultFieldValues=Name=' + encodeURIComponent(c.name || '');
  window.open(sfNewUrl, '_blank', 'noopener');
  showToast('Opening Salesforce — New Account form (' + c.name + ')', 'info');
}

// Delegated click handler for .tenant-link elements
document.addEventListener('click', function (e) {
  const el = e.target && e.target.closest && e.target.closest('.tenant-link[data-tenant-ctx]');
  if (!el) return;
  e.preventDefault();
  e.stopPropagation();
  try {
    const raw = decodeURIComponent(el.getAttribute('data-tenant-ctx') || '');
    if (raw) openTenantDrawer(raw);
  } catch (err) { console.warn('tenant-link click: bad payload', err); }
});
document.addEventListener('keydown', function (e) {
  if (e.key !== 'Enter' && e.key !== ' ') return;
  const el = e.target && e.target.closest && e.target.closest('.tenant-link[data-tenant-ctx]');
  if (!el) return;
  e.preventDefault();
  try {
    const raw = decodeURIComponent(el.getAttribute('data-tenant-ctx') || '');
    if (raw) openTenantDrawer(raw);
  } catch (err) { /* ignore */ }
});

window.openTenantDrawer = openTenantDrawer;
window._switchTenantDrawerTab = _switchTenantDrawerTab;
window._tenantDrawerBeginProspecting = _tenantDrawerBeginProspecting;
window._tenantDrawerCreateSfAccount = _tenantDrawerCreateSfAccount;

// ============================================================================
// BROKER DRAWER — Click-through panel for listing/sale broker names
// ============================================================================
//
// Shows the broker's firm, past deals on this property, and SF activity feed.
// Resolves by broker name against unified_contacts.

let _brokerDrawerCache = null;

async function openBrokerDrawer(ctxJson) {
  let ctx;
  try { ctx = (typeof ctxJson === 'string') ? JSON.parse(ctxJson) : ctxJson; }
  catch (e) { console.error('BrokerDrawer: bad ctx', e); return; }
  if (!ctx) return;

  const panel = document.getElementById('detailPanel');
  const overlay = document.getElementById('detailOverlay');
  if (!panel || !overlay) return;
  panel.style.display = 'block';
  overlay.classList.add('open');

  const headerEl = document.getElementById('detailHeader');
  const tabsEl = document.getElementById('detailTabs');
  const bodyEl = document.getElementById('detailBody');

  if (headerEl) headerEl.innerHTML =
    '<button class="detail-back" onclick="closeDetail()">&#x2190;<span>Back</span></button>' +
    '<div class="detail-header-info">' +
      '<div style="flex:1;min-width:0">' +
        '<div class="detail-title">' + esc(ctx.name || 'Broker') + '</div>' +
        '<div class="detail-subtitle">Loading broker profile...</div>' +
      '</div>' +
      '<span class="detail-badge" style="background:#f59e0b;color:#fff">BROKER</span>' +
    '</div>' +
    '<button class="detail-close" onclick="closeDetail()">&times;</button>';
  if (tabsEl) tabsEl.innerHTML = '';
  if (bodyEl) bodyEl.innerHTML = '<div style="text-align:center;padding:48px;color:var(--text2)"><span class="spinner"></span><p style="margin-top:12px">Loading broker profile...</p></div>';

  try {
    const resolved = await _resolveBrokerProfile(ctx);
    _brokerDrawerCache = resolved;

    const sfBadge = resolved.sf_contact_id || resolved.sf_account_id
      ? '<span style="font-size:10px;padding:2px 8px;border-radius:10px;background:#00a1e0;color:#fff;margin-left:6px">SF linked</span>'
      : '<span style="font-size:10px;padding:2px 8px;border-radius:10px;background:var(--s3);color:var(--text2);margin-left:6px">No SF match</span>';
    if (headerEl) headerEl.innerHTML =
      '<button class="detail-back" onclick="closeDetail()">&#x2190;<span>Back</span></button>' +
      '<div class="detail-header-info">' +
        '<div style="flex:1;min-width:0">' +
          '<div class="detail-title">' + esc(resolved.name || 'Broker') + sfBadge + '</div>' +
          '<div class="detail-subtitle">Broker' + (resolved.broker_firm ? ' · ' + esc(resolved.broker_firm) : '') + '</div>' +
        '</div>' +
        '<span class="detail-badge" style="background:#f59e0b;color:#fff">BROKER</span>' +
      '</div>' +
      '<button class="detail-close" onclick="closeDetail()">&times;</button>';

    const tabs = ['Overview', 'Activities', 'Deals'];
    if (tabsEl) tabsEl.innerHTML = tabs.map(function(t, i) {
      return '<button class="detail-tab ' + (i === 0 ? 'active' : '') + '" onclick="_switchBrokerDrawerTab(\'' + t + '\')">' + t + '</button>';
    }).join('');

    if (bodyEl) bodyEl.innerHTML = _renderBrokerDrawerTab('Overview');
  } catch (err) {
    console.error('BrokerDrawer error:', err);
    if (bodyEl) bodyEl.innerHTML = '<div class="detail-empty">Error loading broker profile: ' + esc(err.message || String(err)) + '</div>';
  }
}

async function _resolveBrokerProfile(ctx) {
  const out = Object.assign({}, ctx);
  out.activities = [];
  out.deals = [];

  // Lookup contact by name
  try {
    const like = encodeURIComponent('*' + (out.name || '') + '*');
    const cRes = await _entityApiFetch('/api/data-query?_source=gov&table=unified_contacts&select=unified_id,full_name,title,email,phone,sf_contact_id,sf_account_id,company_name&filter=full_name%3Dilike.' + like + '&limit=5');
    const matches = (cRes && cRes.data) || [];
    if (matches.length) {
      out.sf_contact_id = out.sf_contact_id || matches[0].sf_contact_id || null;
      out.sf_account_id = out.sf_account_id || matches[0].sf_account_id || null;
      out.broker_firm = out.broker_firm || matches[0].company_name || null;
      out.email = matches[0].email || null;
      out.phone = matches[0].phone || null;
    }
  } catch (e) { /* ignore */ }

  // Activity feed by sf_contact_id
  if (out.sf_contact_id) {
    try {
      const actRes = await diaQuery('v_sf_activity_feed', '*', { filter: 'sf_contact_id=eq.' + encodeURIComponent(out.sf_contact_id), order: 'activity_date.desc', limit: 50 });
      out.activities = Array.isArray(actRes) ? actRes : (actRes && actRes.data) || [];
    } catch (e) { /* ignore */ }
  }

  // Past deals by broker name on this property (from current sales cache)
  if (_salesCache) {
    out.deals = (_salesCache.transactions || []).filter(t => (t.broker_name || t.listing_broker) && String(t.broker_name || t.listing_broker).toLowerCase() === String(out.name || '').toLowerCase());
  }

  return out;
}

function _renderBrokerDrawerTab(tab) {
  const c = _brokerDrawerCache;
  if (!c) return '<div class="detail-empty">No broker data loaded</div>';
  switch (tab) {
    case 'Overview':   return _brokerDrawerOverview(c);
    case 'Activities': return _tenantDrawerActivities(c);
    case 'Deals':      return _brokerDrawerDeals(c);
    default: return '<div class="detail-empty">Unknown tab</div>';
  }
}

function _switchBrokerDrawerTab(tabName) {
  if (!_brokerDrawerCache) return;
  document.querySelectorAll('#detailTabs .detail-tab').forEach(function(t) {
    t.classList.toggle('active', t.textContent.trim() === tabName);
  });
  const bodyEl = document.getElementById('detailBody');
  if (bodyEl) bodyEl.innerHTML = _renderBrokerDrawerTab(tabName);
}

function _brokerDrawerOverview(c) {
  let html = '<div class="detail-section"><div class="detail-section-title">Broker</div><div class="detail-grid">';
  html += _row('Name', c.name);
  if (c.broker_firm) html += _row('Firm', c.broker_firm);
  if (c.email) html += _rowLink('Email', c.email, 'mailto:' + c.email);
  if (c.phone) html += _rowLink('Phone', c.phone, 'tel:' + c.phone);
  html += '</div></div>';

  html += '<div class="detail-section"><div class="detail-section-title">Prospecting</div>';
  html += '<div style="background:linear-gradient(135deg,rgba(245,158,11,0.12),rgba(0,161,224,0.08));border:1px solid rgba(245,158,11,0.25);border-radius:10px;padding:14px 16px">';
  html += '<div style="font-size:13px;color:var(--text);margin-bottom:6px;font-weight:600">Begin Prospecting</div>';
  html += '<div style="font-size:12px;color:var(--text2);margin-bottom:12px">Creates a Salesforce task on <strong>' + esc(c.name) + '</strong>.</div>';
  html += '<button class="act-btn primary" onclick="_brokerDrawerBeginProspecting()" style="background:#f59e0b;color:#fff">\u2192 Begin Prospecting</button>';
  html += '</div></div>';

  html += '<div class="detail-section"><div class="detail-section-title">Engagement Snapshot</div>';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">';
  html += '<div style="text-align:center;padding:12px;background:var(--s2);border-radius:8px"><div style="font-size:20px;font-weight:700;color:var(--green)">' + (c.activities?.length || 0) + '</div><div class="t-meta3">Activities</div></div>';
  html += '<div style="text-align:center;padding:12px;background:var(--s2);border-radius:8px"><div style="font-size:20px;font-weight:700;color:var(--accent)">' + (c.deals?.length || 0) + '</div><div class="t-meta3">Deals (this property)</div></div>';
  html += '</div></div>';
  return html;
}

function _brokerDrawerDeals(c) {
  const deals = c.deals || [];
  if (deals.length === 0) {
    return '<div class="detail-section"><div class="detail-section-title">Deals</div><div class="detail-empty">No deals recorded for this broker on this property.</div></div>';
  }
  let html = '<div class="detail-section"><div class="detail-section-title">Deals (' + deals.length + ')</div>';
  deals.forEach(d => {
    html += '<div class="detail-card"><div class="detail-card-header">';
    html += '<div class="detail-card-title">' + esc(d.transaction_type || 'Sale') + (d.price ? ' — ' + fmt(d.price) : '') + '</div>';
    html += '<div class="detail-card-date">' + esc(_fmtDate(d.sale_date)) + '</div>';
    html += '</div><div class="detail-card-body">';
    if (d.buyer_name) html += '<div>Buyer: ' + esc(d.buyer_name) + '</div>';
    if (d.seller_name) html += '<div>Seller: ' + esc(d.seller_name) + '</div>';
    if (d.cap_rate) html += '<div>Cap: ' + (_fmtCapRate(d.cap_rate) || '') + '</div>';
    html += '</div></div>';
  });
  html += '</div>';
  return html;
}

async function _brokerDrawerBeginProspecting() {
  const c = _brokerDrawerCache;
  if (!c) return;
  try {
    const payload = {
      sf_company_id: c.sf_account_id || undefined,
      sf_contact_id: c.sf_contact_id || undefined,
      activity_type: 'Broker Outreach',
      activity_date: new Date().toISOString().split('T')[0],
      outcome: 'no_answer',
      notes: 'Broker prospecting opened for ' + c.name,
      force: true
    };
    const res = await fetch('/api/sync?action=outbound', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command: 'log_to_sf', payload })
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    showToast('Prospecting task created for ' + c.name, 'success');
  } catch (e) {
    showToast('Could not create SF task: ' + e.message, 'error');
  }
}

// Delegated click handler for .broker-link elements
document.addEventListener('click', function (e) {
  const el = e.target && e.target.closest && e.target.closest('.broker-link[data-broker-ctx]');
  if (!el) return;
  e.preventDefault();
  e.stopPropagation();
  try {
    const raw = decodeURIComponent(el.getAttribute('data-broker-ctx') || '');
    if (raw) openBrokerDrawer(raw);
  } catch (err) { console.warn('broker-link click: bad payload', err); }
});
document.addEventListener('keydown', function (e) {
  if (e.key !== 'Enter' && e.key !== ' ') return;
  const el = e.target && e.target.closest && e.target.closest('.broker-link[data-broker-ctx]');
  if (!el) return;
  e.preventDefault();
  try {
    const raw = decodeURIComponent(el.getAttribute('data-broker-ctx') || '');
    if (raw) openBrokerDrawer(raw);
  } catch (err) { /* ignore */ }
});

window.openBrokerDrawer = openBrokerDrawer;
window._switchBrokerDrawerTab = _switchBrokerDrawerTab;
window._brokerDrawerBeginProspecting = _brokerDrawerBeginProspecting;

// ============================================================================
// LEASE COMPS EXPORT — sidebar header button (Dia + Gov)
// Renders the count dropdown + "Export Lease Comps" button in the unified
// detail header. Pulls the N nearest comparable lease properties (by great-
// circle distance from the subject's lat/lng), enriches them with current /
// last-known rent and owner-of-record info, flags owner-occupied comps, and
// writes a single-sheet xlsx with the subject as a header row.
// ============================================================================

const _UD_LEASE_COMPS_COUNTS = [10, 15, 20, 25, 50];
const _UD_LEASE_COMPS_DEFAULT = 20;

function _udLeaseCompsControlHtml(db, propertyId) {
  // Disable when there's no anchor property — we can't compute distances
  // without subject lat/lng, and lat/lng comes from the property record.
  const disabled = propertyId ? '' : 'disabled';
  const opts = _UD_LEASE_COMPS_COUNTS.map(n =>
    `<option value="${n}"${n === _UD_LEASE_COMPS_DEFAULT ? ' selected' : ''}>${n}</option>`
  ).join('');
  // Wrap select+button in a single inline-flex group so they read as one
  // control. Styling mirrors the consolidate button's neutral chrome.
  return `
    <div style="display:inline-flex;align-items:stretch;gap:0;margin-right:8px" title="${disabled ? 'Open a property with a property_id to export lease comps' : 'Export the N nearest lease comparables to Excel'}">
      <select id="udLeaseCompsCount" ${disabled}
        style="background:transparent;border:1px solid var(--border);border-right:none;color:var(--text2);padding:6px 8px;border-radius:6px 0 0 6px;font-size:12px;font-family:Outfit,sans-serif;${disabled ? 'opacity:0.6;cursor:not-allowed' : 'cursor:pointer'}"
        title="Number of nearest comps to include">
        ${opts}
      </select>
      <button class="detail-action-btn" id="udLeaseCompsExportBtn"
        onclick="_udExportLeaseComps('${db}', ${propertyId || 'null'}, this)"
        ${disabled}
        style="background:transparent;border:1px solid var(--border);color:var(--text2);padding:6px 12px;border-radius:0 6px 6px 0;font-size:12px;cursor:${disabled ? 'not-allowed' : 'pointer'};${disabled ? 'opacity:0.6' : ''}">
        📊 Export Lease Comps
      </button>
    </div>`;
}

// Great-circle distance in miles. Returns null if any coordinate is missing
// or non-numeric — callers should treat null as "unknown" rather than 0.
function _udHaversineMiles(lat1, lon1, lat2, lon2) {
  const a1 = Number(lat1), n1 = Number(lon1), a2 = Number(lat2), n2 = Number(lon2);
  if (!isFinite(a1) || !isFinite(n1) || !isFinite(a2) || !isFinite(n2)) return null;
  const R = 3958.7613; // Earth's mean radius in statute miles
  const toRad = (d) => d * Math.PI / 180;
  const dLat = toRad(a2 - a1);
  const dLon = toRad(n2 - n1);
  const s = Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a1)) * Math.cos(toRad(a2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
}

function _udNormName(s) {
  return String(s || '')
    .toLowerCase()
    .replace(/\b(inc|llc|llp|lp|ltd|corp|corporation|company|co|holdings|trust|properties|realty|partners|the)\b/g, '')
    .replace(/[^a-z0-9]+/g, '')
    .trim();
}

// "Owner-occupied" = the recorded/true owner of the building is the same
// entity as the operator/tenant. We don't have a persisted flag, so we
// fuzzy-compare normalized names. Returns true only on a confident match
// (exact-equal after stripping legal suffixes, or one fully contains the
// other and the shorter side is at least 5 normalized chars).
function _udIsOwnerOccupied(tenant, owner) {
  const t = _udNormName(tenant);
  const o = _udNormName(owner);
  if (!t || !o) return false;
  if (t === o) return true;
  const shorter = t.length < o.length ? t : o;
  const longer  = t.length < o.length ? o : t;
  if (shorter.length >= 5 && longer.includes(shorter)) return true;
  return false;
}

function _udNumOrNull(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return isFinite(n) ? n : null;
}

function _udYearsBetween(fromIso, toIso) {
  if (!fromIso || !toIso) return null;
  const a = new Date(fromIso), b = new Date(toIso);
  if (isNaN(a) || isNaN(b)) return null;
  return Math.round(((b - a) / (365.25 * 86400 * 1000)) * 10) / 10;
}

function _udFmtDateIso(d) {
  if (!d) return '';
  const dt = new Date(d);
  if (isNaN(dt)) return String(d).slice(0, 10);
  return dt.toISOString().slice(0, 10);
}

// We pull v_property_detail with select='*' rather than an explicit column
// list — the view's column set differs slightly between Dia and Gov, and
// PostgREST 400s on any unknown column. Bandwidth is fine for ≤ 5000 rows.

// Coerce whatever land-size field the source view exposes into acres. Dia
// properties carry both `lot_sf` (square feet) and `land_area` (sometimes
// SF, sometimes acres depending on import); gov mostly carries `land_acres`.
// Heuristic: anything > 100 is treated as square feet (43,560 SF = 1 acre);
// values ≤ 100 are already acres.
function _udLandAcres(rec) {
  if (!rec) return null;
  const acres = _udNumOrNull(rec.land_acres);
  if (acres != null && acres > 0) return acres;
  const lotSf = _udNumOrNull(rec.lot_sf);
  if (lotSf != null && lotSf > 0) return Math.round((lotSf / 43560) * 100) / 100;
  const landArea = _udNumOrNull(rec.land_area);
  if (landArea == null) return null;
  if (landArea > 100) return Math.round((landArea / 43560) * 100) / 100;
  return Math.round(landArea * 100) / 100;
}

// Pick the chain / parent operator name (TENANT column) separate from the
// local facility / sub-entity (OPERATOR column). For dialysis, TENANT is
// usually the chain (DaVita, Fresenius); OPERATOR is the local clinic
// trade name. For gov, TENANT is the agency short code; OPERATOR is the
// full agency or sub-component.
function _udExtractTenantOperator(db, rec, fb, lease) {
  rec = rec || {}; fb = fb || {}; lease = lease || {};
  if (db === 'gov') {
    const tenant = rec.agency_short || rec.agency || fb.tenant_agency
                || fb.agency || lease.tenant_name || '';
    const operator = rec.agency_full || rec.agency || fb.agency_full
                  || tenant || '';
    return { tenant, operator };
  }
  // Dialysis: chain vs local operator
  const chain = rec.chain_organization || fb.chain_organization || rec.tenant
             || rec.tenant_operator || lease.tenant_name || '';
  const local = rec.operator_name || fb.operator_name || rec.facility_name
             || fb.facility_name || '';
  return {
    tenant: chain || local || lease.tenant_name || '',
    operator: local || chain || ''
  };
}

function _udSubjectFromCache(db) {
  const c = _udCache || {};
  const p = c.property || {};
  const fb = c.fallback || {};
  const own = c.ownership || {};
  const lease = (c.leases && c.leases[0]) || {};
  const buildingSf = _udNumOrNull(p.building_size || p.building_sf || p.rba || fb.building_sf);
  const leasedArea = _udNumOrNull(lease.leased_area || lease.leased_sf || p.leased_area)
                  || buildingSf;
  const { tenant, operator } = _udExtractTenantOperator(db || c.db, p, fb, lease);
  return {
    property_id: c.ids?.property_id || p.property_id || null,
    lease_number: p.lease_number || c.ids?.lease_number || null,
    db: c.db || null,
    tenant, // chain
    operator, // local entity (clinic / sub-agency)
    address: p.address || fb.address || '',
    city: p.city || fb.city || '',
    state: p.state || fb.state || '',
    zip: p.zip_code || fb.zip || '',
    latitude: _udNumOrNull(p.latitude || fb.latitude),
    longitude: _udNumOrNull(p.longitude || fb.longitude),
    building_sf: buildingSf,
    leased_area: leasedArea,
    occupancy: (buildingSf && leasedArea) ? Math.min(1, leasedArea / buildingSf) : null,
    land_acres: _udLandAcres({ land_acres: p.land_acres, land_area: p.land_area, lot_sf: p.lot_sf }),
    year_built: _udNumOrNull(p.year_built || fb.year_built),
    year_renovated: _udNumOrNull(p.year_renovated || fb.year_renovated),
    lease_start: lease.lease_start || lease.lease_commencement || p.lease_commencement || fb.lease_start || null,
    lease_expiration: lease.lease_expiration || lease.expiration_date || fb.lease_end || null,
    annual_rent: _udNumOrNull(lease.annual_rent || p.annual_rent || fb.annual_rent),
    rent_per_sf: _udNumOrNull(lease.rent_per_sf || p.rent_per_sf || fb.rent_per_sf),
    expense_structure: lease.expense_structure || p.expense_structure || '',
    lease_bump_pct: _udNumOrNull(p.lease_bump_pct || lease.lease_bump_pct),
    lease_bump_interval_mo: _udNumOrNull(p.lease_bump_interval_mo || lease.lease_bump_interval_mo),
    recorded_owner: own.recorded_owner || own.recorded_owner_name || p.recorded_owner_name || '',
    true_owner: own.true_owner || own.true_owner_name || p.true_owner_name || ''
  };
}

async function _udFetchLeaseCompCandidates(db, subject, count) {
  const qFn = db === 'gov' ? govQuery : diaQuery;

  // Two-stage fetch:
  //
  // 1) Universe pull from base `properties` — ONLY the columns needed to
  //    rank by distance (property_id + lat/lng). v_property_detail times
  //    out at the DB (Postgres 57014) when fully-projected with limit
  //    5000 because it joins ownership, leases, parcel records, etc.
  //    Selecting just three integer/numeric columns keeps the payload
  //    well under any statement-timeout budget.
  //
  //    The universe is constrained server-side to a bounding box around
  //    the subject. Without it, PostgREST orders by primary key and the
  //    5000-row cap silently drops geographically-relevant rows once
  //    geocoded coverage exceeds 5000 (audit 2026-05-09: ~30% of dia
  //    subjects and ~50% of gov subjects were getting wrong "nearest"
  //    comps because the true nearest lived past pid 5000 in the
  //    primary-key ordering). We try a tight radius first (covers nearly
  //    every realistic dialysis use) and expand only if too few rows came
  //    back — most queries finish in one round-trip.
  //
  // 2) Top-K enrichment after the haversine sort — v_property_detail,
  //    v_lease_detail and v_ownership_current pulled for at most ~50 rows.
  //    Those joins are fine at that scale.
  const RADII_MI = [150, 500, 2000];
  const lat0 = Number(subject.latitude);
  const lng0 = Number(subject.longitude);
  const cosLat = Math.cos(lat0 * Math.PI / 180);
  let props = [];
  let radiusUsed = null;
  for (const radius of RADII_MI) {
    const dLat = radius / 69.0;
    const dLng = radius / Math.max(0.01, 69.0 * Math.abs(cosLat));
    const bbox = 'and=(' + [
      `latitude.gte.${(lat0 - dLat).toFixed(6)}`,
      `latitude.lte.${(lat0 + dLat).toFixed(6)}`,
      `longitude.gte.${(lng0 - dLng).toFixed(6)}`,
      `longitude.lte.${(lng0 + dLng).toFixed(6)}`
    ].join(',') + ')';
    const propsRes = await qFn('properties', 'property_id,latitude,longitude', {
      filter: bbox,
      limit: 5000
    });
    props = Array.isArray(propsRes) ? propsRes : (propsRes?.data || []);
    radiusUsed = radius;
    // +1 because the subject itself is in its own box and gets filtered
    // out of `ranked` below; we need `count` real comps after that drop.
    if (props.length >= count + 1) break;
  }

  // Diagnostic surface: now scoped to the bbox neighborhood, not the
  // global geocoded set. Stash on window so the next toast can read it
  // without another fetch.
  window._udLastGeocodeUniverseSize = props.length;
  window._udLastGeocodeRadiusMi = radiusUsed;

  // Distance-rank, drop the subject itself, slice to the requested count.
  const ranked = props
    .filter(p => p.property_id && p.property_id !== subject.property_id)
    .map(p => {
      const d = _udHaversineMiles(subject.latitude, subject.longitude, p.latitude, p.longitude);
      return d == null ? null : Object.assign({}, p, { distance_miles: d });
    })
    .filter(Boolean)
    .sort((a, b) => a.distance_miles - b.distance_miles)
    .slice(0, count);

  // Diagnostic logging — lets us tell apart "props came back but
  // distance computation killed all of them" from "PostgREST returned
  // an empty list to begin with." Logs to console with a stable prefix
  // so it's easy to grep in browser devtools.
  if (ranked.length === 0 && props.length > 0) {
    const sample = props.slice(0, 3).map(p => ({
      property_id: p.property_id,
      latitude: p.latitude,
      longitude: p.longitude,
      lat_type: typeof p.latitude,
      lng_type: typeof p.longitude,
      hav_miles: _udHaversineMiles(subject.latitude, subject.longitude, p.latitude, p.longitude)
    }));
    console.warn('[lease-comps] universe>0 but ranked=0', {
      universe: props.length,
      radius_mi: radiusUsed,
      subject: {
        property_id: subject.property_id,
        latitude: subject.latitude,
        longitude: subject.longitude,
        lat_type: typeof subject.latitude,
        lng_type: typeof subject.longitude
      },
      sample
    });
  } else if (props.length === 0) {
    console.warn(`[lease-comps] PostgREST returned no rows within ${radiusUsed} mi of subject (${subject.latitude},${subject.longitude})`);
  } else {
    console.info(`[lease-comps] universe=${props.length} radius=${radiusUsed}mi ranked=${ranked.length} nearestMi=${ranked[0]?.distance_miles?.toFixed(2)}`);
  }

  if (ranked.length === 0) return [];

  const ids = ranked.map(r => r.property_id);

  // PostgREST in.() filter — comma-joined list of property_ids
  const inList = ids.map(id => encodeURIComponent(id)).join(',');

  // Pull rich property attributes + current lease + ownership in parallel
  // for the chosen comp set. v_property_detail is heavy but bounded here
  // to ≤50 rows, so the joins finish in milliseconds. All three are
  // best-effort: any one failing shouldn't block the export.
  const [propRes, leaseRes, ownRes] = await Promise.allSettled([
    qFn('v_property_detail', '*', {
      filter: `property_id=in.(${inList})`,
      limit: ids.length
    }),
    qFn('v_lease_detail', '*', {
      filter: `property_id=in.(${inList})`,
      limit: ids.length * 5
    }),
    qFn('v_ownership_current', '*', {
      filter: `property_id=in.(${inList})`,
      limit: ids.length * 2
    })
  ]);
  const propDetails = propRes.status === 'fulfilled'
    ? (Array.isArray(propRes.value) ? propRes.value : (propRes.value?.data || []))
    : [];
  const leases = leaseRes.status === 'fulfilled'
    ? (Array.isArray(leaseRes.value) ? leaseRes.value : (leaseRes.value?.data || []))
    : [];
  const owners = ownRes.status === 'fulfilled'
    ? (Array.isArray(ownRes.value) ? ownRes.value : (ownRes.value?.data || []))
    : [];

  const propByPid = new Map();
  for (const row of propDetails) {
    if (row?.property_id && !propByPid.has(row.property_id)) propByPid.set(row.property_id, row);
  }

  // Index leases by property_id, preferring the active term (or latest expiration).
  const leaseByProp = new Map();
  for (const l of leases) {
    const pid = l.property_id;
    if (!pid) continue;
    const cur = leaseByProp.get(pid);
    if (!cur) { leaseByProp.set(pid, l); continue; }
    const isActive = (x) => x && (x.is_active === true || x.is_active === 'true');
    if (isActive(l) && !isActive(cur)) { leaseByProp.set(pid, l); continue; }
    const expA = new Date(l.lease_expiration || l.expiration_date || 0).getTime();
    const expB = new Date(cur.lease_expiration || cur.expiration_date || 0).getTime();
    if (expA > expB) leaseByProp.set(pid, l);
  }

  const ownerByProp = new Map();
  for (const o of owners) {
    if (o.property_id && !ownerByProp.has(o.property_id)) ownerByProp.set(o.property_id, o);
  }

  return ranked.map(rk => {
    // Merge the slim ranked row (property_id, lat/lng, distance) with the
    // rich v_property_detail row (address, sf, year_built, ...). Rank row
    // wins for fields it explicitly carries (id, lat/lng, distance_miles).
    const det = propByPid.get(rk.property_id) || {};
    const p = Object.assign({}, det, rk);
    const l = leaseByProp.get(p.property_id) || {};
    const o = ownerByProp.get(p.property_id) || {};
    const { tenant, operator } = _udExtractTenantOperator(db, p, {}, l);
    const owner  = o.true_owner || o.recorded_owner
                || p.true_owner_name || p.true_owner
                || p.recorded_owner_name || p.recorded_owner || '';
    const buildingSf = _udNumOrNull(p.building_size || p.building_sf || p.rba);
    const leasedArea = _udNumOrNull(l.leased_area || l.leased_sf || p.leased_area)
                    || buildingSf;
    return {
      property_id: p.property_id,
      lease_number: p.lease_number || l.lease_number || '',
      tenant,
      operator,
      owner,
      owner_occupied: _udIsOwnerOccupied(tenant, owner) || _udIsOwnerOccupied(operator, owner),
      address: p.address || '',
      city: p.city || '',
      state: p.state || '',
      zip: p.zip_code || '',
      latitude: p.latitude,
      longitude: p.longitude,
      distance_miles: p.distance_miles,
      building_sf: buildingSf,
      leased_area: leasedArea,
      occupancy: (buildingSf && leasedArea) ? Math.min(1, leasedArea / buildingSf) : null,
      land_acres: _udLandAcres({ land_acres: p.land_acres, land_area: p.land_area, lot_sf: p.lot_sf }),
      year_built: _udNumOrNull(p.year_built),
      year_renovated: _udNumOrNull(p.year_renovated),
      lease_start: l.lease_start || l.lease_commencement || p.lease_commencement || null,
      lease_expiration: l.lease_expiration || l.expiration_date || null,
      annual_rent: _udNumOrNull(l.annual_rent || p.annual_rent),
      rent_per_sf: _udNumOrNull(l.rent_per_sf || p.rent_per_sf),
      expense_structure: l.expense_structure || p.expense_structure || '',
      lease_bump_pct: _udNumOrNull(l.lease_bump_pct || p.lease_bump_pct),
      lease_bump_interval_mo: _udNumOrNull(l.lease_bump_interval_mo || p.lease_bump_interval_mo)
    };
  });
}

function _udFmtBumps(pct, intervalMo) {
  if (pct == null && intervalMo == null) return '';
  const p = pct == null ? '?' : (Number(pct).toFixed(2).replace(/\.?0+$/, '') + '%');
  const i = intervalMo == null ? '?' : (Number(intervalMo) + 'mo');
  return `${p} / ${i}`;
}

async function _udExportLeaseComps(db, propertyId, btn) {
  // Fall back to whatever the panel resolved during load. The header HTML
  // is generated once, but for CMS-clinic / fallback-only clicks the
  // property_id only materializes after a medicare_clinics or address
  // lookup — so the inline arg can lag behind reality. Cache wins.
  if (!propertyId) {
    propertyId = _udCache?.property?.property_id
              || _udCache?.ids?.property_id
              || null;
  }
  if (!propertyId) {
    showToast('Open a property with a property_id to export lease comps', 'error');
    return;
  }
  const sel = document.getElementById('udLeaseCompsCount');
  const count = Math.max(1, parseInt(sel?.value || String(_UD_LEASE_COMPS_DEFAULT), 10) || _UD_LEASE_COMPS_DEFAULT);

  const subject = _udSubjectFromCache(db);
  if (subject.latitude == null || subject.longitude == null) {
    // v_property_detail's column list varies by deployment and doesn't
    // always expose latitude/longitude — those columns live on the
    // underlying `properties` table. Self-fetch from there as a fallback
    // before declaring the subject ungeocoded.
    const qFn = db === 'gov' ? govQuery : diaQuery;
    try {
      const res = await qFn('properties', 'property_id,latitude,longitude', {
        filter: `property_id=eq.${propertyId}`,
        limit: 1
      });
      const row = (Array.isArray(res) ? res : (res?.data || []))[0] || null;
      if (row) {
        subject.latitude = _udNumOrNull(row.latitude);
        subject.longitude = _udNumOrNull(row.longitude);
      }
    } catch (e) { console.warn('subject coord fetch failed', e); }
  }
  // Last-resort: geocode the subject's address via Nominatim (OpenStreetMap)
  // and persist the result back to properties so subsequent exports use the
  // stored coords. This handles legacy / CMS-imported clinics that landed in
  // the table without geocoding. Best-effort: any failure (CORS, rate limit,
  // unparsable address) leaves us in the original ungeocoded state.
  if ((subject.latitude == null || subject.longitude == null) && subject.address) {
    if (btn) btn.textContent = '🌍 Geocoding...';
    const geo = await _udGeocodeSubject(db, subject, propertyId);
    if (geo) {
      subject.latitude = geo.lat;
      subject.longitude = geo.lng;
      showToast('Geocoded subject from address — coords saved to property record', 'success');
    }
  }
  if (subject.latitude == null || subject.longitude == null) {
    showToast(
      'Subject property has no coordinates on file and could not be geocoded from the address — set lat/lng manually before exporting',
      'error'
    );
    return;
  }

  // Inline button feedback so the user knows the click registered. Cold path:
  // first click downloads ExcelJS (~900KB) + fetches the template; subsequent
  // clicks are instant once both are cached.
  const origText = btn ? btn.textContent : null;
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Building...'; }

  try {
    // C2 (2026-06-06): fetch comps FIRST so a CDN/ExcelJS failure can still
    // deliver the data as CSV instead of a dead "try again". ExcelJS gives
    // template/style fidelity (Briggs branding); CSV is the honest fallback
    // when the CDN is blocked/offline.
    const comps = await _udFetchLeaseCompCandidates(db, subject, count);
    if (!comps.length) {
      const universe = Number(window._udLastGeocodeUniverseSize || 0);
      const radius = Number(window._udLastGeocodeRadiusMi || 0);
      const msg = universe === 0
        ? `No geocoded properties found within ${radius} mi of the subject — coverage may be too sparse in this area for distance-ranked comps.`
        : 'No comparable properties with coordinates found nearby';
      showToast(msg, 'error');
      return;
    }

    let ExcelJS = null;
    try {
      ExcelJS = await _udLoadExcelJs();
    } catch (libErr) {
      console.warn('[lease-comps] ExcelJS unavailable — falling back to CSV:', libErr?.message || libErr);
      _udExportLeaseCompsCsv(db, subject, comps);
      showToast(`ExcelJS/CDN unavailable — exported ${comps.length} comp${comps.length === 1 ? '' : 's'} as CSV instead.`, 'warn');
      return;
    }
    await _udBuildLeaseCompsWorkbook(ExcelJS, db, subject, comps);
    showToast(`Exported ${comps.length} lease comp${comps.length === 1 ? '' : 's'} to Excel`, 'success');
  } catch (err) {
    console.error('Lease comps export error:', err);
    showToast('Lease comps export failed: ' + (err?.message || 'unknown error'), 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = origText; }
  }
}

// C2 (2026-06-06): CSV fallback when ExcelJS can't load (CDN blocked/offline).
// Style fidelity is lost, but the data ships. Generic: emits a curated set of
// useful columns first, then any remaining scalar fields, so the export is
// never empty regardless of the enriched comp shape.
function _udCsvCell(v) {
  if (v == null) return '';
  let s = String(v);
  if (/[",\n\r]/.test(s)) s = '"' + s.replace(/"/g, '""') + '"';
  return s;
}
function _udExportLeaseCompsCsv(db, subject, comps) {
  if (!Array.isArray(comps) || !comps.length) { showToast('No comps to export.', 'error'); return; }
  // Prefer a human-meaningful column order; append any other scalar keys after.
  const preferred = ['property_id', 'distance_miles', 'address', 'city', 'state', 'tenant',
    'agency', 'sf_leased', 'rba', 'year_built', 'lease_commencement', 'lease_expiration',
    'annual_rent', 'rent', 'base_rent', 'rent_per_sf', 'cap_rate', 'true_owner_name',
    'recorded_owner_name'];
  const seen = new Set();
  const cols = [];
  preferred.forEach(k => { if (comps.some(c => c && c[k] != null)) { cols.push(k); seen.add(k); } });
  comps.forEach(c => {
    if (!c) return;
    Object.keys(c).forEach(k => {
      if (seen.has(k)) return;
      const v = c[k];
      if (v == null || typeof v === 'object') return; // scalars only
      cols.push(k); seen.add(k);
    });
  });
  const lines = [cols.join(',')];
  comps.forEach(c => { lines.push(cols.map(k => _udCsvCell(c ? c[k] : '')).join(',')); });
  const csv = lines.join('\r\n');
  try {
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const subjId = (subject && (subject.property_id || subject.address)) || 'subject';
    a.href = url;
    a.download = `lease_comps_${db}_${String(subjId).replace(/[^a-z0-9]+/gi, '_')}.csv`;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
  } catch (e) {
    console.error('[lease-comps] CSV download failed:', e);
    showToast('CSV fallback failed: ' + (e?.message || e), 'error');
  }
}
window._udExportLeaseCompsCsv = _udExportLeaseCompsCsv;

// Lazy-loads the ExcelJS UMD bundle on first export click. Adds the
// stylepreserving Excel writer to window.ExcelJS without bloating the
// initial page payload — most users never click Export Lease Comps so
// the ~900KB cost is deferred until needed.
let _udExcelJsPromise = null;
function _udLoadExcelJs() {
  if (typeof window !== 'undefined' && window.ExcelJS) return Promise.resolve(window.ExcelJS);
  if (_udExcelJsPromise) return _udExcelJsPromise;
  _udExcelJsPromise = new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.4.0/exceljs.min.js';
    s.async = true;
    s.onload = () => {
      if (window.ExcelJS) resolve(window.ExcelJS);
      else reject(new Error('ExcelJS loaded but global is missing'));
    };
    s.onerror = () => {
      _udExcelJsPromise = null; // allow retry on next click
      reject(new Error('Failed to load ExcelJS from CDN'));
    };
    document.head.appendChild(s);
  });
  return _udExcelJsPromise;
}

// Geocode the subject's address via Nominatim (OpenStreetMap). Free, no API
// key, but capped at ~1 req/sec by their usage policy. We only call this on
// explicit user action (Export Lease Comps click), so volume stays well
// inside their limits. On success we patch latitude/longitude back to the
// `properties` row so the next export skips this path.
//
// Returns { lat, lng } on success, null on any failure. The caller decides
// whether to abort or proceed without coords.
async function _udGeocodeSubject(db, subject, propertyId) {
  const parts = [subject.address, subject.city, subject.state, subject.zip].filter(Boolean);
  if (parts.length < 2) return null; // need at least street + city/state to geocode reliably
  const q = parts.join(', ');
  let lat = null, lng = null;
  try {
    const url = 'https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=us&q=' + encodeURIComponent(q);
    // Browser sets Origin and a real User-Agent on our behalf — both satisfy
    // Nominatim's policy for low-volume interactive use.
    const resp = await fetch(url, { headers: { 'Accept': 'application/json' } });
    if (!resp.ok) {
      console.warn('Nominatim geocode HTTP', resp.status);
      return null;
    }
    const data = await resp.json();
    if (!Array.isArray(data) || data.length === 0) return null;
    lat = parseFloat(data[0].lat);
    lng = parseFloat(data[0].lon);
    if (!isFinite(lat) || !isFinite(lng)) return null;
  } catch (e) {
    console.warn('Nominatim geocode failed', e);
    return null;
  }

  // Persist back to properties — best effort. PATCH goes through dia-query
  // proxy directly for dia, and through gov-write for gov. Either failure
  // is non-fatal: we still return the coords so the export proceeds.
  try {
    if (db === 'gov') {
      // Gov writes to properties must go through the gov-write service
      // (see GOV_WRITE_SERVICE_TABLES in api/_shared/allowlist.js).
      await fetch('/api/gov-write', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          endpoint: 'property-update',
          property_id: propertyId,
          patch: { latitude: lat, longitude: lng }
        })
      });
    } else {
      await fetch('/api/dia-query?table=properties&filter=' +
        encodeURIComponent(`property_id=eq.${propertyId}`), {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ latitude: lat, longitude: lng })
      });
    }
  } catch (e) { console.warn('persist geocode failed', e); }

  return { lat, lng };
}

// Path to the committed Briggs lease comps template. Express + Vercel both
// serve assets/** as static files, and we already include this directory in
// vercel.json's includeFiles for the api/capital-markets bundle.
const _UD_LEASE_COMPS_TEMPLATE_URL = '/assets/cm-templates/dialysis-lease-comps-template.xlsx';

// Template constants — sourced from a structural read of the committed
// template. If the template layout changes (banners moved, column added),
// update these and the populate functions below in lockstep.
const _UD_TPL = {
  subjectHeaderRow: 3,    // "TENANT | OPERATOR | ... | BUMPS" header row for SUBJECT
  subjectDataRow: 4,
  compsHeaderRow: 7,      // "TENANT | ... | USER/OWNER | DISTANCE TO SUBJECT"
  compsFirstDataRow: 8,
  compsLastTemplatedRow: 40, // template ships with rows 8..40 pre-styled
  // Canonical 26-column layout (A..Z). LEASE TYPE (S=19), OPTIONS (V=22),
  // NOTES (Z=26) were merged in 2026-06-20, shifting EXPENSES/BUMPS/
  // USER-OWNER/DISTANCE/PATIENTS right. Keep in sync with
  // scripts/build_lease_comps_template.py COLUMNS and _UD_TABLE_COL_MAP in
  // detail-lease-comps-fix.js.
  cols: {
    counter: 1, tenant: 2, operator: 3, address: 4, city: 5, state: 6,
    land: 7, built: 8, renovated: 9, rba: 10, sfLeased: 11, occupancy: 12,
    rentPsf: 13, currentRent: 14, commence: 15, exp: 16, initialTerm: 17,
    termRem: 18, leaseType: 19, expenses: 20, bumps: 21, options: 22,
    userOwner: 23, distance: 24, patientCount: 25, notes: 26
  }
};

// Years between two date-ish values (ISO strings or Date). Returns null
// if either side is missing or unparseable.
function _udYearsBetweenDates(a, b) {
  if (!a || !b) return null;
  const ad = a instanceof Date ? a : new Date(a);
  const bd = b instanceof Date ? b : new Date(b);
  if (isNaN(ad) || isNaN(bd)) return null;
  return Math.round(((bd - ad) / (365.25 * 86400 * 1000)) * 10) / 10;
}

function _udToDateOrNull(v) {
  if (!v) return null;
  if (v instanceof Date) return isNaN(v) ? null : v;
  const d = new Date(v);
  return isNaN(d) ? null : d;
}

// Set a cell value WITHOUT clobbering its style. ExcelJS' `cell.value = X`
// preserves cell.style; we use this when writing into pre-styled template
// cells so the column's formatting (currency, dates, etc.) survives.
function _udSetCell(sheet, row, col, value) {
  const cell = sheet.getRow(row).getCell(col);
  cell.value = (value === undefined || value === '' || value === null) ? null : value;
  return cell;
}

// Populate one data row (subject or comp). The template's number formats
// are already applied to each column at the data-row level, so we just set
// the raw value in the right type and Excel renders it formatted.
function _udPopulateDataRow(sheet, db, rowIdx, rec, opts) {
  const c = _UD_TPL.cols;
  const isSubject = !!opts?.subject;

  _udSetCell(sheet, rowIdx, c.tenant, rec.tenant || '');
  _udSetCell(sheet, rowIdx, c.operator, rec.operator || '');
  _udSetCell(sheet, rowIdx, c.address, rec.address || '');
  _udSetCell(sheet, rowIdx, c.city, rec.city || '');
  _udSetCell(sheet, rowIdx, c.state, rec.state || '');
  _udSetCell(sheet, rowIdx, c.land, rec.land_acres != null ? rec.land_acres : null);
  _udSetCell(sheet, rowIdx, c.built, rec.year_built != null ? rec.year_built : null);
  _udSetCell(sheet, rowIdx, c.renovated, rec.year_renovated != null ? rec.year_renovated : null);
  _udSetCell(sheet, rowIdx, c.rba, rec.building_sf != null ? rec.building_sf : null);
  _udSetCell(sheet, rowIdx, c.sfLeased, rec.leased_area != null ? rec.leased_area : null);
  // Occupancy column is formatted as 0% — write the raw decimal so Excel
  // does the percent rendering itself.
  _udSetCell(sheet, rowIdx, c.occupancy, rec.occupancy != null ? rec.occupancy : null);
  _udSetCell(sheet, rowIdx, c.rentPsf, rec.rent_per_sf != null ? rec.rent_per_sf : null);
  _udSetCell(sheet, rowIdx, c.currentRent, rec.annual_rent != null ? rec.annual_rent : null);

  const startDate = _udToDateOrNull(rec.lease_start);
  const endDate = _udToDateOrNull(rec.lease_expiration);
  _udSetCell(sheet, rowIdx, c.commence, startDate);
  _udSetCell(sheet, rowIdx, c.exp, endDate);
  _udSetCell(sheet, rowIdx, c.initialTerm, _udYearsBetweenDates(startDate, endDate));
  _udSetCell(sheet, rowIdx, c.termRem, _udYearsBetweenDates(new Date(), endDate));
  // LEASE TYPE / EXPENSES / BUMPS / OPTIONS / NOTES — text columns. Render
  // blank when the data layer can't fill them (no fabrication).
  _udSetCell(sheet, rowIdx, c.leaseType, rec.lease_type || '');
  _udSetCell(sheet, rowIdx, c.expenses, rec.expense_structure || '');
  _udSetCell(sheet, rowIdx, c.bumps, _udFmtBumps(rec.lease_bump_pct, rec.lease_bump_interval_mo));
  _udSetCell(sheet, rowIdx, c.options, rec.renewal_options || '');
  _udSetCell(sheet, rowIdx, c.notes, rec.notes || '');
  if (c.patientCount && rec.patient_count != null) {
    _udSetCell(sheet, rowIdx, c.patientCount, rec.patient_count);
  }

  // USER/OWNER + DISTANCE only apply to comparables. The template has no
  // W/X cells in row 4 (subject), so we leave them untouched there.
  if (!isSubject) {
    const userOwnerLabel = rec.owner_occupied
      ? (rec.owner ? `User (${rec.owner})` : 'User')
      : (rec.owner || '');
    _udSetCell(sheet, rowIdx, c.userOwner, userOwnerLabel);
    _udSetCell(sheet, rowIdx, c.distance, rec.distance_miles != null ? rec.distance_miles : null);
  }
}

// Clone every cell-level style attribute from a source row so a newly
// extended row matches the templated rows pixel-for-pixel. ExcelJS doesn't
// inherit cell styles from columns the way native Excel does once the
// workbook has been written, so we have to re-stamp explicitly.
function _udCloneRowStyles(sheet, srcRowIdx, dstRowIdx, colCount) {
  const srcRow = sheet.getRow(srcRowIdx);
  const dstRow = sheet.getRow(dstRowIdx);
  dstRow.height = srcRow.height;
  for (let c = 1; c <= colCount; c++) {
    const srcCell = srcRow.getCell(c);
    const dstCell = dstRow.getCell(c);
    // Deep-copy via JSON to detach references; ExcelJS stores font/fill
    // objects by reference so a shallow copy would keep both rows pointing
    // at the same style, breaking later per-cell tweaks.
    if (srcCell.style) {
      dstCell.style = JSON.parse(JSON.stringify(srcCell.style));
    }
  }
}

async function _udBuildLeaseCompsWorkbook(ExcelJS, db, subject, comps) {
  // Fetch the template binary. Static asset fetch — auth interceptor only
  // touches /api/ paths, so this passes through unmodified.
  const resp = await fetch(_UD_LEASE_COMPS_TEMPLATE_URL);
  if (!resp.ok) throw new Error(`Template fetch failed: HTTP ${resp.status}`);
  const ab = await resp.arrayBuffer();
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(ab);
  const sheet = wb.worksheets[0];
  if (!sheet) throw new Error('Template has no worksheets');

  // ── Subject row (single row at template position 4) ──────────────────
  _udPopulateDataRow(sheet, db, _UD_TPL.subjectDataRow, subject, { subject: true });

  // ── Comp rows ────────────────────────────────────────────────────────
  // Template ships with 33 pre-styled rows (8..40). For counts >33 we
  // clone row 8's per-cell styles into rows 41..(8+count-1) so they
  // render with identical formats/heights/alignment.
  const lastDataRow = _UD_TPL.compsFirstDataRow + comps.length - 1;
  const lastTpl = _UD_TPL.compsLastTemplatedRow;
  if (lastDataRow > lastTpl) {
    for (let r = lastTpl + 1; r <= lastDataRow; r++) {
      _udCloneRowStyles(sheet, _UD_TPL.compsFirstDataRow, r, _UD_TPL.cols.notes);
      // Stamp the running counter formula so column A keeps incrementing.
      sheet.getRow(r).getCell(_UD_TPL.cols.counter).value = { formula: `A${r - 1}+1` };
    }
  }

  comps.forEach((c, i) => {
    const rowIdx = _UD_TPL.compsFirstDataRow + i;
    _udPopulateDataRow(sheet, db, rowIdx, c, { subject: false });
  });

  // Clear any unused pre-styled comp rows so a count of 10 doesn't ship
  // with 23 blank-but-counted rows trailing it. We blank the data cells
  // (B..Z) but keep column A's counter formula AND the row formatting,
  // which lets the user paste additional comps later if they want.
  if (comps.length < (lastTpl - _UD_TPL.compsFirstDataRow + 1)) {
    for (let r = _UD_TPL.compsFirstDataRow + comps.length; r <= lastTpl; r++) {
      const row = sheet.getRow(r);
      for (let c = _UD_TPL.cols.tenant; c <= _UD_TPL.cols.notes; c++) {
        row.getCell(c).value = null;
      }
    }
  }

  // Generate workbook and trigger browser download.
  const buf = await wb.xlsx.writeBuffer();
  const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const today = new Date().toISOString().slice(0, 10);
  const slug = String(subject.address || subject.property_id || 'subject')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40) || 'subject';
  const fname = `LCC_LeaseComps_${db === 'gov' ? 'GOV' : 'DIA'}_${slug}_${today}.xlsx`;
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fname;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  // Free the object URL after the click handler had a chance to read it.
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

window._udExportLeaseComps = _udExportLeaseComps;