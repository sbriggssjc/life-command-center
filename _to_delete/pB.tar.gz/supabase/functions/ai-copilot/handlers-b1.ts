import { getDialysisClient, getGovClient, jsonResponse, normalizeSFArray, ANTHROPIC_API_KEY, PA_LOG_ACTIVITY_URL, VALID_ACTIVITY_TYPES, constructSFTaskLink, categorizeTask, categorizeActivity } from "./utils.ts";
import type { SFTask } from "./utils.ts";

export async function handleLogToSF(body: { sf_contact_id?: string; sf_company_id?: string; activity_type: string; activity_date?: string; force?: boolean; }) {
  const { sf_contact_id, sf_company_id, activity_type, activity_date, force } = body;
  if (!activity_type || !VALID_ACTIVITY_TYPES.includes(activity_type)) return jsonResponse({ error: "Invalid activity_type", valid_types: VALID_ACTIVITY_TYPES }, 400);
  if (!sf_contact_id && !sf_company_id) return jsonResponse({ error: "sf_contact_id or sf_company_id is required" }, 400);
  if (!PA_LOG_ACTIVITY_URL) return jsonResponse({ error: "PA_LOG_ACTIVITY_URL not configured" }, 500);
  const d = getDialysisClient();
  const dateStr = activity_date || new Date().toISOString().split('T')[0];
  if (!force) { try { const conditions: string[] = []; if (sf_contact_id) conditions.push(`sa.sf_contact_id = '${sf_contact_id}'`); if (sf_company_id) conditions.push(`sa.sf_company_id = '${sf_company_id}'`); const whereClause = conditions.join(' OR '); const { data } = await d.rpc("exec_sql", { query: `SELECT json_agg(sub) FROM (SELECT sa.assigned_to, sa.activity_date, sa.subject, sa.nm_type, sa.company_name, sa.first_name, sa.last_name, (CURRENT_DATE - sa.activity_date::date) as days_ago FROM salesforce_activities sa WHERE (${whereClause}) AND sa.assigned_to IS NOT NULL AND lower(sa.assigned_to) != 'scott briggs' AND (sa.activity_date::date >= (CURRENT_DATE - INTERVAL '75 days') OR sa.nm_type = 'Opportunity') ORDER BY sa.activity_date DESC LIMIT 5) sub` }).single(); const rows = Array.isArray(data) ? data : []; if (rows.length > 0) { return jsonResponse({ warning: "Recent activity by another team member detected", conflicts: rows.map((r: Record<string, unknown>) => ({ assigned_to: r.assigned_to, activity_date: r.activity_date, subject: r.subject, nm_type: r.nm_type, company_name: r.company_name, contact_name: [r.first_name, r.last_name].filter(Boolean).join(' '), days_ago: r.days_ago })), message: "Set force=true to override this warning" }, 409); } } catch (e) { console.warn("75-day check error:", (e as Error).message); } }
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'; let refSuffix = ''; for (let i = 0; i < 8; i++) refSuffix += chars.charAt(Math.floor(Math.random() * chars.length)); const ref_id = `LCC-${refSuffix}`;
  const { error: insertError } = await d.from("outbound_activities").insert({ sf_contact_id: sf_contact_id || null, sf_company_id: sf_company_id || null, activity_type, activity_date: dateStr, ref_id, user_name: 'Scott Briggs', status: 'sent' });
  if (insertError) return jsonResponse({ error: "Failed to create audit record", details: insertError.message }, 500);
  try { const paPayload = { ref_id, sf_contact_id: sf_contact_id || '', sf_company_id: sf_company_id || '', activity_type, activity_date: dateStr, user_name: 'Scott Briggs' }; const paResp = await fetch(PA_LOG_ACTIVITY_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(paPayload) }); const paBody = await paResp.text(); let paJson: Record<string, unknown> = {}; try { paJson = JSON.parse(paBody); } catch (_) { paJson = { raw: paBody }; } if (paResp.ok) { await d.from("outbound_activities").update({ pa_response: paJson, status: 'completed' }).eq("ref_id", ref_id); return jsonResponse({ success: true, ref_id, sf_task_id: paJson.taskId || null, message: `Activity logged to Salesforce (${ref_id})` }); } else { await d.from("outbound_activities").update({ pa_response: paJson, status: 'failed' }).eq("ref_id", ref_id); return jsonResponse({ error: "Power Automate call failed", ref_id, pa_status: paResp.status, details: paJson }, 502); } } catch (e) { await d.from("outbound_activities").update({ status: 'failed', pa_response: { error: (e as Error).message } }).eq("ref_id", ref_id); return jsonResponse({ error: "Failed to call Power Automate", ref_id, details: (e as Error).message }, 500); }
}

export async function handleContactLookup(body: { query: string; limit?: number }) {
  const { query, limit = 10 } = body;
  if (!query) return jsonResponse({ error: "query is required" }, 400);
  const d = getDialysisClient(); const searchTerm = `%${query}%`;
  const results: { contacts: unknown[]; accounts: unknown[] } = { contacts: [], accounts: [] };
  try { const { data, error } = await d.from("salesforce_contacts").select("sf_contact_id, first_name, last_name, email, phone, sf_account_id").or(`first_name.ilike.${searchTerm},last_name.ilike.${searchTerm},email.ilike.${searchTerm}`).limit(limit); if (!error && data) results.contacts = data; } catch (_) {}
  try { const { data, error } = await d.from("salesforce_accounts").select("sf_account_id, name, billing_city, billing_state").or(`name.ilike.${searchTerm},billing_city.ilike.${searchTerm}`).limit(limit); if (!error && data) results.accounts = data.map((a: Record<string, unknown>) => ({ sf_account_id: a.sf_account_id, name: a.name, city_state: [a.billing_city, a.billing_state].filter(Boolean).join(', ') })); } catch (_) {}
  return jsonResponse(results);
}

export async function handleSyncSFTasks(body: { tasks?: SFTask[] | { value?: SFTask[] }; task?: SFTask; }) {
  const tasksList = body.task ? [body.task] : normalizeSFArray<SFTask>(body.tasks as SFTask[] | { value?: SFTask[] });
  if (tasksList.length === 0) return jsonResponse({ error: "No tasks provided" }, 400);
  const d = getDialysisClient(); const results = { upserted: 0, errors: [] as string[], total_received: tasksList.length }; const batchSize = 100;
  for (let i = 0; i < tasksList.length; i += batchSize) { const batch = tasksList.slice(i, i + batchSize).map(t => { const sfId = (t.Id || t.id || '') as string; if (!sfId) return null; const whoObj = (t as any).Who || {}; const whatObj = (t as any).What || {}; return { id: sfId, subject: (t.Subject || t.subject || null) as string | null, description: (t.Description || t.description || null) as string | null, status: (t.Status || t.status || null) as string | null, priority: (t.Priority || t.priority || null) as string | null, activity_date: (t.ActivityDate || t.activity_date || null) as string | null, owner_id: (t.OwnerId || t.owner_id || null) as string | null, who_id: (t.WhoId || t.who_id || null) as string | null, who_name: (whoObj.Name || t.WhoName || t.who_name || null) as string | null, what_id: (t.WhatId || t.what_id || null) as string | null, what_name: (whatObj.Name || t.WhatName || t.what_name || null) as string | null, what_type: (whatObj.Type || t.WhatType || t.what_type || null) as string | null, task_type: ((t as any).Type || t.TaskType || t.task_type || null) as string | null, created_date: (t.CreatedDate || t.created_date || null) as string | null, last_modified_date: (t.LastModifiedDate || t.last_modified_date || null) as string | null, synced_at: new Date().toISOString(), raw_data: t }; }).filter(Boolean); if (batch.length === 0) continue; const { data, error } = await d.from("salesforce_tasks").upsert(batch, { onConflict: "id", ignoreDuplicates: false }).select("id"); if (error) results.errors.push(`Batch ${i}: ${error.message}`); else results.upserted += data?.length || batch.length; }
  let namesResolved = 0;
  try { await d.rpc("exec_sql", { query: `UPDATE salesforce_tasks t SET who_name = TRIM(CONCAT(COALESCE(c.first_name, ''), ' ', COALESCE(c.last_name, ''))) FROM salesforce_contacts c WHERE t.who_id = c.sf_contact_id AND t.who_id IS NOT NULL AND t.who_name IS NULL` }); await d.rpc("exec_sql", { query: `UPDATE salesforce_tasks SET what_type = CASE WHEN what_id LIKE '006%' THEN 'Opportunity' WHEN what_id LIKE '001%' THEN 'Account' WHEN what_id LIKE 'a0%' THEN 'CustomObject' ELSE 'Unknown' END WHERE what_id IS NOT NULL AND what_type IS NULL` }); await d.rpc("exec_sql", { query: `UPDATE salesforce_tasks t SET what_name = a.name FROM salesforce_accounts a WHERE t.what_id = a.sf_account_id AND t.what_id IS NOT NULL AND t.what_name IS NULL AND t.what_type = 'Account'` }); await d.rpc("exec_sql", { query: `UPDATE salesforce_tasks t SET what_id = c.sf_account_id, what_name = a.name, what_type = 'Account' FROM salesforce_contacts c JOIN salesforce_accounts a ON c.sf_account_id = a.sf_account_id WHERE t.who_id = c.sf_contact_id AND c.sf_account_id IS NOT NULL AND t.what_id IS NULL` }); namesResolved = 1; } catch (e) { results.errors.push(`Name resolution: ${(e as Error).message}`); }
  return jsonResponse({ success: results.errors.length === 0, tasks_upserted: results.upserted, total_received: results.total_received, names_resolved: namesResolved, errors: results.errors, version: 52 });
}

export async function handleGetSFTasks(url: URL) {
  const d = getDialysisClient();
  // Per-user reads (Phase 3): resolve an additive `user_email` param -> lcc_users.salesforce_owner_id.
  // Keep Scott's default ONLY when no identity param (owner_id / user_email) is passed. If user_email is
  // passed but not found, filter to a non-matching value so we NEVER fall back to Scott's data.
  let ownerId = url.searchParams.get('owner_id');
  if (!ownerId) {
    const userEmail = url.searchParams.get('user_email');
    if (userEmail) {
      let resolvedOwnerId: string | null = null;
      try { const { data } = await d.from("lcc_users").select("email, salesforce_owner_id").ilike("email", userEmail).limit(5); const match = (data || []).find((u: Record<string, unknown>) => String(u.email || '').toLowerCase() === userEmail.toLowerCase()); resolvedOwnerId = (match?.salesforce_owner_id as string) || null; } catch (_) {}
      ownerId = resolvedOwnerId || '__no_matching_user__';
    } else {
      ownerId = '0051I000001vHJbQAM';
    }
  }
  const statusFilter = url.searchParams.get('status'); const mode = url.searchParams.get('mode') || 'display'; const clientLimit = parseInt(url.searchParams.get('limit') || '0'); const requestedLimit = mode === 'display' ? Math.max(clientLimit || 5000, 5000) : (clientLimit || 5000); const afterDate = url.searchParams.get('after') || (mode === 'display' ? new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] : null); const whoId = url.searchParams.get('who_id'); const whatId = url.searchParams.get('what_id');
  const PAGE_SIZE = 1000; const allTasks: unknown[] = []; let currentOffset = 0;
  while (allTasks.length < requestedLimit) { const batchSize = Math.min(PAGE_SIZE, requestedLimit - allTasks.length); let query = d.from("salesforce_tasks").select("id, subject, description, status, priority, activity_date, owner_id, who_id, who_name, what_id, what_name, what_type, task_type, created_date, last_modified_date").eq("owner_id", ownerId).order("activity_date", { ascending: false }).range(currentOffset, currentOffset + batchSize - 1); if (statusFilter) { const statuses = statusFilter.split(',').map(s => s.trim()); if (statuses.length === 1) { query = query.eq("status", statuses[0]); } else { query = query.in("status", statuses); } } if (afterDate) { query = query.gte("activity_date", afterDate); } if (whoId) query = query.eq("who_id", whoId); if (whatId) query = query.eq("what_id", whatId); const { data, error } = await query; if (error) return jsonResponse({ error: "Failed to fetch SF tasks", details: error.message }, 500); if (!data || data.length === 0) break; allTasks.push(...data); currentOffset += data.length; if (data.length < batchSize) break; }
  const { count: totalCount } = await d.from("salesforce_tasks").select("id", { count: "planned", head: true }).eq("owner_id", ownerId);
  const enrichedTasks = (allTasks as Record<string, unknown>[]).map(t => ({ ...t, sf_link: constructSFTaskLink((t.id || '') as string), computed_category: categorizeTask((t.subject || null) as string | null, (t.what_type || null) as string | null) }));
  return jsonResponse({ tasks: enrichedTasks, count: enrichedTasks.length, total_for_owner: totalCount || 0, mode });
}

export async function handleGetSFActivities(url: URL) {
  const d = getDialysisClient();
  // Per-user reads (Phase 3): resolve an additive `user_email` param -> lcc_users.display_name.
  // Keep Scott's default ONLY when no identity param (assigned_to / user_email) is passed. If user_email is
  // passed but not found, filter to a non-matching value so we NEVER fall back to Scott's data.
  let assignedTo = url.searchParams.get('assigned_to');
  if (!assignedTo) {
    const userEmail = url.searchParams.get('user_email');
    if (userEmail) {
      let resolvedName: string | null = null;
      try { const { data } = await d.from("lcc_users").select("email, display_name").ilike("email", userEmail).limit(5); const match = (data || []).find((u: Record<string, unknown>) => String(u.email || '').toLowerCase() === userEmail.toLowerCase()); resolvedName = (match?.display_name as string) || null; } catch (_) {}
      assignedTo = resolvedName || '__no_matching_user__';
    } else {
      assignedTo = 'Scott Briggs';
    }
  }
  const statusFilter = url.searchParams.get('status') || 'Open'; const category = url.searchParams.get('category'); const search = url.searchParams.get('search'); const clientLimit = parseInt(url.searchParams.get('limit') || '2000'); const requestedLimit = Math.min(clientLimit, 2000); const offset = parseInt(url.searchParams.get('offset') || '0'); const afterDate = url.searchParams.get('after') || new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]; const sortBy = url.searchParams.get('sort') || 'activity_date'; const sortDir = url.searchParams.get('sort_dir') === 'asc' ? true : false;
  const PAGE_SIZE = 1000; const allActivities: unknown[] = []; let currentOffset = offset;
  while (allActivities.length < requestedLimit) { const batchSize = Math.min(PAGE_SIZE, requestedLimit - allActivities.length); let query = d.from("salesforce_activities").select("sf_task_id, subject, first_name, last_name, sf_contact_id, company_name, sf_company_id, company_address, company_city_state, assigned_to, nm_type, activity_date, nm_notes, task_subtype, email, phone, status").order(sortBy === 'company_name' ? 'company_name' : sortBy === 'subject' ? 'subject' : 'activity_date', { ascending: sortDir }).range(currentOffset, currentOffset + batchSize - 1); if (assignedTo && assignedTo !== 'all') { query = query.eq("assigned_to", assignedTo); } if (statusFilter && statusFilter !== 'all') { const statuses = statusFilter.split(',').map(s => s.trim()); if (statuses.length === 1) { query = query.eq("status", statuses[0]); } else { query = query.in("status", statuses); } } if (afterDate) { query = query.gte("activity_date", afterDate); } if (search) { query = query.or(`subject.ilike.%${search}%,company_name.ilike.%${search}%,first_name.ilike.%${search}%,last_name.ilike.%${search}%`); } const { data, error } = await query; if (error) return jsonResponse({ error: "Failed to fetch SF activities", details: error.message }, 500); if (!data || data.length === 0) break; allActivities.push(...data); currentOffset += data.length; if (data.length < batchSize) break; }
  // Deduplicate activities by composite key (subject + contact + company + date)
  const seen = new Set<string>(); const dedupedActivities: unknown[] = []; for (const a of allActivities) { const rec = a as Record<string, unknown>; const key = `${rec.subject}|${rec.first_name}|${rec.last_name}|${rec.company_name}|${rec.activity_date}`; if (!seen.has(key)) { seen.add(key); dedupedActivities.push(a); } }
  const enrichedActivities = (dedupedActivities as Record<string, unknown>[]).map(a => { const computedCat = categorizeActivity((a.subject || null) as string | null); return { ...a, sf_link: constructSFTaskLink((a.sf_task_id || '') as string), computed_category: computedCat, contact_name: [a.first_name, a.last_name].filter(Boolean).join(' ') || null }; });
  let filteredActivities = enrichedActivities; if (category) { const cats = category.split(',').map(c => c.trim().toLowerCase()); filteredActivities = enrichedActivities.filter(a => { const ac = ((a.computed_category || '') as string).toLowerCase(); return cats.some(c => ac.includes(c)); }); }
  const categorySummary: Record<string, number> = {}; for (const a of enrichedActivities) { const cat = (a.computed_category || 'Uncategorized') as string; categorySummary[cat] = (categorySummary[cat] || 0) + 1; }
  let totalCount = 0; try { const countQuery = d.from("salesforce_activities").select("sf_task_id", { count: "planned", head: true }); if (assignedTo && assignedTo !== 'all') { const { count } = await countQuery.eq("assigned_to", assignedTo).eq("status", statusFilter || 'Open'); totalCount = count || 0; } else { const { count } = await countQuery.eq("status", statusFilter || 'Open'); totalCount = count || 0; } } catch (_) {}
  return jsonResponse({ activities: filteredActivities, count: filteredActivities.length, total_fetched: enrichedActivities.length, total_raw: allActivities.length, total_for_owner: totalCount, category_summary: categorySummary, filters: { assigned_to: assignedTo, status: statusFilter, category: category || 'all', search: search || null }, offset, version: 54 });
}