// ============================================================================
// Entities API — Canonical business entities (person, org, asset)
// Life Command Center — Phase 2
//
// GET    /api/entities                        — list/search entities
// GET    /api/entities?id=<uuid>              — get entity with external identities
// POST   /api/entities                        — create entity
// PATCH  /api/entities?id=<uuid>              — update entity
// POST   /api/entities?action=link            — link external identity to entity
// GET    /api/entities?action=search&q=       — search by name across types
// GET    /api/entities?action=lookup_asset&address=&city=&state= — find asset entity by address
// GET    /api/entities?action=duplicates      — find duplicate candidates
// POST   /api/entities?action=merge           — merge two entities (manager+)
// POST   /api/entities?action=add_alias       — add alias for entity
// GET    /api/entities?action=quality         — data quality dashboard
// POST   /api/entities?action=process_sidebar_extraction — unpack CRE sidebar metadata
// ============================================================================

import { authenticate, requireRole, handleCors } from '../_shared/auth.js';
import { opsQuery, paginationParams, requireOps, withErrorHandler } from '../_shared/ops-db.js';
import { ENTITY_TYPES, DOMAINS, isValidEnum } from '../_shared/lifecycle.js';
import { normalizeAddress, stripListingStatusPrefix, canonicalIdentitySystem, CANONICAL_DOMAIN_SYSTEMS, canonicalDomainSourceType, canonicalEntityDomain } from '../_shared/entity-link.js';
import { writeListingCreatedSignal } from '../_shared/signals.js';
import { processSidebarExtraction, hasSidebarData } from './sidebar-pipeline.js';
import { domainQuery } from '../_shared/domain-db.js';
import { sanitizeListingUrl } from '../_shared/listing-url-filter.js';
import { enrichReviewQueueContext } from '../_shared/provenance-row-context.js';
import { computeRoe, mergeTimeline } from '../_shared/roe.js';
import { sf15, toSf18 } from '../_shared/sf-id.js';

function pageMeta(page, perPage, totalCount) {
  const totalPages = Math.ceil((totalCount || 0) / perPage);
  return {
    page,
    per_page: perPage,
    total: totalCount || 0,
    total_pages: totalPages,
    has_next: page < totalPages,
    has_prev: page > 1
  };
}

export const entitiesHandler = withErrorHandler(async function handler(req, res) {
  if (handleCors(req, res)) return;
  if (requireOps(res)) return;

  const user = await authenticate(req, res);
  if (!user) return;

  const workspaceId = req.headers['x-lcc-workspace'] || user.memberships[0]?.workspace_id;
  if (!workspaceId) return res.status(400).json({ error: 'No workspace context' });

  const membership = user.memberships.find(m => m.workspace_id === workspaceId);
  if (!membership) return res.status(403).json({ error: 'Not a member of this workspace' });

  // GET
  if (req.method === 'GET') {
    const { id, action, q, entity_type, domain } = req.query;

    // UI Phase 4B — authoritative per-entity portfolio from the BD spine.
    // GET /api/entities?action=portfolio&id=<uuid>
    //   rollup  ← v_entity_portfolio_all (one row; count / Σ rent / domains)
    //   props   ← lcc_entity_portfolio_facts ⋈ lcc_property_attributes
    // Replaces the old fuzzy v_ownership_current true_owner=ilike name-match in
    // openEntityDetail (SPEs / renamed owners mismatched). Each property row is a
    // 4A zoom target (clicking opens openUnifiedDetail). MUST run before the
    // `if (id)` single-entity early-return below.
    if (action === 'portfolio' && id) {
      // Confirm the entity belongs to this workspace before exposing its portfolio.
      const entRes = await opsQuery('GET',
        `entities?id=eq.${id}&workspace_id=eq.${workspaceId}&select=id,name`);
      if (!entRes.ok || !entRes.data?.length) {
        return res.status(404).json({ error: 'Entity not found' });
      }

      const { rollup, properties } = await fetchEntityPortfolio(id, workspaceId);
      return res.status(200).json({ rollup, properties });
    }

    // Contact 360 — the single aggregating read behind the reusable contact
    // side-panel (openEntityDetail / openContact360). Composes, in ONE call,
    // everything the panel needs: the entity (+ external identities / relationships),
    // the authoritative BD portfolio (owns/former), the developed edges, the
    // UNIFIED activity timeline (LCC activity_events + dia salesforce_activities,
    // each broker-labeled), the Outlook email relationship, engagement
    // (unified_contacts), marketing_leads signals, the SF-account owner, and the
    // Rules-of-Engagement verdict. Entity-keyed — a plain contact resolves to its
    // person entity client-side (openContact360) before calling this.
    // MUST run before the `if (id)` single-entity early-return below.
    if (action === 'contact360' && id) {
      const c360 = await buildContact360(id, workspaceId);
      if (!c360) return res.status(404).json({ error: 'Entity not found' });
      return res.status(200).json(c360);
    }

    // UI Phase 5 — "Owners Missing a Contact" value-ranked BD worklist.
    // GET /api/entities?action=owner_worklist[&min_value=&limit=&offset=]
    //   rows ← v_owner_contact_worklist (contactless valued owners, value-ranked).
    // Defaults to the workable high-value set (min_value); returns the actionable
    // count (matching the filter) AND the full clean universe so the surface can
    // show an honest "X of N" (Consumption-Layer doctrine). The row action runs
    // the EXISTING CONTACT-SELECTION picker via the 4B owner detail Contacts tab.
    if (action === 'owner_worklist') {
      const minValue = Math.max(0, Number(req.query.min_value) || 0);
      const limit = Math.min(Math.max(1, Number(req.query.limit) || 50), 200);
      const offset = Math.max(0, Number(req.query.offset) || 0);
      const base = `v_owner_contact_worklist?workspace_id=eq.${workspaceId}`;
      const filt = minValue > 0 ? `&rank_value=gte.${minValue}` : '';
      const rowPath = base +
        `&select=entity_id,owner_name,rank_value,property_count,primary_domain,is_cross_vertical,enrichment_action,bench_size` +
        filt + `&order=rank_value.desc.nullslast&limit=${limit}&offset=${offset}`;
      const [rowsRes, universeRes] = await Promise.all([
        opsQuery('GET', rowPath, undefined, { countMode: 'exact' }),
        opsQuery('GET', base + '&select=entity_id', undefined, { countMode: 'exact' }),
      ]);
      return res.status(200).json({
        rows: (rowsRes.ok && Array.isArray(rowsRes.data)) ? rowsRes.data : [],
        actionable_count: rowsRes.count ?? (rowsRes.data?.length || 0),
        universe_count: universeRes.count ?? null,
        min_value: minValue,
        limit,
        offset,
      });
    }

    // Single entity with related data
    if (id) {
      const result = await opsQuery('GET',
        `entities?id=eq.${id}&workspace_id=eq.${workspaceId}&select=*,external_identities(*),entity_aliases(*),entity_relationships!entity_relationships_from_entity_id_fkey(*)`
      );
      if (!result.ok || !result.data?.length) {
        return res.status(404).json({ error: 'Entity not found' });
      }
      return res.status(200).json({ entity: result.data[0] });
    }

    // Duplicate candidates — entities with matching canonical names or similar names
    if (action === 'duplicates') {
      const result = await opsQuery('GET',
        `entities?workspace_id=eq.${workspaceId}&select=id,entity_type,name,canonical_name,domain,city,state&order=canonical_name,name`
      );
      const entities = result.data || [];

      // Group by canonical_name to find exact duplicates
      const byCanonical = {};
      for (const e of entities) {
        const key = e.canonical_name || e.name.toLowerCase();
        if (!byCanonical[key]) byCanonical[key] = [];
        byCanonical[key].push(e);
      }

      const duplicates = [];
      for (const [canonical, group] of Object.entries(byCanonical)) {
        if (group.length > 1) {
          duplicates.push({
            canonical_name: canonical,
            match_type: 'exact_canonical',
            count: group.length,
            entities: group
          });
        }
      }

      // Also find near-matches using prefix similarity (first 10 chars)
      const prefixGroups = {};
      for (const e of entities) {
        const prefix = (e.canonical_name || '').substring(0, 10);
        if (prefix.length >= 5) {
          if (!prefixGroups[prefix]) prefixGroups[prefix] = [];
          prefixGroups[prefix].push(e);
        }
      }
      const nearMatches = [];
      for (const [prefix, group] of Object.entries(prefixGroups)) {
        if (group.length > 1) {
          // Only include if not already caught by exact match
          const canonicals = new Set(group.map(e => e.canonical_name));
          if (canonicals.size > 1) {
            nearMatches.push({
              prefix,
              match_type: 'prefix_similarity',
              count: group.length,
              entities: group
            });
          }
        }
      }

      return res.status(200).json({
        exact_duplicates: duplicates,
        near_matches: nearMatches,
        total_entities: entities.length,
        duplicate_groups: duplicates.length,
        near_match_groups: nearMatches.length
      });
    }

    // Data quality dashboard
    if (action === 'quality') {
      const [entities, identities, aliases, orphanedActions, orphanedInbox] = await Promise.all([
        opsQuery('GET', `entities?workspace_id=eq.${workspaceId}&select=id,entity_type,name,domain,email,phone,address,city,state`),
        opsQuery('GET', `external_identities?workspace_id=eq.${workspaceId}&select=id,entity_id,source_system,last_synced_at`),
        opsQuery('GET', `entity_aliases?workspace_id=eq.${workspaceId}&select=id,entity_id`),
        opsQuery('GET', `action_items?workspace_id=eq.${workspaceId}&entity_id=is.null&status=neq.cancelled&select=id&limit=100`),
        opsQuery('GET', `inbox_items?workspace_id=eq.${workspaceId}&status=in.(new,triaged)&select=id&limit=100`)
      ]);

      const entityList = entities.data || [];
      const identityList = identities.data || [];
      const linkedEntityIds = new Set(identityList.map(i => i.entity_id));
      const staleThreshold = new Date(Date.now() - 7 * 86400000).toISOString();
      const staleIdentities = identityList.filter(i => i.last_synced_at && i.last_synced_at < staleThreshold);

      // Entities missing key fields by type
      const missingFields = {
        persons_without_email: entityList.filter(e => e.entity_type === 'person' && !e.email).length,
        persons_without_phone: entityList.filter(e => e.entity_type === 'person' && !e.phone).length,
        assets_without_address: entityList.filter(e => e.entity_type === 'asset' && !e.address).length,
        assets_without_state: entityList.filter(e => e.entity_type === 'asset' && !e.state).length,
        entities_without_domain: entityList.filter(e => !e.domain).length
      };

      return res.status(200).json({
        total_entities: entityList.length,
        by_type: {
          person: entityList.filter(e => e.entity_type === 'person').length,
          organization: entityList.filter(e => e.entity_type === 'organization').length,
          asset: entityList.filter(e => e.entity_type === 'asset').length
        },
        linked_to_external: linkedEntityIds.size,
        unlinked: entityList.length - linkedEntityIds.size,
        total_identities: identityList.length,
        stale_identities: staleIdentities.length,
        total_aliases: (aliases.data || []).length,
        missing_fields: missingFields,
        orphaned_actions: (orphanedActions.data || []).length,
        orphaned_inbox: (orphanedInbox.data || []).length,
        checked_at: new Date().toISOString()
      });
    }

    if (action === 'quality_details') {
      const [duplicates, unlinked, stale, completeness, orphaned, precedence] = await Promise.all([
        opsQuery('GET', `v_duplicate_candidates?workspace_id=eq.${workspaceId}&limit=25`),
        opsQuery('GET', `v_unlinked_entities?workspace_id=eq.${workspaceId}&limit=25`),
        opsQuery('GET', `v_stale_identities?workspace_id=eq.${workspaceId}&limit=25`),
        opsQuery('GET', `v_entity_completeness?workspace_id=eq.${workspaceId}&order=completeness_score.asc&limit=25`),
        opsQuery('GET', `v_orphaned_actions?workspace_id=eq.${workspaceId}&limit=25`),
        opsQuery('GET', `source_precedence?workspace_id=eq.${workspaceId}&order=precedence.desc&limit=25`)
      ]);

      return res.status(200).json({
        duplicate_candidates: duplicates.data || [],
        unlinked_entities: unlinked.data || [],
        stale_identities: stale.data || [],
        low_completeness: (completeness.data || []).filter(row => (row.completeness_score || 0) < 60),
        orphaned_actions: orphaned.data || [],
        source_precedence: precedence.data || []
      });
    }

    // Phase 3 + 4 — surface field_provenance skips/conflicts where the rule
    // is in warn/strict mode AND any (target_table,field_name,source) triple
    // that's been writing to field_provenance but isn't in
    // field_source_priority (schema drift). Drives the LCC Data Quality
    // UI's "Provenance conflicts" + "Unranked fields" panels.
    if (action === 'quality_provenance') {
      const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 100, 1), 500);
      const [actionable, summary, unranked] = await Promise.all([
        // TIER 1 Unit 2: exclude decision='skip' telemetry from the rendered
        // "Provenance conflicts" list — a skip is the registry correctly choosing
        // a higher-priority source, not a human decision. (The summary_7d
        // aggregate below still buckets skip vs conflict as drift telemetry.)
        opsQuery('GET',
          `v_field_provenance_actionable?` +
          `select=provenance_id,recorded_at,target_database,target_table,record_pk_value,` +
          `field_name,attempted_value,attempted_source,attempted_priority,enforce_mode,` +
          `decision,decision_reason,current_source,current_value` +
          `&decision=eq.conflict&order=recorded_at.desc&limit=${limit}`
        ),
        // Summary: by target_table+field, how many would-have-blocked rows
        // in the last 7 days. We can't GROUP BY in PostgREST — fold in JS
        // after fetching the raw set with a higher cap (cheap, < 5k rows
        // expected even at peak).
        opsQuery('GET',
          `v_field_provenance_actionable?` +
          `select=target_table,field_name,enforce_mode,decision` +
          `&recorded_at=gte.${encodeURIComponent(new Date(Date.now() - 7 * 86400000).toISOString())}` +
          `&limit=5000`
        ),
        // Phase 4 — schema-drift detector. Unranked field writes from the
        // last 30 days (any source).
        opsQuery('GET',
          `v_field_provenance_unranked?` +
          `select=target_table,field_name,source,writes_30d,writes_succeeded,` +
          `writes_skipped,writes_conflicted,first_seen,last_seen,distinct_records,` +
          `distinct_sources_seen` +
          `&order=writes_30d.desc&limit=100`
        )
      ]);

      // Build the summary aggregate
      const summaryMap = new Map();
      for (const r of (summary.data || [])) {
        const key = `${r.target_table}|${r.field_name}|${r.enforce_mode}|${r.decision}`;
        summaryMap.set(key, (summaryMap.get(key) || 0) + 1);
      }
      const summaryRows = [...summaryMap.entries()]
        .map(([key, count]) => {
          const [target_table, field_name, enforce_mode, decision] = key.split('|');
          return { target_table, field_name, enforce_mode, decision, count };
        })
        .sort((a, b) => b.count - a.count);

      return res.status(200).json({
        actionable: actionable.data || [],
        summary_7d: summaryRows,
        unranked:   unranked.data || [],
      });
    }

    // R4 Phase-4 Tier A: unified review queue. Drives the "Provenance Review
    // Queue" widget on the Ops page. Returns the rows from
    // v_field_provenance_review_queue plus per-bucket counts so the UI can
    // render the bucket-filter chips without a second round trip.
    //
    // Perf note: an earlier version fetched a 10k-row rollup to count
    // buckets; with the full view computing ~520k skip rows the
    // PostgREST round-trip exceeded the 8s fetchWithTimeout ceiling.
    // The view has since been split: actionable conflicts only live in
    // v_field_provenance_review_queue (~70ms); the warn/strict skip
    // surface lives in v_field_provenance_warn_strict_skips and is
    // loaded only when the dedicated chip is clicked.
    if (action === 'quality_provenance_review_queue') {
      const limit  = Math.min(Math.max(parseInt(req.query.limit, 10)  || 200, 1), 1000);
      const bucket = req.query.bucket; // optional pre-filter
      let path = `v_field_provenance_review_queue?` +
        `select=provenance_id,recorded_at,target_database,target_table,record_pk_value,` +
        `field_name,attempted_value,attempted_source,attempted_priority,attempted_enforce_mode,` +
        `current_provenance_id,current_value,current_source,current_priority,` +
        `decision,decision_reason,row_kind,bucket` +
        `&order=recorded_at.desc&limit=${limit}`;
      if (bucket && /^[a-z_]+$/.test(bucket)) {
        path += `&bucket=eq.${bucket}`;
      }

      // Rows query + tiny aggregate RPC for counts. countMode:'none' skips
      // PostgREST's exact-count round-trip (which doubles the view scan).
      const [rows, countsRpc] = await Promise.all([
        opsQuery('GET', path, undefined, { countMode: 'none' }),
        opsQuery('POST', 'rpc/lcc_provenance_review_queue_counts', {}),
      ]);
      const bucketCounts = {};
      for (const r of (countsRpc.data || [])) {
        bucketCounts[r.bucket] = Number(r.n) || 0;
      }

      // Decorate each row with the underlying entity's label (property
      // address, lease tenant + dates, contact name, document file_name,
      // parcel APN) so the queue card reads like
      //     dia.leases.lease_expiration
      //     Fresenius · expires 2026-05-31
      //     123 Main St, Memphis, TN
      // instead of "record 18391" with no other context. Best-effort:
      // failure leaves record_context=null on the row, queue still renders.
      const queueRows = rows.data || [];
      try {
        await enrichReviewQueueContext(queueRows);
      } catch (err) {
        console.warn('[quality_provenance_review_queue] enrichment failed:', err?.message || err);
      }

      return res.status(200).json({
        rows: queueRows,
        bucket_counts: bucketCounts,
      });
    }

    // Search by name
    if (action === 'search' && q) {
      const searchTerm = q.replace(/[%_]/g, '').trim();
      if (searchTerm.length < 2) {
        return res.status(400).json({ error: 'Search term must be at least 2 characters' });
      }

      let path = `entities?workspace_id=eq.${workspaceId}&or=(name.ilike.*${encodeURIComponent(searchTerm)}*,canonical_name.ilike.*${encodeURIComponent(searchTerm.toLowerCase())}*)&select=id,entity_type,name,domain,city,state,email,phone,address,org_type,asset_type,external_identities(source_system,source_type,external_id)`;
      if (entity_type && isValidEnum(entity_type, ENTITY_TYPES)) {
        path += `&entity_type=eq.${entity_type}`;
      }
      if (domain && isValidEnum(domain, DOMAINS)) {
        path += `&domain=eq.${domain}`;
      }
      path += '&limit=50&order=name';

      // Search results — countMode='estimated' is fine for the surfaced count
      // and skips the second COUNT(*) trip.
      const result = await opsQuery('GET', path, undefined, { countMode: 'estimated' });
      return res.status(200).json({ entities: result.data || [], count: result.count });
    }

    // Lookup a single asset entity by address (+ optional city/state).
    // Used by the property detail panel to surface CoStar-sourced lease
    // estimates from the entity's metadata JSONB.
    //
    // Round 76ek (2026-04-29): the address-only path is fragile against
    // tiny formatting differences ("Dr" vs "Drive" vs "Dr."), which caused
    // the sidebar to "lose" entities right after a successful save and show
    // the green Save button again as if nothing happened. We now try
    // stronger identity signals first when the caller supplies them:
    //   1) entity_id (exact)
    //   2) source_url (exact match against metadata->>'source_url')
    //   3) parcel_number (exact match against metadata->>'parcel_number')
    //   4) domain_property_id + domain (exact)
    //   5) address (case-insensitive, with light Drive↔Dr normalization)
    //   6) address (case-insensitive, exact equality — legacy fallback)
    // First non-empty result wins. This lets the sidebar identify a
    // CoStar-saved property from any of source_url/parcel/property_id even
    // if the address text on the live page has drifted.
    if (action === 'lookup_asset') {
      const select = 'id,entity_type,name,address,city,state,domain,asset_type,metadata';
      const baseFilter = `workspace_id=eq.${workspaceId}&entity_type=eq.asset`;
      const sanitize = (s) => String(s || '').trim().replace(/[%_*,()]/g, '');

      const tryQuery = async (extraFilter) => {
        const path = `entities?${baseFilter}&${extraFilter}&select=${select}&limit=1`;
        const r = await opsQuery('GET', path);
        return (r.data && r.data[0]) || null;
      };

      // 1) entity_id — caller already knows the row (e.g. immediately after save)
      if (req.query.entity_id) {
        const id = sanitize(req.query.entity_id);
        if (id) {
          const hit = await tryQuery(`id=eq.${encodeURIComponent(id)}`);
          if (hit) return res.status(200).json({ entity: hit, matched_via: 'entity_id' });
        }
      }

      // 2) source_url — most precise sidebar identity (CoStar listing URL, etc.)
      if (req.query.source_url) {
        const u = sanitize(req.query.source_url);
        if (u && u.length >= 8) {
          const hit = await tryQuery(`metadata->>source_url=eq.${encodeURIComponent(u)}`);
          if (hit) return res.status(200).json({ entity: hit, matched_via: 'source_url' });
        }
      }

      // 2b) canonical_url — same site path without query/tracking params.
      //     Round 76ej.i (2026-05-04): added because CREXi eblast URLs
      //     carry recommId / utm_term / templateId tokens that drift
      //     between visits, breaking the exact-eq source_url match. The
      //     extension now strips them and sends the canonical
      //     /properties/<id>/<slug> URL alongside the full source_url.
      if (req.query.canonical_url) {
        const cu = sanitize(req.query.canonical_url);
        if (cu && cu.length >= 8) {
          const hit = await tryQuery(
            `metadata->>source_url=ilike.${encodeURIComponent(cu)}*`
          );
          if (hit) return res.status(200).json({ entity: hit, matched_via: 'canonical_url' });
        }
      }

      // 2c) domain_listing_id + listing_source — site-native listing id
      //     (e.g. CREXi /properties/<id>/, LoopNet listing id).
      //     Stable across listing-status changes and URL rewrites.
      if (req.query.domain_listing_id && req.query.listing_source) {
        const lid = sanitize(req.query.domain_listing_id);
        const ls  = sanitize(req.query.listing_source);
        if (lid && ls) {
          // Try a wildcard match against any source_url that contains
          // /<source>.com/properties/<id>/. Cheap O(n) scan but the
          // workspace_id filter keeps it bounded.
          const pat = `*${ls}.com/properties/${lid}*`;
          const hit = await tryQuery(
            `metadata->>source_url=ilike.${encodeURIComponent(pat)}`
          );
          if (hit) return res.status(200).json({ entity: hit, matched_via: 'domain_listing_id' });
        }
      }

      // 3) parcel_number — survives address re-spellings and re-listings
      if (req.query.parcel_number) {
        const parcel = sanitize(req.query.parcel_number);
        if (parcel && parcel.length >= 3) {
          const hit = await tryQuery(`metadata->>parcel_number=eq.${encodeURIComponent(parcel)}`);
          if (hit) return res.status(200).json({ entity: hit, matched_via: 'parcel_number' });
        }
      }

      // 4) domain_property_id + domain (only useful if caller already knows
      //    which dia/gov row this is — e.g. after a save bootstrap)
      if (req.query.domain_property_id && req.query.domain) {
        const pid = sanitize(req.query.domain_property_id);
        const dom = sanitize(req.query.domain);
        if (pid && dom) {
          const hit = await tryQuery(
            `metadata->>domain_property_id=eq.${encodeURIComponent(pid)}` +
            `&domain=eq.${encodeURIComponent(dom)}`
          );
          if (hit) return res.status(200).json({ entity: hit, matched_via: 'domain_property_id' });
        }
      }

      // 5) + 6) address fallbacks
      const rawAddress = (req.query.address || '').trim();
      if (rawAddress.length < 3) {
        return res.status(400).json({
          error: 'address query parameter required (min 3 chars), or supply entity_id/source_url/parcel_number/domain_property_id'
        });
      }
      const address = rawAddress.replace(/[%_*]/g, '');
      const cityFilter = req.query.city
        ? `&city=ilike.${encodeURIComponent(sanitize(req.query.city))}`
        : '';
      const stateFilter = req.query.state
        ? `&state=eq.${encodeURIComponent(sanitize(req.query.state))}`
        : '';

      // 5) address with Drive↔Dr normalization — covers the common drift
      //    we saw on 1507 Hillview where one row stored "Drive" and another
      //    stored "Dr". Build a wildcard pattern that matches either form.
      const STREET_ALIASES = [
        [/\b(drive)\b/i,    'Dr'],
        [/\b(dr\.?)\b/i,    'Drive'],
        [/\b(street)\b/i,   'St'],
        [/\b(st\.?)\b/i,    'Street'],
        [/\b(avenue)\b/i,   'Ave'],
        [/\b(ave\.?)\b/i,   'Avenue'],
        [/\b(boulevard)\b/i,'Blvd'],
        [/\b(blvd\.?)\b/i,  'Boulevard'],
        [/\b(road)\b/i,     'Rd'],
        [/\b(rd\.?)\b/i,    'Road'],
        [/\b(highway)\b/i,  'Hwy'],
        [/\b(hwy\.?)\b/i,   'Highway'],
        [/\b(parkway)\b/i,  'Pkwy'],
        [/\b(pkwy\.?)\b/i,  'Parkway'],
      ];
      const addressVariants = new Set([address]);
      for (const [re, alt] of STREET_ALIASES) {
        if (re.test(address)) {
          addressVariants.add(address.replace(re, alt));
        }
      }
      // Round 76ej.i (2026-05-04): the extension passes the full address
      // string ("109 Harrison Ave & 1601 Spring St, Jeffersonville, IN
      // 47130") but stored entities typically hold just the street
      // portion ("109 Harrison Ave & 1601 Spring St") with city/state
      // in their own columns. Strip the trailing ", City, ST ZIP" so
      // the exact-ilike pass also tries the bare street form. Adds the
      // street-only variant to the set; address-alias normalization
      // re-runs on it.
      const STRIP_SUFFIX = /,\s*[^,]+,\s*[A-Z]{2}\s+\d{5}(?:-\d{4})?\s*$/i;
      if (STRIP_SUFFIX.test(address)) {
        const streetOnly = address.replace(STRIP_SUFFIX, '').trim();
        if (streetOnly && streetOnly.length >= 3) {
          addressVariants.add(streetOnly);
          for (const [re, alt] of STREET_ALIASES) {
            if (re.test(streetOnly)) {
              addressVariants.add(streetOnly.replace(re, alt));
            }
          }
        }
      }
      // Try each variant exact-equal first (cheap), then fall through to a
      // pattern match. Stop at the first hit.
      for (const variant of addressVariants) {
        const v = variant.replace(/[%_*]/g, '');
        const hit = await tryQuery(
          `address=ilike.${encodeURIComponent(v)}${cityFilter}${stateFilter}`
        );
        if (hit) {
          return res.status(200).json({
            entity: hit,
            matched_via: variant === address ? 'address' : 'address_alias',
          });
        }
      }

      // 6) Final widest pass — wildcard on the original address. Helps when
      //    the live-page address has a trailing period or apartment suffix
      //    the saved row doesn't have. Limited to 1 row so we don't return
      //    the wrong building for ambiguous fragments.
      const hit = await tryQuery(
        `address=ilike.*${encodeURIComponent(address)}*${cityFilter}${stateFilter}`
      );
      if (hit) return res.status(200).json({ entity: hit, matched_via: 'address_wildcard' });

      return res.status(200).json({ entity: null, matched_via: null });
    }

    // List with filters
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const perPage = Math.min(Math.max(parseInt(req.query.per_page) || parseInt(req.query.limit) || 50, 1), 100);
    const offset = (page - 1) * perPage;

    let path = `entities?workspace_id=eq.${workspaceId}&select=id,entity_type,name,domain,city,state,email,org_type,asset_type,created_at`;
    if (entity_type && isValidEnum(entity_type, ENTITY_TYPES)) {
      path += `&entity_type=eq.${entity_type}`;
    }
    if (domain && isValidEnum(domain, DOMAINS)) {
      path += `&domain=eq.${domain}`;
    }
    const rawOrder = req.query.order || 'created_at.desc';
    const safeOrder = /^[a-zA-Z0-9_.,]+$/.test(rawOrder) ? rawOrder : 'created_at.desc';
    path += `&limit=${perPage}&offset=${offset}&order=${safeOrder}`;

    // Paginated entity list — countMode='estimated' for parity with v2 queue.
    const result = await opsQuery('GET', path, undefined, { countMode: 'estimated' });
    return res.status(200).json({
      entities: result.data || [],
      count: result.count,
      pagination: pageMeta(page, perPage, result.count)
    });
  }

  // POST — create entity or link external identity
  if (req.method === 'POST') {
    if (!requireRole(user, 'operator', workspaceId)) {
      return res.status(403).json({ error: 'Operator role required' });
    }

    // On-demand sidebar extraction processing
    if (req.query.action === 'process_sidebar_extraction') {
      const { entity_id, force } = req.body || {};
      if (!entity_id) {
        return res.status(400).json({ error: 'entity_id is required' });
      }
      try {
        const result = await processSidebarExtraction(entity_id, workspaceId, user.id, { force: !!force });
        if (!result.ok) {
          return res.status(result.error === 'Entity not found' ? 404 : 500).json(result);
        }
        return res.status(200).json(result);
      } catch (err) {
        console.error('[Sidebar pipeline error]', err);
        return res.status(500).json({ error: 'Pipeline processing failed', detail: err?.message });
      }
    }

    // Round 76cx Phase 3: record a listing verification check
    // POST /api/entities?action=record_listing_verification
    // Body: { domain: 'dialysis'|'government', property_id, method, check_result,
    //         asking_price?, cap_rate?, source_url?, notes?, off_market_reason? }
    // Looks up active listings on the property and calls
    // public.lcc_record_listing_check() once per listing. Returns the
    // per-listing decision (state_transitioned + new_status) so the
    // sidebar can toast a meaningful summary.
    if (req.query.action === 'record_listing_verification') {
      const {
        domain,
        property_id,
        method,
        check_result,
        asking_price,
        cap_rate,
        source_url,
        notes,
        off_market_reason,
      } = req.body || {};

      if (!domain || !['dialysis', 'government'].includes(domain)) {
        return res.status(400).json({ error: 'domain must be "dialysis" or "government"' });
      }
      if (!property_id || !Number.isFinite(Number(property_id))) {
        return res.status(400).json({ error: 'property_id (number) is required' });
      }
      const validMethods = ['auto_scrape', 'manual_user', 'sidebar_capture', 'sold_imported'];
      if (!method || !validMethods.includes(method)) {
        return res.status(400).json({ error: `method must be one of ${validMethods.join(', ')}` });
      }
      const validResults = ['still_available', 'price_changed', 'off_market', 'sold', 'unreachable'];
      if (!check_result || !validResults.includes(check_result)) {
        return res.status(400).json({ error: `check_result must be one of ${validResults.join(', ')}` });
      }

      try {
        // Find active listings on this property in the chosen domain.
        // dia uses is_active boolean; gov uses listing_status text.
        const listingFilter = domain === 'dialysis'
          ? `is_active=eq.true`
          : `listing_status=eq.active`;
        const idColumn = 'listing_id';
        const listingsRes = await domainQuery(domain, 'GET',
          `available_listings?property_id=eq.${Number(property_id)}&${listingFilter}&select=${idColumn}&limit=20`);
        if (!listingsRes.ok) {
          return res.status(502).json({ error: 'failed to read available_listings', detail: listingsRes.data });
        }
        let listings = Array.isArray(listingsRes.data) ? listingsRes.data : [];

        // Round 76eg: before deciding to auto-create, look at *any* listing
        // for this property (including inactive/Sold/Stale ones) so we can
        // (a) refuse to create when a recent sale event has been recorded,
        // and (b) prefer reactivating an existing row over inserting a
        // duplicate. Prior versions only checked is_active=true and would
        // happily insert parallel rows whenever the existing one was Sold.
        let autoCreated = null;
        let reactivated = null;
        if (listings.length === 0
            && method === 'sidebar_capture'
            && check_result === 'still_available'
            && asking_price != null && Number(asking_price) > 0) {

          // Refuse to auto-create when the property has a recorded sale
          // within the last 12 months — the user is most likely looking
          // at a stale broker page, not a genuine re-listing. The DB's
          // fn_listing_close_if_sold trigger would immediately flip any
          // row we inserted back to Sold anyway.
          const saleProbeFilter = domain === 'dialysis'
            ? `property_id=eq.${encodeURIComponent(String(property_id))}`
            : `property_id=eq.${Number(property_id)}`;
          const recentSaleRes = await domainQuery(domain, 'GET',
            `property_sale_events?${saleProbeFilter}&sale_date=gte.${
              new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10)
            }&select=sale_event_id,sale_date,price&order=sale_date.desc&limit=1`);
          if (recentSaleRes.ok && Array.isArray(recentSaleRes.data) && recentSaleRes.data.length) {
            return res.status(409).json({
              error: 'recent_sale_recorded',
              property_id,
              sale_date: recentSaleRes.data[0].sale_date,
              hint: 'A sale was recorded for this property within the last 12 months. Confirm this is a genuine re-listing before creating a fresh available_listings row.',
            });
          }

          // Try reactivating the most-recent inactive listing for this
          // property before inserting. This collapses the
          // sidebar-verify → fresh-row pattern into a single canonical row.
          const reviveFilter = domain === 'dialysis'
            ? `property_id=eq.${Number(property_id)}&is_active=eq.false`
            : `property_id=eq.${Number(property_id)}&listing_status=neq.active`;
          const reviveRes = await domainQuery(domain, 'GET',
            `available_listings?${reviveFilter}&select=*&order=listing_date.desc.nullslast&limit=1`);
          if (reviveRes.ok && Array.isArray(reviveRes.data) && reviveRes.data.length) {
            const prior = reviveRes.data[0];
            // Don't revive Sold rows — those carry sold_date/sold_price
            // and represent a real terminal state. Only revive Stale /
            // Withdrawn / Off Market.
            const status = String(prior.status || prior.listing_status || '').toLowerCase();
            const hasSale = prior.sold_date || prior.sold_price || prior.sale_transaction_id;
            if (!hasSale && !['sold', 'closed', 'closed but obligated'].includes(status)) {
              // Drop paywalled CoStar Suite URLs before persisting
              // (issue #560). Falls back to prior.listing_url so the
              // revive doesn't blank out an already-good URL.
              const safeSourceUrl = sanitizeListingUrl(
                source_url || null,
                `entities-handler:revive:${domain}.available_listings`,
              );
              const patchRow = domain === 'dialysis'
                ? {
                    is_active: true,
                    status: 'Active',
                    last_price: Number(asking_price),
                    current_cap_rate: cap_rate != null ? Number(cap_rate) : prior.current_cap_rate,
                    listing_url: safeSourceUrl || prior.listing_url,
                    last_seen: new Date().toISOString().slice(0, 10),
                    last_verified_at: new Date().toISOString(),
                    off_market_date: null,
                    off_market_reason: null,
                    notes: (prior.notes ? prior.notes + '\n' : '') +
                      `[entities-handler reactivated ${new Date().toISOString().slice(0, 10)}] sidebar verify-still-available`,
                  }
                : {
                    listing_status: 'active',
                    asking_price: Number(asking_price),
                    asking_cap_rate: cap_rate != null ? Number(cap_rate) : prior.asking_cap_rate,
                    source_url: safeSourceUrl || prior.source_url,
                    last_seen_at: new Date().toISOString(),
                    last_verified_at: new Date().toISOString(),
                  };
              const patchRes = await domainQuery(domain, 'PATCH',
                `available_listings?listing_id=eq.${encodeURIComponent(prior.listing_id)}`,
                patchRow,
                { Prefer: 'return=representation' });
              if (patchRes.ok) {
                const revived = Array.isArray(patchRes.data) ? patchRes.data[0] : patchRes.data;
                if (revived?.listing_id) {
                  reactivated = revived;
                  listings = [{ listing_id: revived.listing_id }];
                  console.log(`[record_listing_verification] reactivated listing_id=${revived.listing_id} for ${domain} property_id=${property_id}`);
                }
              }
            }
          }
        }

        if (listings.length === 0
            && reactivated == null
            && method === 'sidebar_capture'
            && check_result === 'still_available'
            && asking_price != null && Number(asking_price) > 0) {
          // Round 76dy: dia.available_listings has no data_source column (only
          // notes); gov uses listing_source not data_source. The prior
          // payload tried to insert data_source on both, which crashed dia
          // INSERTs with "column does not exist" → the verify button toast
          // showed "auto-create attempted but failed" on every click.
          // Drop paywalled CoStar Suite URLs before persisting
          // (issue #560). Same logic as the revive branch above.
          const safeSourceUrlForCreate = sanitizeListingUrl(
            source_url || null,
            `entities-handler:create:${domain}.available_listings`,
          );
          const newListing = domain === 'dialysis'
            ? {
                property_id: Number(property_id),
                is_active: true,
                listing_date: new Date().toISOString().slice(0, 10),
                // R70 B3/B4: no true list-date signal in the verify path —
                // tag as capture-fallback so new-to-market counts can exclude it.
                listing_date_source: 'capture_date_fallback',
                // T4c: no market-entry evidence in the verify path → on_market_date
                // HELD (null) so the row is excluded from the timing/DOM series.
                on_market_date_source: 'unestablished',
                on_market_date_confidence: 'none',
                last_price: Number(asking_price),
                current_cap_rate: cap_rate != null ? Number(cap_rate) : null,
                listing_url: safeSourceUrlForCreate,
                last_seen: new Date().toISOString().slice(0, 10),
                last_verified_at: new Date().toISOString(),
                notes: 'auto-created by LCC sidebar verify-still-available',
              }
            : {
                property_id: Number(property_id),
                listing_status: 'active',
                listing_date: new Date().toISOString().slice(0, 10),
                listing_date_source: 'capture_date_fallback',
                on_market_date_source: 'unestablished',
                on_market_date_confidence: 'none',
                asking_price: Number(asking_price),
                asking_cap_rate: cap_rate != null ? Number(cap_rate) : null,
                source_url: safeSourceUrlForCreate,
                first_seen_at: new Date().toISOString(),
                last_seen_at: new Date().toISOString(),
                last_verified_at: new Date().toISOString(),
                listing_source: 'lcc_sidebar_verify',
              };
          const createRes = await domainQuery(domain, 'POST', 'available_listings', newListing);
          if (createRes.ok) {
            const created = Array.isArray(createRes.data) ? createRes.data[0] : createRes.data;
            if (created?.listing_id) {
              autoCreated = created;
              listings = [{ listing_id: created.listing_id }];
              console.log(`[record_listing_verification] auto-created listing_id=${created.listing_id} for ${domain} property_id=${property_id}`);
            }
          } else {
            console.warn('[record_listing_verification] auto-create failed:', createRes.status, createRes.data);
          }
        }

        if (listings.length === 0) {
          return res.status(404).json({
            error: 'no active listings on this property',
            property_id,
            hint: asking_price ? 'auto-create attempted but failed' : 'pass asking_price to auto-create on first verify',
          });
        }

        const results = [];
        for (const l of listings) {
          const rpcRes = await domainQuery(domain, 'POST', 'rpc/lcc_record_listing_check', {
            p_listing_id: l.listing_id,
            p_method: method,
            p_check_result: check_result,
            p_asking_price: asking_price != null ? Number(asking_price) : null,
            p_cap_rate: cap_rate != null ? Number(cap_rate) : null,
            p_source_url: source_url || null,
            p_off_market_reason: off_market_reason || null,
            p_notes: notes || null,
            p_verified_by: user.id || null,
          }, { label: 'entitiesHandler:recordListingCheck' });
          if (!rpcRes.ok) {
            results.push({ listing_id: l.listing_id, ok: false, error: rpcRes.data });
            continue;
          }
          // RPC returns a row with verification_id, status_history_id,
          // state_transitioned, new_status.
          const decision = Array.isArray(rpcRes.data) ? rpcRes.data[0] : rpcRes.data;
          results.push({ listing_id: l.listing_id, ok: true, ...decision });
        }
        const okCount = results.filter(r => r.ok).length;
        return res.status(200).json({
          ok: okCount > 0,
          property_id,
          domain,
          method,
          check_result,
          listings_verified: okCount,
          listings_total: listings.length,
          auto_created: autoCreated ? { listing_id: autoCreated.listing_id } : null,
          results,
        });
      } catch (err) {
        console.error('[record_listing_verification error]', err);
        return res.status(500).json({ error: 'Verification failed', detail: err?.message });
      }
    }

    // Add alias
    if (req.query.action === 'add_alias') {
      const { entity_id, alias_name, source } = req.body || {};
      if (!entity_id || !alias_name) {
        return res.status(400).json({ error: 'entity_id and alias_name are required' });
      }

      const alias_canonical = alias_name.trim().toLowerCase()
        .replace(/\b(llc|inc|corp|ltd|co|company|group|partners|lp|llp)\b\.?/gi, '')
        .replace(/[^a-z0-9\s]/g, '')
        .replace(/\s+/g, ' ')
        .trim();

      const result = await opsQuery('POST', 'entity_aliases', {
        workspace_id: workspaceId,
        entity_id,
        alias_name: alias_name.trim(),
        alias_canonical,
        source: source || 'manual'
      }, { 'Prefer': 'return=representation,resolution=merge-duplicates' });

      if (!result.ok) {
        return res.status(result.status).json({ error: 'Failed to add alias', detail: result.data });
      }
      return res.status(201).json({ alias: Array.isArray(result.data) ? result.data[0] : result.data });
    }

    if (req.query.action === 'set_precedence') {
      const { field_name, source_system, precedence } = req.body || {};
      const parsed = Number(precedence);
      if (!field_name || !source_system || Number.isNaN(parsed)) {
        return res.status(400).json({ error: 'field_name, source_system, and numeric precedence are required' });
      }

      const result = await opsQuery('POST', 'source_precedence', {
        workspace_id: workspaceId,
        field_name: String(field_name).trim(),
        source_system: String(source_system).trim(),
        precedence: parsed
      }, { 'Prefer': 'return=representation,resolution=merge-duplicates' });

      if (!result.ok) {
        return res.status(result.status).json({ error: 'Failed to set source precedence', detail: result.data });
      }
      return res.status(201).json({ precedence: Array.isArray(result.data) ? result.data[0] : result.data });
    }

    // Merge two entities — moves all relationships, identities, aliases, actions, inbox items to target
    if (req.query.action === 'merge') {
      if (!requireRole(user, 'manager', workspaceId)) {
        return res.status(403).json({ error: 'Manager role required to merge entities' });
      }

      const { target_id, source_id } = req.body || {};
      if (!target_id || !source_id) {
        return res.status(400).json({ error: 'target_id and source_id are required' });
      }
      if (target_id === source_id) {
        return res.status(400).json({ error: 'Cannot merge entity with itself' });
      }

      // Verify both entities exist
      const [targetRes, sourceRes] = await Promise.all([
        opsQuery('GET', `entities?id=eq.${target_id}&workspace_id=eq.${workspaceId}&select=id,name`),
        opsQuery('GET', `entities?id=eq.${source_id}&workspace_id=eq.${workspaceId}&select=id,name`)
      ]);

      if (!targetRes.data?.length) return res.status(404).json({ error: 'Target entity not found' });
      if (!sourceRes.data?.length) return res.status(404).json({ error: 'Source entity not found' });

      const targetEntity = targetRes.data[0];
      const sourceEntity = sourceRes.data[0];

      // Canonical merge (Tier 3 Phase 2, 2026-06-16): route through
      // lcc_merge_entity FIRST — the BD-doctrine merge that PK-safely carries
      // lcc_entity_portfolio_facts + external_identities and tombstones the
      // loser. The older hand-rolled path moved aliases/relationships/ops rows
      // but DROPPED the portfolio edges entirely, silently orphaning BD-graph
      // data on every merge. We now do BOTH: the RPC owns the BD graph
      // (portfolio_facts + external_identities), and the PATCHes below move only
      // the ops tables the RPC does NOT cover — no orphans on either graph.
      const mergeRpc = await opsQuery('POST', 'rpc/lcc_merge_entity',
        { p_loser: source_id, p_winner: target_id });
      if (!mergeRpc.ok) {
        return res.status(502).json({ error: 'merge_failed', detail: mergeRpc.data });
      }

      // Move aliases from source to target (external_identities already moved by
      // the RPC).
      await opsQuery('PATCH',
        `entity_aliases?entity_id=eq.${source_id}&workspace_id=eq.${workspaceId}`,
        { entity_id: target_id }
      );

      // Add source name as alias on target
      const sourceCanonical = sourceEntity.name.trim().toLowerCase()
        .replace(/\b(llc|inc|corp|ltd|co|company|group|partners|lp|llp)\b\.?/gi, '')
        .replace(/[^a-z0-9\s]/g, '')
        .replace(/\s+/g, ' ')
        .trim();
      await opsQuery('POST', 'entity_aliases', {
        workspace_id: workspaceId,
        entity_id: target_id,
        alias_name: sourceEntity.name,
        alias_canonical: sourceCanonical,
        source: `merged_from:${source_id}`
      }, { 'Prefer': 'return=representation,resolution=merge-duplicates' });

      // Move relationships
      await opsQuery('PATCH',
        `entity_relationships?from_entity_id=eq.${source_id}&workspace_id=eq.${workspaceId}`,
        { from_entity_id: target_id }
      );
      await opsQuery('PATCH',
        `entity_relationships?to_entity_id=eq.${source_id}&workspace_id=eq.${workspaceId}`,
        { to_entity_id: target_id }
      );

      // Move action items
      await opsQuery('PATCH',
        `action_items?entity_id=eq.${source_id}&workspace_id=eq.${workspaceId}`,
        { entity_id: target_id }
      );

      // Move activity events
      await opsQuery('PATCH',
        `activity_events?entity_id=eq.${source_id}&workspace_id=eq.${workspaceId}`,
        { entity_id: target_id }
      );

      // Move watchers
      await opsQuery('PATCH',
        `watchers?entity_id=eq.${source_id}&workspace_id=eq.${workspaceId}`,
        { entity_id: target_id }
      );

      // Log merge activity
      await opsQuery('POST', 'activity_events', {
        workspace_id: workspaceId,
        actor_id: user.id,
        entity_id: target_id,
        category: 'system',
        title: `Merged entity "${sourceEntity.name}" into "${targetEntity.name}"`,
        source_type: 'system',
        visibility: 'shared',
        metadata: {
          merge_source_id: source_id,
          merge_source_name: sourceEntity.name,
          merge_target_id: target_id,
          merge_target_name: targetEntity.name
        },
        occurred_at: new Date().toISOString()
      });

      // Merges change entity membership (SPE/parent + queue) — refresh the
      // caches, parity with the Decision Center merge_duplicate_entities path.
      try { await opsQuery('POST', 'rpc/lcc_refresh_buyer_spe_resolved', {}); } catch (_e) { /* soft */ }
      try { await opsQuery('POST', 'rpc/lcc_refresh_priority_queue_resolved', {}); } catch (_e) { /* soft */ }

      // Delete source entity (portfolio + identities now live on target via the
      // RPC; aliases/relationships/ops rows moved above).
      await opsQuery('DELETE',
        `entities?id=eq.${source_id}&workspace_id=eq.${workspaceId}`
      );

      const mergeStats = (Array.isArray(mergeRpc.data) && mergeRpc.data[0]) ? mergeRpc.data[0] : {};
      return res.status(200).json({
        merged: true,
        target: targetEntity,
        source_removed: sourceEntity,
        portfolio_edges_moved: mergeStats.portfolio_edges_moved ?? null,
        external_identities_moved: mergeStats.external_identities_moved ?? null,
        message: `"${sourceEntity.name}" merged into "${targetEntity.name}". Source entity deleted.`
      });
    }

    // R4 Phase-4 Tier A: resolve a single provenance conflict/skip row.
    //
    // Body: { provenance_id: <bigint>,
    //         chosen: 'current'|'attempted'|'custom'|'junk'|'defer',
    //         custom_value: <any>,   // required iff chosen='custom'
    //         notes: <string> }      // optional
    //
    // Flow:
    //   1. Validate body + load attempted row from field_provenance
    //   2. For chosen in {attempted, custom}: call the domain DB's
    //      lcc_apply_field_resolution RPC; abort early on failure
    //   3. Call LCC Opps lcc_record_field_resolution to atomically:
    //      insert resolutions row, insert new manual_resolution
    //      provenance row (if writing), supersede prior rows.
    //
    // Manager role gate. Domain write is reversible via the
    // before_value in resolutions.domain_write_response.
    if (req.query.action === 'resolve_provenance_conflict') {
      if (!requireRole(user, 'manager', workspaceId)) {
        return res.status(403).json({ error: 'Manager role required to resolve provenance conflicts' });
      }

      const body = req.body || {};
      const provenance_id = body.provenance_id;
      const chosen        = body.chosen;
      const custom_value  = body.custom_value;
      const notes         = body.notes || null;

      const VALID_CHOSEN = new Set(['current','attempted','custom','junk','defer']);
      if (!Number.isFinite(Number(provenance_id))) {
        return res.status(400).json({ error: 'provenance_id (bigint) is required' });
      }
      if (!VALID_CHOSEN.has(chosen)) {
        return res.status(400).json({ error: `chosen must be one of ${[...VALID_CHOSEN].join(', ')}` });
      }
      if (chosen === 'custom' && (custom_value === undefined)) {
        return res.status(400).json({ error: 'custom_value is required when chosen=custom' });
      }

      // 1. Load the attempted row from LCC Opps
      const fpRes = await opsQuery('GET',
        `field_provenance?id=eq.${Number(provenance_id)}&select=id,target_database,target_table,record_pk_value,field_name,value,source,decision&limit=1`
      );
      if (!fpRes.ok || !fpRes.data?.length) {
        return res.status(404).json({ error: 'provenance row not found' });
      }
      const fp = fpRes.data[0];

      if (!['conflict','skip'].includes(fp.decision)) {
        return res.status(409).json({ error: `row no longer resolvable (decision=${fp.decision})`, decision: fp.decision });
      }

      // 2. Compute chosen_value + decide whether a domain write is needed.
      //    - 'current'  : no domain write; resolver picks the current value.
      //    - 'attempted': write the attempted value (fp.value) to the domain DB.
      //    - 'custom'   : write the reviewer-typed value.
      //    - 'junk'     : no domain write; flag attempted as junk.
      //    - 'defer'    : no domain write; queue re-review in 7d.
      let chosen_value_jsonb = null;
      let needsDomainWrite = false;
      if (chosen === 'attempted') {
        chosen_value_jsonb = fp.value;        // field_provenance.value is already JSONB
        needsDomainWrite = true;
      } else if (chosen === 'custom') {
        chosen_value_jsonb = custom_value;    // serialized as JSONB through the RPC call
        needsDomainWrite = true;
      }

      // 3. Domain DB write (if needed)
      let domainWriteOk = null;
      let domainWriteResponse = null;
      if (needsDomainWrite) {
        // Map LCC's target_database -> domain key + strip schema prefix from target_table
        let domain = null;
        let unqualifiedTable = fp.target_table;
        if (fp.target_database === 'dia_db' && fp.target_table.startsWith('dia.')) {
          domain = 'dialysis';
          unqualifiedTable = fp.target_table.slice('dia.'.length);
        } else if (fp.target_database === 'gov_db' && fp.target_table.startsWith('gov.')) {
          domain = 'government';
          unqualifiedTable = fp.target_table.slice('gov.'.length);
        } else {
          return res.status(400).json({
            error: 'Domain DB writes only supported for dia_db / gov_db with schema-prefixed target_table',
            target_database: fp.target_database, target_table: fp.target_table,
          });
        }

        const rpcRes = await domainQuery(domain, 'POST', 'rpc/lcc_apply_field_resolution', {
          p_target_table: unqualifiedTable,
          p_record_pk:    String(fp.record_pk_value),
          p_field_name:   fp.field_name,
          p_new_value:    chosen_value_jsonb,
          p_workspace_id: workspaceId,
          p_resolved_by:  user.id,
        }, {}, { label: 'resolve_provenance_conflict' });

        domainWriteResponse = rpcRes.data;
        domainWriteOk = !!(rpcRes.ok && rpcRes.data && rpcRes.data.ok);

        if (!domainWriteOk) {
          // Surface the domain envelope so the UI can show the specific error
          // (schema_ok=false / row-not-found / SQL error) without guessing.
          return res.status(502).json({
            error: 'Domain DB write failed',
            domain, target_table: unqualifiedTable,
            field_name: fp.field_name, record_pk: fp.record_pk_value,
            domain_write_response: rpcRes.data,
          });
        }
      }

      // 4. Atomic LCC-side resolution write
      const recordRes = await opsQuery('POST', 'rpc/lcc_record_field_resolution', {
        p_attempted_provenance_id: Number(provenance_id),
        p_chosen:                  chosen,
        p_chosen_value:            chosen_value_jsonb,
        p_workspace_id:            workspaceId,
        p_resolved_by:             user.id,
        p_decision_notes:          notes,
        p_domain_write_ok:         domainWriteOk,
        p_domain_write_response:   domainWriteResponse,
      });
      if (!recordRes.ok) {
        return res.status(500).json({
          error: 'Failed to record resolution on LCC Opps',
          detail: recordRes.data,
          // domain write already succeeded (if any); operator will need to inspect
          domain_write_ok: domainWriteOk,
          domain_write_response: domainWriteResponse,
        });
      }
      const resolution_id = Array.isArray(recordRes.data) ? recordRes.data[0] : recordRes.data;

      return res.status(200).json({
        ok: true,
        resolution_id,
        chosen,
        domain_write_ok: domainWriteOk,
        domain_write_response: domainWriteResponse,
      });
    }

    // Link external identity
    if (req.query.action === 'link') {
      const { entity_id, source_system, source_type, external_id, external_url, metadata } = req.body || {};
      if (!entity_id || !source_system || !source_type || !external_id) {
        return res.status(400).json({ error: 'entity_id, source_system, source_type, and external_id are required' });
      }

      // R4-A: canonicalize before writing so manual/API links can't introduce
      // a deprecated domain-DB spelling (dia_db/gov_supabase/…).
      const canonSystem = canonicalIdentitySystem(source_system);
      let canonType = source_type;
      if (CANONICAL_DOMAIN_SYSTEMS.includes(canonSystem)) {
        canonType = canonicalDomainSourceType(source_type) || source_type;
      }

      const result = await opsQuery('POST', 'external_identities', {
        workspace_id: workspaceId,
        entity_id,
        source_system: canonSystem,
        source_type: canonType,
        external_id,
        external_url: external_url || null,
        metadata: metadata || {},
        last_synced_at: new Date().toISOString()
      }, { 'Prefer': 'return=representation,resolution=merge-duplicates' });

      if (!result.ok) {
        return res.status(result.status).json({ error: 'Failed to link identity', detail: result.data });
      }

      return res.status(201).json({ identity: Array.isArray(result.data) ? result.data[0] : result.data });
    }

    // Create entity
    const { entity_type, name, domain: entityDomain, metadata, ...fields } = req.body || {};

    if (!entity_type || !isValidEnum(entity_type, ENTITY_TYPES)) {
      return res.status(400).json({ error: `entity_type must be one of: ${ENTITY_TYPES.join(', ')}` });
    }
    if (!name || name.trim().length === 0) {
      return res.status(400).json({ error: 'name is required' });
    }

    // Build canonical name for dedup
    const canonical_name = name.trim().toLowerCase()
      .replace(/\b(llc|inc|corp|ltd|co|company|group|partners|lp|llp)\b\.?/gi, '')
      .replace(/[^a-z0-9\s]/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    // Pre-insert dedup check for assets: match on normalized address + city.
    // Exact ilike on raw address misses common abbreviation variants
    // ("Street" vs "St", "Road" vs "Rd"), which lets CoStar create a duplicate
    // every time it spells a street type differently from the CMS record.
    const pickedFields = pickEntityFields(entity_type, fields);
    // Strip CoStar/LoopNet listing-status prefixes ("For Sale | ", "For Lease | ", …)
    // off the address before dedup or storage. Without this the prefixed string
    // becomes the dedup key and creates a duplicate asset entity for every
    // re-capture of an active listing.
    if (entity_type === 'asset' && pickedFields.address) {
      pickedFields.address = stripListingStatusPrefix(pickedFields.address).trim();
    }
    if (entity_type === 'asset' && pickedFields.address && pickedFields.city) {
      const normAddr = normalizeAddress(pickedFields.address);
      const rawAddr  = pickedFields.address.trim();
      const city = pickedFields.city.trim();
      const state = pickedFields.state;
      // Round 76s (2026-04-27): ilike on state matches 'SC' to stored
      // 'South Carolina' (and vice versa) — eq missed across format split.
      const stateClause = state ? `&state=ilike.${encodeURIComponent(state)}` : '';
      const dedupPath = `entities?entity_type=eq.asset` +
        `&address=ilike.${encodeURIComponent(normAddr)}` +
        `&city=ilike.${encodeURIComponent(city)}` +
        stateClause +
        `&workspace_id=eq.${workspaceId}` +
        `&select=id,domain,metadata` +
        `&order=domain.nullslast,updated_at.desc` +
        `&limit=5`;
      let dupCheck = await opsQuery('GET', dedupPath);
      // Round 76s: Fallback when normAddr ilike misses — try RAW address.
      // Same Round 76m bug pattern: ilike-without-wildcards is exact match,
      // so '3919 mayfair st' lookup misses '3919 Mayfair Street' stored.
      if ((!dupCheck.ok || !dupCheck.data?.length) && rawAddr && rawAddr !== normAddr) {
        const rawDedupPath = `entities?entity_type=eq.asset` +
          `&address=ilike.${encodeURIComponent(rawAddr)}` +
          `&city=ilike.${encodeURIComponent(city)}` +
          stateClause +
          `&workspace_id=eq.${workspaceId}` +
          `&select=id,domain,metadata` +
          `&order=domain.nullslast,updated_at.desc` +
          `&limit=5`;
        const rawDupCheck = await opsQuery('GET', rawDedupPath);
        if (rawDupCheck.ok && rawDupCheck.data?.length) dupCheck = rawDupCheck;
      }
      if (dupCheck.ok && dupCheck.data?.length) {
        // Among matches, prefer the one with domain + domain_property_id set
        const candidates = dupCheck.data;
        const existing = candidates.find(e =>
          e.domain &&
          e.metadata?.domain_property_id
        ) || candidates[0];

        // Found existing entity — update metadata with new extraction data.
        // Merge: prefer incoming non-null values over existing values.
        if (metadata && Object.keys(metadata).length > 0) {
          const existingMeta = existing.metadata || {};
          const incomingMeta = metadata;

          const mergedMeta = { ...existingMeta };
          for (const [key, val] of Object.entries(incomingMeta)) {
            if (val !== undefined && val !== null) {
              mergedMeta[key] = val;
            } else if (val === null) {
              // Explicit null clears stale bad values for tracked fields
              const TRACKED = ['cap_rate', 'noi', 'tenant_name', 'primary_tenant',
                'city', 'state', 'zip_code', 'parcel_number', 'assessed_value',
                'land_value', 'improvement_value'];
              if (TRACKED.includes(key)) mergedMeta[key] = null;
            }
          }
          mergedMeta._pipeline_status = null; // reset so pipeline re-runs

          const patchResult = await opsQuery(
            'PATCH',
            `entities?id=eq.${existing.id}&workspace_id=eq.${workspaceId}`,
            { metadata: mergedMeta, updated_at: new Date().toISOString() }
          );

          // Re-trigger pipeline with the fresh merged metadata
          if (patchResult.ok && hasSidebarData(mergedMeta)) {
            const patched = Array.isArray(patchResult.data)
              ? patchResult.data[0] : patchResult.data;
            if (patched?.id) {
              processSidebarExtraction(patched.id, workspaceId, user.id)
                .catch(err => console.error('[Dedup pipeline re-trigger]',
                  err?.message || err));
            }
          }
        }

        return res.status(200).json({ entity: existing, deduplicated: true });
      }
    }

    const entity = {
      workspace_id: workspaceId,
      entity_type,
      name: name.trim(),
      canonical_name,
      // 5th dia/gov alias bug (2026-06-07): canonicalize entities.domain so a
      // 'dialysis'/'government' body value writes the short form.
      domain: canonicalEntityDomain(entityDomain) || null,
      created_by: user.id,
      metadata: metadata || {},
      ...pickedFields
    };

    // Store a normalized copy of the street address on assets so future
    // dedup lookups can match on an abbreviation-stable key.
    if (entity_type === 'asset' && pickedFields.address) {
      entity.normalized_address = normalizeAddress(pickedFields.address);
    }

    const result = await opsQuery('POST', 'entities', entity);
    if (!result.ok) {
      return res.status(result.status).json({ error: 'Failed to create entity', detail: result.data });
    }

    const created = Array.isArray(result.data) ? result.data[0] : result.data;

    // Fire-and-forget: signal for listing-as-BD pipeline when an asset/listing is created
    if (entity_type === 'asset' && created?.state) {
      writeListingCreatedSignal(created, user);
    }

    // Fire-and-forget: unpack sidebar extraction data (contacts, sales, domain classification)
    if (entity_type === 'asset' && created?.id && hasSidebarData(metadata)) {
      processSidebarExtraction(created.id, workspaceId, user.id)
        .catch(err => console.error('[Sidebar pipeline async error]', err?.message || err));
    }

    return res.status(201).json({ entity: created });
  }

  // PATCH — update entity
  if (req.method === 'PATCH') {
    const { id } = req.query;
    if (!id) return res.status(400).json({ error: 'id query parameter required' });

    if (!requireRole(user, 'operator', workspaceId)) {
      return res.status(403).json({ error: 'Operator role required' });
    }

    const { name, domain: entityDomain, tags, metadata, ...fields } = req.body || {};
    const updates = { updated_at: new Date().toISOString() };

    if (name) {
      updates.name = name.trim();
      updates.canonical_name = name.trim().toLowerCase()
        .replace(/\b(llc|inc|corp|ltd|co|company|group|partners|lp|llp)\b\.?/gi, '')
        .replace(/[^a-z0-9\s]/g, '')
        .replace(/\s+/g, ' ')
        .trim();
    }
    if (entityDomain !== undefined) updates.domain = canonicalEntityDomain(entityDomain);
    if (tags !== undefined) updates.tags = tags;
    if (metadata !== undefined) updates.metadata = metadata;

    // Pick type-appropriate fields
    const allowedFields = ['description', 'first_name', 'last_name', 'title', 'phone', 'email',
      'org_type', 'address', 'city', 'state', 'zip', 'county', 'latitude', 'longitude', 'asset_type'];
    for (const f of allowedFields) {
      if (fields[f] !== undefined) updates[f] = fields[f];
    }

    const result = await opsQuery('PATCH',
      `entities?id=eq.${id}&workspace_id=eq.${workspaceId}`,
      updates
    );
    if (!result.ok) return res.status(result.status).json({ error: 'Failed to update entity' });

    const updated = Array.isArray(result.data) ? result.data[0] : result.data;

    // Fire-and-forget: if metadata was updated with new sidebar data, run the pipeline
    if (metadata && updated?.id && updated?.entity_type === 'asset' && hasSidebarData(metadata)) {
      processSidebarExtraction(updated.id, workspaceId, user.id)
        .catch(err => console.error('[Sidebar pipeline async error on PATCH]', err?.message || err));
    }

    return res.status(200).json({ entity: updated });
  }

  return res.status(405).json({ error: `Method ${req.method} not allowed` });
});

// ============================================================================
// Contact 360 helpers (shared by action=portfolio + action=contact360)
// ============================================================================

/**
 * Authoritative BD-spine portfolio for an entity: the v_entity_portfolio_all
 * rollup + the per-property lcc_entity_portfolio_facts ⋈ lcc_property_attributes
 * rows (owns/former via is_current). Returns { rollup, properties }.
 */
async function fetchEntityPortfolio(entityId, workspaceId) {
  const [rollupRes, factsRes] = await Promise.all([
    opsQuery('GET',
      `v_entity_portfolio_all?entity_id=eq.${entityId}&workspace_id=eq.${workspaceId}` +
      `&select=entity_id,name,owner_role,primary_domain,total_property_count,current_property_count,` +
      `dia_property_count,gov_property_count,is_cross_vertical,current_annual_rent_total,avg_cap_rate,` +
      `earliest_acquisition_date,latest_acquisition_date&limit=1`),
    opsQuery('GET',
      `lcc_entity_portfolio_facts?entity_id=eq.${entityId}` +
      `&select=source_domain,source_property_id,is_current,annual_rent,sale_price,cap_rate,` +
      `ownership_start_date,ownership_end_date,ownership_source` +
      `&order=is_current.desc,annual_rent.desc.nullslast&limit=500`)
  ]);

  const rollup = (rollupRes.ok && rollupRes.data?.length) ? rollupRes.data[0] : null;
  const facts = (factsRes.ok && Array.isArray(factsRes.data)) ? factsRes.data : [];

  // Batch-fetch property attributes for address / tenant / city. The two mirrors
  // share (source_domain, source_property_id) but carry no declared FK, so
  // PostgREST can't embed — fetch per-domain id sets + merge in JS.
  const idsByDomain = {};
  for (const f of facts) {
    const dom = f.source_domain;
    if (!dom || f.source_property_id == null) continue;
    (idsByDomain[dom] = idsByDomain[dom] || []).push(String(f.source_property_id));
  }
  const attrMap = {};
  await Promise.all(Object.entries(idsByDomain).map(async ([dom, ids]) => {
    const uniq = Array.from(new Set(ids));
    for (let i = 0; i < uniq.length; i += 200) {
      const chunk = uniq.slice(i, i + 200);
      const inList = chunk.map(v => encodeURIComponent(v)).join(',');
      const ar = await opsQuery('GET',
        `lcc_property_attributes?source_domain=eq.${encodeURIComponent(dom)}` +
        `&source_property_id=in.(${inList})` +
        `&select=source_domain,source_property_id,address,city,state,tenant_short,tenant_label,` +
        `building_type,asset_class,annual_rent,noi`);
      if (ar.ok && Array.isArray(ar.data)) {
        for (const a of ar.data) attrMap[a.source_domain + ':' + a.source_property_id] = a;
      }
    }
  }));

  const properties = facts.map(f => {
    const a = attrMap[f.source_domain + ':' + f.source_property_id] || {};
    return {
      source_domain: f.source_domain,
      source_property_id: f.source_property_id,
      is_current: f.is_current,
      annual_rent: f.annual_rent != null ? Number(f.annual_rent) : (a.annual_rent != null ? Number(a.annual_rent) : null),
      sale_price: f.sale_price != null ? Number(f.sale_price) : null,
      cap_rate: f.cap_rate != null ? Number(f.cap_rate) : null,
      ownership_start_date: f.ownership_start_date || null,
      ownership_end_date: f.ownership_end_date || null,
      address: a.address || null,
      city: a.city || null,
      state: a.state || null,
      tenant: a.tenant_label || a.tenant_short || null,
      building_type: a.building_type || null,
      asset_class: a.asset_class || null,
    };
  });

  return { rollup, properties };
}

/**
 * Resolve the SF Account owner (the rep who owns the account = the assigned
 * broker for ROE). Reads the sf_owner_name/sf_owner_id captured on the
 * salesforce/Account external_identity's metadata (by the SF sync going forward).
 * Prefers the entity's OWN account identity; falls back to the account of an org
 * the person works_at / is associated_with. Returns { name, sf_owner_id,
 * sf_account_id, source } | null.
 */
async function resolveAccountOwner(entity, entityId, workspaceId) {
  const own = (entity.external_identities || []).find(x =>
    String(x.source_system || '').toLowerCase() === 'salesforce' &&
    String(x.source_type || '').toLowerCase() === 'account');
  if (own && own.metadata && (own.metadata.sf_owner_name || own.metadata.sf_owner_id)) {
    return { name: own.metadata.sf_owner_name || null, sf_owner_id: own.metadata.sf_owner_id || null,
             sf_account_id: own.external_id || null, source: 'entity_account' };
  }

  // Person → org (either edge direction). Fetch related org ids then their
  // Account identity + owner metadata. Best-effort; forward-looking.
  const relRes = await opsQuery('GET',
    `entity_relationships?workspace_id=eq.${workspaceId}` +
    `&or=(from_entity_id.eq.${entityId},to_entity_id.eq.${entityId})` +
    `&relationship_type=in.(works_at,associated_with,owner_parent,managed_by)` +
    `&select=from_entity_id,to_entity_id&limit=50`);
  const orgIds = new Set();
  if (relRes.ok && Array.isArray(relRes.data)) {
    for (const r of relRes.data) {
      if (r.from_entity_id && r.from_entity_id !== entityId) orgIds.add(r.from_entity_id);
      if (r.to_entity_id && r.to_entity_id !== entityId) orgIds.add(r.to_entity_id);
    }
  }
  if (orgIds.size) {
    const inList = Array.from(orgIds).map(v => encodeURIComponent(v)).join(',');
    const orgRes = await opsQuery('GET',
      `external_identities?entity_id=in.(${inList})&source_system=eq.salesforce&source_type=eq.Account` +
      `&select=external_id,metadata&limit=10`);
    if (orgRes.ok && Array.isArray(orgRes.data)) {
      const withOwner = orgRes.data.find(r => r.metadata && (r.metadata.sf_owner_name || r.metadata.sf_owner_id));
      if (withOwner) {
        return { name: withOwner.metadata.sf_owner_name || null, sf_owner_id: withOwner.metadata.sf_owner_id || null,
                 sf_account_id: withOwner.external_id || null, source: 'org_account' };
      }
      if (orgRes.data[0]) {
        return { name: null, sf_owner_id: null, sf_account_id: orgRes.data[0].external_id || null, source: 'org_account' };
      }
    }
  }

  if (own) return { name: null, sf_owner_id: null, sf_account_id: own.external_id || null, source: 'entity_account' };
  return null;
}

/** Aggregate the engagement summary from the entity's unified_contacts row(s). */
function buildEngagement(ucRows) {
  if (!Array.isArray(ucRows) || !ucRows.length) return null;
  let best = ucRows[0];
  for (const u of ucRows) if (Number(u.engagement_score || 0) > Number(best.engagement_score || 0)) best = u;
  return {
    score: best.engagement_score != null ? Number(best.engagement_score) : null,
    last_call: best.last_call_date || null,
    last_email: best.last_email_date || null,
    last_meeting: best.last_meeting_date || null,
    last_activity: best.last_activity_date || null,
    total_calls: best.total_calls || 0,
    total_emails: best.total_emails_sent || 0,
    total_touches: best.total_touches || 0,
    total_transactions: best.total_transactions || 0,
    total_volume: best.total_volume != null ? Number(best.total_volume) : null,
  };
}

// Relationship types that carry each BD role, in priority order. The role
// drives the whole Contact 360 layout (owner-portfolio vs broker deal-intel).
const OWNER_REL_TYPES = new Set(['owns', 'developed']);
const BROKER_REL_TYPES = new Set(['brokers']);
const BUYER_REL_TYPES = new Set(['purchases']);

/**
 * Detect the entity's BD role from its OUT (from-side) relationship edges.
 * owner (owns/developed) > broker (brokers) > buyer (purchases) > contact.
 * A person captured as a "Listing Broker at <firm>" carries `brokers` edges →
 * broker mode. An org/person with owns edges → owner mode. Returns
 * { role, has_owner_edges, has_broker_edges, has_buyer_edges }.
 */
export function detectEntityRole(entity) {
  const edges = Array.isArray(entity?.entity_relationships) ? entity.entity_relationships : [];
  let owner = false, broker = false, buyer = false;
  for (const e of edges) {
    const t = e?.relationship_type;
    if (OWNER_REL_TYPES.has(t)) owner = true;
    else if (BROKER_REL_TYPES.has(t)) broker = true;
    else if (BUYER_REL_TYPES.has(t)) buyer = true;
  }
  // An asset entity is never a contact — but Contact 360 is only opened on
  // person/org, so we key purely on the edges. Priority: owner > broker > buyer.
  let role = 'contact';
  if (owner) role = 'owner';
  else if (broker) role = 'broker';
  else if (buyer) role = 'buyer';
  return { role, has_owner_edges: owner, has_broker_edges: broker, has_buyer_edges: buyer };
}

/**
 * Broker deal intelligence — replaces owner-portfolio for broker entities.
 * Counts deals brokered off the `brokers` OUT edges and splits by
 * metadata.role (listing_broker = represents SELLERS; buyer_broker = represents
 * BUYERS — the signal is on the LCC edge, no cross-DB name-match needed).
 * Target markets = the states/cities of the linked asset entities. Returns
 * { total_deals, represents_sellers, represents_buyers, represents_unknown,
 *   markets:[{state, count}], recent_deals:[{name, city, state, role}] }.
 */
export async function buildBrokerDealIntel(entity, entityId, queryFn = opsQuery) {
  const edges = (Array.isArray(entity?.entity_relationships) ? entity.entity_relationships : [])
    .filter(e => e?.relationship_type === 'brokers' && e.to_entity_id);
  if (!edges.length) {
    return { total_deals: 0, represents_sellers: 0, represents_buyers: 0,
             represents_unknown: 0, markets: [], recent_deals: [] };
  }

  let sellers = 0, buyers = 0, unknown = 0;
  for (const e of edges) {
    const r = String(e.metadata?.role || '').toLowerCase();
    if (r === 'listing_broker') sellers++;
    else if (r === 'buyer_broker') buyers++;
    else unknown++;
  }

  // Resolve the linked asset entities (name / city / state) for target markets
  // + a recent-deals sample. Asset entities carry city/state directly.
  const assetIds = Array.from(new Set(edges.map(e => e.to_entity_id)));
  const assetById = {};
  for (let i = 0; i < assetIds.length; i += 200) {
    const inList = assetIds.slice(i, i + 200).map(v => encodeURIComponent(v)).join(',');
    const ar = await queryFn('GET',
      `entities?id=in.(${inList})&select=id,name,city,state`).catch(() => null);
    if (ar && ar.ok && Array.isArray(ar.data)) for (const a of ar.data) assetById[a.id] = a;
  }

  const marketCounts = {};
  const recent = [];
  for (const e of edges) {
    const a = assetById[e.to_entity_id] || {};
    const st = (a.state || '').trim().toUpperCase();
    if (st) marketCounts[st] = (marketCounts[st] || 0) + 1;
    const r = String(e.metadata?.role || '').toLowerCase();
    recent.push({
      name: a.name || null, city: a.city || null, state: st || null,
      role: r === 'listing_broker' ? 'seller' : r === 'buyer_broker' ? 'buyer' : 'unknown',
      at: e.metadata?.extracted_at || e.created_at || null,
    });
  }
  const markets = Object.entries(marketCounts)
    .map(([state, count]) => ({ state, count }))
    .sort((a, b) => b.count - a.count);
  recent.sort((a, b) => String(b.at || '').localeCompare(String(a.at || '')));

  return {
    total_deals: edges.length,
    represents_sellers: sellers,
    represents_buyers: buyers,
    represents_unknown: unknown,
    markets,
    recent_deals: recent.slice(0, 15),
  };
}

/**
 * Compose the full Contact 360 payload for an entity. Returns null when the
 * entity is missing / not in this workspace. Every sub-fetch is best-effort so a
 * missing dia connection / stale table degrades to an empty block, never a 500.
 */
async function buildContact360(entityId, workspaceId) {
  const entRes = await opsQuery('GET',
    `entities?id=eq.${entityId}&workspace_id=eq.${workspaceId}` +
    `&select=*,external_identities(*),entity_relationships!entity_relationships_from_entity_id_fkey(*)`);
  if (!entRes.ok || !entRes.data?.length) return null;
  const entity = entRes.data[0];

  // sf_contact_ids for this entity (salesforce/Contact identities + linked
  // unified_contacts) — the join key for SF activity, engagement, marketing.
  const sfContactIds = new Set();
  for (const x of (entity.external_identities || [])) {
    if (String(x.source_system || '').toLowerCase() === 'salesforce' &&
        String(x.source_type || '').toLowerCase() === 'contact' && x.external_id) {
      sfContactIds.add(String(x.external_id));
    }
  }
  const ucRes = await opsQuery('GET',
    `unified_contacts?entity_id=eq.${entityId}` +
    `&select=unified_id,sf_contact_id,email,engagement_score,last_call_date,last_email_date,` +
    `last_meeting_date,last_activity_date,total_calls,total_emails_sent,total_touches,` +
    `total_transactions,total_volume&limit=25`);
  const ucRows = (ucRes.ok && Array.isArray(ucRes.data)) ? ucRes.data : [];
  for (const u of ucRows) if (u.sf_contact_id) sfContactIds.add(String(u.sf_contact_id));
  const sfIds = Array.from(sfContactIds);
  // dia salesforce_activities.sf_contact_id is overwhelmingly 15-char, but the
  // LCC external_identities are 18-char — a raw match misses every SF activity.
  // Query BOTH forms (15-char base + canonical 18-char) so the fold-in populates.
  const sfIdVariants = new Set();
  for (const id of sfContactIds) {
    const s = String(id).trim();
    if (!s) continue;
    sfIdVariants.add(s);
    const b15 = sf15(s);
    if (b15) { sfIdVariants.add(b15); const c18 = toSf18(b15); if (c18) sfIdVariants.add(c18); }
  }
  const inSf = Array.from(sfIdVariants).map(v => encodeURIComponent(v)).join(',');

  let subjectEmail = entity.email ? String(entity.email).trim().toLowerCase() : null;
  if (!subjectEmail) { const em = ucRows.find(u => u.email)?.email; if (em) subjectEmail = String(em).trim().toLowerCase(); }

  const accountOwner = await resolveAccountOwner(entity, entityId, workspaceId);

  const [portfolio, lccEvents, sfActs, mktRows, emailRel, sfOpenTasks] = await Promise.all([
    fetchEntityPortfolio(entityId, workspaceId).catch(() => ({ rollup: null, properties: [] })),
    opsQuery('GET',
      `activity_events?entity_id=eq.${entityId}&workspace_id=eq.${workspaceId}` +
      `&select=occurred_at,created_at,category,title,body,source_type,users!activity_events_actor_id_fkey(display_name)` +
      `&order=occurred_at.desc&limit=40`).then(r => (r.ok && Array.isArray(r.data)) ? r.data : []).catch(() => []),
    sfIds.length
      ? domainQuery('dialysis', 'GET',
          `salesforce_activities?sf_contact_id=in.(${inSf})` +
          `&select=subject,nm_type,task_subtype,activity_date,nm_notes,status,assigned_to,company_name` +
          `&order=activity_date.desc&limit=40`)
          .then(r => (r.ok && Array.isArray(r.data)) ? r.data : []).catch(() => [])
      : Promise.resolve([]),
    sfIds.length
      ? domainQuery('dialysis', 'GET',
          `marketing_leads?sf_contact_id=in.(${inSf})` +
          `&select=source,activity_type,activity_detail,status,touchpoint_count,assigned_to,lead_date,deal_name` +
          `&order=lead_date.desc.nullslast&limit=20`)
          .then(r => (r.ok && Array.isArray(r.data)) ? r.data : []).catch(() => [])
      : Promise.resolve([]),
    subjectEmail
      ? Promise.all([
          opsQuery('POST', 'rpc/lcc_email_relationship', { p_email: subjectEmail })
            .then(r => Array.isArray(r.data) ? (r.data[0] || null) : null).catch(() => null),
          opsQuery('POST', 'rpc/lcc_email_recent', { p_email: subjectEmail, p_limit: 12 })
            .then(r => Array.isArray(r.data) ? r.data : []).catch(() => []),
        ]).then(([summary, recent]) => ({ email: subjectEmail, summary, recent })).catch(() => null)
      : Promise.resolve(null),
    // Open SF tasks (Not Started / Open / In Progress) — completed tasks dominate
    // the recent-activity window, so a dedicated open-status query is needed. dia
    // salesforce_activities carries no WhatId, so the linked "opportunity" surfaces
    // via the marketing array's deal_name; the account is company_name.
    sfIds.length
      ? domainQuery('dialysis', 'GET',
          `salesforce_activities?sf_contact_id=in.(${inSf})` +
          `&status=in.(${encodeURIComponent('Not Started')},Open,${encodeURIComponent('In Progress')})` +
          `&select=subject,nm_type,task_subtype,activity_date,status,assigned_to,company_name` +
          `&order=activity_date.desc.nullslast&limit=15`)
          .then(r => (r.ok && Array.isArray(r.data)) ? r.data : []).catch(() => [])
      : Promise.resolve([]),
  ]);

  const openTasks = (Array.isArray(sfOpenTasks) ? sfOpenTasks : []).map(t => ({
    subject: t.subject || '(task)',
    status: t.status || null,
    date: t.activity_date || null,
    account: t.company_name || null,
    type: t.task_subtype || t.nm_type || null,
    assigned_to: t.assigned_to || null,
  }));

  // Person-level ownership / linked properties (Contact 360 refinement): a person
  // often owns via their affiliated org, not directly. Resolve (a) direct
  // owns/purchases edges to asset entities and (b) the first affiliated org's BD
  // portfolio. Reuses the true-owner graph + fetchEntityPortfolio (no new engine).
  let ownedProperties = { direct: [], affiliated: null };
  if (entity.entity_type === 'person') {
    const fromEdges = entity.entity_relationships || [];
    const ownEdges = fromEdges.filter(r => (r.relationship_type === 'owns' || r.relationship_type === 'purchases') && r.to_entity_id);
    if (ownEdges.length) {
      const inIds = Array.from(new Set(ownEdges.map(e => e.to_entity_id))).map(v => encodeURIComponent(v)).join(',');
      const ar = await opsQuery('GET', `entities?id=in.(${inIds})&select=id,name,city,state,entity_type,domain`).catch(() => null);
      const byId = {};
      if (ar && ar.ok && Array.isArray(ar.data)) for (const e of ar.data) byId[e.id] = e;
      ownedProperties.direct = ownEdges.map(e => ({ entity_id: e.to_entity_id, rel: e.relationship_type, ...(byId[e.to_entity_id] || {}) }));
    }
    const orgEdge = fromEdges.find(r => (r.relationship_type === 'associated_with' || r.relationship_type === 'works_at') && r.to_entity_id);
    if (orgEdge) {
      const orgRes = await opsQuery('GET', `entities?id=eq.${orgEdge.to_entity_id}&select=id,name,entity_type`).catch(() => null);
      const org = orgRes && orgRes.ok && orgRes.data && orgRes.data[0];
      if (org) {
        const p = await fetchEntityPortfolio(org.id, workspaceId).catch(() => ({ properties: [] }));
        if (p && Array.isArray(p.properties) && p.properties.length) {
          ownedProperties.affiliated = { org_entity_id: org.id, org_name: org.name, rollup: p.rollup || null, properties: p.properties.slice(0, 25) };
        }
      }
    }
  }

  // Developed edges (a distinct ownership signal from owns/former). Rare; resolve
  // the target entity names best-effort so the panel can label them.
  const developedEdges = (entity.entity_relationships || []).filter(r => r.relationship_type === 'developed' && r.to_entity_id);
  let developed = [];
  if (developedEdges.length) {
    const inDev = Array.from(new Set(developedEdges.map(e => e.to_entity_id))).map(v => encodeURIComponent(v)).join(',');
    const devRes = await opsQuery('GET', `entities?id=in.(${inDev})&select=id,name,city,state`).catch(() => null);
    const nameById = {};
    if (devRes && devRes.ok && Array.isArray(devRes.data)) for (const e of devRes.data) nameById[e.id] = e;
    developed = developedEdges.map(e => ({ entity_id: e.to_entity_id, ...(nameById[e.to_entity_id] || {}) }));
  }

  const dealAssignees = sfActs.map(a => ({ name: a.assigned_to, date: a.activity_date })).filter(a => a.name);
  const roe = computeRoe({ accountOwnerName: accountOwner?.name || null, dealAssignees });
  const engagement = buildEngagement(ucRows);
  const timeline = mergeTimeline(lccEvents, sfActs, { limit: 40 });

  // Role drives the layout. Broker mode replaces owner-portfolio with the
  // deal-intelligence block (deals brokered + buyer/seller representation).
  const roleInfo = detectEntityRole(entity);
  const brokerIntel = roleInfo.role === 'broker'
    ? await buildBrokerDealIntel(entity, entityId).catch(() => null)
    : null;

  return {
    subject: {
      entity_id: entityId,
      name: entity.name,
      entity_type: entity.entity_type,
      domain: entity.domain,
      email: subjectEmail,
      sf_contact_ids: sfIds,
      role: roleInfo.role,
    },
    role: roleInfo.role,
    role_flags: roleInfo,
    broker_intel: brokerIntel,
    entity,
    portfolio,
    developed,
    timeline,
    engagement,
    marketing: mktRows,
    open_tasks: openTasks,
    owned_properties: ownedProperties,
    account_owner: accountOwner,
    roe,
    email_relationship: emailRel,
  };
}

/** Pick only fields relevant to the entity type */
function pickEntityFields(type, fields) {
  const picked = {};
  const common = ['description'];
  const person = ['first_name', 'last_name', 'title', 'phone', 'email'];
  const org = ['org_type'];
  const asset = ['address', 'city', 'state', 'zip', 'county', 'latitude', 'longitude', 'asset_type'];

  const allowed = [...common,
    ...(type === 'person' ? person : []),
    ...(type === 'organization' ? org : []),
    ...(type === 'asset' ? asset : [])
  ];

  for (const f of allowed) {
    if (fields[f] !== undefined) picked[f] = fields[f];
  }
  return picked;
}
