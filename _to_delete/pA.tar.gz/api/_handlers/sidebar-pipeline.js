// ============================================================================
// Sidebar Data Pipeline — Unpacks CRE metadata from browser extension captures
// Life Command Center
//
// When the LCC browser extension saves a property from CoStar/LoopNet/CREXi,
// it stores rich metadata JSONB on the entity. This pipeline unpacks that
// metadata into proper relational records:
//
//   1. Contacts  → person/org entities + entity_relationships
//   2. Sales     → activity_events + buyer/seller/lender entities
//   3. Signals   → learning-loop signal
//   4. Domain    → classification (government/dialysis/null) + cross-domain sync
//
// Invocation:
//   - Fire-and-forget after entity creation (entities-handler.js)
//   - On-demand via POST /api/entities?action=process_sidebar_extraction
// ============================================================================

import { ensureEntityLink, normalizeCanonicalName, normalizeAddress, stripStreetSuffix, stripListingStatusPrefix, canonicalIdentitySystem, canonicalEntityDomain, isJunkEntityName, normalizeEmail, isGenericInboxEmail, looksLikeContactPhone } from '../_shared/entity-link.js';
import { isCompetitorBroker } from '../_shared/sf-nm-classifier.js';
import { opsQuery, insertEntityRelationship, fetchWithTimeout } from '../_shared/ops-db.js';
import { uploadArtifactToStorage } from '../_shared/artifact-storage.js';
import { writeSignal, writeListingCreatedSignal } from '../_shared/signals.js';
import { runListingBdPipeline } from '../_shared/listing-bd.js';
import { getCadenceState, entityHasBdSignal } from '../_shared/cadence-engine.js';
import { domainQuery, getDomainCredentials } from '../_shared/domain-db.js';
import { recalculateSaleCapRates } from '../_shared/rent-projection.js';
import { isOwnFirmAddress } from '../_shared/own-firm-addresses.js';
// Round 76co: BEFORE-write priority gate. filterByFieldPriority drops
// fields whose strict-mode rules block this source from updating; the
// existing after-the-fact provenance recorder (recordCoStarFieldsProvenance)
// remains in place so the registry still observes every attempted write,
// but actual UPDATEs are now narrowed to fields the registry approves.
import { filterByFieldPriority, shouldWriteField } from '../_shared/field-priority-guard.js';
import { canonicalizeTenant } from '../_shared/tenant-canonical.js';
// C9 Phase 2 (2026-05-27): validate sale rows through the ingest contract.
// NOTE: ingest-contract.js imports isJunkContactName/isFederalOwnerAntiPattern
// back from THIS module — that's an intentional cycle. It's safe because all
// cross-module bindings are hoisted function declarations resolved at call
// time (runtime), never at module-load time.
import { validateSaleIngest, validateContactIngest } from '../_shared/ingest-contract.js';
// Round 77d (2026-06-02): listing_date derivation moved to a shared module so
// the CoStar sidebar and the OM-intake promoter stay consistent. Re-exported
// here for the existing test/derive-listing-date.test.js import path.
import { deriveListingDate, deriveOnMarketDate } from '../_shared/listing-date.js';
export { deriveListingDate };
import { cleanLenderName } from '../_shared/lender-name.js';

// ============================================================================
// FIELD-LEVEL PROVENANCE RECORDER (Phase 2.2, 2026-04-25)
// ============================================================================
//
// Records every cross-table field write that the CoStar sidebar performs into
// public.field_provenance via lcc_merge_field RPC. Source='costar_sidebar'.
// All entries default to enforce_mode=record_only so this is observation-only
// — actual UPDATEs in this file still happen unchanged.
//
// Why CoStar sidebar specifically: the audit on 2026-04-25 showed CoStar
// captures consistently overwriting OM-derived data because CoStar runs
// after OM intake on most properties. The merge function consults the
// per-field priority registry and (in strict mode, future phase) will
// block costar_sidebar (priority 60-70) from clobbering om_extraction
// (priority 30-50) on fields like rent / cap_rate / tenant.
//
// Coverage in this PR (Phase 2.2.a + 2.2.b, 2026-04-26):
//   - upsertDomainProperty            ← address, tenant, year_built, lot_sf, etc.
//   - upsertDialysisListings          ← initial_price, cap_rate, listing_broker
//   - upsertGovListings               ← same on gov side
//   - upsertDomainLeases              ← rent, expense_structure, lease dates  (2.2.b: per-row)
//   - upsertSidebarContacts           ← name, email, role                       (2.2.b: per-row)
//   - upsertDomainSales               ← sold_price, sale_date, buyer, seller    (2.2.b: per-row)
//   - upsertPublicRecords             ← parcel apn, assessed_value              (2.2.b: per-row)
//
// Coverage still deferred (lower-priority writers — write less-frequently-conflicted data):
//   - upsertDocumentLinks
//   - upsertDialysisDeedRecords / upsertGovernmentDeedRecords
//   - upsertDomainLoans
//   - upsertDomainOwners (recorded + true)
//   - upsertDialysisBrokerLinks / upsertGovBrokers
//
// Phase 2.2.b mechanism: writers accept an optional `provCollect` array and
// push `{table, recordPk, fields, confidence?}` entries on each successful
// INSERT/PATCH. `propagateToDomainDbDirect` then flushes that array through
// `recordCoStarFieldsProvenance` after all writers have run.
//
// CoStar default confidence is 0.6 — lower than OM extraction (0.7) since
// CoStar data is aggregator-quality and sometimes lags actual lease
// modifications by weeks/months.

const COSTAR_DEFAULT_CONFIDENCE = 0.6;

// ============================================================================
// Pre-ingestion guards for sales-party text fields (Round 76ax, 2026-04-28)
// ============================================================================
//
// Defense-in-depth filter that rejects buyer/seller/recorded_owner names that
// are obviously brokerage firms ("Cbre", "Marcus & Millichap", "NAI KLNB"),
// CoStar's "Company 1 X | Company 2 Y" broker-pair format, or test-fixture
// residue (__TEST_BUYER__ etc).
//
// JS-level filter catches at write time so the value never reaches the DB.
// SQL-level BEFORE INSERT trigger (dia_filter_junk_sales_party,
// gov_filter_junk_sales_party) catches values that arrive via other paths.
//
// Why: the 2026-04-28 audit found "Cbre" / "Marcus & Millichap" populating
// gov.sales_transactions.buyer in 7 rows and "__TEST_BUYER__" in 1 dia
// property's recorded_owner_name. Both came from CoStar export columns
// where the broker-firm field bleeds into the buyer column when the deed
// hadn't recorded yet at scrape time.
//
// Round 76ax-D (2026-04-29): extended pre-ingestion guards. New patterns
// added based on bug-class samples surfaced through prior rounds:
//   - section-label residue ("buyer contacts", "seller contacts", "sale
//     notes" — CoStar UI labels concatenated with the actual contact name)
//   - asset-type words misread as party names ("medical office",
//     "industrial", "warehouse")
//   - bare digits / phone-shaped values / dollar amounts / date strings
//   - buyer/seller/owner role words alone
const SALES_PARTY_JUNK_RE = new RegExp(
  '^(' +
    // Brokerage firms (Round 76ax)
    'cbre|marcus & millichap|jll|cushman( & wakefield)?|colliers( international)?|' +
    'nai( [a-z]+)?|stream realty|kw commercial|newmark|capital pacific|' +
    'northmarq|berkadia|matthews real estate|matthews|' +
    'company \\d+ .+|.* \\| company \\d+ .+|' +
    // Test fixtures + sentinel placeholders
    '__test.*__|test_buyer|test_seller|n/a|none|null|tbd|unknown|placeholder|' +
    // Round 76ax-D: section-label residue from CoStar contact panels
    'buyer contacts?|seller contacts?|sale contacts?|sales contacts?|' +
    'sale notes?|sale highlights?|tenant highlights?|' +
    'owner contacts?|recorded owners?|true owners?|' +
    // Round 76ax-D: asset-type words alone
    'medical( office| building)?|office( building)?|retail|industrial|warehouse|' +
    'flex|land|self storage|self-storage|multifamily|hotel|motel|' +
    // Round 76ax-D: role words alone
    'buyer|seller|owner|borrower|lender|grantor|grantee|tenant|landlord' +
  ')$',
  'i'
);

// Round 76ax-D: numeric / phone / currency / date residue. Easier to detect
// with shape than a single big regex.
const PHONE_RE      = /^[+()\d\s\-.x]+$/;          // phone-shaped (only digits + punct)
const CURRENCY_RE   = /^\$?[\d,]+(\.\d+)?\s*[KMB]?$/i; // dollar amount alone
const DATE_RE       = /^(?:\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}|[a-z]{3,9}\s+\d{1,2},?\s+\d{4})$/i;
const ZIP_ONLY_RE   = /^\d{5}(-\d{4})?$/;          // bare zip code
const ROUTE_NUM_RE  = /^(?:rt|route|hwy|highway|us|sr|i)\s*\d+\s*$/i; // bare route number

// Round 76el (2026-04-29): cheap live-state counters for property-linked tables.
// Populated into _pipeline_summary.domain_records_current at the end of every
// pipeline run so consumers have a clear "current DB state" signal rather than
// inferring it from the always-snapshot domain_records (per-run writes only).
// Selects only the property_id column up to PostgREST's default page (1000) and
// counts the returned array — properties with >1000 of any one type are vanishingly
// rare here, and the counter underreporting at that ceiling is acceptable.
async function fetchDomainRecordsCurrent(domain, propertyId) {
  if (!domain || !propertyId) return null;
  if (domain !== 'dialysis' && domain !== 'government') return null;
  const tables = ['available_listings', 'leases', 'sales_transactions', 'ownership_history'];
  const out = {};
  for (const table of tables) {
    try {
      const r = await domainQuery(domain, 'GET',
        `${table}?property_id=eq.${Number(propertyId)}&select=property_id&limit=1000`
      );
      out[table] = r && r.ok && Array.isArray(r.data) ? r.data.length : null;
    } catch {
      out[table] = null;
    }
  }
  return out;
}

function isJunkSalesParty(name) {
  if (name === null || name === undefined) return false;
  const trimmed = String(name).trim();
  if (!trimmed) return false;
  if (SALES_PARTY_JUNK_RE.test(trimmed.toLowerCase())) return true;
  // Round 76ax-D: shape-based junk detectors. Each guards a class the
  // alternation regex can't easily cover without false-positives on real
  // names that happen to contain digits or punctuation.
  if (trimmed.length < 2) return true;            // single char
  if (PHONE_RE.test(trimmed) && /\d{6,}/.test(trimmed)) return true;
  if (CURRENCY_RE.test(trimmed)) return true;
  if (DATE_RE.test(trimmed)) return true;
  if (ZIP_ONLY_RE.test(trimmed)) return true;
  if (ROUTE_NUM_RE.test(trimmed)) return true;
  return false;
}

function cleanSalesPartyValue(name) {
  if (name === null || name === undefined) return null;
  const trimmed = String(name).trim();
  if (!trimmed) return null;
  if (isJunkSalesParty(trimmed)) {
    console.warn(`[isJunkSalesParty] Stripping junk party name: "${trimmed}"`);
    return null;
  }
  return sanitizeOwnerName(trimmed);
}

// R5-DQ-2 (2026-05-20): strip trailing " by <Brokerage>" suffix that
// occasionally leaks in via CoStar comp scrapes — the same regex lives
// in dia.dia_strip_broker_suffix() (migration
// 20260520230000_dia_r5_dq_*). Without this guard, the same Tsoumpas-
// type entity gets stored as N variants ("Foo LLC by Northmarq",
// "Foo LLC by CBRE", "Foo LLC") and the dedup loop fails to merge them.
const BROKER_SUFFIX_RE = new RegExp(
  '\\s+by\\s+(' +
    'northmarq|cbre|jll|colliers( international)?|newmark|' +
    'cushman( & wakefield)?|marcus( & millichap)?|matthews( real estate)?|' +
    'matthews|berkadia|hanley|capital pacific|nai( [a-z]+)?|' +
    'stream realty|kw commercial|trinity|avison( young)?|' +
    'stan johnson( company)?|sjc' +
  ')\\.?\\s*$',
  'i'
);
function sanitizeOwnerName(name) {
  if (name === null || name === undefined) return null;
  const trimmed = String(name).trim();
  if (!trimmed) return null;
  const stripped = trimmed.replace(BROKER_SUFFIX_RE, '').trim();
  if (stripped !== trimmed) {
    console.log(`[sanitizeOwnerName] Stripped broker suffix: "${trimmed}" → "${stripped}"`);
  }
  return stripped || null;
}

// R5-DQ-3 (2026-05-20): OM section-header / table-of-contents tokens
// that leak into property.address when AI extraction grabs a layout
// label instead of the street line. Mirrors the dia_v_data_quality
// 'duplicate_property_address' / OM-junk address audit. Returns true
// when the address must NOT be used to create a property record.
const OM_JUNK_ADDRESS_RE = new RegExp(
  '\\b(' +
    'lease summary|investment (highlights|summary)|financials|rent roll|' +
    'table of contents|offering memorandum|offering|executive summary|' +
    'recent changes|view property video|exclusively listed?|' +
    'property highlights|tenant highlights|sale highlights|' +
    'about the (owner|seller|buyer|building|tenant|property)|' +
    'marketing brochure|broker package|new listing alert' +
  ')\\b',
  'i'
);
function isJunkAddress(addr) {
  if (!addr) return false;
  const s = String(addr).trim();
  if (!s) return false;
  return OM_JUNK_ADDRESS_RE.test(s);
}

// R19 (2026-06-15): link/FK/metadata columns are not contested DATA values —
// they don't need source precedence and shouldn't sit in the provenance ledger
// (~1,200 of the 30d writes were these). Excluding them at the single
// lowest-level recorder covers EVERY provenance path (pushProvenance flush AND
// the direct recordCoStarFieldsProvenance calls) and keeps
// v_field_provenance_unranked meaningful (a non-zero count = a NEW gap, not
// accumulated FK/metadata noise). Returning before the RPC avoids the ledger
// write entirely.
const BOOKKEEPING_PROV_FIELDS = new Set([
  'property_id',  // FK → properties
  'sale_id',      // FK → sales_transactions
  'sale_role',    // link role (buyer/seller)
  'data_source',  // ingest-channel metadata, not a contested value
]);

async function recordFieldProvenance(args) {
  const { workspaceId, targetDatabase, targetTable, recordPk, fieldName,
          value, source, sourceRunId, confidence, recordedBy } = args;
  if (value === undefined || value === null) return null;
  if (!targetTable || !recordPk || !fieldName || !source) return null;
  // R19: skip link/FK/metadata fields — never a source-precedence question.
  if (BOOKKEEPING_PROV_FIELDS.has(fieldName)) return null;
  try {
    const res = await opsQuery('POST', 'rpc/lcc_merge_field', {
      p_workspace_id:     workspaceId || null,
      p_target_database:  targetDatabase,
      p_target_table:     targetTable,
      p_record_pk:        String(recordPk),
      p_field_name:       fieldName,
      p_value:            value,
      p_source:           source,
      p_source_run_id:    sourceRunId || null,
      p_confidence:       confidence ?? null,
      p_recorded_by:      recordedBy || null,
    });
    if (!res.ok) return null;
    const result = Array.isArray(res.data) ? res.data[0] : res.data;

    // Phase 3 (2026-04-26): when enforce_mode is `warn` or `strict` and the
    // merge function decided this write is a `skip` (lower-priority source
    // can't override) or `conflict` (same-priority disagreement), log a
    // warning so it surfaces in Vercel function logs. The actual UPDATE in
    // the writer above already happened — this is the visibility hook the
    // architectural plan calls for before flipping `strict` mode (which
    // would refactor writers to consult priority BEFORE writing).
    if (result && (result.enforce_mode === 'warn' || result.enforce_mode === 'strict')
        && (result.decision === 'skip' || result.decision === 'conflict')) {
      console.warn(
        `[field-provenance:${result.enforce_mode}] ${result.decision} on ` +
        `${targetTable}.${fieldName} record=${recordPk}: ${result.decision_reason} ` +
        `(incoming source=${source} priority=${result.new_priority}, ` +
        `current source=${result.current_source} priority=${result.current_priority})`
      );
    }
    return result;
  } catch (err) {
    // Best-effort — never block a real write on provenance recording.
    return null;
  }
}

/**
 * Record provenance for a batch of CoStar-derived fields on a single row.
 * @param {object} ctx { targetDatabase, targetTable, recordPk, sidebarRunId, workspaceId, actorId }
 * @param {Object<string,*>} fieldValues - { field_name: value }
 * @param {Object<string,number>} [perFieldConfidence]
 */
/**
 * Push a per-row provenance entry into `provCollect` (Phase 2.2.b helper).
 * Safe to call with provCollect=undefined — no-op in that case so writers
 * stay backwards-compatible with non-sidebar callers.
 *
 * Item #5 Phase B (2026-05-17): `writeResult` is an optional 7th
 * parameter. When provided, the push is skipped if the upstream write
 * failed (`writeResult.ok === false`). This prevents recording
 * provenance for a record that doesn't reflect what's in the DB.
 * Backwards compatible: existing call sites continue to work unchanged.
 * Migration pattern for new call sites:
 *
 *     const patchRes = await domainPatch(...);
 *     pushProvenance(provCollect, 'table', id, fields, undefined, undefined, patchRes);
 */
function pushProvenance(provCollect, table, recordPk, fields, confidence, source, writeResult) {
  // Gate: if a writeResult was supplied and it explicitly failed, skip.
  // (undefined/missing writeResult preserves legacy behavior — push goes through.)
  if (writeResult && writeResult.ok === false) return;
  if (!Array.isArray(provCollect) || !table || !recordPk || !fields) return;
  // Drop null/undefined fields up front so the consumer doesn't have to.
  const filtered = {};
  for (const [k, v] of Object.entries(fields)) {
    if (v !== null && v !== undefined && v !== '') filtered[k] = v;
  }
  if (Object.keys(filtered).length === 0) return;
  // Round 76ek.b: optional `source` override lets a single writer (e.g.
  // upsertLoanRecords) tag its rows with a different source than the batch
  // default (costar_sidebar). The flush loop below honors it by passing
  // per-field source mapping to recordCoStarFieldsProvenance.
  provCollect.push({ table, recordPk: String(recordPk), fields: filtered, confidence, source });
}

async function recordCoStarFieldsProvenance(ctx, fieldValues, perFieldConfidence = {}, perFieldSource = {}) {
  if (!ctx?.targetTable || !ctx?.recordPk) return;
  // Round 76af 2026-04-28: respect ctx.sourceTag so RCA captures land as
  // source='rca_sidebar' instead of being mis-tagged as costar_sidebar.
  // Round 76ej.l 2026-05-05: perFieldSource overrides the batch-level
  // sourceTag for individual fields — used to split CREXi prose-mined
  // values (crexi_sidebar_description) from structured-panel values
  // (crexi_sidebar) inside a single capture.
  const batchSource = ctx.sourceTag || 'costar_sidebar';
  const promises = [];
  for (const [fieldName, value] of Object.entries(fieldValues)) {
    if (value === undefined || value === null) continue;
    promises.push(recordFieldProvenance({
      workspaceId:    ctx.workspaceId,
      targetDatabase: ctx.targetDatabase,
      targetTable:    ctx.targetTable,
      recordPk:       ctx.recordPk,
      fieldName,
      value,
      source:         perFieldSource[fieldName] || batchSource,
      sourceRunId:    ctx.sidebarRunId,
      confidence:     perFieldConfidence[fieldName] ?? COSTAR_DEFAULT_CONFIDENCE,
      recordedBy:     ctx.actorId,
    }));
  }
  await Promise.allSettled(promises);
}

// ── Role → relationship_type mapping ────────────────────────────────────────

const ROLE_TO_RELATIONSHIP = {
  owner: 'owns',
  seller: 'sells',
  buyer: 'purchases',
  listing_broker: 'brokers',
  buyer_broker: 'brokers',
  lender: 'finances',
  true_buyer: 'purchases',
  true_seller: 'sells',
  true_buyer_contact: 'associated_with',
  true_seller_contact: 'associated_with',
};

// ── Domain classification keywords ──────────────────────────────────────────
// Word-boundary regexes prevent false positives (e.g. 'ice' matching 'office').
// Short acronyms use \b boundaries; multi-word phrases use plain includes via
// the longer string naturally preventing substring collisions.

export const GOV_TENANT_PATTERNS = [
  /\bgsa\b/,  /\bgeneral services administration\b/,  /\bveterans affairs\b/,
  /\bva\b/,   /\bsocial security\b/,  /\bssa\b/,  /\birs\b/,
  /\binternal revenue\b/,  /\bfbi\b/,  /\bdea\b/,
  /\bice\b/,  /\buscis\b/,  /\bfema\b/,  /\busda\b/,  /\bhud\b/,
  /\bdepartment of\b/,  /\bbureau of\b/,
  /\bfederal\b/,  /\bstate of\b/,  /\bcounty of\b/,  /\bcity of\b/,
  /\busps\b/,  /\bpostal service\b/,
  /\barmy corps\b/,  /\bcoast guard\b/,  /\bcustoms\b/,  /\bcbp\b/,  /\btsa\b/,
  /\bprobation\b/,
  /\bparole\b/,                                    // (TX) Dept of Criminal Justice — Parole Division/Supervision (live capture 2026-06-23, Haltom City 3912 NE 28th St)
  // Round 76ej.r (2026-05-05): expanded keyword set after the Mast One
  // capture (1040 University Boulevard) classified as no_domain. Its
  // tenant prose mentioned "Supreme Court of Virginia" and "Food and
  // Drug Administration" but the prior pattern list missed both. The
  // additions below cover federal agency acronyms / full names CREXi
  // and CoStar pages routinely surface, plus state and federal courts.
  /\bepa\b/,  /\benvironmental protection agency\b/,
  /\bfda\b/,  /\bfood and drug\b/,
  /\bdoj\b/,  /\bdepartment of justice\b/,
  /\bdod\b/,  /\bdepartment of defense\b/,
  /\bnoaa\b/, /\bnational oceanic\b/,
  /\bfaa\b/,  /\bfederal aviation\b/,
  /\bnps\b/,  /\bnational park service\b/,
  /\boffice of\b/,            // "Office of Personnel Mgmt", "Office of the Comptroller"
  /\bsupreme court\b/,        // "Supreme Court of Virginia", "Supreme Court of <state>"
  /\bdistrict court\b/,       // "U.S. District Court", "District Court of Maryland"
  /\bsuperior court\b/,       // "Superior Court of the District of Columbia"
  /\bcourt of\b/,             // catches "Supreme Court of X", "Court of Appeals", etc.
  /\bcourthouse\b/,
  /\battorney general\b/,
  /\bnational guard\b/,
  /\bmilitary\b/,
  // Round 76ej.u (2026-05-05): credit-tag and high-level-government
  // phrasings that show up in CREXi investment-highlights bullets
  // even when the structured Details panel doesn't surface a tenant.
  // Manteo (201 Etheridge / GSA FBI Outer Banks) fell to no_domain
  // because its truncated marketing description was just
  // "United States Government (S&P: AA+) | Option To Extend | …" —
  // none of the prior keywords matched.
  /\bunited states government\b/,
  /\bu\.s\.\s+government\b/,
  /\bus government\b/,
  /\bforest service\b/,           // United States Forest Service (Butte)
  /\bnational forest\b/,
  /\bdivision of\b/,              // "Montana Division of Criminal Investigation"
  /\bfish\s+(?:and\s+|,\s*)?wildlife\b/,  // "U.S. Fish and Wildlife Service" or "Fish, Wildlife & Parks"
  /\bcriminal investigation\b/,
  // Round 76ej.v (2026-05-08): full-agency-name variants. CoStar / CREXi
  // pages frequently spell out federal agencies rather than using the
  // acronym, e.g. "U.S. Citizenship and Immigration Services" (USCIS),
  // "Mine Safety & Health Administration" (MSHA), "Indian Health
  // Services" (IHS). Audit on 2026-05-08 found 20 LCC entities stuck at
  // pipeline_status=failed / no_domain because their tenant prose used
  // these long forms and none of the existing acronym patterns matched.
  // Affected tenants included: U.S. Citizenship and Immigration
  // Services (Louisville KY), Mine Safety & Health Administration
  // (Helena MT), Indian Health Services (701 Market Dr), US Justice
  // Department (402 W Main St), Alabama Law Enforcement Agency
  // (Tuscaloosa), Los Angeles County Health Service.
  /\bcitizenship\b/,                              // USCIS full name
  /\bimmigration\s+(?:services?|and\s+customs|and\s+naturalization)\b/,
  /\bmine\s+safety\b/,                            // MSHA
  /\bindian\s+health\b/,                          // IHS
  /\bjustice\s+department\b/,                     // alt phrasing for DOJ
  /\blaw\s+enforcement\b/,                        // state law enforcement agencies
  /\bhealth\s+service\b/,                         // county/state health services
  /\bdrug\s+enforcement\b/,                       // DEA full name
  /\bemergency\s+management\b/,                   // FEMA / state EM agencies
  /\bcustoms\s+and\s+border\b/,                   // CBP full name
  /\btransportation\s+security\b/,                // TSA full name
  /\bu\.?s\.?\s+attorney(?:'s)?(?:\s+office)?\b/, // "U.S. Attorney's Office", "US Attorney"
  /\bbankruptcy\s+court\b/,                       // "United States Bankruptcy Court"
  /\btax\s+court\b/,                              // U.S. Tax Court
  /\bappeals\s+court\b/,                          // Appeals Courts
  /\bcourt\s+of\s+appeals\b/,                     // Court of Appeals (alt phrasing)
  // ── State / local government vocabulary (Gap Memo 2026-06-23, Topic 1) ──
  // The list above is federal-centric; an audit against a real STATE lease
  // corpus (Texas Facilities Commission "Agency Report", 1,179 leases) found
  // 54% fell to no_domain because state-agency PROGRAM names and abbreviations
  // weren't covered — including the trigger case "TX Health and Human Services"
  // (the single largest tenant, 319 leases). The additions below are anchored
  // and scoped to avoid false-positiving private tenants: NO bare "department"
  // ("department store" is retail), NO bare "workforce" ("workforce housing" is
  // multifamily), NO bare "lottery"/"commission"/"board".
  /\bhuman services\b/,                           // (TX) Health & Human Services Commission — trigger case
  /\b(?:child|children'?s|adult|family)\s+protective(?:\s+services)?\b/,  // CPS/APS — Child/Adult/Children's Protective Services. "services" optional: CoStar truncates the TENANTS panel to "Texas Children's Protective" (live capture 2026-06-25, Lubbock TX 1622 10th St). Anchor (child/adult/family) keeps private "Allied Protective Services" out.
  /\bdept\.?\s+of\b/,                             // "Dept of"/"Dept. of" abbrev (Texas Dept of Criminal Justice)
  /\bcomm(?:ission|\.)?\s+on\b/,                  // "Commission on"/"Comm. on" (Comm. on Environmental Quality)
  /\bcriminal justice\b/,                         // Dept of Criminal Justice
  /\bjuvenile justice\b/,                         // Juvenile Justice Department
  /\bparks?\s+and\s+wildlife\b/,                  // Parks and Wildlife Department
  /\bwildlife\s+(?:department|commission|service|resources?|conservation)\b/,
  /\bcomptroller\b/,                              // Comptroller of Public Accounts / Office of the Comptroller
  /\benvironmental quality\b/,                    // (TX) Commission on Environmental Quality
  /\bconservation\s+(?:board|district|commission)\b/,  // Soil & Water Conservation Board
  /\blottery commission\b/,                       // (TX) Lottery Commission
  /\bland office\b/,                              // General Land Office
  /\brailroad commission\b/,                      // (TX) Railroad Commission (oil & gas regulator)
  /\bworkforce\s+(?:commission|solutions|development\s+board)\b/,  // Workforce Commission/Solutions
  /\beducation agency\b/,                         // (TX) Education Agency
  /\bschool district\b/,                          // independent school districts (municipal gov)
  /\badministrative hearings\b/,                  // State Office of Administrative Hearings
  /\bwater development board\b/,                  // (TX) Water Development Board
  /\balcoholic beverage\s+(?:commission|control)\b/,   // (TX) Alcoholic Beverage Commission
  /\blicensing\s+(?:and|&)\s+regulation\b/,       // Dept of Licensing & Regulation
  /\bsecurities board\b/,                         // State Securities Board
  /\banimal health commission\b/,                // (TX) Animal Health Commission
  /\bboard of\s+\w+\s+examiners\b/,               // Board of Plumbing Examiners (licensing boards)
  /\bpublic safety\b/,                            // Dept of Public Safety (state police), common across states
  /\bstate board\b/,                             // State Board of <profession> (licensing boards)
  /\bhistorical commission\b/,                    // (TX) Historical Commission
];

// Max chars of a sales_history[].sale_notes_raw narrative scanned for the
// domain keyword sets. The CoStar "Sale Notes" narrative is a free-text
// paragraph that frequently LEADS with a long physical-description preamble
// (building count, SF, acreage, vintage) and only names the government/medical
// TENANT in the back half. The original 300-char cap (added to "avoid bloating
// the search string") silently truncated that tenant signal, dropping whole
// captures to no_domain — e.g. the SVEA New Mexico portfolio (40 NM office
// buildings) whose notes put "Government tenants … The State of New Mexico …
// leased to the GSA" past char ~325, so /\bstate of\b/ + /\bgsa\b/ never saw
// it. 4000 chars covers a real sale-notes paragraph end-to-end while still
// bounding pathological input. 2026-06-25.
export const SALE_NOTES_CLASSIFY_MAXLEN = 4000;

const DIALYSIS_TENANT_PATTERNS = [
  /\bfresenius\b/,  /\bfresnius\b/,  // common misspelling from CoStar OCR
  /\bfmc\b/,  /\bdavita\b/,  /\bdialysis\b/,
  /\bdci\b/,  /\bdialysis clinic\b/,
  /\bus renal care\b/,  /\bamerican renal\b/,
  /\bgreenfield renal\b/,  /\binnovative renal\b/,
  /\bsatellite healthcare\b/,  /\bsatellite dialysis\b/,
  /\bnorthwest kidney\b/,  /\bkidney center\b/,
  /\brenal\b/,  /\bnephrology\b/,
];

// ── Mortgage / refinance deed types ─────────────────────────────────────────
// These deed types are financial instruments recorded against the property
// (liens, refinances, releases) and do NOT represent ownership transfers.
// They must be skipped when building sales_transactions and ownership_history.
const MORTGAGE_DEED_TYPES = /^(mortgage|deed\s+of\s+trust|assignment\s+of|subordination|satisfaction|release|reconveyance|lien|easement)/i;

// Lender/bank name pattern — entities with these names are financial institutions,
// NOT property owners. When a deed shows a bank as "buyer" it's typically a
// foreclosure, refinance, or securitization event rather than a real sale.
// Must be filtered from ownership_history to prevent false owner records.
const LENDER_PATTERN = /\b(bank|bancorp|bankcentre|bancshares|credit\s*union|mortgage\s*co|lending|savings\s*(and|&)?\s*loan|financial\s*services|capital\s*one|wells\s*fargo|chase\s*manhattan|citibank|us\s*bank|jpmorgan|bmo\s*harris|pnc\s*bank|td\s*bank|fifth\s*third|truist|regions\s*bank|citizens\s*bank|key\s*bank|comerica|zions|m\s*&?\s*t\s*bank|first\s*national\s*bank|umpqua|glacier|webster\s*bank|midwest\s*bankcentre|fannie\s*mae|freddie\s*mac|fhlmc|fnma|ginnie\s*mae)\b/i;

// ── Sale-price bleed defense (QA1, 2026-06-03) ──────────────────────────────
// CoStar portfolio captures stamp a deal's AGGREGATE sale price onto every
// constituent property as that property's per-property sold_price, with no
// per-property allocation — producing implausible per-property prices that
// pollute Next Best Action value and cap-rate math. The reliable auto-null
// signature: the SAME sold_price on the SAME sale_date already exists on a
// DIFFERENT property_id (a genuine single-property sale never shares an
// identical price+date with another property). Magnitude alone is only a soft
// flag — large government buildings are legitimately expensive — so an
// over-ceiling price is flagged for human review but NOT auto-nulled; only the
// duplicate price+date signature nulls the price. Mirrors the isJunkTenant()
// style: thresholds live here as named constants.
export const SALE_PRICE_BLEED_CEILING = {
  dialysis:    50000000,   // $50M — a single dialysis/medical asset rarely exceeds this
  government: 250000000,   // $250M — DC trophy federal buildings can be legitimately large
};

// Probe sales_transactions for the bleed signature. Returns
// { isAggregate, overCeiling }. isAggregate ⇒ a sale row on ANOTHER property
// already carries this exact sold_price + sale_date (portfolio aggregate bled
// through). overCeiling ⇒ price exceeds the per-domain magnitude soft-guard.
// Note: the FIRST property of a brand-new portfolio capture has no sibling yet,
// so it isn't caught until a second arrives; the SQL backfill handles already-
// landed clusters and a later re-capture of the first property self-heals it.
export async function detectSalePriceBleed(domain, propertyId, soldPrice, datePart) {
  const out = { isAggregate: false, overCeiling: false };
  if (soldPrice == null || !Number.isFinite(soldPrice) || soldPrice <= 0) return out;

  const ceiling = SALE_PRICE_BLEED_CEILING[domain] ?? SALE_PRICE_BLEED_CEILING.government;
  out.overCeiling = soldPrice > ceiling;

  if (!datePart) return out;
  const dup = await domainQuery(domain, 'GET',
    `sales_transactions?sold_price=eq.${soldPrice}` +
    `&sale_date=eq.${encodeURIComponent(datePart)}` +
    `&property_id=neq.${propertyId}` +
    `&select=sale_id&limit=1`
  ).catch(() => ({ ok: false, data: [] }));
  if (dup.ok && Array.isArray(dup.data) && dup.data.length > 0) {
    out.isAggregate = true;
  }
  return out;
}

// R37 (2026-06-17): does this property already carry a LIVE priced sale?
// The sidebar minted a new price-less sales_transactions row on every
// re-capture of a property (the ±14d lookup misses when there is no priced
// row to match), piling up needs_review placeholders — 86% of which sat on a
// property that already had a real, priced live sale. This probe lets the
// writer refuse the placeholder at the source. `transaction_state='live'`
// matches the R36 canonical-metric definition; `sold_price>0` is a real price.
export async function propertyHasLivePricedSale(domain, propertyId) {
  if (propertyId == null) return false;
  const res = await domainQuery(domain, 'GET',
    `sales_transactions?property_id=eq.${propertyId}` +
    `&transaction_state=eq.live&sold_price=gt.0&select=sale_id&limit=1`
  ).catch(() => ({ ok: false, data: [] }));
  return !!(res.ok && Array.isArray(res.data) && res.data.length > 0);
}

// R37 (2026-06-17): decide what an incoming sidebar sale should do BEFORE any
// write. Pure — all I/O is resolved by the caller and passed in as booleans so
// this is unit-testable and the policy lives in one place.
//
//   lookupMatched     — an existing sale row matched (the price±5%/date±14d
//                       window, or the R37 dedup-key window).
//   incomingHasPrice  — the CAPTURE carried a positive sold_price. This is the
//                       raw page price, NOT the written price: a portfolio
//                       aggregate is nulled on write but is still a real,
//                       identified sale, so it is allowed to insert.
//   propertyHasLiveSale — the property already has a 'live' priced sale.
//
// Returns { action: 'patch' | 'insert' | 'skip', reason }.
//   patch  → idempotently refresh the matched row (never a second row).
//   insert → a genuinely new priced transaction.
//   skip   → a price-less page reference is not a closed transaction; never
//            mint a placeholder into the live transactions table. Re-captures
//            are naturally idempotent because nothing is written.
export function classifySaleWrite({ lookupMatched, incomingHasPrice, propertyHasLiveSale }) {
  if (lookupMatched) return { action: 'patch', reason: 'matched_existing' };
  if (incomingHasPrice) return { action: 'insert', reason: 'new_priced_sale' };
  return propertyHasLiveSale
    ? { action: 'skip', reason: 'priceless_redundant_live_sale_exists' }
    : { action: 'skip', reason: 'priceless_no_live_sale' };
}

// ── Helpers ─────────────────────────────────────────────────────────────────

/**
 * Parse a display-format date string into an ISO timestamp.
 * Handles "Mar 27, 2026", "2/28/2019", "2019-03-27", etc.
 */
function parseDate(dateStr) {
  if (!dateStr) return null;
  // Bug Z follow-up #9, 2026-04-27 — guard against numeric inputs.
  // `new Date(2030)` returns "1970-01-01T00:00:02.030Z" (interprets the
  // number as ms-since-epoch), which would silently write a 1970 date to
  // date columns if AI extraction ever returned a year-only field as a
  // number. The AI prompt does say "For dates, return YYYY-MM-DD", but
  // numbers slip through the prompt occasionally — defensive type guard.
  if (typeof dateStr === 'number') return null;
  if (typeof dateStr !== 'string' && !(dateStr instanceof Date)) return null;
  const d = new Date(dateStr);
  return isNaN(d.getTime()) ? null : d.toISOString();
}

/**
 * Parse a display-format currency string to a numeric value.
 * "$3,390,952" → 3390952,  "Not Disclosed" → null
 */
function parseCurrency(val) {
  if (val == null || val === '') return null;
  // Accept numbers directly (OM extraction stores asking_price as a number;
  // sidebar pipeline used to only handle CoStar's stringified "$2,792,962"
  // form, so numeric inputs from OM intake fell through to null and the
  // upsertDialysisListings early-exit guard silently dropped the listing
  // — Bug Z follow-up #8, 2026-04-27).
  if (typeof val === 'number') return Number.isFinite(val) ? val : null;
  if (typeof val !== 'string') return null;
  const cleaned = val.replace(/[$,\s]/g, '');
  const num = parseFloat(cleaned);
  return isNaN(num) ? null : num;
}

/** Parse SF string: "8,750 SF" → 8750 */
function parseSF(val) {
  if (val == null) return null;
  if (typeof val === 'number') return val;
  const cleaned = String(val).replace(/,/g, '').replace(/\s*SF\s*/gi, '').trim();
  const num = parseFloat(cleaned);
  return isNaN(num) ? null : num;
}

/** Parse percentage string: "6.76%" → 6.76, "100%" → 100 */
function parsePercent(val) {
  if (val == null) return null;
  if (typeof val === 'number') return val;
  const cleaned = String(val).replace(/[%\s]/g, '');
  const num = parseFloat(cleaned);
  return isNaN(num) ? null : num;
}

/**
 * Parse cap rate to decimal: "6.7%" → 0.067, "0.067" → 0.067.
 * CoStar sends cap rates as "6.7%" (percentage) but the DB stores decimal.
 * Values > 1 are treated as percentages and divided by 100.
 */
function parseCapRateDecimal(val) {
  const num = parsePercent(val);
  if (num == null) return null;
  const dec = num > 1 ? num / 100 : num;
  // Guard (2026-06-02): clamp to the sane CRE cap-rate band [0.005, 0.30].
  // A leaked adjacent value (occupancy "85" → 0.85, LTV, a price/SF, etc.)
  // would otherwise be stored as a bogus cap rate. Out-of-band → null.
  if (dec < 0.005 || dec > 0.30) return null;
  return dec;
}

/** Parse acres string: "0.54 AC" → 0.54 */
function parseAcres(val) {
  if (val == null) return null;
  if (typeof val === 'number') return val;
  const cleaned = String(val).replace(/,/g, '').replace(/\s*AC\s*/gi, '').trim();
  const num = parseFloat(cleaned);
  return isNaN(num) ? null : num;
}

/** Parse lot SF: handles "2.49 AC" → acres-to-SF conversion, or standard SF parse */
function parseLotSF(rawLotSize) {
  if (!rawLotSize) return null;
  // If value contains AC/Acres, convert to SF
  const acMatch = String(rawLotSize).match(/([\d.]+)\s*AC/i);
  if (acMatch) return Math.round(parseFloat(acMatch[1]) * 43560);
  // Otherwise try standard SF parse
  return parseSF(rawLotSize);
}

/** Parse parking ratio: "2.28/1,000 SF" → 2.28, "32 Spaces (5.82 Spaces per 1,000 SF)" → 5.82 */
function parseParkingRatio(raw) {
  if (!raw) return null;
  // Prefer "X per 1,000 SF" ratio pattern
  const ratioMatch = String(raw).match(/([\d.]+)\s*[Ss]paces?\s+per\s+1[,.]?000/);
  if (ratioMatch) return parseFloat(ratioMatch[1]);
  // Fall back to first number (e.g. "4.35/1,000 SF" from CoStar)
  const perMatch = String(raw).match(/([\d.]+)\s*\/\s*1[,.]?000/);
  if (perMatch) return parseFloat(perMatch[1]);
  // Last resort: any decimal/integer
  const numMatch = String(raw).match(/[\d.]+/);
  return numMatch ? parseFloat(numMatch[0]) : null;
}

/** Safely parse integer: "2019" → 2019, "1" → 1 */
function parseIntSafe(val) {
  if (val == null) return null;
  const num = parseInt(String(val), 10);
  return isNaN(num) ? null : num;
}

/**
 * Parse a 4-digit "year built" value. Returns NULL for blank, non-numeric,
 * zero, or out-of-range inputs so we never persist year_built = 0.
 * Matches the DB CHECK constraint added in
 * sql/20260415_properties_year_built_null_zero.sql (1600–2100).
 */
function parseYearSafe(val) {
  if (val == null) return null;
  const str = String(val).trim();
  if (!str) return null;
  const num = parseInt(str, 10);
  if (isNaN(num) || num <= 0) return null;
  if (num < 1600 || num > 2100) return null;
  return num;
}

/** Parse a latitude or longitude value. Returns a valid numeric coordinate or null. */
function parseCoord(val) {
  if (val == null) return null;
  const num = typeof val === 'number' ? val : parseFloat(String(val).trim());
  if (isNaN(num) || num === 0) return null;
  // Sanity: lat [-90,90], lng [-180,180] — accept anything in the wider range
  if (num < -180 || num > 180) return null;
  return Math.round(num * 1e6) / 1e6; // 6 decimal places (~11cm precision)
}

/**
 * Extract structured data from CoStar "Sale Notes" narrative text.
 * Returns an object of parsed values (empty if nothing matched).
 */
export function parseSaleNotes(text) {
  if (!text) return {};
  const extracted = {};

  // NOI
  const noiMatch = text.match(/(?:net\s+operating\s+income|noi)\s+(?:of\s+)?\$?([\d,]+)/i);
  if (noiMatch) extracted.noi = parseFloat(noiMatch[1].replace(/,/g, ''));

  // Cap rate from notes (cross-reference against structured cap_rate)
  const capMatch = text.match(/(\d+\.?\d*)\s*%\s*cap\s*rate/i) ||
                   text.match(/cap\s*rate.*?(\d+\.?\d*)\s*%/i);
  if (capMatch) extracted.stated_cap_rate = parseFloat(capMatch[1]);

  // Lease term remaining. Capture decimals — CoStar narratives routinely phrase
  // this as "11.5 years remaining on the lease term"; an integer-only capture
  // (the prior /(\d+)/) silently dropped the fractional term.
  const termMatch = text.match(/(\d+(?:\.\d+)?)\s*(?:remaining\s+)?years?\s+remaining/i) ||
                    text.match(/(\d+(?:\.\d+)?)\s+years?\s+remain/i);
  if (termMatch) extracted.years_remaining = parseFloat(termMatch[1]);

  // Building SF (cross-reference against RBA)
  const sfMatch = text.match(/([\d,]+)\s*[-–]?\s*square[-\s]?foot/i);
  if (sfMatch) extracted.building_sf = parseInt(sfMatch[1].replace(/,/g, ''));

  // Acreage
  const acreMatch = text.match(/([\d.]+)\s*acres?/i);
  if (acreMatch) extracted.acreage = parseFloat(acreMatch[1]);

  // Days on market
  const domMatch = text.match(/(?:market\s+for|on\s+the\s+market)\s+(\d+)\s+days/i);
  if (domMatch) extracted.days_on_market = parseInt(domMatch[1]);

  // Asking price
  const askMatch = text.match(/asking\s+price\s+of\s+\$?([\d,]+)/i) ||
                   text.match(/initial\s+asking.*?\$?([\d,]+(?:\.\d+)?)/i);
  if (askMatch) extracted.asking_price = parseFloat(askMatch[1].replace(/,/g, ''));

  // Construction type
  const constMatch = text.match(/(?:features?\s+)?(?:reinforced\s+)?(\w+\s+(?:concrete|construction|frame|masonry))/i);
  if (constMatch) extracted.construction_type = constMatch[1].trim();

  // Verification method
  const verifyMatch = text.match(/verified\s+(?:through|via|by)\s+(.+?)(?:\.|$)/i);
  if (verifyMatch) extracted.verification_method = verifyMatch[1].trim();

  // Lease type (e.g. "15-year triple net", "20 year NNN")
  const leaseMatch = text.match(/(\d+)[-\s]year\s+(triple\s+net|nnn|nn|gross|absolute)/i);
  if (leaseMatch) {
    extracted.lease_term_years = parseInt(leaseMatch[1]);
    extracted.lease_type = leaseMatch[2];
  }

  return extracted;
}

// ── Sale-Notes → gov enrichment helpers (pure; unit-tested) ─────────────────
// Gov has a full cap-rate framework (gov_compute_cap_rate + cap_rate_history)
// and an at-sale firm-term column; rather than dead-end the captured values in
// audit columns, the gov path routes the Sale-Notes NOI into properties.noi
// (the framework's confirmed_sale tier-1 input) and the term into
// sales_transactions.firm_term_years_at_sale (what the cap-by-term views read
// first). These pure helpers hold the selection/guard logic so it can be tested
// without the live DB.

/**
 * Pick the confirmed-sale NOI for a gov sale from the capture. Prefers the
 * structured Income & Expenses NOI (metadata.noi), falls back to the value
 * parsed from the Sale Notes narrative. Returns a positive number or null.
 */
export function pickConfirmedSaleNoi(metadata, saleNotesExtracted) {
  const fromMeta = parseCurrency(metadata?.noi);
  const fromNotes = saleNotesExtracted?.noi;
  if (fromMeta != null && fromMeta > 0) return fromMeta;
  if (typeof fromNotes === 'number' && fromNotes > 0) return fromNotes;
  return null;
}

/**
 * Fill-blank-or-newer guard for writing properties.noi as a confirmed_sale
 * anchor. Never overwrite an NOI already anchored at/after this sale's date —
 * a more-recent / curated NOI wins. Returns true when the write should run.
 */
export function shouldWriteConfirmedSaleNoi(existingRow, saleDate) {
  if (!existingRow || existingRow.noi == null) return true;   // blank — fill it
  const asOf = existingRow.noi_as_of_date || null;
  if (!asOf) return false;                  // has NOI, unknown anchor — don't clobber
  return String(saleDate) > String(asOf);   // only a strictly-newer sale wins
}

/**
 * Map the Sale-Notes "N years remaining" into the gov at-sale firm-term seed.
 * Returns {firm_term_years_at_sale, firm_term_source} or {} when absent/insane.
 */
export function govSaleNotesTermFields(saleNotesExtracted) {
  const yrs = saleNotesExtracted?.years_remaining;
  if (typeof yrs === 'number' && yrs > 0 && yrs <= 25) {
    return { firm_term_years_at_sale: yrs, firm_term_source: 'costar_sale_notes' };
  }
  return {};
}

/**
 * Write a Sale-Notes / Income&Expenses NOI onto gov properties.noi as a
 * confirmed_sale anchor so gov_compute_cap_rate (tier 1, HIGH confidence) can
 * derive this sale's cap rate from a real NOI instead of leaving it
 * market-implied. MUST be called BEFORE the sale upsert: trg_gov_auto_cap_rate_
 * on_sale is a BEFORE trigger that reads properties.noi at insert time, and a
 * sale's cap is point-in-time — a later NOI change refreshes active listings
 * only, never prior sales (gov R44). Fill-blank-or-newer + routed through the
 * priority guard so curated/county NOI is never clobbered. Non-fatal: a failure
 * logs and proceeds (the sale still writes).
 */
async function writeConfirmedSaleNoi(propertyId, noi, saleDate, provCollect) {
  try {
    const cur = await domainQuery('government', 'GET',
      `properties?property_id=eq.${propertyId}&select=noi,noi_as_of_date&limit=1`);
    const row = (cur.ok && Array.isArray(cur.data) && cur.data[0]) ? cur.data[0] : null;
    if (!shouldWriteConfirmedSaleNoi(row, saleDate)) {
      console.log(`[writeConfirmedSaleNoi] skip property=${propertyId} — existing NOI anchored ${row?.noi_as_of_date} >= ${saleDate}`);
      return;
    }
    const fields = { noi, noi_source: 'confirmed_sale', noi_as_of_date: saleDate };
    const allowed = await filterByFieldPriority({
      targetDb: 'gov_db', targetTable: 'gov.properties', recordPk: propertyId,
      source: 'costar_sidebar', confidence: 0.6, fields,
    }).catch(() => fields);
    if (!allowed || allowed.noi == null) {
      console.log(`[writeConfirmedSaleNoi] priority gate blocked NOI write property=${propertyId}`);
      return;
    }
    await domainPatch('government', `properties?property_id=eq.${propertyId}`, allowed, 'writeConfirmedSaleNoi');
    pushProvenance(provCollect, 'properties', propertyId, { noi }, 0.6, 'costar_sidebar');
    console.log(`[writeConfirmedSaleNoi] property=${propertyId} NOI=$${noi} as_of=${saleDate} (confirmed_sale)`);
  } catch (err) {
    console.warn('[writeConfirmedSaleNoi] failed (non-fatal):', err?.message || err);
  }
}

/**
 * Classify a CoStar-style property_type into the LCC building_type taxonomy.
 * CoStar routinely tags dialysis clinics, nephrology offices, and MOBs as a
 * generic "Office" subtype. When the tenant/entity signals are medical, we
 * promote that to a medical taxonomy value so the Property sidebar shows the
 * right label. Returns null when we have nothing confident to assert (caller
 * should leave the DB column untouched).
 */
function classifyBuildingType(metadata, entity, primaryTenant) {
  const rawType = (metadata.property_type || metadata.property_subtype || '').toString().trim();
  const signalText = [
    primaryTenant,
    entity?.name,
    metadata.tenant_name,
    metadata.asset_type,
    metadata.property_subtype,
    metadata.facility_name,
  ].filter(Boolean).join(' ').toLowerCase();

  const isDialysis = /dialysis|fresenius|davita|fmc\b|us\s+renal|american\s+renal|kidney|nephrology|satellite\s+healthcare|dci\b/.test(signalText);
  const isMedical  = isDialysis || /medical|clinic|physician|healthcare|health\s+care|hospital|imaging|surgery|oncology|cardiology/.test(signalText);

  if (isDialysis) return 'Medical Office – Dialysis Clinic';
  if (isMedical && /office/i.test(rawType)) return 'Medical Office';
  if (isMedical) return 'Medical Office';
  return rawType || null;
}

/** Strip null/undefined values from an object (for PATCH — avoids overwriting with null) */
function stripNulls(obj) {
  const result = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v !== null && v !== undefined) result[k] = v;
  }
  return result;
}

/** Strip address prefix from tenant names (e.g. "309 Monroe Ave, Memphis, TN 38103 - SSA, Office of Disability" → "SSA, Office of Disability") */
function cleanTenantValue(raw) {
  if (!raw) return null;
  const dashIdx = raw.indexOf(' - ');
  if (dashIdx > 0) {
    const prefix = raw.substring(0, dashIdx);
    if (/^\d+\s+\w/.test(prefix) || /,\s*[A-Z]{2}\s+\d{5}/.test(prefix)) {
      return raw.substring(dashIdx + 3).trim();
    }
  }
  return raw;
}

// ── Primary tenant priority selectors ──────────────────────────────────────
// Multi-tenant properties list tenants by SF (largest first). For domain
// pipelines the most *relevant* tenant matters more than the largest:
//   - Dialysis: prefer medical/dialysis tenants (e.g. Fresenius over Dollar Tree)
//   - Government: prefer government agency tenants (e.g. SSA over anchor store)

const MEDICAL_TENANT_PRIORITY = /fresenius|davita|dialysis|fmc|dci\b|kidney|renal|nephrology|satellite|healthcare|medical|clinic|health\s+care/i;

const GOV_TENANT_PRIORITY = /\bgsa\b|general services administration|veterans affairs|\bva\b|social security|\bssa\b|\birs\b|internal revenue|\bfbi\b|\bdea\b|\bice\b|\buscis\b|\bfema\b|\busda\b|\bhud\b|department of|bureau of|\bfederal\b|state of|county of|city of|\busps\b|postal service|army corps|coast guard|customs|\bcbp\b|\btsa\b|government|\bepa\b|environmental protection|\bfda\b|food and drug|\bdoj\b|department of justice|\bdod\b|department of defense|\bnoaa\b|national oceanic|\bfaa\b|federal aviation|\bnps\b|national park service|office of|supreme court|district court|superior court|court of|courthouse|attorney general|national guard|\bmilitary\b|united states government|u\.s\.\s+government|us government|forest service|national forest|division of|criminal investigation|fish,?\s+wildlife|citizenship|immigration\s+(?:services?|and\s+customs|and\s+naturalization)|mine\s+safety|indian\s+health|justice\s+department|law\s+enforcement|health\s+service|drug\s+enforcement|emergency\s+management|customs\s+and\s+border|transportation\s+security|u\.?s\.?\s+attorney|bankruptcy\s+court|tax\s+court|appeals\s+court|court\s+of\s+appeals|fish\s+(?:and\s+|,\s*)?wildlife/i;

// Round 76eq (2026-04-29): defensive parser for stringified-array tenant
// values. The OM extractor's AI sometimes returns tenant_name as a JSON-
// stringified array (e.g. '["FMC", "Prine Health"]') instead of a flat
// string. Downstream writers crashed with type errors. This helper
// detects the pattern and returns the first parseable tenant; if the
// value isn't an array string, it's returned unchanged.
function unwrapTenantValue(raw) {
  if (raw == null) return null;
  if (typeof raw !== 'string') return raw;
  const trimmed = raw.trim();
  if (!trimmed.startsWith('[')) return trimmed;
  try {
    const parsed = JSON.parse(trimmed);
    if (Array.isArray(parsed) && parsed.length > 0) {
      const first = parsed.find(v => typeof v === 'string' && v.trim());
      return first ? first.trim() : null;
    }
  } catch {
    // Not valid JSON — fall through to return original
  }
  return trimmed;
}

/**
 * Select the most domain-relevant tenant from metadata.tenants[].
 * Falls back to metadata.tenant_name / metadata.primary_tenant when no
 * tenants array is present, and to tenants[0] when no priority match.
 * Round 76eq: every fallback path goes through unwrapTenantValue() to
 * defend against AI-stringified-array input.
 */
// Round 76fh (2026-05-18): when RCA emits a property with no tenants
// table, the tenant identity often appears only inside sale comment
// strings — "100% occ.;Office - Sub property; Tenants: single tenant
// -- GSA - Immigration & Customs Enforcement; part of 12 property
// portfolio". Extract the dash-delimited tenant from the most recent
// sale's comments so the downstream classifier + agency writer still
// have a name to work with.
function extractTenantFromSalesHistoryComments(salesHistory) {
  if (!Array.isArray(salesHistory) || salesHistory.length === 0) return null;
  // Sort newest-first so the current tenant wins over historical ones.
  const sorted = [...salesHistory].sort((a, b) => {
    const ad = a?.sale_date ? new Date(a.sale_date).getTime() : 0;
    const bd = b?.sale_date ? new Date(b.sale_date).getTime() : 0;
    return bd - ad;
  });
  // RCA's sale comment phrasing:
  //   Tenants: single tenant -- <name>
  //   Tenants: multi-tenant -- <name>; <name>
  //   Tenants: anchor -- <name>
  // Conservative: capture only the first dash-delimited token (up to the
  // next semicolon / period / newline). Strip any "and N others" tail.
  const TENANT_RE = /\bTenants?\s*:\s*(?:single\s+tenant|multi[- ]tenant|anchor|major\s+tenants?|principal\s+tenant)?\s*--\s*([^;.\n]+)/i;
  for (const ev of sorted) {
    if (!ev?.comments) continue;
    const m = String(ev.comments).match(TENANT_RE);
    if (m && m[1]) {
      const name = m[1]
        .replace(/\s+and\s+\d+\s+others?$/i, '')
        .replace(/\s+\(.*?\)$/, '') // strip trailing parenthetical
        .trim();
      if (name.length >= 3 && name.length <= 120) return name;
    }
  }
  return null;
}

function selectPrimaryTenant(metadata, domain) {
  const tenants = metadata.tenants || [];
  if (tenants.length === 0) {
    // Round 76fh: include sales_history.comments fallback before giving up.
    return unwrapTenantValue(metadata.tenant_name)
      || unwrapTenantValue(metadata.primary_tenant)
      || extractTenantFromSalesHistoryComments(metadata.sales_history)
      || null;
  }
  const priorityRe = domain === 'government' ? GOV_TENANT_PRIORITY : MEDICAL_TENANT_PRIORITY;
  const match = tenants.find(t => t.name && priorityRe.test(t.name));
  if (match) return match.name;
  // Fall back to first (largest by SF) tenant
  return tenants[0]?.name
    || unwrapTenantValue(metadata.tenant_name)
    || extractTenantFromSalesHistoryComments(metadata.sales_history)
    || null;
}

// ── Junk tenant filter (module-level; shared by the leases writer and the
// entity bridge) ──────────────────────────────────────────────────────────
// Hoisted from upsertDomainLeases (2026-06-07) so unpackTenant's entity-mint
// boundary runs the exact same junk check the leases writer does — no drift.
// Anchored ^...$ patterns so legitimate tenant names containing these words
// still pass ("First National Bank" ok; bare "Financials" not).
// ── Junk tenant filter (defense-in-depth against scraper bugs) ──────
// Reject tenant names that are obviously demographics, traffic, street names,
// OM table-of-contents headers, NAICS classifications, or CoStar UI
// artifacts rather than real business/tenant names.
//
// Bug M (2026-04-25): the V2 sidebar OM intake on property 29237 wrote
// tenant='Loan' / 'Financials' / 'Changes' / 'Health Care and Social
// Assistance' (NAICS sector 62) into dialysis.leases. The first three
// are OM table-of-contents headers picked up by the CoStar sidebar
// parser; the last is a NAICS classification mislabeled as a tenant.
// Extending the filter here so they're rejected at write time.
const JUNK_TENANT_RE = /^(population|households|median\s+(age|hh\s+income)|daytime\s+employees|traffic(\s+vol)?|last\s+measured|collection\s+street|cross\s+street|distance|store\s+type|made\s+with\s+)/i;
const STREET_NAME_RE = /\b(ave|st|blvd|rd|dr|pkwy|pl|ct|ln|way|hwy)\s*(n|s|e|w|ne|nw|se|sw)?$/i;
const GROWTH_RE = /growth\s+'\d/i;
// OM table-of-contents headers + section labels. Single-word ones first,
// then multi-word phrases. Anchored ^...$ so they only match standalone
// values, not real tenants whose names happen to contain these words
// (e.g. "First National Bank" is fine; bare "Financials" is not).
const OM_SECTION_RE = /^(loan|loans|financial|financials|changes|recent\s+changes|summary|executive\s+summary|investment\s+highlights|property\s+overview|location\s+overview|tenant\s+overview|lease\s+abstract|rent\s+roll|operating\s+statement|comparable\s+sales|sales\s+comps|lease\s+comps|disclaimer|confidentiality|table\s+of\s+contents|appendix|exhibits?)\s*$/i;
// NAICS sector names (Census Bureau industry classifications). These
// sometimes leak through CoStar's "industry" field into tenant.
const NAICS_SECTOR_RE = /^(agriculture|mining|utilities|construction|manufacturing|wholesale\s+trade|retail\s+trade|transportation\s+and\s+warehousing|information|finance\s+and\s+insurance|real\s+estate(\s+and\s+rental(\s+and\s+leasing)?)?|professional(,?\s+scientific(,?\s+and\s+technical\s+services)?)?|management\s+of\s+companies|administrative(\s+and\s+support)?|educational\s+services|health\s+care(\s+and\s+social\s+assistance)?|arts(,?\s+entertainment(,?\s+and\s+recreation)?)?|accommodation(\s+and\s+food\s+services)?|other\s+services|public\s+administration)\s*$/i;
// Bug N (2026-04-25): CoStar's "For Lease at Sale" / "Tenants" panels
// contain availability metric labels ("Smallest Space", "Max Contiguous",
// "Office Avail", "Retail Avail" etc.) that the sidebar parser was
// reading as tenant names with associated SF values. The sidebar wrote
// 22+ junk lease rows across 5 properties on 2026-04-21 → 2026-04-25.
// Add anchored matchers for these CoStar UI artifacts plus tenancy
// metadata lines that show up in the same panel.
const COSTAR_PANEL_RE = /^(smallest\s+space|max\s+contiguous|total\s+(available|vacant)|direct\s+vacant|sublet\s+(available|space)?|vacant\s+space|asking\s+rent|rent|service\s+type|tenancy|owner\s+occupied|for\s+lease(\s+at\s+sale)?|(office|retail|industrial|warehouse|flex|medical|r\&d|land|other)\s+(avail(able)?|sf))\s*$/i;
// Bug V (2026-04-25): cleanup of 947 lease_no_dates rows surfaced
// additional junk-tenant patterns the existing filters missed. These
// are OM/CoStar UI labels and lease-type values being misread as
// tenant names (audit deactivated 69 rows with these).
const COSTAR_EXTRA_JUNK_RE = /^(triple\s+net|double\s+net|absolute\s+net|anchor|anchors|anchored|asking|starting|withheld|analytics|store\s+type|store\s+layout|cam|cam\s+(charges|recovery)|public\s+transportation|commuter\s+rail|highway\s+access|about\s+the\s+(architect|developer|owner)|united\s+states|investment\s+grade|credit\s+rating|net\s+(operating\s+income|leasable\s+area)|gross\s+leasable\s+area|nra|gla|noi|rba|year\s+(built|renovated)|building\s+(class|size|type)|lot\s+size)\s*$/i;
// Round 76ej.l (2026-05-04): more CoStar UI labels and detail-page
// column headers caught landing as tenant rows on the 250 Pettit Ave
// Sale Comp ingestion. Junk values seen in dia.leases for property
// 35836: 'Medical', 'M Ford Mcneil' (Architect-section person), 'Since
// Jun 23, 2009' (CoStar 'On Market Since' date), 'Unkwn' / 'Unknown'
// (CoStar placeholder), and bare CoStar lease-history column headers
// ('Lease Activity', 'Sign Date', 'Leased', 'Use', 'Services',
// 'Rent Type', 'Rent Schedule'). Anchored ^...$ so legitimate names
// containing these words still pass.
const COSTAR_LABEL_JUNK_RE = /^(lease\s+activity|sign\s+date|leased|use|services|rent\s+type|rent\s+schedule|rent\s+steps|rent\s+(adjust(ment)?s?|escalation\s+type)|use\s+type|space\s+(use|type|category)|space\s+id|building\s+id|tenant\s+id|tenant\s+type|status|expense\s+type|expenses?|source|listing\s+(id|type|status)|lease\s+(type|status)|on\s+market\s+(since|date)|on\s+market|days?\s+on\s+market|move[-\s]?in\s+ready|brand|brand\/tenant|tenant\/brand|condition|class|grade|industry)\s*$/i;
// Bare property-use / asset-type categories — landed as 'Medical' /
// 'Office' / 'Retail' on Pettit Ave. NOT a substring match — those
// would false-positive on real medical-tenant names. Anchored.
const COSTAR_USE_CATEGORY_RE = /^(medical|office|retail|industrial|warehouse|flex|mixed[-\s]?use|residential|hospitality|specialty|land|other)\s*$/i;
// Round 76ek.g (2026-05-08): bare industry-role labels CoStar surfaces in
// its tenant-mix column ("Retailer", "Wholesaler", "Operator", etc.). On
// 38275 W Twelve Mile Rd the tenant list dropped a bare "Retailer" row.
// These are role classifications, never tenant names. Anchored — won't
// false-positive on real names like "Joe's Retailer LLC".
const COSTAR_INDUSTRY_ROLE_RE = /^(retailer|wholesaler|distributor|operator|manufacturer|supplier|service\s+provider|landlord|owner\s+occupier|owner[-\s]?occupied)\s*$/i;
// 'Unkwn' / 'Unknown' / 'N/A' / 'TBD' / '--' / dashes — CoStar
// placeholder values for unknown-yet fields.
const COSTAR_PLACEHOLDER_RE = /^(unkwn|unknown|n\/?a|tbd|none|null|-+|—+|\.{2,})\s*$/i;
// Date strings landing as tenants — 'Since Jun 23, 2009',
// 'Mar 26, 2026', 'Q2 2026', 'Jan 2024 - Dec 2028' etc.
const COSTAR_DATE_RE = /^(since\s+)?((?:january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)\s+\d{1,2},?\s+\d{4}|q[1-4]\s+\d{4}|\d{1,2}\/\d{1,2}\/\d{2,4}|\d{4}-\d{1,2}-\d{1,2}|\d{4}\s*-\s*\d{4})\s*$/i;
function isJunkTenant(name) {
  if (!name || name.trim().length < 3) return true;
  const n = name.trim();
  if (JUNK_TENANT_RE.test(n)) return true;
  if (STREET_NAME_RE.test(n)) return true;
  if (GROWTH_RE.test(n)) return true;
  if (OM_SECTION_RE.test(n)) return true;
  if (NAICS_SECTOR_RE.test(n)) return true;
  if (COSTAR_PANEL_RE.test(n)) return true;
  if (COSTAR_EXTRA_JUNK_RE.test(n)) return true;
  // Round 76ej.l: additional CoStar Sale Comp / Lease detail-page
  // labels and CoStar placeholder values + date-string residue.
  if (COSTAR_LABEL_JUNK_RE.test(n)) return true;
  if (COSTAR_USE_CATEGORY_RE.test(n)) return true;
  if (COSTAR_INDUSTRY_ROLE_RE.test(n)) return true;
  if (COSTAR_PLACEHOLDER_RE.test(n)) return true;
  if (COSTAR_DATE_RE.test(n)) return true;
  // City+state+zip residue — "West Chicago, IL 60185" or just "<city>, <state>"
  if (/^[a-z\s]+,\s*[a-z]{2}(\s+\d{5}(-\d{4})?)?$/i.test(n)) return true;
  return false;
}


/**
 * Wrapper around domainQuery for PATCH calls that surfaces silent failures
 * (column mismatches, CHECK constraint violations, etc.) in Vercel logs.
 * Previously, PATCH failures were swallowed — this forced schema issues to
 * only be discovered during audits. Always use this instead of calling
 * domainQuery(..., 'PATCH', ...) directly within this pipeline.
 */
async function domainPatch(domain, path, data, label) {
  // Item #5 (audit/05-provenance-integrity): pass label through to
  // domainQuery so the ingest_write_failures row carries a meaningful
  // tag for triage (e.g. 'upsertDomainSales:dialysis:patch').
  const result = await domainQuery(domain, 'PATCH', path, data, {}, {
    label,
    callerFile: 'sidebar-pipeline.js',
  });
  if (!result.ok) {
    console.error(`[${label}] PATCH failed:`, {
      domain, path,
      status: result.status,
      error: result.data,
      fields: Object.keys(data),
    });
    // Note: the recordWriteFailure call now happens inside domainQuery, so
    // we no longer need to record from here. console.error remains for fast
    // triage in Vercel function logs.
  }
  return result;
}

/**
 * Infer entity_type for a contact entry from the sidebar metadata.
 */
function contactEntityType(contact) {
  if (contact.type === 'entity' || contact.type === 'organization') return 'organization';
  if (contact.type === 'person') return 'person';
  // Heuristic: if name looks like a company (all-caps, contains LLC/Inc, etc.)
  const name = (contact.name || '').trim();
  if (/\b(LLC|INC|CORP|LTD|LP|LLP|PARTNERS|GROUP|ASSOCIATES|ADVISORS)\b/i.test(name)) {
    return 'organization';
  }
  return 'person';
}

/**
 * Build seed fields for ensureEntityLink based on contact data.
 */
export function contactSeedFields(contact, entityType) {
  const seed = { name: contact.name };

  if (entityType === 'person') {
    const parts = (contact.name || '').trim().split(/\s+/);
    if (parts.length >= 2) {
      seed.first_name = parts[0];
      seed.last_name = parts.slice(1).join(' ');
    }
    if (contact.email) seed.email = contact.email;
    if (contact.phones?.length) seed.phone = contact.phones[0];
    if (contact.title) seed.title = contact.title;
  }

  if (entityType === 'organization') {
    if (contact.ownership_type) seed.org_type = 'owner';
    // ORE Phase 1 Unit B: carry the org's phone/email so an owner ORGANIZATION
    // entity is reachable (the entity layer now retains them — see
    // pickSeedFields). The entity layer validates the value shape; here we only
    // forward what CoStar captured. Previously dropped (person-only), so owner
    // org contact details we already had never landed.
    if (contact.email) seed.email = contact.email;
    if (contact.phones?.length) seed.phone = contact.phones[0];
  }

  if (contact.address) {
    // Try to parse "6436 Penn Ave S, Minneapolis, MN 55423"
    const addrParts = contact.address.split(',').map(s => s.trim());
    seed.address = addrParts[0] || contact.address;
    if (addrParts.length >= 2) seed.city = addrParts[1];
    if (addrParts.length >= 3) {
      const stateZip = addrParts[2].split(/\s+/);
      if (stateZip[0]) seed.state = stateZip[0];
      if (stateZip[1]) seed.zip = stateZip[1];
    }
  }

  return seed;
}

/**
 * Classify domain based on property metadata.
 * Checks DIALYSIS first (more specific) to avoid misclassifying dialysis
 * properties with "Medical Office" subtypes as government.
 * Returns 'dialysis', 'government', or null.
 */
// Round 76t (2026-04-27): junk values the classifier should drop before
// building searchText. Older extension versions captured 'Show' (CoStar
// expand button) and compound metadata strings ('Tenancy: Summary - ...')
// as tenant names, and they overwrite cleaner values on subsequent saves.
const CLASSIFIER_TENANT_JUNK_RE = /^(show|hide|expand|collapse|view|see\s+(all|more|details)|my\s+data|shared\s+data|loan|loans|financial|financials|changes|recent\s+changes|sale\s+highlights|investment\s+highlights|property\s+highlights|key\s+highlights|table\s+of\s+contents|appendix|exhibits?|executive\s+summary|name|industry|sector|tenant|tenancy|owner\s+occupied|est\.?\s*rent|directory|stacking\s+plan|public\s+record|building|land|market|sources|md\/dds|md\/dental|medical\/office|office\/medical|retail|industrial|office|medical|warehouse|flex|sale\s+notes|owner\s+address|recorded\s+owner|tax\s+amount|moving\s+(in|out))\s*$/i;
const CLASSIFIER_COMPOUND_RE = /(\u00b7|\u2022)|(:[^,\n]*\b(\d|\$)[^,\n]*\/(sf|fs|mg|ig|nnn|gross|net)\b)/i;
function dropTenantJunk(val) {
  if (!val) return val;
  const s = String(val).trim();
  if (CLASSIFIER_TENANT_JUNK_RE.test(s) || CLASSIFIER_COMPOUND_RE.test(s)) return null;
  return val;
}

export function classifyDomain(metadata, entityFields) {
  const textParts = [
    dropTenantJunk(metadata.tenant_name),
    dropTenantJunk(metadata.primary_tenant),
    metadata.building_name,
    entityFields.description,
    entityFields.name,
    // Also read entity.tenant column. The propagation step backfills it
    // from the cleaned tenant value, so even if metadata.tenant_name is
    // junky ("Show" / "Tenancy: Summary - ..."), entity.tenant has
    // the real tenant. Round 76r 2026-04-27.
    dropTenantJunk(entityFields.tenant),
    metadata.asset_type,
    metadata.property_type,
    metadata.property_subtype,
    metadata.occupancy_details,
    // Sale notes narrative often names the tenant when structured fields don't
    metadata.sale_notes_raw,
    // Industrial Sale Comp pages place tenant text in a summary/tenancy
    // block rather than a labeled Tenant field; include those too.
    metadata.tenants_raw,
    metadata.tenancy_block,
    metadata.investment_highlights,
    // CREXi govt-leased listings often surface the tenant only in the
    // marketing prose (headline + description). Without these the
    // classifier sees only generic labels like "Office, Special
    // Purpose" and drops to no_domain even when the page text is
    // saturated with "GSA", "Federal", "VA Clinic" etc.
    metadata.marketing_headline,
    metadata.marketing_description,
  ];

  // Include tenant names from tenants[] array (filtered through dropTenantJunk
  // so a stale extension that captured 'Show' or 'Tenancy: Summary - ...' as
  // an entry can't poison the classifier — Round 76t 2026-04-27).
  if (Array.isArray(metadata.tenants)) {
    for (const t of metadata.tenants) {
      const cleaned = dropTenantJunk(t.name);
      if (cleaned) textParts.push(cleaned);
    }
  }

  // Include contact names from contacts[] array
  if (Array.isArray(metadata.contacts)) {
    for (const c of metadata.contacts) {
      if (c.name) textParts.push(c.name);
    }
  }

  // Include extracted PDF text (OM brochures often identify the tenant)
  if (Array.isArray(metadata.pdf_extracted_texts)) {
    for (const pdf of metadata.pdf_extracted_texts) {
      if (pdf.text) {
        // Only take first 500 chars to avoid bloating the search string
        // with map legends and legal boilerplate — tenant names appear early
        textParts.push(pdf.text.substring(0, 500));
      }
    }
  }

  // Round 76fh (2026-05-18): include sales_history[].comments and entities_text.
  // RCA Property Details pages don't always render a Tenants section; when
  // they don't, the tenant name often only appears inside sale comments like
  // "100% occ.;Office - Sub property; Tenants: single tenant -- GSA -
  // Immigration & Customs Enforcement; part of 12 property portfolio". The
  // 1530 Commonwealth Business Dr / GSA-ICE capture (LCC entity adb366b9)
  // classified as no_domain because the searchText omitted these comments
  // even though every one of the 4 sales_history entries had the GSA tag.
  // Same defense for entities_text — lender/buyer narratives sometimes carry
  // government affiliations the structured field set misses.
  if (Array.isArray(metadata.sales_history)) {
    for (const ev of metadata.sales_history) {
      if (ev?.comments) textParts.push(String(ev.comments).substring(0, 300));
      if (ev?.entities_text) textParts.push(String(ev.entities_text).substring(0, 200));
      // On a CoStar Sale Comps page (/Comp/NNN/), the parser routes the "Sale
      // Notes" narrative INTO the matching sale record (sales_history[].
      // sale_notes_raw), NOT top-level metadata.sale_notes_raw. For a
      // government-LEASED comp sold private→private (3411 Horal, San Antonio:
      // buyer Foresight Asset Mgmt, seller a private individual), the ONLY gov
      // signal is the tenant named in those Sale Notes ("...fully leased by the
      // Texas Health And Human Services Commission"). Without this read the
      // capture classified no_domain even though the tenant matches a State
      // agency pattern. 2026-06-23.
      // 2026-06-25: scan the FULL notes (up to SALE_NOTES_CLASSIFY_MAXLEN) —
      // the prior 300-char cap dropped portfolio captures whose gov tenant
      // signal sits behind a long physical-description preamble.
      if (ev?.sale_notes_raw) textParts.push(String(ev.sale_notes_raw).substring(0, SALE_NOTES_CLASSIFY_MAXLEN));
    }
  }

  const searchText = textParts.filter(Boolean).join(' ').toLowerCase();

  // ── Diagnostic: log classifier inputs for debugging ──
  const hasSaleNotes = !!metadata.sale_notes_raw;
  const hasPdfTexts = Array.isArray(metadata.pdf_extracted_texts) && metadata.pdf_extracted_texts.length > 0;
  const textLen = searchText.length;
  const snippet = searchText.substring(0, 200);
  console.log(`[classifyDomain] searchText length=${textLen}, hasSaleNotes=${hasSaleNotes}, hasPdfTexts=${hasPdfTexts}, snippet="${snippet}"`);

  // Check DIALYSIS FIRST — more specific domain, prevents misclassification
  for (const rx of DIALYSIS_TENANT_PATTERNS) {
    if (rx.test(searchText)) {
      console.log(`[classifyDomain] → dialysis (matched ${rx})`);
      return 'dialysis';
    }
  }

  // Then check government
  if (entityFields.asset_type === 'government_leased') {
    console.log(`[classifyDomain] → government (asset_type=government_leased)`);
    return 'government';
  }
  for (const rx of GOV_TENANT_PATTERNS) {
    if (rx.test(searchText)) {
      console.log(`[classifyDomain] → government (matched ${rx})`);
      return 'government';
    }
  }

  console.log(`[classifyDomain] → null (no pattern matched)`);
  return null;
}

// Round 76ej.x (2026-05-05): return ALL applicable domains for a
// capture, not just the primary one. Multi-tenant buildings like
// Centralia Medical Offices (1815 Cooks Hill Rd) have DaVita
// (dialysis) AND Social Security Administration (government) under
// the same roof — both domains' tooling needs the property to
// surface in their respective DBs. classifyDomain still returns the
// PRIMARY (first match, dialysis-preferred) for backward-compat
// callers that need a single value (e.g. entity.domain column).
function classifyAllApplicableDomains(metadata, entityFields) {
  const all = [];
  // Reuse the same searchText assembly as classifyDomain.
  const textParts = [
    dropTenantJunk(metadata.tenant_name),
    dropTenantJunk(metadata.primary_tenant),
    metadata.building_name,
    entityFields.description,
    entityFields.name,
    dropTenantJunk(entityFields.tenant),
    metadata.asset_type,
    metadata.property_type,
    metadata.property_subtype,
    metadata.occupancy_details,
    metadata.sale_notes_raw,
    metadata.tenants_raw,
    metadata.tenancy_block,
    metadata.investment_highlights,
    metadata.marketing_headline,
    metadata.marketing_description,
  ];
  if (Array.isArray(metadata.tenants)) {
    for (const t of metadata.tenants) {
      const cleaned = dropTenantJunk(t && t.name);
      if (cleaned) textParts.push(cleaned);
    }
  }
  if (Array.isArray(metadata.contacts)) {
    for (const c of metadata.contacts) if (c && c.name) textParts.push(c.name);
  }
  if (Array.isArray(metadata.pdf_extracted_texts)) {
    for (const pdf of metadata.pdf_extracted_texts) {
      if (pdf && pdf.text) textParts.push(pdf.text.substring(0, 500));
    }
  }
  // Round 76fh: same sales_history sweep as classifyDomain so multi-domain
  // detection on RCA captures without a tenants table behaves identically.
  if (Array.isArray(metadata.sales_history)) {
    for (const ev of metadata.sales_history) {
      if (ev?.comments) textParts.push(String(ev.comments).substring(0, 300));
      if (ev?.entities_text) textParts.push(String(ev.entities_text).substring(0, 200));
      // On a CoStar Sale Comps page (/Comp/NNN/), the parser routes the "Sale
      // Notes" narrative INTO the matching sale record (sales_history[].
      // sale_notes_raw), NOT top-level metadata.sale_notes_raw. For a
      // government-LEASED comp sold private→private (3411 Horal, San Antonio:
      // buyer Foresight Asset Mgmt, seller a private individual), the ONLY gov
      // signal is the tenant named in those Sale Notes ("...fully leased by the
      // Texas Health And Human Services Commission"). Without this read the
      // capture classified no_domain even though the tenant matches a State
      // agency pattern. 2026-06-23.
      if (ev?.sale_notes_raw) textParts.push(String(ev.sale_notes_raw).substring(0, SALE_NOTES_CLASSIFY_MAXLEN));
    }
  }
  const searchText = textParts.filter(Boolean).join(' ').toLowerCase();

  // Dialysis first (more specific) — same priority as classifyDomain.
  if (DIALYSIS_TENANT_PATTERNS.some((rx) => rx.test(searchText))) all.push('dialysis');
  // Government — either explicit asset_type tag OR keyword match.
  if (entityFields.asset_type === 'government_leased') {
    if (!all.includes('government')) all.push('government');
  } else if (GOV_TENANT_PATTERNS.some((rx) => rx.test(searchText))) {
    if (!all.includes('government')) all.push('government');
  }
  return all;
}

// Per-domain tenant filter — used when the same metadata.tenants[]
// is propagated to multiple domain DBs and each domain should only
// see its own-flavored tenants.
//   - government domain: include only tenants matching GOV_TENANT_PATTERNS
//   - dialysis domain:   exclude tenants that match GOV_TENANT_PATTERNS
//                        UNLESS they ALSO match DIALYSIS_TENANT_PATTERNS
//                        (a hybrid name like "VA Dialysis Center" stays
//                        in dia.leases). Non-gov, non-dialysis tenants
//                        (typical healthcare names like "Assured Home
//                        Health") stay in dia by default.
function isTenantForDomain(tenantName, domain) {
  if (!tenantName || typeof tenantName !== 'string') return false;
  const name = tenantName.toLowerCase();
  const isGov = GOV_TENANT_PATTERNS.some((rx) => rx.test(name));
  const isDia = DIALYSIS_TENANT_PATTERNS.some((rx) => rx.test(name));
  if (domain === 'government') return isGov;
  if (domain === 'dialysis') return !(isGov && !isDia);
  return true;
}

// ── Round 76cr-Phase 2: forward-routing mismatch detector ──────────────
// Flag captures where the classifier picks one domain but the PRIMARY
// tenant slot screams the other. Two real cases motivated this:
//   (a) Pure VA Medical Center (no dialysis) classified to 'dialysis'
//       because its name contains "Medical" and CoStar's metadata had
//       residual dialysis text from a sub-tenant. Phase 1 found 2 such
//       records already in the dia DB and flagged them via
//       domain_classification_flag='misclassified_gov'. Phase 2 prevents
//       new ones from landing wrong.
//   (b) Hybrid (DaVita primary + VA secondary) — these stay as dialysis;
//       the primary-tenant check is what keeps this from false-firing.
function detectDomainMismatch(domain, metadata, entityFields) {
  const primaryTenantParts = [
    dropTenantJunk(metadata && metadata.tenant_name),
    dropTenantJunk(metadata && metadata.primary_tenant),
    dropTenantJunk(entityFields && entityFields.tenant),
    metadata && metadata.building_name,
  ];
  // Also pull the first entry of the tenants array — that's the primary
  // tenant on multi-tenant captures.
  if (metadata && Array.isArray(metadata.tenants) && metadata.tenants.length) {
    primaryTenantParts.push(dropTenantJunk(metadata.tenants[0] && metadata.tenants[0].name));
  }
  const primaryText = primaryTenantParts.filter(Boolean).join(' ').toLowerCase();
  if (!primaryText) return null;

  // domain='dialysis' but primary tenant is government → likely misroute
  if (domain === 'dialysis') {
    for (const rx of GOV_TENANT_PATTERNS) {
      if (rx.test(primaryText)) {
        // Suppress when the dialysis signal is ALSO in the primary tenant
        // (hybrid like "DaVita Dialysis | VA Clinic"). Only warn when no
        // dialysis pattern matches the primary slot — that's the "pure
        // government" case.
        const hasDialysisSignal = DIALYSIS_TENANT_PATTERNS.some(d => d.test(primaryText));
        if (hasDialysisSignal) return null;
        return {
          warning: 'primary_tenant_looks_government',
          suggested_domain: 'government',
          matched: String(rx),
          primary_tenant_text: primaryText.substring(0, 120),
        };
      }
    }
  }

  // domain='government' but primary tenant is a dialysis operator → misroute
  if (domain === 'government') {
    for (const rx of DIALYSIS_TENANT_PATTERNS) {
      if (rx.test(primaryText)) {
        return {
          warning: 'primary_tenant_looks_dialysis',
          suggested_domain: 'dialysis',
          matched: String(rx),
          primary_tenant_text: primaryText.substring(0, 120),
        };
      }
    }
  }
  return null;
}

// Expose last classifier diagnostic for pipeline summary (debugging)
let _lastClassifierDiag = null;

// Round 76fg (2026-05-15): capture the actual PostgREST error response when
// upsertDomainProperty's POST/PATCH fails. Without this, every gov/dia
// property_upsert_failed surfaces to the sidebar UI as just the reason string
// — Vercel function logs hold the body but the user has no visibility, and
// repeat captures of the same property keep failing for the same opaque
// reason. Surfacing the error response in entity.metadata._pipeline_last_
// error_detail (and the sidebar status line) makes the fix path
// self-service. Populated inside upsertDomainProperty; read once by
// propagateToDomainDbDirect into the propagation result, then reset on the
// next call.
let _lastDomainPropertyError = null;
function classifyDomainWithDiag(metadata, entityFields) {
  const result = classifyDomain(metadata, entityFields);
  // Build diagnostic snapshot
  const textParts = [
    metadata.tenant_name, metadata.primary_tenant, metadata.building_name,
    entityFields.tenant,
    entityFields.description, entityFields.name, metadata.asset_type,
    metadata.property_type, metadata.property_subtype, metadata.occupancy_details,
    metadata.sale_notes_raw, metadata.tenants_raw, metadata.tenancy_block,
    metadata.investment_highlights,
    metadata.marketing_headline, metadata.marketing_description,
  ];
  if (Array.isArray(metadata.tenants)) for (const t of metadata.tenants) { if (t.name) textParts.push(t.name); }
  if (Array.isArray(metadata.contacts)) for (const c of metadata.contacts) { if (c.name) textParts.push(c.name); }
  if (Array.isArray(metadata.pdf_extracted_texts)) for (const pdf of metadata.pdf_extracted_texts) { if (pdf.text) textParts.push(pdf.text.substring(0, 500)); }
  const searchText = textParts.filter(Boolean).join(' ').toLowerCase();

  // Find which pattern matched
  let matchedPattern = null;
  for (const rx of DIALYSIS_TENANT_PATTERNS) { if (rx.test(searchText)) { matchedPattern = `DIA:${rx}`; break; } }
  if (!matchedPattern && entityFields.asset_type === 'government_leased') matchedPattern = 'asset_type=government_leased';
  if (!matchedPattern) { for (const rx of GOV_TENANT_PATTERNS) { if (rx.test(searchText)) { matchedPattern = `GOV:${rx}`; break; } } }

  // Round 76cr-Phase 2: detect and log primary-tenant/domain mismatches.
  // Surfaced into the response via _lastClassifierDiag.mismatchWarning so
  // the sidebar UI can show a "this looks like a government property —
  // route to gov DB instead?" banner.
  const mismatch = detectDomainMismatch(result, metadata, entityFields);
  if (mismatch) {
    console.warn(`[classifyDomain] DOMAIN MISMATCH WARNING: classified=${result}, suggested=${mismatch.suggested_domain}, matched=${mismatch.matched}, primary="${mismatch.primary_tenant_text}"`);
  }

  _lastClassifierDiag = {
    result,
    matchedPattern: matchedPattern || 'none',
    searchTextLen: searchText.length,
    searchTextFirst200: searchText.substring(0, 200),
    hasSaleNotes: !!metadata.sale_notes_raw,
    hasPdfTexts: Array.isArray(metadata.pdf_extracted_texts) && metadata.pdf_extracted_texts.length > 0,
    fieldSources: textParts.filter(Boolean).map((v, i) => `[${i}]${String(v).substring(0, 40)}`),
    mismatchWarning: mismatch,
  };
  return result;
}

// ── Step 1: Unpack Contacts ─────────────────────────────────────────────────

async function unpackContacts(propertyEntityId, metadata, workspaceId, userId, domain) {
  const contacts = metadata.contacts;
  if (!Array.isArray(contacts) || contacts.length === 0) return 0;

  let created = 0;
  const source = metadata.source || 'costar';
  const extractedAt = metadata.extracted_at || new Date().toISOString();

  for (const contact of contacts) {
    if (!contact.name) continue;

    const entityType = contactEntityType(contact);
    const seedFields = contactSeedFields(contact, entityType);

    // Use ensureEntityLink to deduplicate
    const link = await ensureEntityLink({
      workspaceId,
      userId,
      sourceSystem: source,
      sourceType: entityType === 'person' ? 'contact' : 'company',
      externalId: normalizeCanonicalName(contact.name),
      domain,
      seedFields,
      metadata: {
        sidebar_source: source,
        original_contact: contact,
      },
    });

    if (!link.ok) {
      console.error('[Sidebar pipeline] Failed to create contact entity:', contact.name, link.error);
      continue;
    }

    if (link.createdEntity) created++;

    // ── Item #7 (audit/07-contact-cadence-seed): seed cadence + inbox
    // triage for newly-created person entities so each captured broker
    // is immediately visible in the triage flow instead of dead-ending
    // at a row write. Closes D-2 and the contact-side of D-6.
    //
    // Gating:
    //   • Only on link.createdEntity === true (skip pre-existing entities;
    //     they already have whatever cadence state they need).
    //   • Only for person entities — companies don't get cadence rows.
    //   • Only when we have a workspaceId + userId (sidebar paths that
    //     skip the bridge gate land here with both unset; bail silently).
    //
    // Both calls wrapped in try/catch: a failure here MUST NOT roll back
    // the upstream unpackContacts work. Stragglers can be re-seeded later
    // via a backfill if needed.
    if (link.createdEntity && entityType === 'person' && workspaceId && link.entityId) {
      try {
        // 1. R63 Unit 1 — only a real BD target gets an auto-cadence. A bare
        //    captured contact (the typical CoStar broker/owner contact) carries
        //    no Salesforce identity, value, open opp, or SF activity, so it is
        //    NOT auto-seeded into a prospecting cadence — that is exactly the
        //    capture noise that drowned the cadence dashboard (300 overdue
        //    captures vs Scott's real ~16 relationships). It still lands in the
        //    inbox triage below; Scott promotes it to a real target (open an
        //    opp / SF-link / portfolio value), and a cadence then grows from the
        //    real outreach he logs (the sf-activity grow path).
        let cadenceRes = null;
        if (await entityHasBdSignal(link.entityId)) {
          // Initialize touchpoint_cadence at touch 0 (idempotent — an existing
          // row for this entity_id is returned unchanged).
          cadenceRes = await getCadenceState(
            { entity_id: link.entityId },
            { domain }
          );
          if (!cadenceRes?.ok) {
            console.warn('[contact-cadence-seed] getCadenceState non-ok for',
              link.entityId, '-', cadenceRes?.error || 'unknown');
          }
        }
        // 2. POST inbox_items so the new contact lands in Scott's triage queue
        //    regardless of cadence — the contact stays in the inbox until it is
        //    promoted to a real target (when it earns its cadence above).
        {
          const role = contact.role || 'unknown';
          const title = `New contact: ${contact.name}${role && role !== 'unknown' ? ' (' + role + ')' : ''}`;
          const bodyLines = [
            `Captured from ${source} on ${new Date(extractedAt).toLocaleDateString()}.`,
            `Role: ${role}`,
          ];
          if (contact.company) bodyLines.push(`Firm: ${contact.company}`);
          if (contact.email)   bodyLines.push(`Email: ${contact.email}`);
          if (contact.phones?.length) bodyLines.push(`Phone: ${contact.phones[0]}`);
          if (contact.title)   bodyLines.push(`Title: ${contact.title}`);
          bodyLines.push('');
          bodyLines.push('Triage to qualify, set priority tier, and route to the right cadence template.');

          const inboxRes = await opsQuery('POST', 'inbox_items', {
            workspace_id:   workspaceId,
            source_user_id: userId,
            visibility:     'private',
            title,
            body:           bodyLines.join('\n'),
            source_type:    'new_contact_qualify',
            status:         'new',
            priority:       'normal',
            entity_id:      link.entityId,
            domain:         domain || null,
            metadata: {
              role,
              source:           `${source}_sidebar`,
              contact_name:     contact.name,
              contact_email:    contact.email || null,
              contact_phone:    contact.phones?.[0] || contact.phone || null,
              contact_company:  contact.company || null,
              contact_title:    contact.title || null,
              cadence_id:       cadenceRes?.cadence?.id || null,
              extracted_at:     extractedAt,
              property_entity_id: propertyEntityId || null,
            },
          }, { 'Prefer': 'return=minimal' });
          if (!inboxRes?.ok) {
            console.warn('[contact-cadence-seed] inbox_items POST failed for',
              link.entityId, '-', inboxRes?.status, inboxRes?.data);
          } else {
            console.log(`[contact-cadence-seed] ${cadenceRes ? 'seeded cadence + ' : 'no-signal (no cadence), '}inbox triage for new contact ${contact.name} (entity ${link.entityId}, domain ${domain})`);
          }
        }
      } catch (err) {
        // Never propagate — cadence/inbox seeding is best-effort follow-up
        // to the unpackContacts core work.
        console.error('[contact-cadence-seed] failed (non-fatal):', err?.message || err);
      }
    }

    // Store additional contact details via PATCH if we have enrichment data
    if (entityType === 'person' && (contact.email || contact.phones?.length || contact.title)) {
      const updates = {};
      if (contact.email && !link.entity.email) updates.email = contact.email;
      if (contact.phones?.length && !link.entity.phone) updates.phone = contact.phones[0];
      if (contact.title && !link.entity.title) updates.title = contact.title;
      if (contact.company) {
        updates.metadata = {
          ...(link.entity.metadata || {}),
          company: contact.company,
          phones: contact.phones || [],
          website: contact.website || null,
        };
      }
      if (Object.keys(updates).length > 0) {
        updates.updated_at = new Date().toISOString();
        await opsQuery('PATCH',
          `entities?id=eq.${link.entityId}&workspace_id=eq.${workspaceId}`,
          updates
        );
      }
    }

    // Create entity_relationship linking contact → property
    const role = contact.role || 'unknown';
    const relationshipType = ROLE_TO_RELATIONSHIP[role] || 'associated_with';

    await insertEntityRelationship({
      workspace_id: workspaceId,
      from_entity_id: link.entityId,
      to_entity_id: propertyEntityId,
      relationship_type: relationshipType,
      metadata: {
        role,
        source: `${source}_sidebar`,
        extracted_at: extractedAt,
      },
      effective_from: parseDate(metadata.sale_date) || null,
    }, { 'Prefer': 'return=representation,resolution=merge-duplicates' });

    // If person has a company, also create the company as an org entity
    if (entityType === 'person' && contact.company) {
      const companyLink = await ensureEntityLink({
        workspaceId,
        userId,
        sourceSystem: source,
        sourceType: 'company',
        externalId: normalizeCanonicalName(contact.company),
        domain,
        seedFields: { name: contact.company, org_type: 'broker' },
      });

      if (companyLink.ok && companyLink.createdEntity) created++;
    }
  }

  return created;
}

// ── Step 1b: Unpack Tenant → Entity + Lease Relationship ────────────────────

async function unpackTenant(propertyEntityId, metadata, workspaceId, userId, domain) {
  // Tenant-mix bleed guard (2026-06-07): the entity bridge must NOT mint the
  // CoStar tenant-MIX list as first-class org entities. A multi-tenant capture
  // (property 31457, Delano CA) leaked co-tenant labels ("Massage Therapist",
  // "Wing King Express", "Chicago Steak House") into the entity graph — role
  // labels are junk everywhere, and real-but-irrelevant co-tenants don't
  // warrant a BD entity. Doctrine: mint an org entity (+ lease relationship)
  // for ONLY the PRIMARY tenant; the full mix list lives in metadata.tenants on
  // the asset (and the domain leases table, junk-filtered by upsertDomainLeases)
  // and is NOT minted here. owners/buyers/sellers/brokers mint via
  // unpackContacts / unpackSalesHistory. (Previously this walked tenant_name +
  // primary_tenant + the whole tenants[] array, minting one org per entry.)
  const primaryName = selectPrimaryTenant(metadata, domain);
  if (!primaryName || typeof primaryName !== 'string') return 0;
  const tenantName = primaryName.trim();
  if (tenantName.length < 3) return 0;

  // Run the SAME junk check the leases writer uses (hoisted to module scope),
  // so a primary tenant that's actually a role label / use-category /
  // placeholder / demographic never mints an entity.
  if (isJunkTenant(tenantName)) {
    console.warn(`[unpackTenant] skipped junk primary tenant: "${tenantName.slice(0, 60)}"`);
    return 0;
  }

  // Recover the per-tenant SF / suite from the mix list when the primary
  // appears there (multi-tenant captures), so the lease relationship keeps
  // that scalar even though we only mint the primary.
  let sf = null, location = null;
  if (Array.isArray(metadata.tenants)) {
    const m = metadata.tenants.find(
      (t) => t && typeof t === 'object' && typeof t.name === 'string'
        && t.name.trim().toLowerCase() === tenantName.toLowerCase());
    if (m) { sf = m.sf || null; location = m.location || null; }
  }

  const source = metadata.source || 'costar';
  const tenantLink = await ensureEntityLink({
    workspaceId,
    userId,
    sourceSystem: source,
    sourceType: 'company',
    externalId: normalizeCanonicalName(tenantName),
    domain,
    seedFields: { name: tenantName, org_type: 'tenant' },
  });

  if (!tenantLink.ok) return 0;

  // Lease relationship for the primary tenant. Carries the lease scalars from
  // metadata when available (lease_term / occupancy / lease_type) plus the
  // per-tenant SF / suite when the page surfaced it.
  await insertEntityRelationship({
    workspace_id: workspaceId,
    from_entity_id: tenantLink.entityId,
    to_entity_id: propertyEntityId,
    relationship_type: 'leases',
    metadata: {
      role: 'tenant',
      source: `${source}_sidebar`,
      lease_term: metadata.lease_term || null,
      lease_type: metadata.lease_type || null,
      occupancy: metadata.occupancy || null,
      sf_leased: sf,
      suite_or_location: location,
      is_primary_tenant: true,
      extracted_at: metadata.extracted_at || new Date().toISOString(),
    },
  }, { 'Prefer': 'return=representation,resolution=merge-duplicates' });

  return tenantLink.createdEntity ? 1 : 0;
}

// ── Step 2: Unpack Sales History ────────────────────────────────────────────

async function unpackSalesHistory(propertyEntityId, metadata, workspaceId, userId, domain) {
  const sales = metadata.sales_history;
  if (!Array.isArray(sales) || sales.length === 0) return 0;

  const source = metadata.source || 'costar';
  let recorded = 0;

  for (const sale of sales) {
    const saleDate = parseDate(sale.sale_date);
    const salePrice = sale.sale_price && sale.sale_price !== 'Not Disclosed'
      ? sale.sale_price : null;

    // Build descriptive title
    const pricePart = salePrice || 'Undisclosed';
    const partiesPart = [sale.seller, sale.buyer].filter(Boolean).join(' → ');
    const title = partiesPart
      ? `Sale: ${pricePart} — ${partiesPart}`
      : `Sale: ${pricePart}`;

    const occurredAt = saleDate || new Date().toISOString();
    const srcType = `${source}_deed_record`;

    // D1 idempotency (2026-06-06): a re-run / double-submit of the same capture
    // used to re-insert an identical sale event (same entity/source/title/
    // occurred_at, ~1s apart) because there was no idempotency key. Set a
    // deterministic external_id AND skip the write when an identical sale event
    // already exists for this property+source+title — so repeated captures of
    // the same deal no longer pile up duplicate system events.
    const idemKey = ('sale|' + propertyEntityId + '|' + String(occurredAt).slice(0, 10)
      + '|' + (salePrice || '') + '|' + (sale.buyer || '') + '|' + (sale.seller || '')).slice(0, 480);
    try {
      const dupCheck = await opsQuery('GET',
        'activity_events?category=eq.system&entity_id=eq.' + encodeURIComponent(propertyEntityId)
        + '&source_type=eq.' + encodeURIComponent(srcType)
        + '&title=eq.' + encodeURIComponent(title)
        + '&select=id&limit=1');
      if (dupCheck.ok && Array.isArray(dupCheck.data) && dupCheck.data.length) {
        continue; // identical sale event already recorded — idempotent skip
      }
    } catch (_e) { /* non-fatal: fall through to insert */ }

    // Create activity_event
    const eventResult = await opsQuery('POST', 'activity_events', {
      workspace_id: workspaceId,
      actor_id: userId,
      entity_id: propertyEntityId,
      category: 'system',
      source_type: srcType,
      external_id: idemKey,
      title,
      occurred_at: occurredAt,
      domain,
      visibility: 'shared',
      metadata: {
        sale_price: sale.sale_price || null,
        asking_price: sale.asking_price || null,
        cap_rate: sale.cap_rate || null,
        buyer: sale.buyer || null,
        buyer_address: sale.buyer_address || null,
        seller: sale.seller || null,
        seller_address: sale.seller_address || null,
        lender: sale.lender || null,
        loan_amount: sale.loan_amount || null,
        loan_type: sale.loan_type || null,
        loan_origination_date: sale.loan_origination_date || null,
        interest_rate: sale.interest_rate || null,
        loan_term: sale.loan_term || null,
        maturity_date: sale.maturity_date || null,
        deed_type: sale.deed_type || null,
        transaction_type: sale.transaction_type || null,
        sale_type: sale.sale_type || null,
        sale_condition: sale.sale_condition || null,
        hold_period: sale.hold_period || null,
        document_number: sale.document_number || null,
        title_company: sale.title_company || null,
        is_current: sale.is_current || false,
        source,
      },
    });

    if (eventResult.ok) recorded++;

    // Create buyer entity if present (and not already handled by contacts)
    if (sale.buyer) {
      const buyerType = /\b(LLC|INC|CORP|LTD|LP|LLP|PARTNERS|GROUP)\b/i.test(sale.buyer)
        ? 'organization' : 'person';
      const buyerSeed = { name: sale.buyer };
      if (sale.buyer_address) {
        const parts = sale.buyer_address.split(',').map(s => s.trim());
        buyerSeed.address = parts[0];
        if (parts.length >= 2) buyerSeed.city = parts[1];
        if (parts.length >= 3) {
          const sz = parts[2].split(/\s+/);
          if (sz[0]) buyerSeed.state = sz[0];
          if (sz[1]) buyerSeed.zip = sz[1];
        }
      }

      const buyerLink = await ensureEntityLink({
        workspaceId,
        userId,
        sourceSystem: source,
        sourceType: buyerType === 'person' ? 'contact' : 'company',
        externalId: normalizeCanonicalName(sale.buyer),
        domain,
        seedFields: buyerSeed,
      });

      if (buyerLink.ok) {
        // Find the next sale date for effective_to
        const saleIdx = sales.indexOf(sale);
        const nextSaleDate = saleIdx > 0 ? parseDate(sales[saleIdx - 1].sale_date) : null;

        await insertEntityRelationship({
          workspace_id: workspaceId,
          from_entity_id: buyerLink.entityId,
          to_entity_id: propertyEntityId,
          relationship_type: 'purchases',
          metadata: { role: 'buyer', source: `${source}_deed`, document_number: sale.document_number || null },
          effective_from: saleDate || null,
          effective_to: nextSaleDate || null,
        }, { 'Prefer': 'return=representation,resolution=merge-duplicates' });
      }
    }

    // Create seller entity if present
    if (sale.seller) {
      const sellerType = /\b(LLC|INC|CORP|LTD|LP|LLP|PARTNERS|GROUP)\b/i.test(sale.seller)
        ? 'organization' : 'person';

      const sellerLink = await ensureEntityLink({
        workspaceId,
        userId,
        sourceSystem: source,
        sourceType: sellerType === 'person' ? 'contact' : 'company',
        externalId: normalizeCanonicalName(sale.seller),
        domain,
        seedFields: { name: sale.seller },
      });

      if (sellerLink.ok) {
        await insertEntityRelationship({
          workspace_id: workspaceId,
          from_entity_id: sellerLink.entityId,
          to_entity_id: propertyEntityId,
          relationship_type: 'sells',
          metadata: { role: 'seller', source: `${source}_deed`, document_number: sale.document_number || null },
          effective_from: saleDate || null,
        }, { 'Prefer': 'return=representation,resolution=merge-duplicates' });
      }
    }

    // Create lender entity if present
    if (sale.lender) {
      const lenderLink = await ensureEntityLink({
        workspaceId,
        userId,
        sourceSystem: source,
        sourceType: 'company',
        externalId: normalizeCanonicalName(sale.lender),
        domain,
        seedFields: { name: sale.lender, org_type: 'lender' },
      });

      if (lenderLink.ok) {
        await insertEntityRelationship({
          workspace_id: workspaceId,
          from_entity_id: lenderLink.entityId,
          to_entity_id: propertyEntityId,
          relationship_type: 'finances',
          metadata: {
            role: 'lender',
            source: `${source}_deed`,
            loan_amount: sale.loan_amount || null,
            loan_type: sale.loan_type || null,
            loan_origination_date: sale.loan_origination_date || null,
            interest_rate: sale.interest_rate || null,
            loan_term: sale.loan_term || null,
            maturity_date: sale.maturity_date || null,
            document_number: sale.document_number || null,
          },
          effective_from: parseDate(sale.loan_origination_date) || saleDate || null,
        }, { 'Prefer': 'return=representation,resolution=merge-duplicates' });
      }
    }
  }

  return recorded;
}

// ── Step 3: Write extraction signal ─────────────────────────────────────────

async function writeExtractionSignal(propertyEntityId, metadata, domain, userId, contactCount, salesCount) {
  await writeSignal({
    signal_type: 'sidebar_extraction_processed',
    signal_category: 'intelligence',
    entity_type: 'asset',
    entity_id: propertyEntityId,
    domain,
    user_id: userId,
    payload: {
      source: metadata.source || 'costar',
      extraction_type: `${metadata.source || 'costar'}_sidebar`,
      contacts_created: contactCount,
      sales_recorded: salesCount,
      financial_signals: {
        has_pricing: !!metadata.asking_price,
        has_cap_rate: !!metadata.cap_rate,
        has_noi: !!metadata.noi,
        sale_count: metadata.sales_history?.length || 0,
      },
    },
    outcome: 'pending',
  });
}

// ── Step 4: Domain classification + update ──────────────────────────────────

async function classifyAndUpdateDomain(entity, metadata, workspaceId) {
  const classified = classifyDomainWithDiag(metadata, entity);

  if (classified) {
    // Positive keyword match — update if it changed. entities.domain is
    // CHECK-constrained to the canonical short form (gov/dia/lcc/cre), but the
    // classifier returns the long form ('government'/'dialysis') that the
    // propagation router (propagateToDomainDb / getDomainCredentials) needs.
    // Write the canonical value to the column (a raw 'government' silently
    // 23514's chk_entities_domain, so the column never persisted from this
    // path and only got set later by the bridge); keep returning the long
    // form for the caller's routing. 2026-06-25.
    const canonicalDomain = canonicalEntityDomain(classified);
    if (canonicalDomain !== entity.domain) {
      await opsQuery('PATCH',
        `entities?id=eq.${entity.id}&workspace_id=eq.${workspaceId}`,
        { domain: canonicalDomain, updated_at: new Date().toISOString() }
      );
    }
    return classified;
  }

  // No keyword match found — this usually means the page view didn't
  // include tenant data (e.g. user was on Contacts or Public Records tab).
  // NEVER downgrade an established domain to null or a different domain
  // based on absence of evidence. Only a POSITIVE match for a different
  // domain should cause a reclassification.
  if (entity.domain) {
    return entity.domain;  // preserve existing
  }

  return null;
}

// ── Step 5: Domain database propagation ────────────────────────────────────
//
// After unpacking into LCC Ops relational records, propagate the structured
// data into the correct domain-specific Supabase backend (dialysis or gov).

/**
 * Main domain propagation dispatcher.
 * Routes to the correct domain backend based on classified domain.
 */
async function propagateToDomainDb(entity, metadata, domain, opts = {}) {
  if (!domain) return { propagated: false, reason: 'no_domain' };

  try {
    if (domain === 'dialysis' || domain === 'government') {
      if (!getDomainCredentials(domain)) return { propagated: false, reason: 'domain_db_not_configured' };
      return await propagateToDomainDbDirect(domain, entity, metadata, opts);
    }
    return { propagated: false, reason: 'unknown_domain' };
  } catch (err) {
    // Round 76ea: surface the actual error message + stack into the response
    // so pipeline failures are diagnosable from the entity metadata without
    // pulling Vercel logs. The prior catch swallowed err.stack which made
    // every "propagation_error" indistinguishable from every other.
    const errMsg = err?.message || String(err);
    const errStack = err?.stack ? String(err.stack).split('\n').slice(0, 5).join(' | ') : null;
    console.error(`[Sidebar pipeline] Domain propagation error (${domain}):`, errMsg, errStack);
    return {
      propagated: false,
      reason: 'propagation_error',
      error: errMsg,
      error_stack: errStack,
      entity_address: entity?.address || null,
    };
  }
}

// ── Upsert sidebar contacts (brokers, true owner contacts → contacts table) ─
//
// Column mapping differs between domain databases:
//   Dialysis:    contact_id (PK), contact_name, contact_email, contact_phone, role
//   Government:  contact_id (PK), name, email, phone, contact_type
//
const CONTACT_COLS = {
  dialysis:   { id: 'contact_id', name: 'contact_name', email: 'contact_email', phone: 'contact_phone', role: 'role' },
  government: { id: 'contact_id', name: 'name',         email: 'email',         phone: 'phone',         role: 'contact_type' },
};

// Junk-name filter for contact_name. Mirrors the isJunkTenant() pattern
// used by upsertDomainLeases. The CoStar sidebar's contact extraction
// occasionally produces firm names, section labels, or narrative text
// where a person name belongs. Audit 2026-04-29 surfaced 213 same-source
// "conflicts" against dia.contacts.contact_name in 2 days, including
// "Marcus & Millichap", "Public REIT", "Fund Name", and even narrative
// sentences like "This transaction was a sale leaseback."
//
// Returning true drops the contact entirely — a real person broker on
// the same listing usually arrives as a separate contact entry with
// proper name+email and gets written; the firm/junk row would only
// pollute contacts and burn a contact_id.
//
// Keep regex anchored ^...$ for label class so legitimate names
// containing those tokens aren't false-positived (e.g. "John Hess"
// is fine; bare "Vice Chairman" is not).

// Strip "<Role> Contacts" section-label prefix that the CoStar
// extractor sometimes glues onto person names: e.g.
//   "Buyer ContactsAlexandria Foster(619) 295-6565 (p)"
//   "Buyer ContactsBrendan Bush"
//   "Owner ContactsDidier P. Hakizimana"
// Audit on 2026-04-30 found 28 contacts and 12 sales_transactions rows
// with this pattern. Fix is two-fold: this function cleans incoming
// names before they're written, and migration 20260430050000 (Dialysis
// repo) cleaned the historical rows.
//
// Returns the cleaned name. If the string starts with one of the
// section-label prefixes we strip both the prefix AND the trailing
// phone "(NNN) NNN-NNNN (p)". Otherwise the input is returned
// unchanged. Trims whitespace either way.
function stripContactLabelPrefix(name) {
  if (typeof name !== 'string') return name;
  const trimmed = name.trim();
  if (!trimmed) return trimmed;
  if (!/^(Buyer|Seller|Owner|Listing( Broker)?) Contacts/i.test(trimmed)) return trimmed;
  return trimmed
    .replace(/^(Buyer|Seller|Owner|Listing( Broker)?) Contacts\s*/i, '')
    .replace(/\s*\(\d{3}\)\s*\d{3}-\d{4}\s*\(p\)\s*$/, '')
    .trim();
}

// C9 (2026-05-27): exported so api/_shared/ingest-contract.js can re-export
// as the canonical junk-name filter. Keep the regex source of truth here;
// the contract module is the API surface.
export function isJunkContactName(name) {
  if (typeof name !== 'string') return true;
  const trimmed = name.trim();
  if (trimmed.length < 3 || trimmed.length > 80) return true;

  // Class A: firm-name suffix patterns. Real person names don't end with these.
  // R4-6 (2026-05-20): added `Investors` (was missing alongside Investments?)
  // to catch "LA Investors", "Acme Investors LLC", etc.
  const firmSuffixRe = /\b(LLC|L\.L\.C\.?|Inc\.?|Corp\.?|Corporation|Companies?|Co\.|Realty,?|Real Estate|Realtors?|Properties|Property|Partners|Investments?|Investors|Capital|Holdings?|Advisors?|Management|Brokerage|Brokers|Commercial|Services|Solutions|REIT|Fund(s)?( [IVX]+| [0-9]+)?)\b/i;
  if (firmSuffixRe.test(trimmed)) return true;

  // Class B: well-known brokerage / firm brand markers.
  const firmBrandRe = /(\bMarcus & Millichap\b|\bCBRE\b|\bJLL\b|\bNewmark\b|\bCushman\b|\bColliers\b|\bAvison Young\b|\bBerkadia\b|\bEastdil\b|\bWalker & Dunlop\b|\bMatthews Real Estate\b|\bHorvath & Tremblay\b|\bKW Commercial\b)/i;
  if (firmBrandRe.test(trimmed)) return true;

  // Class C: pipe-separated firm names ("Colliers | Virginia").
  if (/\|/.test(trimmed)) return true;

  // Class D: section labels and UI noise (anchored).
  // R4-6 (2026-05-20): added Managing/General/Limited Partner + bare Partner
  // (CoStar's role-as-name leak; surfaced as "Managing Partner" landing in
  // contacts.contact_name vs OM's "Nathan Huffman").
  const labelRe = /^(Fund Name|Owner Name|Listing Broker|Buyer Broker|Seller Broker|View More|View Less|Per SF|Public REIT|Equity Funds?|Vice Chairman|Senior Associate|Senior Director|Senior Vice President|Director|Principal|Managing Director|Executive Vice President|Managing Partner|General Partner|Limited Partner|Partner)$/i;
  if (labelRe.test(trimmed)) return true;

  // Class E: narrative sentences (5+ words ending with period, OR
  // narrative-opener phrases). Person names don't have terminal periods
  // except for middle initials and titles ("Sarah J. Lee" stays fine —
  // initials aren't followed by another sentence-final period).
  if (trimmed.split(/\s+/).length >= 6 && /\.$/.test(trimmed)) return true;
  if (/^(This transaction|The seller|The buyer|This listing|The property|This property|This sale)/i.test(trimmed)) return true;

  // Round 76ek.g (2026-05-08): CoStar's per-sale Verification footnotes
  // landed as TRUE_SELLER_CONTACT names on 38275 W Twelve Mile Rd. Examples:
  //   "The sale price RBA were verified with listing broker"
  //   "The deed was unavailable at the time of publication."
  //   "Information was obtained from public records and CoStar research."
  // Extended narrative-opener list AND a verb-auxiliary detector for any
  // multi-word string that opens with a determiner and contains a tense
  // marker. Real person names never contain "was/were/is/are/has/have".
  if (/^(The sale|The deed|The transaction|The data|The information|The price|The asking|The cap|The NOI|This property|This deal|Information|Sale price|Asking price)\b/i.test(trimmed)) return true;
  const tokens = trimmed.split(/\s+/);
  if (tokens.length >= 4
      && /^(the|this|that|a|an|it|all|none|no)$/i.test(tokens[0])
      && /\b(was|were|is|are|has|have|had|will|would|been|verified|unavailable|disclosed|published|obtained|recorded|reported|confirmed)\b/i.test(trimmed)) {
    return true;
  }

  return false;
}

// ── Deed / document byte capture-at-ingestion (Build 1) ───────────────
//
// We were LOSING the deed: the sidebar captured the CoStar CDN URL
// (ahprd1cdn.csgpimgs.com/…) and NEVER the bytes; the CDN links expire, and the
// storage-only document-text-tick worker can never process a url-only doc — so a
// captured deed sat permanently unprocessable. The CDN link IS valid at the
// MOMENT of capture, so we fetch + store the bytes then. Strictly additive /
// best-effort: any failure leaves the url_captured row exactly as before.
//
// storage_path convention here is the DOMAIN `property-documents` bucket:
//   storage_path  = <objectPath> (WITHIN the bucket, NO bucket prefix)
//   storage_bucket = 'property-documents'
// which is exactly what intake-prepare-upload.js writes and what
// document-text.js::buildStorageGet reads (it prefixes the bucket itself). Do NOT
// use the LCC `lcc-om-uploads` '<bucket>/<path>' convention here.
export const PROPERTY_DOC_BUCKET = 'property-documents';

// Bounded so a giant or hung download can't stall the sidebar write path.
const DOC_BYTES_MAX     = Number(process.env.DOC_CAPTURE_MAX_BYTES   || 25_000_000);   // ~25 MB
const DOC_BYTES_TIMEOUT = Number(process.env.DOC_CAPTURE_TIMEOUT_MS  || 15_000);        // 15 s

function docBytesShortDomain(domain) {
  return /^(dia|dialysis)$/i.test(domain) ? 'dia' : 'gov';
}
function docBytesSeg(s, fallback) {
  const v = String(s ?? '').toLowerCase().replace(/[^\w.\-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80);
  return v || fallback;
}
function docBytesExt(fileName, sourceUrl) {
  const m = /\.([a-z0-9]{2,6})(?:[?#]|$)/i.exec(String(fileName || '')) ||
            /\.([a-z0-9]{2,6})(?:[?#]|$)/i.exec(String(sourceUrl || ''));
  return (m?.[1] || 'pdf').toLowerCase();
}

/**
 * Deterministic object path keyed on (domain, doctype, property_id, document_id)
 * so a re-capture of the same (property_id, file_name) — which upserts the SAME
 * document_id — overwrites the same object (x-upsert) rather than duplicating.
 */
export function documentObjectPath({ domain, documentType, propertyId, docId, fileName, sourceUrl }) {
  const dom = docBytesShortDomain(domain);
  const dt  = docBytesSeg(documentType, 'other');
  const pid = docBytesSeg(propertyId, 'unknown');
  const ext = docBytesExt(fileName, sourceUrl);
  return `${dom}/${dt}/${pid}/${docId}.${ext}`;
}

/**
 * Fetch a document's bytes from its (fresh) source_url and store them in the
 * domain `property-documents` bucket. Does NOT write property_documents — returns
 * the storage descriptor for the caller to PATCH. Bounded (size cap + timeout),
 * best-effort (never throws), deps-injected for testing.
 *
 * @returns {Promise<{ok:true, storage_path, storage_bucket, bytes}
 *                  | {ok:false, reason, status?, detail?}>}
 */
export async function fetchAndStoreDocBytes(domain, { docId, propertyId, sourceUrl, documentType, fileName }, deps = {}) {
  if (docId == null) return { ok: false, reason: 'no_doc_id' };
  if (!sourceUrl || !/^https?:\/\//i.test(String(sourceUrl))) return { ok: false, reason: 'no_absolute_url' };
  const getCreds = deps.getDomainCredentials || getDomainCredentials;
  const creds = getCreds(domain);
  if (!creds) return { ok: false, reason: 'domain_db_not_configured' };

  const doFetch = deps.fetchImpl || ((u, o) => fetchWithTimeout(u, o, DOC_BYTES_TIMEOUT));
  let res;
  try {
    res = await doFetch(sourceUrl, { headers: { 'User-Agent': 'Mozilla/5.0 (LCC document-capture)' } });
  } catch (err) {
    return { ok: false, reason: 'fetch_threw', detail: err?.message?.slice(0, 200) || String(err) };
  }
  if (!res || !res.ok) return { ok: false, reason: 'fetch_non_ok', status: res?.status || 0 };

  const cl = Number(res.headers?.get?.('content-length') || 0);
  if (cl && cl > DOC_BYTES_MAX) return { ok: false, reason: 'too_large', detail: `content-length=${cl}` };

  let buffer;
  try { buffer = Buffer.from(await res.arrayBuffer()); }
  catch (err) { return { ok: false, reason: 'read_failed', detail: err?.message?.slice(0, 200) || String(err) }; }
  if (!buffer.length) return { ok: false, reason: 'empty' };
  if (buffer.length > DOC_BYTES_MAX) return { ok: false, reason: 'too_large', detail: `bytes=${buffer.length}` };

  const objectPath = documentObjectPath({ domain, documentType, propertyId, docId, fileName, sourceUrl });
  const upload = deps.uploadImpl || uploadArtifactToStorage;
  const up = await upload({
    opsUrl: creds.url, opsKey: creds.key, bucket: PROPERTY_DOC_BUCKET,
    objectPath, mimeType: res.headers?.get?.('content-type') || 'application/pdf', buffer,
    fetchImpl: deps.uploadFetchImpl || ((u, o) => fetchWithTimeout(u, o, DOC_BYTES_TIMEOUT)),
  });
  if (!up.ok) return { ok: false, reason: 'upload_failed', status: up.status || 0, detail: up.detail };

  return { ok: true, storage_path: objectPath, storage_bucket: PROPERTY_DOC_BUCKET, bytes: buffer.length };
}

/**
 * Build-1 Unit 1 — capture the bytes at ingestion for one just-upserted
 * property_documents row and PATCH storage_path/storage_bucket/bytes_captured
 * onto it. Idempotent (skips a row that already carries storage_path, so a
 * re-capture never re-downloads). Best-effort — a failed capture returns a
 * non-ok result and the caller leaves the url_captured row untouched.
 */
export async function captureDocumentBytesAtIngest(domain, row, deps = {}) {
  if (row.storage_path) return { ok: true, outcome: 'already_stored' };
  const stored = await fetchAndStoreDocBytes(domain, {
    docId: row.document_id, propertyId: row.property_id, sourceUrl: row.source_url,
    documentType: row.document_type, fileName: row.file_name,
  }, deps);
  if (!stored.ok) return { ok: false, outcome: 'capture_skipped', reason: stored.reason };

  const q = deps.domainQuery || domainQuery;
  const patch = await q(domain, 'PATCH', `property_documents?document_id=eq.${row.document_id}`,
    { storage_path: stored.storage_path, storage_bucket: stored.storage_bucket, ingestion_status: 'bytes_captured' },
    { Prefer: 'return=minimal' });
  if (!patch.ok) return { ok: false, outcome: 'patch_failed', status: patch.status, storage_path: stored.storage_path };
  return { ok: true, outcome: 'bytes_captured', storage_path: stored.storage_path, bytes: stored.bytes };
}

// ── Upsert document links from CoStar "Documents" section ─────────────

async function upsertDocumentLinks(domain, propertyId, metadata, provCollect) {
  const docs = metadata.document_links;
  if (!Array.isArray(docs) || docs.length === 0) return 0;

  let count = 0;
  for (const doc of docs) {
    if (!doc.url) continue;
    const fileName = doc.label || doc.url.split('/').pop() || 'unknown';
    const row = {
      property_id: propertyId,
      file_name:   fileName,
      document_type: doc.type || 'other',
      source_url:  doc.url,
      ingestion_status: 'url_captured',
    };

    // Try upsert first
    let r = await domainQuery(
      domain, 'POST',
      'property_documents?on_conflict=property_id,file_name',
      row,
      { 'Prefer': 'return=representation,resolution=merge-duplicates' }
    );

    // If upsert fails, try plain insert (may be first time)
    if (!r.ok) {
      console.warn(`[doc-links] upsert failed for ${fileName} (${r.status}), trying plain insert`);
      r = await domainQuery(domain, 'POST', 'property_documents', row);
    }

    if (r.ok) {
      count++;
      const inserted = Array.isArray(r.data) ? r.data[0] : r.data;
      const docId = inserted?.document_id || inserted?.id;
      if (docId) {
        pushProvenance(provCollect, 'property_documents', docId, {
          file_name:     fileName,
          document_type: row.document_type,
          source_url:    row.source_url,
        });
        // Build 1 — fetch + store the bytes NOW while the CDN link is fresh, so
        // the storage-only document-text-tick worker can later extract text →
        // deed parse → grantee → R51. Strictly additive + best-effort: any
        // failure (dead link, timeout, size cap, storage hiccup) leaves the
        // url_captured row exactly as before and never blocks the capture.
        try {
          await captureDocumentBytesAtIngest(domain, {
            document_id:   docId,
            property_id:   propertyId,
            source_url:    row.source_url,
            document_type: row.document_type,
            file_name:     fileName,
            storage_path:  inserted?.storage_path || null,
          });
        } catch (e) {
          console.warn(`[doc-links] byte-capture threw for ${fileName}: ${e?.message || e}`);
        }
      }
    }
    else console.error(`[doc-links] insert also failed for ${fileName}:`, r.status, JSON.stringify(r.data));
  }
  return count;
}

async function upsertSidebarContacts(domain, propertyId, entity, metadata, provCollect) {
  const contacts = metadata.contacts || [];
  let count = 0;
  const col = CONTACT_COLS[domain];
  if (!col) return 0;

  // ── Helper: collect provenance for a contact row write ────────────────
  // Mirrors the row shape we just persisted into contacts (gov or dialysis
  // both follow CONTACT_COLS[domain].name/email/phone/role). recordPk is
  // the primary key whose name varies by domain — col.id resolves it.
  function collectContactProv(rowPk, fieldsObj) {
    if (!rowPk) return;
    pushProvenance(provCollect, 'contacts', rowPk, fieldsObj);
  }

  // ── Helper: find existing contact by email then by name ──────────────
  async function findExisting(email, normName, roleFilter) {
    if (email) {
      // Email is the most authoritative key. Verify the matching row's
      // name is consistent with the incoming name before claiming it's
      // the same contact. The 2026-04-30 audit found 254 dia.contacts
      // rows where the existing row's surname is absent from the
      // existing row's email — a strong signal that prior runs
      // collapsed distinct people sharing a firm-pool email
      // (info@firm.com, listings@brokerage.com, etc.) into one row
      // because email-fallback dedupe didn't check name affinity.
      const r = await domainQuery(domain, 'GET',
        `contacts?${col.email}=eq.${encodeURIComponent(email)}` +
        `&select=${col.id},${col.name}&limit=1`
      );
      if (r.ok && r.data?.length) {
        const candidate = r.data[0];
        const existingName = (candidate[col.name] || '').toLowerCase().trim();
        // Exact match: same person, reuse the row.
        if (existingName === normName) return candidate[col.id];
        // No name on existing row: safe to claim (prior run had only email).
        if (!existingName) return candidate[col.id];
        // Surname overlap: pick the longest token >= 3 chars from each
        // name; if any exact match, treat as same person.
        const incomingTokens = normName.split(/\s+/).filter(t => t.length >= 3);
        const existingTokens = existingName.split(/\s+/).filter(t => t.length >= 3);
        const sharedToken = incomingTokens.some(t => existingTokens.includes(t));
        if (sharedToken) return candidate[col.id];
        // Distinct-people-on-firm-pool-email pattern: do NOT claim the
        // existing row. INSERT a fresh contact instead so each person
        // keeps their identity (the constraint that prevented duplicate
        // INSERTs on (email) without role differentiation needs the
        // non-null property_id-based or role-based unique key — we
        // already partition by role on the gov branch via the loop
        // outside this helper).
        // Returning null falls through to the name+role lookup below.
      }
    }
    // Name-only fallback (or post-email-mismatch): require a role
    // filter when available to keep distinct deals' brokers separate.
    // When no role filter is supplied we keep the prior behavior of
    // matching purely by name — the dia branch caller handles this
    // since dia.contacts uses a free-text 'role' column. Same risk
    // class as before but bounded to dia, where the fuzzy upsert
    // pattern is still net-positive.
    const nameQ = roleFilter
      ? `contacts?${col.name}=ilike.${encodeURIComponent(normName)}&${col.role}=eq.${roleFilter}&select=${col.id}&limit=1`
      : `contacts?${col.name}=ilike.${encodeURIComponent(normName)}&select=${col.id}&limit=1`;
    const r2 = await domainQuery(domain, 'GET', nameQ);
    if (r2.ok && r2.data?.length) return r2.data[0][col.id];
    return null;
  }

  // ── Person contacts (brokers, true buyer/seller individuals) ─────────
  const PERSON_ROLES = ['listing_broker', 'buyer_broker',
    'true_buyer_contact', 'true_seller_contact'];

  // Read roles[] if present (set by the CoStar extractor's dedupe pass) and
  // fall back to the single-value .role. A person who is both listing broker
  // and buyer broker on the same deal arrives as one contact with
  // roles=['listing_broker','buyer_broker'] — we want one row per role in
  // the government DB (typed contact_type column) and a single row with
  // concatenated roles in the dialysis DB (free-text role column).
  const rolesOf = (c) => {
    if (Array.isArray(c.roles) && c.roles.length > 0) return c.roles;
    if (c.role) return [c.role];
    return [];
  };

  const people = contacts.filter(c => {
    const rs = rolesOf(c);
    return rs.some(r => PERSON_ROLES.includes(r)) &&
           c.name && c.name.length > 2 && c.name.length < 80 &&
           (c.email || c.phones?.length || c.phone);
  });

  // Low-confidence names (name_quality='first_only' from the Chrome
  // extension) don't get written into contacts — they'd overwrite or
  // dupe real broker rows with a stray first-name token. Route them to
  // the research queue so an enrichment pass can resolve the full name
  // from email/phone/LinkedIn rather than letting the default enricher
  // guess (which tends to invent surnames like "JOHN CUNNINGHAM" where
  // none is on the page).
  // D-13 fix (Item #5 Phase B, 2026-05-17): the legacy enqueue below was a
  // 100% silent-fail since ownership_research_queue was migrated to the
  // AI-pipeline shape. The columns posted (property_id, address, city,
  // state, recorded_owner_name, source, priority, status) do not exist on
  // the live schema, which now uses lead_id, task_type ('contact_discovery'
  // for first-name-only brokers), task_status, ai_*, etc.
  //
  // The Python AI pipeline already runs contact_discovery against the same
  // signal stream via the lead_id-based queue, so the sidebar shouldn't
  // double-enqueue. Neutralized as a no-op. The few thousand
  // ingest_write_failures rows this surface generated will stop appearing.
  if (domain === 'government') {
    const _firstOnlyCount = (people || []).filter(c => c && c.name_quality === 'first_only').length;
    if (_firstOnlyCount > 0) {
      console.debug('[sidebar-pipeline] D-13: skipped legacy ownership_research_queue enqueue for ' +
        _firstOnlyCount + ' first-name-only broker(s) — covered by AI pipeline task_type=contact_discovery.');
    }
  }
  // Strip "<Role> Contacts" section-label prefix in-place before the
  // junk-name filter runs. Captures cases like
  // "Buyer ContactsAlexandria Foster(619) 295-6565 (p)" → "Alexandria Foster".
  for (const c of people) {
    if (c && typeof c.name === 'string') {
      const cleaned = stripContactLabelPrefix(c.name);
      if (cleaned !== c.name) c.name = cleaned;
    }
  }

  // Drop contacts whose name looks like a firm, section label, or
  // narrative text rather than a person. See isJunkContactName()
  // header comment for the audit that motivated this filter.
  const droppedJunk = [];
  const writable = people.filter(c => {
    if (c.name_quality === 'first_only') return false;
    if (isJunkContactName(c.name)) {
      droppedJunk.push(c.name);
      return false;
    }
    return true;
  });
  if (droppedJunk.length > 0) {
    console.log(`[upsertSidebarContacts] dropped ${droppedJunk.length} junk-name contact(s) for ${domain} property=${propertyId}:`,
      droppedJunk.slice(0, 5).join(' | '));
  }

  for (const person of writable) {
    const email   = person.email || null;
    const phone   = person.phones?.[0] || person.phone || null;
    const company = person.company || null;
    const normName = person.name.trim().toLowerCase();
    const personRoles = rolesOf(person).filter(r => PERSON_ROLES.includes(r));

    // Force-refresh contact rows on every re-ingest so updated_at
    // advances as the audit signal. Even when nothing has changed, stamp
    // updated_at = now() and re-apply the latest email/phone/company
    // values so the row carries the freshest provenance. Dropping the
    // early-return on "no new fields" path is intentional per the
    // idempotency audit.
    const nowIso = new Date().toISOString();
    if (domain === 'government') {
      // One contacts row per role — contact_type is a typed column used by
      // downstream queries that filter "show me all listing brokers".
      for (const role of personRoles) {
        const existingId = await findExisting(email, normName, role);
        if (existingId) {
          const patch = {
            updated_at:  nowIso,
            data_source: 'costar_sidebar',
          };
          if (email) patch[col.email] = email;
          if (phone) patch[col.phone] = phone;
          if (company) patch.company = company;
          // Round 76co (Phase 3): priority gate on contact updates.
          // Contacts often have email/phone curated from CRM that should
          // outrank a CoStar refresh.
          const filteredPatch = await filterByFieldPriority({
            targetDb:    domain === 'dialysis' ? 'dia_db' : 'gov_db',
            targetTable: domain === 'dialysis' ? 'dia.contacts' : 'gov.contacts',
            recordPk:    existingId,
            source:      'costar_sidebar',
            confidence:  0.5,
            fields:      patch,
          }).catch(err => {
            console.warn('[upsertSidebarContacts] field-priority filter failed:', err?.message);
            return patch;
          });
          await domainPatch(domain,
            `contacts?${col.id}=eq.${existingId}`, filteredPatch,
            'upsertSidebarContacts:personUpdate'
          );
          // Provenance must mirror what was actually patched. The PATCH
          // path doesn't touch the name column (matched-by-email rows
          // already have an authoritative name), so don't claim we
          // attempted a name write — that produced 213 phantom
          // "conflicts" in the 2026-04-29 audit before this fix.
          const provFields = {};
          if ('email' in filteredPatch || col.email in filteredPatch) provFields[col.email] = email;
          if ('phone' in filteredPatch || col.phone in filteredPatch) provFields[col.phone] = phone;
          if ('company' in filteredPatch) provFields.company = company;
          collectContactProv(existingId, provFields);
        } else {
          const row = {
            [col.name]:  person.name.trim(),
            [col.email]: email,
            [col.phone]: phone,
            company:     company,
            title:       person.title || null,
            [col.role]:  role,
            data_source: 'costar_sidebar',
          };
          const r = await domainQuery(domain, 'POST', 'contacts', row);
          if (r.ok) {
            count++;
            const inserted = Array.isArray(r.data) ? r.data[0] : r.data;
            // INSERT path actually wrote name + role — record those.
            collectContactProv(inserted?.[col.id], {
              [col.name]: person.name.trim(),
              [col.email]: email, [col.phone]: phone, company,
              [col.role]: role,
            });
          }
        }
      }
    } else {
      // Dialysis DB: single row per person; role column gets a comma
      // list when multiple roles apply.
      const existingId = await findExisting(email, normName, null);
      const roleStr = personRoles.join(',') || person.role || null;
      if (existingId) {
        const patch = {
          updated_at:  nowIso,
          data_source: 'costar_sidebar',
        };
        if (email) patch[col.email] = email;
        if (phone) patch[col.phone] = phone;
        if (company) patch.company = company;
        if (roleStr) patch[col.role] = roleStr;
        await domainPatch(domain,
          `contacts?${col.id}=eq.${existingId}`, patch,
          'upsertSidebarContacts:personUpdate'
        );
        // Same as the gov branch: dia PATCH path doesn't touch the name
        // column on existing rows. Don't fabricate name-write provenance.
        const provFields = {};
        if (email) provFields[col.email] = email;
        if (phone) provFields[col.phone] = phone;
        if (company) provFields.company = company;
        if (roleStr) provFields[col.role] = roleStr;
        collectContactProv(existingId, provFields);
      } else {
        const row = {
          [col.name]:  person.name.trim(),
          [col.email]: email,
          [col.phone]: phone,
          company:     company,
          title:       person.title || null,
          [col.role]:  roleStr,
          data_source: 'costar_sidebar',
        };
        const r = await domainQuery(domain, 'POST', 'contacts', row);
        if (r.ok) {
          count++;
          const inserted = Array.isArray(r.data) ? r.data[0] : r.data;
          collectContactProv(inserted?.[col.id], {
            [col.name]: person.name.trim(),
            [col.email]: email, [col.phone]: phone, company,
            [col.role]: roleStr,
          });
        }
      }
    }
  }

  // ── Entity/org-level contacts (owners, buyers, sellers) ──────────────
  // High-value CRM contacts — true buyers/sellers often have direct
  // email/phone from CoStar that is critical for prospecting.

  const ENTITY_ROLE_MAP = {
    true_buyer:  'buyer',
    true_seller: 'seller',
    owner:       'owner',
    buyer:       'buyer',
    seller:      'seller',
  };

  // Entities that have at least one recognised entity role. Exclude anything
  // already classified as a person (roles[] includes a PERSON_ROLE) so a
  // single contact never flows through both loops.
  const entities = contacts.filter(c => {
    const rs = rolesOf(c);
    const hasEntity = rs.some(r => ENTITY_ROLE_MAP[r]);
    const hasPerson = rs.some(r => PERSON_ROLES.includes(r));
    return hasEntity && !hasPerson &&
           c.name && c.name.length > 2 && c.name.length < 80;
  });

  for (const ent of entities) {
    const email      = ent.email || null;
    const phone      = ent.phones?.[0] || ent.phone || null;
    const website    = ent.website || null;
    const normName   = ent.name.trim().toLowerCase();
    const mappedRoles = [...new Set(
      rolesOf(ent).map(r => ENTITY_ROLE_MAP[r]).filter(Boolean)
    )];

    const entityNowIso = new Date().toISOString();
    if (domain === 'government') {
      for (const mappedRole of mappedRoles) {
        const existingId = await findExisting(email, normName, mappedRole);
        if (existingId) {
          const patch = {
            updated_at:  entityNowIso,
            data_source: 'costar_sidebar',
          };
          if (email)       patch[col.email] = email;
          if (phone)       patch[col.phone] = phone;
          if (website)     { patch.website = website; patch.title = `Website: ${website}`; }
          if (ent.address) patch.address = ent.address;
          if (ent.city)    patch.city = ent.city;
          if (ent.state)   patch.state = ent.state;
          await domainPatch(domain,
            `contacts?${col.id}=eq.${existingId}`, patch,
            'upsertSidebarContacts:entityUpdate'
          );
          collectContactProv(existingId, {
            [col.name]: ent.name.trim(),
            [col.email]: email, [col.phone]: phone,
            [col.role]: mappedRole, website,
            address: ent.address, city: ent.city, state: ent.state,
          });
        } else {
          const row = {
            [col.name]:  ent.name.trim(),
            [col.email]: email,
            [col.phone]: phone,
            company:     ent.name.trim(),
            title:       website ? `Website: ${website}` : null,
            [col.role]:  mappedRole,
            website:     website,
            address:     ent.address || null,
            city:        ent.city || null,
            state:       ent.state || null,
            data_source: 'costar_sidebar',
          };
          const r = await domainQuery(domain, 'POST', 'contacts', row);
          if (r.ok) {
            count++;
            const inserted = Array.isArray(r.data) ? r.data[0] : r.data;
            collectContactProv(inserted?.[col.id], {
              [col.name]: ent.name.trim(),
              [col.email]: email, [col.phone]: phone,
              [col.role]: mappedRole, website,
              address: ent.address, city: ent.city, state: ent.state,
            });
          }
        }
      }
    } else {
      const existingId = await findExisting(email, normName, null);
      const roleStr = mappedRoles.join(',') ||
                      ENTITY_ROLE_MAP[ent.role] || null;
      if (existingId) {
        const patch = {
          updated_at:  entityNowIso,
          data_source: 'costar_sidebar',
        };
        if (email)       patch[col.email] = email;
        if (phone)       patch[col.phone] = phone;
        if (website)     { patch.website = website; patch.title = `Website: ${website}`; }
        if (ent.address) patch.address = ent.address;
        if (ent.city)    patch.city = ent.city;
        if (ent.state)   patch.state = ent.state;
        if (roleStr)     patch[col.role] = roleStr;
        await domainPatch(domain,
          `contacts?${col.id}=eq.${existingId}`, patch,
          'upsertSidebarContacts:entityUpdate'
        );
        collectContactProv(existingId, {
          [col.name]: ent.name.trim(),
          [col.email]: email, [col.phone]: phone,
          [col.role]: roleStr, website,
          address: ent.address, city: ent.city, state: ent.state,
        });
      } else {
        const row = {
          [col.name]:  ent.name.trim(),
          [col.email]: email,
          [col.phone]: phone,
          company:     ent.name.trim(),
          title:       website ? `Website: ${website}` : null,
          [col.role]:  roleStr,
          website:     website,
          address:     ent.address || null,
          city:        ent.city || null,
          state:       ent.state || null,
          data_source: 'costar_sidebar',
        };
        const r = await domainQuery(domain, 'POST', 'contacts', row);
        if (r.ok) {
          count++;
          const inserted = Array.isArray(r.data) ? r.data[0] : r.data;
          collectContactProv(inserted?.[col.id], {
            [col.name]: ent.name.trim(),
            [col.email]: email, [col.phone]: phone,
            [col.role]: roleStr, website,
            address: ent.address, city: ent.city, state: ent.state,
          });
        }
      }
    }
  }

  return count;
}

// ── ORE Option A Unit 2 — capture EVERY observed owner address (never collapse) ─
// The pipeline reduces the payload's many owner-address surfaces to ONE curated
// recorded_owners write (ensureRecordedOwner). This ALSO emits an append-only
// observation for each address-bearing surface to LCC Opps
// (lcc_record_owner_address_observation) so the reconcile engine + Build 2's
// address dimension see them. The curated write is untouched; this is additive,
// best-effort, and never blocks the capture. The owner NAME is guarded (federal
// anti-pattern / structural junk) so an address never attaches to a garbage owner;
// the RPC name-resolves the owner entity + normalizes/dedupes server-side.
// Pure collector (exported for tests): every owner-address surface in the
// payload, guarded (federal anti-pattern / structural junk owner names dropped),
// never collapsed. Returns [{ owner_name, address, surface, kind }].
export function collectOwnerAddressObservations(metadata) {
  const contacts = Array.isArray(metadata?.contacts) ? metadata.contacts : [];
  const sales    = Array.isArray(metadata?.sales_history) ? metadata.sales_history : [];
  const obs = [];
  const push = (name, address, surface, kind) => {
    const nm = (typeof name === 'string' ? name.trim() : '');
    const addr = (typeof address === 'string' ? address.trim() : '');
    if (!nm || !addr) return;
    if (isFederalOwnerAntiPattern(nm) || isJunkEntityName(nm)) return; // don't attach an address to a garbage owner
    obs.push({ owner_name: nm, address: addr, surface, kind });
  };
  for (const c of contacts) {
    if (!c || !c.address) continue;
    if (c.role === 'owner')       push(c.name, c.address, 'costar_owner_panel', 'notice');
    else if (c.role === 'true_buyer' || c.role === 'true_seller')
                                  push(c.name, c.address, 'costar_contacts', 'notice');
  }
  for (const s of sales) {
    if (!s) continue;
    if (s.buyer  && s.buyer_address)  push(s.buyer,  s.buyer_address,  'sales_comp_contact', 'mailing');
    if (s.seller && s.seller_address) push(s.seller, s.seller_address, 'sales_comp_contact', 'mailing');
  }
  return obs;
}

async function recordOwnerAddressObservations(domain, metadata) {
  const shortDomain = domain === 'dialysis' ? 'dia' : (domain === 'government' ? 'gov' : domain);
  const obs = collectOwnerAddressObservations(metadata);
  if (!obs.length) return 0;
  let recorded = 0;
  await Promise.all(obs.map(async (o) => {
    try {
      const r = await opsQuery('POST', 'rpc/lcc_record_owner_address_observation', {
        p_owner_entity_id: null,
        p_owner_name: o.owner_name,
        p_source_domain: shortDomain,
        p_source_recorded_owner_id: null,
        p_address: o.address,
        p_city: null,
        p_state: null,
        p_source_surface: o.surface,
        p_address_kind: o.kind,
        p_confidence: 0.6,
        p_source_url: null,
        p_source_context: null,
      });
      if (r.ok) recorded++;
    } catch (_) { /* best-effort — never blocks the capture */ }
  }));
  return recorded;
}

// ORE Option A Unit 4 — record a CoStar recorded↔true-owner assertion as an
// UNVERIFIED datapoint (verified=false). NEVER written to true_owner_id from the
// store; a deed/domain-derived link that AGREES corroborates it, one that
// DISAGREES is a review flag (v_lcc_owner_link_review). Best-effort; never blocks.
async function recordOwnerLinkObservation(domain, recordedOwnerName, assertedTrueOwnerName, recordedOwnerId) {
  const shortDomain = domain === 'dialysis' ? 'dia' : (domain === 'government' ? 'gov' : domain);
  const ro = (typeof recordedOwnerName === 'string' ? recordedOwnerName.trim() : '');
  const tt = (typeof assertedTrueOwnerName === 'string' ? assertedTrueOwnerName.trim() : '');
  if (!ro || !tt) return;
  try {
    await opsQuery('POST', 'rpc/lcc_record_owner_link_observation', {
      p_source_domain: shortDomain,
      p_recorded_owner_id: recordedOwnerId ? String(recordedOwnerId) : null,
      p_recorded_owner_name: ro,
      p_asserted_true_owner_name: tt,
      p_asserted_true_owner_id: null,
      p_source: 'costar',
      p_source_context: null,
    });
  } catch (_) { /* best-effort — never blocks */ }
}

// ── Domain DB propagation (direct PostgREST for both dialysis & government) ─

async function propagateToDomainDbDirect(domain, entity, metadata, opts = {}) {
  const results = { domain, property_id: null, records: {} };
  // Item #1: workspaceId/userId threaded from processSidebarExtraction so
  // we can fire runListingBdPipeline after the listing upsert.
  const { workspaceId = null, userId = null } = opts;

  // Phase 2.2.b: shared array writers push per-row provenance entries onto.
  // Flushed at the end of this function via recordCoStarFieldsProvenance.
  const provCollect = [];

  // Step 5a: Upsert property record
  const propertyId = await upsertDomainProperty(domain, entity, metadata);
  if (!propertyId) {
    console.error(`[Sidebar pipeline] ${domain} property upsert failed for:`, entity.address);
    // Round 76fg: surface the captured PostgREST error so the sidebar
    // status line and entity metadata show the actual reason (column /
    // constraint / type) instead of the bare 'property_upsert_failed'
    // sentinel that was indistinguishable across all failure modes.
    const err = _lastDomainPropertyError;
    const errSummary = err
      ? [err.message, err.details, err.hint]
          .filter(Boolean)
          .join(' — ')
          .substring(0, 400) || null
      : null;
    return {
      propagated: false,
      reason: 'property_upsert_failed',
      error: errSummary,
      error_detail: err,
      ...results,
    };
  }

  // Step 5a.5 (dialysis only): if a CMS clinic exists at this normalized
  // address, set properties.medicare_id (only when currently NULL — never
  // overwrite a confirmed link). Closes a propagation gap where every
  // CoStar sidebar capture that landed on a CMS-known address missed the
  // chance to link, leaving the orphan auto-linker cron to clean up later.
  if (domain === 'dialysis' && entity.address && entity.city && entity.state) {
    try {
      await linkDialysisMedicareIdInline(propertyId, entity);
    } catch (linkErr) {
      console.warn('[Sidebar pipeline] medicare_id auto-link failed (non-fatal):', linkErr?.message);
    }
  }
  results.property_id = propertyId;

  // Step 5a1: Link property to government agency tenant (gov only)
  if (domain === 'government') {
    results.records.property_agencies = await upsertPropertyAgency(
      propertyId, metadata
    );
  }

  // Step 5a2: Upsert public records (parcel + tax from CoStar sidebar)
  results.records.public_records = await upsertPublicRecords(
    domain, propertyId, entity, metadata, provCollect
  );

  // Step 5b: Upsert sales transactions
  results.records.sales = await upsertDomainSales(domain, propertyId, entity, metadata, provCollect);

  // Step 5b0: Upsert document links from CoStar "Documents" section
  results.records.document_links = await upsertDocumentLinks(domain, propertyId, metadata, provCollect);

  // Step 5b0.5: Auto-stage gov comp to sf_comps_staging for Salesforce sync
  if (domain === 'government' && results.records.sales > 0) {
    await stageGovCompForSalesforce(propertyId, entity, metadata);
  }

  // Step 5b1.5: Upsert available_listings
  if (domain === 'government') {
    results.records.listings = await upsertGovListings(propertyId, entity, metadata);
  }
  if (domain === 'dialysis') {
    results.records.listings = await upsertDialysisListings(propertyId, metadata);
  }

  // ── Item #1 (audit/01-bd-pipeline-trigger): Fire runListingBdPipeline
  // on truly NEW listings. Writers above return { count, insertedListingId }
  // where insertedListingId is non-null ONLY on a genuinely-new INSERT path.
  // Matches the sync.js:2571 SF-webhook pattern: inline await + parallel
  // writeListingCreatedSignal for telemetry. Failures never roll back the
  // upstream pipeline. processSidebarExtraction is already fire-and-forget
  // (see entities-handler.js), so added latency does not block the user.
  const _newListingId = results.records?.listings?.insertedListingId || null;
  if (_newListingId && workspaceId && entity?.id && entity?.state) {
    try {
      const _listingForBd = {
        ...entity,
        asset_type: entity.asset_type || metadata?.asset_type || entity.metadata?.asset_type || null,
        metadata: { ...(entity.metadata || {}), listing_status: 'active' },
      };
      writeListingCreatedSignal(_listingForBd, { id: userId }).catch(err =>
        console.warn('[bd-trigger:sidebar] writeListingCreatedSignal failed:', err?.message)
      );
      const _bdResult = await runListingBdPipeline(
        _listingForBd,
        workspaceId,
        userId,
        { triggerSource: 'sidebar_capture' }
      );
      results.records.bd_pipeline = {
        listing_id: _newListingId,
        t011_queued: _bdResult?.t011_same_asset?.queued || 0,
        t012_queued: _bdResult?.t012_geographic?.queued || 0,
        total_queued: _bdResult?.total_queued || 0,
      };
      console.log(`[bd-trigger:sidebar] queued ${_bdResult?.total_queued || 0} draft candidates (T-011=${_bdResult?.t011_same_asset?.queued || 0}, T-012=${_bdResult?.t012_geographic?.queued || 0}) for listing_id=${_newListingId} domain=${domain}`);
    } catch (err) {
      console.error('[bd-trigger:sidebar] runListingBdPipeline failed (non-fatal):', err?.message || err);
      results.records.bd_pipeline = { error: err?.message || String(err) };
    }
  } else if (_newListingId) {
    console.warn('[bd-trigger:sidebar] new listing detected but BD not fired:', {
      listing_id: _newListingId, domain,
      has_workspaceId: !!workspaceId, has_userId: !!userId,
      has_entity_id: !!entity?.id, has_state: !!entity?.state,
    });
  }

  // Step 5b2: Upsert broker links
  if (domain === 'dialysis') {
    results.records.brokers = await upsertDialysisBrokerLinks(propertyId, results.records.sales, metadata, provCollect);
  }
  if (domain === 'government') {
    results.records.brokers = await upsertGovBrokers(propertyId, metadata, provCollect);
  }

  // Step 5b3: Upsert deed records
  if (domain === 'dialysis') {
    results.records.deed_records = await upsertDialysisDeedRecords(propertyId, entity, metadata, provCollect);
  }
  if (domain === 'government') {
    results.records.deed_records = await upsertGovernmentDeedRecords(entity, metadata, provCollect);
  }

  // Step 5b4 (R51): propagate the latest deed grantee → recorded_owner.
  // The recorded deed grantee is the authoritative legal title-holder; push it
  // onto properties.recorded_owner through the field-priority gate so a fresh
  // deed self-corrects a stale / broker-as-owner recorded_owner. Best-effort —
  // the priority gate protects manual overrides, the guards reject brokerages /
  // junk, and a failure here never blocks the capture.
  if (propertyId) {
    try {
      const latestDeed = latestDeedGranteeFromMetadata(metadata);
      if (latestDeed?.grantee) {
        const dop = await propagateDeedGranteeToOwner({
          domain, propertyId, granteeName: latestDeed.grantee,
          entity, workspaceId, sourceRunId: null, confidence: 0.9,
        });
        results.records.deed_owner_propagation = dop;
        // When the deed grantee actually became the recorded_owner, close the
        // transfer loop in the same capture (attribute the matching sale + append
        // the ownership_history row) so a fresh capture self-heals and never leaves
        // the orphan-sale / owner-conflict banners for the operator. Best-effort.
        if (dop && dop.applied && dop.recorded_owner_id) {
          results.records.deed_owner_reconcile = await reconcileSaleAndOwnershipForNewOwner({
            domain, propertyId, recordedOwnerId: dop.recorded_owner_id, ownerName: latestDeed.grantee,
          });
        }
      }
    } catch (err) {
      console.warn('[R51:propagateDeedGranteeToOwner] non-fatal:', err?.message || err);
    }
  }

  // Step 5c: Upsert loans
  results.records.loans = await upsertDomainLoans(domain, propertyId, metadata, provCollect);

  // Step 5c2: Upsert CMBS loan records (Round 76ek.b).
  // metadata.loan_records[] arrives from extension/content/costar.js when the
  // user is on a /detail/lookup/{N}/loan page. Each record carries CMBS-grade
  // loan facts (servicer / sponsor / origination LTV / etc.) plus an embedded
  // snapshot block (NOI / DSCR / GLA / top tenants @ as_of_date).
  results.records.loan_records = await upsertLoanRecords(
    domain, propertyId, metadata, provCollect
  );

  // Step 5c3: Upsert CMBS multi-year financials (Round 76ek.e).
  // metadata.property_financials[] arrives from /detail/lookup/{N}/cmbs-financials.
  // The parser drops Market-mode and Per-SF-mode captures and skips the
  // Underwritten column at the source. Same dia opt-in gate as snapshots.
  results.records.property_financials = await upsertPropertyFinancials(
    domain, propertyId, metadata, provCollect
  );

  // Step 5d: Upsert recorded owners + ownership history
  const ownerResults = await upsertDomainOwners(domain, propertyId, entity, metadata, provCollect);
  results.records.owners = ownerResults.owners;
  results.records.history = ownerResults.history;

  // Step 5d2: Upsert true owners (true buyer / true seller behind shell entities)
  const trueOwnerResult = await upsertTrueOwners(domain, propertyId, metadata);
  results.records.true_owners = (trueOwnerResult.true_buyer_id ? 1 : 0)
                               + (trueOwnerResult.true_seller_id ? 1 : 0);

  // Step 5d3: Cross-reference all owners against Salesforce (dialysis only)
  const sfResult = await crossReferenceSalesforce(domain, propertyId);
  results.records.sf_matches = sfResult.matched;

  // Step 5e: Upsert leases
  if (domain === 'dialysis') {
    results.records.leases = await upsertDomainLeases(domain, propertyId, metadata, provCollect);
  } else if (domain === 'government') {
    results.records.leases = await upsertGovernmentLeases(propertyId, metadata, provCollect);
  }

  // Step 5e2: Upsert named contacts (brokers, true owner contacts → CRM)
  results.records.contacts = await upsertSidebarContacts(
    domain, propertyId, entity, metadata, provCollect
  );

  // Step 5f: Auto-enqueue ownership research if true_owner still unknown (gov)
  if (domain === 'government') {
    await autoEnqueueOwnerResearch(propertyId, entity, metadata);
  }

  // Step 5g: Recalculate sale cap rates from confirmed rent anchor (dialysis).
  // No-op when no anchor rent has been set, so this is safe to run on every
  // save — it only does work once an OM or lease has populated anchor_rent.
  if (domain === 'dialysis') {
    try {
      const { updated, skipped } = await recalculateSaleCapRates(propertyId, domainQuery);
      console.log(`[cap-rate-recalc] property=${propertyId} updated=${updated} skipped=${skipped}`);
      results.records.cap_rate_recalc = { updated, skipped };
    } catch (err) {
      console.error('[cap-rate-recalc] post-propagate error:', err?.message || err);
    }
  }

  // Step 5h: Stamp properties.last_ingested_at so the audit trail shows
  // when CoStar last refreshed this property. The gov properties table
  // has this column from the initial schema; dialysis added it in
  // migration 20260421000000_properties_last_ingested_at.sql (included
  // with this change). Failures are logged but non-fatal since the
  // upstream writes are what actually carry the refreshed data.
  try {
    const nowIso = new Date().toISOString();
    await domainPatch(
      domain,
      `properties?property_id=eq.${propertyId}`,
      { last_ingested_at: nowIso },
      'propagateToDomainDbDirect:last_ingested_at'
    );
  } catch (err) {
    console.error('[last_ingested_at] stamp failed:', err?.message || err);
  }

  // Step 5i (Bug C fix, 2026-04-24): write the domain-bridge
  // external_identities row. Without this, an asset entity created by
  // CoStar sidebar is orphaned — it has external_identities{source_system:
  // 'costar'} but no pointer back to the actual gov/dia property_id. That
  // broke the LCC-bridge unwrap in intake-promoter. Idempotent upsert keyed
  // on (workspace_id, source_system, source_type, external_id); safe to re-run.
  // R4-A (2026-06-04): canonical source_system 'dia'/'gov' + source_type
  // 'asset' (was 'dia_db'/'gov_db' + 'property') so the property-anchor entity
  // resolves under one spelling and the detail page stops fragmenting.
  if (propertyId && entity?.id && entity?.workspace_id) {
    const sourceSystem = canonicalIdentitySystem(domain);
    try {
      const nowIso = new Date().toISOString();
      await opsQuery('POST',
        'external_identities?on_conflict=workspace_id,source_system,source_type,external_id',
        {
          workspace_id: entity.workspace_id,
          entity_id:    entity.id,
          source_system: sourceSystem,
          source_type:  'asset',
          external_id:  String(propertyId),
          metadata:     { synced_via: 'sidebar-pipeline.propagateToDomainDbDirect' },
          last_synced_at: nowIso,
        },
        { 'Prefer': 'return=minimal,resolution=merge-duplicates' }
      );
    } catch (err) {
      console.warn('[sidebar-pipeline] domain bridge identity insert failed (non-fatal):', err?.message || err);
    }
  }

  // ── Phase 2.2 (2026-04-25): record CoStar field provenance ────────────
  // For each cross-table field this sidebar capture wrote, log a row to
  // public.field_provenance via lcc_merge_field. Source='costar_sidebar',
  // source_run_id=entity.id (the LCC entity that owns this CoStar capture).
  // Every priority entry is enforce_mode=record_only today, so this is
  // observation-only — actual upserts above ran unchanged.
  //
  // Phase 2.2.a coverage (this PR): properties + the listing rows we just
  // wrote (looked up by property_id). Phase 2.2.b deferred: leases,
  // contacts, sales_transactions, public_records, deed records, loans,
  // ownership_history. Those writers return counts not row PKs; Phase
  // 2.2.b will modify their return shapes to expose the PKs they wrote.
  try {
    const targetDb = domain === 'dialysis' ? 'dia_db' : 'gov_db';
    const tablePrefix = domain === 'dialysis' ? 'dia' : 'gov';
    // Round 76af 2026-04-28: derive provenance source tag from sidebar source.
    // RCA captures (metadata.source='rca' from extension/content/rca.js) carry
    // their own trust profile and should appear as 'rca_sidebar' in provenance.
    // Round 76ej.d 2026-05-04: CREXi captures get their own tag too
    // (priority registry seeded by the sibling migration). Falls back to
    // costar_sidebar for any unrecognised source.
    // Round 76ej.h 2026-05-04: trace marker + diagnostic logging — earlier
    // run on a CREXi capture (entity 76ej-c5b0d0d5) tagged provenance as
    // costar_sidebar despite metadata.source='crexi'. Logging the resolved
    // sourceTag lets us confirm in Vercel function logs whether the
    // deployed build includes this branch.
    const sidebarSource = (metadata?.source || metadata?._source || '').toLowerCase();
    let sourceTag = 'costar_sidebar';
    if (sidebarSource === 'rca')   sourceTag = 'rca_sidebar';
    if (sidebarSource === 'crexi') sourceTag = 'crexi_sidebar';
    const runIdPrefix =
      sourceTag === 'rca_sidebar'   ? 'rca'   :
      sourceTag === 'crexi_sidebar' ? 'crexi' :
                                      'costar';
    console.log('[sidebar-pipeline] Round 76ej.h sourceTag derive', {
      sidebar_source_raw: metadata?.source ?? null,
      sidebar_source_alt: metadata?._source ?? null,
      sidebar_source_lower: sidebarSource,
      resolved_source_tag: sourceTag,
      run_id_prefix: runIdPrefix,
      entity_id: entity?.id || null,
    });
    const provCtx = {
      targetDatabase: targetDb,
      sidebarRunId:   entity?.id ? `${runIdPrefix}:${entity.id}` : null,
      workspaceId:    entity?.workspace_id || null,
      actorId:        entity?.created_by || null,
      sourceTag,
    };

    // Round 76ej.l 2026-05-05: per-field source override for CREXi prose-
    // mined lease facts. Round 76ej.k attached a `lease_facts_from_
    // description` breadcrumb to metadata; any field present (non-null)
    // there came from regex-mining the broker's marketing description
    // rather than CREXi's structured Details panel, so it gets tagged
    // as crexi_sidebar_description (priority 75) instead of crexi_sidebar
    // (priority 70). Map keys are the breadcrumb's labels; values are
    // the actual DB column names the writer uses.
    const proseLease = metadata?.lease_facts_from_description;
    const perFieldSource = {};
    if (proseLease && typeof proseLease === 'object') {
      const PROSE_TO_DB_FIELD = {
        expense_structure:    'expense_structure',
        remaining_term_years: 'remaining_term',
        lease_expiration:     'lease_expiration',
        renewal_options:      'renewal_options',
        rent_escalations_pct: 'rent_escalations',
      };
      for (const [proseKey, dbField] of Object.entries(PROSE_TO_DB_FIELD)) {
        if (proseLease[proseKey] != null) {
          perFieldSource[dbField] = 'crexi_sidebar_description';
        }
      }
    }

    // 1. Property fields — direct from entity + metadata (what CoStar
    //    actually advertised before the writer applied any cleaning).
    if (propertyId) {
      // Property schema differs by domain. dia has tenant / building_size /
      // land_area / lot_sf / parcel_number / anchor_rent_* / lease_commencement.
      // gov has rba / land_acres / lease_commencement (NO tenant, lot_sf,
      // parcel_number, building_size, land_area, anchor_rent_*). Sending
      // dia field names to gov (and vice-versa) lands provenance on
      // nonexistent columns. Same fix pattern as PR #498 (gov listings)
      // and PR #500 (gov contacts). The actual upsertDomainProperty
      // already handles the field-name split correctly.
      const sharedPropFields = {
        address:    entity.address || metadata.address || null,
        city:       entity.city    || metadata.city    || null,
        state:      entity.state   || metadata.state   || null,
        zip_code:   entity.zip     || metadata.zip     || null,
        year_built: metadata.year_built || null,
      };
      // Mirror buildGovListingRow / upsertDomainProperty's gov branch on the
      // sidebar-pipeline side: gov.properties has many lease + financial
      // columns the dia branch doesn't (gross_rent, gross_rent_psf,
      // lease_expiration, renewal_options, sf_leased, agency, etc.) plus
      // sale-mirror columns (latest_deed_date, latest_sale_price). The
      // writer populates all of them; provenance covered only the first 8.
      // 15 additional fields registered in migration 20260429460000.
      const govLatestSale = (Array.isArray(metadata.sales_history) ? metadata.sales_history : [])
        .filter(s => s && s.sale_date)
        .sort((a, b) => new Date(b.sale_date).getTime() - new Date(a.sale_date).getTime())[0];
      const propValues = domain === 'government'
        ? {
            ...sharedPropFields,
            rba:                 metadata.sf_total || metadata.building_sf || null,
            land_acres:          metadata.land_acres || null,
            lease_commencement:  parseDate(metadata.lease_commencement)?.split('T')[0] || null,
            year_renovated:      metadata.year_renovated || null,
            county:              metadata.county || entity.county || null,
            building_type:       metadata.property_type || null,
            gov_occupancy_pct:   metadata.occupancy != null ? Number(metadata.occupancy) : null,
            assessed_value:      parseCurrency(metadata.assessed_value),
            gross_rent:          parseCurrency(metadata.annual_rent),
            gross_rent_psf:      parseCurrency(metadata.rent_per_sf),
            lease_expiration:    parseDate(metadata.lease_expiration)?.split('T')[0] || null,
            renewal_options:     metadata.renewal_options || null,
            rent_escalations:    metadata.rent_escalations || null,
            sf_leased:           metadata.sf_leased != null ? Number(metadata.sf_leased) : null,
            agency:              metadata.tenant_name || metadata.primary_tenant || null,
            agency_full_name:    metadata.tenant_name || metadata.primary_tenant || null,
            latest_deed_date:    govLatestSale ? (parseDate(govLatestSale.sale_date)?.split('T')[0] || null) : null,
            latest_sale_price:   govLatestSale ? parseCurrency(govLatestSale.sale_price) : null,
          }
        : {
            ...sharedPropFields,
            tenant:             metadata.tenant_name || metadata.primary_tenant || null,
            building_size:      metadata.sf_total || metadata.building_sf || null,
            lot_sf:             metadata.lot_sf || null,
            land_area:          metadata.land_acres || null,   // dia column is land_area; metadata.land_acres is the input field name
            parcel_number:      metadata.parcel_number || metadata.apn || null,
            anchor_rent:        parseCurrency(metadata.anchor_rent),
            anchor_rent_date:   parseDate(metadata.anchor_rent_date)?.split('T')[0] || null,
            anchor_rent_source: metadata.anchor_rent_source || null,
            lease_commencement: parseDate(metadata.lease_commencement)?.split('T')[0] || null,
          };
      await recordCoStarFieldsProvenance(
        { ...provCtx, targetTable: `${tablePrefix}.properties`, recordPk: propertyId },
        propValues,
        {},
        perFieldSource
      );
    }

    // 2. Phase 2.2.b — flush per-row entries collected by leases / sales /
    //    contacts / public_records writers. Each entry: {table, recordPk,
    //    fields, confidence?}. The writers stamp `dia.<table>` etc. so we
    //    don't need to re-prefix here.
    if (provCollect.length > 0) {
      for (const entry of provCollect) {
        // Allow writers to override default confidence per-row (e.g. lease
        // rent from a confirmed lease abstract should carry higher
        // confidence than CoStar metadata's "Asking Rent" panel value).
        const perField = {};
        if (entry.confidence != null) {
          for (const k of Object.keys(entry.fields)) perField[k] = entry.confidence;
        }
        // Round 76ek.b: when an entry was pushed with an explicit `source`
        // override (e.g. upsertLoanRecords stamps its rows as
        // 'costar_cmbs_loan'), build a per-field source map so the flush
        // tags those fields correctly. Falls through to the batch sourceTag
        // for entries without an override (the existing CoStar-sidebar path).
        const entryFieldSource = { ...perFieldSource };
        if (entry.source) {
          for (const k of Object.keys(entry.fields)) {
            entryFieldSource[k] = entry.source;
          }
        }
        await recordCoStarFieldsProvenance(
          { ...provCtx, targetTable: `${tablePrefix}.${entry.table}`, recordPk: entry.recordPk },
          entry.fields,
          perField,
          entryFieldSource
        );
      }
    }

    // 3. Available_listings — look up by property_id since the writer
    //    returns a count, not the listing_id. Most recent CoStar-sourced
    //    listing for this property is the one we just wrote.
    if (propertyId && results.records?.listings?.count > 0) {
      try {
        const listingLookup = await domainQuery(
          domain, 'GET',
          `available_listings?property_id=eq.${propertyId}` +
          `&order=last_seen.desc.nullslast,listing_id.desc&select=listing_id&limit=1`
        );
        const latestListing = listingLookup.ok && listingLookup.data?.length
          ? listingLookup.data[0]
          : null;
        if (latestListing?.listing_id) {
          // Schema differs by domain — gov.available_listings uses
          // asking_price / asking_cap_rate / asking_price_psf, dia uses
          // initial_price / last_price / current_cap_rate / initial_cap_rate
          // / price_per_sf / seller_name. The actual listing INSERT
          // (upsertGovListings vs upsertDialysisListings) already branches
          // correctly; this provenance call has to mirror that or
          // v_field_provenance_unranked surfaces writes against columns
          // that don't exist on the target table. Same fix as the OM
          // promoter side in PR #498.
          // R4-6 (2026-05-20): parse before recording provenance. CoStar
          // sends prices as strings like "$3,690,000 ($246.00/SF)" and cap
          // rates as "6.7%". Recording the raw strings produced ~120 fake
          // same-priority conflicts vs the OM promoter's parsed numerics
          // ("$3,690,000 ($246.00/SF)" != 3690000, "6.7%" -> NaN -> null).
          // Both the listing INSERT and the provenance call must operate on
          // the same parsed values.
          const capRateDecimal = parseCapRateDecimal(metadata.cap_rate);
          const askPrice = parseCurrency(metadata.list_price) || parseCurrency(metadata.asking_price) || null;
          const sfInt = parseSF(metadata.square_footage);
          const askPpsf = (askPrice && sfInt)
            ? Math.round((askPrice / sfInt) * 100) / 100
            : null;

          const listingValues = domain === 'government'
            ? {
                asking_price:     askPrice,
                asking_cap_rate:  capRateDecimal,
                asking_price_psf: askPpsf,
                listing_broker:   metadata.listing_broker || null,
                broker_email:     metadata.listing_broker_email || null,
                seller_name:      metadata.seller_name || null,
                listing_date:     metadata.listing_date || null,
              }
            : {
                initial_price:    askPrice,
                last_price:       askPrice,
                current_cap_rate: capRateDecimal,
                initial_cap_rate: capRateDecimal,
                listing_broker:   metadata.listing_broker || null,
                broker_email:     metadata.listing_broker_email || null,
                seller_name:      metadata.seller_name || null,
                listing_date:     metadata.listing_date || null,
              };

          await recordCoStarFieldsProvenance(
            { ...provCtx, targetTable: `${tablePrefix}.available_listings`, recordPk: latestListing.listing_id },
            listingValues,
            {},
            perFieldSource
          );
        }
      } catch (err) {
        // Listing provenance is observation-only; failure here is noise.
      }
    }
  } catch (err) {
    console.warn('[sidebar-pipeline] field provenance recording failed (non-fatal):', err?.message);
  }

  // Step 5z (2026-06-25): explode a Bulk/Portfolio Sale's constituent Properties
  // table into per-property rows. The subject property above carried the deal
  // aggregate (now nulled by the isPortfolioAggregateSale guard); each
  // constituent is matched-or-created by normalized address and gets its OWN
  // per-property price from the table. Gated on the extension capturing
  // portfolio_properties[]; fully fail-safe (never breaks the subject write).
  if (Array.isArray(metadata.portfolio_properties) && metadata.portfolio_properties.length > 1) {
    try {
      results.records.portfolio_constituents =
        await unpackPortfolioConstituents(domain, entity, metadata, provCollect);
    } catch (err) {
      console.warn('[portfolio-unpack] failed (non-fatal):', err?.message);
      results.records.portfolio_constituents = { error: err?.message || String(err) };
    }
  }

  // ORE Option A Unit 2: append-only owner-address observations (never collapse).
  // Best-effort; never blocks. The curated recorded_owners write above is intact.
  try {
    results.records.owner_address_observations = await recordOwnerAddressObservations(domain, metadata);
  } catch (err) {
    console.warn('[sidebar-pipeline] owner-address observation recording failed (non-fatal):', err?.message);
  }

  return { propagated: true, ...results };
}

// ── Auto-enqueue ownership research ───────────────────────────────────────
//
// D-13 fix (Item #5 Phase B, 2026-05-17): the legacy implementation below
// was a 100% silent-fail. The columns posted (property_id, address, city,
// state, recorded_owner_id, recorded_owner_name, source, priority, status)
// do not exist on the live ownership_research_queue schema, which uses
// lead_id, task_type ('entity_resolution' for unknown true_owner from a
// known recorded_owner), task_status, ai_*, etc. The Python AI pipeline
// already runs entity_resolution via the lead_id-based queue.
//
// Neutralized as a no-op — keeps the call site stable but stops generating
// ingest_write_failures rows. The caller in propagateToDomainDbDirect
// (line ~2349, gov-only) still invokes this; the function now logs and
// returns immediately.

async function autoEnqueueOwnerResearch(propertyId, entity, metadata) {
  // D-13: legacy schema mismatch. The AI pipeline handles entity_resolution
  // via the lead_id-based queue with task_type='entity_resolution'.
  void entity; void metadata;
  console.debug('[sidebar-pipeline] D-13: skipped legacy autoEnqueueOwnerResearch ' +
    'for property=' + propertyId + ' — covered by AI pipeline task_type=entity_resolution.');
  return;
}

// ── Shared domain DB upsert helpers ────────────────────────────────────────

/**
 * Find or create a property record in the domain database.
 * Matches by address + state for deduplication.
 * Returns the property_id (UUID) or null on failure.
 */
// Auto-link a freshly-upserted dialysis property to a CMS clinic by
// normalized address+city+state. Only sets medicare_id when:
//   - properties.medicare_id is currently NULL (never clobbers an existing
//     confirmed link)
//   - exactly one medicare_clinic matches the address (no ambiguity)
// Calls the dia.apply_property_link_outcome RPC so both sides
// (properties.medicare_id and medicare_clinics.property_id) get set
// atomically and the audit trail matches the auto-linker cron.
async function linkDialysisMedicareIdInline(propertyId, entity) {
  // Quick existing-link check
  const existingProp = await domainQuery(
    'dialysis', 'GET',
    `properties?property_id=eq.${Number(propertyId)}&select=medicare_id&limit=1`
  );
  if (existingProp.ok && Array.isArray(existingProp.data) && existingProp.data.length
      && existingProp.data[0].medicare_id) {
    return; // already linked
  }

  // Look up clinic by normalized address+city+state. The Dialysis DB has
  // dia_normalize_address available, so we ask Postgres to do the matching.
  const params = new URLSearchParams({
    p_address: entity.address,
    p_city:    entity.city,
    p_state:   entity.state,
  });
  const candidates = await domainQuery(
    'dialysis', 'POST',
    'rpc/dia_find_clinic_by_address',
    { p_address: entity.address, p_city: entity.city, p_state: entity.state }
  );
  if (!candidates.ok || !Array.isArray(candidates.data) || candidates.data.length !== 1) {
    return; // 0 or 2+ candidates — let the orphan auto-linker handle it (or stay manual)
  }

  const clinicId = candidates.data[0]?.medicare_id;
  if (!clinicId) return;

  // Apply the canonical link via the RPC (writes both sides + audit-friendly)
  const linkRes = await domainQuery(
    'dialysis', 'POST',
    'rpc/apply_property_link_outcome',
    { p_clinic_id: String(clinicId), p_property_id: Number(propertyId) }
  );
  if (linkRes.ok) {
    console.log('[Sidebar pipeline] auto-linked property #' + propertyId
      + ' to clinic ' + clinicId + ' via address match');
  }
}

export async function upsertDomainProperty(domain, entity, metadata) {
  // Round 76fg: reset captured error each call. Set on the true-failure
  // path (POST 4xx + retry-lookup miss) so propagateToDomainDbDirect can
  // surface it into the entity metadata.
  _lastDomainPropertyError = null;

  // Strip CoStar/LoopNet listing-status prefixes ("For Sale | ",
  // "For Lease | ", "Reduced | ", …) off the incoming address before any
  // lookup or write. Without this guard, the prefixed form becomes the
  // properties.address value and creates a duplicate property for every
  // re-capture of an active listing — and the consolidate UI then can't
  // match it to the canonical row because dia_normalize_address /
  // gov_normalize_address don't strip the prefix either.
  const rawAddress = entity.address || metadata.address;
  const address = stripListingStatusPrefix(rawAddress);
  if (address && address !== rawAddress) {
    if (entity.address) entity.address = address;
    if (metadata.address) metadata.address = address;
  }
  if (!address) return null;

  // R5-DQ-3 (2026-05-20): reject OM section-header / table-of-contents
  // residue that AI extraction grabbed instead of a street line. Without
  // this guard the sidebar creates a junk-address property (e.g.
  // "2 Lease Summary 110 Enterprise Dr") and then has to be merged into
  // the canonical record manually. Better to skip the write entirely so
  // the canonical address path runs against the next CoStar capture.
  if (isJunkAddress(address)) {
    _lastDomainPropertyError = `junk_address_rejected:${address}`;
    console.warn(`[upsertDomainProperty] Refusing to write OM-junk address: "${address}" (${domain})`);
    return null;
  }

  // §3 (2026-05-21): never create a property at the firm's OWN office address.
  // OM/flyer extractors often grab the broker contact-block address ("For more
  // information contact …") instead of the subject property — the 6120 S Yale
  // Ave case created 11 mis-located dia properties. Skip the write so the
  // canonical subject-address path runs against the next/better capture.
  if (isOwnFirmAddress(address)) {
    _lastDomainPropertyError = `own_firm_address_rejected:${address}`;
    console.warn(`[upsertDomainProperty] Refusing to write firm office address: "${address}" (${domain})`);
    return null;
  }

  // Round 76y (2026-04-27): trust the matcher's authoritative property_id
  // when present. handleIntakePromote stamps metadata.matcher_property_id
  // after intake-matcher resolves a numeric dia/gov property_id with
  // confidence. Without this trust path, upsertDomainProperty re-derives
  // the property via an address ilike — and the lookup can MISS the
  // already-resolved property when (a) the address format drifted between
  // matcher time and promote time, (b) ilike fails because of state-format
  // split (SC vs South Carolina), or (c) the CoStar sidebar later
  // overwrote entity.address with a slightly different spelling. Confirmed
  // root cause for property 37565 / Mayfair St duplicate: all three
  // promote runs of intake 73046be2 had matcher_pid=35423 but only the
  // first honored it. The 2nd and 3rd promotes' address ilike missed and
  // they CREATED 37565 + reused 37565 instead of finding 35423.
  // Strategy: short-circuit the lookup chain by pre-populating `lookup`
  // with the matcher's pid. The existing UPDATE flow further down then
  // applies snapshot fields to that property normally.
  const sizeCol = domain === 'government' ? 'rba' : 'building_size';
  const matcherPid = Number(metadata.matcher_property_id);
  let lookup;
  if (Number.isFinite(matcherPid) && matcherPid > 0) {
    const trustLookup = await domainQuery(domain, 'GET',
      `properties?property_id=eq.${matcherPid}&select=property_id,${sizeCol}&limit=1`);
    if (trustLookup.ok && trustLookup.data?.length) {
      console.log(`[upsertDomainProperty] Trusting matcher_property_id=${matcherPid} (skipping address lookup, ${domain})`);
      lookup = trustLookup;
    } else {
      console.warn(`[upsertDomainProperty] matcher_property_id=${matcherPid} not in ${domain} DB; falling back to address lookup`);
    }
  }

  // Try to find existing property by address. Normalize first so abbreviation
  // variants ("Street" vs "St", "Road" vs "Rd") resolve to the same record
  // instead of creating a duplicate every time CoStar spells it differently.
  const normAddr = normalizeAddress(address);
  // Skip address-based lookup if the matcher trust path above already
  // populated `lookup`.
  if (!lookup) {
    let lookupPath = `properties?address=ilike.${encodeURIComponent(normAddr)}` +
      `&select=property_id,${sizeCol}&limit=1`;
    if (entity.state) lookupPath += `&state=eq.${encodeURIComponent(entity.state)}`;
    if (entity.city)  lookupPath += `&city=ilike.${encodeURIComponent(entity.city)}`;
    lookup = await domainQuery(domain, 'GET', lookupPath);
  }

  // Fallback 0: if normalized-address ilike missed, retry with the RAW
  // address. Older sidebar-pipeline writes stored the un-normalized form
  // (e.g. "599 Court Street") so a normAddr ilike of "599 ct st" without
  // wildcards never matches them — ilike-without-wildcards is exact-match.
  // Without this, every re-promote of an OM whose address has expandable
  // suffixes (Street/Avenue/Boulevard/etc.) creates a new duplicate
  // property row. Net: ~107 duplicate_property_address issues across the
  // dia DB pre-fix (audit 2026-04-27).
  if (!lookup.data?.length && address && address !== normAddr) {
    let rawLookupPath = `properties?address=ilike.${encodeURIComponent(address)}` +
      `&select=property_id,${sizeCol}&limit=1`;
    if (entity.state) rawLookupPath += `&state=eq.${encodeURIComponent(entity.state)}`;
    if (entity.city)  rawLookupPath += `&city=ilike.${encodeURIComponent(entity.city)}`;
    const rawLookup = await domainQuery(domain, 'GET', rawLookupPath);
    if (rawLookup.ok && rawLookup.data?.length) {
      console.log(`[upsertDomainProperty] Raw-address fallback matched: "${address}" (normAddr "${normAddr}" missed)`);
      lookup = rawLookup;
    }
  }

  // Fallback 1: if city filter yielded no results, retry without city in case of
  // city-name variant mismatch ("MEMPHIS" vs "Memphis" vs "memphis" in DB).
  if (!lookup.data?.length && entity.city && entity.state) {
    const fallbackPath = `properties?address=ilike.${encodeURIComponent(normAddr)}` +
      `&state=eq.${encodeURIComponent(entity.state)}&select=property_id,${sizeCol}&limit=1`;
    const fallback = await domainQuery(domain, 'GET', fallbackPath);
    if (fallback.ok && fallback.data?.length) lookup = fallback;
  }

  // Fallback 2: street-suffix mismatch ("Dozier St" vs "Dozier Blvd").
  // Strip the suffix and search with a wildcard so the number + street name
  // portion is enough to match regardless of which suffix the DB has.
  if (!lookup.data?.length && entity.state) {
    const stripped = stripStreetSuffix(normAddr);
    if (stripped && stripped !== normAddr) {
      const suffixFallback = `properties?address=ilike.${encodeURIComponent(stripped + '*')}` +
        `&state=eq.${encodeURIComponent(entity.state)}&select=property_id,${sizeCol},address&limit=5`;
      const fb2 = await domainQuery(domain, 'GET', suffixFallback);
      if (fb2.ok && fb2.data?.length) {
        // If we got exactly one match, use it. If multiple, log and skip
        // to avoid linking to the wrong property.
        if (fb2.data.length === 1) {
          console.log(`[upsertDomainProperty] Suffix-stripped fallback matched: "${normAddr}" → "${fb2.data[0].address}" (${domain})`);
          lookup = fb2;
        } else {
          console.warn(`[upsertDomainProperty] Suffix-stripped fallback returned ${fb2.data.length} matches for "${stripped}*" — skipping ambiguous match`);
        }
      }
    }
  }

  // Anchored ^...$ regex of values that are CoStar UI text or section
  // labels we never want as a property tenant. Audit 2026-04-29 added
  // "my data" (8 conflicts/7d), "show" (4), "more", "less" — all
  // captured from CoStar collapse-toggle UI when extraction misfires.
  const INVALID_TENANT_VALUES = /^(public\s+record|building|building\s+info|land|market|market\s+data|sources|assessment|investment|not\s+disclosed|none|vacant|available|owner.occupied|confirmed|verified|research|buyer|seller|contacts|name|sf\s+occupied|analytics|reports|data|directory|stacking\s+plan|leasing|for\s+lease|for\s+sale|property\s+info|demographics|transit|walk\s+score|my\s+data|show|hide|view\s+more|view\s+less|more|less|expand|collapse)$/i;

  const rawTenant = selectPrimaryTenant(metadata, domain);
  // canonicalizeTenant collapses brand variants (DaVita, Fresenius,
  // Total Renal Care → DaVita Kidney Care) so the property's tenant
  // column is stable across captures. See _shared/tenant-canonical.js.
  const primaryTenant = (rawTenant && rawTenant.length > 2 && !INVALID_TENANT_VALUES.test(rawTenant))
    ? canonicalizeTenant(cleanTenantValue(rawTenant))
    : null;
  // Round 76ek.i: filter out federal-government anti-pattern owner candidates
  // when a private alternative exists (e.g. CoStar surfacing "U S A" because
  // ICE has personal property recorded at the address — not the real owner).
  const ownerContact = selectAuthoritativeOwner(metadata);
  // Belt-and-suspenders: warn if the chosen owner is the federal anti-pattern
  // (means there was no private alternative; the data may need manual review).
  if (ownerContact && isFederalOwnerAntiPattern(ownerContact.name)) {
    console.warn(
      `[upsertDomainProperty] property ${propertyId || '<new>'} ` +
      `recorded_owner_name="${ownerContact.name}" — federal anti-pattern accepted ` +
      `(no private alternative). Verify this is actually federally-owned.`
    );
  }

  // Build property data from CoStar metadata — domain-aware field names.
  // Dialysis build stays as-is; government overrides follow below because
  // the gov properties table uses a different column set entirely.
  // building_size fallback chain: CoStar square_footage → largest tenant SF → sf_leased
  let parsedSF = parseSF(metadata.square_footage);
  if (!parsedSF) {
    // Try tenant SF data as fallback
    const tenants = metadata.tenants || [];
    const tenantSFs = tenants.map(t => parseSF(t.sf)).filter(Boolean);
    if (tenantSFs.length > 0) {
      // For single-tenant properties, tenant SF ≈ building SF
      parsedSF = Math.max(...tenantSFs);
      console.log(`[upsertDomainProperty] building_size derived from tenant SF: ${parsedSF}`);
    }
  }
  if (!parsedSF) {
    parsedSF = parseSF(metadata.sf_leased);
    if (parsedSF) console.log(`[upsertDomainProperty] building_size derived from sf_leased: ${parsedSF}`);
  }
  // Round 76cw: detect captures from a historical CoStar sale comp page
  // (URL form /Comp/<id>/) or from a /Sale/<id>/ history record. Those
  // captures reflect the property's STATE AT THE TIME OF THAT SALE — the
  // tenant, rent, and lease commencement may all be obsolete by the
  // time the user pulls the comp into LCC. Writing those fields onto
  // the LIVE property row would silently overwrite curated current
  // values with stale historical ones (an audit found this caused
  // anchor_rent regressions where a 2018 sale's rent landed on a
  // property whose 2024 lease was the right anchor). Suppress the
  // current-state field writes when the source is a historical sale;
  // the sales_history block downstream still records the historical
  // sale row in sales_transactions, where it belongs.
  const isHistoricalCompCapture = !!(
    metadata._comp_id
    || metadata.is_historical_sale
    || /\/(Comp|Sale)\/\d+/i.test(String(metadata.page_url || metadata.url || ''))
  );
  if (isHistoricalCompCapture) {
    console.log(`[upsertDomainProperty] historical-sale-comp capture detected (comp_id=${metadata._comp_id}); suppressing tenant/rent/lease writes onto property row`);
  }

  const propertyData = stripNulls({
    // Store the NORMALIZED address (e.g. "599 ct st") so the address=ilike.<normAddr>
    // lookup at the top of this function can find this row on the next promote.
    // Storing the raw form ("599 Court Street") leaves the next lookup unable to
    // match it because PostgREST ilike-without-wildcards is exact case-insensitive
    // match, not abbreviation-expanding fuzzy match. Bug Z follow-up #10, 2026-04-27.
    address: normAddr,
    city: entity.city || null,
    state: entity.state || null,
    zip_code: entity.zip || null,
    county: metadata.county || entity.county || null,
    building_size: parsedSF,
    year_built: parseYearSafe(metadata.year_built),
    year_renovated: parseYearSafe(metadata.year_renovated),
    building_type: classifyBuildingType(metadata, entity, primaryTenant),
    // Round 76cw: only write tenant on non-historical captures.
    tenant: isHistoricalCompCapture ? null : primaryTenant,
    zoning: metadata.zoning || null,
    occupancy_percent: parsePercent(metadata.occupancy),
    parking_ratio: parseParkingRatio(metadata.parking),
    lot_sf: parseLotSF(metadata.land_sf) || parseLotSF(metadata.lot_size),
    assessed_value: parseCurrency(metadata.assessed_value),
    is_single_tenant: metadata.tenancy_type === 'Single' ? true : metadata.tenancy_type === 'Multi' ? false : null,
    property_ownership_type: metadata.ownership_type || null,
    // NOTE (dia denorm-drift, 2026-07-15): this writes the CoStar owner-panel name
    // independently of the FK recorded_owner_id (resolved later from the ownership
    // chain), which historically DRIFTED the two. The dia DB trigger
    // trg_dia_sync_recorded_owner_name now forces recorded_owner_name to mirror the
    // FK owner whenever the FK is set, so this write only "sticks" as a fallback
    // when the FK is still null (a not-yet-resolved owner). recorded_owner_id (FK)
    // is the single source of truth; do NOT rely on this column being independent.
    recorded_owner_name: ownerContact?.name || null,
    land_area: metadata.lot_size && /AC/i.test(metadata.lot_size) ? parseAcres(metadata.lot_size) : null,
    // Coordinates from CoStar Public Record tab (shared across both domains)
    latitude:  parseCoord(metadata.public_record?.latitude) || parseCoord(metadata.location?.latitude) || parseCoord(metadata.property?.latitude) || parseCoord(metadata.latitude),
    longitude: parseCoord(metadata.public_record?.longitude) || parseCoord(metadata.location?.longitude) || parseCoord(metadata.property?.longitude) || parseCoord(metadata.longitude),
    // Rent anchor + lease escalation (dialysis only — gov schema has no
    // anchor_rent columns). Only applied below when domain === 'dialysis'.
    // Round 76cw: suppress on historical-comp captures.
    anchor_rent:            isHistoricalCompCapture ? null : parseCurrency(metadata.anchor_rent),
    anchor_rent_date:       isHistoricalCompCapture ? null : parseDate(metadata.anchor_rent_date)?.split('T')[0] || null,
    anchor_rent_source:     isHistoricalCompCapture ? null : metadata.anchor_rent_source || null,
    lease_commencement:     isHistoricalCompCapture ? null : parseDate(metadata.lease_commencement)?.split('T')[0] || null,
    lease_bump_pct:         isHistoricalCompCapture ? null : (metadata.lease_bump_pct != null ? Number(metadata.lease_bump_pct) : null),
    lease_bump_interval_mo: isHistoricalCompCapture ? null : parseIntSafe(metadata.lease_bump_interval_mo),
  });

  if (domain === 'government') {
    // Government properties schema uses different column names
    const lotSF = parseSF(metadata.land_sf) || parseSF(metadata.lot_size);
    const lotAcres = lotSF ? Math.round(lotSF / 43560 * 100) / 100 : null;
    const landAcresRaw = metadata.lot_size && /AC/i.test(metadata.lot_size)
      ? parseAcres(metadata.lot_size) : null;

    // Mirror most-recent sale fields onto properties so v_sales_comps /
    // portfolio dashboards don't have to JOIN sales_transactions for
    // headline numbers. Sales are upserted in Step 5b immediately after
    // the property upsert, but the properties row also carries its own
    // latest_deed_date / latest_sale_price columns (migration
    // 20260326_public_record_property_signals.sql).
    let latestDeedDate = null;
    let latestSalePrice = null;
    {
      const sales = (metadata.sales_history || [])
        .filter(s => s && s.sale_date)
        .map(s => ({
          date: parseDate(s.sale_date)?.split('T')[0] || null,
          price: parseCurrency(s.sale_price),
          deed_type: s.deed_type || null,
        }))
        .filter(s => s.date
          && !(s.deed_type && MORTGAGE_DEED_TYPES.test(s.deed_type)));
      sales.sort((a, b) =>
        new Date(b.date).getTime() - new Date(a.date).getTime());
      if (sales.length) {
        latestDeedDate = sales[0].date;
        latestSalePrice = sales[0].price || null;
      }
    }

    Object.assign(propertyData, stripNulls({
      rba:               parsedSF,
      year_built:        parseYearSafe(metadata.year_built),
      year_renovated:    parseYearSafe(metadata.year_renovated),
      county:            metadata.county || entity.county || null,
      zip_code:          entity.zip || null,
      land_acres:        landAcresRaw || lotAcres,
      // Gov properties.building_type exists (sql/20260304_initial_schema.sql:35)
      // — preserve the classified value. Dialysis also has this column via
      // supabase/migrations/20260416210000_add_building_type_to_properties.sql.
      building_type:     classifyBuildingType(metadata, entity, primaryTenant),
      gov_occupancy_pct: parsePercent(metadata.occupancy),
      assessed_value:    parseCurrency(metadata.assessed_value),
      // Round 76cw: gov rent + lease fields suppressed on historical-comp
      // captures. The historical sale's annual_rent/lease_commencement
      // would otherwise overwrite the property's current GSA lease rent.
      gross_rent:        isHistoricalCompCapture ? null : parseCurrency(metadata.annual_rent),
      gross_rent_psf:    isHistoricalCompCapture ? null : parseCurrency(metadata.rent_per_sf),
      // gov.properties.noi exists (see migration
      // 20260423220000_gov_v_available_listings_enrichment.sql line 39)
      // and is what v_available_listings exposes to the UI. Without
      // this write, every CREXi capture of a govt-leased listing
      // discarded the NOI value the page advertised — the field
      // landed in entity metadata but never reached the gov DB.
      noi:               isHistoricalCompCapture ? null : parseCurrency(metadata.noi),
      lease_commencement: isHistoricalCompCapture ? null : parseDate(metadata.lease_commencement)?.split('T')[0] || null,
      lease_expiration:   isHistoricalCompCapture ? null : parseDate(metadata.lease_expiration)?.split('T')[0] || null,
      renewal_options:    isHistoricalCompCapture ? null : metadata.renewal_options || null,
      rent_escalations:   isHistoricalCompCapture ? null : metadata.rent_escalations || null,
      sf_leased:         isHistoricalCompCapture ? null : parseSF(metadata.sf_leased),
      agency:            isHistoricalCompCapture ? null : (primaryTenant || null),
      agency_full_name:  isHistoricalCompCapture ? null : (primaryTenant || null),
      // Mirror latest deed / sale from sales_history — these columns live
      // on the gov properties row independently of sales_transactions.
      latest_deed_date:  latestDeedDate,
      latest_sale_price: latestSalePrice,
      data_source:       'costar_sidebar',
    }));
    // Remove any dialysis-only fields that may have been set
    delete propertyData.lot_sf;
    delete propertyData.parking_ratio;
    delete propertyData.property_ownership_type;
    delete propertyData.tenant;
    delete propertyData.occupancy_percent;
    delete propertyData.zoning;
    delete propertyData.land_area;
    delete propertyData.is_single_tenant;
    delete propertyData.building_size;
    // gov.properties resolves owner via recorded_owner_id (uuid → recorded_owners),
    // not raw text. The shared propertyData carries `recorded_owner_name` from
    // ownerContact.name; sending it to gov produces a PostgREST column-not-found
    // and surfaces as `property_upsert_failed` to the sidebar (Round 76eq).
    delete propertyData.recorded_owner_name;
    // Rent anchor columns live on the dialysis properties table only
    delete propertyData.anchor_rent;
    delete propertyData.anchor_rent_date;
    delete propertyData.anchor_rent_source;
    delete propertyData.lease_bump_pct;
    delete propertyData.lease_bump_interval_mo;

    // Round 76fg (2026-05-15): defensive whitelist gate. The explicit-
    // delete pattern above is fragile — every new field added to the
    // shared propertyData object upstream has to be remembered here, and
    // a single miss yields a PostgREST "column not found" that surfaces
    // as the opaque 'property_upsert_failed' the user sees in the
    // sidebar (this is the third round in the 76eq → 76eq → 76fg arc
    // chasing this same class of bug, most recently for the RCA capture
    // at 3401 Northern Cross Blvd / NWS Fort Worth / GSA-NOAA tenant).
    // Whitelist what gov.properties actually accepts so any unknown key
    // can never reach the wire.
    const GOV_PROPERTY_COLUMNS = new Set([
      'address', 'city', 'state', 'zip_code', 'county',
      'latitude', 'longitude',
      'land_acres', 'year_built', 'year_renovated', 'rba', 'sf_leased',
      'gov_occupancy_pct', 'building_type', 'is_build_to_suit',
      'agency', 'agency_full_name', 'agency_canonical', 'agency_full',
      'government_type', 'lease_structure',
      'gross_rent', 'gross_rent_psf', 'noi', 'noi_psf',
      'expenses', 'noi_source', 'noi_as_of_date',
      'expense_ratio', 'estimated_expenses', 'estimated_value',
      'lease_commencement', 'lease_expiration', 'termination_date',
      'firm_term_years', 'firm_term_remaining',
      'total_term_years', 'term_remaining',
      'rent_escalations', 'renewal_options',
      'recorded_owner_id', 'true_owner_id', 'developer',
      'linked_gsa_lease_id', 'linked_frpp_id',
      'match_confidence', 'match_method',
      'investment_score', 'deal_grade',
      'status', 'data_source', 'notes',
      'lease_number', 'location_code',
      'normalized_address',
      'assessed_value', 'assessed_owner',
      'tax_delinquent', 'tax_delinquent_amount',
      'latest_deed_date', 'latest_deed_grantee',
      'latest_sale_price', 'latest_sale_grantor',
      'public_record_count',
      'comp_name', 'original_developer_contact_id',
      'base_year', 'base_year_taxes', 'base_year_opex',
      'current_annual_opex', 'current_re_taxes',
      'agency_id',
    ]);
    for (const k of Object.keys(propertyData)) {
      if (!GOV_PROPERTY_COLUMNS.has(k)) {
        console.warn(`[upsertDomainProperty] dropping unknown gov.properties column "${k}" from payload (defensive whitelist)`);
        delete propertyData[k];
      }
    }
  }

  if (lookup.ok && lookup.data?.length) {
    // Update existing property. Cap-rate anchor fields that get written here
    // are picked up by the end-of-propagateToDomainDbDirect recalc step
    // (Step 5g), which fires on every dialysis save and is idempotent.
    const propertyId = lookup.data[0].property_id;

    // ── Guard: protect building_size / rba from lease-area contamination ──
    // Hierarchy: (1) CoStar RBA from property tab, (2) existing DB value.
    // Never allow lease area (sf_leased) to overwrite building size.
    const existingSize = lookup.data[0][sizeCol];
    if (existingSize && existingSize > 0) {
      // DB already has a building size. Only overwrite if the incoming CoStar
      // value is clearly RBA (square_footage set AND different from sf_leased).
      // If sf_leased == square_footage, the extension may have picked up a
      // lease-area value that bled into the RBA field — keep existing.
      const incomingSF = parsedSF;
      const leasedSF = parseSF(metadata.sf_leased);
      if (!incomingSF || (leasedSF && incomingSF === leasedSF && incomingSF !== existingSize)) {
        console.log(`[upsertDomainProperty] Protecting ${sizeCol}: DB has ${existingSize}, ` +
          `incoming ${incomingSF || 'null'} matches sf_leased ${leasedSF || 'null'} — skipping overwrite`);
        delete propertyData.building_size;
        delete propertyData.rba;
      }
    }

    // Round 76co (Phase 2): consult priority registry BEFORE the property PATCH.
    const filteredPropertyData = await filterByFieldPriority({
      targetDb:    domain === 'dialysis' ? 'dia_db' : 'gov_db',
      targetTable: domain === 'dialysis' ? 'dia.properties' : 'gov.properties',
      recordPk:    propertyId,
      source:      isHistoricalCompCapture ? 'costar_sidebar_historical' : 'costar_sidebar',
      confidence:  isHistoricalCompCapture ? 0.4 : 0.6,
      fields:      propertyData,
    }).catch(err => {
      console.warn('[upsertDomainProperty] field-priority filter failed (proceeding with full patch):', err?.message);
      return propertyData;
    });
    await domainPatch(domain, `properties?property_id=eq.${propertyId}`, filteredPropertyData, 'upsertDomainProperty');
    if (domain === 'government' && metadata.lease_number) {
      await linkGsaLease(propertyId, metadata.lease_number, metadata);
    }
    return propertyId;
  }

  // Create new property. Tag the originating source on brand-new rows only
  // (metadata._source_tag, e.g. 'om_intake' from the create-from-intake flow)
  // so forensics can tell OM-created properties from CoStar captures. Injected
  // here, after the UPDATE path has returned, so it never re-stamps an existing
  // property. gov.properties uses `data_source`; dia.properties uses `source`.
  if (metadata._source_tag) {
    if (domain === 'government') propertyData.data_source = metadata._source_tag;
    else propertyData.source = metadata._source_tag;
  }
  const result = await domainQuery(domain, 'POST', 'properties', propertyData);
  if (result.ok && result.data) {
    const created = Array.isArray(result.data) ? result.data[0] : result.data;
    const newPropertyId = created?.property_id || null;
    if (newPropertyId && domain === 'government' && metadata.lease_number) {
      await linkGsaLease(newPropertyId, metadata.lease_number, metadata);
    }
    return newPropertyId;
  }

  // Round 76cs: write race recovery. When the user captures multiple
  // documents (deed/brochure/OM) on the same property simultaneously,
  // multiple sidebar-pipeline invocations all run their lookups before
  // any of them commit the insert. They all miss, all attempt INSERT,
  // one wins, the others get a constraint violation and return null.
  // Symptom: the LCC sidebar shows 'Pipeline error: property_upsert_
  // failed' twice then 'Pipeline re-ran successfully'.
  // Recovery: redo the lookup. By now the winning insert has committed;
  // we should find the row and treat as a regular update path.
  let retryLookup = await domainQuery(domain, 'GET',
    `properties?address=ilike.${encodeURIComponent(normAddr)}` +
    (entity.state ? `&state=eq.${encodeURIComponent(entity.state)}` : '') +
    (entity.city  ? `&city=ilike.${encodeURIComponent(entity.city)}`  : '') +
    `&select=property_id,${sizeCol}&limit=1`);
  if (!retryLookup.data?.length && address && address !== normAddr) {
    retryLookup = await domainQuery(domain, 'GET',
      `properties?address=ilike.${encodeURIComponent(address)}` +
      (entity.state ? `&state=eq.${encodeURIComponent(entity.state)}` : '') +
      (entity.city  ? `&city=ilike.${encodeURIComponent(entity.city)}`  : '') +
      `&select=property_id,${sizeCol}&limit=1`);
  }
  if (retryLookup.ok && retryLookup.data?.length) {
    const propertyId = retryLookup.data[0].property_id;
    console.log(`[upsertDomainProperty] Race recovery: original POST failed (${result.status}); retry-lookup found property_id=${propertyId} -- treating as update.`);
    // Round 76co (Phase 2): same priority filter on the race-recovery path.
    const filteredPropertyData = await filterByFieldPriority({
      targetDb:    domain === 'dialysis' ? 'dia_db' : 'gov_db',
      targetTable: domain === 'dialysis' ? 'dia.properties' : 'gov.properties',
      recordPk:    propertyId,
      source:      isHistoricalCompCapture ? 'costar_sidebar_historical' : 'costar_sidebar',
      confidence:  isHistoricalCompCapture ? 0.4 : 0.6,
      fields:      propertyData,
    }).catch(err => {
      console.warn('[upsertDomainProperty:retry] field-priority filter failed (proceeding with full patch):', err?.message);
      return propertyData;
    });
    await domainPatch(domain, `properties?property_id=eq.${propertyId}`, filteredPropertyData, 'upsertDomainProperty');
    if (domain === 'government' && metadata.lease_number) {
      await linkGsaLease(propertyId, metadata.lease_number, metadata);
    }
    return propertyId;
  }

  console.error(`[Sidebar pipeline] Failed to create ${domain} property:`, result.status, result.data);
  console.error(`  Address: "${address}" (normalized: "${normAddr}"), city=${entity.city}, state=${entity.state}`);
  console.error(`  propertyData keys (${Object.keys(propertyData).length}): ${Object.keys(propertyData).sort().join(',')}`);
  console.error(`  Retry-lookup also missed; this is not a write race -- likely a real validation failure.`);
  // Round 76fg: stash the PostgREST response so the caller can surface it
  // into entity.metadata._pipeline_last_error_detail. The message,
  // details, and hint fields come straight from PostgREST's JSON error
  // body (PGRST-coded), which is what the user actually needs to fix the
  // upstream payload — "column 'foo' does not exist", "violates check
  // constraint 'bar'", etc.
  const errBody = result?.data && typeof result.data === 'object' ? result.data : null;
  _lastDomainPropertyError = {
    status:        result?.status || null,
    message:       errBody?.message || (typeof result?.data === 'string' ? result.data.substring(0, 240) : null),
    details:       errBody?.details || null,
    hint:          errBody?.hint || null,
    code:          errBody?.code || null,
    domain,
    address,
    propertyDataKeys: Object.keys(propertyData).sort(),
  };
  // Round 76fg.b (2026-05-15): belt-and-suspenders. Round 76fg's
  // first attempt plumbed the captured error through the
  // propagateToDomainDbDirect return value into _pipeline_summary.
  // per_domain.<dom>.{error,error_detail}, but post-deploy retries
  // on the Northern Cross / NWS Fort Worth entity surfaced reason=
  // 'property_upsert_failed' WITHOUT the new fields — symptom of
  // either an old Railway image still in rotation or an Object-
  // spread quirk we haven't pinned down. Mutating the shared
  // metadata object here bypasses the return-value chain entirely:
  // processSidebarExtraction's final PATCH spreads `...metadata`
  // into updatedMeta (sidebar-pipeline.js:8677), so anything we set
  // here lands on entity.metadata._postgrest_capture on the next
  // wallclock write, regardless of how the per_domain summary is
  // assembled. Self-explaining failure mode = self-service fix.
  if (metadata && typeof metadata === 'object') {
    metadata._postgrest_capture = {
      captured_at: new Date().toISOString(),
      domain,
      address,
      table: 'properties',
      method: 'POST',
      http_status:        result?.status || null,
      postgrest_message:  errBody?.message || null,
      postgrest_details:  errBody?.details || null,
      postgrest_hint:     errBody?.hint || null,
      postgrest_code:     errBody?.code || null,
      // First 400 chars of the raw body in case PostgREST returns text
      // instead of structured JSON (rare — usually means infra-level
      // 502/504 surfaced as a 4xx by a proxy).
      raw_body_preview:
        typeof result?.data === 'string'
          ? result.data.substring(0, 400)
          : (errBody ? JSON.stringify(errBody).substring(0, 400) : null),
      property_data_keys: Object.keys(propertyData).sort(),
    };
  }
  return null;
}

/**
 * Look up a GSA lease by lease_number and link it to the property, pulling in
 * annual_rent, lease_expiration, sf_leased, agency, and government_type from
 * the GSA IOLP data already in the database.
 */
async function linkGsaLease(propertyId, leaseNumber, metadata = null) {
  if (!leaseNumber) return;

  // Find the GSA lease record
  const leaseLookup = await domainQuery('government', 'GET',
    `gsa_leases?lease_number=eq.${encodeURIComponent(leaseNumber)}` +
    `&select=lease_id,agency,agency_full_name,annual_rent,lease_expiration,` +
    `sf_leased,government_type&limit=1`
  );
  if (!leaseLookup.ok || !leaseLookup.data?.length) {
    console.log('[linkGsaLease] Lease not found in gsa_leases:', leaseNumber);
    return;
  }

  const lease = leaseLookup.data[0];

  // Guard against master-lease agency clobbering the CoStar-confirmed occupant.
  // A master GSA lease (e.g. LPA00668) can cover a building whose actual
  // occupant per CoStar is a sub-agency like FEMA. If the CoStar tenant
  // already resolves to a government_agencies row, treat that as the
  // authoritative occupant and do NOT overwrite the properties.agency /
  // agency_full_name / government_type fields with the umbrella lease's
  // values.
  const costarTenant = (metadata?.tenants?.[0]?.name
    || metadata?.tenant_name
    || metadata?.primary_tenant
    || null);
  let preserveCostarTenant = false;
  if (costarTenant) {
    const costarLookup = await domainQuery('government', 'GET',
      `government_agencies?full_name=ilike.*${encodeURIComponent(costarTenant)}*` +
      `&select=agency_id&limit=1`
    );
    if (costarLookup.ok && costarLookup.data?.length) {
      preserveCostarTenant = true;
      console.log('[linkGsaLease] CoStar tenant', JSON.stringify(costarTenant),
        'matched government_agencies — preserving tenant fields against lease',
        leaseNumber);
    }
  }

  // Always link the lease record and pull in lease-derived fields (SF, rent,
  // expiration). Only the tenant-identity fields are gated by the guard above.
  const patch = {
    linked_gsa_lease_id: lease.lease_id,
    lease_number:        leaseNumber,
    sf_leased:           lease.sf_leased || null,
    gross_rent:          lease.annual_rent || null,
    lease_expiration:    lease.lease_expiration || null,
  };
  if (!preserveCostarTenant) {
    patch.agency           = lease.agency || null;
    patch.agency_full_name = lease.agency_full_name || null;
    patch.government_type  = lease.government_type || null;
  }

  await domainPatch('government',
    `properties?property_id=eq.${propertyId}`,
    patch,
    'linkGsaLease'
  );

  console.log('[linkGsaLease] Linked lease', leaseNumber, 'to property', propertyId,
    preserveCostarTenant ? '(preserved CoStar tenant)' : '');
}

/**
 * Link a property to its government agency tenant in the property_agencies
 * junction table (government domain only, 43k rows).
 *
 * Schema (from information_schema):
 *   property_agency_id (uuid PK), property_id (bigint), agency_id (uuid),
 *   agency_code (text), government_type (text), sf_occupied (int),
 *   occupancy_pct (numeric), is_primary_tenant (bool), lease_number (text),
 *   lease_commencement (date), lease_expiration (date), annual_rent (numeric),
 *   rent_psf (numeric), status (text), move_in_date (date), move_out_date (date),
 *   data_source (text), notes (text), created_at (timestamptz), updated_at (timestamptz)
 *
 * government_agencies uses `full_name` (not `name`) for the agency display name.
 */
async function upsertPropertyAgency(propertyId, metadata) {
  const agencyName = metadata.tenants?.[0]?.name
    || metadata.tenant_name
    || metadata.primary_tenant
    || null;
  if (!agencyName) return 0;

  // Look up the agency in government_agencies by full_name
  const agencyLookup = await domainQuery('government', 'GET',
    `government_agencies?full_name=ilike.*${encodeURIComponent(agencyName)}*&select=agency_id,code,government_type&limit=1`
  );
  const agency = agencyLookup.ok && agencyLookup.data?.length
    ? agencyLookup.data[0] : null;

  if (!agency) {
    // Agency not in master list — skip for now (don't create unknown agencies)
    console.log('[upsertPropertyAgency] Agency not found in master list:', agencyName);
    return 0;
  }

  // Check existing link for this exact agency
  const existing = await domainQuery('government', 'GET',
    `property_agencies?property_id=eq.${propertyId}&agency_id=eq.${agency.agency_id}` +
    `&select=property_agency_id,is_primary_tenant,data_source&limit=1`
  );

  // Uniqueness/primacy invariant: at most one property_agencies row per
  // property may hold is_primary_tenant=true. Priority source for the
  // CoStar-driven sidebar pipeline is 'costar_sidebar', with 'frpp' as
  // an accepted peer (the FRPP loader is the other trusted writer). On
  // re-ingest we demote any primary row for this property whose
  // data_source is NEITHER of those trusted sources, then we insert or
  // promote the CoStar row to primary. The parallel select of
  // data_source is only so we can include it in the log.
  const PRIORITY_SOURCES = ['costar_sidebar', 'frpp'];
  const currentPrimaries = await domainQuery('government', 'GET',
    `property_agencies?property_id=eq.${propertyId}&is_primary_tenant=eq.true` +
    `&select=property_agency_id,agency_id,data_source&limit=10`
  );
  if (currentPrimaries.ok && Array.isArray(currentPrimaries.data)) {
    for (const row of currentPrimaries.data) {
      // Leave this row alone if it's already the CoStar-targeted agency
      // and came from a trusted source — we'll refresh it below. Only
      // demote OTHER primaries (different agency_id) or stale rows from
      // non-priority sources.
      const sameAgency = row.agency_id === agency.agency_id;
      const trustedSource = PRIORITY_SOURCES.includes(row.data_source);
      if (sameAgency && trustedSource) continue;
      await domainPatch('government',
        `property_agencies?property_agency_id=eq.${row.property_agency_id}`,
        { is_primary_tenant: false, updated_at: new Date().toISOString() },
        'upsertPropertyAgency:demote'
      );
      console.log('[upsertPropertyAgency] demoted primary',
        row.property_agency_id,
        'agency_id=', row.agency_id,
        'data_source=', row.data_source,
        'on property', propertyId);
    }
  }

  if (existing.ok && existing.data?.length) {
    // Already linked — always PATCH (even when no field changes) so the
    // row's updated_at advances on re-ingest. This is the audit signal
    // the ops team relies on to confirm CoStar actually touched the
    // property_agencies row during a refresh.
    const row = existing.data[0];
    await domainPatch('government',
      `property_agencies?property_agency_id=eq.${row.property_agency_id}`,
      {
        is_primary_tenant: true,
        agency_code:       agency.code || null,
        government_type:   agency.government_type || null,
        data_source:       'costar_sidebar',
        updated_at:        new Date().toISOString(),
      },
      'upsertPropertyAgency:refresh'
    );
    return 1;
  }

  // Create junction record — primary by default for the CoStar tenant.
  const r = await domainQuery('government', 'POST', 'property_agencies', {
    property_id:     propertyId,
    agency_id:       agency.agency_id,
    agency_code:     agency.code || null,
    government_type: agency.government_type || null,
    is_primary_tenant: true,
    data_source:     'costar_sidebar',
  });
  return r.ok ? 1 : 0;
}

/**
 * Upsert parcel_records and tax_records from CoStar Public Records section.
 * Writes APN, land value, and improvement value into both domain databases.
 *
 * Schema notes (from information_schema):
 *   Dialysis parcel_records: id (uuid PK), apn, county, state, assessed_value,
 *       data_hash (NOT NULL)
 *   Dialysis tax_records: id (uuid PK), apn, county, state, tax_year,
 *       assessed_value, data_hash (NOT NULL)
 *   Gov parcel_records: parcel_id (uuid PK), apn, county (NOT NULL),
 *       state_code (NOT NULL), land_value, improvement_value,
 *       total_assessed_value, assessment_year, data_hash
 *   Gov tax_records: tax_record_id (uuid PK), parcel_id (uuid FK),
 *       county (NOT NULL), state_code (NOT NULL), tax_year (NOT NULL),
 *       assessed_value, data_hash
 */
/**
 * Link a public record (parcel or tax) to a property via the property_public_records join table.
 * Deduplicates by property_id + record_type + record_id.
 */
async function linkPublicRecord(domain, propertyId, recordType, recordId) {
  try {
    // Check if link already exists
    const existing = await domainQuery(domain, 'GET',
      `property_public_records?property_id=eq.${propertyId}` +
      `&record_type=eq.${encodeURIComponent(recordType)}` +
      `&record_id=eq.${encodeURIComponent(recordId)}` +
      `&select=id&limit=1`
    );
    if (existing.ok && existing.data?.length) return; // already linked

    const r = await domainQuery(domain, 'POST', 'property_public_records', {
      property_id: propertyId,
      record_type: recordType,
      record_id:   recordId,
    });
    if (r.ok) {
      console.log(`[PublicRecords] Linked ${recordType} ${recordId} → property ${propertyId} (${domain})`);
    } else {
      console.error(`[PublicRecords] Failed to link ${recordType} → property ${propertyId}: status=${r.status}`, r.data);
    }
  } catch (err) {
    console.error(`[PublicRecords] linkPublicRecord error:`, err?.message);
  }
}

async function upsertPublicRecords(domain, propertyId, entity, metadata, provCollect) {
  // ── Diagnostic: log what the extension actually sent ──────────────────
  const pubRecFields = {
    parcel_number: metadata.parcel_number || null,
    land_value: metadata.land_value || null,
    improvement_value: metadata.improvement_value || null,
    assessed_value: metadata.assessed_value || null,
    county: metadata.county || null,
    tax_amount: metadata.tax_amount || null,
    assessment_years: metadata.assessment_years || null,   // multi-year (if extension sends)
    census_tract: metadata.census_tract || null,
    legal_description: metadata.legal_description || null,
    latitude: metadata.latitude || null,
    longitude: metadata.longitude || null,
  };
  console.log(`[PublicRecords] domain=${domain} property=${propertyId} input:`, JSON.stringify(pubRecFields));

  if (!metadata.parcel_number) {
    console.warn(`[PublicRecords] SKIP — no parcel_number in metadata for property ${propertyId}. ` +
      `Extension may not be scraping CoStar Public Record tab. Keys received: [${Object.keys(metadata).join(', ')}]`);
    return 0;
  }
  let count = 0;

  const apn       = metadata.parcel_number;
  const county    = metadata.county || entity.county || null;
  const landVal   = parseCurrency(metadata.land_value);
  const impVal    = parseCurrency(metadata.improvement_value);
  const assessed  = parseCurrency(metadata.assessed_value)
                    || (landVal && impVal ? landVal + impVal : null);
  const taxYear   = new Date().getFullYear();

  // ── parcel_records ──────────────────────────────────────────────────────
  if (domain === 'dialysis') {
    const parcelHash = Buffer.from(`parcel|${apn}|${entity.state || ''}`).toString('base64');
    const parcelLookup = await domainQuery('dialysis', 'GET',
      `parcel_records?apn=eq.${encodeURIComponent(apn)}&select=id&limit=1`
    );
    if (!parcelLookup.ok || !parcelLookup.data?.length) {
      const parcelData = stripNulls({
        apn,
        county,
        state:          entity.state || null,
        assessed_value: assessed,
        raw_payload:    {
          source: 'costar_sidebar', property_id: propertyId,
          census_tract: metadata.census_tract || null,
          legal_description: metadata.legal_description || null,
          construction_type: metadata.construction_type || null,
          far: metadata.far || null,
          assessment_years: metadata.assessment_years || null,
          tax_amount: metadata.tax_amount || null,
        },
        fetched_at:     metadata.extracted_at || new Date().toISOString(),
        data_hash:      parcelHash,
      });
      parcelData.data_hash = parcelHash;  // NOT NULL — ensure present after stripNulls
      const r = await domainQuery('dialysis', 'POST', 'parcel_records', parcelData);
      if (r.ok) {
        count++;
        console.log(`[PublicRecords] INSERT dialysis parcel_records OK — apn=${apn}`);
        // Link parcel → property via join table
        const createdParcel = Array.isArray(r.data) ? r.data[0] : r.data;
        const parcelRecordId = createdParcel?.id;
        if (parcelRecordId) {
          await linkPublicRecord('dialysis', propertyId, 'parcel', parcelRecordId);
          pushProvenance(provCollect, 'parcel_records', parcelRecordId, {
            apn, county, assessed_value: assessed,
          });
        }
      }
      else console.error(`[PublicRecords] INSERT dialysis parcel_records FAILED — apn=${apn} status=${r.status}`, r.data);
    } else {
      // Round 76co (Phase 5): consult priority registry before parcel PATCH.
      // CoStar's parcel data is aggregator-quality; county-records and OM
      // promoter both outrank it for these fields when they're present.
      const existingParcelId = parcelLookup.data[0]?.id;
      const filteredParcelPatch = await filterByFieldPriority({
        targetDb:    'dia_db',
        targetTable: 'dia.parcel_records',
        recordPk:    existingParcelId || apn,
        source:      'costar_sidebar',
        confidence:  0.6,
        fields:      { assessed_value: assessed, county },
      }).catch(err => {
        console.warn('[upsertPublicRecords:dia:parcel] field-priority filter failed (proceeding with full patch):', err?.message);
        return { assessed_value: assessed, county };
      });
      let _parcelPatchRes = { ok: true }; // default: nothing to patch → no failure
      if (filteredParcelPatch && Object.keys(filteredParcelPatch).length > 0) {
        _parcelPatchRes = await domainPatch('dialysis',
          `parcel_records?apn=eq.${encodeURIComponent(apn)}`,
          filteredParcelPatch,
          'upsertPublicRecords:dialysis:parcel'
        );
      }
      // Ensure join table link exists for existing parcel
      if (existingParcelId) {
        await linkPublicRecord('dialysis', propertyId, 'parcel', existingParcelId);
        // Item #5 Phase B gating: only push provenance if the PATCH actually
        // succeeded. Prevents recording provenance for a write that 4xx'd.
        pushProvenance(provCollect, 'parcel_records', existingParcelId, {
          apn, county, assessed_value: assessed,
        }, undefined, undefined, _parcelPatchRes);
      }
    }
  }

  if (domain === 'government') {
    const parcelLookup = await domainQuery('government', 'GET',
      `parcel_records?apn=eq.${encodeURIComponent(apn)}&select=parcel_id&limit=1`
    );
    if (!parcelLookup.ok || !parcelLookup.data?.length) {
      const parcelHash = Buffer.from(`parcel|${apn}|${entity.state || ''}`).toString('base64');
      const parcelData = stripNulls({
        apn,
        county:               county || 'Unknown',
        state_code:           entity.state || 'XX',
        land_value:           landVal,
        improvement_value:    impVal,
        total_assessed_value: assessed,
        assessment_year:      taxYear,
        situs_address:        entity.address || null,
        raw_payload:          {
          source: 'costar_sidebar', property_id: propertyId,
          census_tract: metadata.census_tract || null,
          legal_description: metadata.legal_description || null,
          fips_code: metadata.fips_code || null,
          construction_type: metadata.construction_type || null,
          far: metadata.far || null,
          assessment_years: metadata.assessment_years || null,
          tax_amount: metadata.tax_amount || null,
        },
        fetched_at:           metadata.extracted_at || new Date().toISOString(),
        data_hash:            parcelHash,
      });
      const r = await domainQuery('government', 'POST', 'parcel_records', parcelData);
      if (r.ok) {
        count++;
        console.log(`[PublicRecords] INSERT gov parcel_records OK — apn=${apn}`);
        // Link parcel → property via join table (if gov has property_public_records)
        const createdParcel = Array.isArray(r.data) ? r.data[0] : r.data;
        const parcelRecordId = createdParcel?.parcel_id;
        if (parcelRecordId) {
          await linkPublicRecord('government', propertyId, 'parcel', parcelRecordId);
          pushProvenance(provCollect, 'parcel_records', parcelRecordId, {
            apn, county, land_value: landVal, improvement_value: impVal,
            total_assessed_value: assessed,
          });
        }
      }
      else console.error(`[PublicRecords] INSERT gov parcel_records FAILED — apn=${apn} status=${r.status}`, r.data);
    } else {
      // Round 76co (Phase 5): same priority filter on the gov parcel path.
      const existingParcelId = parcelLookup.data[0]?.parcel_id;
      const govParcelPatch = stripNulls({
        land_value:           landVal,
        improvement_value:    impVal,
        total_assessed_value: assessed,
        assessment_year:      taxYear,
      });
      const filteredGovParcelPatch = await filterByFieldPriority({
        targetDb:    'gov_db',
        targetTable: 'gov.parcel_records',
        recordPk:    existingParcelId || apn,
        source:      'costar_sidebar',
        confidence:  0.6,
        fields:      govParcelPatch,
      }).catch(err => {
        console.warn('[upsertPublicRecords:gov:parcel] field-priority filter failed (proceeding with full patch):', err?.message);
        return govParcelPatch;
      });
      if (filteredGovParcelPatch && Object.keys(filteredGovParcelPatch).length > 0) {
        await domainPatch('government',
          `parcel_records?apn=eq.${encodeURIComponent(apn)}`,
          filteredGovParcelPatch,
          'upsertPublicRecords:gov:parcel'
        );
      }
      if (existingParcelId) {
        await linkPublicRecord('government', propertyId, 'parcel', existingParcelId);
        pushProvenance(provCollect, 'parcel_records', existingParcelId, {
          apn, county, land_value: landVal, improvement_value: impVal,
          total_assessed_value: assessed,
        });
      }
    }
  }

  // ── tax_records ─────────────────────────────────────────────────────────
  // Build list of year/value pairs — prefer multi-year from extension, fallback to single current year
  const taxYears = [];
  if (Array.isArray(metadata.assessment_years) && metadata.assessment_years.length > 0) {
    for (const row of metadata.assessment_years) {
      const yr = row.year || row.tax_year;
      const val = parseCurrency(row.total) || parseCurrency(row.assessed_value)
                  || (parseCurrency(row.land) && parseCurrency(row.improvements)
                      ? parseCurrency(row.land) + parseCurrency(row.improvements) : null);
      if (yr && val) taxYears.push({ year: yr, assessed: val, land: parseCurrency(row.land), imp: parseCurrency(row.improvements) });
    }
    console.log(`[PublicRecords] Multi-year assessment data: ${taxYears.length} years from extension`);
  }
  if (taxYears.length === 0 && assessed) {
    taxYears.push({ year: taxYear, assessed, land: landVal, imp: impVal });
  }

  if (domain === 'dialysis') {
    for (const ty of taxYears) {
      const taxHash = Buffer.from(`tax|${apn}|${ty.year}`).toString('base64');
      const taxLookup = await domainQuery('dialysis', 'GET',
        `tax_records?apn=eq.${encodeURIComponent(apn)}&tax_year=eq.${ty.year}&select=id&limit=1`
      );
      if (!taxLookup.ok || !taxLookup.data?.length) {
        const taxData = stripNulls({
          apn,
          county,
          state:          entity.state || null,
          tax_year:       ty.year,
          assessed_value: ty.assessed,
          raw_payload:    { source: 'costar_sidebar', land_value: ty.land, improvement_value: ty.imp },
          fetched_at:     metadata.extracted_at || new Date().toISOString(),
          data_hash:      taxHash,
        });
        taxData.data_hash = taxHash;  // NOT NULL — ensure present after stripNulls
        const r = await domainQuery('dialysis', 'POST', 'tax_records', taxData);
        if (r.ok) {
          count++;
          console.log(`[PublicRecords] INSERT dialysis tax_records OK — apn=${apn} year=${ty.year}`);
          const createdTax = Array.isArray(r.data) ? r.data[0] : r.data;
          if (createdTax?.id) {
            await linkPublicRecord('dialysis', propertyId, 'tax', createdTax.id);
            pushProvenance(provCollect, 'tax_records', createdTax.id, {
              apn, tax_year: ty.year, assessed_value: ty.assessed,
            });
          }
        }
        else console.error(`[PublicRecords] INSERT dialysis tax_records FAILED — apn=${apn} year=${ty.year} status=${r.status}`, r.data);
      } else {
        // Round 76co (Phase 5): priority gate on tax_records updates.
        const existingTaxId = taxLookup.data[0]?.id;
        const filteredTaxPatch = await filterByFieldPriority({
          targetDb:    'dia_db',
          targetTable: 'dia.tax_records',
          recordPk:    existingTaxId || `${apn}|${ty.year}`,
          source:      'costar_sidebar',
          confidence:  0.6,
          fields:      { assessed_value: ty.assessed },
        }).catch(err => {
          console.warn('[upsertPublicRecords:dia:tax] field-priority filter failed (proceeding with full patch):', err?.message);
          return { assessed_value: ty.assessed };
        });
        if (filteredTaxPatch && Object.keys(filteredTaxPatch).length > 0) {
          await domainPatch('dialysis',
            `tax_records?apn=eq.${encodeURIComponent(apn)}&tax_year=eq.${ty.year}`,
            filteredTaxPatch,
            'upsertPublicRecords:dialysis:tax'
          );
        }
        if (existingTaxId) {
          await linkPublicRecord('dialysis', propertyId, 'tax', existingTaxId);
          pushProvenance(provCollect, 'tax_records', existingTaxId, {
            apn, tax_year: ty.year, assessed_value: ty.assessed,
          });
        }
      }
    }
  }

  if (domain === 'government' && taxYears.length > 0) {
    // Gov tax_records requires parcel_id FK — look up parcel first
    const parcelLookup = await domainQuery('government', 'GET',
      `parcel_records?apn=eq.${encodeURIComponent(apn)}&select=parcel_id&limit=1`
    );
    const parcelId = parcelLookup.ok && parcelLookup.data?.length
      ? parcelLookup.data[0].parcel_id
      : null;

    for (const ty of taxYears) {
      const taxLookup = parcelId
        ? await domainQuery('government', 'GET',
            `tax_records?parcel_id=eq.${parcelId}&tax_year=eq.${ty.year}&select=tax_record_id&limit=1`)
        : { ok: false, data: [] };

      if (!taxLookup.ok || !taxLookup.data?.length) {
        const taxHash = Buffer.from(`tax|${apn}|${entity.state || ''}|${ty.year}`).toString('base64');
        const taxData = stripNulls({
          parcel_id:      parcelId,
          county:         county || 'Unknown',
          state_code:     entity.state || 'XX',
          tax_year:       ty.year,
          assessed_value: ty.assessed,
          raw_payload:    { source: 'costar_sidebar', land_value: ty.land, improvement_value: ty.imp },
          fetched_at:     metadata.extracted_at || new Date().toISOString(),
          data_hash:      taxHash,
        });
        const r = await domainQuery('government', 'POST', 'tax_records', taxData);
        if (r.ok) {
          count++;
          console.log(`[PublicRecords] INSERT gov tax_records OK — apn=${apn} year=${ty.year}`);
          const createdTax = Array.isArray(r.data) ? r.data[0] : r.data;
          if (createdTax?.tax_record_id) {
            pushProvenance(provCollect, 'tax_records', createdTax.tax_record_id, {
              tax_year: ty.year, assessed_value: ty.assessed,
            });
          }
        }
        else console.error(`[PublicRecords] INSERT gov tax_records FAILED — apn=${apn} year=${ty.year} status=${r.status}`, r.data);
      } else {
        // Round 76co (Phase 5): priority gate on gov tax_records updates.
        const existingTaxRecordId = taxLookup.data[0]?.tax_record_id;
        const filteredGovTaxPatch = await filterByFieldPriority({
          targetDb:    'gov_db',
          targetTable: 'gov.tax_records',
          recordPk:    existingTaxRecordId || `${parcelId}|${ty.year}`,
          source:      'costar_sidebar',
          confidence:  0.6,
          fields:      { assessed_value: ty.assessed },
        }).catch(err => {
          console.warn('[upsertPublicRecords:gov:tax] field-priority filter failed (proceeding with full patch):', err?.message);
          return { assessed_value: ty.assessed };
        });
        if (filteredGovTaxPatch && Object.keys(filteredGovTaxPatch).length > 0) {
          await domainPatch('government',
            `tax_records?parcel_id=eq.${parcelId}&tax_year=eq.${ty.year}`,
            filteredGovTaxPatch,
            'upsertPublicRecords:gov:tax'
          );
        }
        if (existingTaxRecordId) {
          pushProvenance(provCollect, 'tax_records', existingTaxRecordId, {
            tax_year: ty.year, assessed_value: ty.assessed,
          });
        }
      }
    }
  }

  return count;
}

// A "Bulk/Portfolio Sale" stamps the WHOLE deal's aggregate price onto the one
// subject property the sidebar captured — implausible as that property's
// per-property sold_price and corrupting NBA value + cap-rate math (the SVEA
// New Mexico portfolio: a $119.08M deal aggregate landing on 445 Camino Del Rey
// Dr, whose real per-property price was $8.02M). detectSalePriceBleed() only
// catches this once a SECOND constituent property arrives with the same
// price+date — the FIRST/only capture has no sibling — so this is the
// self-evident signal read straight off the sale itself. A per-property-
// allocated record (set by the portfolio unpacker, which carries the row's own
// real price from the Properties table) is exempt via _per_property_allocated.
export function isPortfolioAggregateSale(sale) {
  if (!sale || sale._per_property_allocated) return false;
  const cond = String(sale.sale_condition || '').toLowerCase();
  if (/\b(bulk|portfolio)\b/.test(cond)) return true;
  const ttype = String(sale.transaction_type || sale.sale_type || '').toLowerCase();
  if (/\bportfolio\b/.test(ttype)) return true;
  const notes = String(sale.sale_notes_raw || '').toLowerCase();
  // "...the sale of 40 suburban office buildings...", "portfolio of 12 properties"
  if (/\bsale of\s+\d{1,3}\s+[\w-]+\s+(?:office\s+)?(?:building|propert|asset|facilit)/.test(notes)) return true;
  if (/\bportfolio of\s+\d{1,3}\b/.test(notes)) return true;
  return false;
}

// ── Portfolio constituent unpacking (Bulk/Portfolio Sale) ───────────────────
//
// A CoStar Bulk/Portfolio Sale Comp page captures one SUBJECT property + the
// whole deal aggregate, plus (via the extension's _portfolio-parse.js) a
// portfolio_properties[] table of every constituent. These pure helpers turn
// the deal + each constituent into the {entity, metadata} inputs the existing
// upsertDomainProperty + upsertDomainSales writers consume — so constituents
// ride the SAME address-normalized match/create/dedupe + sale-write path as any
// capture, each carrying its OWN per-property price (not the deal aggregate).

// Pick the deal-level fields off the subject's most-recent (portfolio) sale.
export function derivePortfolioDeal(metadata) {
  const hist = Array.isArray(metadata.sales_history) ? metadata.sales_history : [];
  // Prefer an explicit Bulk/Portfolio row; else the most-recent dated sale.
  let deal = hist.find((s) => isPortfolioAggregateSale(s));
  if (!deal) {
    let best = null; let bestT = -Infinity;
    for (const s of hist) {
      const t = new Date(s && s.sale_date).getTime();
      if (Number.isFinite(t) && t > bestT) { bestT = t; best = s; }
    }
    deal = best || hist[0] || {};
  }
  return {
    sale_date:        deal.sale_date || metadata.sale_date || null,
    buyer:            deal.buyer || deal.buyer_name || metadata.buyer || metadata.buyer_name || null,
    seller:           deal.seller || deal.seller_name || metadata.seller || metadata.seller_name || null,
    sale_condition:   deal.sale_condition || null,
    sale_notes_raw:   deal.sale_notes_raw || metadata.sale_notes_raw || null,
    total_deal_price: deal.sale_price || metadata.sale_price || null,
    asset_type:       metadata.asset_type || null,
    document_links:   Array.isArray(deal.document_links) ? deal.document_links : null,
  };
}

// Build the {entity, metadata} inputs for ONE constituent. Its own table price
// is the per-property allocation; _per_property_allocated exempts it from the
// aggregate-null guard. The deal's sale notes ride along so the constituent
// classifies into the same domain (gov tenant signal lives in the notes).
export function buildConstituentInputs(domain, deal, c) {
  if (!c || !c.address) return null;
  const sizeKey = domain === 'government' ? 'rba' : 'building_size';
  const priceNum = (c.sale_price != null && Number.isFinite(Number(c.sale_price)))
    ? Number(c.sale_price) : null;
  const sale = {
    sale_date:        deal.sale_date || null,
    sale_price:       priceNum != null ? `$${priceNum.toLocaleString('en-US')}` : null,
    buyer:            deal.buyer || null,
    seller:           deal.seller || null,
    sale_condition:   deal.sale_condition || null,
    sale_notes_raw:   deal.sale_notes_raw || null,
    transaction_type: 'Portfolio',
    document_links:   deal.document_links || undefined,
    _per_property_allocated: true,
    _portfolio_constituent:  true,
  };
  const entity = {
    address: c.address,
    city:    c.city || null,
    state:   c.state || null,
    name:    c.address,
    domain,
  };
  const metadata = {
    address:        c.address,
    city:           c.city || null,
    state:          c.state || null,
    asset_type:     deal.asset_type || null,
    property_type:  c.property_type || null,
    ...(c.size_sf != null ? { [sizeKey]: c.size_sf, square_footage: c.size_sf } : {}),
    // Carry the deal narrative so the constituent classifies into the same
    // domain as the parent capture (the gov tenant signal is in the notes).
    sale_notes_raw: deal.sale_notes_raw || null,
    sales_history:  [sale],
  };
  return { entity, metadata };
}

function classifySaleType(sale) {
  // C2 Part C (2026-05-27): consult multiple signals, not just the
  // sale.sale_type/transaction_type CoStar field (which is empty 90%+ of
  // the time). Falls through to the SQL-side backfill patterns so new
  // captures classify with the same rules as the historical run.
  const raw = (sale.sale_type || sale.transaction_type || '').toLowerCase();
  const deedType = (sale.deed_type || '').toLowerCase();
  const buyer = (sale.buyer || sale.buyer_name || '').toLowerCase().trim();
  const seller = (sale.seller || sale.seller_name || '').toLowerCase().trim();
  const notes = (sale.sale_notes_raw || '').toLowerCase();

  // Combined haystack for keyword searches
  const hay = `${raw} ${deedType} ${notes}`;

  if (/\b(land\s+sale|vacant\s+land|ground\s+lease|pre[\s-]?development|pre development)\b/.test(hay)) {
    return { transaction_type: 'Land Sale', exclude_from_market_metrics: true };
  }
  if (/\btrustee\s+(deed|sale)\b/.test(hay)) {
    return { transaction_type: 'Foreclosure', exclude_from_market_metrics: true };
  }
  if (buyer && seller && buyer === seller) {
    return { transaction_type: 'Nominal Transfer', exclude_from_market_metrics: true };
  }
  if (/owner\s+user|owner-user|owner occupied|\buser\b/.test(hay)) {
    return { transaction_type: 'Owner-User', exclude_from_market_metrics: true };
  }
  if (/\bportfolio\b/.test(hay)) {
    return { transaction_type: 'Portfolio', exclude_from_market_metrics: false };
  }
  if (/1031|\bexchange\b/.test(hay)) {
    return { transaction_type: '1031 Exchange', exclude_from_market_metrics: false };
  }
  if (/\bbts\b|build[\s-]?to[\s-]?suit|built to suit/.test(hay)) {
    return { transaction_type: 'Build-to-Suit', exclude_from_market_metrics: false };
  }
  if (/\bnominal\b|\brelated\s+party\b/.test(hay)) {
    return { transaction_type: 'Nominal Transfer', exclude_from_market_metrics: true };
  }
  if (/\binvestment\b|\bresale\b/.test(hay)) {
    return { transaction_type: 'Investment', exclude_from_market_metrics: false };
  }
  // Default for normal arm's-length deeds with a real sale price
  if (/\b(warranty\s+deed|grant\s+deed|special\s+warranty)\b/.test(hay)) {
    const price = Number(sale.sale_price || sale.sold_price);
    if (Number.isFinite(price) && price > 50000) {
      return { transaction_type: 'Investment', exclude_from_market_metrics: false };
    }
  }
  return { transaction_type: null, exclude_from_market_metrics: false };
}

/**
 * Re-route a record that looked like a sale but is actually a listing
 * (asking price, on-market, missing sale_date/sold_price) into
 * available_listings. Logs with the [listing-misroute] prefix so the
 * misroutes are auditable.
 */
async function routeListingMisroute(domain, propertyId, saleRow, reasons) {
  const rawPrice = Number(saleRow?.sold_price);
  const listPrice = Number.isFinite(rawPrice) && rawPrice > 0 ? rawPrice : null;
  const notesVal = saleRow?.notes || null;

  const record = {
    property_id: domain === 'dialysis' ? parseInt(propertyId, 10) : propertyId,
    list_price: listPrice,
    status: 'off_market',
    notes: notesVal,
    data_source: 'costar_sidebar',
  };

  console.warn(
    `[listing-misroute] rerouting ${domain} property=${propertyId} to available_listings`,
    {
      list_price: listPrice,
      notes: notesVal,
      transaction_type: saleRow?.transaction_type || null,
      sale_date: saleRow?.sale_date || null,
      reasons,
    }
  );

  const result = await domainQuery(domain, 'POST', 'available_listings', record);
  if (!result.ok) {
    console.error('[listing-misroute] available_listings insert failed', {
      domain,
      propertyId,
      status: result.status,
      data: result.data,
      record,
    });
  }
  return result.ok;
}

/**
 * One-time audit helper: scan sales_transactions in both dialysis and
 * government DBs for rows where sale_date IS NULL and log them so we
 * can review and backfill/remove manually. Runs at most once per
 * process lifetime (guarded by `_nullSaleDateAuditDone`).
 */
let _nullSaleDateAuditDone = false;
async function auditNullSaleDates() {
  if (_nullSaleDateAuditDone) return;
  _nullSaleDateAuditDone = true;

  for (const domain of ['dialysis', 'government']) {
    try {
      if (!getDomainCredentials(domain)) continue;
      const selectCols = domain === 'government'
        ? 'sale_id,property_id,sale_date,sold_price,buyer,seller,transaction_type,data_source'
        : 'sale_id,property_id,sale_date,sold_price,buyer_name,seller_name,transaction_type,notes,data_source';
      const result = await domainQuery(domain, 'GET',
        `sales_transactions?sale_date=is.null&select=${selectCols}&limit=500`
      );
      if (!result.ok) {
        console.error(
          `[null-sale-date-audit] ${domain}: query failed status=${result.status}`
        );
        continue;
      }
      const rows = result.data || [];
      if (!rows.length) {
        console.log(`[null-sale-date-audit] ${domain}: clean, 0 null-sale_date rows`);
        continue;
      }
      console.warn(
        `[null-sale-date-audit] ${domain}: ${rows.length} sales_transactions rows have sale_date IS NULL — review manually`
      );
      for (const row of rows) {
        console.warn(`[null-sale-date-audit] ${domain} row`, JSON.stringify(row));
      }
    } catch (err) {
      console.error(
        `[null-sale-date-audit] ${domain}: error`,
        err?.message || err
      );
    }
  }
}

/**
 * Find the available_listings.listing_id that best represents the listing
 * campaign a given sale came from. Matches on property_id with a
 * listing_date within 180 days of sale_date — the closest preceding
 * listing wins; if none precede, the closest listing within the 180-day
 * window (future direction) is used. Returns null when no listing is in
 * range, signalling an off-market / private sale.
 *
 * Dialysis only (government sales_transactions has no listing_sale_id
 * column in the current schema).
 */
async function findMatchingListingForSale(domain, propertyId, saleDate) {
  if (domain !== 'dialysis') return null;
  const datePart = String(saleDate || '').split('T')[0];
  if (!datePart) return null;
  try {
    const propertyIdInt = parseInt(propertyId, 10);
    const lookup = await domainQuery('dialysis', 'GET',
      `available_listings?property_id=eq.${propertyIdInt}` +
      `&select=listing_id,listing_date&limit=200`
    );
    if (!lookup.ok || !Array.isArray(lookup.data) || !lookup.data.length) {
      return null;
    }
    const saleMs = new Date(datePart).getTime();
    const WINDOW_MS = 180 * 24 * 60 * 60 * 1000;
    let best = null;
    for (const row of lookup.data) {
      if (!row.listing_date) continue;
      const listMs = new Date(String(row.listing_date).split('T')[0]).getTime();
      if (!Number.isFinite(listMs)) continue;
      const diff = saleMs - listMs; // positive = listing preceded sale
      if (Math.abs(diff) > WINDOW_MS) continue;
      // Prefer listings that preceded the sale; among those pick closest.
      const candidate = { listingId: row.listing_id, diff };
      if (!best) { best = candidate; continue; }
      const bestPreceded = best.diff >= 0;
      const candPreceded = candidate.diff >= 0;
      if (bestPreceded && !candPreceded) continue;
      if (!bestPreceded && candPreceded) { best = candidate; continue; }
      if (Math.abs(candidate.diff) < Math.abs(best.diff)) best = candidate;
    }
    return best?.listingId ?? null;
  } catch (err) {
    console.error('[listing-match] error', {
      domain, propertyId, saleDate: datePart, error: err?.message || String(err),
    });
    return null;
  }
}

/**
 * After a listing is inserted or updated, link any sales_transactions rows
 * for the same property whose sale_date is within 180 days of this
 * listing's listing_date and which currently have listing_sale_id=null.
 * This handles the normal pipeline ordering (sales written before the
 * listing that produced them): the sale-time match returns null for the
 * just-being-created listing, then this backfill associates them.
 * Dialysis only. Never throws.
 */
async function backfillListingSaleIdForListing(domain, { listingId, propertyId, listingDate }) {
  if (domain !== 'dialysis') return 0;
  if (listingId == null) return 0;
  const listDatePart = String(listingDate || '').split('T')[0];
  if (!listDatePart) return 0;
  try {
    const listMs = new Date(listDatePart).getTime();
    if (!Number.isFinite(listMs)) return 0;
    const WINDOW_MS = 180 * 24 * 60 * 60 * 1000;
    const loStr = new Date(listMs - WINDOW_MS).toISOString().split('T')[0];
    const hiStr = new Date(listMs + WINDOW_MS).toISOString().split('T')[0];
    const patchPath =
      `sales_transactions?property_id=eq.${propertyId}` +
      `&sale_date=gte.${loStr}&sale_date=lte.${hiStr}` +
      `&listing_sale_id=is.null`;
    const res = await domainPatch('dialysis', patchPath,
      { listing_sale_id: listingId },
      'backfillListingSaleIdForListing'
    );
    if (res?.ok !== false) {
      console.log(
        `[listing-backfill] domain=dialysis listing_id=${listingId} ` +
        `property_id=${propertyId} window=${loStr}..${hiStr}`
      );
    }
    return 1;
  } catch (err) {
    console.error('[listing-backfill] error', {
      listingId, propertyId, listingDate: listDatePart,
      error: err?.message || String(err),
    });
    return 0;
  }
}

/**
 * Choose which government available_listings row a sales_transactions sale
 * should close. Returns the listing whose listing_date is closest in time to
 * the sale_date and within a 3-year window on either side; ties are broken
 * in favor of the listing on-or-before the sale date (the listing that
 * "produced" the sale). Returns null when no candidate falls inside the
 * window — caller logs `skipped=no_match_in_3yr_window` and leaves the
 * listings alone for human review.
 *
 * The 3-year window prevents one stale listing from being closed by an
 * unrelated sale years later. The dialysis branch closes ALL active listings
 * unconditionally because the dialysis dataset is small and curated; gov is
 * larger and messier, so the rule is more conservative.
 *
 * @param {Array<{listing_id: number|string, listing_date: string|null}>} rows
 *   Candidate active listings for the property.
 * @param {string} saleDate ISO YYYY-MM-DD date of the sale.
 * @returns {{listing_id, listing_date}|null}
 */
const PICK_CLOSEST_WINDOW_DAYS = 3 * 365 + 1; // 3 years + leap-year cushion
export function pickClosestListing(rows, saleDate) {
  if (!Array.isArray(rows) || rows.length === 0) return null;
  const saleMs = Date.parse(saleDate);
  if (!Number.isFinite(saleMs)) return null;

  const windowMs = PICK_CLOSEST_WINDOW_DAYS * 24 * 60 * 60 * 1000;
  let best = null;
  let bestDist = Infinity;
  let bestSign = 1; // +1 = listing_date AFTER sale_date, -1 = on-or-before

  for (const row of rows) {
    const listingMs = row?.listing_date ? Date.parse(row.listing_date) : NaN;
    if (!Number.isFinite(listingMs)) continue;
    const diff = listingMs - saleMs;
    const dist = Math.abs(diff);
    if (dist > windowMs) continue;
    const sign = diff <= 0 ? -1 : 1;
    // Smaller distance wins. On exact tie, prefer the listing on-or-before
    // (sign = -1) — that's the listing the sale most likely closed.
    if (dist < bestDist || (dist === bestDist && sign < bestSign)) {
      best = row;
      bestDist = dist;
      bestSign = sign;
    }
  }
  return best;
}

/**
 * After a sales_transactions row is written for a property, close any
 * available_listings rows still flagged as active/Active for the same
 * property. Applies to both dialysis and government domains, using each
 * domain's native column set:
 *   dialysis:   is_active=false, status='Sold', sold_date, off_market_date,
 *               sale_transaction_id (when provided), sold_price (when provided)
 *   government: listing_status='Sold', off_market_date, updated_at
 * Logs one line per closed listing with the [listing-close] prefix.
 * Never throws — listing-close failures must not abort the sales write.
 *
 * @param {'dialysis'|'government'} domain
 * @param {string|number} propertyId
 * @param {string} saleDate        — YYYY-MM-DD (sale_date of the transaction)
 * @param {number|null} [soldPrice] — sold_price from that sales_transactions
 *                                    row; written onto the dialysis listing
 *                                    row as sold_price.
 * @param {number|null} [saleId]   — sales_transactions.sale_id of the sale that
 *                                   just closed; written onto the dialysis
 *                                   listing row as sale_transaction_id (see
 *                                   the available_listings_sale_fk migration).
 *                                   Omit when no confirmed sale_id is available.
 */
async function closeActiveListingsOnSale(domain, propertyId, saleDate, soldPrice, saleId = null) {
  const datePart = String(saleDate || '').split('T')[0];
  if (!datePart) return 0;
  const priceNum = soldPrice != null && Number.isFinite(Number(soldPrice)) && Number(soldPrice) > 0
    ? Number(soldPrice)
    : null;
  const saleIdNum = Number.isFinite(Number(saleId)) && Number(saleId) > 0
    ? Number(saleId)
    : null;
  try {
    if (domain === 'dialysis') {
      const propertyIdInt = parseInt(propertyId, 10);
      const lookup = await domainQuery('dialysis', 'GET',
        `available_listings?property_id=eq.${propertyIdInt}` +
        `&is_active=is.true&select=listing_id,listing_date&limit=100`
      );
      if (!lookup.ok || !Array.isArray(lookup.data) || !lookup.data.length) return 0;
      let closed = 0;
      for (const row of lookup.data) {
        const listingId = row.listing_id;
        const patch = {
          is_active:        false,
          status:           'Sold',
          sold_date:        datePart,
          off_market_date:  datePart,
        };
        if (priceNum != null) patch.sold_price = priceNum;
        if (saleIdNum != null) patch.sale_transaction_id = saleIdNum;
        const res = await domainPatch('dialysis',
          `available_listings?listing_id=eq.${listingId}`,
          patch,
          'closeActiveListingsOnSale'
        );
        if (res?.ok !== false) {
          console.log(
            `[listing-close] domain=dialysis listing_id=${listingId} ` +
            `property_id=${propertyIdInt} sale_date=${datePart}` +
            (priceNum != null ? ` sold_price=${priceNum}` : '') +
            (saleIdNum != null ? ` sale_transaction_id=${saleIdNum}` : '')
          );
          closed++;
        }
      }
      return closed;
    }

    if (domain === 'government') {
      const lookup = await domainQuery('government', 'GET',
        `available_listings?property_id=eq.${propertyId}` +
        `&listing_status=eq.Active&select=listing_id,listing_date&limit=100`
      );
      if (!lookup.ok || !Array.isArray(lookup.data) || !lookup.data.length) return 0;
      const target = pickClosestListing(lookup.data, datePart);
      if (!target) {
        console.log(
          `[listing-close] domain=government property_id=${propertyId} ` +
          `sale_date=${datePart} skipped=no_match_in_3yr_window ` +
          `candidates=${lookup.data.length}`
        );
        return 0;
      }
      const listingId = target.listing_id;
      const patch = {
        listing_status:   'Sold',
        off_market_date:  datePart,
        updated_at:       new Date().toISOString(),
      };
      const res = await domainPatch('government',
        `available_listings?listing_id=eq.${listingId}`,
        patch,
        'closeActiveListingsOnSale'
      );
      if (res?.ok !== false) {
        console.log(
          `[listing-close] domain=government listing_id=${listingId} ` +
          `property_id=${propertyId} sale_date=${datePart} ` +
          `listing_date=${target.listing_date || 'null'}`
        );
        return 1;
      }
      return 0;
    }
  } catch (err) {
    console.error('[listing-close] error', {
      domain, propertyId, saleDate: datePart, error: err?.message || String(err),
    });
  }
  return 0;
}

// ────────────────────────────────────────────────────────────────────────────
// Round 76ek.f (2026-05-08): cap-rate provenance back-write helper.
//
// When a gov sale lands with a cap_rate, point at the NOI source the cap was
// computed from. The four-tier ladder (cmbs_audited → om_actual →
// om_pro_forma → market_implied) lets analytics filter sales by the trust
// level of their cap-rate denominator, and lets a UI show "this 7.2% cap was
// audited against the Q4-2023 CMBS servicer report" instead of just "7.2%".
//
// R66x.2: enabled for gov AND dia. dia NNN cap rates are net-rent-derived, but
// OMs (and occasionally CMBS) DO carry an in-place NOI worth pointing at; for dia
// we record only the NOI lineage and leave cap_rate_quality (its suspect flag) alone.
//
// Lookup order:
//   1. Loan snapshot for any loan on this property, as_of_date in the
//      18 months before the sale → cmbs_audited.
//   2. property_financials.is_actual=true, fiscal_year = sale_year or
//      sale_year-1 → om_actual.
//   3. metadata.noi present (CoStar / OM aggregate NOI) → om_pro_forma.
//   4. Otherwise → market_implied.
//
// Returns {} when no annotation should be applied (dia, no cap rate, or
// no sale date). Failures are swallowed and the write proceeds without
// the new provenance fields — they're additive, never blocking.
async function resolveCapRateProvenance(domain, propertyId, sale, metadata) {
  // R66x.2 (OM/CMBS NOI wiring): enabled for gov AND dia. gov stores the NOI-trust
  // tier in cap_rate_quality; dia OVERLOADS cap_rate_quality for its suspect/
  // implausible flag, so for dia we record ONLY the NOI lineage
  // (cap_rate_noi_source_table/_id) and never write cap_rate_quality (which would
  // clobber the suspect flag). The lineage table name implies the tier on dia
  // (loan_snapshots=cmbs_audited, property_financials=om_actual).
  if (domain !== 'government' && domain !== 'dialysis') return {};
  const stampQuality = (domain === 'government');

  const hasCapRate =
    sale.cap_rate != null
    || sale.stated_cap_rate != null
    || sale.calculated_cap_rate != null
    || sale.initial_cap_rate != null
    || (metadata && metadata.cap_rate);
  if (!hasCapRate || !propertyId || !sale.sale_date) return {};

  const saleDate = String(sale.sale_date).slice(0, 10);
  const saleYear = parseInt(saleDate.slice(0, 4), 10);
  if (!Number.isFinite(saleYear)) return {};

  // Window for snapshot lookup: 18 months before the sale date.
  const eighteenMo = new Date(saleDate);
  if (Number.isNaN(eighteenMo.getTime())) return {};
  eighteenMo.setMonth(eighteenMo.getMonth() - 18);
  const windowStart = eighteenMo.toISOString().slice(0, 10);

  try {
    // ── Tier 1: CMBS loan snapshot (servicer-audited NOI)
    const loansRes = await domainQuery(domain, 'GET',
      `loans?property_id=eq.${propertyId}&select=loan_id&limit=20`);
    if (loansRes.ok && Array.isArray(loansRes.data) && loansRes.data.length > 0) {
      const loanIds = loansRes.data
        .map(l => l.loan_id)
        .filter(Boolean)
        .map(id => encodeURIComponent(id));
      if (loanIds.length > 0) {
        const snapsRes = await domainQuery(domain, 'GET',
          `loan_snapshots?loan_id=in.(${loanIds.join(',')})` +
          `&as_of_date=gte.${windowStart}` +
          `&as_of_date=lte.${saleDate}` +
          `&noi=not.is.null` +
          `&select=snapshot_id,as_of_date,noi&order=as_of_date.desc&limit=1`);
        if (snapsRes.ok && snapsRes.data?.[0]?.snapshot_id) {
          return {
            cap_rate_noi_source_table: 'loan_snapshots',
            cap_rate_noi_source_id:    snapsRes.data[0].snapshot_id,
            ...(stampQuality ? { cap_rate_quality: 'cmbs_audited' } : {}),
          };
        }
      }
    }

    // ── Tier 2: property_financials actuals in same FY or year-prior.
    // Round 76ek.k: gov uses `financial_id`, dia uses `id`.
    const finPkCol = domain === 'government' ? 'financial_id' : 'id';
    const finRes = await domainQuery(domain, 'GET',
      `property_financials?property_id=eq.${propertyId}` +
      `&is_actual=eq.true` +
      `&fiscal_year=in.(${saleYear},${saleYear - 1})` +
      `&noi=not.is.null` +
      // BOUNDARY (Stage B widen): folder-feed lease-abstract expense rows are
      // is_actual=false + noi=null (so already excluded above); the explicit
      // source guard is belt-and-suspenders against a future row that sets them.
      `&source=neq.folder_feed_lease` +
      `&select=${finPkCol},fiscal_year&order=fiscal_year.desc&limit=1`);
    if (finRes.ok && finRes.data?.[0]?.[finPkCol]) {
      return {
        cap_rate_noi_source_table: 'property_financials',
        cap_rate_noi_source_id:    finRes.data[0][finPkCol],
        ...(stampQuality ? { cap_rate_quality: 'om_actual' } : {}),
      };
    }
  } catch (err) {
    console.warn('[resolveCapRateProvenance] lookup failed (proceeding without provenance):',
      err?.message || err);
  }

  // ── Tier 3: OM/CoStar-derived NOI (pro-forma quality)
  // We don't have a stable record_id to point at — these come from
  // metadata.noi which is a transient capture artifact. Set quality only.
  // Tiers 3-4 set only cap_rate_quality (no record to point at). On dia that
  // column is the suspect flag, so dia returns {} here rather than clobber it.
  if (stampQuality && (metadata?._intake_promoted || metadata?.noi)) {
    return { cap_rate_quality: 'om_pro_forma' };
  }

  // ── Tier 4: no NOI source identified — market-implied (gov only)
  return stampQuality ? { cap_rate_quality: 'market_implied' } : {};
}

/**
 * Upsert sales transactions in the domain database.
 * Matches by property_id + sale_date + sold_price for deduplication.
 */
// Explode a Bulk/Portfolio Sale into per-property rows. Each constituent is
// matched-or-created by normalized address (reusing upsertDomainProperty's
// dedupe + junk-address guards) and gets its own allocated sale written via
// upsertDomainSales. Fully fail-safe: a single bad constituent is skipped and
// never aborts the others or the subject write. Idempotent — a re-capture
// resolves the same property_ids and fill-blanks the same sales.
// NOTE: the live auto-create path needs a first-capture gate (the extension
// portfolio_properties[] parse is verified against synthetic lines, not the
// live CoStar DOM). 2026-06-25.
async function unpackPortfolioConstituents(domain, entity, metadata, provCollect) {
  const constituents = Array.isArray(metadata.portfolio_properties)
    ? metadata.portfolio_properties : [];
  const deal = derivePortfolioDeal(metadata);
  const out = { count: constituents.length, matched_or_created: 0, sales_written: 0, skipped: 0, property_ids: [] };
  for (const c of constituents) {
    try {
      const inputs = buildConstituentInputs(domain, deal, c);
      if (!inputs) { out.skipped++; continue; }
      const cPropertyId = await upsertDomainProperty(domain, inputs.entity, inputs.metadata);
      if (!cPropertyId) { out.skipped++; continue; }
      out.matched_or_created++;
      out.property_ids.push(cPropertyId);
      const n = await upsertDomainSales(domain, cPropertyId, inputs.entity, inputs.metadata, provCollect);
      out.sales_written += (n || 0);
    } catch (err) {
      console.warn(`[portfolio-unpack] constituent "${c && c.address}" failed (non-fatal):`, err?.message);
      out.skipped++;
    }
  }
  console.log(`[portfolio-unpack] ${domain}: ${out.matched_or_created}/${out.count} constituents resolved, ${out.sales_written} sales written, ${out.skipped} skipped`);
  return out;
}

async function upsertDomainSales(domain, propertyId, entity, metadata, provCollect) {
  const sales = metadata.sales_history;
  if (!Array.isArray(sales) || sales.length === 0) return 0;

  const parsedSF = parseSF(metadata.square_footage);
  const primaryTenant = cleanTenantValue(selectPrimaryTenant(metadata, domain));

  // ── Sale Notes extraction ──────────────────────────────────────────────
  const saleNotesRaw = metadata.sale_notes_raw || null;
  const saleNotesExtracted = parseSaleNotes(saleNotesRaw);

  // Cross-reference sale notes values against structured fields
  if (saleNotesRaw && Object.keys(saleNotesExtracted).length > 0) {
    // NOI + cap rate → price validation
    if (saleNotesExtracted.noi && saleNotesExtracted.stated_cap_rate) {
      const impliedPrice = Math.round(saleNotesExtracted.noi / (saleNotesExtracted.stated_cap_rate / 100));
      console.log(`[sale-notes-xref] NOI=$${saleNotesExtracted.noi} / ${saleNotesExtracted.stated_cap_rate}% = implied price $${impliedPrice.toLocaleString()}`);
    }
    // Building SF cross-reference
    if (saleNotesExtracted.building_sf && parsedSF) {
      const sfDelta = Math.abs(saleNotesExtracted.building_sf - parsedSF);
      if (sfDelta > 100) {
        console.log(`[sale-notes-xref] SF mismatch: notes=${saleNotesExtracted.building_sf} vs RBA=${parsedSF} (delta=${sfDelta})`);
      }
    }
  }

  // Identify the "most recent" sale — the one whose sale_date most closely
  // matches the CoStar Last Sale Date stat-card value. Only that row may
  // carry the CoStar-stated cap rate; historical deed rows predate the
  // current listing and must not inherit its cap rate.
  const statCardLastSaleDate = parseDate(metadata.last_sale_date || metadata.sale_date);
  let mostRecentSaleDatePart = null;
  {
    const dated = sales
      .map(s => parseDate(s.sale_date))
      .filter(Boolean)
      .map(d => d.split('T')[0]);
    if (dated.length) {
      if (statCardLastSaleDate) {
        const target = new Date(statCardLastSaleDate.split('T')[0]).getTime();
        dated.sort((a, b) =>
          Math.abs(new Date(a).getTime() - target) -
          Math.abs(new Date(b).getTime() - target));
      } else {
        dated.sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
      }
      mostRecentSaleDatePart = dated[0];
    }
  }

  let count = 0;
  // R37 (2026-06-17) prevent-at-write telemetry: skipped price-less
  // placeholders (split redundant vs genuinely-new) and dedup-window
  // collapses that avoided an insert→supersede churn row.
  let skippedPriceless = 0, skippedPricelessRedundant = 0, skippedPricelessNew = 0;
  let dedupCollapsed = 0;
  for (const sale of sales) {
    const saleDate = parseDate(sale.sale_date);
    if (!saleDate) continue;

    // Skip refinance/encumbrance deeds — not ownership transfers.
    // Still written as loan records if lender/loan data is present
    // (upsertDomainLoans handles this separately).
    if (sale.deed_type && MORTGAGE_DEED_TYPES.test(sale.deed_type)) {
      continue;
    }

    const soldPrice = parseCurrency(sale.sale_price);

    // Match predicate for existing sales:
    //   1. By price ±5% AND sale_date ±14 days — economic identity.
    //   2. Else fall through to INSERT (distinct transaction).
    // (sales_transactions carries no document_number column — the recorder
    //  document number lives on deed_records — so the prior "same deed"
    //  stage was a no-op that errored every run; price/date is the dedup key.)
    // The previous implementation pulled back any row within ±45 days
    // (limit=1) and PATCHed it, which collapsed a $10K seed transfer and
    // a $45.75M acquisition that happened on the same property a few
    // days apart into one row.
    const datePart = saleDate.split('T')[0]; // YYYY-MM-DD

    // QA1 (2026-06-03): refuse to store a portfolio AGGREGATE as a per-property
    // price. `saleBleed.isAggregate` ⇒ this exact price+date already exists on
    // another property → null the price + flag out of market metrics.
    // `saleBleed.overCeiling` ⇒ implausibly large → flag for human review only
    // (never auto-null on magnitude alone). soldPrice itself is left intact for
    // matching/broker logic; only the WRITTEN value (writeSoldPrice) changes.
    const saleBleed = await detectSalePriceBleed(domain, propertyId, soldPrice, datePart);
    // 2026-06-25: fold in the self-evident Bulk/Portfolio signal so the
    // first/only constituent property of a portfolio capture is caught BEFORE a
    // sibling arrives (the gap detectSalePriceBleed's comment documents).
    if (!saleBleed.isAggregate && isPortfolioAggregateSale(sale)) {
      saleBleed.isAggregate = true;
      saleBleed.portfolioAggregate = true;
    }
    const writeSoldPrice = saleBleed.isAggregate ? null : soldPrice;
    const saleBleedExclude = saleBleed.isAggregate || saleBleed.overCeiling;
    if (saleBleed.isAggregate) {
      console.log(`[sale-price-bleed] property=${propertyId} price=${soldPrice} date=${datePart} — ${saleBleed.portfolioAggregate ? 'bulk/portfolio sale aggregate (single-property capture)' : 'portfolio aggregate detected (duplicate price+date on another property)'}; nulling per-property price`);
    } else if (saleBleed.overCeiling) {
      console.log(`[sale-price-bleed] property=${propertyId} price=${soldPrice} date=${datePart} — over per-domain ceiling; flagged for human review (price retained)`);
    }

    const saleD = new Date(datePart);
    const lo = new Date(saleD); lo.setDate(lo.getDate() - 14);
    const hi = new Date(saleD); hi.setDate(hi.getDate() + 14);
    const loStr = lo.toISOString().split('T')[0];
    const hiStr = hi.toISOString().split('T')[0];

    const lookupSelect = domain === 'government'
      ? 'sale_id,sale_date,sold_price,firm_term_years_at_sale,firm_term_locked'
      : 'sale_id,sale_date,sold_price,stated_cap_rate,calculated_cap_rate,cap_rate_confidence';

    let lookup = { ok: false, data: [] };

    // Match by price ±5% AND date ±14d window. Fetch candidates in the
    // 14-day window and JS-filter by price — PostgREST can't express
    // "within ±5% of incoming" in a single URL.
    if (!lookup.ok || !lookup.data?.length) {
      const windowLookup = await domainQuery(domain, 'GET',
        `sales_transactions?property_id=eq.${propertyId}` +
        `&sale_date=gte.${loStr}&sale_date=lte.${hiStr}` +
        `&select=${lookupSelect}&limit=5`
      );
      if (windowLookup.ok && Array.isArray(windowLookup.data)
          && windowLookup.data.length) {
        if (soldPrice == null || soldPrice <= 0) {
          // Missing price on incoming — can't verify economic identity
          // on price. Only match if the window has exactly one candidate
          // with a missing/zero price too, to avoid picking the wrong
          // row when several deeds cluster on the same week.
          const ambiguous = windowLookup.data.filter(r =>
            r.sold_price == null || Number(r.sold_price) <= 0);
          if (ambiguous.length === 1) {
            lookup = { ok: true, data: [ambiguous[0]] };
          }
        } else {
          const compatible = windowLookup.data.find(r => {
            const rp = Number(r.sold_price);
            if (!Number.isFinite(rp) || rp <= 0) return false;
            const delta = Math.abs(rp - soldPrice) / Math.max(rp, soldPrice);
            return delta <= 0.05;
          });
          if (compatible) lookup = { ok: true, data: [compatible] };
        }
      }
    }

    // Stage 3 (R37, 2026-06-17): prevent-at-write the duplicate_superseded
    // churn. The sales_dedup_tick cron quarantines a NEW priced row when an
    // existing LIVE sale on the same property is within $1,000 and 60 days
    // (its cross-month proximity pass). Rather than insert a row the cron will
    // immediately supersede (~335/mo), match the survivor here and PATCH it in
    // place. Bounded by an ABSOLUTE $1,000 price window (not the relative ±5%
    // of Stage 2) so a $10K seed transfer never collapses into a $45M
    // acquisition; only a genuine re-capture of the same sale collapses.
    if ((!lookup.ok || !lookup.data?.length) && soldPrice != null && soldPrice > 0) {
      const lo60 = new Date(saleD); lo60.setDate(lo60.getDate() - 60);
      const hi60 = new Date(saleD); hi60.setDate(hi60.getDate() + 60);
      const dedupLookup = await domainQuery(domain, 'GET',
        `sales_transactions?property_id=eq.${propertyId}` +
        `&transaction_state=eq.live` +
        `&sale_date=gte.${lo60.toISOString().split('T')[0]}` +
        `&sale_date=lte.${hi60.toISOString().split('T')[0]}` +
        `&select=${lookupSelect}&limit=10`
      ).catch(() => ({ ok: false, data: [] }));
      if (dedupLookup.ok && Array.isArray(dedupLookup.data) && dedupLookup.data.length) {
        const cand = dedupLookup.data
          .filter(r => Number.isFinite(Number(r.sold_price))
                    && Math.abs(Number(r.sold_price) - soldPrice) <= 1000)
          .sort((a, b) =>
            Math.abs(new Date(a.sale_date).getTime() - saleD.getTime()) -
            Math.abs(new Date(b.sale_date).getTime() - saleD.getTime()))[0];
        if (cand) {
          lookup = { ok: true, data: [cand] };
          dedupCollapsed++;
        }
      }
    }

    // Only apply current brokers to the current/most-recent sale. Historical
    // deed-record sales predate the current broker engagement and must not
    // have these broker names attributed to them.
    //
    // Round 76gp.a (2026-05-21): the original 90-day gate dropped ~95% of
    // listing_broker writes on costar_sidebar sales because most CoStar
    // captures happen 3-18 months after the deed records. Audit found 587
    // most-recent sales with price but no broker, of which 184 had a broker
    // sitting in available_listings (same property) — i.e. the data was
    // available but the gate prevented attribution. We now use two tiers:
    //   1. 90-day window — any sale (even older historical rows on the
    //      same page) can receive the broker. Unchanged.
    //   2. "Most recent on property" within 2 years — the page-level
    //      contacts plausibly belong to this sale even though the 90-day
    //      window has passed. Limits false attribution to a realistic
    //      broker engagement horizon.
    const parsedSaleDate = new Date(saleDate);
    const ninetyDaysAgo = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
    const twoYearsAgo   = new Date(Date.now() - 2 * 365 * 24 * 60 * 60 * 1000);
    const isCurrentSale = parsedSaleDate >= ninetyDaysAgo;
    // isMostRecentSale is computed later as `datePart === mostRecentSaleDatePart`
    // but we need it here for the broker gate.
    const isMostRecentOnPropertyForBroker =
      datePart === mostRecentSaleDatePart && parsedSaleDate >= twoYearsAgo;
    const brokerFallbackAllowed = isCurrentSale || isMostRecentOnPropertyForBroker;

    // Find brokers from contacts
    const listingBroker = (metadata.contacts || []).find(c =>
      c.role === 'listing_broker' && (
        // Prefer a broker tagged to this specific transaction
        (c.sale_buyer && (
          (sale.buyer || '').toLowerCase().includes(c.sale_buyer.toLowerCase().split(' ')[0]) ||
          (sale.buyer_name || '').toLowerCase().includes(c.sale_buyer.toLowerCase().split(' ')[0])
        )) ||
        (c.sale_seller && (
          (sale.seller || '').toLowerCase().includes(c.sale_seller.toLowerCase().split(' ')[0]) ||
          (sale.seller_name || '').toLowerCase().includes(c.sale_seller.toLowerCase().split(' ')[0])
        ))
      )
    ) || (brokerFallbackAllowed ? (metadata.contacts || []).find(c => c.role === 'listing_broker') : null);
    const buyerBroker = (metadata.contacts || []).find(c => c.role === 'buyer_broker');

    // Domain-aware field names for sales transactions
    const capRateVal = parseCapRateDecimal(sale.cap_rate || metadata.cap_rate);
    // For current sales with no deed-level buyer/seller, supplement
    // from contacts (buyer/seller contacts are the same entities).
    // The same 2-year/most-recent gate applies here as for brokers — when
    // the parser only captured page-level buyer/seller contacts (no per-deed
    // entries), they belong to whichever sale the page is showing, which
    // is reliably the most-recent transaction on the property.
    const contactBuyer = (metadata.contacts || [])
      .find(c => c.role === 'buyer')?.name || null;
    const contactSeller = (metadata.contacts || [])
      .find(c => c.role === 'seller')?.name || null;

    // Round 76ax: strip brokerage names + test fixtures from buyer/seller
    // before they reach the DB. SQL trigger (dia/gov_filter_junk_sales_party)
    // is the second line of defense; this is the first.
    const buyerVal  = cleanSalesPartyValue(sale.buyer  || (brokerFallbackAllowed ? contactBuyer  : null));
    const sellerVal = cleanSalesPartyValue(sale.seller || (brokerFallbackAllowed ? contactSeller : null));
    const procuringBrokerVal = brokerFallbackAllowed ? (buyerBroker?.name || null) : null;

    // Cap-rate gating: only the most-recent sale (matching CoStar's Last
    // Sale Date) with a real sold_price may carry the CoStar-stated cap
    // rate. Historical deed rows still record provenance
    // (confidence='low', rent_source='costar_stated') but get
    // stated_cap_rate=NULL so they no longer inherit the current
    // listing's cap rate. sale_date-null rows are already skipped above.
    const isMostRecentSale = datePart === mostRecentSaleDatePart;
    const allowStatedCapRate =
      isMostRecentSale && soldPrice != null && capRateVal != null;

    // Round 77 (2026-06-02): persist the CoStar listing's price history onto
    // the gov sale row. The sidebar already captures metadata.list_price (the
    // original ask), metadata.asking_price (the final/current ask),
    // metadata.listing_date (on-market) and metadata.days_on_market, but
    // upsertDomainSales previously DROPPED all of them on the gov sale —
    // leaving only ~8% of gov market sales with any listing history, which
    // starved the supply-side Capital Markets charts (Seller Sentiment
    // "Price Chg %", DOM & Price-Change, Bid-Ask Spread). We now map them onto
    // initial_price / last_price / on_market_date / days_on_market and derive
    // had_price_change / pct_of_initial. Only the most-recent sale on the
    // property is stamped — CoStar's listing fields describe the listing that
    // just transacted, not older historical deeds — and we never fabricate an
    // ask: a field stays null when CoStar didn't carry it (so the sale simply
    // stays out of the price-change / bid-ask metrics). The field-priority
    // guard + manual_override below keep curated values from being clobbered.
    const govListingHistory = {};
    if (domain === 'government' && isMostRecentSale) {
      const lastAsk  = parseCurrency(metadata.asking_price);
      const origAsk  = parseCurrency(metadata.list_price);
      const onMarket = parseDate(metadata.listing_date)?.split('T')[0] || null;
      const domRaw   = parseInt(metadata.days_on_market, 10);
      const domDays  = Number.isFinite(domRaw) ? domRaw : null;
      if (lastAsk != null && lastAsk > 0) govListingHistory.last_price = lastAsk;
      if (origAsk != null && origAsk > 0) govListingHistory.initial_price = origAsk;
      if (onMarket && onMarket <= datePart) govListingHistory.on_market_date = onMarket;
      if (domDays != null && domDays >= 0 && domDays <= 1825) govListingHistory.days_on_market = domDays;
      const ip = govListingHistory.initial_price ?? null;
      const lp = govListingHistory.last_price ?? null;
      // had_price_change is only knowable when BOTH asks were captured.
      if (ip != null && lp != null) govListingHistory.had_price_change = ip !== lp;
      // pct_of_initial = sold / initial ask, guarded to a sane capitulation band.
      if (ip != null && ip > 0 && soldPrice != null && soldPrice > 0) {
        const pct = soldPrice / ip;
        if (pct >= 0.5 && pct <= 1.05) govListingHistory.pct_of_initial = Math.round(pct * 10000) / 10000;
      }
    }

    // Sale-Notes-derived at-sale firm term (gov, most-recent sale only). The
    // narrative often carries the term CoStar's structured fields omit
    // ("11.5 years remaining"); seed firm_term_years_at_sale so the cap-by-term
    // views (which COALESCE it first) can use it. Fill-blank only — the gov
    // term-reconcile pass (firm_term_locked) stays authoritative (the PATCH
    // branch strips this when the existing row is locked or already set).
    const govSaleNotesFields = (domain === 'government' && isMostRecentSale)
      ? govSaleNotesTermFields(saleNotesExtracted)
      : {};

    const domainSaleFields = domain === 'government'
      ? {
          sold_cap_rate:    capRateVal,
          buyer:            buyerVal,
          seller:           sellerVal,
          purchasing_broker: procuringBrokerVal,
          // v_sales_comps reads address/agency from sales_transactions
          address:          entity.address || null,
          city:             entity.city    || null,
          state:            entity.state   || null,
          agency:           primaryTenant  || null,
          government_type:  metadata.government_type || null,
          // Compute sold_price_psf when both price and SF are known.
          // QA1: a nulled portfolio-aggregate price yields no per-SF figure.
          sold_price_psf:   (writeSoldPrice && parsedSF && parsedSF > 0)
                            ? Math.round(writeSoldPrice / parsedSF * 100) / 100
                            : null,
          // QA1: record the bleed/oversize reason (gov has no notes column).
          ...(saleBleedExclude ? {
            sales_exclusion_reason: saleBleed.isAggregate
              ? (saleBleed.portfolioAggregate
                  ? `[portfolio-aggregate] ${soldPrice} on ${datePart} is a Bulk/Portfolio deal aggregate, not this property's price; nulled — capture all constituents for per-property prices`
                  : `[portfolio-aggregate] per-property price ${soldPrice} on ${datePart} matched another property's sale; nulled — not a valid single-property sale price`)
              : `[oversized-sale-review] sold_price ${soldPrice} exceeds the $${SALE_PRICE_BLEED_CEILING.government.toLocaleString()} gov ceiling; flagged for human review (price retained)`,
          } : {}),
          // Financing details from deed entry.
          // C9 Phase 2 (2026-05-27): dropped the `|| sale.deed_type` fallback
          // — it leaked the deed type ("Quit Claim Deed", "Special Warranty
          // Deed") into financing_type, which C2A then had to enrich around.
          // deed_type is preserved in deed_records (upsertGovernmentDeedRecords)
          // and financing_type is populated authoritatively from gov.loans by
          // the C2A sales_enrich_from_loans() cron. validateSaleIngest below
          // backstops any residual leak.
          financing_type:   sale.financing_type || null,
          lender_name:      sale.lender_name    || null,
          guarantor:        metadata.guarantor  || null,
          gross_rent:       parseCurrency(metadata.annual_rent),
          gross_rent_psf:   parseCurrency(metadata.rent_per_sf),
          transaction_type: null,  // set below by classifySaleType
          // Round 77: listing price-history (initial/last ask, on-market date,
          // DOM, had_price_change, pct_of_initial). Only present on the
          // most-recent sale and only for fields CoStar actually carried.
          ...govListingHistory,
          // Sale-Notes at-sale firm term seed (fill-blank; PATCH branch guards).
          ...govSaleNotesFields,
          data_source:      'costar_sidebar',
        }
      : {
          // Cap rate provenance: raw CoStar value is "stated" with low
          // confidence until an OM or lease confirms it. calculated_cap_rate
          // and rent_at_sale are intentionally left null here — they are
          // populated downstream when confirmed rent data arrives.
          // Only the most-recent sale gets the stated cap rate value;
          // historical rows keep provenance but no value. The explicit
          // null on stated_cap_rate is re-applied after stripNulls below
          // so PATCHes clear any previously-written stat-card value.
          stated_cap_rate:     allowStatedCapRate ? capRateVal : null,
          cap_rate_confidence: 'low',
          rent_source:         'costar_stated',
          buyer_name:       buyerVal,
          seller_name:      sellerVal,
          procuring_broker: procuringBrokerVal,
        };

    const { transaction_type, exclude_from_market_metrics } = classifySaleType(sale);

    // Task 2 (R68-B, 2026-06-05): guarantee the firm-term resolver has a term to
    // work with at INSERT even when no covering lease row lands. The dia
    // BEFORE-INSERT trigger (dia_sales_set_firm_term) resolves term via
    // dia_firm_term_fields() — tier 1 = a covering leases row, tier 3 =
    // sale_notes_extracted->>'years_remaining'. parseSaleNotes only catches a term
    // phrased in the *narrative*; CoStar normally carries it as the structured
    // metadata.lease_expiration, so tier 3 never fired (live audit: 0/57 unresolved
    // 2026 sales had a notes term). For the MOST RECENT sale only — the one the
    // current lease describes; applying it to historical deed rows would violate
    // the Round-66 freeze-at-sale doctrine — derive years_remaining from
    // (lease_expiration − sale_date). A real covering lease row, written later by
    // upsertDomainLeases, still upgrades this via tier 1 (these rows stay unlocked).
    let saleNotesForRow = saleNotesExtracted;
    if (domain === 'dialysis' && datePart === mostRecentSaleDatePart
        && saleNotesExtracted.years_remaining == null) {
      const expStr = parseDate(metadata.lease_expiration)?.split('T')[0];
      if (expStr) {
        const yr = (new Date(expStr).getTime() - new Date(datePart).getTime()) / (365.25 * 86400000);
        if (yr > 0 && yr <= 25) {
          saleNotesForRow = { ...saleNotesExtracted,
            years_remaining: Math.round(yr * 10000) / 10000,
            years_remaining_source: 'derived_lease_expiration' };
        }
      }
    }

    const saleData = stripNulls({
      property_id: propertyId,
      sale_date:   datePart,
      // QA1: writeSoldPrice is null for a detected portfolio aggregate.
      sold_price:  writeSoldPrice,
      ...domainSaleFields,
      listing_broker: listingBroker?.name || null,
      // Only include recorded_date and notes for dialysis — gov
      // sales_transactions has neither column, and PostgREST will
      // silently 400 on PATCH if these are sent.
      ...(domain === 'dialysis' ? {
        recorded_date: parseDate(sale.recordation_date)?.split('T')[0] || null,
        notes: [
          sale.deed_type ? `Deed: ${sale.deed_type}` : null,
          sale.transaction_type ? `Type: ${sale.transaction_type}` : null,
          sale.document_number ? `Doc#: ${sale.document_number}` : null,
          sale.buyer_address ? `Buyer addr: ${sale.buyer_address}` : null,
          // QA1: record the bleed/oversize reason inline in dia notes.
          saleBleed.isAggregate
            ? (saleBleed.portfolioAggregate
                ? `[portfolio-aggregate] ${soldPrice} on ${datePart} is a Bulk/Portfolio deal aggregate, not this property's price; nulled — capture all constituents for per-property prices`
                : `[portfolio-aggregate] per-property price ${soldPrice} on ${datePart} matched another property's sale; nulled — not a valid single-property sale price`)
            : (saleBleed.overCeiling
              ? `[oversized-sale-review] sold_price ${soldPrice} exceeds the $${SALE_PRICE_BLEED_CEILING.dialysis.toLocaleString()} dia ceiling; flagged for human review (price retained)`
              : null),
          saleNotesRaw ? `--- Sale Notes ---\n${saleNotesRaw}` : null,
        ].filter(Boolean).join('; ') || null,
        sale_notes_raw: saleNotesRaw,
        sale_notes_extracted: Object.keys(saleNotesForRow).length > 0
          ? saleNotesForRow : null,
      } : {}),
      // Gov audit-retention parity (2026-06-20): retain the raw narrative +
      // structured extract on the most-recent sale only (the notes describe the
      // displayed/most-recent deal). Gov has no `notes`/`recorded_date` columns,
      // so just the two parity columns added by the gov sale-notes migration.
      ...(domain === 'government' && isMostRecentSale && saleNotesRaw ? {
        sale_notes_raw: saleNotesRaw,
        sale_notes_extracted: Object.keys(saleNotesExtracted).length > 0
          ? saleNotesExtracted : null,
      } : {}),
    });
    if (transaction_type !== null) saleData.transaction_type = transaction_type;
    // Always write exclude flag since false is a valid value that should persist.
    // QA1: a portfolio-aggregate or over-ceiling row is forced out of metrics.
    saleData.exclude_from_market_metrics =
      saleBleedExclude ? true : (exclude_from_market_metrics ?? false);
    saleData.data_source                = 'costar_sidebar';

    // QA1: re-apply the explicit null after stripNulls so a PATCH actively
    // clears any previously-stored aggregate price (stripNulls drops nulls,
    // which would otherwise leave a stale bled value on the existing row).
    if (saleBleed.isAggregate) {
      saleData.sold_price = null;
      if (domain === 'government') saleData.sold_price_psf = null;
    }

    // C9 Phase 2 (2026-05-27): backstop the sale row through the ingest
    // contract. Soft enforcement — log + sanitize, never block the write
    // (sale_date is already guarded above; the SQL junk-party trigger is a
    // second line of defense). financing_type leak is the main catch: if a
    // deed-type string slipped into financing_type, null it rather than
    // persist it in the wrong column.
    {
      const dto = {
        domain,
        property_id: propertyId,
        sale_date: saleData.sale_date,
        sold_price: saleData.sold_price,
        buyer: saleData.buyer || saleData.buyer_name || null,
        seller: saleData.seller || saleData.seller_name || null,
        financing_type: saleData.financing_type || null,
      };
      const { ok: saleOk, errors: saleErrors } = validateSaleIngest(dto);
      if (!saleOk) {
        const financingLeak = saleErrors.some(e => e.startsWith('financing_type '));
        if (financingLeak && saleData.financing_type != null) {
          console.warn(`[upsertDomainSales] nulling financing_type leak on property=${propertyId}: ${JSON.stringify(saleData.financing_type)}`);
          delete saleData.financing_type;
        }
        const otherErrors = saleErrors.filter(e => !e.startsWith('financing_type '));
        if (otherErrors.length) {
          console.warn(`[upsertDomainSales] ingest-contract warnings property=${propertyId}: ${otherErrors.join('; ')}`);
        }
      }
    }

    // Link the sale to the listing campaign that produced it, if any.
    // Only written for dialysis — government sales_transactions does not
    // carry a listing_sale_id column. Nullable: off-market sales or sales
    // that predate any captured listing get null and stay unlinked.
    if (domain === 'dialysis') {
      const matchedListingId = await findMatchingListingForSale(
        domain, propertyId, datePart
      );
      if (matchedListingId != null) {
        saleData.listing_sale_id = matchedListingId;
      }
    }
    // Re-apply explicit null on historical dialysis rows: stripNulls above
    // removes null values, but PATCH must actively clear stated_cap_rate
    // on rows that previously inherited the stat-card cap rate.
    if (domain !== 'government' && !allowStatedCapRate) {
      saleData.stated_cap_rate = null;
    }

    // Guard: block listing/asking-price rows from being written into
    // sales_transactions. A valid sale requires a parseable sale_date, a
    // positive sold_price, and no listing/asking/on-market markers in
    // transaction_type or notes. Any failure reroutes the record to
    // available_listings as an off-market listing.
    const txTypeForGuard = [
      saleData.transaction_type,
      sale.transaction_type,
      sale.sale_type,
    ].filter(Boolean).join(' | ');
    const notesForGuard = saleData.notes || '';
    const priceNum = Number(saleData.sold_price);
    const hasParseableDate = !!parseDate(saleData.sale_date);
    const hasPositivePrice = Number.isFinite(priceNum) && priceNum > 0;
    const hasListingTxMarker = /(listing|asking|on[\s-]?market)/i.test(txTypeForGuard);
    const hasOnMarketNotes = /on[\s-]?market/i.test(notesForGuard);

    // Allow sales without a disclosed price through — "Not Disclosed",
    // nominal transactions, and deed transfers are legitimate ownership
    // transfers that should be recorded even without a dollar amount.
    // Only block on missing date or listing/asking-price markers.
    if (!hasParseableDate || hasListingTxMarker || hasOnMarketNotes) {
      await routeListingMisroute(domain, propertyId, saleData, {
        invalid_date: !hasParseableDate,
        invalid_price: !hasPositivePrice,
        listing_transaction_type: hasListingTxMarker,
        on_market_notes: hasOnMarketNotes,
      });
      continue;
    }

    // Round 76ek.f: resolve cap-rate NOI provenance (gov only). Adds
    // cap_rate_noi_source_table / cap_rate_noi_source_id / cap_rate_quality
    // when an authoritative NOI source exists in our DB. No-op for dia (NNN
    // cap rates aren't NOI-derived) and for sales without a cap rate.
    const capRateProv = await resolveCapRateProvenance(domain, propertyId, saleData, metadata);
    if (Object.keys(capRateProv).length > 0) {
      Object.assign(saleData, capRateProv);
    }

    // Round 76gp.d: track the resolved sale_id across both write branches
    // so we can emit a single diagnostic per iteration at the end.
    let loopSaleId = null;

    // R37 (2026-06-17): resolve the write action at the source. A price-less
    // capture (no price on the page) that matches no existing row is NOT a
    // closed transaction — never mint a placeholder into the live table. Use
    // the raw `soldPrice` signal (an aggregate-nulled but genuinely-priced
    // sale still has soldPrice>0 and is allowed to insert).
    const lookupMatched = !!(lookup.ok && lookup.data?.length);
    const incomingHasPrice = soldPrice != null && Number(soldPrice) > 0;
    let writeAction;
    if (lookupMatched) {
      writeAction = { action: 'patch', reason: 'matched_existing' };
    } else if (incomingHasPrice) {
      writeAction = { action: 'insert', reason: 'new_priced_sale' };
    } else {
      const propertyHasLiveSale = await propertyHasLivePricedSale(domain, propertyId);
      writeAction = classifySaleWrite({ lookupMatched, incomingHasPrice, propertyHasLiveSale });
    }

    if (writeAction.action === 'skip') {
      skippedPriceless++;
      if (writeAction.reason === 'priceless_redundant_live_sale_exists') skippedPricelessRedundant++;
      else skippedPricelessNew++;
      console.log(`[upsertDomainSales] R37 skip price-less ${writeAction.reason} domain=${domain} property=${propertyId} date=${datePart} — no placeholder minted`);
      continue;
    }

    // Sale-Notes / Income&Expenses NOI → properties.noi (confirmed_sale anchor),
    // written BEFORE the sale upsert so the BEFORE trigger
    // trg_gov_auto_cap_rate_on_sale derives this sale's cap rate from a real NOI
    // (tier 1, HIGH) instead of leaving it market-implied. Most-recent sale only.
    if (domain === 'government' && isMostRecentSale) {
      const confirmedNoi = pickConfirmedSaleNoi(metadata, saleNotesExtracted);
      if (confirmedNoi != null) {
        await writeConfirmedSaleNoi(propertyId, confirmedNoi, datePart, provCollect);
      }
    }

    if (writeAction.action === 'patch') {
      const existing = lookup.data[0];
      loopSaleId = existing.sale_id;

      // Lookup already proved identity (document_number OR price ±5%
      // AND date ±14d). Treat as the same sale and refresh it so the
      // re-ingest advances updated_at and pulls in any new fields from
      // this CoStar capture. Previous tight-dedup "skip" block was
      // redundant given the new lookup and blocked the audit timestamps
      // this audit demands, so it has been removed.
      let patchData = saleData;

      // Fill-blank-only for the Sale-Notes at-sale term: never overwrite an
      // existing or locked firm_term_years_at_sale (the gov term-reconcile pass
      // is authoritative). Clone before deleting so saleData stays intact.
      if (domain === 'government'
          && (existing.firm_term_locked || existing.firm_term_years_at_sale != null)
          && (patchData.firm_term_years_at_sale != null || patchData.firm_term_source != null)) {
        patchData = { ...patchData };
        delete patchData.firm_term_years_at_sale;
        delete patchData.firm_term_source;
      }

      // Preserve confirmed cap rate data: if a sale already has a
      // calculated_cap_rate and its confidence is medium/high, the CoStar
      // stated value must not downgrade confidence or clobber the anchor
      // rent source. Only refresh stated_cap_rate, and only if it changed.
      if (domain !== 'government'
          && existing.calculated_cap_rate != null
          && (existing.cap_rate_confidence === 'medium'
              || existing.cap_rate_confidence === 'high')) {
        patchData = { ...saleData };
        delete patchData.cap_rate_confidence;
        delete patchData.rent_source;
        const newStated = patchData.stated_cap_rate;
        const existingStated = existing.stated_cap_rate != null
          ? Number(existing.stated_cap_rate) : null;
        if (newStated == null || existingStated === Number(newStated)) {
          delete patchData.stated_cap_rate;
        }
      }

      // Force an updated_at bump so the audit trail shows this re-ingest
      // actually refreshed the row even if every other field happened to
      // be identical. Supabase maintains updated_at via a trigger, but
      // a no-op PATCH can be a no-op — include an explicit timestamp.
      patchData.updated_at = new Date().toISOString();

      // Round 76co (Phase 3): consult priority registry before sales PATCH.
      // Sales rows carry buyer/seller/cap_rate/sold_price — fields that
      // multiple sources (deed records, OM extracts, sidebar) write to.
      // Strict-mode rules can now block a CoStar overwrite when a
      // higher-trust source (county deed) already populated the field.
      const filteredSalesPatch = await filterByFieldPriority({
        targetDb:    domain === 'dialysis' ? 'dia_db' : 'gov_db',
        targetTable: domain === 'dialysis' ? 'dia.sales_transactions' : 'gov.sales_transactions',
        recordPk:    existing.sale_id,
        source:      metadata._intake_promoted ? 'om_extraction' : 'costar_sidebar',
        confidence:  metadata._intake_promoted ? 0.7 : 0.6,
        fields:      patchData,
      }).catch(err => {
        console.warn('[upsertDomainSales] field-priority filter failed (proceeding with full patch):', err?.message);
        return patchData;
      });

      await domainPatch(domain,
        `sales_transactions?sale_id=eq.${existing.sale_id}`, filteredSalesPatch, 'upsertDomainSales');
      // Close any still-active listings for this property now that a
      // confirmed sale exists. Fire-and-forget relative to the sale write —
      // failures are logged but do not affect the sales_transactions result.
      // Pass the existing sale_id + incoming soldPrice so the dialysis
      // listing row persists sale_transaction_id + sold_price (see the
      // available_listings_sale_fk migration).
      await closeActiveListingsOnSale(
        domain, propertyId, datePart, saleData.sold_price, existing.sale_id
      );
      // Link brokers from text fields to sale_brokers table
      await linkSaleBrokers(domain, existing.sale_id, saleData);
      // Phase 2.2.b: record per-row provenance for the refreshed sale
      pushProvenance(provCollect, 'sales_transactions', existing.sale_id, {
        sale_date:        saleData.sale_date,
        sold_price:       saleData.sold_price,
        buyer_name:       saleData.buyer_name || saleData.buyer || null,
        seller_name:      saleData.seller_name || saleData.seller || null,
        stated_cap_rate:  saleData.stated_cap_rate ?? null,
        sold_cap_rate:    saleData.sold_cap_rate ?? null,
        listing_broker:   saleData.listing_broker || null,
        procuring_broker: saleData.procuring_broker || saleData.purchasing_broker || null,
        transaction_type: saleData.transaction_type || null,
        // Round 76ek.f: cap-rate NOI provenance (gov only; null on dia)
        cap_rate_noi_source_table: saleData.cap_rate_noi_source_table || null,
        cap_rate_noi_source_id:    saleData.cap_rate_noi_source_id ?? null,
        cap_rate_quality:          saleData.cap_rate_quality || null,
        // Sale-Notes at-sale term (gov only; null when stripped/absent)
        firm_term_years_at_sale: patchData.firm_term_years_at_sale ?? null,
        // Round 77: listing price-history (gov only; null/absent on dia)
        initial_price:    saleData.initial_price ?? null,
        last_price:       saleData.last_price ?? null,
        on_market_date:   saleData.on_market_date || null,
        days_on_market:   saleData.days_on_market ?? null,
        had_price_change: saleData.had_price_change ?? null,
        pct_of_initial:   saleData.pct_of_initial ?? null,
      });
    } else {
      // Create new
      // Fresh audit A-2 (2026-05-18): label the POST so the 409-recovery
      // log entries surface in ingest_write_failures as recoverable
      // (vs. anonymous 4xx in the unlabeled bucket).
      const result = await domainQuery(domain, 'POST', 'sales_transactions', saleData,
        { label: 'upsertDomainSales:initialInsert' });

      // Discovery patch #2 (audit/discovery-02-sales-409-dedupe, 2026-05-17):
      // defensive 409 recovery against uq_st_property_date_price partial
      // unique index on (property_id, sale_date, sold_price). The upstream
      // lookup uses fuzzy match (price ±5%, date ±14d); when an exact-match
      // row already exists from another writer (deed parser, RCA capture)
      // the lookup misses but the unique index still rejects. Pre-patch
      // observed: 26+ silent 409s per gov sidebar capture.
      let recoveredSaleId = null;
      if (!result.ok
          && result.status === 409
          && /uq_st_property_date_price/.test(JSON.stringify(result.data || {}))) {
        const exactLookup = await domainQuery(domain, 'GET',
          `sales_transactions?property_id=eq.${propertyId}` +
          `&sale_date=eq.${encodeURIComponent(saleData.sale_date)}` +
          `&sold_price=eq.${saleData.sold_price}` +
          `&select=sale_id&limit=1`
        );
        if (exactLookup.ok && exactLookup.data?.length) {
          recoveredSaleId = exactLookup.data[0].sale_id;
          // PATCH the existing row with our refreshed payload. Force an
          // updated_at bump so the audit trail reflects this re-ingest.
          const patchData = { ...saleData, updated_at: new Date().toISOString() };
          // Same field-priority gate as the upstream-lookup PATCH branch,
          // so a fuzzy-miss recovery doesn't bypass curated data protection.
          const filteredRecoveryPatch = await filterByFieldPriority({
            targetDb:    domain === 'dialysis' ? 'dia_db' : 'gov_db',
            targetTable: domain === 'dialysis' ? 'dia.sales_transactions' : 'gov.sales_transactions',
            recordPk:    recoveredSaleId,
            source:      metadata._intake_promoted ? 'om_extraction' : 'costar_sidebar',
            confidence:  metadata._intake_promoted ? 0.7 : 0.6,
            fields:      patchData,
          }).catch(() => patchData);
          await domainPatch(domain,
            `sales_transactions?sale_id=eq.${recoveredSaleId}`,
            filteredRecoveryPatch,
            'upsertDomainSales:409Recovery'
          );
          console.log(`[upsertDomainSales:409Recovery] recovered sale ${recoveredSaleId} for property=${propertyId} date=${saleData.sale_date} price=${saleData.sold_price}`);
        }
      }

      if (result.ok || recoveredSaleId) {
        count++;
        // Determine the sale_id to use for the post-write flow:
        //   • result.ok       → freshly inserted, sale_id from response
        //   • recoveredSaleId → 409 recovery, sale_id from exact lookup
        const inserted = result.ok
          ? (Array.isArray(result.data) ? result.data[0] : result.data)
          : null;
        const newSaleId = inserted?.sale_id ?? recoveredSaleId ?? null;
        loopSaleId = newSaleId;

        // Create BD alert for new dialysis sale capture (gov uses sf_comps_staging).
        // Only on a TRUE insert — 409 recovery means we already knew about this sale.
        if (domain === 'dialysis' && result.ok) {
          await createSaleAlert(propertyId, saleData);
        }
        // Close any still-active listings for this property on a new sale.
        await closeActiveListingsOnSale(
          domain, propertyId, datePart, saleData.sold_price, newSaleId
        );
        // Link brokers from text fields to sale_brokers table
        await linkSaleBrokers(domain, newSaleId, saleData);
        // Phase 2.2.b: record per-row provenance for the sale (insert or recovery)
        if (newSaleId) {
          pushProvenance(provCollect, 'sales_transactions', newSaleId, {
            sale_date:        saleData.sale_date,
            sold_price:       saleData.sold_price,
            buyer_name:       saleData.buyer_name || saleData.buyer || null,
            seller_name:      saleData.seller_name || saleData.seller || null,
            stated_cap_rate:  saleData.stated_cap_rate ?? null,
            sold_cap_rate:    saleData.sold_cap_rate ?? null,
            listing_broker:   saleData.listing_broker || null,
            procuring_broker: saleData.procuring_broker || saleData.purchasing_broker || null,
            transaction_type: saleData.transaction_type || null,
            cap_rate_noi_source_table: saleData.cap_rate_noi_source_table || null,
            cap_rate_noi_source_id:    saleData.cap_rate_noi_source_id ?? null,
            cap_rate_quality:          saleData.cap_rate_quality || null,
            // Sale-Notes at-sale term (gov only; null/absent on dia)
            firm_term_years_at_sale:   saleData.firm_term_years_at_sale ?? null,
          });
        }
      }
    }

    // C2 Part B (2026-05-27): persist buyer/seller/broker PII from
    // metadata.contacts to contacts table, linked to this sale. Idempotent.
    if (loopSaleId) {
      try {
        await persistSaleContacts(domain, loopSaleId, propertyId, metadata, provCollect);
      } catch (err) {
        console.warn('[upsertDomainSales] persistSaleContacts failed (non-fatal):', err?.message || err);
      }
    }

    // Round 76gp.d: fire-and-forget per-capture diagnostic for empirical
    // miss-rate tracking. Logs to LCC Opps; failures are swallowed.
    await recordSalesParserDiagnostic({
      domain,
      propertyId,
      saleId:                 loopSaleId,
      saleDate:               datePart,
      dataSource:             metadata._intake_promoted ? 'om_extraction' : 'costar_sidebar',
      metadata,
      sale,
      saleData,
      isMostRecent:           datePart === mostRecentSaleDatePart,
      isCurrent:              isCurrentSale,
      brokerFallbackAllowed:  brokerFallbackAllowed,
    });
  }

  // R37 (2026-06-17): surface prevent-at-write outcomes in the function logs
  // so the cron-log audit can confirm the sidebar stopped minting placeholders.
  if (skippedPriceless > 0 || dedupCollapsed > 0) {
    console.log(`[upsertDomainSales] R37 summary domain=${domain} property=${propertyId} wrote=${count} skipped_priceless=${skippedPriceless} (redundant=${skippedPricelessRedundant} new=${skippedPricelessNew}) dedup_collapsed=${dedupCollapsed}`);
  }

  return count;
}

// ── Sale-contacts PII persistence (C2 Part B, 2026-05-27) ───────────────
// Per Decision #5: when CoStar Sale Contacts carry phone/email/address/website
// for the buyer / seller / brokers, persist them to contacts with sale_id +
// sale_role so the relationship is queryable from the buyer-history view.
// Idempotent: looks up an existing contact for (sale_id, sale_role, name)
// before inserting and PATCHes new PII onto the existing row when found.
// Skipped entirely when no contact has at least one PII field beyond the name.
async function persistSaleContacts(domain, saleId, propertyId, metadata, provCollect) {
  if (!saleId) return 0;
  const contacts = Array.isArray(metadata?.contacts) ? metadata.contacts : [];
  if (contacts.length === 0) return 0;

  const isDia = domain === 'dialysis';
  const roleMap = {
    buyer: 'buyer',
    seller: 'seller',
    listing_broker: 'broker_listing',
    buyer_broker: 'broker_buyer',
  };
  const cols = isDia
    ? { name: 'contact_name', email: 'contact_email', phone: 'contact_phone' }
    : { name: 'name',         email: 'email',         phone: 'phone' };

  let written = 0;
  for (const c of contacts) {
    if (!c || typeof c !== 'object') continue;
    const saleRole = roleMap[c.role];
    if (!saleRole) continue;
    if (!c.name || typeof c.name !== 'string') continue;
    const trimmedName = c.name.trim();
    if (!trimmedName) continue;
    // C9 Phase 2 (2026-05-27): route through the ingest contract — catches
    // junk/section-label names AND federal-anti-pattern (broader than the
    // bare isJunkContactName check this replaced).
    {
      const { errors: cErrors } = validateContactIngest({
        domain, name: trimmedName, email: c.email || null, role: saleRole,
      });
      if (cErrors.some(e => e.startsWith('name '))) continue;
    }

    // Require at least one PII field beyond the name — a bare buyer-name
    // contact is already captured on sales_transactions.{buyer,buyer_name}
    // and writing it to contacts adds no information.
    const hasPii = !!(c.phone || c.email || c.address || c.website);
    if (!hasPii) continue;

    const fields = stripNulls({
      [cols.name]:  trimmedName,
      [cols.email]: c.email   || null,
      [cols.phone]: c.phone   || null,
      address:      c.address || null,
      website:      c.website || null,
      property_id:  isDia ? parseInt(propertyId, 10) : propertyId,
      sale_id:      saleId,
      sale_role:    saleRole,
      data_source:  'costar_sale_contacts',
    });

    const lookup = await domainQuery(domain, 'GET',
      `contacts?sale_id=eq.${saleId}&sale_role=eq.${encodeURIComponent(saleRole)}` +
      `&${cols.name}=ilike.${encodeURIComponent(trimmedName)}&select=contact_id&limit=1`);

    if (lookup.ok && lookup.data?.length) {
      const id = lookup.data[0].contact_id;
      const res = await domainPatch(domain, `contacts?contact_id=eq.${id}`, fields, 'persistSaleContacts:patch');
      if (res?.ok !== false) {
        written++;
        pushProvenance(provCollect, 'contacts', id, fields);
      }
    } else {
      const result = await domainQuery(domain, 'POST', 'contacts', fields,
        { label: 'persistSaleContacts:insert' });
      if (result.ok) {
        written++;
        const created = Array.isArray(result.data) ? result.data[0] : result.data;
        const newId = created?.contact_id;
        if (newId) {
          pushProvenance(provCollect, 'contacts', newId, fields);
        }
      }
    }
  }
  return written;
}

// ── Per-capture diagnostics (Round 76gp.d) ────────────────────────────────
// Logs to LCC Opps `sales_parser_diagnostics` so we can quantify, post-hoc,
// how often each field-of-interest made it from the parser's metadata into
// sales_transactions. Used to prioritize parser-fix work empirically rather
// than from one-off audit guesses. Fire-and-forget: errors are logged but
// never block the write path.
async function recordSalesParserDiagnostic(ctx) {
  // ctx: { domain, propertyId, saleId, saleDate, dataSource, metadata, sale,
  //        saleData, isMostRecent, isCurrent, brokerFallbackAllowed }
  try {
    const contacts = Array.isArray(ctx.metadata?.contacts) ? ctx.metadata.contacts : [];
    const parserSawListingBroker = contacts.some(c => c?.role === 'listing_broker');
    const parserSawBuyerBroker   = contacts.some(c => c?.role === 'buyer_broker');
    const parserSawBuyerContact  = contacts.some(c => c?.role === 'buyer');
    const parserSawSellerContact = contacts.some(c => c?.role === 'seller');
    const parserSawCapRate       = ctx.sale?.cap_rate != null || ctx.metadata?.cap_rate != null;
    const parserSawSoldPrice     = ctx.sale?.sale_price != null;

    const sd = ctx.saleData || {};
    const wroteListingBroker   = !!(sd.listing_broker && String(sd.listing_broker).trim());
    const wroteProcuringBroker = !!((sd.procuring_broker || sd.purchasing_broker) &&
                                    String(sd.procuring_broker || sd.purchasing_broker).trim());
    const wroteBuyer  = !!((sd.buyer_name || sd.buyer) && String(sd.buyer_name || sd.buyer).trim());
    const wroteSeller = !!((sd.seller_name || sd.seller) && String(sd.seller_name || sd.seller).trim());
    const wroteCap    = sd.stated_cap_rate != null || sd.sold_cap_rate != null
                     || sd.calculated_cap_rate != null;
    const wroteSoldPrice = sd.sold_price != null && Number(sd.sold_price) > 0;

    const daysSinceClose = ctx.saleDate
      ? Math.max(0, Math.round((Date.now() - new Date(ctx.saleDate).getTime()) / (24 * 60 * 60 * 1000)))
      : null;

    await opsQuery('POST', 'sales_parser_diagnostics', {
      domain:        ctx.domain === 'dialysis' ? 'dialysis' : 'government',
      property_id:   ctx.propertyId ?? null,
      sale_id:       ctx.saleId ?? null,
      sale_date:     ctx.saleDate ?? null,
      data_source:   ctx.dataSource || 'costar_sidebar',
      days_since_close:            daysSinceClose,
      is_most_recent_on_property:  !!ctx.isMostRecent,
      is_current_sale_90d:         !!ctx.isCurrent,
      parser_listing_broker_avail: parserSawListingBroker,
      parser_buyer_broker_avail:   parserSawBuyerBroker,
      parser_cap_rate_avail:       parserSawCapRate,
      parser_buyer_contact_avail:  parserSawBuyerContact,
      parser_seller_contact_avail: parserSawSellerContact,
      parser_sold_price_avail:     parserSawSoldPrice,
      written_listing_broker:   wroteListingBroker,
      written_procuring_broker: wroteProcuringBroker,
      written_cap_rate:         wroteCap,
      written_buyer:            wroteBuyer,
      written_seller:           wroteSeller,
      written_sold_price:       wroteSoldPrice,
      details: {
        broker_tag_match_tried: parserSawListingBroker && !wroteListingBroker,
        broker_fallback_allowed: !!ctx.brokerFallbackAllowed,
      },
    });
  } catch (err) {
    // Diagnostic writes are best-effort. Never propagate failures back to
    // the sale write path.
    console.warn('[sales-diagnostic] log failed:', err?.message);
  }
}

// ── Link sale_brokers table from listing_broker / procuring_broker text ──────
async function linkSaleBrokers(domain, saleId, saleData) {
  if (!saleId || domain !== 'dialysis') return;
  const brokerFields = [
    { text: saleData.listing_broker, role: 'listing' },
    { text: saleData.procuring_broker, role: 'procuring' },
  ];
  for (const { text, role } of brokerFields) {
    if (!text || text.length < 2) continue;
    try {
      // Normalize for lookup
      const normalized = text.trim().toLowerCase()
        .replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
      // Find existing broker by normalized_name or broker_name
      let brokerLookup = await domainQuery(domain, 'GET',
        `brokers?normalized_name=eq.${encodeURIComponent(normalized)}&select=broker_id&limit=1`
      );
      let brokerId = brokerLookup.ok && brokerLookup.data?.length
        ? brokerLookup.data[0].broker_id : null;
      // Fallback: case-insensitive name match
      if (!brokerId) {
        brokerLookup = await domainQuery(domain, 'GET',
          `brokers?broker_name=ilike.${encodeURIComponent(text.trim())}&select=broker_id&limit=1`
        );
        brokerId = brokerLookup.ok && brokerLookup.data?.length
          ? brokerLookup.data[0].broker_id : null;
      }
      if (brokerId) {
        // Check if already linked
        const existing = await domainQuery(domain, 'GET',
          `sale_brokers?sale_id=eq.${saleId}&broker_id=eq.${brokerId}&role=eq.${role}&select=sale_broker_id&limit=1`
        );
        if (!existing.data?.length) {
          await domainQuery(domain, 'POST', 'sale_brokers', {
            sale_id: saleId, broker_id: brokerId, role
          });
          console.log(`[linkSaleBrokers] linked broker_id=${brokerId} (${text}) as ${role} on sale_id=${saleId}`);
        }
      }
    } catch (err) {
      console.warn(`[linkSaleBrokers] error linking ${role} broker "${text}":`, err?.message);
    }
  }
}

// ── Alert BD team on new dialysis sale capture ──────────────────────────────
async function createSaleAlert(propertyId, saleData) {
  const price = saleData.sold_price
    ? '$' + Number(saleData.sold_price).toLocaleString(undefined, { maximumFractionDigits: 0 })
    : 'undisclosed price';
  const capRate = saleData.stated_cap_rate ? ` at ${saleData.stated_cap_rate}% cap` : '';
  const buyer = saleData.buyer_name || 'unknown buyer';

  await domainQuery('dialysis', 'POST', 'alerts_unified', {
    entity_type:   'property',
    entity_id:     String(propertyId),
    alert_type:    'new_sale',
    priority:      'high',
    title:         `New sale captured via CoStar`,
    message:       `Sold to ${buyer} for ${price}${capRate} on ${saleData.sale_date}`,
    data_source:   'costar_sidebar',
    is_resolved:   false,
    created_at:    new Date().toISOString(),
  });
}

// ── Auto-stage gov comp for Salesforce sync ─────────────────────────────────
async function stageGovCompForSalesforce(propertyId, entity, metadata) {
  // Check if already staged for this property + most recent sale date
  const mostRecentSale = (metadata.sales_history || [])
    .filter(s => s.sale_date)
    .sort((a, b) => new Date(b.sale_date) - new Date(a.sale_date))[0];
  if (!mostRecentSale) return;

  const saleDate = parseDate(mostRecentSale.sale_date)?.split('T')[0];
  if (!saleDate) return;

  // Check for existing staging row. Column names must match the real
  // sf_comps_staging schema (street/sold_date/staging_id) — the same columns
  // the INSERT below uses. The old address/sale_date/id form errored every
  // run ("column sf_comps_staging.id does not exist") and never deduped.
  const existing = await domainQuery('government', 'GET',
    `sf_comps_staging?street=eq.${encodeURIComponent(entity.address || '')}` +
    `&sold_date=eq.${saleDate}&select=staging_id&limit=1`
  );
  if (existing.ok && existing.data?.length) return; // already staged

  const buyerContact = (metadata.contacts || []).find(c => c.role === 'buyer');
  const sellerContact = (metadata.contacts || []).find(c => c.role === 'seller');

  // Fresh audit A-3 (2026-05-18): rewritten to match the real
  // sf_comps_staging schema. The old payload (address/sale_price/
  // sale_date/buyer_name/seller_name/square_feet/sync_status) didn't
  // match any columns — PostgREST 400'd every write with PGRST204
  // "Could not find the 'address' column" (178 silent 4xx/24h).
  // Real columns: street/sold_price/sold_date/building_sf/...
  // Buyer + seller names stash in raw_row (jsonb) since the table
  // has no dedicated columns for them.
  await domainQuery('government', 'POST', 'sf_comps_staging', {
    // D2 (2026-06-06): import_batch is NOT NULL with no default. The sidebar
    // writer never set it, so EVERY costar_sidebar auto-stage insert 4xx'd on
    // the constraint (verified: 0 costar_sidebar rows ever landed). Stamp a
    // stable daily batch so the row inserts and the SF sync's
    // (sf_id, source_system, import_batch) upsert key stays meaningful.
    import_batch:       'costar_sidebar_' + new Date().toISOString().slice(0, 10),
    street:             entity.address || null,
    city:               entity.city    || null,
    state:              entity.state   || null,
    sold_date:          saleDate,
    sold_price:         parseCurrency(mostRecentSale.sale_price),
    sold_cap_rate:      parseCapRateDecimal(mostRecentSale.cap_rate),
    building_sf:        parseSF(metadata.square_footage),
    linked_property_id: propertyId,
    source_system:      'costar_sidebar',
    process_status:     'pending',
    raw_row: {
      buyer_name:  cleanSalesPartyValue(buyerContact?.name || mostRecentSale.buyer),
      seller_name: cleanSalesPartyValue(sellerContact?.name || mostRecentSale.seller),
    },
  }, { label: 'autoStageGovComp' });
}

/**
 * Upsert broker records and sale_brokers junction links in the Dialysis DB.
 * Collects broker names from metadata.contacts[], normalizes them, upserts into
 * the brokers table, then links each broker to the relevant sale via sale_brokers.
 */
async function upsertDialysisBrokerLinks(propertyId, salesResult, metadata, provCollect) {
  const contacts = metadata.contacts;
  if (!Array.isArray(contacts)) return 0;

  const brokerContacts = contacts.filter(
    c => c.role === 'listing_broker' || c.role === 'buyer_broker'
  );
  if (brokerContacts.length === 0) return 0;

  // Map role to sale_brokers.role value
  const roleMap = { listing_broker: 'listing', buyer_broker: 'procuring' };

  let created = 0;

  // Regex to detect firm/company names vs. actual person names
  // e.g. "Horvath & Tremblay" or "Marcus & Millichap" match on "&"
  const FIRM_PATTERN = /\b(LLC|INC|CORP|LTD|LP|LLP|PARTNERS|GROUP|ASSOCIATES|ADVISORS|REALTY|PROPERTIES|CAPITAL|INVESTMENTS|COMMERCIAL|RETAIL|&)\b/i;

  // ── Pass 2: Group-based firm→person assignment ──
  // Contacts are extracted in CoStar order, where one or more people are
  // followed by the firm they all work for. Walk the array collecting people,
  // and when a firm entry is encountered, assign it to ALL people in the
  // current group who don't yet have a company. This correctly handles
  // groups with multiple people sharing a single firm (e.g. Matt Hagar +
  // Yuan-Sing Chang both at AiCRE Partners, or Alvin Mansour + Phil Sambazis
  // both at Marcus & Millichap).
  let groupPeople = [];
  for (const contact of brokerContacts) {
    const isFirm = FIRM_PATTERN.test(contact.name || '');
    if (!isFirm) {
      groupPeople.push(contact);
    } else {
      // Firm encountered — assign to ALL people in the current group
      // who don't yet have a company
      for (const person of groupPeople) {
        if (!person.company) person.company = contact.name;
      }
      groupPeople = []; // reset for next group
    }
  }

  // Re-derive people and firms arrays after assignment
  const people = brokerContacts.filter(c => !FIRM_PATTERN.test(c.name || ''));
  const firms  = brokerContacts.filter(c =>  FIRM_PATTERN.test(c.name || ''));

  // ── Pass 3: Process people — create broker records + sale_brokers entries ──
  for (const contact of people) {
    const name = (contact.name || '').trim();
    if (!name) continue;

    // Normalize: lowercase, strip common suffixes, collapse whitespace
    const normalized = name
      .toLowerCase()
      .replace(/\b(llc|inc|corp|ltd|lp|llp|co|company|group|associates|advisors)\b\.?/gi, '')
      .replace(/[.,]/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    if (!normalized) continue;

    // Look up existing broker by normalized_name
    const encodedNorm = encodeURIComponent(normalized);
    const lookup = await domainQuery('dialysis', 'GET',
      `brokers?normalized_name=eq.${encodedNorm}&select=broker_id,email,phone,company&limit=1`
    );

    let brokerId;
    if (lookup.ok && lookup.data?.length) {
      brokerId = lookup.data[0].broker_id;

      // Patch null contact fields if we now have data
      const existing = lookup.data[0];
      const patch = stripNulls({
        email: existing.email == null && contact.email ? contact.email : null,
        phone: existing.phone == null && contact.phones?.[0] ? contact.phones[0] : null,
        company: existing.company == null && contact.company ? contact.company : null,
      });
      if (Object.keys(patch).length) {
        await domainPatch('dialysis',
          `brokers?broker_id=eq.${brokerId}`, patch, 'upsertDialysisBrokerLinks'
        );
      }
    } else {
      // Insert new broker with company from the firm assignment above
      const brokerData = stripNulls({
        broker_name: name,
        email: contact.email || null,
        phone: contact.phones?.[0] || null,
        company: contact.company || null,
        normalized_name: normalized,
      });
      const ins = await domainQuery('dialysis', 'POST', 'brokers', brokerData);
      if (!ins.ok || !ins.data?.length) continue;
      brokerId = ins.data[0].broker_id;
      created++;
      // Phase 2.2.c: provenance for newly inserted broker (person)
      pushProvenance(provCollect, 'brokers', brokerId, {
        broker_name: name,
        email:       contact.email || null,
        phone:       contact.phones?.[0] || null,
        company:     contact.company || null,
      });
    }

    // Link broker to each sale for this property written in this pipeline run
    const sales = metadata.sales_history;
    if (!Array.isArray(sales)) continue;

    for (const sale of sales) {
      // Skip land / pre-development sales — they distort broker market stats.
      const { exclude_from_market_metrics } = classifySaleType(sale);
      if (exclude_from_market_metrics) continue;

      const saleDate = parseDate(sale.sale_date);
      if (!saleDate) continue;
      const datePart = saleDate.split('T')[0];

      // Match broker to their transaction using the tagged buyer/seller,
      // falling back to recency if no tag is available
      const hasSaleTag = contact.sale_buyer || contact.sale_seller;
      if (hasSaleTag) {
        // Broker was tagged with a specific transaction group —
        // only link to sales that match the buyer or seller
        const buyerMatch  = contact.sale_buyer
          && sale.buyer === contact.sale_buyer?.toUpperCase()?.trim();
        const sellerMatch = contact.sale_seller
          && sale.seller === contact.sale_seller?.toUpperCase()?.trim();
        // Also try case-insensitive token match. Split on spaces AND hyphens
        // so hyphenated compounds like "Tognoli-Blefari-Thompson" yield
        // individual tokens that can match "THOMAS C TOGNOLI; LYNN D TOGNOLI".
        const buyerTokens = (contact.sale_buyer || '')
          .toLowerCase()
          .split(/[\s\-]+/)
          .filter(t => t.length >= 4);
        const buyerFuzzy = buyerTokens.length > 0 && (
          sale.buyer_name || sale.buyer || ''
        ).toLowerCase().split(/[\s\-;,]+/)
          .some(nameToken => buyerTokens.includes(nameToken));

        const sellerTokens = (contact.sale_seller || '')
          .toLowerCase()
          .split(/[\s\-]+/)
          .filter(t => t.length >= 4);
        const sellerFuzzy = sellerTokens.length > 0 && (
          sale.seller_name || sale.seller || ''
        ).toLowerCase().split(/[\s\-;,]+/)
          .some(nameToken => sellerTokens.includes(nameToken));
        if (!buyerMatch && !sellerMatch && !buyerFuzzy && !sellerFuzzy) continue;
      } else {
        // No tag — fall back to 90-day recency filter (current sale only)
        const saleDateObj  = new Date(saleDate);
        const ninetyDaysAgo = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
        if (saleDateObj < ninetyDaysAgo) continue;
      }

      // Look up the sale_id by property_id + sale_date
      const saleLookup = await domainQuery('dialysis', 'GET',
        `sales_transactions?property_id=eq.${propertyId}&sale_date=eq.${datePart}&select=sale_id&limit=1`
      );
      if (!saleLookup.ok || !saleLookup.data?.length) continue;
      const saleId = saleLookup.data[0].sale_id;

      // Check if junction row already exists
      const junctionLookup = await domainQuery('dialysis', 'GET',
        `sale_brokers?sale_id=eq.${saleId}&broker_id=eq.${brokerId}&select=sale_broker_id&limit=1`
      );
      if (junctionLookup.ok && junctionLookup.data?.length) continue;

      // Insert junction record
      await domainQuery('dialysis', 'POST', 'sale_brokers', {
        sale_id: saleId,
        broker_id: brokerId,
        role: roleMap[contact.role] || contact.role,
      });
    }
  }

  // ── Pass 4: Handle firm-only listings (no person from the same firm) ──
  // If a firm has no matching person, create a broker record + sale_brokers
  // for the firm itself so we don't lose data.
  const processedCompanies = new Set(people.map(p => p.company).filter(Boolean));

  for (const firm of firms) {
    const firmName = (firm.name || '').trim();
    if (!firmName) continue;

    // A person already carries this firm as their company — skip
    if (processedCompanies.has(firmName)) continue;

    // Normalize firm name for lookup
    const normalized = firmName
      .toLowerCase()
      .replace(/\b(llc|inc|corp|ltd|lp|llp|co|company|group|associates|advisors)\b\.?/gi, '')
      .replace(/[.,]/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    if (!normalized) continue;

    const encodedNorm = encodeURIComponent(normalized);
    const lookup = await domainQuery('dialysis', 'GET',
      `brokers?normalized_name=eq.${encodedNorm}&select=broker_id&limit=1`
    );

    let brokerId;
    if (lookup.ok && lookup.data?.length) {
      brokerId = lookup.data[0].broker_id;
    } else {
      const brokerData = stripNulls({
        broker_name: firmName,
        email: firm.email || null,
        phone: firm.phones?.[0] || null,
        company: firmName,
        normalized_name: normalized,
      });
      const ins = await domainQuery('dialysis', 'POST', 'brokers', brokerData);
      if (!ins.ok || !ins.data?.length) continue;
      brokerId = ins.data[0].broker_id;
      created++;
      // Phase 2.2.c: provenance for newly inserted firm broker
      pushProvenance(provCollect, 'brokers', brokerId, {
        broker_name: firmName,
        email:       firm.email || null,
        phone:       firm.phones?.[0] || null,
        company:     firmName,
      });
    }

    // Link firm broker to each sale
    const sales = metadata.sales_history;
    if (!Array.isArray(sales)) continue;

    for (const sale of sales) {
      // Skip land / pre-development sales — they distort broker market stats.
      const { exclude_from_market_metrics } = classifySaleType(sale);
      if (exclude_from_market_metrics) continue;

      const saleDate = parseDate(sale.sale_date);
      if (!saleDate) continue;
      const datePart = saleDate.split('T')[0];

      // Match broker to their transaction using the tagged buyer/seller,
      // falling back to recency if no tag is available
      const hasSaleTag = firm.sale_buyer || firm.sale_seller;
      if (hasSaleTag) {
        // Broker was tagged with a specific transaction group —
        // only link to sales that match the buyer or seller
        const buyerMatch  = firm.sale_buyer
          && sale.buyer === firm.sale_buyer?.toUpperCase()?.trim();
        const sellerMatch = firm.sale_seller
          && sale.seller === firm.sale_seller?.toUpperCase()?.trim();
        // Also try case-insensitive partial match
        const buyerFuzzy  = firm.sale_buyer && sale.buyer_name
          && sale.buyer_name.toLowerCase().includes(
               firm.sale_buyer.toLowerCase().split(' ')[0]);
        const sellerFuzzy = firm.sale_seller && sale.seller_name
          && sale.seller_name.toLowerCase().includes(
               firm.sale_seller.toLowerCase().split(' ')[0]);
        if (!buyerMatch && !sellerMatch && !buyerFuzzy && !sellerFuzzy) continue;
      } else {
        // No tag — fall back to 90-day recency filter (current sale only)
        const saleDateObj  = new Date(saleDate);
        const ninetyDaysAgo = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
        if (saleDateObj < ninetyDaysAgo) continue;
      }

      const saleLookup = await domainQuery('dialysis', 'GET',
        `sales_transactions?property_id=eq.${propertyId}&sale_date=eq.${datePart}&select=sale_id&limit=1`
      );
      if (!saleLookup.ok || !saleLookup.data?.length) continue;
      const saleId = saleLookup.data[0].sale_id;

      const junctionLookup = await domainQuery('dialysis', 'GET',
        `sale_brokers?sale_id=eq.${saleId}&broker_id=eq.${brokerId}&select=sale_broker_id&limit=1`
      );
      if (junctionLookup.ok && junctionLookup.data?.length) continue;

      await domainQuery('dialysis', 'POST', 'sale_brokers', {
        sale_id: saleId,
        broker_id: brokerId,
        role: roleMap[firm.role] || firm.role,
      });
    }
  }

  return created;
}

// ── Step 5b2-gov: Upsert brokers (government) ────────────────────────────

/**
 * Upsert broker records in the government brokers table.
 * Gov brokers table has a different schema than Dialysis — no sale_brokers
 * junction table exists in gov, so we only upsert broker records themselves.
 *
 * For each listing_broker / buyer_broker contact:
 *   - Build canonical_name (lowercase, strip punctuation, collapse spaces)
 *   - Look up by canonical_name (ilike match)
 *   - INSERT if not found; PATCH email/phone/firm only if previously null
 *
 * Returns count of broker records created.
 */
async function upsertGovBrokers(propertyId, metadata, provCollect) {
  const contacts = metadata.contacts;
  if (!Array.isArray(contacts)) return 0;

  const brokerContacts = contacts.filter(
    c => c.role === 'listing_broker' || c.role === 'buyer_broker'
  );
  if (brokerContacts.length === 0) return 0;

  let created = 0;

  for (const contact of brokerContacts) {
    const name = (contact.name || '').trim();
    if (!name) continue;

    // Build canonical_name: lowercase, strip punctuation, collapse spaces
    const canonicalName = name
      .toLowerCase()
      .replace(/[^\w\s]/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    if (!canonicalName) continue;

    // Look up existing broker by canonical_name (case-insensitive)
    const encodedName = encodeURIComponent(canonicalName);
    const lookup = await domainQuery('government', 'GET',
      `brokers?canonical_name=ilike.${encodedName}&select=broker_id,email,phone,firm&limit=1`
    );

    if (lookup.ok && lookup.data?.length) {
      // PATCH only null fields — don't overwrite existing data
      const existing = lookup.data[0];
      const patchData = {};
      if (!existing.email && contact.email) patchData.email = contact.email;
      if (!existing.phone && contact.phones?.[0]) patchData.phone = contact.phones[0];
      if (!existing.firm && contact.company) patchData.firm = contact.company;

      if (Object.keys(patchData).length > 0) {
        await domainPatch('government',
          `brokers?broker_id=eq.${existing.broker_id}`, patchData, 'upsertGovBrokers');
        // Phase 2.2.c: provenance for the patched fields only
        pushProvenance(provCollect, 'brokers', existing.broker_id, patchData);
      }
    } else {
      // INSERT new broker record
      const brokerData = stripNulls({
        name,
        firm: contact.company || null,
        email: contact.email || null,
        phone: contact.phones?.[0] || null,
        canonical_name: canonicalName,
        active: true,
      });
      const ins = await domainQuery('government', 'POST', 'brokers', brokerData);
      if (ins.ok) {
        created++;
        const inserted = Array.isArray(ins.data) ? ins.data[0] : ins.data;
        if (inserted?.broker_id) {
          pushProvenance(provCollect, 'brokers', inserted.broker_id, {
            name, firm: contact.company || null,
            email: contact.email || null,
            phone: contact.phones?.[0] || null,
          });
        }
      }
    }
  }

  return created;
}

/**
 * Upsert deed records in the Dialysis database from sales_history entries.
 * Only processes entries that have a document_number.
 * Deduplicates by data_hash (document_number + state + recording_date).
 * Deed records are immutable — existing records are never updated.
 * Returns count of records inserted.
 */
async function upsertDialysisDeedRecords(propertyId, entity, metadata, provCollect) {
  const sales = metadata.sales_history;
  if (!Array.isArray(sales) || sales.length === 0) return 0;

  // Round 76ae 2026-04-28: only write deed_records when we have a propertyId.
  // Orphan deeds (no property linkage) provide no analytic value and clutter
  // the table — we'd rather skip than insert untraceable rows.
  if (!propertyId) {
    console.warn(`[upsertDialysisDeedRecords] no propertyId — skipping ${sales.length} sale-history entries (would have created orphans)`);
    return 0;
  }

  let inserted = 0;

  for (const sale of sales) {
    if (!sale.document_number) continue;

    // Round 76cp: skip mortgage/loan entries - they belong in the `loans`
    // table (handled by upsertDomainLoans), not deed_records. CoStar's
    // Sale History tab includes both deed and mortgage records mixed
    // together; the deed_type/transaction_type field distinguishes them.
    const txnType = String(sale.transaction_type || sale.deed_type || '').toLowerCase();
    const looksLikeLoan = txnType.includes('mortgage')
                       || txnType.includes('loan')
                       || txnType.includes('lien')
                       || sale.lender
                       || sale.loan_amount;
    if (looksLikeLoan) continue;

    const datePart = parseDate(sale.recordation_date)?.split('T')[0] || null;

    // Build deterministic dedup hash: document_number|state|recording_date
    const hashSource = `${sale.document_number}|${entity.state || ''}|${datePart || ''}`;
    const dataHash = Buffer.from(hashSource).toString('base64');

    // Check if a deed_record with this hash already exists — skip if so (immutable).
    // If it exists but is orphaned (property_id NULL), patch it now that we
    // know the linkage. This is the recovery path for the 24+ rows already
    // inserted from CoStar Sale History before this writer wrote property_id.
    const lookup = await domainQuery('dialysis', 'GET',
      `deed_records?data_hash=eq.${encodeURIComponent(dataHash)}&select=id,property_id&limit=1`
    );
    if (lookup.ok && lookup.data?.length) {
      const existing = lookup.data[0];
      if (existing.property_id == null && propertyId) {
        await domainQuery('dialysis', 'PATCH',
          `deed_records?id=eq.${encodeURIComponent(existing.id)}`,
          { property_id: propertyId }
        );
      }
      continue;
    }

    const deedRecord = stripNulls({
      property_id: propertyId,                    // Round 76ae: linked!
      county: entity.county || metadata.county || null,
      state: entity.state || null,
      recording_date: datePart,
      document_number: sale.document_number,
      deed_type: sale.deed_type || null,
      grantor: sale.seller || null,
      grantee: sale.buyer || null,
      consideration: parseCurrency(sale.sale_price),
      raw_payload: sale,
      data_hash: dataHash,
      fetched_at: metadata.extracted_at || new Date().toISOString(),
    });

    // data_hash is NOT NULL, ensure it's always present after stripNulls
    deedRecord.data_hash = dataHash;

    const result = await domainQuery('dialysis', 'POST', 'deed_records', deedRecord);
    if (result.ok) {
      inserted++;
      const created = Array.isArray(result.data) ? result.data[0] : result.data;
      const deedId = created?.id || created?.deed_id;
      if (deedId) {
        pushProvenance(provCollect, 'deed_records', deedId, {
          document_number: deedRecord.document_number,
          deed_type:       deedRecord.deed_type,
          grantor:         deedRecord.grantor,
          grantee:         deedRecord.grantee,
          recording_date:  deedRecord.recording_date,
          consideration:   deedRecord.consideration,
        });
      }
    }
  }

  return inserted;
}

/**
 * Upsert deed records into the government domain database.
 * Government deed_records has no property_id — it uses parcel_id (UUID FK to
 * parcel_records).  Since we may not have a parcel UUID, we write with
 * available fields only, using document_number as the dedup key.
 * Filters out mortgage-type deeds via MORTGAGE_DEED_TYPES.
 */
async function upsertGovernmentDeedRecords(entity, metadata, provCollect) {
  const deedSales = (metadata.sales_history || []).filter(s =>
    s.document_number &&
    s.deed_type &&
    !MORTGAGE_DEED_TYPES.test(s.deed_type)
  );
  if (deedSales.length === 0) return 0;

  let count = 0;
  for (const sale of deedSales) {
    const dataHash = Buffer.from(
      `${sale.document_number}|${entity.state || ''}|${sale.sale_date || ''}`
    ).toString('base64');

    const existing = await domainQuery('government', 'GET',
      `deed_records?data_hash=eq.${encodeURIComponent(dataHash)}&select=deed_id&limit=1`
    );
    if (existing.ok && existing.data?.length) continue;

    const dateStr = parseDate(sale.recordation_date || sale.sale_date)
      ?.split('T')[0] || null;

    const deedRow = {
      document_number: sale.document_number,
      deed_type:       sale.deed_type || null,
      grantor:         sale.seller    || null,
      grantee:         sale.buyer     || null,
      recording_date:  dateStr,
      consideration:   parseCurrency(sale.sale_price),
      county:          entity.county  || null,
      state_code:      entity.state   || null,
      data_hash:       dataHash,
      raw_payload:     sale,
    };
    const r = await domainQuery('government', 'POST', 'deed_records', deedRow);
    if (r.ok) {
      count++;
      const created = Array.isArray(r.data) ? r.data[0] : r.data;
      const deedId = created?.deed_id || created?.id;
      if (deedId) {
        pushProvenance(provCollect, 'deed_records', deedId, {
          document_number: deedRow.document_number,
          deed_type:       deedRow.deed_type,
          grantor:         deedRow.grantor,
          grantee:         deedRow.grantee,
          recording_date:  deedRow.recording_date,
          consideration:   deedRow.consideration,
        });
      }
    }
  }
  return count;
}

/**
 * Map a raw CoStar loan type description to the constrained values
 * allowed by the Dialysis loans table CHECK constraint ('Refinance' or
 * 'Acquisition'). Returns null for unknown types rather than violating
 * the constraint.
 */
function mapLoanType(rawType) {
  if (!rawType) return null;
  const t = rawType.toLowerCase();
  // Any purchase/acquisition loan
  if (t.includes('purchase') || t.includes('acquisition') ||
      t.includes('commercial') || t.includes('construction') ||
      t.includes('future advance') || t.includes('open end') ||
      t.includes('bridge') || t.includes('new') ||
      t.includes('purchase money')) {
    return 'Acquisition';
  }
  // Any refinance loan
  if (t.includes('refinanc') || t.includes('refi') ||
      t.includes('cash out') || t.includes('rate') ||
      t.includes('term') || t.includes('modification')) {
    return 'Refinance';
  }
  // Unknown — send null rather than violate the constraint
  return null;
}

/**
 * Upsert loan records in the domain database.
 * Created from sales_history entries that have lender/loan_amount data.
 */
async function upsertDomainLoans(domain, propertyId, metadata, provCollect) {
  const sales = metadata.sales_history;
  if (!Array.isArray(sales) || sales.length === 0) return 0;

  let count = 0;
  for (const sale of sales) {
    // Accept either `lender` (extractor default, parseDeedHistory line 2016)
    // or `lender_name` (alternate emitted by sales_transactions enrichers
    // and a few Public Records DOM paths). A sale that only carries
    // `lender_name` — like the CMFG Life $23.5M loan on property 11450 —
    // was silently being dropped here because the check required the
    // literal `lender` key.
    const lenderName = sale.lender || sale.lender_name || null;
    // Loan amount can arrive under a few aliases depending on whether the
    // row came from the Transaction Details stat card, the Loan Details
    // sub-section, or a stand-alone Loans Initiated block.
    const rawLoanAmount = sale.loan_amount
      ?? sale.mortgage_amount
      ?? sale.amount_financed
      ?? null;
    if (!lenderName || !rawLoanAmount) continue;

    const loanAmount = parseCurrency(rawLoanAmount);
    if (!loanAmount) continue;

    // Round 76ep (2026-05-09): fall back to sale.sale_date for the loan's
    // origination_date when no specific date is present. RCA captures don't
    // emit loan_origination_date — they have the event sale_date (which IS
    // when the loan was originated for Refinance / Construction events).
    // Without this fallback, every RCA-sourced loan was landing with
    // origination_date=null even though the date is right there on the
    // event row.
    const originationDatePart =
      parseDate(sale.loan_origination_date
        || sale.origination_date
        || sale.mortgage_date
        || sale.sale_date)?.split('T')[0] || null;

    // Defensive dedup: the same mortgage can reach us twice — once from the
    // stat-card (signing date) and once from Public Records (recordation
    // date), potentially with slightly different rounded loan amounts. Treat
    // rows on the same property within ±5% of the loan amount as the same
    // loan, and — when origination_date is known on both sides — require
    // the dates to be within ±14 days. PostgREST can't express the ±5%
    // band in a single URL, so we fetch the ±5% window and pick the best
    // candidate in JS.
    const amtLo = Math.floor(loanAmount * 0.95);
    const amtHi = Math.ceil(loanAmount * 1.05);
    const lenderFilter = domain === 'government'
      ? ''  // gov loans has no lender_name column
      : `&lender_name=ilike.${encodeURIComponent(lenderName)}`;
    const lookupSelect = domain === 'government'
      ? 'loan_id,loan_amount,origination_date'
      : 'loan_id,loan_amount,origination_date,lender_name';
    const lookup = await domainQuery(domain, 'GET',
      `loans?property_id=eq.${propertyId}` +
      `&loan_amount=gte.${amtLo}&loan_amount=lte.${amtHi}` +
      `${lenderFilter}&select=${lookupSelect}&limit=5`
    );

    let matchedLoanId = null;
    if (lookup.ok && Array.isArray(lookup.data)) {
      for (const cand of lookup.data) {
        const candDate = cand.origination_date
          ? String(cand.origination_date).split('T')[0]
          : null;
        let dateOk = true;
        if (originationDatePart && candDate) {
          const daysDiff = Math.abs(
            new Date(candDate).getTime() - new Date(originationDatePart).getTime()
          ) / 86400000;
          dateOk = daysDiff <= 14;
        }
        if (dateOk) {
          matchedLoanId = cand.loan_id;
          break;
        }
      }
    }

    const loanType = mapLoanType(sale.loan_type);

    // Round 76cu: pull CMBS deal identifiers captured by extension/content/rca.js
    // (Round 76ct). When the borrower text named a securitization pool —
    // e.g. "CFCRE 2016-C6" or "GSMS 2014-GC22" — write deal_name + sponsor +
    // vintage + tranche so v_cmbs_portfolio can group exposure by trust.
    const cmbsDealName = sale.cmbs_deal_name ? String(sale.cmbs_deal_name).trim().substring(0, 80) : null;
    const cmbsSponsor  = sale.cmbs_sponsor   ? String(sale.cmbs_sponsor).trim().substring(0, 40)  : null;
    const cmbsVintage  = Number.isFinite(parseInt(sale.cmbs_vintage, 10)) ? parseInt(sale.cmbs_vintage, 10) : null;
    const cmbsTranche  = sale.cmbs_tranche   ? String(sale.cmbs_tranche).trim().substring(0, 20)  : null;
    // Vintage sanity (1990-2100) — guards against the regex matching a year
    // in unrelated text. A vintage outside that window means the upstream
    // capture isn't actually a CMBS deal name.
    const cmbsValid = cmbsDealName && cmbsVintage && cmbsVintage >= 1990 && cmbsVintage <= 2100;

    // Government loans table has different column names (no text lender
    // column, term_years instead of loan_term, interest_rate instead of
    // interest_rate_percent), so build a domain-specific payload.
    const nowIso = new Date().toISOString();
    const loanData = domain === 'government' ? stripNulls({
      property_id:      propertyId,
      loan_type:        loanType,
      loan_amount:      loanAmount,
      interest_rate:    parsePercent(sale.interest_rate),
      term_years:       sale.loan_term ? parseFloat(sale.loan_term) / 12 : null,
      origination_date: originationDatePart,
      maturity_date:    parseDate(sale.maturity_date)?.split('T')[0] || null,
      // Round 76ep (2026-05-09): write the lender name into gov.loans.originator
      // (text column added in Round 76ek.a). Previously gov loans only had
      // lender_id (uuid FK); RCA captures don't have FK lookup so the loan
      // landed with no human-readable lender attribution at all.
      originator:       lenderName,
      data_source:      'costar_sidebar',
      // CMBS enrichment (Round 76cu)
      cmbs_deal_name:   cmbsValid ? cmbsDealName : null,
      cmbs_sponsor:     cmbsValid ? cmbsSponsor  : null,
      cmbs_vintage:     cmbsValid ? cmbsVintage  : null,
      cmbs_tranche:     cmbsValid ? cmbsTranche  : null,
    }) : stripNulls({
      property_id:           propertyId,
      lender_name:           lenderName,
      loan_amount:           loanAmount,
      loan_type:             loanType,
      origination_date:      originationDatePart,
      interest_rate_percent: parsePercent(sale.interest_rate),
      loan_term:             parseIntSafe(sale.loan_term),
      maturity_date:         parseDate(sale.maturity_date)?.split('T')[0] || null,
      data_source:           'costar_sidebar',
      // CMBS enrichment (Round 76cu)
      cmbs_deal_name:        cmbsValid ? cmbsDealName : null,
      cmbs_sponsor:          cmbsValid ? cmbsSponsor  : null,
      cmbs_vintage:          cmbsValid ? cmbsVintage  : null,
      cmbs_tranche:          cmbsValid ? cmbsTranche  : null,
    });

    if (matchedLoanId != null) {
      // Always PATCH on re-ingest so loans.updated_at advances (the ops
      // audit signal that CoStar re-touched the row). Explicit
      // updated_at is added on top of the fresh payload.
      // Round 76co (Phase 4): consult priority registry before loans PATCH.
      const filteredLoanPatch = await filterByFieldPriority({
        targetDb:    domain === 'dialysis' ? 'dia_db' : 'gov_db',
        targetTable: domain === 'dialysis' ? 'dia.loans' : 'gov.loans',
        recordPk:    matchedLoanId,
        source:      'costar_sidebar',
        confidence:  0.6,
        fields:      { ...loanData, updated_at: nowIso },
      }).catch(err => {
        console.warn('[upsertDomainLoans] field-priority filter failed:', err?.message);
        return { ...loanData, updated_at: nowIso };
      });
      await domainPatch(domain,
        `loans?loan_id=eq.${matchedLoanId}`,
        filteredLoanPatch,
        'upsertDomainLoans'
      );
      pushProvenance(provCollect, 'loans', matchedLoanId, loanData);
    } else {
      const result = await domainQuery(domain, 'POST', 'loans', loanData);
      if (result.ok) {
        count++;
        const inserted = Array.isArray(result.data) ? result.data[0] : result.data;
        if (inserted?.loan_id) {
          pushProvenance(provCollect, 'loans', inserted.loan_id, loanData);
        }
      } else {
        // Round 76er: surface silent failures (was a 5-month bug where the
        // dia.loans data_source column-not-found error went unlogged).
        console.warn(`[upsertDomainLoans] POST failed status=${result.status}: ${JSON.stringify(result.data)}; payload keys=${Object.keys(loanData).join(',')}`);
      }
    }
  }

  // Fallback path: a loan shown on the sidebar UI (Lender: CMFG Life,
  // Loan Amount: $23.5M) is sometimes split across a `role='lender'`
  // contact row and a top-level stat-card loan_amount / loan_type pair,
  // instead of being packed into a single sales_history entry. The
  // sales_history iterator above misses those because neither row
  // carries both `lender` AND `loan_amount`. Compose one loan write per
  // distinct lender contact, using stat-card fields for amount/type and
  // the most recent non-mortgage sale_date as the origination date.
  const lenderContacts = (metadata.contacts || []).filter(c =>
    (c.role === 'lender' || (Array.isArray(c.roles) && c.roles.includes('lender')))
    && c.name && c.name.length > 2
  );
  if (lenderContacts.length > 0) {
    const statLoanAmount = parseCurrency(
      metadata.loan_amount
        ?? metadata.current_loan_amount
        ?? metadata.last_loan_amount
    );
    const statOrigination = parseDate(
      metadata.loan_origination_date
        ?? metadata.origination_date
        ?? metadata.last_loan_origination_date
    )?.split('T')[0] || null;

    const mostRecentSale = (metadata.sales_history || [])
      .filter(s => s.sale_date
        && !(s.deed_type && MORTGAGE_DEED_TYPES.test(s.deed_type)))
      .map(s => ({
        date: parseDate(s.sale_date)?.split('T')[0] || null,
      }))
      .filter(s => s.date)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0]
      ?.date || null;

    const fallbackAmount = statLoanAmount;
    const fallbackDate = statOrigination || mostRecentSale;

    for (const lender of lenderContacts) {
      if (!fallbackAmount) continue;

      // Check whether a loan with this amount already exists (either
      // written by the sales_history loop above or a prior run). Match
      // on property + amount within 1% to avoid writing the same loan
      // twice when CMFG Life is also present on a sales_history row.
      const amtLo = Math.floor(fallbackAmount * 0.99);
      const amtHi = Math.ceil(fallbackAmount * 1.01);
      const lookupSelect = domain === 'government'
        ? 'loan_id'
        : 'loan_id,lender_name';
      const dupCheck = await domainQuery(domain, 'GET',
        `loans?property_id=eq.${propertyId}` +
        `&loan_amount=gte.${amtLo}&loan_amount=lte.${amtHi}` +
        `&select=${lookupSelect}&limit=1`
      );
      if (dupCheck.ok && dupCheck.data?.length) continue;

      const fallbackLoanType = mapLoanType(
        metadata.loan_type || metadata.current_loan_type || null
      );
      const loanData = domain === 'government' ? stripNulls({
        property_id:      propertyId,
        loan_type:        fallbackLoanType,
        loan_amount:      fallbackAmount,
        origination_date: fallbackDate,
        data_source:      'costar_sidebar',
      }) : stripNulls({
        property_id:      propertyId,
        lender_name:      lender.name,
        loan_amount:      fallbackAmount,
        loan_type:        fallbackLoanType,
        origination_date: fallbackDate,
        data_source:      'costar_sidebar',
      });

      const result = await domainQuery(domain, 'POST', 'loans', loanData);
      if (result.ok) {
        count++;
        console.log(`[upsertDomainLoans] fallback wrote loan for lender="${lender.name}" ` +
          `amount=$${fallbackAmount} property=${propertyId}`);
        const inserted = Array.isArray(result.data) ? result.data[0] : result.data;
        if (inserted?.loan_id) {
          pushProvenance(provCollect, 'loans', inserted.loan_id, loanData);
        }
      }
    }
  }

  // ── Round 76er.c (2026-05-13): RCA Financing section ingestion ──
  // RCA pages carry a dedicated Financing block with 16 label/value pairs:
  //   Loan Status, Loan Type, Loan Amount, Interest Rate, Debt Yield,
  //   Total Reserves, Term, Deal Appraisal, Originator, Lender Name,
  //   Lender Group, Special Servicer, Original LTV, Origination,
  //   Defeasance Date, Prepayment Date, Original Maturity
  // extension/content/rca.js::extractFinancing parses these into
  // `data.loans[]` and the rca.js normalizer (Round 76er.b) types them into
  // ISO dates / dollar integers / numeric percents. The first two loops
  // above only consume `metadata.sales_history[].lender` + `loan_amount`,
  // dropping the rich detail (originator, special_servicer, ltv, term,
  // maturity_date, is_cmbs, origination_appraisal). This loop reads
  // `metadata.loans[]`, dedups against rows already written above (±5%
  // amount band), then PATCHes the existing row with the rich payload or
  // INSERTs a new row when no match is found.
  const financingLoans = Array.isArray(metadata.loans) ? metadata.loans : [];
  for (const fin of financingLoans) {
    const amount = Number(fin.loan_amount_dollars);
    if (!Number.isFinite(amount) || amount <= 0) continue;
    const lenderName = fin.lender_name || null;
    const originator = fin.originator || null;
    const origDate   = fin.origination_date_iso || null;
    const matDate    = fin.maturity_date_iso || null;
    const ltv        = Number.isFinite(fin.ltv_pct) ? fin.ltv_pct : null;
    const rate       = Number.isFinite(fin.interest_rate_pct) ? fin.interest_rate_pct : null;
    const termMo     = Number.isFinite(fin.term_months) ? fin.term_months : null;
    const termYr     = Number.isFinite(fin.term_years)  ? fin.term_years  : null;
    // Fresh audit A-4 (2026-05-18): inline normalizer for CoStar-style
    // loan status text. Mapped to the loans_status_check allowed enum.
    // Unknown / unparseable inputs return null (loans_status_check now
    // allows NULL after the paired migration).
    function mapLoanStatus(raw) {
      if (raw == null) return null;
      const s = String(raw).toLowerCase();
      if (!s.trim()) return null;
      if (/(outstanding|current|active|performing|open|in\s*good\s*standing)/.test(s)) return 'active';
      if (/(paid[\s_-]*off|paid[\s_-]*in[\s_-]*full|closed[\s_-]*paid|satisfied)/.test(s)) return 'paid_off';
      if (/matured|mature[d]?/.test(s)) return 'matured';
      if (/(default|delinquent|foreclos|reo|non[\s_-]*performing|distressed)/.test(s)) return 'defaulted';
      if (/(refinanced|refi'?d|paid[\s_-]*by[\s_-]*refi)/.test(s)) return 'refinanced';
      if (/(assumed|assumption)/.test(s)) return 'assumed';
      // Common CoStar headers we DO see: "Loan Status:OutstandingLoan Type:..."
      // — try once more on a substring after "Loan Status:" prefix.
      const m = s.match(/loan\s*status[:\s]+([a-z][a-z\s]+?)(?:loan|\d|$)/);
      if (m && m[1]) {
        const inner = m[1].trim();
        if (/outstanding|current|active|performing/.test(inner)) return 'active';
        if (/paid/.test(inner)) return 'paid_off';
        if (/matur/.test(inner)) return 'matured';
        if (/default|delinquent|foreclos/.test(inner)) return 'defaulted';
        if (/refi/.test(inner)) return 'refinanced';
        if (/assum/.test(inner)) return 'assumed';
      }
      return null;
    }
    const appraisal  = Number.isFinite(fin.origination_appraisal_dollars)
      ? fin.origination_appraisal_dollars : null;
    const reserves   = Number.isFinite(fin.total_reserves_dollars)
      ? fin.total_reserves_dollars : null;
    const debtYield  = Number.isFinite(fin.debt_yield_pct) ? fin.debt_yield_pct : null;
    const status     = mapLoanStatus(fin.loan_status);
    const isCmbs     = fin.is_cmbs === true || null;
    // mapLoanType('1st Mortgage') → null (no direct keyword match), but the
    // dia.loans CHECK constraint requires Refinance | Acquisition. Cross-
    // reference the matching sales_history event to infer: a loan whose
    // origination_date lands within ±60 days of a Sale/Construction event
    // is an Acquisition; one matching a Refinance event is a Refinance.
    let loanType = mapLoanType(fin.loan_type);
    if (!loanType && origDate && Array.isArray(metadata.sales_history)) {
      const origTs = new Date(origDate).getTime();
      for (const s of metadata.sales_history) {
        const sDate = parseDate(s.sale_date)?.split('T')[0];
        if (!sDate) continue;
        const days = Math.abs(new Date(sDate).getTime() - origTs) / 86400000;
        if (days > 60) continue;
        const kind = String(s.kind || s.event_type || '').toLowerCase();
        if (kind.includes('refinanc')) { loanType = 'Refinance'; break; }
        if (kind.includes('sale') || kind.includes('construction') || kind.includes('acquisition')) {
          loanType = 'Acquisition';
          break;
        }
      }
    }
    const specialSrv = fin.special_servicer || null;
    // Round 76cu: lender_name like 'BMARK 2021-B26' is a CMBS deal name.
    // The existing CMBS-deal-name regex on sales_history runs upstream; here
    // we trust the rca.js flag (is_cmbs from "Lender Group: CMBS"). When the
    // lender_name matches a CMBS deal naming pattern, also set cmbs_deal_name.
    const cmbsDealName = (isCmbs && lenderName) ? lenderName : null;

    // Dedup against existing rows on this property within ±5% of the amount.
    const amtLo = Math.floor(amount * 0.95);
    const amtHi = Math.ceil(amount * 1.05);
    const dupLookup = await domainQuery(domain, 'GET',
      `loans?property_id=eq.${propertyId}` +
      `&loan_amount=gte.${amtLo}&loan_amount=lte.${amtHi}` +
      `&select=loan_id,origination_date&limit=5`);
    let existingLoanId = null;
    if (dupLookup.ok && Array.isArray(dupLookup.data)) {
      for (const row of dupLookup.data) {
        if (!origDate || !row.origination_date) {
          existingLoanId = row.loan_id;
          break;
        }
        const days = Math.abs(
          new Date(String(row.origination_date).split('T')[0]).getTime() -
          new Date(origDate).getTime()
        ) / 86400000;
        if (days <= 31) { existingLoanId = row.loan_id; break; }
      }
    }

    // Domain-specific payload. dia.loans uses loan_to_value/loan_term/
    // interest_rate_percent; gov.loans uses ltv/term_years/interest_rate.
    // Both schemas share originator/special_servicer/sponsor/is_cmbs/
    // origination_appraisal/cmbs_deal_name (added in Round 76ek.a).
    // Stash debt_yield/total_reserves/status in the notes JSON since
    // neither column exists on either domain (Round 76er future-proofs
    // these as a structured note rather than dropping the data).
    const notesObj = stripNulls({
      debt_yield_pct:        debtYield,
      total_reserves_dollars: reserves,
      loan_status:           status,
      defeasance_date:       fin.defeasance_date_iso || null,
      prepayment_date:       fin.prepayment_date_iso || null,
    });
    const notesStr = Object.keys(notesObj).length
      ? JSON.stringify(notesObj)
      : null;

    // NOTE: is_cmbs is a generated column on both gov.loans and dia.loans
    // (`is_cmbs = (cmbs_deal_name IS NOT NULL)`) — do NOT include it in the
    // payload or PostgREST rejects with "cannot insert a non-DEFAULT value
    // into generated column". Setting cmbs_deal_name = lenderName above
    // already drives is_cmbs to true on the row.
    const loanData = domain === 'government' ? stripNulls({
      property_id:           propertyId,
      loan_type:             loanType,
      loan_amount:           amount,
      interest_rate:         rate,
      term_years:            termYr,
      origination_date:      origDate,
      maturity_date:         matDate,
      ltv:                   ltv,
      originator:            originator || lenderName,
      special_servicer:      specialSrv,
      origination_appraisal: appraisal,
      cmbs_deal_name:        cmbsDealName,
      status:                status,
      notes:                 notesStr,
      data_source:           'costar_sidebar',
    }) : stripNulls({
      property_id:           propertyId,
      lender_name:           lenderName || originator,
      loan_type:             loanType,
      loan_amount:           amount,
      interest_rate_percent: rate,
      loan_term:             termMo,
      origination_date:      origDate,
      maturity_date:         matDate,
      loan_to_value:         ltv,
      originator:            originator,
      special_servicer:      specialSrv,
      origination_appraisal: appraisal,
      cmbs_deal_name:        cmbsDealName,
      notes:                 notesStr,
      data_source:           'costar_sidebar',
    });

    if (existingLoanId != null) {
      const nowIso = new Date().toISOString();
      const filteredPatch = await filterByFieldPriority({
        targetDb:    domain === 'dialysis' ? 'dia_db' : 'gov_db',
        targetTable: domain === 'dialysis' ? 'dia.loans' : 'gov.loans',
        recordPk:    existingLoanId,
        source:      'costar_sidebar',
        confidence:  0.6,
        fields:      { ...loanData, updated_at: nowIso },
      }).catch(err => {
        console.warn('[upsertDomainLoans:financing] field-priority filter failed:', err?.message);
        return { ...loanData, updated_at: nowIso };
      });
      await domainPatch(domain,
        `loans?loan_id=eq.${existingLoanId}`,
        filteredPatch,
        'upsertDomainLoans:financing');
      pushProvenance(provCollect, 'loans', existingLoanId, loanData);
    } else {
      const result = await domainQuery(domain, 'POST', 'loans', loanData);
      if (result.ok) {
        count++;
        const inserted = Array.isArray(result.data) ? result.data[0] : result.data;
        if (inserted?.loan_id) {
          pushProvenance(provCollect, 'loans', inserted.loan_id, loanData);
        }
        console.log(`[upsertDomainLoans:financing] inserted loan for ` +
          `lender="${lenderName || originator}" amount=$${amount} ` +
          `property=${propertyId} cmbs=${isCmbs ? 'yes' : 'no'}`);
      } else {
        console.warn(`[upsertDomainLoans:financing] POST failed status=${result.status}: ${JSON.stringify(result.data)}`);
      }
    }
  }

  return count;
}

// ────────────────────────────────────────────────────────────────────────────
// Round 76ek.b: CMBS loan-record writer.
//
// metadata.loan_records[] arrives from extension/content/costar.js when the
// user is on a /detail/lookup/{N}/loan page. Each entry is shaped:
//
//   {
//     costar_loan_id, source_url, data_source: 'costar_cmbs_loan',
//     origination_date, maturity_date, originator,
//     loan_amount, origination_amount, pct_of_total_loan,
//     num_collateral, ltv, origination_appraisal, appraisal_date,
//     origination_term_months, origination_io_months, amortization_months,
//     interest_rate, rate_type, balloon_maturity, interest_only, pay_frequency,
//     loan_status, num_delinquent, modification, special_servicing, watchlist,
//     status_at_disposal, servicer, special_servicer, sponsor,
//     snapshot: {                       // optional
//       as_of_date, noi, noi_dscr, debt_service, gla, occupied_sf,
//       occupancy_pct, loan_balance,
//       top_tenants: [ { rank, tenant_name, expiration_date, occupied_sf } ]
//     }
//   }
//
// Routing rules (per Round 76ek.a scope):
//   - loans + loan_commentary write for both gov and dia.
//   - loan_snapshots + loan_top_tenants + property_financials write for gov
//     unconditionally; for dia they write only when
//     dia.properties.track_cmbs_snapshots = true.
// ────────────────────────────────────────────────────────────────────────────
// ────────────────────────────────────────────────────────────────────────────
// Round 76ek.i (2026-05-08): federal-government anti-pattern owner guard.
//
// CoStar's "Recorded Owner" / "Current Owner" panel sometimes pulls from
// county personal-property records (federal agencies leasing equipment in
// the building) rather than real-property records. When a federal-leased
// office shows up with "U S A" as the recorded owner but a private LLC in
// deed_records / sales_history, the USA candidate is the personal-property
// bleed-through and should not overwrite the real owner.
//
// Concrete report: 2075 North Blvd Idaho Falls — Martek Ice IDF LLC owns
// the dirt and leases space to ICE (federal). CoStar's Public Record tab
// surfaced "Current Owner: U S A / Government" because ICE has personal
// property recorded at the address. Without this guard the USA candidate
// would have been written to gov.properties.recorded_owner_name, masking
// the real LLC owner from every downstream cap-rate / ownership query.
//
// Detection: candidate name matches one of the bare federal labels.
// Decision: if there is at least one non-federal owner candidate
// (contacts[role=owner] OR sales_history[*].buyer), suppress the federal
// candidate. If federal is the ONLY candidate (e.g. an actual federal
// courthouse owned by GSA), let it through — the data really is what it is.
const FEDERAL_OWNER_ANTI_PATTERN_RE =
  /^(usa?|u\.?\s*s\.?\s*a?\.?|united\s+states(\s+of\s+america)?|u\.?\s*s\.?\s+government|federal\s+government|government)\s*$/i;

// C9 (2026-05-27): exported for the ingest-contract module.
export function isFederalOwnerAntiPattern(name) {
  if (!name || typeof name !== 'string') return false;
  return FEDERAL_OWNER_ANTI_PATTERN_RE.test(name.trim());
}

/**
 * Pick the most authoritative recorded-owner candidate from metadata.
 * Returns the contact object, or null if no candidate is usable.
 *
 * Order of preference:
 *   1. Owner-role contact whose name does NOT match the federal anti-pattern.
 *   2. The most recent sales_history buyer whose name does NOT match it.
 *   3. The first owner-role contact (even if federal anti-pattern) — used
 *      only when no private alternative exists (e.g. genuinely USPS-owned).
 */
// ORE Phase 1 Unit D: lift the owner contact's reachable details (phone / email
// / mailing address) off the captured contact object so the owner write path
// can persist them — previously selectAuthoritativeOwner's callers only read
// `.name`/`.address` and the phone/email we already had was dropped. Guards:
// a malformed phone (no real digits) and a generic/role inbox (info@/sales@ — a
// firm mailbox, not the owner decision-maker) are NOT carried. The owner NAME is
// already federal/junk-guarded upstream.
function ownerReachableDetails(contact) {
  if (!contact || typeof contact !== 'object') return { phone: null, email: null, address: null };
  const phones = Array.isArray(contact.phones) ? contact.phones : (contact.phone ? [contact.phone] : []);
  const phone = phones.map(p => (typeof p === 'string' ? p.trim() : '')).find(p => looksLikeContactPhone(p)) || null;
  const normEmail = normalizeEmail(contact.email);
  const email = (normEmail && !isGenericInboxEmail(normEmail)) ? normEmail : null;
  const address = (typeof contact.address === 'string' && contact.address.trim()) ? contact.address.trim() : null;
  return { phone, email, address };
}

// Decorate the chosen owner contact with normalized reachable details so every
// downstream consumer (recorded_owners write, owner-entity link) gets a uniform
// `{ phone, email, address }` regardless of the raw capture shape.
function withOwnerDetails(contact) {
  if (!contact) return contact;
  return { ...contact, ...ownerReachableDetails(contact) };
}

export function selectAuthoritativeOwner(metadata) {
  const contacts = Array.isArray(metadata?.contacts) ? metadata.contacts : [];
  const owners = contacts.filter(c => c && c.role === 'owner' && c.name);
  const privateOwner = owners.find(c => !isFederalOwnerAntiPattern(c.name));
  if (privateOwner) return withOwnerDetails(privateOwner);

  // No private owner contact — try sales_history buyers (most recent first).
  // A sale buyer carries no reachable contact details (name only).
  const sales = Array.isArray(metadata?.sales_history) ? metadata.sales_history : [];
  const sortedSales = sales
    .filter(s => s && s.buyer && !isFederalOwnerAntiPattern(s.buyer))
    .sort((a, b) => {
      const ad = a.sale_date ? new Date(a.sale_date).getTime() : 0;
      const bd = b.sale_date ? new Date(b.sale_date).getTime() : 0;
      return bd - ad;
    });
  if (sortedSales[0]) {
    return { role: 'owner', name: sortedSales[0].buyer, type: 'entity', _from_sales_history: true,
      phone: null, email: null, address: sortedSales[0].buyer_address || null };
  }

  // Fall through to the federal candidate only if it's all we have.
  if (owners[0]) {
    if (isFederalOwnerAntiPattern(owners[0].name)) {
      console.warn(
        `[selectAuthoritativeOwner] only candidate is federal anti-pattern (${owners[0].name}); ` +
        `accepting because no private alternative is present. ` +
        `Verify this property is actually federally-owned (USPS / GSA-titled).`
      );
    }
    return withOwnerDetails(owners[0]);
  }
  return null;
}

// ────────────────────────────────────────────────────────────────────────────
// Round 76ek.j Phase 1b (2026-05-08): LLC research queue enqueue.
//
// Called from upsertDomainOwners after a new recorded_owner row is created.
// Enqueues the owner for SOS-record enrichment when the name looks like a
// private business entity. Best-effort; failures never block the write.
//
// Filter rules:
//   - Skip federal-government anti-pattern names (USA, Government, etc.)
//   - Skip names that don't have a recognizable business-entity suffix
//     (LLC / LP / LLP / Inc / Corp / Co / Trust / Holdings / Partners /
//     Associates). Individuals and bare-noun names get manual research.
//   - Skip if a row already exists for this recorded_owner_id (UNIQUE
//     constraint on the queue table — INSERT will fail with 409, which we
//     swallow as a no-op).
//
// `guessedState` defaults to the owner's mailing-address state when known.
// The research handler in Phase 2 will fall back to the property's state if
// the owner address state isn't a recognized SOS-supported jurisdiction.
const PRIVATE_LLC_SUFFIX_RE =
  /\b(llc|l\.l\.c\.?|lp|l\.p\.?|llp|l\.l\.p\.?|inc|inc\.?|incorporated|corp|corp\.?|corporation|co\.|company|companies|trust|holdings?|partners|associates|properties|capital|ventures|management|group|enterprises?|investments?)\b\.?\s*$/i;

function looksLikePrivateLlc(name) {
  if (!name || typeof name !== 'string') return false;
  if (isFederalOwnerAntiPattern(name)) return false;
  return PRIVATE_LLC_SUFFIX_RE.test(name.trim());
}

async function enqueueLlcResearch(domain, recordedOwnerId, propertyId, name, guessedState) {
  if (!recordedOwnerId || !name) return;
  if (!looksLikePrivateLlc(name)) return;

  const payload = stripNulls({
    recorded_owner_id: recordedOwnerId,
    property_id:       propertyId || null,
    search_name:       name.trim(),
    guessed_state:     (guessedState || '').trim().toUpperCase().slice(0, 2) || null,
    status:            'queued',
  });

  const r = await domainQuery(domain, 'POST', 'llc_research_queue', payload);
  // 409 (UNIQUE on recorded_owner_id) is the no-op success case — the owner
  // is already queued or already researched. Any other non-2xx is logged.
  if (!r.ok && r.status !== 409) {
    console.warn(
      `[enqueueLlcResearch] insert failed status=${r.status} ` +
      `owner_id=${recordedOwnerId} name="${name}": `,
      r.data
    );
  }
}

async function upsertLoanRecords(domain, propertyId, metadata, provCollect) {
  const records = Array.isArray(metadata?.loan_records) ? metadata.loan_records : [];
  if (records.length === 0) return 0;

  // Resolve dia opt-in once per property (gov: always tracked).
  let tracksSnapshots = true;
  if (domain === 'dialysis') {
    try {
      const r = await domainQuery(domain, 'GET',
        `properties?property_id=eq.${propertyId}&select=track_cmbs_snapshots&limit=1`);
      tracksSnapshots = !!(r.ok && r.data?.[0]?.track_cmbs_snapshots);
    } catch (err) {
      console.warn('[upsertLoanRecords] dia track_cmbs_snapshots lookup failed:', err?.message);
      tracksSnapshots = false;
    }
  }

  const isGov = domain === 'government';

  // Round 76ek.h: link a non-CMBS loan's "Borrower" (the SPE LLC that signed
  // the note) to a recorded_owner row so loans.recorded_owner_id is populated.
  // We never auto-CREATE a recorded_owner here — that's reserved for the
  // dedicated upsertDomainOwners path which handles canonicalization and
  // dedup against the existing owner universe. Look up only.
  async function resolveBorrowerOwnerId(borrowerName) {
    if (!borrowerName || typeof borrowerName !== 'string') return null;
    const trimmed = borrowerName.trim();
    if (trimmed.length < 3) return null;
    const nameCol = isGov ? 'canonical_name' : 'normalized_name';
    // Match by case-insensitive ilike; the recorded_owners normalization
    // strategy lives in upsertDomainOwners, which runs in the same request
    // so the row should already exist by the time this lookup fires.
    const r = await domainQuery(domain, 'GET',
      `recorded_owners?${nameCol}=ilike.${encodeURIComponent(trimmed)}` +
      `&select=recorded_owner_id&limit=1`);
    if (r.ok && r.data?.[0]?.recorded_owner_id) return r.data[0].recorded_owner_id;
    return null;
  }

  let processed = 0;
  for (const lr of records) {
    if (!lr || typeof lr !== 'object') continue;

    // ── Step 0: resolve borrower → recorded_owner_id (best-effort).
    const borrowerOwnerId = await resolveBorrowerOwnerId(lr.borrower);

    // ── Step 1: find or create the loans row.
    let matchedLoanId = null;

    if (lr.costar_loan_id) {
      const r = await domainQuery(domain, 'GET',
        `loans?costar_loan_id=eq.${encodeURIComponent(lr.costar_loan_id)}` +
        `&select=loan_id&limit=1`);
      if (r.ok && r.data?.[0]) matchedLoanId = r.data[0].loan_id;
    }
    // Fallback: same property + same origination_date (CMBS loans on the
    // same collateral don't share an origination_date, so this is safe).
    if (!matchedLoanId && lr.origination_date) {
      const r = await domainQuery(domain, 'GET',
        `loans?property_id=eq.${propertyId}` +
        `&origination_date=eq.${lr.origination_date}` +
        `&select=loan_id&limit=1`);
      if (r.ok && r.data?.[0]) matchedLoanId = r.data[0].loan_id;
    }

    // Build the domain-specific loans payload.
    const loanAmount = lr.loan_amount != null ? lr.loan_amount
                     : (lr.origination_amount != null ? lr.origination_amount : null);

    const loanData = stripNulls(isGov ? {
      property_id:           propertyId,
      origination_date:      lr.origination_date || null,
      maturity_date:         lr.maturity_date || null,
      loan_amount:           loanAmount,
      interest_rate:         lr.interest_rate != null ? lr.interest_rate : null,
      term_years:            lr.origination_term_months != null
                               ? lr.origination_term_months / 12 : null,
      io_period_months:      lr.origination_io_months || null,
      ltv:                   lr.ltv != null ? lr.ltv : null,
      rate_type:             lr.rate_type || null,
      status:                lr.loan_status || null,
      prepayment_type:       lr.status_at_disposal || null,
      // CMBS-specific (added in Round 76ek.a)
      originator:            lr.originator || null,
      servicer:              lr.servicer || null,
      special_servicer:      lr.special_servicer || null,
      sponsor:               lr.sponsor || null,
      num_delinquent:        lr.num_delinquent != null ? lr.num_delinquent : null,
      modification:          lr.modification != null ? lr.modification : null,
      watchlist:             lr.watchlist || null,
      special_servicing:     lr.special_servicing || null,
      status_at_disposal:    lr.status_at_disposal || null,
      balloon_maturity:      lr.balloon_maturity != null ? lr.balloon_maturity : null,
      pay_frequency:         lr.pay_frequency || null,
      num_collateral:        lr.num_collateral != null ? lr.num_collateral : null,
      pct_of_total_loan:     lr.pct_of_total_loan != null ? lr.pct_of_total_loan : null,
      origination_appraisal: lr.origination_appraisal != null ? lr.origination_appraisal : null,
      appraisal_date:        lr.appraisal_date || null,
      recorded_owner_id:     borrowerOwnerId,
      costar_loan_id:        lr.costar_loan_id || null,
      source_url:            lr.source_url || null,
      data_source:           'costar_cmbs_loan',
    } : {
      property_id:           propertyId,
      lender_name:           lr.originator || null,
      origination_date:      lr.origination_date || null,
      maturity_date:         lr.maturity_date || null,
      loan_amount:           loanAmount,
      interest_rate_percent: lr.interest_rate != null ? lr.interest_rate * 100 : null,
      loan_term:             lr.origination_term_months || null,
      loan_to_value:         lr.ltv != null ? lr.ltv : null,
      // CMBS-specific (added in Round 76ek.a)
      originator:            lr.originator || null,
      servicer:              lr.servicer || null,
      special_servicer:      lr.special_servicer || null,
      sponsor:               lr.sponsor || null,
      num_delinquent:        lr.num_delinquent != null ? lr.num_delinquent : null,
      modification:          lr.modification != null ? lr.modification : null,
      watchlist:             lr.watchlist || null,
      special_servicing:     lr.special_servicing || null,
      status_at_disposal:    lr.status_at_disposal || null,
      balloon_maturity:      lr.balloon_maturity != null ? lr.balloon_maturity : null,
      pay_frequency:         lr.pay_frequency || null,
      num_collateral:        lr.num_collateral != null ? lr.num_collateral : null,
      pct_of_total_loan:     lr.pct_of_total_loan != null ? lr.pct_of_total_loan : null,
      origination_appraisal: lr.origination_appraisal != null ? lr.origination_appraisal : null,
      appraisal_date:        lr.appraisal_date || null,
      recorded_owner_id:     borrowerOwnerId,
      costar_loan_id:        lr.costar_loan_id || null,
      source_url:            lr.source_url || null,
      data_source:           'costar_cmbs_loan',
    });

    let loanId = matchedLoanId;
    if (matchedLoanId != null) {
      // Field-priority filter: costar_cmbs_loan @ priority 20 outranks
      // costar_sidebar @ 60-65 and om_extraction @ 30-40 for the shared
      // loan columns. The filter consults field_source_priority and drops
      // any field whose registered priority is lower (= more authoritative).
      let filtered = loanData;
      try {
        filtered = await filterByFieldPriority({
          targetDb:    isGov ? 'gov_db' : 'dia_db',
          targetTable: isGov ? 'gov.loans' : 'dia.loans',
          source:      'costar_cmbs_loan',
          confidence:  0.85,
          recordPk:    matchedLoanId,
          fields:      loanData,
        }) || loanData;
      } catch (err) {
        console.warn('[upsertLoanRecords] field-priority filter failed:', err?.message);
      }
      const patch = { ...filtered, updated_at: new Date().toISOString() };
      const r = await domainQuery(domain, 'PATCH',
        `loans?loan_id=eq.${matchedLoanId}`, patch);
      if (r.ok) {
        pushProvenance(provCollect, 'loans', matchedLoanId, patch, 0.85, 'costar_cmbs_loan');
      }
    } else {
      const r = await domainQuery(domain, 'POST', 'loans', loanData);
      if (r.ok) {
        const inserted = Array.isArray(r.data) ? r.data[0] : r.data;
        loanId = inserted?.loan_id || null;
        if (loanId != null) {
          pushProvenance(provCollect, 'loans', loanId, loanData, 0.85, 'costar_cmbs_loan');
        }
      }
    }

    if (loanId == null) {
      console.warn('[upsertLoanRecords] failed to write loan', {
        property_id: propertyId, costar_loan_id: lr.costar_loan_id,
      });
      continue;
    }
    processed++;

    // ── Step 2: snapshot + top tenants (gov always; dia opt-in).
    if (lr.snapshot && tracksSnapshots) {
      const snap = lr.snapshot;
      if (snap.as_of_date) {
        const snapData = stripNulls({
          loan_id:      loanId,
          as_of_date:   snap.as_of_date,
          noi:          snap.noi != null ? snap.noi : null,
          noi_dscr:     snap.noi_dscr != null ? snap.noi_dscr : null,
          debt_service: snap.debt_service != null ? snap.debt_service : null,
          gla:          snap.gla != null ? snap.gla : null,
          occupied_sf:  snap.occupied_sf != null ? snap.occupied_sf : null,
          occupancy_pct: snap.occupancy_pct != null ? snap.occupancy_pct : null,
          loan_balance: snap.loan_balance != null ? snap.loan_balance : null,
          data_source:  'costar_cmbs_loan',
          source_url:   lr.source_url || null,
        });

        // Find existing snapshot by (loan_id, as_of_date) — the table's
        // unique constraint guarantees at most one row.
        const lookup = await domainQuery(domain, 'GET',
          `loan_snapshots?loan_id=eq.${loanId}` +
          `&as_of_date=eq.${snap.as_of_date}` +
          `&select=snapshot_id&limit=1`);

        let snapshotId = null;
        if (lookup.ok && lookup.data?.[0]) {
          snapshotId = lookup.data[0].snapshot_id;
          const patch = { ...snapData, updated_at: new Date().toISOString() };
          await domainQuery(domain, 'PATCH',
            `loan_snapshots?snapshot_id=eq.${snapshotId}`, patch);
        } else {
          const r = await domainQuery(domain, 'POST', 'loan_snapshots',
            snapData);
          if (r.ok) {
            const ins = Array.isArray(r.data) ? r.data[0] : r.data;
            snapshotId = ins?.snapshot_id || null;
          }
        }

        if (snapshotId != null) {
          pushProvenance(provCollect, 'loan_snapshots', snapshotId, snapData, 0.85, 'costar_cmbs_loan');

          // Replace top-tenants for this snapshot. The CMBS report is the
          // authoritative rent-roll snapshot for this as_of_date, so we
          // delete-then-insert rather than merge — the snapshot is the
          // unit of truth, not individual rows.
          const tenants = Array.isArray(snap.top_tenants) ? snap.top_tenants : [];
          if (tenants.length > 0) {
            await domainQuery(domain, 'DELETE',
              `loan_top_tenants?snapshot_id=eq.${snapshotId}`,
              null);
            const tenantRows = tenants
              .filter(t => t && t.tenant_name)
              .map(t => stripNulls({
                snapshot_id:     snapshotId,
                rank:            t.rank != null ? t.rank : null,
                tenant_name:     t.tenant_name,
                expiration_date: t.expiration_date || null,
                occupied_sf:     t.occupied_sf != null ? t.occupied_sf : null,
                data_source:     'costar_cmbs_loan',
              }));
            if (tenantRows.length > 0) {
              const r = await domainQuery(domain, 'POST', 'loan_top_tenants',
                tenantRows);
              if (r.ok) {
                const insertedRows = Array.isArray(r.data) ? r.data : [];
                for (const ins of insertedRows) {
                  if (ins?.id != null) {
                    pushProvenance(provCollect, 'loan_top_tenants', ins.id, ins, 0.85, 'costar_cmbs_loan');
                  }
                }
              }
            }
          }
        }
      }
    } else if (lr.snapshot && !tracksSnapshots) {
      console.log(`[upsertLoanRecords] dia property=${propertyId} ` +
        `track_cmbs_snapshots=false — skipping snapshot/top_tenants fan-out`);
    }

    // Round 76ek.c: write commentary entries. UNIQUE partial index on
    // (loan_id, entry_label) WHERE entry_label IS NOT NULL handles dedup
    // across re-captures. Unlike snapshots/top-tenants, commentary writes
    // for both gov AND dia regardless of track_cmbs_snapshots — these are
    // narrative loan events (delinquency, payoff, modification) that are
    // useful BD context everywhere.
    const commentary = Array.isArray(lr.commentary) ? lr.commentary : [];
    for (const entry of commentary) {
      if (!entry || !entry.body || !entry.entry_label) continue;
      const commentaryRow = stripNulls({
        loan_id:     loanId,
        rank:        entry.rank != null ? entry.rank : null,
        entry_date:  entry.entry_date || null,
        entry_label: entry.entry_label,
        body:        entry.body,
        data_source: 'costar_cmbs_loan',
        source_url:  lr.source_url || null,
      });

      // Try INSERT first; on conflict (duplicate label), PATCH instead so
      // a re-capture refreshes the body (CoStar occasionally edits the
      // narrative after the initial post). PostgREST surfaces the unique
      // violation as 409.
      const ins = await domainQuery(domain, 'POST', 'loan_commentary', commentaryRow);
      if (ins.ok) {
        const insertedRow = Array.isArray(ins.data) ? ins.data[0] : ins.data;
        if (insertedRow?.id) {
          pushProvenance(provCollect, 'loan_commentary', insertedRow.id, commentaryRow, 0.85, 'costar_cmbs_loan');
        }
      } else if (ins.status === 409) {
        // Existing row with this (loan_id, entry_label) — PATCH it.
        // Safe because the body is the only field that meaningfully changes;
        // entry_label / entry_date are stable identifiers.
        const lookup = await domainQuery(domain, 'GET',
          `loan_commentary?loan_id=eq.${loanId}` +
          `&entry_label=eq.${encodeURIComponent(entry.entry_label)}` +
          `&select=id&limit=1`);
        const existingId = lookup.ok && lookup.data?.[0]?.id;
        if (existingId) {
          await domainQuery(domain, 'PATCH',
            `loan_commentary?id=eq.${existingId}`,
            { body: entry.body, rank: entry.rank ?? null });
          pushProvenance(provCollect, 'loan_commentary', existingId, commentaryRow, 0.85, 'costar_cmbs_loan');
        }
      } else {
        console.warn('[upsertLoanRecords] loan_commentary insert failed:',
          { loan_id: loanId, entry_label: entry.entry_label, status: ins.status });
      }
    }
  }

  return processed;
}

// ────────────────────────────────────────────────────────────────────────────
// Round 76ek.e: CMBS multi-year financials writer.
//
// metadata.property_financials[] arrives from extension/content/costar.js when
// the user is on a /detail/lookup/{N}/cmbs-financials page in Property+Totals
// mode. The parser already drops Market mode, Per-SF mode, and the
// Underwritten column at the source, so anything reaching this writer is
// actual operating financials.
//
// Each row is shaped:
//   {
//     source: 'costar_cmbs_loan',
//     fiscal_year, period_end_date, months_covered, is_actual: true,
//     gross_income, vacancy, effective_gross_income,
//     operating_expenses, taxes, insurance, cam, noi, capex,
//     line_items: { base_rent: ..., utilities: ..., ... } | null,
//     source_url, data_source: 'costar_cmbs_loan',
//   }
//
// Routing: writes for both gov and dia, but dia is gated on
// dia.properties.track_cmbs_snapshots (same flag as loan snapshots).
// Property is the natural identity; we upsert by
// (property_id, fiscal_year, source).
// ────────────────────────────────────────────────────────────────────────────
async function upsertPropertyFinancials(domain, propertyId, metadata, provCollect) {
  const rows = Array.isArray(metadata?.property_financials) ? metadata.property_financials : [];
  if (rows.length === 0) return 0;

  // Round 76ek.k: gov.property_financials uses `financial_id` as its PK
  // (legacy 98k-row schema), dia uses `id`. The dia-aligned columns
  // (gross_income, vacancy, is_actual, etc.) were ADD COLUMN'd onto gov
  // in 20260508130000 so the unified payload writes cleanly on both. The
  // PK column name is the only remaining domain-specific bit.
  const pkCol = domain === 'government' ? 'financial_id' : 'id';

  // Dia opt-in: same gate as snapshots/top-tenants.
  if (domain === 'dialysis') {
    try {
      const r = await domainQuery(domain, 'GET',
        `properties?property_id=eq.${propertyId}&select=track_cmbs_snapshots&limit=1`);
      const tracks = !!(r.ok && r.data?.[0]?.track_cmbs_snapshots);
      if (!tracks) {
        console.log(`[upsertPropertyFinancials] dia property=${propertyId} ` +
          `track_cmbs_snapshots=false — skipping ${rows.length} financial rows`);
        return 0;
      }
    } catch (err) {
      console.warn('[upsertPropertyFinancials] dia track_cmbs_snapshots lookup failed:', err?.message);
      return 0;
    }
  }

  let processed = 0;
  for (const r of rows) {
    if (!r || !r.fiscal_year || r.is_actual !== true) continue;

    const payload = stripNulls({
      property_id:            propertyId,
      fiscal_year:            r.fiscal_year,
      period_end_date:        r.period_end_date || null,
      source:                 r.source || 'costar_cmbs_loan',
      months_covered:         r.months_covered != null ? r.months_covered : null,
      is_actual:              true,
      gross_income:           r.gross_income != null ? r.gross_income : null,
      vacancy:                r.vacancy != null ? r.vacancy : null,
      effective_gross_income: r.effective_gross_income != null ? r.effective_gross_income : null,
      operating_expenses:     r.operating_expenses != null ? r.operating_expenses : null,
      taxes:                  r.taxes != null ? r.taxes : null,
      insurance:              r.insurance != null ? r.insurance : null,
      cam:                    r.cam != null ? r.cam : null,
      noi:                    r.noi != null ? r.noi : null,
      capex:                  r.capex != null ? r.capex : null,
      line_items:             r.line_items || null,
      source_url:             r.source_url || null,
    });

    // Find existing row by (property_id, fiscal_year, source) — the table's
    // unique constraint guarantees at most one match.
    const lookup = await domainQuery(domain, 'GET',
      `property_financials?property_id=eq.${propertyId}` +
      `&fiscal_year=eq.${r.fiscal_year}` +
      `&source=eq.${encodeURIComponent(r.source || 'costar_cmbs_loan')}` +
      `&select=${pkCol}&limit=1`);

    if (lookup.ok && lookup.data?.[0]?.[pkCol]) {
      const id = lookup.data[0][pkCol];
      const patch = { ...payload, updated_at: new Date().toISOString() };
      delete patch.is_actual; // immutable post-insert; safe to omit on PATCH
      const r2 = await domainQuery(domain, 'PATCH',
        `property_financials?${pkCol}=eq.${id}`, patch);
      if (r2.ok) {
        pushProvenance(provCollect, 'property_financials', id, patch, 0.85, 'costar_cmbs_loan');
        processed++;
      }
    } else {
      const r2 = await domainQuery(domain, 'POST', 'property_financials', payload);
      if (r2.ok) {
        const ins = Array.isArray(r2.data) ? r2.data[0] : r2.data;
        const insertedId = ins?.[pkCol];
        if (insertedId) {
          pushProvenance(provCollect, 'property_financials', insertedId, payload, 0.85, 'costar_cmbs_loan');
          processed++;
        }
      } else {
        console.warn('[upsertPropertyFinancials] insert failed', {
          property_id: propertyId, fiscal_year: r.fiscal_year,
          status: r2.status, data: r2.data,
        });
      }
    }
  }

  return processed;
}

/**
 * Upsert recorded owners and build ownership history chain.
 * Sources: contacts[] with role=owner, plus buyers/sellers from sales_history[].
 */
async function upsertDomainOwners(domain, propertyId, entity, metadata, provCollect) {
  const results = { owners: 0, history: 0 };
  const ownerIds = new Map(); // name → recorded_owner_id
  const nameCol = domain === 'government' ? 'canonical_name' : 'normalized_name';

  // Normalize an owner name for dedup matching
  function normalizeOwnerName(n) {
    return n.trim().toLowerCase()
      .replace(/\b(llc|inc|corp|ltd|co|company|group|partners|lp|llp)\b\.?/gi, '')
      .replace(/[^a-z0-9\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // Bulk-prefetch existing recorded_owners to avoid per-owner round-trips
  const allOwnerNames = new Set();
  for (const c of (metadata.contacts || []).filter(c => c.role === 'owner')) {
    if (c.name) allOwnerNames.add(normalizeOwnerName(c.name));
  }
  for (const s of (metadata.sales_history || [])) {
    if (s.buyer) allOwnerNames.add(normalizeOwnerName(s.buyer));
    if (s.seller) allOwnerNames.add(normalizeOwnerName(s.seller));
  }
  // Track existing owner rows so we can back-fill missing fields on cache hit
  const existingOwnerData = new Map();
  if (allOwnerNames.size > 0) {
    const nameList = [...allOwnerNames].map(n => encodeURIComponent(n)).join(',');
    const selectCols = domain === 'government'
      ? `recorded_owner_id,${nameCol}`
      : `recorded_owner_id,${nameCol},address`;
    const prefetch = await domainQuery(domain, 'GET',
      `recorded_owners?${nameCol}=in.(${nameList})&select=${selectCols}&limit=50`
    );
    if (prefetch.ok && Array.isArray(prefetch.data)) {
      for (const row of prefetch.data) {
        ownerIds.set(row[nameCol], row.recorded_owner_id);
        existingOwnerData.set(row[nameCol], row);
      }
    }
  }

  // Helper to find-or-create a recorded owner by name.
  // ORE Phase 1 Unit D: `contact` (optional `{ phone, email }`) carries the
  // owner's reachable details. On gov they land in the `contact_info` jsonb
  // (dia has no phone/email column — those owners are reachable via the LCC
  // entity, which Unit B now lets carry phone/email; a dia recorded_owners
  // phone/email migration is a documented follow-up).
  async function ensureRecordedOwner(name, address, contact = null) {
    // R5-DQ-2 (2026-05-20): strip " by <Brokerage>" suffix BEFORE the
    // existing normalizer so the same entity captured by two different
    // brokers (or the same broker with/without the suffix) resolves to
    // one recorded_owners row. Same logic mirrored in
    // dia.dia_strip_broker_suffix() (migration 20260520230000).
    name = sanitizeOwnerName(name);
    if (!name) return null;
    const normalizedName = normalizeOwnerName(name);

    if (ownerIds.has(normalizedName)) {
      const id = ownerIds.get(normalizedName);

      // Patch address if existing record is missing it and we have data.
      // Gov uses a contact_info JSONB column instead of flat address — skip
      // that domain here to avoid PATCHing a non-existent column.
      if (domain !== 'government' && address) {
        const existing = existingOwnerData.get(normalizedName);
        if (existing && !existing.address) {
          const addrFields = {};
          const parts = address.split(',').map(s => s.trim());
          addrFields.address = parts[0] || null;
          if (parts.length >= 2) addrFields.city = parts[1] || null;
          if (parts.length >= 3) {
            const stateZip = parts[2].split(/\s+/);
            if (stateZip[0]) addrFields.state = stateZip[0];
          }
          if (Object.keys(addrFields).length) {
            // Round 76co (Phase 5): priority gate on recorded_owners updates.
            // Deed records and county-recorder data outrank costar_sidebar
            // for owner-address fields, since CoStar often shows the listing
            // contact's mailing address rather than the legal owner's.
            const filteredOwnerPatch = await filterByFieldPriority({
              targetDb:    domain === 'dialysis' ? 'dia_db' : 'gov_db',
              targetTable: domain === 'dialysis' ? 'dia.recorded_owners' : 'gov.recorded_owners',
              recordPk:    id,
              source:      'costar_sidebar',
              confidence:  0.6,
              fields:      addrFields,
            }).catch(err => {
              console.warn('[upsertDomainOwners:ensureRecordedOwner] field-priority filter failed (proceeding with full patch):', err?.message);
              return addrFields;
            });
            if (filteredOwnerPatch && Object.keys(filteredOwnerPatch).length > 0) {
              await domainPatch(domain,
                `recorded_owners?recorded_owner_id=eq.${id}`,
                filteredOwnerPatch,
                'upsertDomainOwners:ensureRecordedOwner'
              );
            }
          }
        }
      }

      return id;
    }

    // Parse address if provided — domain-aware storage
    // Dialysis: flat address/city/state columns
    // Gov: contact_info JSONB with { address, city, state, phone, email }
    let addrLine = null, cityVal = null, stateVal = null;
    if (address) {
      const parts = address.split(',').map(s => s.trim());
      addrLine = parts[0] || null;
      cityVal = parts.length >= 2 ? (parts[1] || null) : null;
      if (parts.length >= 3) {
        const stateZip = parts[2].split(/\s+/);
        if (stateZip[0]) stateVal = stateZip[0];
      }
    }
    // ORE Phase 1 Unit D: guard the reachable details (drop a malformed phone /
    // a generic-role inbox) before they reach the owner record.
    const ownerPhone = (contact && looksLikeContactPhone(contact.phone)) ? contact.phone.trim() : null;
    const normOwnerEmail = contact ? normalizeEmail(contact.email) : '';
    const ownerEmail = (normOwnerEmail && !isGenericInboxEmail(normOwnerEmail)) ? normOwnerEmail : null;

    const addrFields = {};
    if (domain === 'government') {
      // contact_info is jsonb — build it whenever ANY reachable detail exists,
      // even with no address (a phone-only owner still gets contact_info).
      const ci = stripNulls({ address: addrLine, city: cityVal, state: stateVal,
        phone: ownerPhone, email: ownerEmail });
      if (Object.keys(ci).length) addrFields.contact_info = ci;
    } else {
      // dia: flat address/city/state (no phone/email column — see Unit D note).
      if (addrLine) addrFields.address = addrLine;
      if (cityVal) addrFields.city = cityVal;
      if (stateVal) addrFields.state = stateVal;
    }

    const ownerData = stripNulls({
      name: name.trim(),
      [nameCol]: normalizedName,
      ...addrFields,
    });

    const result = await domainQuery(domain, 'POST', 'recorded_owners', ownerData);
    if (result.ok && result.data) {
      const created = Array.isArray(result.data) ? result.data[0] : result.data;
      const id = created?.recorded_owner_id || null;
      if (id) {
        ownerIds.set(normalizedName, id);
        results.owners++;
        // Phase 2.2.c: provenance for new recorded_owner row
        pushProvenance(provCollect, 'recorded_owners', id, {
          name: name.trim(),
          [nameCol]: normalizedName,
          ...(addrFields.address ? { address: addrFields.address } : {}),
          ...(addrFields.city ? { city: addrFields.city } : {}),
          ...(addrFields.state ? { state: addrFields.state } : {}),
        });
        // Round 76ek.j Phase 1b: enqueue this newly-created owner for LLC
        // research enrichment when it looks like a private business entity.
        // Best-effort and isolated — failures here never block the write.
        try {
          await enqueueLlcResearch(domain, id, propertyId, name.trim(), addrFields.state || null);
        } catch (err) {
          console.warn('[upsertDomainOwners] enqueueLlcResearch failed (non-fatal):',
            err?.message || err);
        }
      }
      return id;
    }
    // C4 (2026-05-24): write-time UNIQUE on the dedup key. A 23505 here means
    // another writer (race) inserted the same canonical owner between our
    // pre-fetch and this POST. Re-query by the dedup column, cache, and reuse
    // the existing UUID — same semantics as the pre-fetch cache hit.
    if (result.status === 409 && result.data?.code === '23505') {
      const stateForLookup = addrFields.state || (addrFields.contact_info && addrFields.contact_info.state) || null;
      const lookupParams = domain === 'government'
        ? `canonical_name=eq.${encodeURIComponent(normalizedName)}` +
          (stateForLookup ? `&state=eq.${encodeURIComponent(stateForLookup)}` : '&state=is.null')
        : `normalized_name=eq.${encodeURIComponent(normalizedName)}`;
      const refetch = await domainQuery(domain, 'GET',
        `recorded_owners?${lookupParams}&merged_into_recorded_owner_id=is.null&select=recorded_owner_id&limit=1`);
      if (refetch.ok && refetch.data?.length) {
        const existingId = refetch.data[0].recorded_owner_id;
        ownerIds.set(normalizedName, existingId);
        return existingId;
      }
      console.warn(`[upsertDomainOwners] 23505 on recorded_owners but refetch found nothing for "${name}" (${domain})`);
    }
    return null;
  }

  // Process contacts with role=owner.
  // Round 76ek.i: skip federal-government anti-pattern names (USA, U S A,
  // Government, etc.) when there's a private alternative — those almost
  // always come from CoStar's personal-property record bleed-through.
  const allOwnerContacts = (metadata.contacts || []).filter(c => c.role === 'owner');
  const hasPrivateOwner = allOwnerContacts.some(c => c.name && !isFederalOwnerAntiPattern(c.name));
  const ownerContacts = hasPrivateOwner
    ? allOwnerContacts.filter(c => c.name && !isFederalOwnerAntiPattern(c.name))
    : allOwnerContacts;
  if (hasPrivateOwner && ownerContacts.length < allOwnerContacts.length) {
    const dropped = allOwnerContacts.filter(c => c.name && isFederalOwnerAntiPattern(c.name)).map(c => c.name);
    console.warn(`[upsertDomainOwners] property=${propertyId} dropped federal anti-pattern owners (private alternative present): ${dropped.join(', ')}`);
  }
  for (const contact of ownerContacts) {
    // ORE Phase 1 Unit D: carry the owner's reachable phone/email onto the
    // recorded_owner (gov contact_info) — fill-blanks, guarded inside the helper.
    await ensureRecordedOwner(contact.name, contact.address, ownerReachableDetails(contact));
  }

  // Process buyers and sellers from sales history to build ownership chain
  const sales = metadata.sales_history || [];

  // Build ownership chain — only use sales with actual buyers as
  // transition points. Stat card entries (is_current: true, no buyer)
  // are noise and must not create false ownership end dates.
  const validTransitions = [...sales]
    .filter(s => s.sale_date && s.buyer)  // must have a buyer to count as a transfer
    .sort((a, b) => new Date(a.sale_date) - new Date(b.sale_date));

  // Pre-fetch sales_transactions for this property so we can link ownership_history → sale_id
  const existingSales = await domainQuery(domain, 'GET',
    `sales_transactions?property_id=eq.${propertyId}&select=sale_id,sale_date,sold_price&limit=50`
  );
  const salesTxns = existingSales.ok ? (existingSales.data || []) : [];

  // Helper: find matching sale_id by date (within 7 days) + price (within 5%)
  function findMatchingSaleId(dateStr, priceVal) {
    if (!dateStr) return null;
    const targetDate = new Date(dateStr);
    for (const st of salesTxns) {
      if (!st.sale_date) continue;
      const stDate = new Date(st.sale_date);
      const daysDiff = Math.abs((targetDate - stDate) / 86400000);
      if (daysDiff > 7) continue;
      // If prices available, verify within 5%; if one is missing, date match is enough
      if (priceVal && st.sold_price) {
        const priceDiff = Math.abs(Number(st.sold_price) - priceVal) / Math.max(Number(st.sold_price), priceVal);
        if (priceDiff > 0.05) continue;
      }
      return st.sale_id;
    }
    return null;
  }

  for (let i = 0; i < validTransitions.length; i++) {
    const sale = validTransitions[i];
    const saleDate = parseDate(sale.sale_date);
    if (!saleDate) continue;

    // Skip refinance/encumbrance deeds — buyer here is a lender or the
    // existing owner refinancing, not a new owner. Counting these would
    // create duplicate ownership_history rows.
    if (sale.deed_type && MORTGAGE_DEED_TYPES.test(sale.deed_type)) continue;

    // Skip lender names as buyers — banks appearing as buyers are typically
    // foreclosures, securitization, or refinancing events, not real transfers.
    if (LENDER_PATTERN.test(sale.buyer)) {
      console.log(`[upsertDomainOwners] skipping lender buyer: "${sale.buyer}" ` +
        `for property=${propertyId} date=${sale.sale_date}`);
      continue;
    }

    const saleDateStr = saleDate.split('T')[0];

    // Ensure buyer owner record
    const buyerId = sale.buyer ? await ensureRecordedOwner(sale.buyer, sale.buyer_address) : null;

    // Ensure seller owner record
    const sellerId = sale.seller ? await ensureRecordedOwner(sale.seller, sale.seller_address) : null;

    // Link sale_transaction to the buyer's recorded_owner_id (+ seller_id for dia).
    // DEVELOPER_BD_AUDIT_v3 §11 Topic 1.5: when seller is captured, also link
    // sales_transactions.seller_id so the v_dia_owner_role_classification view
    // can see who sold the asset (the developer-exit signal). Gov uses
    // seller_contact_id linking to contacts via a separate ingest path, so
    // we skip the seller link for gov here.
    const matchedSaleId = findMatchingSaleId(saleDateStr, parseCurrency(sale.sale_price));
    if (matchedSaleId && buyerId) {
      const buyerPatch = stripNulls({
        recorded_owner_id: buyerId,
        recorded_owner_name: sale.buyer,
      });
      if (domain === 'dialysis' && sellerId) {
        buyerPatch.seller_id = sellerId;
        if (sale.seller) buyerPatch.seller_name = sale.seller;
      }
      await domainPatch(domain,
        `sales_transactions?sale_id=eq.${matchedSaleId}`,
        buyerPatch,
        'upsertDomainOwners:linkSaleToOwner'
      );
    }

    // Build ownership_history entry for the buyer (they own from this sale forward)
    if (buyerId) {
      // Next transition is the NEXT SALE WITH A BUYER, not any stat card entry.
      // nextSaleDate = null means this buyer is still the current owner.
      // (Only used by the dialysis branch — gov has no ownership_end column.)
      const nextTransition = i < validTransitions.length - 1 ? validTransitions[i + 1] : null;
      const nextSaleDate = nextTransition ? parseDate(nextTransition.sale_date) : null;

      // Dedup check — domain-aware date column.
      // Gov ownership_history uses transfer_date; dialysis uses ownership_start.
      const dateColFilter = domain === 'government'
        ? `transfer_date=eq.${saleDateStr}`
        : `ownership_start=eq.${saleDateStr}`;
      const ohLookup = await domainQuery(domain, 'GET',
        `ownership_history?property_id=eq.${propertyId}` +
        `&recorded_owner_id=eq.${buyerId}&${dateColFilter}` +
        `&select=ownership_id&limit=1`
      );

      // Build data — domain-aware column names.
      // Gov: transfer_date / transfer_price, no ownership_end.
      // Dialysis: ownership_start / ownership_end / sold_price.
      const ohData = domain === 'government'
        ? stripNulls({
            property_id:       propertyId,
            recorded_owner_id: buyerId,
            new_owner:         sale.buyer || null,
            prior_owner:       sale.seller || null,
            transfer_date:     saleDateStr,
            transfer_price:    parseCurrency(sale.sale_price),
            data_source:       'costar_sidebar',
          })
        : stripNulls({
            property_id:       propertyId,
            recorded_owner_id: buyerId,
            ownership_start:   saleDateStr,
            ownership_end:     nextSaleDate ? nextSaleDate.split('T')[0] : null,
            sold_price:        parseCurrency(sale.sale_price),
            sale_id:           matchedSaleId || null,
          });

      if (!ohLookup.ok || !ohLookup.data?.length) {
        const result = await domainQuery(domain, 'POST', 'ownership_history', ohData);
        if (result.ok) {
          results.history++;
          const ohRow = Array.isArray(result.data) ? result.data[0] : result.data;
          if (ohRow?.ownership_id) {
            pushProvenance(provCollect, 'ownership_history', ohRow.ownership_id, ohData);
          }
        }
      } else if (matchedSaleId) {
        // Existing row — ensure sale_id is linked
        const existingOhId = ohLookup.data[0].ownership_id;
        await domainPatch(domain,
          `ownership_history?ownership_id=eq.${existingOhId}`,
          { sale_id: matchedSaleId },
          'upsertDomainOwners:linkOwnershipToSale'
        );
      }
    }

    // DEVELOPER_BD_AUDIT_v3 §11 Topic 1.5: write seller-exit OH row for dia.
    // The legacy sidebar code never closed the seller's tenure when a new
    // sale was captured, leaving 99.6% of pre-stabilization developers
    // invisible to ownership_history chain queries. This addition closes
    // the gap on new captures. Gov OH already captures the seller via
    // the prior_owner text field on the (single-event) transfer row above,
    // so no separate seller OH row is needed for gov.
    if (domain === 'dialysis' && sellerId) {
      // Dedup: skip if a seller-exit OH row already exists for this
      // (property, recorded_owner) closed near saleDateStr.
      const sellerOhLookup = await domainQuery(domain, 'GET',
        `ownership_history?property_id=eq.${propertyId}` +
        `&recorded_owner_id=eq.${sellerId}` +
        `&ownership_end=eq.${saleDateStr}` +
        `&select=ownership_id&limit=1`
      );

      if (!sellerOhLookup.ok || !sellerOhLookup.data?.length) {
        // start_date NULL to dodge the unique (property_id, start_date) index;
        // end_date carries the developer-exit signal.
        const sellerOhData = stripNulls({
          property_id:       propertyId,
          recorded_owner_id: sellerId,
          ownership_start:   null,
          ownership_end:     saleDateStr,
          start_date:        null,
          end_date:          saleDateStr,
          sold_price:        parseCurrency(sale.sale_price),
          sale_id:           null, // exit row, not acquisition
          ownership_source:  'sales_transactions_seller_exit',
          notes:             `Sidebar: seller exit from sale ${matchedSaleId || 'unmatched'} on ${saleDateStr}`,
        });
        const sellerResult = await domainQuery(domain, 'POST', 'ownership_history', sellerOhData);
        if (sellerResult.ok) {
          results.history++;
          const sellerOhRow = Array.isArray(sellerResult.data) ? sellerResult.data[0] : sellerResult.data;
          if (sellerOhRow?.ownership_id) {
            pushProvenance(provCollect, 'ownership_history', sellerOhRow.ownership_id, sellerOhData);
          }
        }
      }
    }
  }

  // ── Auto-resolve recorded_owner → true_owner ──
  // For each recorded_owner we created/found, check if they need a true_owner link.
  // If no true_owner exists, create one. This ensures the ownership chain is
  // fully resolved for Salesforce cross-referencing downstream.
  if (domain === 'dialysis') {
    for (const [normalizedName, recordedOwnerId] of ownerIds) {
      try {
        const roLookup = await domainQuery(domain, 'GET',
          `recorded_owners?recorded_owner_id=eq.${recordedOwnerId}` +
          `&select=recorded_owner_id,name,true_owner_id,address,city,state&limit=1`
        );
        const ro = roLookup.ok && roLookup.data?.length ? roLookup.data[0] : null;
        if (!ro || ro.true_owner_id) continue; // already linked

        // Skip lenders — they don't get true_owner records
        if (LENDER_PATTERN.test(ro.name || '')) continue;

        // Check if a true_owner already exists by normalized name
        const toMatch = await domainQuery(domain, 'GET',
          `true_owners?normalized_name=eq.${encodeURIComponent(normalizedName)}` +
          `&select=true_owner_id&limit=1`
        );
        let trueOwnerId = null;
        if (toMatch.ok && toMatch.data?.length) {
          trueOwnerId = toMatch.data[0].true_owner_id;
        } else {
          // ORE Option A Unit 4: "the recorded owner IS the true owner" is an
          // UNVERIFIED CoStar assertion (Scott: "CoStar mis-identifies constantly").
          // Record it as a datapoint to corroborate/review; only auto-CREATE a
          // brand-new true_owner from it when COSTAR_TRUE_OWNER_TRUST is enabled
          // (default off — surface it, don't trust it). A pre-existing true_owner
          // (the toMatch branch above) is still linked; only the blind clone is gated.
          await recordOwnerLinkObservation(domain, ro.name, ro.name, recordedOwnerId);
          if (process.env.COSTAR_TRUE_OWNER_TRUST !== 'true' && process.env.COSTAR_TRUE_OWNER_TRUST !== '1') {
            continue; // await corroboration; no blind recorded→true clone
          }
          // Create new true_owner from recorded_owner data
          const toData = stripNulls({
            name: ro.name,
            normalized_name: normalizedName,
            city: ro.city || null,
            state: ro.state || null,
            owner_type: 'investor',
          });
          const toResult = await domainQuery(domain, 'POST', 'true_owners', toData);
          if (toResult.ok && toResult.data) {
            const created = Array.isArray(toResult.data) ? toResult.data[0] : toResult.data;
            trueOwnerId = created?.true_owner_id || null;
          } else if (toResult.status === 409 && toResult.data?.code === '23505') {
            // C4 race: another writer just landed the same true_owner. Re-fetch by key.
            const refetch = await domainQuery(domain, 'GET',
              `true_owners?normalized_name=eq.${encodeURIComponent(normalizedName)}` +
              `&merged_into_true_owner_id=is.null&select=true_owner_id&limit=1`);
            if (refetch.ok && refetch.data?.length) {
              trueOwnerId = refetch.data[0].true_owner_id;
            }
          }
        }

        if (trueOwnerId) {
          await domainPatch(domain,
            `recorded_owners?recorded_owner_id=eq.${recordedOwnerId}`,
            { true_owner_id: trueOwnerId },
            'upsertDomainOwners:linkToTrueOwner'
          );
          console.log(`[upsertDomainOwners] linked recorded_owner "${ro.name}" → true_owner ${trueOwnerId}`);
        }
      } catch (err) {
        console.error(`[upsertDomainOwners] true_owner resolution error for ${normalizedName}:`, err?.message);
      }
    }
  }

  // If no ownership_history was written from sales (e.g. only stat card
  // captured, no deed entries with buyer names), write one from the
  // current owner contact and the most recent sale date.
  if (results.history === 0) {
    // Round 76ek.i: same filter as the property writer — prefer a private
    // owner over the federal-government anti-pattern when both exist.
    const ownerContact = selectAuthoritativeOwner(metadata);
    if (ownerContact?.name) {
      const ownerId = await ensureRecordedOwner(
        ownerContact.name,
        ownerContact.address || null,
        { phone: ownerContact.phone || null, email: ownerContact.email || null }
      );
      if (ownerId) {
        // Find the most recent sale date as the transfer date
        const mostRecentSale = [...(metadata.sales_history || [])]
          .filter(s => s.sale_date)
          .sort((a, b) => new Date(b.sale_date) - new Date(a.sale_date))[0];
        const transferDate = mostRecentSale
          ? parseDate(mostRecentSale.sale_date)?.split('T')[0]
          : null;

        // Gov uses transfer_date + new_owner/prior_owner
        // Dialysis uses ownership_start
        const ohData = domain === 'government'
          ? stripNulls({
              property_id:       propertyId,
              recorded_owner_id: ownerId,
              new_owner:         ownerContact.name,
              prior_owner:       (metadata.contacts || [])
                                   .find(c => c.role === 'seller')?.name || null,
              transfer_date:     transferDate,
              sale_price:        parseCurrency(
                                   mostRecentSale?.sale_price),
              data_source:       'costar_sidebar',
            })
          : stripNulls({
              property_id:       propertyId,
              recorded_owner_id: ownerId,
              ownership_start:   transferDate,
              ownership_end:     null,  // current owner
              sold_price:        parseCurrency(
                                   mostRecentSale?.sale_price),
            });

        const dateCol = domain === 'government'
          ? `transfer_date=eq.${transferDate}`
          : `ownership_start=eq.${transferDate}`;
        const dedupPath = `ownership_history?property_id=eq.${propertyId}` +
          `&recorded_owner_id=eq.${ownerId}&${dateCol}&select=ownership_id&limit=1`;
        const ohCheck = await domainQuery(domain, 'GET', dedupPath);
        if (!ohCheck.ok || !ohCheck.data?.length) {
          const r = await domainQuery(domain, 'POST', 'ownership_history', ohData);
          if (r.ok) results.history++;
        }
      }
    }
  }

  // Reconcile: set properties.recorded_owner_id to the most-recent
  // ownership_history buyer, and update current_value_estimate from the
  // latest sold_price.  This covers the gap where CoStar sidebar ingests
  // a new sale (with buyer) but never explicitly marks that buyer as
  // role=owner in contacts.
  await reconcilePropertyOwnership(domain, propertyId);

  return results;
}

// ── Ownership reconciliation ───────────────────────────────────────────────
// Ensures properties.recorded_owner_id always points to the most-recent buyer
// from ownership_history, and back-fills current_value_estimate from the latest
// sold_price.  Called per-property after upsertDomainOwners and also exposed
// for batch repair via admin diagnostics.

export async function reconcilePropertyOwnership(domain, propertyId) {
  const dateCol  = domain === 'government' ? 'transfer_date' : 'ownership_start';
  const priceCol = domain === 'government' ? 'transfer_price' : 'sold_price';

  // 1. Fetch the most recent ownership_history record for this property
  const ohRes = await domainQuery(domain, 'GET',
    `ownership_history?property_id=eq.${propertyId}` +
    `&recorded_owner_id=not.is.null` +
    `&order=${dateCol}.desc.nullslast` +
    `&select=recorded_owner_id,${dateCol},${priceCol}` +
    `&limit=1`
  );
  if (!ohRes.ok || !ohRes.data?.length) return { updated: false };

  const latest = ohRes.data[0];
  const latestOwnerId = latest.recorded_owner_id;
  const latestDate    = latest[dateCol];
  const latestPrice   = latest[priceCol];

  // 2. Fetch the property's current recorded_owner_id so we know whether to
  //    update.  Also grab the current owner's transfer date for comparison.
  const propRes = await domainQuery(domain, 'GET',
    `properties?property_id=eq.${propertyId}` +
    `&select=recorded_owner_id,current_value_estimate` +
    `&limit=1`
  );
  if (!propRes.ok || !propRes.data?.length) return { updated: false };

  const prop = propRes.data[0];
  const patch = {};

  // If the property already points to this owner, skip the owner update but
  // still check whether current_value_estimate needs back-filling.
  if (prop.recorded_owner_id !== latestOwnerId) {
    // Verify the new owner is actually newer than the existing one
    if (prop.recorded_owner_id && latestDate) {
      const curOwnerOh = await domainQuery(domain, 'GET',
        `ownership_history?property_id=eq.${propertyId}` +
        `&recorded_owner_id=eq.${prop.recorded_owner_id}` +
        `&order=${dateCol}.desc.nullslast` +
        `&select=${dateCol}` +
        `&limit=1`
      );
      if (curOwnerOh.ok && curOwnerOh.data?.length) {
        const curDate = curOwnerOh.data[0][dateCol];
        if (curDate && new Date(curDate) >= new Date(latestDate)) {
          // Current owner is same-date-or-newer; don't overwrite
          return { updated: false, reason: 'current_owner_is_newer' };
        }
      }
    }
    patch.recorded_owner_id = latestOwnerId;

    // 2b. Back-fill recorded_owner_name, true_owner_id, and true_owner_name
    //     from the recorded_owners / true_owners tables so the denormalized
    //     cache on the properties row stays in sync with the new owner ID.
    const roRes = await domainQuery(domain, 'GET',
      `recorded_owners?recorded_owner_id=eq.${latestOwnerId}` +
      `&select=name,true_owner_id` +
      `&limit=1`
    );
    if (roRes.ok && roRes.data?.length) {
      const ro = roRes.data[0];
      if (ro.name) patch.recorded_owner_name = ro.name;
      if (ro.true_owner_id) {
        patch.true_owner_id = ro.true_owner_id;
        const truRes = await domainQuery(domain, 'GET',
          `true_owners?true_owner_id=eq.${ro.true_owner_id}` +
          `&select=name` +
          `&limit=1`
        );
        if (truRes.ok && truRes.data?.length && truRes.data[0].name) {
          patch.true_owner_name = truRes.data[0].name;
        }
      }
    }
  }

  // 3. Back-fill current_value_estimate from the latest sold price
  if (latestPrice && !prop.current_value_estimate) {
    patch.current_value_estimate = latestPrice;
  }

  if (Object.keys(patch).length === 0) return { updated: false, reason: 'no_change' };

  await domainPatch(domain,
    `properties?property_id=eq.${propertyId}`,
    patch,
    'reconcilePropertyOwnership'
  );
  return { updated: true, patch };
}

// ── R51: deed grantee → recorded_owner forward propagation ──────────────────
// The recorded deed grantee is the authoritative "who took title" (legal
// title). When a NEW grantee that passes the owner guards is captured, push it
// onto properties.recorded_owner THROUGH the field-priority gate
// (source='recorded_deed', priority 3) so it OUTRANKS the costar/county
// aggregators (50/60/10) but can NEVER clobber a manual_resolution / manual_edit
// (priority 1). true_owner is NEVER written directly here — it is the
// R47-resolved parent and re-resolves from the new recorded_owner via the
// owner-facts mirror sync / R47 cron. Used by the deed-writer path (forward,
// new captures) AND the R51 Unit-3 high-confidence auto-fix worker.

// Reusable guard: a brokerage / junk / federal-antipattern / deal-string
// grantee must NEVER become the recorded owner. Reuses the same write-time
// guards the entity graph and contact pipeline use.
export function granteePassesOwnerGuards(name) {
  if (!name || typeof name !== 'string') return false;
  const clean = sanitizeOwnerName(name); // strips " by <Brokerage>" suffix
  if (!clean || clean.replace(/[^a-z0-9]/gi, '').length < 4) return false;
  if (isCompetitorBroker(clean)) return false;        // a brokerage is never the owner
  if (isFederalOwnerAntiPattern(clean)) return false; // personal-property bleed-through
  if (isJunkEntityName(clean)) return false;          // structural garbage (org-safe:
                                                      // does NOT reject firm suffixes)
  return true;
}

function ownerNameNorm(s) {
  return String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

const R51_PROP_TARGET_DB    = (domain) => (domain === 'government' ? 'gov_db' : 'dia_db');
const R51_PROP_TARGET_TABLE = (domain) => (domain === 'government' ? 'gov.properties' : 'dia.properties');
const R51_OWNER_TARGET_TABLE = (domain) => (domain === 'government' ? 'gov.recorded_owners' : 'dia.recorded_owners');

function buildDeedPropagationDeps() {
  return { domainQuery, domainPatch, shouldWriteField };
}

// Resolve an existing recorded_owner by EXACT name — the real UNIQUE key on dia
// recorded_owners.name — following a merge tombstone to the surviving owner so we
// never point a property at a tombstoned owner. This is the fix for the
// owner_resolve_failed class (2026-07-15): the stored normalized_name/canonical_name
// on an existing owner can be computed by an OLDER norm than
// resolveOrCreateRecordedOwnerForDeed uses (e.g. "corporation"→"...oration",
// "income"→"...ome", kept `&`/comma), so the normalized dedup GET misses AND the
// POST 409s on UNIQUE(name), and the old normalized 409-recovery missed too. The
// exact-name value is PostgREST-quoted so commas/`&`/spaces in the name are safe.
async function findRecordedOwnerByExactName(domain, cleanName, q) {
  const quoted = '"' + String(cleanName).replace(/"/g, '\\"') + '"';
  const r = await q(domain, 'GET',
    `recorded_owners?name=eq.${encodeURIComponent(quoted)}` +
    `&select=recorded_owner_id,merged_into_recorded_owner_id&limit=1`);
  if (!r.ok || !Array.isArray(r.data) || !r.data.length) return null;
  const row = r.data[0];
  return row.merged_into_recorded_owner_id || row.recorded_owner_id || null;
}

// Resolve an existing recorded_owner by normalized name, or create a minimal
// one. Mirrors upsertDomainOwners' ensureRecordedOwner dedup convention.
async function resolveOrCreateRecordedOwnerForDeed(domain, cleanName, entity, deps) {
  const q = deps.domainQuery;
  const nameCol = domain === 'government' ? 'canonical_name' : 'normalized_name';
  const norm = cleanName.trim().toLowerCase()
    .replace(/\b(llc|inc|corp|ltd|co|company|group|partners|lp|llp)\b\.?/gi, '')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  const look = await q(domain, 'GET',
    `recorded_owners?${nameCol}=eq.${encodeURIComponent(norm)}` +
    `&merged_into_recorded_owner_id=is.null&select=recorded_owner_id&limit=1`);
  if (look.ok && Array.isArray(look.data) && look.data.length) {
    return look.data[0].recorded_owner_id;
  }
  // Exact-name dedup (the real UNIQUE key) BEFORE the POST — catches an existing
  // owner whose stored normalized_name was computed by an older norm (which the
  // normalized GET above misses and the POST below would 409 on), and follows a
  // merge tombstone to the live survivor.
  const byName = await findRecordedOwnerByExactName(domain, cleanName, q);
  if (byName) return byName;
  const ownerData = stripNulls({ name: cleanName, [nameCol]: norm, state: entity?.state || null });
  const ins = await q(domain, 'POST', 'recorded_owners', ownerData);
  if (ins.ok && ins.data) {
    const created = Array.isArray(ins.data) ? ins.data[0] : ins.data;
    if (created?.recorded_owner_id) return created.recorded_owner_id;
  }
  if (ins.status === 409) {
    // A UNIQUE(name) collision on a row the normalized GET couldn't see — recover
    // by exact name (following the tombstone), then fall back to the normalized re-GET.
    const survivor = await findRecordedOwnerByExactName(domain, cleanName, q);
    if (survivor) return survivor;
    const r2 = await q(domain, 'GET',
      `recorded_owners?${nameCol}=eq.${encodeURIComponent(norm)}` +
      `&merged_into_recorded_owner_id=is.null&select=recorded_owner_id&limit=1`);
    if (r2.ok && r2.data?.length) return r2.data[0].recorded_owner_id;
  }
  return null;
}

// R59 — exported thin wrapper so the deed-extraction worker can resolve/create a
// recorded_owner for an ownership_history append. Sanitizes the raw deed grantee
// (strips " by <Brokerage>" etc.) then reuses the same dedup-or-create resolver.
// Returns recorded_owner_id or null (best-effort; never throws).
export async function resolveDeedRecordedOwner(domain, name, deps) {
  try {
    const d = deps || buildDeedPropagationDeps();
    const clean = sanitizeOwnerName(name) || (name || '').trim();
    if (!clean || clean.replace(/[^a-z0-9]/gi, '').length < 4) return null;
    return await resolveOrCreateRecordedOwnerForDeed(domain, clean, {}, d);
  } catch (_e) { return null; }
}

// A lender name must be substantive and not a brokerage/junk — but a bank / finance
// / federal entity IS a legitimate lender, so (unlike granteePassesOwnerGuards) do
// NOT apply the federal anti-pattern reject here.
function lenderNamePasses(name) {
  const clean = sanitizeOwnerName(name);
  if (!clean || clean.replace(/[^a-z0-9]/gi, '').length < 4) return null;
  if (isCompetitorBroker(clean)) return null;   // a broker is not a lender
  if (isJunkEntityName(clean)) return null;      // structural garbage
  return clean;
}

// ── ORE follow-up (2026-07-15/16): normalize a lender into the `lenders` entity
// table so lenders dedup ACROSS loans (like recorded_owners), then stamp
// `loans.lender_id`. Dedup key: dia `normalized_name` / gov `lower(name)` — NEITHER
// `lenders` table carries a UNIQUE on the name, so this is a GET-then-insert (a POST
// never 409s). `lender_type` is left UNSET (a per-domain CHECK vocabulary with no
// value we can infer from a deed). Returns lender_id (uuid) or null (best-effort;
// never throws).
//   Cleaning pipeline (the SINGLE choke point both the deed path AND the messy
//   CoStar text-lender backfill inherit): cleanLenderName() FIRST — strips a leading
//   broker/intermediary prefix ("Marcus & Millichap Capstar Bank" → "Capstar Bank"),
//   drops allocation-note parentheticals ("JLL CIT Group ($1.5m alloc'd)" → "CIT
//   Group"), and SKIPS an ambiguous/garbage string (multi-lender `;`, placeholder
//   Private/Other, bare fragment) so it is left text-only, never forced into
//   `lenders`. Then lenderNamePasses() (banks / finance / federal ARE legit lenders
//   — no federal reject). The cleaner's quality IS the dedup quality.
export async function resolveOrCreateLender(domain, name, deps) {
  try {
    const q = (deps || buildDeedPropagationDeps()).domainQuery;
    const cleaned = cleanLenderName(name);
    if (cleaned.skip) return null;
    const clean = lenderNamePasses(cleaned.clean);
    if (!clean) return null;
    const isGov = domain === 'government';
    // Case-insensitive exact match; escape LIKE wildcards so a `%`/`_` in a name
    // can't broaden the dedup (lender names essentially never carry them).
    const likeVal = clean.replace(/([%_\\])/g, '\\$1');
    const norm = clean.trim().toLowerCase()
      .replace(/\b(llc|inc|corp|ltd|co|company|group|partners|lp|llp|na|n a)\b\.?/gi, '')
      .replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
    if (isGov) {
      const g = await q(domain, 'GET',
        `lenders?name=ilike.${encodeURIComponent(likeVal)}&select=lender_id&limit=1`).catch(() => ({ ok: false }));
      if (g.ok && Array.isArray(g.data) && g.data.length) return g.data[0].lender_id;
    } else {
      const g = await q(domain, 'GET',
        `lenders?normalized_name=eq.${encodeURIComponent(norm)}&select=lender_id&limit=1`).catch(() => ({ ok: false }));
      if (g.ok && Array.isArray(g.data) && g.data.length) return g.data[0].lender_id;
      // Exact-name fallback: a pre-existing dia lender whose normalized_name was
      // computed by an older/absent norm (mirrors the recorded_owner resolver).
      const g2 = await q(domain, 'GET',
        `lenders?lender_name=ilike.${encodeURIComponent(likeVal)}&select=lender_id&limit=1`).catch(() => ({ ok: false }));
      if (g2.ok && Array.isArray(g2.data) && g2.data.length) return g2.data[0].lender_id;
    }
    const row = isGov ? { name: clean } : { lender_name: clean, normalized_name: norm };
    const ins = await q(domain, 'POST', 'lenders', row).catch(() => ({ ok: false }));
    if (ins.ok && ins.data) {
      const created = Array.isArray(ins.data) ? ins.data[0] : ins.data;
      if (created && created.lender_id) return created.lender_id;
    }
    return null;
  } catch (_e) { return null; }
}

// ── ORE: route a SECURITY-INSTRUMENT (mortgage / deed of trust) party set to the
// LENDER side of the DB (Scott's doctrine, 2026-07-15). The grantee is the LENDER
// (mortgagee) → the loan's text lender column (dia `lender_name` / gov `originator`
// — the codebase stores lenders as text on `loans`, the `lenders` table is dormant);
// the grantor is the BORROWER (mortgagor = owner) → `loans.recorded_owner_id`
// (resolve/create, since the mortgagor genuinely IS a property owner). NEVER writes
// the mortgagee to any owner-side field. Fill-blanks-ish: dedups on
// (property_id, lender, origination_date). Best-effort; never throws.
export async function writeLoanFromDeed(args, deps) {
  const d = deps || buildDeedPropagationDeps();
  const q = d.domainQuery;
  const out = { ok: false, lender_routed: null, lender_id: null, loan_written: false, borrower_owner_id: null, skipped: null };
  try {
    const { domain, propertyId, lenderName, borrowerName = null,
            loanAmount = null, originationDate = null, documentId = null, sourceUrl = null } = args || {};
    if (!domain || propertyId == null || !lenderName) { out.skipped = 'missing_input'; return out; }
    const lender = lenderNamePasses(lenderName);
    if (!lender) { out.skipped = 'lender_failed_guards'; return out; }

    // Normalize the lender into the `lenders` entity table (dedup across loans) and
    // stamp loans.lender_id. Best-effort — a null lender_id still writes the loan
    // with the text lender (originator / lender_name), so the loan is never lost.
    const lenderId = await resolveOrCreateLender(domain, lender, d).catch(() => null);
    out.lender_id = lenderId;

    // Borrower (mortgagor) = the property owner who took the loan. BOTH domains now
    // carry a `loans.recorded_owner_id` column, so resolve/create the borrower owner
    // and link it structurally on both (gov column added 2026-07-15).
    let borrowerOwnerId = null;
    if (borrowerName) {
      borrowerOwnerId = await resolveDeedRecordedOwner(domain, borrowerName, d).catch(() => null);
    }
    out.borrower_owner_id = borrowerOwnerId;

    // Dedup: an existing loan for this property + lender near the same origination.
    const lenderCol = domain === 'government' ? 'originator' : 'lender_name';
    const dedupParts = [`property_id=eq.${encodeURIComponent(String(propertyId))}`,
                        `${lenderCol}=ilike.${encodeURIComponent(lender)}`];
    if (originationDate) dedupParts.push(`origination_date=eq.${originationDate}`);
    const look = await q(domain, 'GET', `loans?${dedupParts.join('&')}&select=loan_id&limit=1`).catch(() => ({ ok: false }));
    if (look.ok && Array.isArray(look.data) && look.data.length) {
      out.ok = true; out.lender_routed = lender; out.skipped = 'already_recorded'; return out;
    }

    // loan_type is a CHECK-constrained vocabulary that differs by domain and has no
    // generic "mortgage" value — the security-instrument nature is carried by
    // data_source='deed_extraction' + the notes instead (gov's 'County_Recorded'
    // is the semantic fit but dia lacks it, so leave loan_type unset on both).
    const borrowerNote = borrowerName ? ` Borrower (mortgagor) = ${borrowerName}.` : '';
    const row = stripNulls(domain === 'government'
      ? { property_id: propertyId, originator: lender, lender_id: lenderId, recorded_owner_id: borrowerOwnerId,
          loan_amount: loanAmount || null, origination_date: originationDate || null,
          status: 'active', source_url: sourceUrl || null, data_source: 'deed_extraction',
          notes: `Deed-extracted security instrument (doc ${documentId}); grantee=lender, grantor=borrower.${borrowerNote}` }
      : { property_id: propertyId, lender_name: lender, lender_id: lenderId, recorded_owner_id: borrowerOwnerId,
          loan_amount: loanAmount || null, origination_date: originationDate || null,
          is_active: true, source_url: sourceUrl || null, data_source: 'deed_extraction',
          notes: `Deed-extracted security instrument (doc ${documentId}); grantee=lender, grantor=borrower.${borrowerNote}` });
    const ins = await q(domain, 'POST', 'loans', row, { Prefer: 'return=minimal' }).catch(() => ({ ok: false }));
    if (ins && ins.ok) { out.ok = true; out.loan_written = true; out.lender_routed = lender; }
    else { out.skipped = 'loan_insert_failed'; }
    return out;
  } catch (_e) { out.skipped = 'exception'; return out; }
}

// ── ORE: write the SIGNATORY (the person signing the document) as a contact linked
// to the property (Scott: "the contact signing the documents"). Enrichment only —
// junk-guarded, deduped on (property_id, name, role='signatory'), best-effort.
export async function writeDeedPartyContact(args, deps) {
  const d = deps || buildDeedPropagationDeps();
  const q = d.domainQuery;
  const out = { ok: false, written: false, skipped: null };
  try {
    const { domain, propertyId, name, title = null, role = 'signatory',
            onBehalfOf = null, documentId = null } = args || {};
    if (!domain || propertyId == null || !name) { out.skipped = 'missing_input'; return out; }
    const clean = String(name).trim();
    if (clean.replace(/[^a-z0-9]/gi, '').length < 4 || isJunkEntityName(clean)) { out.skipped = 'name_failed_guards'; return out; }
    const isGov = domain === 'government';
    const nameCol = isGov ? 'name' : 'contact_name';
    const roleCol = isGov ? 'contact_type' : 'role';
    const look = await q(domain, 'GET',
      `contacts?property_id=eq.${encodeURIComponent(String(propertyId))}` +
      `&${nameCol}=ilike.${encodeURIComponent(clean)}&${roleCol}=eq.${encodeURIComponent(role)}&select=contact_id&limit=1`
    ).catch(() => ({ ok: false }));
    if (look.ok && Array.isArray(look.data) && look.data.length) { out.ok = true; out.skipped = 'already_recorded'; return out; }
    const row = stripNulls({
      [nameCol]: clean, [roleCol]: role, title: title || null,
      property_id: propertyId, company: onBehalfOf || null, data_source: 'deed_extraction',
      notes: `Document signatory (doc ${documentId})${onBehalfOf ? `, on behalf of ${onBehalfOf}` : ''}.`,
    });
    const ins = await q(domain, 'POST', 'contacts', row, { Prefer: 'return=minimal' }).catch(() => ({ ok: false }));
    if (ins && ins.ok) { out.ok = true; out.written = true; }
    else { out.skipped = 'contact_insert_failed'; }
    return out;
  } catch (_e) { out.skipped = 'exception'; return out; }
}

export async function propagateDeedGranteeToOwner(args, deps) {
  deps = deps || buildDeedPropagationDeps();
  const { domain, propertyId, granteeName, entity = {},
          source = 'recorded_deed', workspaceId = null,
          sourceRunId = null, confidence = 0.9 } = args || {};
  const out = { domain, property_id: propertyId, grantee: granteeName || null,
                applied: false, decision: null, skipped: null, recorded_owner_id: null };
  try {
    if (!domain || !propertyId || !granteeName) { out.skipped = 'missing_input'; return out; }
    const clean = sanitizeOwnerName(granteeName);
    if (!clean) { out.skipped = 'empty_after_sanitize'; return out; }
    if (!granteePassesOwnerGuards(granteeName)) { out.skipped = 'grantee_failed_guards'; return out; }

    // Current property owner.
    const propRes = await deps.domainQuery(domain, 'GET',
      `properties?property_id=eq.${propertyId}&select=recorded_owner_id&limit=1`);
    if (!propRes.ok || !propRes.data?.length) { out.skipped = 'property_not_found'; return out; }
    const curOwnerId = propRes.data[0].recorded_owner_id;
    let curName = null;
    if (curOwnerId) {
      const r = await deps.domainQuery(domain, 'GET',
        `recorded_owners?recorded_owner_id=eq.${curOwnerId}&select=name&limit=1`);
      curName = (r.ok && r.data?.[0]) ? r.data[0].name : null;
    }
    if (curName && ownerNameNorm(curName) === ownerNameNorm(clean)) {
      out.skipped = 'already_current'; out.recorded_owner_id = curOwnerId; return out;
    }

    const newOwnerId = await resolveOrCreateRecordedOwnerForDeed(domain, clean, entity, deps);
    if (!newOwnerId) { out.skipped = 'owner_resolve_failed'; return out; }
    if (curOwnerId && String(curOwnerId) === String(newOwnerId)) {
      out.skipped = 'already_current'; out.recorded_owner_id = curOwnerId; return out;
    }

    // Priority gate — recorded_deed(3) beats the aggregators, loses to manual(1).
    const gate = await deps.shouldWriteField({
      targetDb: R51_PROP_TARGET_DB(domain), targetTable: R51_PROP_TARGET_TABLE(domain),
      recordPk: propertyId, fieldName: 'recorded_owner_id', value: newOwnerId,
      source, sourceRunId, confidence,
    });
    out.decision = gate.decision;
    if (!gate.write) {
      out.skipped = 'blocked_by_priority'; out.blocked_by = gate.currentSource || null; return out;
    }

    // Apply: set recorded_owner_id (+ recorded_owner_name on dia, where the
    // denormalized column exists). Do NOT write true_owner_id (R47 re-resolves).
    const patch = { recorded_owner_id: newOwnerId };
    if (domain === 'dialysis') patch.recorded_owner_name = clean;
    const pr = await deps.domainPatch(domain,
      `properties?property_id=eq.${propertyId}`, patch, 'propagateDeedGranteeToOwner');
    if (pr && pr.ok === false) { out.skipped = 'patch_failed'; return out; }

    // Record the recorded_owner_name logical-field provenance too (best-effort).
    try {
      await deps.shouldWriteField({
        targetDb: R51_PROP_TARGET_DB(domain), targetTable: R51_PROP_TARGET_TABLE(domain),
        recordPk: propertyId, fieldName: 'recorded_owner_name', value: clean,
        source, sourceRunId, confidence,
      });
    } catch (_e) { /* best-effort */ }

    out.applied = true; out.recorded_owner_id = newOwnerId;
    return out;
  } catch (err) {
    out.skipped = 'error'; out.error = err?.message || String(err);
    return out;
  }
}

// After a deed grantee becomes the recorded_owner (R51 propagateDeedGranteeToOwner),
// close the transfer loop on the DOMAIN side so the property doesn't leave the two
// orphan banners behind ("Back-link sale" + "Reconcile owner"):
//   (a) attribute the property's most-recent sale WHOSE BUYER IS this owner to the
//       new recorded_owner_id. Keying on the sale's own buyer (== the grantee) is
//       what makes this correct — the legacy orphan-sale backlink attributed the
//       sale to whatever the *current* recorded_owner was, which mis-attributes a
//       just-transferred property (e.g. the 2026 TNRE-13 sale → the stale Rainier
//       owner). And
//   (b) append the ownership_history transfer for that sale (dedup on
//       property+owner+date; per-domain columns; mirrors upsertDomainOwners / R59).
// Never fabricates a sale — only acts on a captured sale whose buyer normalizes to
// the owner. Append-only / fill-blanks; best-effort, never throws. Reversible:
// data_source='owner_deed_reconcile' (gov) / ownership_source='owner_deed_reconcile'
// (dia) tag the OH row; the sale carries the recorded_owner_id it set. Returns
// { sale_attributed, sale_id, ownership_history_appended, skipped }.
export async function reconcileSaleAndOwnershipForNewOwner(args, deps) {
  deps = deps || buildDeedPropagationDeps();
  const { domain, propertyId, recordedOwnerId, ownerName } = args || {};
  const out = { domain, property_id: propertyId, sale_attributed: false, sale_id: null,
                ownership_history_appended: false, skipped: null };
  try {
    if (!domain || !propertyId || !recordedOwnerId || !ownerName) { out.skipped = 'missing_input'; return out; }
    const wantNorm = ownerNameNorm(ownerName);
    if (!wantNorm) { out.skipped = 'owner_name_empty'; return out; }

    // Most-recent captured sales for the property (buyer/seller/price/attribution).
    const salesRes = await deps.domainQuery(domain, 'GET',
      `sales_transactions?property_id=eq.${propertyId}` +
      `&order=sale_date.desc.nullslast,sale_id.desc` +
      `&select=sale_id,sale_date,sold_price,buyer,seller,recorded_owner_id&limit=25`);
    if (!salesRes.ok || !Array.isArray(salesRes.data) || !salesRes.data.length) {
      out.skipped = 'no_sales'; return out;
    }
    // The acquisition sale = the most-recent sale whose BUYER is this owner.
    const sale = salesRes.data.find((s) => s.buyer && ownerNameNorm(s.buyer) === wantNorm);
    if (!sale) { out.skipped = 'no_matching_buyer_sale'; return out; }
    out.sale_id = sale.sale_id;
    const saleDateStr = sale.sale_date ? String(sale.sale_date).split('T')[0] : null;

    // (a) Attribute the sale to the new owner (only when null or different).
    if (String(sale.recorded_owner_id || '') !== String(recordedOwnerId)) {
      const buyerPatch = { recorded_owner_id: recordedOwnerId, recorded_owner_name: ownerName };
      const pr = await deps.domainPatch(domain,
        `sales_transactions?sale_id=eq.${encodeURIComponent(sale.sale_id)}`,
        buyerPatch, 'reconcileSaleAndOwnershipForNewOwner:attributeSale');
      if (!(pr && pr.ok === false)) out.sale_attributed = true;
    }

    // (b) Append the ownership_history transfer. Dedup is per-domain: dia keys a
    // transfer by sale_id (a UNIQUE constraint — ownership_history_sale_id_unique)
    // so if the sale is already on an OH row the transfer is recorded and a second
    // insert would 23505; gov's shape carries no sale_id, so it keys on
    // (property, owner, transfer_date). The insert shape mirrors the proven
    // upsertDomainOwners OH writer.
    if (saleDateStr) {
      if (domain === 'dialysis') {
        const byId = await deps.domainQuery(domain, 'GET',
          `ownership_history?sale_id=eq.${encodeURIComponent(sale.sale_id)}&select=ownership_id&limit=1`);
        if (!(byId.ok && Array.isArray(byId.data) && byId.data.length)) {
          const ohData = stripNulls({
            property_id: propertyId, recorded_owner_id: recordedOwnerId,
            ownership_start: saleDateStr, sold_price: parseCurrency(sale.sold_price),
            sale_id: sale.sale_id, ownership_source: 'owner_deed_reconcile',
          });
          const ins = await deps.domainQuery(domain, 'POST', 'ownership_history', ohData);
          if (ins.ok) out.ownership_history_appended = true;
        }
      } else {
        const dedup = await deps.domainQuery(domain, 'GET',
          `ownership_history?property_id=eq.${propertyId}` +
          `&recorded_owner_id=eq.${encodeURIComponent(recordedOwnerId)}` +
          `&transfer_date=eq.${saleDateStr}&select=ownership_id&limit=1`);
        if (!(dedup.ok && Array.isArray(dedup.data) && dedup.data.length)) {
          const ohData = stripNulls({
            property_id: propertyId, recorded_owner_id: recordedOwnerId,
            new_owner: ownerName, prior_owner: sale.seller || null,
            transfer_date: saleDateStr, transfer_price: parseCurrency(sale.sold_price),
            data_source: 'owner_deed_reconcile',
          });
          const ins = await deps.domainQuery(domain, 'POST', 'ownership_history', ohData);
          if (ins.ok) out.ownership_history_appended = true;
        }
      }
    }
    return out;
  } catch (err) { out.skipped = 'error'; out.error = err?.message || String(err); return out; }
}

// ORE Phase 1 Unit C — write the recorded deed's GRANTEE mailing address onto the
// resolved recorded_owner (fill-blanks only, provenance source='recorded_deed').
// The deed grantee IS the new owner; its notice / return-to address is the owner
// mailing address Scott's ownership cross-match (Phase 2) keys on.
//   gov: a single `mailing_address` text column (gov.recorded_owners has no
//        address/city — a dedicated queryable column beats burying in contact_info).
//   dia: the EXISTING `address`/`city`/`state` columns (the owner mailing address;
//        already laddered in field_source_priority), filled from the parsed parts.
// Never clobbers a non-blank value; records LCC field provenance per filled field
// (best-effort, record_only). Reversible (revert by clearing the column / the
// recorded_deed provenance row). Returns { applied, fields_filled, skipped }.
export async function writeOwnerMailingAddress(args, deps) {
  deps = deps || buildDeedPropagationDeps();
  const { domain, ownerId, address, parsed = null, source = 'recorded_deed',
          sourceRunId = null, confidence = 0.9 } = args || {};
  const out = { domain, owner_id: ownerId, applied: false, fields_filled: [], skipped: null };
  try {
    if (!domain || !ownerId || !address) { out.skipped = 'missing_input'; return out; }
    const clean = String(address).replace(/\s+/g, ' ').trim();
    if (clean.length < 6) { out.skipped = 'address_too_short'; return out; }

    const isGov = domain === 'government';
    const selCols = isGov ? 'mailing_address' : 'address,city,state';
    const cur = await deps.domainQuery(domain, 'GET',
      `recorded_owners?recorded_owner_id=eq.${encodeURIComponent(ownerId)}&select=${selCols}&limit=1`);
    if (!cur.ok || !cur.data?.length) { out.skipped = 'owner_not_found'; return out; }
    const row = cur.data[0];

    // Fill-blanks per column (never clobber a curated value).
    const patch = {};
    if (isGov) {
      if (!row.mailing_address) patch.mailing_address = clean;
    } else {
      const street = (parsed && parsed.street) || clean;
      if (!row.address && street) patch.address = street;
      if (!row.city && parsed && parsed.city) patch.city = parsed.city;
      if (!row.state && parsed && parsed.state) patch.state = parsed.state;
    }
    if (!Object.keys(patch).length) { out.skipped = 'already_present'; return out; }

    const pr = await deps.domainPatch(domain,
      `recorded_owners?recorded_owner_id=eq.${encodeURIComponent(ownerId)}`, patch, 'writeOwnerMailingAddress');
    if (pr && pr.ok === false) { out.skipped = 'patch_failed'; return out; }

    // Record provenance per filled field (best-effort; record_only ⇒ never blocks).
    for (const f of Object.keys(patch)) {
      out.fields_filled.push(f);
      try {
        await deps.shouldWriteField({
          targetDb: R51_PROP_TARGET_DB(domain), targetTable: R51_OWNER_TARGET_TABLE(domain),
          recordPk: ownerId, fieldName: f, value: patch[f], source, sourceRunId, confidence,
        });
      } catch (_e) { /* best-effort */ }
    }
    out.applied = true;
    return out;
  } catch (err) { out.skipped = 'error'; out.error = err?.message || String(err); return out; }
}

// Pick the latest deed grantee from captured sales/deeds (non-mortgage, newest
// recording date), preferring the property's denormalized latest_deed_grantee.
export function latestDeedGranteeFromMetadata(metadata) {
  const sales = Array.isArray(metadata?.sales_history) ? metadata.sales_history : [];
  const deeds = sales.filter(s =>
    s && s.buyer &&
    !MORTGAGE_DEED_TYPES.test(String(s.deed_type || s.transaction_type || '')));
  if (deeds.length === 0) return null;
  deeds.sort((a, b) => {
    const ad = new Date(a.recordation_date || a.sale_date || 0).getTime() || 0;
    const bd = new Date(b.recordation_date || b.sale_date || 0).getTime() || 0;
    return bd - ad;
  });
  return { grantee: deeds[0].buyer, deedDate: deeds[0].recordation_date || deeds[0].sale_date || null };
}

// ── Step 5d1b: Cross-reference owners against Salesforce ──────────────────
// After true_owner records are resolved, check LCC unified_contacts for
// matching Salesforce IDs. Uses normalized name + related entity expansion.
// Only runs for dialysis domain (gov has separate SF integration path).

async function crossReferenceSalesforce(domain, propertyId) {
  if (domain !== 'dialysis') return { matched: 0 };

  let matched = 0;

  try {
    // Get all true_owners linked to this property via recorded_owners in ownership_history
    const ohRes = await domainQuery(domain, 'GET',
      `ownership_history?property_id=eq.${propertyId}` +
      `&recorded_owner_id=not.is.null` +
      `&select=recorded_owner_id` +
      `&limit=20`
    );
    if (!ohRes.ok || !ohRes.data?.length) return { matched: 0 };

    // Collect unique recorded_owner_ids → true_owner_ids
    const roIds = [...new Set(ohRes.data.map(r => r.recorded_owner_id))];

    for (const roId of roIds) {
      const roRes = await domainQuery(domain, 'GET',
        `recorded_owners?recorded_owner_id=eq.${roId}` +
        `&select=recorded_owner_id,name,normalized_name,true_owner_id` +
        `&limit=1`
      );
      if (!roRes.ok || !roRes.data?.length) continue;
      const ro = roRes.data[0];
      if (!ro.true_owner_id) continue;

      // Check if true_owner already has SF link
      const toRes = await domainQuery(domain, 'GET',
        `true_owners?true_owner_id=eq.${ro.true_owner_id}` +
        `&select=true_owner_id,name,normalized_name,salesforce_id,sf_company_id` +
        `&limit=1`
      );
      if (!toRes.ok || !toRes.data?.length) continue;
      const trueOwner = toRes.data[0];
      if (trueOwner.salesforce_id || trueOwner.sf_company_id) continue; // already linked

      // Search LCC unified_contacts by normalized company name
      const normalizedName = trueOwner.normalized_name || ro.normalized_name;
      if (!normalizedName) continue;

      // Use opsQuery (LCC Supabase) to search unified_contacts
      const sfMatch = await opsQuery('GET',
        `unified_contacts?company_name=ilike.*${encodeURIComponent(normalizedName)}*` +
        `&or=(sf_contact_id.not.is.null,sf_account_id.not.is.null)` +
        `&select=sf_contact_id,sf_account_id,company_name,full_name` +
        `&limit=3`
      );

      if (sfMatch.ok && sfMatch.data?.length) {
        const best = sfMatch.data[0];
        const sfPatch = {};
        if (best.sf_contact_id) sfPatch.salesforce_id = best.sf_contact_id;
        if (best.sf_account_id) sfPatch.sf_company_id = best.sf_account_id;

        if (Object.keys(sfPatch).length) {
          await domainPatch(domain,
            `true_owners?true_owner_id=eq.${trueOwner.true_owner_id}`,
            sfPatch,
            'crossReferenceSalesforce'
          );
          matched++;
          console.log(`[crossReferenceSalesforce] linked true_owner "${trueOwner.name}" ` +
            `→ SF ${sfPatch.salesforce_id || sfPatch.sf_company_id} ` +
            `(matched via "${best.company_name || best.full_name}")`);
        }
      } else {
        // Fallback: search by recorded_owner name (LLC names) in case the SF
        // record uses the LLC name rather than the true owner name
        const roName = ro.normalized_name;
        if (roName && roName !== normalizedName) {
          const roSfMatch = await opsQuery('GET',
            `unified_contacts?company_name=ilike.*${encodeURIComponent(roName)}*` +
            `&or=(sf_contact_id.not.is.null,sf_account_id.not.is.null)` +
            `&select=sf_contact_id,sf_account_id,company_name` +
            `&limit=1`
          );
          if (roSfMatch.ok && roSfMatch.data?.length) {
            const best = roSfMatch.data[0];
            const sfPatch = {};
            if (best.sf_contact_id) sfPatch.salesforce_id = best.sf_contact_id;
            if (best.sf_account_id) sfPatch.sf_company_id = best.sf_account_id;
            if (Object.keys(sfPatch).length) {
              await domainPatch(domain,
                `true_owners?true_owner_id=eq.${trueOwner.true_owner_id}`,
                sfPatch,
                'crossReferenceSalesforce:roFallback'
              );
              matched++;
              console.log(`[crossReferenceSalesforce] linked true_owner "${trueOwner.name}" ` +
                `→ SF via recorded_owner "${ro.name}" match`);
            }
          }
        }
      }
    }
  } catch (err) {
    console.error('[crossReferenceSalesforce] error:', err?.message || err);
  }

  return { matched };
}

// ── Step 5d2: Upsert true owners (true buyer / true seller) ────────────────

async function upsertTrueOwners(domain, propertyId, metadata) {
  const contacts = metadata.contacts || [];

  // Find true buyer — must have a name that looks like an organization,
  // not a CoStar UI label
  const COSTAR_LABEL_PATTERN = /^(sale\s+date|sale\s+price|buyer\s+type|country|national|institutional|private|individual|confirmed|investment|research\s+complete|wood\s+frame|suburban|parking|land|zoning|building|type|location|stories|class|construction|tenancy|sprinklers|parcels|assessment|documents|deed|market|vacancy|submarket|months\s+on\s+market|prev\s+year)/i;

  const trueBuyer = contacts.find(c =>
    c.role === 'true_buyer' &&
    c.name &&
    c.name.length > 3 &&
    c.name.length < 100 &&
    !COSTAR_LABEL_PATTERN.test(c.name)
  );

  const trueSeller = contacts.find(c =>
    c.role === 'true_seller' &&
    c.name &&
    c.name.length > 3 &&
    c.name.length < 100 &&
    !COSTAR_LABEL_PATTERN.test(c.name)
  );

  // Filter individual contacts to only include those with a name that
  // looks like a real person (not a CoStar UI label)
  const trueBuyerContacts = contacts.filter(c =>
    c.role === 'true_buyer_contact' &&
    c.name &&
    c.name.length > 3 &&
    c.name.length < 60 &&
    !COSTAR_LABEL_PATTERN.test(c.name) &&
    // Real person names have at least a first and last name (space between)
    // OR have a phone/email attached
    (c.name.includes(' ') || c.phones?.length || c.email)
  );
  const trueSellerContacts = contacts.filter(c =>
    c.role === 'true_seller_contact' &&
    c.name &&
    c.name.length > 3 &&
    c.name.length < 60 &&
    !COSTAR_LABEL_PATTERN.test(c.name) &&
    (c.name.includes(' ') || c.phones?.length || c.email)
  );

  let trueBuyerId  = null;
  let trueSellerId = null;

  // Helper: find or create a true_owner record
  async function ensureTrueOwner(owner, individualContacts) {
    if (!owner?.name) return null;

    // Reject CoStar classification labels that slip in as contact entries
    const CONTACT_LABEL_REJECT = /^(public|private|local|national|institutional|corporation|individual|other|buyer\s+contacts|seller\s+contacts|public\s+reit|user|managing\s+partner|country\s+of\s+origin|buyer\s+origin|seller\s+origin|buyer\s+type|seller\s+type|secondary\s+type|activity|sale\s+notes|documents|deed)$/i;

    const cleanedContacts = individualContacts.filter(c =>
      c.name &&
      c.name.length > 3 &&
      !CONTACT_LABEL_REJECT.test(c.name.trim()) &&
      (c.name.includes(' ') || c.phones?.length || c.email)
    );

    const normalized = owner.name.trim().toLowerCase()
      .replace(/\b(llc|inc|corp|ltd|lp|llp|co|company|group|partners)\b\.?/gi, '')
      .replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();

    if (domain === 'government') {
      // Check true_owners table first (canonical buyer intelligence)
      const normalized = owner.name.trim().toUpperCase()
        .replace(/\b(LLC|INC|CORP|LTD|LP|LLP|GLOBAL|ASSET\s+MANAGEMENT)\b\.?/gi, '')
        .replace(/[^A-Z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();

      const lookup = await domainQuery('government', 'GET',
        `true_owners?canonical_name=ilike.*${encodeURIComponent(normalized)}*` +
        `&select=true_owner_id,name&limit=1`
      );
      if (lookup.ok && lookup.data?.length) {
        return lookup.data[0].true_owner_id;
      }

      // Not in true_owners — create a new record
      const r = await domainQuery('government', 'POST', 'true_owners', {
        name:           owner.name,
        canonical_name: owner.name.toUpperCase(),
        entity_type:    'buyer',
        contact_info:   JSON.stringify({
          address: owner.address || null,
          city:    owner.city    || null,
          state:   owner.state   || null,
          phone:   owner.phone   || null,
        }),
      });
      return r.ok && r.data
        ? (Array.isArray(r.data) ? r.data[0] : r.data)?.true_owner_id
        : null;
    }

    // Dialysis: true_owners table
    const lookup = await domainQuery('dialysis', 'GET',
      `true_owners?normalized_name=eq.${encodeURIComponent(normalized)}&select=true_owner_id&limit=1`
    );
    if (lookup.ok && lookup.data?.length) {
      return lookup.data[0].true_owner_id;
    }
    const contact1 = cleanedContacts[0]?.name || null;
    const contact2 = cleanedContacts[1]?.name || null;
    const trueOwnerData = stripNulls({
      name:              owner.name,
      normalized_name:   normalized,
      notice_address_1:  owner.address || null,
      city:              owner.city    || null,
      state:             owner.state   || null,
      contact_1_name:    contact1,
      contact_2_name:    contact2,
      owner_type:        'buyer',
      is_prospect:       true,
      updated_at:        new Date().toISOString(),
    });
    const r = await domainQuery('dialysis', 'POST', 'true_owners', trueOwnerData);
    return r.ok && r.data
      ? (Array.isArray(r.data) ? r.data[0] : r.data)?.true_owner_id
      : null;
  }

  // Write true buyer
  if (trueBuyer) {
    // ORE Option A Unit 4: record the CoStar recorded→true-buyer assertion as an
    // UNVERIFIED datapoint (recorded owner from the owner panel → this true buyer)
    // BEFORE the write. The properties.true_owner_id write is KEPT: it is CoStar's
    // explicit True-Buyer panel (the strongest CoStar ownership signal) and the
    // sole source of gov true_owners — gating it off would gut the gov ownership
    // chain. It is surfaced for corroboration/review in v_lcc_owner_link_review,
    // never blindly trusted. (Judgment call, 2026-07-23; see the round summary.)
    try {
      const recordedOwner = selectAuthoritativeOwner(metadata);
      if (recordedOwner?.name) {
        await recordOwnerLinkObservation(domain, recordedOwner.name, trueBuyer.name, null);
      }
    } catch (_) { /* best-effort */ }
    trueBuyerId = await ensureTrueOwner(trueBuyer, trueBuyerContacts);
    if (trueBuyerId) {
      await domainPatch(domain,
        `properties?property_id=eq.${propertyId}`,
        { true_owner_id: trueBuyerId },
        'upsertTrueOwners'
      );
    }
  }

  // Write true seller (for historical record — don't update property)
  if (trueSeller) {
    trueSellerId = await ensureTrueOwner(trueSeller, trueSellerContacts);
  }

  return {
    true_buyer_id:  trueBuyerId,
    true_seller_id: trueSellerId,
  };
}

// ── Step 5e: Upsert leases (dialysis only) ────────────────────────────────

// Rent-anchor source tier ranking. Lower = more authoritative. Mirrors the
// guard in migrations/dialysis_db/20260416_lease_data_provenance_03_guard_upsert_functions.sql
// (upsert_lease_field) so a lower-tier source never clobbers a higher-tier one.
const ANCHOR_SOURCE_RANK = {
  lease_confirmed: 0,
  om_confirmed:    1,
  costar_stated:   2,
};
function anchorSourceRank(src) {
  if (src == null) return 3;
  return ANCHOR_SOURCE_RANK[src] ?? 3;
}

/**
 * Map a promoted-intake document_type to the anchor_rent_source label.
 * Returns null when the intake path doesn't correspond to a known anchor
 * source (leaves properties.anchor_rent_source alone).
 */
function promotedAnchorSource(metadata) {
  if (!metadata || metadata._intake_promoted !== true) return null;
  if (metadata.document_type === 'lease_abstract') return 'lease_confirmed';
  if (metadata.document_type === 'om')             return 'om_confirmed';
  return null;
}

/**
 * Promote properties.anchor_rent/date/source from a freshly-ingested lease
 * record iff the incoming source outranks (or matches) the existing anchor.
 * No-op when a strictly higher-tier source is already present.
 */
async function promotePropertyAnchorRent(domain, propertyId, candidate) {
  if (domain !== 'dialysis') return false;
  if (!candidate?.anchor_rent || !candidate.anchor_rent_source) return false;
  if (!(Number(candidate.anchor_rent) > 0)) return false;
  if (!candidate.anchor_rent_date) return false;

  const lookup = await domainQuery(domain, 'GET',
    `properties?property_id=eq.${encodeURIComponent(propertyId)}` +
    `&select=anchor_rent_source&limit=1`
  );
  if (!lookup.ok) {
    console.error('[promotePropertyAnchorRent] lookup failed:', lookup.status);
    return false;
  }
  const existingSource = lookup.data?.[0]?.anchor_rent_source || null;
  if (anchorSourceRank(existingSource) < anchorSourceRank(candidate.anchor_rent_source)) {
    console.log(
      `[promotePropertyAnchorRent] skipping property=${propertyId}: ` +
      `existing=${existingSource} outranks incoming=${candidate.anchor_rent_source}`
    );
    return false;
  }

  await domainPatch(domain,
    `properties?property_id=eq.${encodeURIComponent(propertyId)}`,
    {
      anchor_rent:        Number(candidate.anchor_rent),
      anchor_rent_date:   candidate.anchor_rent_date,
      anchor_rent_source: candidate.anchor_rent_source,
    },
    'promotePropertyAnchorRent'
  );
  console.log(
    `[promotePropertyAnchorRent] promoted property=${propertyId} ` +
    `rent=${candidate.anchor_rent} date=${candidate.anchor_rent_date} ` +
    `source=${candidate.anchor_rent_source} (was=${existingSource || 'null'})`
  );
  return true;
}

/**
 * Upsert a CoStar-sourced lease row on the government leases table.
 *
 * Government-domain context: the GSA master-lease loader seeds leases
 * with data_source='excel_master' carrying the umbrella-lease tenant
 * (e.g. "PITTSBURGH FIELD OFFICE"). CoStar may identify a different
 * actual occupant (e.g. FEMA under LPA00668). Rather than mutating the
 * master-lease row, this writer maintains a PARALLEL
 * data_source='costar_sidebar' row keyed on (property_id, lease_number,
 * tenant_agency) so both facts are preserved and downstream queries
 * can prefer the costar_sidebar row when reporting the actual occupant.
 *
 * This function always PATCHes the matched costar_sidebar row on
 * re-ingest so the audit trail (leases.updated_at) advances, even when
 * no underlying field changes.
 *
 * Returns the number of leases written (inserted or updated).
 */
async function upsertGovernmentLeases(propertyId, metadata, provCollect) {
  // Round 76ej.q (2026-05-05): write one lease record per tenant for
  // multi-tenant gov-leased buildings. Pre-fix this function only
  // wrote a single row from tenants[0], silently dropping the rest —
  // a Mast One-style listing with 5 GSA / Bon Secours / FDA / Supreme
  // Court of VA / Rein / Edward Jones tenants kept just the first.
  // Mirror upsertDomainLeases (dialysis) which already does per-tenant
  // fan-out.

  // Build the tenant list from BOTH sources so single-tenant captures
  // (where metadata.tenants is empty) still write their one lease.
  const tenantInputs = [];
  const seen = new Set();
  const pushTenant = (name, extra) => {
    if (!name || typeof name !== 'string') return;
    const trimmed = name.trim();
    if (trimmed.length < 3) return;
    const key = trimmed.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    tenantInputs.push({ name: trimmed, ...(extra || {}) });
  };
  // Round 76ej.x (2026-05-05): per-domain tenant filter. On mixed-
  // tenant buildings (Centralia: DaVita + Assured + SSA) we only want
  // gov-flavored tenants in gov.leases. Without this, dia tenants
  // would land in gov.leases too once the orchestrator propagates to
  // both domains.
  const govPush = (n, x) => { if (isTenantForDomain(n, 'government')) pushTenant(n, x); };
  govPush(metadata.tenant_name);
  govPush(metadata.primary_tenant);
  if (Array.isArray(metadata.tenants)) {
    for (const t of metadata.tenants) {
      if (t && typeof t === 'object') govPush(t.name, { sf: t.sf });
      else if (typeof t === 'string') govPush(t);
    }
  }
  if (tenantInputs.length === 0) return 0;

  const leaseNumber = metadata.lease_number || null;
  // Lease-level scalars are shared across tenants in a building — we
  // copy them onto each per-tenant row. When the page surfaces a
  // per-tenant SF (multi-tenant buildings often have suite areas),
  // that overrides the metadata-level rent_per_sf computation later.
  const annualRent  = parseCurrency(metadata.annual_rent);
  const rentPsf     = parseCurrency(metadata.rent_per_sf);
  const commence    = parseDate(metadata.lease_commencement)?.split('T')[0] || null;
  const expire      = parseDate(metadata.lease_expiration)?.split('T')[0] || null;
  const govType     = metadata.government_type || null;
  const expense     = metadata.expense_structure || metadata.lease_type || null;
  const renewal     = metadata.renewal_options || null;

  let writes = 0;
  for (const t of tenantInputs) {
    const tenantAgency = t.name;

    // Look up an existing costar_sidebar-sourced row keyed on
    // (property_id, data_source='costar_sidebar', tenant_agency,
    //  lease_number-when-present). Intentionally scoped so we never
    // overwrite the excel_master master-lease row — the priority-source
    // rule from the audit is that costar_sidebar and excel_master
    // coexist, and downstream reporting picks costar_sidebar first.
    let filter = `property_id=eq.${propertyId}&data_source=eq.costar_sidebar`;
    if (leaseNumber) {
      filter += `&lease_number=eq.${encodeURIComponent(leaseNumber)}`;
    }
    filter += `&tenant_agency=eq.${encodeURIComponent(tenantAgency)}`;
    const existing = await domainQuery('government', 'GET',
      `leases?${filter}&select=lease_id&limit=1`
    );

    const payload = {
      property_id:        propertyId,
      lease_number:       leaseNumber,
      tenant_agency:      tenantAgency,
      tenant_agency_full: tenantAgency,
      government_type:    govType,
      commencement_date:  commence,
      expiration_date:    expire,
      // Per-tenant SF when surfaced by the page; falls back to null so
      // the column doesn't get clobbered by an aggregate value.
      annual_rent:        annualRent,
      rent_psf:           rentPsf,
      expense_structure:  expense,
      renewal_options:    renewal,
      data_source:        'costar_sidebar',
      updated_at:         new Date().toISOString(),
    };

    // Fresh audit A-3 (2026-05-18): the gov_reject_dateless_active_lease
    // trigger correctly blocks active-lease writes with both dates NULL
    // (98 silent 4xx/24h). Honor the trigger's intent by skipping the
    // write up-front. Existing leases (UPDATE branch below) are fine — the
    // trigger only rejects new active rows lacking both dates.
    if (!existing.ok || !existing.data?.length) {
      if (!commence && !expire) {
        console.log('[upsertGovernmentLeases] skipped dateless active lease ' +
          'property=' + propertyId + ' tenant_agency=' + JSON.stringify(tenantAgency) +
          ' — both dates NULL; gov_reject_dateless_active_lease would reject.');
        continue;
      }
    }

    if (existing.ok && existing.data?.length) {
      const leaseId = existing.data[0].lease_id;
      await domainPatch('government',
        `leases?lease_id=eq.${leaseId}`,
        payload,
        'upsertGovernmentLeases:refresh'
      );
      console.log(`[upsertGovernmentLeases] refreshed costar_sidebar lease ` +
        `lease_id=${leaseId} property=${propertyId} ` +
        `tenant_agency=${JSON.stringify(tenantAgency)}`);
      // Round 76ej.r (2026-05-05): record per-tenant gov.leases write to
      // field_provenance so the data-quality dashboard sees multi-tenant
      // coverage. Mirrors the dialysis upsertDomainLeases instrumentation.
      // Writer flush re-prefixes with `${tablePrefix}.`; pass the unqualified
      // table name so the row lands as `gov.leases`, not `gov.gov.leases`.
      // (R4-5 2026-05-20: double-schema typo here produced 600+ unranked rows.)
      pushProvenance(provCollect, 'leases', leaseId, {
        tenant_agency: tenantAgency,
        tenant_agency_full: tenantAgency,
        government_type: govType,
        commencement_date: commence,
        expiration_date: expire,
        annual_rent: annualRent,
        rent_psf: rentPsf,
        expense_structure: expense,
        renewal_options: renewal,
      });
      writes++;
      continue;
    }

    const r = await domainQuery('government', 'POST', 'leases', payload,
      { label: 'upsertGovernmentLeases:insert' });
    if (r.ok) {
      const created = Array.isArray(r.data) ? r.data[0] : r.data;
      const newLeaseId = created?.lease_id || null;
      console.log(`[upsertGovernmentLeases] inserted costar_sidebar lease ` +
        `property=${propertyId} tenant_agency=${JSON.stringify(tenantAgency)} ` +
        `lease_number=${leaseNumber || 'null'}`);
      if (newLeaseId) {
        pushProvenance(provCollect, 'leases', newLeaseId, {
          tenant_agency: tenantAgency,
          tenant_agency_full: tenantAgency,
          government_type: govType,
          commencement_date: commence,
          expiration_date: expire,
          annual_rent: annualRent,
          rent_psf: rentPsf,
          expense_structure: expense,
          renewal_options: renewal,
        });
      }
      writes++;
      continue;
    }
    console.error('[upsertGovernmentLeases] INSERT failed:',
      r.status, r.data, 'tenant_agency=', tenantAgency);
  }
  return writes;
}

/**
 * Upsert lease records in the domain database.
 * Uses a parent-child consolidation model: extensions/renewals reference
 * the original lease via parent_lease_id rather than creating independent rows.
 *
 * Builds one lease record per tenant from metadata.tenants[].
 * Falls back to a single record from top-level fields if tenants[] is empty.
 * Deduplicates by property_id + tenant (case-insensitive, fuzzy for dialysis).
 *
 * When incoming dates differ from the active lease for the same tenant,
 * the existing active lease is superseded and a new term is created.
 * When dates match, the existing row is PATCHed with updated data.
 *
 * Skips government domain — see upsertGovernmentLeases above for the
 * gov-specific writer (different schema, different conflict semantics).
 */
async function upsertDomainLeases(domain, propertyId, metadata, provCollect) {
  // Domain guard — only dialysis for now
  if (domain !== 'dialysis') return 0;

  // Round 76ej.x (2026-05-05): per-domain tenant filter. On mixed-
  // tenant buildings (Centralia) we want DaVita + Assured Home Health
  // in dia.leases but NOT Social Security Administration (which is
  // gov-only). isTenantForDomain('dialysis') drops tenants matching
  // GOV_TENANT_PATTERNS unless they ALSO match DIALYSIS_TENANT_PATTERNS
  // (a hybrid like "VA Dialysis Center" stays).
  const tenants = Array.isArray(metadata.tenants)
    ? metadata.tenants.filter((t) => t && t.name && isTenantForDomain(t.name, 'dialysis'))
    : metadata.tenants;
  let leaseRecords = [];

  // Determine data_source and source_confidence based on origin
  const leaseDataSource = metadata._intake_promoted
    ? 'email_intake'
    : 'costar_sidebar';
  // Dialysis leases.source_confidence CHECK: 'documented' | 'inferred' | 'placeholder'
  // lease_abstract docs → 'documented'; OM / other intake → 'inferred'
  // CoStar sidebar data → 'inferred' (not 'estimated' — that value is rejected by CHECK)
  const leaseConfidence = metadata._intake_promoted
    ? (metadata.document_type === 'lease_abstract' ? 'documented' : 'inferred')
    : 'inferred';

  // ── Junk tenant filter (defense-in-depth against scraper bugs) ──────
  // isJunkTenant() + its regex battery were hoisted to module scope (2026-06-07)
  // so the entity bridge (unpackTenant) reuses the SAME definition instead of
  // a drifting copy. See the module-level isJunkTenant above.

  // ── Derive annual_rent from NOI for NNN/absolute leases ──────────────
  // On absolute NNN leases, the tenant pays all expenses, so NOI ≈ annual_rent.
  // If metadata.annual_rent is missing but NOI is present and the expense
  // structure indicates NNN/absolute, use NOI as a derived annual_rent.
  const expStructure = (metadata.expense_structure || metadata.lease_type || '').toLowerCase();
  const isNNN = /\b(nnn|triple\s*net|absolute\s*net|absolute|bond)\b/i.test(expStructure);
  let derivedAnnualRent = null;
  if (!metadata.annual_rent && metadata.noi && isNNN) {
    derivedAnnualRent = parseCurrency(metadata.noi);
    if (derivedAnnualRent && derivedAnnualRent >= 100) {
      console.log(`[upsertDomainLeases] Derived annual_rent=$${derivedAnnualRent} from NOI (NNN lease)`);
    } else {
      derivedAnnualRent = null;
    }
  }

  // Upper-bound rent guard (2026-05-21): detect and correct annual_rent
  // values inflated by 12 (legacy ingestor pattern where annual was treated
  // as monthly and multiplied by 12). Cleanup migration backfilled 113
  // properties + 70 leases; this guard prevents recurrence on new captures.
  // Realistic dialysis lease PSF: $15-$60/SF/yr. PSF > 200 is the corruption
  // threshold; if dividing by 12 lands in [10, 80] PSF we auto-correct,
  // otherwise we drop the rent value entirely and log for review.
  function correctRentForPsfAnomaly(rent, leasedArea, tenantName) {
    if (!rent || !leasedArea || leasedArea < 100) return rent;
    const psf = rent / leasedArea;
    if (psf <= 200) return rent;
    const div12Psf = psf / 12;
    if (div12Psf >= 10 && div12Psf <= 80) {
      console.warn(`[upsertDomainLeases] x12 rent anomaly auto-corrected for ${tenantName}: ` +
        `$${Math.round(rent)} (PSF $${Math.round(psf)}) -> $${Math.round(rent / 12)} (PSF $${Math.round(div12Psf)})`);
      return rent / 12;
    }
    console.warn(`[upsertDomainLeases] suspicious rent dropped for ${tenantName}: ` +
      `$${Math.round(rent)} on ${Math.round(leasedArea)} SF = $${Math.round(psf)}/SF (no clean correction). ` +
      `Will fall through to derived rent.`);
    return null;
  }

  if (Array.isArray(tenants) && tenants.length > 0) {
    // Build one lease record per tenant entry, filtering out junk
    for (const t of tenants) {
      if (!t.name || isJunkTenant(t.name)) continue;
      // Guard: CoStar metadata.annual_rent is often a junk value like "$11"
      // (the per-SF rent misread as total rent). Reject obviously bogus values
      // below $100/yr — no real commercial lease has annual rent that low.
      const parsedAnnualRent = parseCurrency(metadata.annual_rent);
      const safeAnnualRent = (parsedAnnualRent && parsedAnnualRent >= 100) ? parsedAnnualRent : derivedAnnualRent;
      // Round 76dr: leased_area inference. Tenant-level SF can be missing
      // (single-tenant for-sale pages don't always show a Tenants table)
      // or reject as a placeholder ("0000,000" in the 5 Route 45 capture).
      // When the property is single-tenant + 100% leased + RBA known,
      // infer leased_area = RBA. This matches CoStar's own implicit
      // statement that a 100%-leased single-tenant building's tenant
      // occupies the full RBA.
      let inferredLeasedArea = parseSF(t.sf);
      if (!inferredLeasedArea) {
        const isSingleTenant = (metadata.tenancy_type === 'Single')
          || /single/i.test(metadata.tenancy_type || '')
          || (Array.isArray(tenants) && tenants.length === 1);
        const occupancyPct = parsePercent(metadata.occupancy);
        const fullyLeased = occupancyPct == null || occupancyPct >= 99;
        const rba = parseSF(metadata.square_footage)
          || parseSF(metadata.rba)
          || parseSF(metadata.sf_leased);
        if (isSingleTenant && fullyLeased && rba && rba >= 100) {
          inferredLeasedArea = rba;
          console.log(`[upsertDomainLeases] inferred leased_area=${rba} for ${t.name} (single-tenant + 100% leased + RBA)`);
        }
      }
      const leaseStart = parseDate(t.lease_start || metadata.lease_commencement);
      const leaseExp   = parseDate(t.lease_expiration || metadata.lease_expiration);
      // Skip dateless placeholder leases. v_data_quality_issues 2026-04-29
      // showed 36 active leases with no dates, all written by costar_sidebar
      // in the prior 48h — the writer was happily creating placeholders
      // when CoStar had a tenant name but no lease dates. A lease without
      // either date can't drive lifecycle (expiration, supersede, rent
      // projection) and just pollutes the table.
      if (!leaseStart && !leaseExp) {
        console.log(`[upsertDomainLeases] skip dateless tenant=${t.name} on property=${propertyId}`);
        continue;
      }
      const correctedAnnualRent = correctRentForPsfAnomaly(safeAnnualRent, inferredLeasedArea, t.name);
      const finalAnnualRent = correctedAnnualRent !== null ? correctedAnnualRent : derivedAnnualRent;
      leaseRecords.push({
        property_id: propertyId,
        // canonicalizeTenant collapses brand variants (DaVita Inc. /
        // DAVITA DIALYSIS / Davita Healthcare Partners → DaVita Kidney Care)
        // so the lease row's tenant column is stable across captures and
        // same-source provenance conflicts disappear.
        tenant: canonicalizeTenant(t.name.trim()),
        leased_area: inferredLeasedArea,
        lease_start: leaseStart,
        lease_expiration: leaseExp,
        expense_structure: t.lease_type || metadata.expense_structure || metadata.lease_type,
        rent_per_sf: parseCurrency(t.rent_per_sf || metadata.rent_per_sf),
        annual_rent: finalAnnualRent,
        renewal_options: metadata.renewal_options || null,
        guarantor: metadata.guarantor || null,
        status: 'active',
        is_active: true,
        data_source: leaseDataSource,
        source_confidence: leaseConfidence,
      });
    }
  } else {
    // Fallback: single lease from top-level metadata fields
    const tenantName = metadata.tenant_name || metadata.primary_tenant;
    if (!tenantName) return 0;

    const fallbackStart = parseDate(metadata.lease_commencement);
    const fallbackExp   = parseDate(metadata.lease_expiration);
    if (!fallbackStart && !fallbackExp) {
      console.log(`[upsertDomainLeases] skip dateless top-level tenant=${tenantName} on property=${propertyId}`);
      return 0;
    }

    const fallbackAnnualRent = parseCurrency(metadata.annual_rent);
    const safeFallbackRent = (fallbackAnnualRent && fallbackAnnualRent >= 100) ? fallbackAnnualRent : derivedAnnualRent;
    const fallbackLeasedArea = parseSF(metadata.sf_leased);
    const correctedFallbackRent = correctRentForPsfAnomaly(safeFallbackRent, fallbackLeasedArea, tenantName);
    const finalFallbackRent = correctedFallbackRent !== null ? correctedFallbackRent : derivedAnnualRent;
    leaseRecords.push({
      property_id: propertyId,
      tenant: canonicalizeTenant(tenantName.trim()),
      leased_area: fallbackLeasedArea,
      lease_start: fallbackStart,
      lease_expiration: fallbackExp,
      expense_structure: metadata.expense_structure || metadata.lease_type,
      rent_per_sf: parseCurrency(metadata.rent_per_sf),
      annual_rent: finalFallbackRent,
      renewal_options: metadata.renewal_options || null,
      guarantor: metadata.guarantor || null,
      status: 'active',
      is_active: true,
      data_source: leaseDataSource,
      source_confidence: leaseConfidence,
    });
  }

  // Fetch all existing leases for this property (including superseded) with
  // full date/term data so we can detect new terms vs. updates to existing terms.
  const existing = await domainQuery(
    domain, 'GET',
    `leases?property_id=eq.${propertyId}` +
    `&select=lease_id,tenant,lease_start,lease_expiration,term_number,parent_lease_id,superseded_at,is_active,leased_area,renewal_options,expense_structure,operator,annual_rent,rent_per_sf,source_confidence` +
    `&limit=50`
  );
  const existingLeases = existing.data || [];
  const existingTenants = new Set(
    existingLeases.map(l => l.tenant?.toLowerCase().trim())
  );

  // Helper: find the original (root) lease for a tenant chain
  function findOriginalLease(tenantKey) {
    return existingLeases.find(l =>
      l.tenant?.toLowerCase().trim() === tenantKey &&
      !l.parent_lease_id &&
      (l.term_number === 1 || l.term_number == null)
    );
  }

  // Helper: find the current active lease for a tenant
  function findActiveLease(tenantKey) {
    return existingLeases.find(l =>
      l.tenant?.toLowerCase().trim() === tenantKey &&
      l.is_active && !l.superseded_at
    );
  }

  // Helper: normalize date to YYYY-MM-DD for comparison
  function normDateStr(d) {
    if (!d) return null;
    return String(d).slice(0, 10);
  }

  let count = 0;
  for (const record of leaseRecords) {
    const cleaned = stripNulls(record);
    // Always keep property_id, status, is_active even if they'd survive stripNulls
    cleaned.property_id = propertyId;
    cleaned.status = 'active';
    cleaned.is_active = true;

    const tenantKey = record.tenant.toLowerCase().trim();
    let leaseId = null;

    // ── Tenant matching: exact first, then fuzzy for dialysis ──
    let matchedLease = null;
    let matchedTenantKey = tenantKey;

    // Exact match — prefer active lease
    if (existingTenants.has(tenantKey)) {
      matchedLease = findActiveLease(tenantKey) ||
        existingLeases.find(l => l.tenant?.toLowerCase().trim() === tenantKey);
    }
    // Fuzzy match for dialysis — single-tenant operators with name variants
    if (!matchedLease && domain === 'dialysis') {
      const incomingWords = tenantKey.split(/\s+/).filter(w => w.length > 3);
      for (const l of existingLeases) {
        const eName = l.tenant?.toLowerCase().trim() || '';
        if (incomingWords.some(w => eName.includes(w))) {
          matchedLease = l;
          matchedTenantKey = eName;
          break;
        }
      }
    }

    if (matchedLease) {
      // ── Lease consolidation: decide PATCH vs. new term ──
      const incomingStart = normDateStr(cleaned.lease_start);
      const incomingExp = normDateStr(cleaned.lease_expiration);
      const existingStart = normDateStr(matchedLease.lease_start);
      const existingExp = normDateStr(matchedLease.lease_expiration);

      const datesAreDifferent = (incomingStart && existingStart && incomingStart !== existingStart) ||
        (incomingExp && existingExp && incomingExp !== existingExp);

      // Only create a new term if BOTH incoming dates are present and differ
      // from the existing active lease. If incoming has no dates or only one
      // date differs, it's an update to the current term, not a new extension.
      const isNewTerm = datesAreDifferent && incomingStart && incomingExp &&
        matchedLease.is_active && !matchedLease.superseded_at;

      if (isNewTerm) {
        // ── New term detected → supersede the existing active lease, insert new term ──
        const originalLeaseId = matchedLease.parent_lease_id || matchedLease.lease_id;
        const maxTermNumber = Math.max(
          ...existingLeases
            .filter(l => (l.parent_lease_id || l.lease_id) === originalLeaseId)
            .map(l => l.term_number || 1),
          0
        );

        // Determine term_type: if there's a gap > 30 days, it's a renewal; otherwise extension
        const gapDays = existingExp && incomingStart
          ? (new Date(incomingStart) - new Date(existingExp)) / 86400000
          : 0;
        const termType = gapDays > 30 ? 'renewal' : 'extension';

        // Supersede the existing active lease
        await domainPatch(domain,
          `leases?lease_id=eq.${matchedLease.lease_id}`,
          { superseded_at: new Date().toISOString(), is_active: false },
          'upsertDomainLeases:supersede'
        );
        console.log(`[upsertDomainLeases] superseded lease_id=${matchedLease.lease_id} ` +
          `(term ${matchedLease.term_number || 1}) for new ${termType}`);

        // Carry forward leased_area, operator, expense_structure from parent if incoming is null
        const parentLease = existingLeases.find(l => l.lease_id === originalLeaseId) || matchedLease;
        if (!cleaned.leased_area && parentLease?.leased_area) {
          cleaned.leased_area = parentLease.leased_area;
          console.log(`[upsertDomainLeases] propagating leased_area=${parentLease.leased_area} from parent`);
        }
        if (!cleaned.operator && parentLease?.operator) cleaned.operator = parentLease.operator;
        if (!cleaned.expense_structure && parentLease?.expense_structure) {
          cleaned.expense_structure = parentLease.expense_structure;
        }

        // Insert the new term
        cleaned.parent_lease_id = originalLeaseId;
        cleaned.term_number = maxTermNumber + 1;
        cleaned.term_type = termType;

        const result = await domainQuery(domain, 'POST', 'leases', cleaned);
        if (!result.ok) {
          console.error('[upsertDomainLeases] new term INSERT failed:', {
            domain, propertyId, tenant: record.tenant,
            status: result.status, error: result.data,
          });
          continue;
        }
        count++;
        leaseId = Array.isArray(result.data) ? result.data[0]?.lease_id : result.data?.lease_id;
        console.log(`[upsertDomainLeases] created new ${termType} lease_id=${leaseId} ` +
          `term ${maxTermNumber + 1} for property=${propertyId}`);
        // Phase 2.2.b: provenance for the new term lease
        pushProvenance(provCollect, 'leases', leaseId, {
          tenant:            cleaned.tenant,
          annual_rent:       cleaned.annual_rent,
          rent_per_sf:       cleaned.rent_per_sf,
          leased_area:       cleaned.leased_area,
          lease_start:       cleaned.lease_start,
          lease_expiration:  cleaned.lease_expiration,
          expense_structure: cleaned.expense_structure,
          renewal_options:   cleaned.renewal_options,
          guarantor:         cleaned.guarantor,
        });
      } else {
        // ── Same term or partial update → PATCH existing lease ──
        const { property_id: _pid, ...patchData } = cleaned;
        // Don't overwrite term metadata on a simple PATCH
        delete patchData.term_number;
        delete patchData.term_type;
        delete patchData.parent_lease_id;
        // Don't overwrite existing rent data with lower-confidence CoStar values.
        // If the existing lease has annual_rent from a documented/confirmed source,
        // or the existing rent is much higher (>10x) than the incoming value,
        // preserve the existing value — CoStar metadata often contains junk rent.
        if (matchedLease.annual_rent && patchData.annual_rent) {
          const existingIsHigherConfidence =
            matchedLease.source_confidence === 'documented' ||
            (matchedLease.source_confidence === 'inferred' && leaseConfidence === 'inferred' &&
             matchedLease.annual_rent > patchData.annual_rent * 10);
          if (existingIsHigherConfidence) {
            console.log(`[upsertDomainLeases] preserving existing annual_rent=${matchedLease.annual_rent} ` +
              `(${matchedLease.source_confidence}) over incoming=${patchData.annual_rent} (${leaseConfidence})`);
            delete patchData.annual_rent;
            delete patchData.rent_per_sf;
          }
        }
        // Round 76co: consult the priority registry BEFORE the PATCH.
        // filterByFieldPriority drops any column whose strict-mode rule
        // blocks this source. Result: the registry's strict rules now
        // actually prevent writes (they were record-only before), and
        // warn-mode rules still log but proceed. Non-fatal: registry RPC
        // errors fail open so existing behavior continues.
        const filteredPatch = await filterByFieldPriority({
          targetDb:    'dia_db',
          targetTable: 'dia.leases',
          recordPk:    matchedLease.lease_id,
          source:      leaseDataSource,
          confidence:  leaseConfidence === 'documented' ? 0.9
                       : leaseConfidence === 'inferred' ? 0.6
                       : 0.4,
          fields:      patchData,
        }).catch(err => {
          console.warn('[upsertDomainLeases] field-priority filter failed (proceeding with full patch):', err?.message);
          return patchData;
        });
        await domainPatch(domain,
          `leases?lease_id=eq.${matchedLease.lease_id}`, filteredPatch, 'upsertDomainLeases');
        leaseId = matchedLease.lease_id;
        // Phase 2.2.b: provenance for the patched lease (only fields that
        // actually went in via patchData — preserves the per-field skip
        // logic above where existing rent was kept on conflict).
        pushProvenance(provCollect, 'leases', leaseId, {
          tenant:            patchData.tenant,
          annual_rent:       patchData.annual_rent,
          rent_per_sf:       patchData.rent_per_sf,
          leased_area:       patchData.leased_area,
          lease_start:       patchData.lease_start,
          lease_expiration:  patchData.lease_expiration,
          expense_structure: patchData.expense_structure,
          renewal_options:   patchData.renewal_options,
          guarantor:         patchData.guarantor,
        });
      }
    } else {
      // ── No existing lease for this tenant → INSERT as original term ──
      cleaned.term_number = 1;
      cleaned.term_type = 'original';
      const result = await domainQuery(domain, 'POST', 'leases', cleaned);
      if (!result.ok) {
        console.error('[upsertDomainLeases] INSERT failed:', {
          domain,
          propertyId,
          tenant: record.tenant,
          status: result.status,
          error: result.data,
          leaseData: cleaned,
        });
        continue;
      }
      count++;
      existingTenants.add(tenantKey); // prevent double-insert within same run
      leaseId = Array.isArray(result.data) ? result.data[0]?.lease_id : result.data?.lease_id;
      // Phase 2.2.b: provenance for the original-term lease
      pushProvenance(provCollect, 'leases', leaseId, {
        tenant:            cleaned.tenant,
        annual_rent:       cleaned.annual_rent,
        rent_per_sf:       cleaned.rent_per_sf,
        leased_area:       cleaned.leased_area,
        lease_start:       cleaned.lease_start,
        lease_expiration:  cleaned.lease_expiration,
        expense_structure: cleaned.expense_structure,
        renewal_options:   cleaned.renewal_options,
        guarantor:         cleaned.guarantor,
      });
    }

    // Write escalation data from CoStar estimated rent range
    if (domain === 'dialysis' && leaseId) {
      await upsertLeaseEscalations(propertyId, leaseId, metadata);

      // ── Parse and create lease_options from renewal_options text ──
      // Common formats: "2, 5yr" → two 5-year renewal options
      //                 "3x5" → three 5-year options
      //                 "1, 10yr" → one 10-year option
      const renewalText = record.renewal_options || metadata.renewal_options;
      if (renewalText) {
        try {
          const optMatch = String(renewalText).match(/(\d+)\s*[,x×]\s*(\d+)\s*(?:yr|year)?/i);
          if (optMatch) {
            const optCount = parseInt(optMatch[1], 10);
            const optYears = parseInt(optMatch[2], 10);
            for (let i = 1; i <= optCount; i++) {
              await domainQuery(domain, 'POST', 'lease_options', {
                lease_id: leaseId,
                property_id: propertyId,
                option_number: i,
                option_type: 'renewal',
                option_term_years: optYears,
              }, { onConflict: 'lease_id,option_number', merge: 'option_type,option_term_years' });
            }
            console.log(`[upsertDomainLeases] created ${optCount} renewal options (${optYears}yr each) for lease_id=${leaseId}`);
          }
        } catch (optErr) {
          console.warn('[upsertDomainLeases] lease_options parse error:', optErr?.message);
        }
      }

      // ── Lease field provenance: track underwriting-critical fields ──
      // Uses upsert_lease_field() which checks source tier before overwriting,
      // so CoStar data (tier 5) never clobbers lease-document data (tier 1-3).
      //
      // When data arrives via intake promotion (_intake_promoted), the source
      // tier is determined by the document type:
      //   lease_abstract → tier 1 (lease_document)
      //   om             → tier 3 (om_lease_abstract)
      //   otherwise      → tier 4 (broker_package)
      const isIntake = metadata._intake_promoted === true;
      const intakeDocType = metadata.document_type;
      const intakeTier = intakeDocType === 'lease_abstract' ? 1
        : intakeDocType === 'om' ? 3
        : 4;
      const sourceTier   = isIntake ? intakeTier : 5;
      const sourceLabel  = isIntake
        ? (intakeDocType === 'lease_abstract' ? 'lease_document'
           : intakeDocType === 'om' ? 'om_lease_abstract'
           : 'broker_package')
        : 'costar_verified';
      const capturedBy   = isIntake ? 'intake_pipeline' : 'sidebar_pipeline';
      const sourceFile   = isIntake ? (metadata._intake_source || null) : null;
      const provenanceNote = isIntake
        ? `Auto-captured from intake promotion (${intakeDocType || 'unknown'} document)`
        : 'Auto-captured from CoStar sidebar ingestion';

      const provenanceFields = {
        expense_structure: record.expense_structure,
        rent:              record.annual_rent,
        rent_per_sf:       record.rent_per_sf,
        leased_area:       record.leased_area,
        roof_responsibility:      metadata.roof_responsibility || null,
        hvac_responsibility:      metadata.hvac_responsibility || null,
        structure_responsibility: metadata.structure_responsibility || null,
        parking_responsibility:   metadata.parking_responsibility || null,
      };
      for (const [field, value] of Object.entries(provenanceFields)) {
        if (value == null) continue;
        await domainQuery(domain, 'POST', 'rpc/upsert_lease_field', {
          p_lease_id:      leaseId,
          p_field_name:    field,
          p_field_value:   String(value),
          p_source_tier:   sourceTier,
          p_source_label:  sourceLabel,
          p_captured_by:   capturedBy,
          p_source_file:   sourceFile,
          p_source_detail: null,
          p_notes:         provenanceNote,
        });
      }

      // Sync expense_structure_canonical from the mapping table
      if (record.expense_structure) {
        const canonical = await domainQuery(domain, 'GET',
          `expense_structure_canonical?raw_value=eq.${encodeURIComponent(record.expense_structure)}&select=canonical&limit=1`
        );
        if (canonical.ok && canonical.data?.[0]?.canonical) {
          await domainPatch(domain,
            `leases?lease_id=eq.${leaseId}`,
            { expense_structure_canonical: canonical.data[0].canonical },
            'upsertDomainLeases:canonical'
          );
        }
      }
    }
  }

  // ── Anchor-rent promotion ──────────────────────────────────────────────
  // When a lease_abstract or OM promotes through intake, update the
  // property's rent anchor so Step 5g (recalculateSaleCapRates) re-stamps
  // historical sales against the confirmed rent. CoStar sidebar ingests set
  // _intake_promoted=false and leave the existing anchor alone — the only
  // CoStar path that writes anchor_rent is the explicit metadata.anchor_rent
  // branch in upsertDomainProperty.
  const incomingAnchorSource = promotedAnchorSource(metadata);
  if (domain === 'dialysis' && incomingAnchorSource) {
    const anchorRecord = leaseRecords.find(r => Number(r.annual_rent) > 0);
    if (anchorRecord) {
      // For OMs the rent-effective date is lease_commencement when known
      // (the rent figure is anchored to the documented start of the lease);
      // otherwise fall back to today (the OM as-of date).
      const rawDate = anchorRecord.lease_start
        || parseDate(metadata.lease_commencement)
        || new Date().toISOString();
      const anchorDate = typeof rawDate === 'string' ? rawDate.split('T')[0] : null;
      await promotePropertyAnchorRent(domain, propertyId, {
        anchor_rent:        Number(anchorRecord.annual_rent),
        anchor_rent_date:   anchorDate,
        anchor_rent_source: incomingAnchorSource,
      });
    }
  }

  // ── Escalation derivation from OM/metadata fields ──────────────────────
  // When metadata provides escalation info (lease_bump_pct, rent_escalations,
  // or escalation text), create a lease_escalations row if none exists yet.
  if (domain === 'dialysis' && count > 0) {
    const bumpPct = metadata.lease_bump_pct != null ? Number(metadata.lease_bump_pct) : null;
    const bumpIntervalMo = metadata.lease_bump_interval_mo
      ? parseInt(metadata.lease_bump_interval_mo, 10) : null;
    const escalationText = metadata.rent_escalations || metadata.escalation || null;
    // Only proceed if we have SOME escalation signal
    if (bumpPct || escalationText) {
      // Find the active lease we just created/updated
      const activeLease = await domainQuery(domain, 'GET',
        `leases?property_id=eq.${propertyId}&is_active=eq.true` +
        `&select=lease_id,annual_rent,lease_start,lease_expiration&limit=1`
      );
      const lease = activeLease.ok && activeLease.data?.length ? activeLease.data[0] : null;
      if (lease) {
        // Check if escalation already exists for this lease from OM/sidebar
        const existEsc = await domainQuery(domain, 'GET',
          `lease_escalations?lease_id=eq.${lease.lease_id}` +
          `&escalation_type=eq.percentage&select=escalation_id&limit=1`
        );
        if (!existEsc.ok || !existEsc.data?.length) {
          const escData = stripNulls({
            lease_id:                      lease.lease_id,
            property_id:                   parseInt(propertyId, 10),
            escalation_type:               'percentage',
            escalation_value:              bumpPct || null,
            // annualized_escalation_percent is a GENERATED column — do not write it
            escalation_frequency_years:    bumpIntervalMo ? bumpIntervalMo / 12 : 1,
            rent_amount:                   lease.annual_rent ? Number(lease.annual_rent) : null,
            effective_date:                lease.lease_start || null,
            start_date:                    lease.lease_start || null,
            end_date:                      lease.lease_expiration || null,
            raw_escalation_text:           escalationText,
          });
          const escResult = await domainQuery(domain, 'POST', 'lease_escalations', escData);
          if (escResult.ok) {
            console.log(`[upsertDomainLeases] Created escalation for lease ${lease.lease_id}: ${bumpPct}% every ${bumpIntervalMo || 12}mo`);
          } else {
            console.error(`[upsertDomainLeases] Failed to create escalation:`, escResult.status, escResult.data);
          }
        }
      }
    }
  }

  return count;
}

// ── Step 5e-ii: Upsert lease_escalations (CoStar rent band) ───────────────

/**
 * Parse CoStar estimated rent range (e.g. "$24 - 29/NNN (Office)") and
 * write a lease_escalations row capturing the rent band.
 * Skips if the lease already has a costar_sidebar escalation row.
 */
async function upsertLeaseEscalations(propertyId, leaseId, metadata) {
  const estRent = metadata.est_rent;
  if (!estRent) return 0;

  // Parse "$24 - 29/NNN" → low: 24, high: 29, structure: NNN
  const match = estRent.match(/\$?([\d.]+)\s*[-–]\s*([\d.]+)\s*\/([\w\s]+)/);
  if (!match) return 0;

  const rentLow     = parseFloat(match[1]);
  const rentHigh    = parseFloat(match[2]);
  const structure   = match[3].trim().split(' ')[0]; // "NNN", "FS", "MG"
  const midpoint    = Math.round((rentLow + rentHigh) / 2 * 100) / 100;

  // Check if already have an escalation row for this lease from sidebar
  const existing = await domainQuery('dialysis', 'GET',
    `lease_escalations?lease_id=eq.${leaseId}&data_source=eq.costar_sidebar&select=id&limit=1`
  );
  if (existing.ok && existing.data?.length) return 0;

  const r = await domainQuery('dialysis', 'POST', 'lease_escalations', {
    lease_id:           leaseId,
    property_id:        parseInt(propertyId, 10),
    rent_low_psf:       rentLow,
    rent_high_psf:      rentHigh,
    rent_estimate_psf:  midpoint,
    expense_structure:  structure,
    escalation_source:  'costar_estimate',
    data_source:        'costar_sidebar',
    effective_date:     new Date().toISOString().split('T')[0],
  });
  return r.ok ? 1 : 0;
}

// ── Step 5f: Upsert available_listings ─────────────────────────────────────

/**
 * Upsert a listing record in the dialysis available_listings table.
 * Trigger: only writes if metadata.asking_price is present OR any
 *          sales_history entry has is_current: true.
 * Dedup: property_id + is_active=true — one active listing per property.
 *        If one already exists, PATCH price/cap_rate; otherwise INSERT.
 * Returns 1 if a record was created or updated, 0 if skipped.
 */
async function upsertDialysisListings(propertyId, metadata) {
  // Trigger guard — check parsed value, not raw metadata string.
  // If metadata.asking_price is undefined (e.g. stripped by buildMetadata),
  // the raw-string guard would silently return 0 even when a current sale
  // exists, so parse first and also evaluate any current sales_history rows.
  let parsedAskingPrice = parseCurrency(metadata.asking_price);
  const currentListings = Array.isArray(metadata.sales_history)
    ? metadata.sales_history.filter(s => s.is_current === true)
    : [];

  // Round 76dv: when the capture URL is a CoStar /for-sale/ listing page and
  // metadata.asking_price is empty but metadata.sale_price has a real value,
  // treat sale_price AS the asking price. The page uses "For Sale" / "Sale
  // Price" labels instead of "Asking Price" so the extractor's older regex
  // missed it. Validation: sale_price must be >= $1,000 AND there must NOT
  // already be a closed sale of that price in sales_history (which would
  // mean it's a historical sold price, not the current asking).
  const sourceUrl = String(metadata.page_url || metadata.url || '');
  const onForSaleUrl = /\/detail\/for-sale\//i.test(sourceUrl);
  if (!parsedAskingPrice) {
    const sp = parseCurrency(metadata.sale_price);
    if (onForSaleUrl && sp && sp >= 1000) {
      const matchesClosedSale = (metadata.sales_history || []).some(s =>
        s && parseCurrency(s.sale_price) === sp && s.is_current !== true);
      if (!matchesClosedSale) {
        console.log(`[upsertDialysisListings] inferred asking_price=${sp} from sale_price on /for-sale/ URL`);
        metadata.asking_price = metadata.sale_price;
        parsedAskingPrice = sp;
      }
    }
  }

  // Round 77c (2026-06-02): reject implausibly-low asking prices. A real
  // net-lease / CRE asset never lists below ~$50k; such values are parser leaks
  // — RBA/SF (e.g. 9,972), price-per-SF ($1,410), historical easements
  // ($18,500), or $1 placeholders — bleeding into the price field. Drop to null
  // so the listing is created WITHOUT a bogus price (a price-less Active row via
  // the /for-sale/ path below) instead of carrying garbage into the supply-side
  // cap-rate / price metrics. Layout-independent backstop to the parser-side
  // "Not Disclosed" guard in extension/content/costar.js.
  const ASKING_PRICE_FLOOR = 50000;
  if (parsedAskingPrice != null && parsedAskingPrice < ASKING_PRICE_FLOOR) {
    console.warn('[upsertDialysisListings] Round 77c: dropping implausibly-low asking_price (likely SF/per-SF/easement leak)', {
      propertyId,
      rejected_asking_price: parsedAskingPrice,
      raw_asking_price: metadata.asking_price,
    });
    parsedAskingPrice = null;
    metadata.asking_price = null;
  }

  if (!parsedAskingPrice && !currentListings.length && !onForSaleUrl) {
    console.log('[upsertDialysisListings] early-exit: no asking_price, no current sale, not a for-sale listing page', {
      propertyId,
      raw_asking_price: metadata.asking_price,
      parsed_asking_price: parsedAskingPrice,
      sales_history_count: Array.isArray(metadata.sales_history) ? metadata.sales_history.length : 0,
      source_url: sourceUrl || null,
    });
    // Item #1: every return path uses { count, insertedListingId } shape.
    return { count: 0, insertedListingId: null };
  }

  // Round 77b (2026-06-02): a CoStar /for-sale/ page is itself authoritative
  // evidence the property is actively on the market, even when the price reads
  // "Not Disclosed". Dialysis is full of price-on-request listings; dropping
  // them at the guard above made genuinely-active listings invisible to the
  // supply-side Capital Markets charts (Market Turnover / Inventory Backlog /
  // Available Market Size, which count by listing_date, not price). Proceed to
  // create a price-less Active row — initial_price/last_price stay null
  // (stripNulls drops them), but the derived listing_date + DOM still flow into
  // the charts; cap-rate metrics simply skip the null. Only the explicit
  // /for-sale/ URL qualifies — a property captured from a non-listing page
  // still early-exits above.
  if (!parsedAskingPrice && !currentListings.length) {
    console.log('[upsertDialysisListings] Round 77b: price-undisclosed /for-sale/ listing — creating price-less Active row', {
      propertyId,
      source_url: sourceUrl,
    });
  }

  try {

  const contacts = metadata.contacts || [];
  const sellerContact = contacts.find(c => c.role === 'owner' || c.role === 'seller') || null;

  // Priority 1: OM-extracted listing broker fields (specific to current listing)
  // Priority 2: contacts array (may contain historical brokers from all sales)
  let primaryBroker = null;
  if (metadata.listing_broker) {
    primaryBroker = {
      name: metadata.listing_broker,
      email: metadata.listing_email || null,
    };
  } else {
    // Fallback: search contacts for listing_broker / buyer_broker
    const brokerContacts = contacts.filter(
      c => c.role === 'listing_broker' || c.role === 'buyer_broker'
    );
    const FIRM_PATTERN = /\b(LLC|INC|CORP|LTD|LP|LLP|PARTNERS|GROUP|ASSOCIATES|ADVISORS|REALTY|PROPERTIES|CAPITAL|INVESTMENTS|COMMERCIAL|RETAIL|&)\b/i;
    const personBroker = brokerContacts.find(
      c => !FIRM_PATTERN.test(c.name) && (c.email || c.phones?.length)
    );
    const firmBroker = brokerContacts.find(c => FIRM_PATTERN.test(c.name));
    primaryBroker = personBroker || firmBroker || brokerContacts[0] || null;
  }

  // Guard: reject price_per_sf under $50 (cap rate leak) or over $2000
  // (CoStar sometimes shows building SF in the Price/SF position)
  const rawPricePsf = parseCurrency(metadata.price_per_sf);
  const pricePsf = (rawPricePsf && rawPricePsf >= 50 && rawPricePsf <= 2000)
    ? rawPricePsf : null;
  // Fallback: compute from asking_price / square_footage when raw value is bad
  const computedPricePsf = (!pricePsf && parseCurrency(metadata.asking_price)
    && parseSF(metadata.square_footage))
    ? Math.round(parseCurrency(metadata.asking_price) / parseSF(metadata.square_footage) * 100) / 100
    : null;
  const safePricePsf = pricePsf || computedPricePsf || null;

  // Dialysis available_listings.property_id is an integer column; PostgREST
  // will reject a numeric-string with a silent 400. Cast once here and reuse.
  const propertyIdInt = parseInt(propertyId, 10);

  // Listing cap rate — sourced ONLY from the CoStar listing cap rate field
  // (the one tied to the current asking price). Must never be derived from
  // a historical sale's calculated_cap_rate or sold_cap_rate. Named
  // distinctly from the sales-context capRate/cap_rate to keep the source
  // unambiguous in code review.
  const listingCapRate = parseCapRateDecimal(metadata.cap_rate);

  // Round 76cw+ Phase 2 / Round 76en INSERT-side mirror (2026-04-29):
  // when there's no existing listing to compare against, we can't use
  // the existing-vs-new check from the PATCH path. Instead, run a
  // first-pass historical-sale check on the new value alone: if the
  // proposed asking_price matches any sales_history price within 5% AND
  // sales_history shows a sale that is at least 5 years old, treat the
  // captured price as suspect and INSERT without it. The listing row
  // still gets created with cap rate / broker / SF — the user can fix
  // the price via the sidebar Update flow once they verify.
  // Tunable: 5% match window + 5-year-old sale threshold. Stricter than
  // the PATCH-side check because we have less context to lean on.
  const newInsertAsking = parseCurrency(metadata.asking_price);
  let insertAskingSuppressed = false;
  if (newInsertAsking) {
    const histSales = Array.isArray(metadata.sales_history) ? metadata.sales_history : [];
    const fiveYearsAgo = Date.now() - 5 * 365 * 86400 * 1000;
    const matchedOldSale = histSales.find(s => {
      const sp = parseCurrency(s && s.sale_price);
      if (!sp || sp <= 0) return false;
      if (Math.abs(sp - newInsertAsking) / sp > 0.05) return false;
      const sd = s && s.sale_date ? Date.parse(s.sale_date) : null;
      return Number.isFinite(sd) && sd <= fiveYearsAgo;
    });
    if (matchedOldSale) {
      insertAskingSuppressed = true;
      console.warn('[upsertDialysisListings] Round 76cw+ Phase 2: suppressed INSERT asking_price — value matches a sale older than 5 years within 5%', {
        property_id: propertyIdInt,
        rejected_asking_price: newInsertAsking,
        matched_sale_date: matchedOldSale.sale_date,
        matched_sale_price: matchedOldSale.sale_price,
      });
    }
  }

  // Round 77 (2026-06-02): derive listing_date from CoStar's real on-market
  // signal instead of stamping the capture date — see deriveListingDate().
  const { listing_date: derivedListingDate, source: listingDateSource } =
    deriveListingDate(metadata);

  // Round 68-A (Task 1): persist WHERE the date came from so the 2025-hole
  // class never silently re-forms. CoStar's "Date on Market" -> 'costar_date_on_
  // market'; a DOM-subtracted date -> 'costar_days_on_market'; a bare capture
  // date stays NULL (origin = capture, unknown true marketing start).
  const listingDateSourceTag =
    listingDateSource === 'on_market_date' ? 'costar_date_on_market' :
    listingDateSource === 'days_on_market' ? 'costar_days_on_market' :
    null;

  // T4c (2026-06-24): on_market_date provenance — the TIMING truth the charts
  // read, from CoStar's real on-market signal (never the capture clock). HELD
  // (null) when CoStar carried no date/DOM → excluded from the timing series.
  const om = deriveOnMarketDate(metadata);

  const record = stripNulls({
    property_id: propertyIdInt,
    initial_price: insertAskingSuppressed ? null : newInsertAsking,
    last_price:    insertAskingSuppressed ? null : newInsertAsking,
    current_cap_rate: listingCapRate,
    cap_rate: listingCapRate,
    listing_date: derivedListingDate,
    listing_date_source: listingDateSourceTag,
    on_market_date: om.on_market_date,
    on_market_date_source: om.source,
    on_market_date_confidence: om.confidence,
    status: 'Active',
    is_active: true,
    seller_name: cleanSalesPartyValue(sellerContact?.name),
    listing_broker: primaryBroker?.name || null,
    broker_email: primaryBroker?.email || null,
    price_per_sf: insertAskingSuppressed ? null : safePricePsf,
  });

  console.log('[upsertDialysisListings] building record:', {
    propertyId: propertyIdInt,
    asking_price_raw: metadata.asking_price,
    asking_price_parsed: parseCurrency(metadata.asking_price),
    cap_rate_raw: metadata.cap_rate,
    cap_rate_parsed: listingCapRate,
    broker: primaryBroker?.name || '(none)',
    seller: sellerContact?.name || '(none)',
    listing_date: derivedListingDate,
    listing_date_source: listingDateSource,
    costar_on_market_raw: metadata.listing_date ?? null,
    costar_days_on_market_raw: metadata.days_on_market ?? null,
    record_keys: Object.keys(record),
  });

  // Always keep property_id, status, and is_active even after stripNulls
  record.property_id = propertyIdInt;
  record.status = 'Active';
  record.is_active = true;

  // Dedup: an existing active listing whose listing_date is within 90 days
  // of now represents the SAME listing campaign — PATCH it in place. An
  // older active listing (>90 days) is a separate prior campaign for the
  // same property; we leave it alone and INSERT a new row for the new
  // campaign (avoids collapsing distinct campaigns into a single listing
  // record that then gets associated with multiple sales).
  const ingestionDatePart = new Date().toISOString().split('T')[0];
  const ninetyDaysAgoPart = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000)
    .toISOString().split('T')[0];
  const lookup = await domainQuery('dialysis', 'GET',
    `available_listings?property_id=eq.${propertyIdInt}` +
    `&is_active=is.true` +
    `&listing_date=gte.${ninetyDaysAgoPart}` +
    `&select=listing_id,listing_date` +
    `&order=listing_date.desc.nullslast&limit=1`
  );

  let currentListingId = null;

  console.log('[upsertDialysisListings] dedup lookup:', {
    propertyId: propertyIdInt,
    lookup_ok: lookup.ok,
    lookup_status: lookup.status,
    lookup_count: lookup.data?.length || 0,
    ninetyDaysAgo: ninetyDaysAgoPart,
  });

  if (lookup.ok && lookup.data?.length) {
    // Update price and cap rate on the in-window active listing. listingCapRate
    // comes only from metadata.cap_rate (the CoStar listing's asking cap
    // rate); never from a sale-derived calculated/sold cap rate.
    currentListingId = lookup.data[0].listing_id;

    // Round 76en (2026-04-29): historical-sale-price overwrite guard.
    // 6606 Stadium Dr in Zephyrhills FL surfaced a case where the CoStar
    // capture extracted $445K as the current asking price for a 7,200 SF
    // medical office (= $61.80/SF, implausibly cheap). The existing LCC
    // entity correctly had $3.2M ($444/SF — typical). The $445K was
    // suspiciously close to a 2014 historical sale of $450K visible in
    // the page's Sales History block, suggesting the parser grabbed a
    // historical price value into the asking-price slot.
    //
    // Defense: refuse to overwrite the price field when the new asking
    // price looks like a historical sale price that's leaking into the
    // current-listing slot. Two trip-wires fire INDEPENDENTLY (Round 76eu-D,
    // 2026-04-29):
    //
    // Path A — order-of-magnitude drop (Round 76en original):
    //   new < 75% of existing AND within 5% of any historical sale.
    //   Catches the obvious cases like 6606 Stadium Dr where $445K (14% of
    //   $3.2M) matched a 2014 sale of $450K. Threshold loosened from 60% to
    //   75% after 5 Route 45 case where 61.1% just barely escaped.
    //
    // Path B — exact match to OLD sale (Round 76eu-D new):
    //   new is within 2% of any sales_history entry that is ≥2 years old,
    //   regardless of price-drop ratio. Catches cases like 5 Route 45 where
    //   a 2018 sale of exactly $2,750,000 was overwriting a current
    //   $4,500,000 listing — drop ratio was 61% (above Path A's threshold)
    //   but the exact-match-to-old-sale signal is independently strong.
    //
    // Either path triggers suppression. We still PATCH cap_rate, broker,
    // etc. — only the suspicious price is held back.
    let askingPriceSuppressed = false;
    let suppressionReason = null;
    const newAskingPrice = parseCurrency(metadata.asking_price);
    const existingLastPrice = (() => {
      const raw = lookup.data[0].last_price;
      const n = raw == null ? null : Number(raw);
      return Number.isFinite(n) && n > 0 ? n : null;
    })();
    const histSales = Array.isArray(metadata.sales_history) ? metadata.sales_history : [];

    // Path A — substantial drop AND historical-match (any age)
    if (!askingPriceSuppressed && newAskingPrice && existingLastPrice
        && newAskingPrice < existingLastPrice * 0.75) {
      const matchedHistorical = histSales.some(s => {
        const sp = parseCurrency(s && s.sale_price);
        if (!sp || sp <= 0) return false;
        return Math.abs(sp - newAskingPrice) / sp <= 0.05;
      });
      if (matchedHistorical) {
        askingPriceSuppressed = true;
        suppressionReason = 'price_drop_with_historical_match';
      }
    }

    // Path B — exact match to a sale ≥2 years old (regardless of drop ratio)
    if (!askingPriceSuppressed && newAskingPrice) {
      const twoYearsAgo = Date.now() - 2 * 365 * 86400 * 1000;
      const matchedOldSale = histSales.find(s => {
        const sp = parseCurrency(s && s.sale_price);
        if (!sp || sp <= 0) return false;
        if (Math.abs(sp - newAskingPrice) / sp > 0.02) return false;
        const sd = s && s.sale_date ? Date.parse(s.sale_date) : null;
        return Number.isFinite(sd) && sd <= twoYearsAgo;
      });
      if (matchedOldSale) {
        askingPriceSuppressed = true;
        suppressionReason = 'exact_match_to_old_sale';
      }
    }

    if (askingPriceSuppressed) {
      console.warn(`[upsertDialysisListings] Round 76eu-D: suppressed asking_price overwrite — ${suppressionReason}`, {
        listing_id: currentListingId,
        property_id: propertyIdInt,
        existing_last_price: existingLastPrice,
        rejected_asking_price: newAskingPrice,
        sales_history_prices: histSales
          .map(s => ({ price: parseCurrency(s && s.sale_price), date: s && s.sale_date }))
          .filter(s => s.price > 0),
      });
    }

    const patchData = stripNulls({
      last_price: askingPriceSuppressed ? null : newAskingPrice,
      current_cap_rate: listingCapRate,
      cap_rate: listingCapRate,
      price_per_sf: askingPriceSuppressed ? null : safePricePsf,
    });
    // Also update broker fields if currently empty
    if (primaryBroker?.name)  patchData.listing_broker = primaryBroker.name;
    if (primaryBroker?.email) patchData.broker_email   = primaryBroker.email;
    await domainPatch('dialysis',
      `available_listings?listing_id=eq.${currentListingId}`,
      patchData, 'upsertDialysisListings'
    );
    await backfillListingSaleIdForListing('dialysis', {
      listingId: currentListingId,
      propertyId: propertyIdInt,
      listingDate: lookup.data[0].listing_date || ingestionDatePart,
    });
    // Item #1: PATCH path = UPDATE on existing in-window listing. NOT a new
    // listing for BD purposes — insertedListingId stays null so the caller
    // does not re-fire runListingBdPipeline on every re-capture.
    return { count: 1, insertedListingId: null };
  }

  console.log('[upsertDialysisListings] attempting INSERT for property', propertyIdInt);
  const result = await domainQuery('dialysis', 'POST', 'available_listings', record);
  console.log('[upsertDialysisListings] INSERT result:', {
    propertyId: propertyIdInt,
    ok: result.ok,
    status: result.status,
    data_type: typeof result.data,
    data_preview: JSON.stringify(result.data)?.slice(0, 200),
  });
  if (!result.ok) {
    console.error('[upsertDialysisListings] INSERT failed:', {
      propertyId: propertyIdInt,
      status: result.status,
      data: result.data,
      record,
    });
    return { count: 0, insertedListingId: null };
  }

  // Recover the new listing_id from the insert response (PostgREST returns
  // the row when Prefer: return=representation is set — domainQuery sets it
  // for POSTs). Fall back to a property_id lookup if unavailable.
  if (Array.isArray(result.data) && result.data.length && result.data[0].listing_id != null) {
    currentListingId = result.data[0].listing_id;
  } else if (result.data?.listing_id != null) {
    currentListingId = result.data.listing_id;
  } else {
    const idLookup = await domainQuery('dialysis', 'GET',
      `available_listings?property_id=eq.${propertyIdInt}` +
      `&is_active=is.true&select=listing_id&order=listing_date.desc.nullslast&limit=1`
    );
    currentListingId = idLookup.ok && idLookup.data?.[0]?.listing_id || null;
  }

  if (currentListingId != null) {
    await backfillListingSaleIdForListing('dialysis', {
      listingId: currentListingId,
      propertyId: propertyIdInt,
      listingDate: record.listing_date || ingestionDatePart,
    });
  }

  // Post-insert check: if a closed sale already exists for this property
  // within the last 2 years, immediately close the listing so we don't
  // treat it as a new active listing.
  const twoYearsAgo = new Date(Date.now() - 2 * 365 * 24 * 60 * 60 * 1000)
    .toISOString().split('T')[0];
  const recentSales = await domainQuery('dialysis', 'GET',
    `sales_transactions?property_id=eq.${propertyIdInt}` +
    `&sale_date=gte.${twoYearsAgo}&select=sale_id,sale_date,sold_price` +
    `&order=sale_date.desc&limit=1`
  );

  if (recentSales.ok && recentSales.data?.length) {
    const latestSale = recentSales.data[0];
    const latestSalePrice = parseCurrency(latestSale.sold_price);
    const latestSaleId = Number.isFinite(Number(latestSale.sale_id))
      && Number(latestSale.sale_id) > 0
        ? Number(latestSale.sale_id) : null;
    // Do NOT copy any sale-derived cap rate into available_listings here.
    // The listing's cap_rate / current_cap_rate columns must only ever
    // reflect the CoStar listing's asking cap rate (listingCapRate above);
    // leaking a sales_transactions cap rate into them was the root cause
    // of the cap-rate-leak bug this branch fixes.
    // Scope the close to the listing we just inserted (not every active
    // listing for the property) — older campaigns stay open per the 3-year
    // rule in closeActiveListingsOnSale.
    //
    // Bulk-close FK linkage: populate sale_transaction_id + sold_price so
    // the closed listing resolves to the specific sales_transactions row
    // that closed it (matched by property_id + closest sale_date above, via
    // the sale_date.desc limit=1 lookup). See available_listings_sale_fk
    // migration.
    const closeFilter = currentListingId != null
      ? `listing_id=eq.${currentListingId}`
      : `property_id=eq.${propertyIdInt}&is_active=is.true`;
    const patch = {
      is_active: false,
      status: 'Sold',
      off_market_date: latestSale.sale_date,
      last_price: latestSalePrice || null,
    };
    if (latestSaleId != null) patch.sale_transaction_id = latestSaleId;
    if (latestSalePrice != null) patch.sold_price = latestSalePrice;
    await domainPatch('dialysis',
      `available_listings?${closeFilter}`,
      patch,
      'upsertDialysisListings:autoClose'
    );
    console.log(
      `[listing-fk-backfill] auto-close property_id=${propertyIdInt} ` +
      `sale_transaction_id=${latestSaleId ?? 'null'} ` +
      `sold_price=${latestSalePrice ?? 'null'} sale_date=${latestSale.sale_date}`
    );
    // Already auto-closed as sold — not a genuinely-new active listing.
    return { count: 0, insertedListingId: null };
  }
  // Item #1: genuine new INSERT (not auto-closed). Surface listing_id so
  // propagateToDomainDbDirect can fire runListingBdPipeline.
  return { count: 1, insertedListingId: currentListingId };

  } catch (err) {
    console.error('[upsertDialysisListings] unexpected error:', {
      propertyId,
      error: err?.message || err,
      stack: err?.stack?.slice(0, 300),
    });
    return { count: 0, insertedListingId: null };
  }
}

/**
 * Upsert a listing record in the government available_listings table.
 * Trigger: only writes if metadata.asking_price is present OR any
 *          sales_history entry has is_current: true.
 * Dedup: finds ANY existing listing for the property (not just Active).
 *        If Active exists, PATCH it. If non-Active (under_contract/sold/etc),
 *        create a new Active listing. If none exist, INSERT.
 */
async function upsertGovListings(propertyId, entity, metadata) {
  // Trigger guard
  const hasAskingPrice = !!metadata.asking_price;
  const hasCurrentSale = Array.isArray(metadata.sales_history)
    && metadata.sales_history.some(s => s.is_current === true);
  if (!hasAskingPrice && !hasCurrentSale) return { count: 0, insertedListingId: null };

  // Derive listing_date from the most recent is_current sale, else today
  let listingDate = new Date().toISOString().split('T')[0];
  let currentSaleDatePart = null;
  if (Array.isArray(metadata.sales_history)) {
    const currentSale = metadata.sales_history.find(s => s.is_current === true);
    if (currentSale?.sale_date) {
      const parsed = parseDate(currentSale.sale_date);
      if (parsed) { listingDate = parsed.split('T')[0]; currentSaleDatePart = listingDate; }
    }
  }
  // T4c (2026-06-24): on_market_date is the TIMING truth (charts read it),
  // sourced ONLY from evidence — never the `today` fallback above. Prefer
  // CoStar's on-market/DOM signal; else the current-sale anchor; else HELD
  // (null) → excluded from the added-per-month + DOM series.
  const om0 = deriveOnMarketDate(metadata);
  const om = om0.on_market_date
    ? om0
    : (currentSaleDatePart
        ? { on_market_date: currentSaleDatePart, source: 'sale_anchor', confidence: 'low' }
        : om0);

  // Find broker / seller contacts
  const contacts = metadata.contacts || [];
  const brokerContact = contacts.find(c => c.role === 'listing_broker') || null;
  const sellerContact = contacts.find(c => c.role === 'owner' || c.role === 'seller') || null;

  // Compute firm_term_remaining from lease_expiration
  let firmTermRemaining = null;
  const leaseExp = parseDate(metadata.lease_expiration);
  if (leaseExp) {
    const diffMs = new Date(leaseExp).getTime() - Date.now();
    if (diffMs > 0) {
      firmTermRemaining = Math.round((diffMs / (365.25 * 24 * 60 * 60 * 1000)) * 10) / 10;
    }
  }

  const sfInt = parseSF(metadata.square_footage);

  // Guard: reject price_per_sf under $50 (cap rate leak) or over $2000
  // (CoStar sometimes shows building SF in the Price/SF position)
  const rawGovPricePsf = parseCurrency(metadata.price_per_sf);
  const govPricePsf = (rawGovPricePsf && rawGovPricePsf >= 50 && rawGovPricePsf <= 2000)
    ? rawGovPricePsf : null;
  const computedGovPricePsf = (!govPricePsf && parseCurrency(metadata.asking_price) && sfInt)
    ? Math.round(parseCurrency(metadata.asking_price) / sfInt * 100) / 100
    : null;
  const safeGovPricePsf = govPricePsf || computedGovPricePsf || null;

  // Guard against section-header noise captured as tenant names (e.g. "Buyer")
  const INVALID_TENANT = /^(public\s+record|building|building\s+info|land|market|market\s+data|sources|assessment|investment|not\s+disclosed|none|vacant|available|owner.occupied|confirmed|verified|research|buyer|seller|contacts|name|sf\s+occupied|analytics|reports|data|directory|stacking\s+plan|leasing|for\s+lease|for\s+sale|property\s+info|demographics|transit|walk\s+score)$/i;
  const tenantAgency = [
    metadata.tenants?.[0]?.name,
    metadata.tenant_name,
    metadata.primary_tenant,
  ].find(t => t && t.length > 2 && !INVALID_TENANT.test(t)) || null;

  // Listing cap rate — sourced ONLY from the CoStar listing cap rate field
  // (the one tied to the current asking price). Must never be derived from
  // a historical sale's sold_cap_rate or calculated_cap_rate. Named
  // distinctly from the sales-context capRate to keep the source
  // unambiguous in code review.
  const listingCapRate = parseCapRateDecimal(metadata.cap_rate);

  const record = stripNulls({
    property_id: propertyId,
    listing_source: 'costar_sidebar',
    address: entity.address || null,
    city: entity.city || null,
    state: entity.state || null,
    square_feet: sfInt != null ? Math.round(sfInt) : null,
    asking_price: parseCurrency(metadata.asking_price),
    asking_cap_rate: listingCapRate,
    asking_price_psf: safeGovPricePsf,
    listing_date: listingDate,
    on_market_date: om.on_market_date,
    on_market_date_source: om.source,
    on_market_date_confidence: om.confidence,
    listing_status: 'Active',
    days_on_market: parseIntSafe(metadata.days_on_market),
    tenant_agency: tenantAgency,
    annual_rent: parseCurrency(metadata.annual_rent),
    lease_expiration: parseDate(metadata.lease_expiration)?.split('T')[0] || null,
    firm_term_remaining: firmTermRemaining,
    listing_broker: brokerContact?.name || null,
    listing_firm: brokerContact?.company || null,
    broker_phone: brokerContact?.phones?.[0] || null,
    broker_email: brokerContact?.email || null,
    seller_name: cleanSalesPartyValue(sellerContact?.name),
  });

  // Always keep property_id and listing_status even after stripNulls
  record.property_id = propertyId;
  record.listing_status = 'Active';

  // Dedup: the 2026-04-23 migration adds a partial unique index on
  // (property_id, listing_source, listing_status, listing_date). Use
  // PostgREST's resolution=merge-duplicates so re-scraping the same CoStar
  // page updates the existing row instead of inserting a fresh one. This
  // replaces the old "find latest, decide INSERT vs PATCH" logic that
  // produced 3-Sold-row groups when the auto-close PATCH below flipped the
  // prior row to Sold between consecutive sidebar hits.
  //
  // When a prior Active row exists for this property with an OLDER
  // listing_date, we still want to update *that* one (the user's re-scrape
  // is the same listing even if CoStar changed the listing_date). So we do
  // a single pre-check looking for an Active row on the same property and,
  // if found, PATCH it. Otherwise we upsert via on_conflict.
  // Property-first (Round 76 listing-lifecycle): converge onto ANY active row
  // for this property regardless of source, so a CoStar re-scrape updates the
  // existing iteration (including an OM-sourced one) instead of minting a
  // parallel active row. Was scoped to costar_sidebar+Active, which let a
  // sidebar capture sit beside an lcc_intake_om active row. is_active is
  // GENERATED from listing_status — query it directly.
  const activeLookup = await domainQuery('government', 'GET',
    `available_listings?property_id=eq.${propertyId}` +
    `&is_active=eq.true` +
    `&select=listing_id&order=listing_date.desc.nullslast&limit=1`
  );
  if (activeLookup.ok && activeLookup.data?.length) {
    const existingId = activeLookup.data[0].listing_id;
    const { property_id: _pid, ...patchData } = record;
    await domainPatch('government',
      `available_listings?listing_id=eq.${existingId}`,
      patchData, 'upsertGovListings:updateActive'
    );
    // Fall through to the auto-close-on-sale check below so a fresh sale
    // still flips this row to Sold in one round of work.
    var _existingActiveId = existingId;  // eslint-disable-line no-var
  }

  // Upsert using the compound unique index. If no Active row matched above,
  // this INSERTs; otherwise the PATCH above already ran and this becomes a
  // no-op conflict-merge against the row we just updated.
  const result = !(typeof _existingActiveId !== 'undefined' && _existingActiveId)
    ? await domainQuery('government', 'POST',
        'available_listings?on_conflict=property_id,listing_source,listing_status,listing_date',
        record,
        { Prefer: 'return=representation,resolution=merge-duplicates' }
      )
    : { ok: true };
  if (!result.ok) return { count: 0, insertedListingId: null };

  // Post-insert check: if a closed sale already exists for this property
  // within the last 2 years, immediately close the listing so we don't
  // treat it as a new active listing. The close_listing_on_sale trigger
  // fires on sale INSERT, but the pipeline creates the listing AFTER the
  // sale, so the trigger finds no active listing to close.
  const twoYearsAgo = new Date(Date.now() - 2 * 365 * 24 * 60 * 60 * 1000)
    .toISOString().split('T')[0];
  const recentSales = await domainQuery('government', 'GET',
    `sales_transactions?property_id=eq.${propertyId}` +
    `&sale_date=gte.${twoYearsAgo}&select=sale_id,sale_date,sold_price` +
    `&order=sale_date.desc&limit=1`
  );

  if (recentSales.ok && recentSales.data?.length) {
    const latestSale = recentSales.data[0];
    // Do NOT copy any sale-derived cap rate (sold_cap_rate /
    // calculated_cap_rate) into available_listings.asking_cap_rate here.
    // asking_cap_rate must only ever reflect the CoStar listing's asking
    // cap rate (listingCapRate above); leaking a sales_transactions cap
    // rate into it was the root cause of the cap-rate-leak bug this
    // branch fixes.
    await domainPatch('government',
      `available_listings?property_id=eq.${propertyId}&listing_status=eq.Active`,
      {
        listing_status:  'Sold',
        off_market_date: latestSale.sale_date,
        updated_at:      new Date().toISOString(),
      },
      'upsertGovListings:autoClose'
    );
    // Already auto-closed as sold — not a genuinely-new active listing.
    return { count: 0, insertedListingId: null };
  }
  // Item #1: discriminate true INSERT vs PATCH-of-existing-Active.
  //   wasInsert == true  → no prior Active row was found at the top of the
  //                        function; the upsert just created a new row.
  //   wasInsert == false → an existing Active row was PATCHed in place
  //                        above (activeLookup branch); do NOT re-fire BD.
  // Rare same-day on_conflict merge case (property + source + status +
  // listing_date all identical) is an accepted false-positive: it queues
  // T-011/T-012 candidates again, which Scott can delete. Worth keeping
  // the gate simple and predictable.
  const wasInsert = !(typeof _existingActiveId !== 'undefined' && _existingActiveId);
  let insertedListingId = null;
  if (wasInsert) {
    if (Array.isArray(result.data) && result.data.length && result.data[0].listing_id != null) {
      insertedListingId = result.data[0].listing_id;
    } else if (result.data?.listing_id != null) {
      insertedListingId = result.data.listing_id;
    } else {
      // Fallback when PostgREST didn't return representation.
      const lookup = await domainQuery('government', 'GET',
        `available_listings?property_id=eq.${propertyId}` +
        `&listing_status=eq.Active&listing_source=eq.costar_sidebar` +
        `&select=listing_id&order=listing_id.desc&limit=1`
      );
      if (lookup.ok && lookup.data?.length) insertedListingId = lookup.data[0].listing_id;
    }
  }
  return { count: 1, insertedListingId };
}

// ── Main pipeline entry point ───────────────────────────────────────────────

/**
 * Process sidebar extraction metadata for a property entity.
 * This is the main entry point — called fire-and-forget after entity creation,
 * or on-demand via the process_sidebar_extraction action.
 *
 * @param {string} entityId - The property entity UUID
 * @param {string} workspaceId - Workspace UUID
 * @param {string} userId - Acting user UUID
 * @returns {object} Summary of what was processed
 */
export async function processSidebarExtraction(entityId, workspaceId, userId, opts = {}) {
  // Fetch the full entity
  const entityResult = await opsQuery('GET',
    `entities?id=eq.${entityId}&workspace_id=eq.${workspaceId}&select=*`
  );
  if (!entityResult.ok || !entityResult.data?.length) {
    return { ok: false, error: 'Entity not found' };
  }

  const entity = entityResult.data[0];
  const metadata = entity.metadata || {};

  // Only skip if not forced AND there's no actionable sidebar data to unpack.
  // Manual "Re-run Pipeline" always passes force:true so the user's explicit
  // action bypasses the hasSidebarData() gate.
  if (!opts.force && !hasSidebarData(metadata)) {
    return { ok: true, skipped: true, reason: 'No actionable sidebar data in metadata' };
  }

  // One-time audit of legacy null-sale_date rows in both domain DBs
  // (fire-and-forget; runs at most once per process lifetime).
  auditNullSaleDates().catch(err =>
    console.error('[null-sale-date-audit] unexpected error', err?.message || err)
  );

  // Step 1 — classify domain (needed for entity creation in steps 2-3).
  // classifyAndUpdateDomain still returns the PRIMARY domain for
  // entity.domain column / single-domain consumers; classifyAll-
  // ApplicableDomains returns the full set so multi-domain captures
  // (Centralia: dialysis + government) propagate to both DBs.
  const domain = await classifyAndUpdateDomain(entity, metadata, workspaceId);
  const allDomains = classifyAllApplicableDomains(metadata, entity);
  // Belt-and-suspenders: if the primary classifier picked something
  // (preserve-existing path), make sure it's in the list too.
  if (domain && !allDomains.includes(domain)) allDomains.unshift(domain);

  // Step 2 — Unpack contacts → entities + relationships
  const contactCount = await unpackContacts(entityId, metadata, workspaceId, userId, domain);

  // Step 2b — Unpack tenant → entity + lease relationship
  const tenantCount = await unpackTenant(entityId, metadata, workspaceId, userId, domain);

  // Step 3 — Unpack sales history → activity events + buyer/seller/lender entities
  const salesCount = await unpackSalesHistory(entityId, metadata, workspaceId, userId, domain);

  // Step 4 — Propagate to EVERY applicable domain database. Each
  // domain's writers filter metadata.tenants[] via isTenantForDomain
  // so dia.leases gets only DaVita+Assured and gov.leases gets only
  // SSA on the Centralia-style mixed-tenant capture. Single-domain
  // captures still hit exactly one domain and behave identically to
  // the prior single-call path.
  const perDomainResults = {};
  let firstError = null;
  let anyPropagated = false;
  let primaryPropagation = null;
  if (allDomains.length === 0) {
    primaryPropagation = await propagateToDomainDb(entity, metadata, null, { workspaceId, userId });
  } else {
    for (const dom of allDomains) {
      const r = await propagateToDomainDb(entity, metadata, dom, { workspaceId, userId });
      perDomainResults[dom] = r;
      if (r.propagated) anyPropagated = true;
      else if (!firstError) firstError = r;
      if (dom === domain || (!primaryPropagation && r.propagated)) {
        primaryPropagation = r;
      }
    }
    if (!primaryPropagation) primaryPropagation = firstError || { propagated: false, reason: 'no_domain' };
  }
  const propagation = anyPropagated
    ? {
        ...(primaryPropagation || {}),
        propagated: true,
        domains: allDomains,
        per_domain: perDomainResults,
      }
    : (primaryPropagation || { propagated: false, reason: 'no_domain', domains: allDomains, per_domain: perDomainResults });
  // Per-domain property_id map for downstream consumers that need to
  // join from the LCC entity into multiple domain DBs.
  const domainPropertyIds = {};
  for (const [d, r] of Object.entries(perDomainResults)) {
    if (r && r.property_id != null) domainPropertyIds[d] = String(r.property_id);
  }

  // Step 5 — Write signal for learning loop
  const totalContacts = contactCount + tenantCount;
  await writeExtractionSignal(entityId, metadata, domain, userId, totalContacts, salesCount);

  // Mark metadata as processed so we don't re-process
  // Only write _pipeline_processed_at when propagation succeeded — failed runs
  // remain retryable (hasSidebarData() will return true on the next save).
  // Round 76eo-B (2026-04-29): also lift propagation.property_id up to the
  // top-level metadata.domain_property_id slot. The 30-day audit found 76
  // entities where _pipeline_summary.domain_property_id was correctly set
  // but the top-level field stayed null, breaking downstream consumers
  // (lookup_asset, merge-log reconciler) that read the top-level field.
  // Without this lift, propagated entities looked unlinked to the rest of
  // the system.
  const updatedMeta = {
    ...metadata,
    ...(propagation.propagated
      ? {
          _pipeline_processed_at: new Date().toISOString(),
          _pipeline_status:       'success',
          // Round 76eo-B: promote the propagated property_id to the top-level
          // metadata slot, which downstream lookup paths key on.
          ...(propagation.property_id != null
              ? { domain_property_id: String(propagation.property_id) }
              : {}),
          // Round 76ej.x (2026-05-05): full per-domain map for multi-
          // domain captures. domain_property_id (singular) above stays
          // pointed at the PRIMARY domain for backward-compat
          // consumers.
          ...(Object.keys(domainPropertyIds).length > 0
              ? { domain_property_ids: domainPropertyIds }
              : {}),
        }
      : {
          _pipeline_status: 'failed',
          _pipeline_last_error: propagation.reason || 'unknown',
          _pipeline_last_error_detail: propagation.error || null,
          _pipeline_last_error_stack:  propagation.error_stack || null,
        }),
    _pipeline_summary: {
      contacts_created: contactCount,
      tenant_created: tenantCount,
      sales_recorded: salesCount,
      domain,
      // Round 76ej.x: full applicable-domain set + per-domain results.
      domains: allDomains,
      per_domain: perDomainResults,
      domain_property_ids: domainPropertyIds,
      domain_propagated: propagation.propagated || false,
      domain_property_id: propagation.property_id || null,
      domain_records: propagation.records || null,
      domain_records_note: 'writes_this_run_only — see domain_records_current for live DB state',
      domain_records_current: await fetchDomainRecordsCurrent(domain, propagation.property_id).catch(() => null),
      _classifier_diag: _lastClassifierDiag,
    },
  };
  await opsQuery('PATCH',
    `entities?id=eq.${entityId}&workspace_id=eq.${workspaceId}`,
    { metadata: updatedMeta, updated_at: new Date().toISOString() }
  );

  console.log(`[Sidebar pipeline] Done: entity=${entityId}, domain=${domain}, contacts=${totalContacts}, sales=${salesCount}, propagated=${propagation.propagated}`);

  return {
    ok: true,
    entity_id: entityId,
    domain,
    contacts_created: contactCount,
    tenant_created: tenantCount,
    sales_recorded: salesCount,
    domain_propagated: propagation.propagated || false,
    domain_property_id: propagation.property_id || null,
    domain_records: propagation.records || null,
    // Round 76cr-Phase 2: surface domain-mismatch warning at top level
    // so the sidebar UI can show a "looks misclassified — switch DB?"
    // banner without parsing the nested diagnostic.
    domain_mismatch_warning: (_lastClassifierDiag && _lastClassifierDiag.mismatchWarning) || null,
    _classifier_diag: _lastClassifierDiag,
    processed_at: new Date().toISOString(),
  };
}

/**
 * Check if an entity's metadata has sidebar extraction data that needs processing.
 * Used by entities-handler.js to gate the pipeline on inserts/updates.
 */
export function hasSidebarData(metadata) {
  if (!metadata) return false;
  if (metadata._pipeline_processed_at && metadata._pipeline_status !== 'failed') return false;
  return !!(
    metadata.contacts?.length ||
    metadata.sales_history?.length ||
    metadata.tenants?.length ||
    metadata.tenant_name ||
    metadata.primary_tenant ||
    metadata.asking_price ||
    metadata.square_footage ||
    metadata.cap_rate ||
    metadata.lease_expiration
  );
}
