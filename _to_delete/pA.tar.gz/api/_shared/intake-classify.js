// ============================================================================
// Intake classification — doctype normalization + deal/non-deal disposition
// Life Command Center
//
// Pure, dependency-free helpers shared by the extractor, the promoter, the
// create-from-intake handler, and the rematch/disposition worker. Kept in
// _shared (no DB imports) so it loads instantly in unit tests and can be
// imported from any layer without pulling the promoter's heavy graph.
//
// Single source of truth for:
//   - DOCTYPE_ALIASES / normalizeDocType   (was local to intake-promoter.js)
//   - LISTING_DOCUMENT_TYPES               (om / flyer / marketing_brochure)
//   - snapshotLooksLikeListing             (listing-grade heuristic)
//   - isNonDealSnapshot                    (auto-disposition classifier)
//   - hasFullDealSignature                 (guarded AUTO-create gate)
// ============================================================================

// Document types that represent on-market listing marketing. Full OMs,
// 1-page broker flyers, and marketing brochures all contain listing-grade
// data (address, tenant, price, cap rate, lease terms, broker) and populate
// available_listings identically. Comps and lease abstracts are deal-adjacent
// but not listings-of-record; they stay out of this set.
export const LISTING_DOCUMENT_TYPES = new Set([
  'om',
  'flyer',
  'marketing_brochure',
]);

// ── Doctype normalization (Bug Z fix, 2026-04-27) ────────────────────────
// The extractor returns document_type values that vary across AI providers
// and prompt versions: 'om', 'OM', 'offering_memorandum', 'offering memorandum',
// 'broker package', 'broker_package', 'flyer', 'marketing_flyer', etc.
// Normalize at the boundary so any variant of "OM" maps back to 'om', etc.
const DOCTYPE_ALIASES = {
  // OM variants
  'om':                    'om',
  'offering_memorandum':   'om',
  'offering memorandum':   'om',
  'offering-memorandum':   'om',
  'offering':              'om',
  'broker_package':        'om',
  'broker package':        'om',
  'investment_memorandum': 'om',
  'investment memorandum': 'om',
  // Flyer variants
  'flyer':                 'flyer',
  'broker_flyer':          'flyer',
  'broker flyer':          'flyer',
  'marketing_flyer':       'flyer',
  'marketing flyer':       'flyer',
  'one_pager':             'flyer',
  'one pager':             'flyer',
  'one-pager':             'flyer',
  // Brochure variants
  'marketing_brochure':    'marketing_brochure',
  'marketing brochure':    'marketing_brochure',
  'brochure':              'marketing_brochure',
};

/**
 * Normalize a document_type string to its canonical short form.
 * Returns the input (lower/trimmed) unchanged if no alias matches, so
 * non-listing types ('lease_abstract', 'rent_roll', 'unknown', 'comp', …)
 * flow through and are classified normally by the callers.
 */
export function normalizeDocType(dt) {
  if (!dt || typeof dt !== 'string') return dt;
  const key = dt.toLowerCase().trim();
  // Tolerate common typos / extra punctuation ("OFFERRING MEMORANDUM")
  const dedup = key.replace(/r{2,}/g, 'r').replace(/[.,]/g, '');
  return DOCTYPE_ALIASES[key] || DOCTYPE_ALIASES[dedup] || key;
}

/**
 * Heuristic: classify an extraction snapshot as listing-grade when
 * `document_type` is null/unknown but the snapshot carries the signals a
 * listing usually has (asking price + tenant + ≥1 of cap rate / building SF /
 * lease term, OR (cap/noi) + tenant + lease expiration). Used as a fallback so
 * low-quality classification doesn't block obviously-promotable deals.
 */
export function snapshotLooksLikeListing(snapshot) {
  if (!snapshot) return false;
  const hasPrice  = Number(snapshot.asking_price) > 0;
  const hasCap    = Number(snapshot.cap_rate) > 0
                 || (typeof snapshot.cap_rate === 'string' && /\d/.test(snapshot.cap_rate));
  const hasNoi    = Number(snapshot.noi) > 0;
  const hasTenant = !!(snapshot.tenant_name || snapshot.primary_tenant);
  const supportingFields = [
    snapshot.cap_rate,
    snapshot.building_sf,
    snapshot.lease_term_years,
    snapshot.lease_expiration,
    snapshot.noi,
  ].filter(v => v != null && v !== '').length;
  if (hasPrice && hasTenant && supportingFields >= 1) return true;
  if ((hasCap || hasNoi) && hasTenant && snapshot.lease_expiration) return true;
  return false;
}

// Doctypes that, on their own, keep an intake in the review pile even with no
// address/price — a comp or listing doc is deal-shaped enough to triage.
const DEAL_DISPOSITION_DOCTYPES = new Set(['om', 'flyer', 'marketing_brochure', 'comp']);

function snapshotHasAddress(snapshot) {
  if (!snapshot) return false;
  return !!(snapshot.address
    || (Array.isArray(snapshot.addresses) && snapshot.addresses.length));
}

function snapshotHasCapRate(snapshot) {
  if (!snapshot) return false;
  return Number(snapshot.cap_rate) > 0
    || (typeof snapshot.cap_rate === 'string' && /\d/.test(snapshot.cap_rate));
}

/**
 * Auto-disposition classifier (doctrine 2026-06-04).
 *
 * An intake is NON-DEAL — i.e. a newsletter / broker blast / thread history
 * that will never match or promote — when ALL of:
 *   - no extracted address
 *   - no asking_price
 *   - no cap_rate
 *   - document_type NOT IN (om, flyer, marketing_brochure, comp)
 * Tenant alone does NOT save it (a "DaVita is expanding" newsletter mentions
 * a tenant but carries no deal).
 *
 * Returns false for a null snapshot — that's an extraction *failure*, handled
 * separately, not a confidently-classified non-deal.
 */
export function isNonDealSnapshot(snapshot) {
  if (!snapshot || typeof snapshot !== 'object') return false;
  const dt = normalizeDocType(snapshot.document_type || '');
  if (DEAL_DISPOSITION_DOCTYPES.has(dt)) return false;
  if (snapshotHasAddress(snapshot)) return false;
  if (Number(snapshot.asking_price) > 0) return false;
  if (snapshotHasCapRate(snapshot)) return false;
  return true;
}

// ── Decision Center: staged-intake lane classification (2026-06-30) ──────
// The `intake_disposition` Decision-Center lane mixed four fundamentally
// different things under one "Create property" button: genuine unmatched
// listing docs, already-matched rows (promotion just didn't finish), broker
// market-blast / comp doctypes (never a property), and rows the extractor got
// nothing usable from. classifyStagedIntake sorts each staged-intake row into
// exactly one `klass` so the lane can default to the create-candidate set,
// route the rest correctly, and report an HONEST count.
//
// Input is the extraction_result fields (works on the nested object OR a flat
// PostgREST projection that aliases the `->>` paths to the same names):
//   document_type, address, city, state, tenant_name, asking_price, cap_rate,
//   match_status, match_domain, match_property_id
//
// Doctypes that are market intel / comps, NOT a listing to create a property
// from. A matched row of any doctype is still `matched` (matched wins).
export const INTAKE_NOISE_DOCTYPES = new Set([
  'email_update', 'broker_email', 'market_update', 'email', 'comp',
]);

// Asking-price sanity ceiling (2026-07). The extractor occasionally mashes a
// multi-property OM into one row and concatenates the prices into an absurd
// number (e.g. $750,200,011,294,000). A single-asset net-lease deal never
// approaches $1B, so a parsed asking price ABOVE this ceiling is SUSPECT — it is
// treated as absent for value-ranking (sorts last, never #1) AND flagged on the
// card for re-extraction. Display + ranking only; the raw extraction (raw_payload)
// is never mutated — the real fix for a suspect row is re-extraction.
export const INTAKE_ASKING_PRICE_MAX = 1_000_000_000;

// Cap-rate DISPLAY band (percent). A real CRE cap rate is well under 25%; a value
// that normalizes above this is a mis-parse and is omitted rather than shown.
const CAP_RATE_DISPLAY_MAX = 25;

function _intakeText(v) {
  const s = (v == null ? '' : String(v)).trim();
  return s || null;
}
function _intakeMoney(v) {
  const n = Number(String(v == null ? '' : v).replace(/[^0-9.]/g, ''));
  return (Number.isFinite(n) && n > 0) ? n : null;
}
// A field carrying a pipe-joined string ("A|B") or a ≥2-element array is a
// multi-property OM the extractor merged into one row — the root cause of the
// concatenated garbage price. Soft flag (needs split / re-extract), never a hard
// exclusion.
function _intakeLooksMulti(v) {
  if (Array.isArray(v)) return v.filter((x) => x != null && String(x).trim() !== '').length >= 2;
  return typeof v === 'string' && v.includes('|');
}

/**
 * Normalize a cap-rate value to ONE displayed format ("5.55%"), regardless of
 * whether the source stored it as a decimal fraction (0.0555) or a whole percent
 * (5.24) — the extractor emits both. Standard heuristic: v<1 is a decimal (×100);
 * 1 ≤ v ≤ CAP_RATE_DISPLAY_MAX is already a percent; v normalizing above the band
 * is a mis-parse → null (omit / suspect). Pure + display-only; never mutates the
 * source. Returns the formatted string or null.
 */
export function formatCapRateDisplay(v) {
  if (v == null) return null;
  const n = Number(String(v).replace(/[^0-9.\-]/g, ''));
  if (!Number.isFinite(n) || n <= 0) return null;
  const pct = n < 1 ? n * 100 : n;
  if (pct > CAP_RATE_DISPLAY_MAX) return null;   // out of band → suspect, omit
  return pct.toFixed(2) + '%';
}

/**
 * Classify ONE staged-intake row for the Decision-Center create lane.
 *
 * klass:
 *   - 'matched'          : match_status='matched' — already tied to a property
 *                          (promotion didn't finish). Open / promote, NOT create.
 *   - 'no_data'          : no address AND no tenant AND no asking price — the
 *                          extractor got nothing usable. Auto-retire.
 *   - 'noise'            : a non-listing doctype (email_update/broker_email/
 *                          comp/market_update/email) — market intel, not a
 *                          listing. Excluded from the create lane.
 *   - 'create_candidate' : an unmatched listing doc (om/flyer/marketing_brochure,
 *                          aliases normalized) carrying content. The genuine
 *                          "create the property" set.
 *   - 'other'            : unmatched, has content, but doctype is unknown/null —
 *                          workable but lower-confidence; shown only in "all".
 */
export function classifyStagedIntake(fields) {
  const f = fields || {};
  const address = _intakeText(f.address);
  const city = _intakeText(f.city);
  const state = _intakeText(f.state);
  const tenant = _intakeText(f.tenant_name);
  const asking = _intakeMoney(f.asking_price);
  // An implausible parsed price (multi-property mash-up) is kept for DISPLAY but
  // flagged suspect so ranking treats it as absent — never sorts it to the top.
  const askingSuspect = asking != null && asking > INTAKE_ASKING_PRICE_MAX;
  const multiProperty = _intakeLooksMulti(f.address) || _intakeLooksMulti(f.tenant_name);
  const capRate = _intakeText(f.cap_rate);
  const matchStatus = _intakeText(f.match_status);
  const matchDomain = _intakeText(f.match_domain);
  const matchPropertyId = _intakeText(f.match_property_id);
  const doctype = f.document_type ? normalizeDocType(f.document_type) : null;
  const hasContent = !!(address || tenant || asking != null);

  let klass;
  if (matchStatus === 'matched') klass = 'matched';
  else if (!hasContent) klass = 'no_data';
  else if (doctype && INTAKE_NOISE_DOCTYPES.has(doctype)) klass = 'noise';
  else if (doctype && LISTING_DOCUMENT_TYPES.has(doctype)) klass = 'create_candidate';
  else klass = 'other';

  return {
    klass,
    doctype,
    address, city, state, tenant,
    asking_price: asking,
    asking_price_suspect: askingSuspect,
    multi_property: multiProperty,
    cap_rate: capRate,
    cap_rate_display: formatCapRateDisplay(f.cap_rate),
    match_status: matchStatus,
    match_domain: matchDomain,
    match_property_id: matchPropertyId,
    has_content: hasContent,
  };
}

// ── Cap-rate normalization (Round 77f, 2026-06-04) ───────────────────────
// The extractor emits cap rates in BOTH forms depending on the AI/prompt:
//   - decimal fraction  : 0.055  (5.5%)        — already DB-ready
//   - whole-number pct   : 7.75   (7.75%)       — needs ÷100
// The promoter previously assumed percent form and unconditionally divided by
// 100, so a decimal-form 0.055 became 0.00055 and blew the
// chk_*_cap_rate_decimal_range check ([0.005, 0.30]) — killing the listing
// INSERT (Buckeye AZ, listing 23514, 2026-06-04). Detect, don't assume.
//
// Returns a DB-ready DECIMAL cap rate, or null when the value is implausible
// either way (callers keep the raw value in notes/metadata rather than failing
// the row). Plausible decimal band mirrors the DB check: [0.005, 0.30].
//
//   v > 1.5            → treat as percent, ÷100, accept only if result in band
//   0.005 ≤ v ≤ 0.30   → already decimal, pass through
//   0.30 < v ≤ 1.5     → ambiguous/implausible → null
//   v < 0.005          → implausible (e.g. a double-divided 0.00055) → null
export function normalizeCapRate(v) {
  if (v == null) return null;
  let n;
  if (typeof v === 'number') {
    n = v;
  } else {
    // Strip $, %, commas, whitespace — keep digits, dot, minus.
    const cleaned = String(v).replace(/[^0-9.\-]/g, '');
    if (!cleaned || cleaned === '-' || cleaned === '.') return null;
    n = Number(cleaned);
  }
  if (!Number.isFinite(n) || n <= 0) return null;

  if (n > 1.5) {
    const dec = n / 100;
    return dec >= 0.005 && dec <= 0.30 ? round6(dec) : null;
  }
  if (n >= 0.005 && n <= 0.30) return round6(n);
  return null;
}

function round6(x) {
  return Math.round(x * 1e6) / 1e6;
}

// ── Array-valued snapshot field coercion (Round 77f, 2026-06-04) ──────────
// The F1/F2 work made tenant_name, listing_broker, listing_broker_email,
// seller_name (etc.) legitimately ARRAY-valued for multi-tenant / multi-broker
// OMs. Scalar consumers (`(snapshot.foo || '').trim()`, text-column writes)
// then crash with "(...).trim is not a function" or stuff a raw JSON array
// (["Jay","Tom"]) into a text column. These helpers coerce at the call site:
//   - firstOf(v)        → first non-empty element when array (or array-shaped
//                         JSON string), else the scalar. "first-as-primary".
//   - joinedOf(v, sep)  → human-joined string ("Jay Patel, Thomas Ladt") when
//                         array/array-string, else the scalar. For text columns
//                         and for feeding the broker comma-splitter — never raw
//                         JSON.

function parseArrayShape(v) {
  if (Array.isArray(v)) return v;
  if (typeof v === 'string') {
    const s = v.trim();
    if (s.startsWith('[')) {
      try {
        const parsed = JSON.parse(s);
        if (Array.isArray(parsed)) return parsed;
      } catch { /* not JSON — treat as scalar */ }
    }
  }
  return null;
}

export function firstOf(v) {
  if (v == null) return v;
  const arr = parseArrayShape(v);
  if (arr == null) return v; // scalar — pass through unchanged
  const first = arr.find((x) => x != null && String(x).trim() !== '');
  return first == null ? null : first;
}

export function joinedOf(v, sep = ', ') {
  if (v == null) return v;
  const arr = parseArrayShape(v);
  if (arr == null) return v; // scalar — pass through unchanged
  return arr
    .map((x) => (x == null ? '' : String(x).trim()))
    .filter(Boolean)
    .join(sep);
}

/**
 * Full deal signature: address + tenant + asking_price. Gate for the guarded
 * AUTO create-from-intake mode (the manual route is less strict — an operator
 * vouches for the item).
 */
export function hasFullDealSignature(snapshot) {
  if (!snapshot || typeof snapshot !== 'object') return false;
  const hasTenant = !!(snapshot.tenant_name || snapshot.primary_tenant);
  return snapshotHasAddress(snapshot)
    && hasTenant
    && Number(snapshot.asking_price) > 0;
}

// ===========================================================================
// Infra-alert classification (Vercel / GitHub CI-CD failure notifications)
// ---------------------------------------------------------------------------
// Scott flags Vercel/GitHub build & deploy failure emails in Outlook, same as
// any deal email — no new folder, flag, or button. These helpers let the
// outlook-message intake handler recognize such an email, tag it
// domain='infra' + source_system, and priority-SCORE it against the rest of
// the open queue so its To Do task carries a scannable [HIGH]/[MED]/[LOW]
// tier.  THIS IS THE SINGLE SOURCE OF TRUTH FOR THE SENDER/SUBJECT PATTERNS —
// edit them here.  See docs/INFRA_ALERT_CLASSIFICATION.md.
//
// NOTE: the score itself is produced by scoreItem() in briefing-data.js (the
// same engine the daily briefing uses); these helpers only classify + shape
// the pseudo-item + bucket the resulting score into a tier.
// ===========================================================================

// Sender domain → source_system. A domain matches when the sender's domain
// part equals it OR is a subdomain (e.g. notifications.github.com → github).
export const INFRA_SENDER_DOMAINS = {
  vercel: ['vercel.com'],
  github: ['github.com', 'githubapp.com'],
};

// Subject-line fallbacks (a forwarded / re-branded alert may not keep the
// original sender). Anchored on failure/attention wording, not bare "build".
export const INFRA_SUBJECT_PATTERNS = [
  /\bbuild failed\b/i,
  /\bbuild has failed\b/i,
  /\bdeploy(?:ment)? failed\b/i,
  /\bfailed to deploy\b/i,
  /\bworkflow run failed\b/i,
  /\b(?:ci|pipeline|check(?:s)?|job|run) failed\b/i,
  /\baction required:/i,
];

/**
 * Classify an inbound flagged email as a Vercel/GitHub infra alert.
 * Sender-domain match wins (most authoritative → sets source_system);
 * subject-pattern match is the fallback, inferring the system from wording.
 * @returns {{ isInfra: boolean, sourceSystem: string|null, matchedBy: string|null }}
 */
export function detectInfraAlert({ senderEmail, subject } = {}) {
  const email = String(senderEmail || '').toLowerCase().trim();
  const domainPart = email.includes('@') ? email.split('@').pop() : email;
  if (domainPart) {
    for (const [system, suffixes] of Object.entries(INFRA_SENDER_DOMAINS)) {
      if (suffixes.some((s) => domainPart === s || domainPart.endsWith('.' + s))) {
        return { isInfra: true, sourceSystem: system, matchedBy: 'sender_domain' };
      }
    }
  }
  const subj = String(subject || '');
  if (INFRA_SUBJECT_PATTERNS.some((re) => re.test(subj))) {
    let system = 'unknown';
    if (/\bvercel\b/i.test(subj)) system = 'vercel';
    else if (/\b(?:github|workflow|gh action|action required)\b/i.test(subj)) system = 'github';
    return { isInfra: true, sourceSystem: system, matchedBy: 'subject' };
  }
  return { isInfra: false, sourceSystem: null, matchedBy: null };
}

/**
 * Urgency of an infra alert, derived from the subject.
 *  - 'high'   — an actual failure (build/deploy/workflow failed, error)
 *  - 'medium' — needs attention but not a hard failure ("action required")
 *  - 'low'    — a softer infra notice that still matched a pattern
 */
export function infraUrgency(subject) {
  const s = String(subject || '');
  if (/\b(?:failed|failure|error|broke|broken|cannot deploy|could not)\b/i.test(s)) return 'high';
  if (/\b(?:action required|required|approve|review|attention|warning)\b/i.test(s)) return 'medium';
  return 'low';
}

/**
 * Build the pseudo-item scoreItem() expects, encoding the infra scoring
 * policy: the urgency (build failure = high) rides in `priority` so the shared
 * engine adds its priority weight; there is NO due_date (infra has no
 * client-facing deadline); source_type='flagged_email' gives it the small
 * flagged-email weight — so it lands BELOW active deal-deadline emails (deal
 * keywords add 70-100) but ABOVE a bare FYI/reference email. The `body` is
 * deliberately omitted so a long alert body can't trip deal/pursuit keywords.
 */
export function buildInfraScoringItem({ subject, senderEmail } = {}) {
  const urgency = infraUrgency(subject);
  const priority = urgency === 'high' ? 'urgent' : urgency === 'medium' ? 'high' : 'low';
  return {
    title: String(subject || ''),
    body: '',
    metadata: { sender_email: senderEmail || null, has_attachments: false },
    source_type: 'flagged_email',
    priority,
    // no due_date — infra alerts carry no client-facing deadline
  };
}

/**
 * Bucket a numeric priority score into the scannable To Do tier.
 * Calibrated to the shared scoreItem() scale so an infra alert reads:
 *   failure  (urgent + flagged_email = 40) → HIGH
 *   attention(high   + flagged_email = 30) → MED
 *   notice   (low    + flagged_email = 10) → LOW
 */
export function priorityTierFromScore(score) {
  const n = Number(score) || 0;
  if (n >= 40) return 'HIGH';
  if (n >= 20) return 'MED';
  return 'LOW';
}
