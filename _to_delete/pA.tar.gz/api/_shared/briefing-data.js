// ============================================================================
// Briefing Data Helpers — data-fetching and scoring functions for daily briefing
// Life Command Center
//
// Extracted from the former api/daily-briefing.js (deleted in Phase 4b
// consolidation) so that briefing-email-handler.js can continue to import
// these functions without pulling in the full serverless handler.
// ============================================================================

import { fetchWithTimeout, opsQuery } from './ops-db.js';
import { sendTeamsAlert } from './teams-alert.js';
import { diaSupabaseKey, govSupabaseKey } from './supabase-keys.js';

const GOV_URL = process.env.GOV_SUPABASE_URL;
const GOV_KEY = govSupabaseKey();
const DIA_URL = process.env.DIA_SUPABASE_URL;
const DIA_KEY = diaSupabaseKey();

// ---------------------------------------------------------------------------
// deriveItemTitle
// ---------------------------------------------------------------------------

export function deriveItemTitle(item) {
  if (item == null) return null;
  if (typeof item === 'string') {
    const s = item.trim();
    return s || null;
  }
  if (typeof item !== 'object') return null;

  const direct = [
    item.title,
    item.subject,
    item.name,
    item.headline,
    item.label,
    item.what_name,
    item.full_name,
    item.company_name,
  ];
  for (const c of direct) {
    if (c != null && String(c).trim()) return String(c).trim();
  }

  const meta = (item.metadata && typeof item.metadata === 'object') ? item.metadata : {};
  const sender =
    item.sender_name || item.from_name || meta.sender_name || meta.from_name || null;
  const senderEmail =
    item.sender_email || item.from_email || meta.sender_email || meta.from_email || null;
  const taskType = item.task_type || meta.task_type || null;
  const rawType = String(
    item.item_type || item.source_type || item.type || meta.type || ''
  ).toLowerCase();

  if (rawType.includes('email') || rawType.includes('inbox')) {
    if (sender) return `Email from ${sender}`;
    if (senderEmail) return `Email from ${senderEmail}`;
  }
  if (rawType.includes('call')) {
    if (sender) return `Call with ${sender}`;
  }
  if (rawType.includes('task') || rawType.includes('action')) {
    if (taskType) return `Task: ${taskType}`;
    if (sender) return `Task from ${sender}`;
  }

  const descriptive = item.description || item.text || item.summary;
  if (descriptive && String(descriptive).trim()) {
    return String(descriptive).trim();
  }

  return null;
}

// ---------------------------------------------------------------------------
// Internal helpers (not exported)
// ---------------------------------------------------------------------------

function mapPriorityItems(items, limit = 5) {
  const mapped = [];
  for (const item of items || []) {
    if (mapped.length >= limit) break;
    const title = deriveItemTitle(item);
    if (!title) continue;
    mapped.push({
      id: item.id,
      title,
      status: item.status || null,
      priority: item.priority || null,
      due_date: item.due_date || null,
      domain: item.domain || null,
      type: item.item_type || item.source_type || 'action'
    });
  }
  return mapped;
}

const DEAL_KEYWORDS = /offer|under contract|loi|letter of intent|closing|escrow|due diligence|earnest money|psa|purchase|disposition|assignment/i;
const REVENUE_KEYWORDS = /commission|fee|listing agreement|exclusive|signed|engaged|retained/i;
const PURSUIT_KEYWORDS = /bov|proposal|valuation|pitch|pursuit|prospect|owner|developer|seller/i;
const RELATIONSHIP_KEYWORDS = /follow[- ]?up|check[- ]?in|touch base|reconnect|introduction|referral|thank you|congrat/i;

// Exported so the infra-alert intake path (api/intake.js) can priority-score a
// flagged Vercel/GitHub alert against the same scale as the daily briefing —
// reuse, not a duplicated scoring engine.
export function scoreItem(item, hotContactMap) {
  let score = 0;
  let tier = 'urgent';
  const title = (item.title || '').toLowerCase();
  const body = (item.body || '').toLowerCase();
  const combined = title + ' ' + body;
  const senderEmail = item.metadata?.sender_email || '';

  if (DEAL_KEYWORDS.test(combined)) {
    score += 100;
    tier = 'strategic';
  }
  if (REVENUE_KEYWORDS.test(combined)) {
    score += 90;
    tier = 'strategic';
  }
  if (PURSUIT_KEYWORDS.test(combined)) {
    score += 70;
    if (tier !== 'strategic') tier = 'strategic';
  }

  if (RELATIONSHIP_KEYWORDS.test(combined)) {
    score += 50;
    if (tier === 'urgent') tier = 'important';
  }

  if (senderEmail && hotContactMap) {
    const contact = hotContactMap.get(senderEmail.toLowerCase());
    if (contact) {
      score += Math.min(contact.engagement_score || 0, 50);
      if (contact.engagement_score >= 60) tier = tier === 'urgent' ? 'important' : tier;
    }
  }

  if (item.due_date) {
    const due = new Date(item.due_date);
    const now = new Date();
    const daysUntil = (due - now) / 86400000;
    if (daysUntil < 0) score += 40;
    else if (daysUntil < 1) score += 30;
    else if (daysUntil < 3) score += 20;
    else if (daysUntil < 7) score += 10;
  }

  if (item.priority === 'urgent') score += 30;
  else if (item.priority === 'high') score += 20;

  if (item.source_type === 'sf_task') score += 15;
  if (item.source_type === 'flagged_email') score += 10;

  if (item.metadata?.has_attachments) score += 5;

  return { score, tier };
}

// ---------------------------------------------------------------------------
// Data fetchers
// ---------------------------------------------------------------------------

export async function fetchWorkCounts(workspaceId, userId) {
  // Single-row materialized-view reads — count header is never consumed.
  const [teamMv, userMv] = await Promise.all([
    opsQuery('GET', `mv_work_counts?workspace_id=eq.${encodeURIComponent(workspaceId)}&limit=1`, undefined, { countMode: 'none' }),
    opsQuery('GET', `mv_user_work_counts?workspace_id=eq.${encodeURIComponent(workspaceId)}&user_id=eq.${encodeURIComponent(userId)}&limit=1`, undefined, { countMode: 'none' })
  ]);

  let team = teamMv;
  let teamSource = 'mv_work_counts';
  if (!team.ok || !team.data?.length) {
    team = await opsQuery('GET', `v_work_counts?workspace_id=eq.${encodeURIComponent(workspaceId)}&limit=1`, undefined, { countMode: 'none' });
    teamSource = 'v_work_counts';
  }
  let t = team.data?.[0] || {};
  const rawMvRow = { ...t, _source: teamSource, _ok: team.ok, _status: team.status, _row_count: team.data?.length || 0 };

  const wsEnc = encodeURIComponent(workspaceId);
  if (!t.open_actions && !t.inbox_new && !t.overdue_actions) {
    try {
      const today = new Date().toISOString().slice(0, 10);
      const [openRes, inboxNewRes, syncErrRes, overdueRes] = await Promise.all([
        opsQuery('GET', `action_items?workspace_id=eq.${wsEnc}&status=in.(open,in_progress,waiting,assigned)&select=id&limit=0`),
        opsQuery('GET', `inbox_items?workspace_id=eq.${wsEnc}&status=eq.new&select=id&limit=0`),
        opsQuery('GET', `action_items?workspace_id=eq.${wsEnc}&status=eq.sync_error&select=id&limit=0`),
        opsQuery('GET', `action_items?workspace_id=eq.${wsEnc}&status=in.(open,in_progress)&due_date=lt.${today}&select=id&limit=0`)
      ]);
      t = {
        ...t,
        open_actions: openRes.count || 0,
        inbox_new: inboxNewRes.count || 0,
        sync_errors: (syncErrRes.count || 0) + (t.sync_errors || 0),
        overdue_actions: overdueRes.count || 0,
        _source: 'direct_count_fallback'
      };
      console.log('[Briefing] team signals direct-count fallback used:', { open: t.open_actions, inbox: t.inbox_new, overdue: t.overdue_actions, sync: t.sync_errors });
    } catch (err) {
      console.error('[Briefing] direct-count fallback failed:', err.message);
    }
  }

  let user = userMv;
  if (!user.ok || !user.data?.length) {
    const myActions = await opsQuery('GET',
      `action_items?workspace_id=eq.${wsEnc}&or=(owner_id.eq.${encodeURIComponent(userId)},assigned_to.eq.${encodeURIComponent(userId)})&status=in.(open,in_progress,waiting)&select=id&limit=0`
    );
    user = { data: [{ my_actions: myActions.count || 0, my_overdue: 0, my_inbox: 0, my_research: 0, my_completed_week: 0 }] };
  }
  const u = user.data?.[0] || {};

  const today = new Date().toISOString().slice(0, 10);
  let dueToday = 0;
  try {
    const dueTodayRes = await opsQuery('GET',
      `action_items?workspace_id=eq.${encodeURIComponent(workspaceId)}&status=in.(open,in_progress,waiting)&due_date=eq.${today}&select=id&limit=0`
    );
    dueToday = dueTodayRes.count || 0;
  } catch (err) {
    console.error('[Briefing] due_today direct-count failed:', err.message);
  }

  const open = Number(t.open_actions || 0);
  const overdue = Number(t.overdue_actions || 0);

  return {
    open,
    overdue,
    due_today: dueToday,
    my_actions: u.my_actions || 0,
    my_overdue: u.my_overdue || 0,
    my_inbox: u.my_inbox || 0,
    my_research: u.my_research || 0,
    my_completed_week: u.my_completed_week || 0,
    open_actions: open,
    inbox_new: t.inbox_new || 0,
    inbox_triaged: t.inbox_triaged || 0,
    research_active: t.research_active || 0,
    sync_errors: t.sync_errors || 0,
    due_this_week: t.due_this_week || 0,
    completed_week: t.completed_week || 0,
    open_escalations: t.open_escalations || 0,
    refreshed_at: t.refreshed_at || null,
    _mv_raw: rawMvRow
  };
}

export async function fetchMyWork(workspaceId, userId, limit = 15) {
  const path =
    `v_my_work?workspace_id=eq.${encodeURIComponent(workspaceId)}` +
    `&or=(user_id.eq.${encodeURIComponent(userId)},assigned_to.eq.${encodeURIComponent(userId)})` +
    `&limit=${Math.max(1, Math.min(limit, 50))}` +
    `&order=due_date.asc.nullslast,created_at.desc`;
  // List read — count header unused.
  const result = await opsQuery('GET', path, undefined, { countMode: 'none' });
  return Array.isArray(result.data) ? result.data : [];
}

export async function fetchInboxSummary(workspaceId, limit = 10) {
  const path =
    `v_inbox_triage?workspace_id=eq.${encodeURIComponent(workspaceId)}` +
    `&limit=${Math.max(1, Math.min(limit, 50))}` +
    '&order=received_at.desc';
  // Items list reads .data only; the two count probes (select=id&limit=0)
  // intentionally keep count=exact since their whole purpose is counting.
  const [items, newCount, triagedCount] = await Promise.all([
    opsQuery('GET', path, undefined, { countMode: 'none' }),
    opsQuery('GET', `inbox_items?workspace_id=eq.${encodeURIComponent(workspaceId)}&status=eq.new&select=id&limit=0`),
    opsQuery('GET', `inbox_items?workspace_id=eq.${encodeURIComponent(workspaceId)}&status=eq.triaged&select=id&limit=0`)
  ]);
  return {
    total_new: newCount.count || 0,
    total_triaged: triagedCount.count || 0,
    items: Array.isArray(items.data) ? items.data : []
  };
}

/**
 * Auto-archive/cleanup activity in the last N hours.
 *
 * One row per email whose intake job finished is recorded in processing_log
 * (filed / needs_review / duplicate). This rolls the recent window up so the
 * briefing can report a one-liner: "14 emails auto-filed, 2 flagged for review".
 * Best-effort: a missing table (migration not yet applied) returns zeros.
 */
export async function fetchProcessingSummary(workspaceId, hours = 24) {
  const sinceIso = new Date(Date.now() - hours * 3600_000).toISOString();
  const wsEnc = encodeURIComponent(workspaceId);
  const base = `processing_log?workspace_id=eq.${wsEnc}&created_at=gte.${encodeURIComponent(sinceIso)}`;
  const [filed, review, dup, pending] = await Promise.all([
    opsQuery('GET', `${base}&outcome=eq.filed&select=id&limit=0`),
    opsQuery('GET', `${base}&outcome=eq.needs_review&select=id&limit=0`),
    opsQuery('GET', `${base}&outcome=eq.duplicate&select=id&limit=0`),
    // KNOWN ISSUE (see docs/KNOWN_ISSUES.md): pending_moves counts rows still at
    // move_status='pending', but NOTHING clears that column anymore — the queue-
    // drain consumer (api/_handlers/processing-complete.js) was retired, and the
    // live sync.js relay reconciles via pa-move-message, never touching
    // processing_log.move_status on the terminal path. So this count monotonically
    // inflates (counts ~every move-eligible email in the window). The filed/
    // needs_review/duplicate counts above are accurate (they key on `outcome`,
    // still written by emitProcessingComplete). Preferred fix: DROP the
    // pending_moves clause from the briefing line — do NOT wire a parallel
    // PATCH-based move_status tracker (sync.js + the To Do Completion Poll already
    // own real move-tracking; a second mechanism would recreate the two-systems
    // duplication that PR #1435 removed).
    opsQuery('GET', `${base}&move_status=eq.pending&select=id&limit=0`),
  ]);
  return {
    filed: filed.ok ? (filed.count || 0) : 0,
    needs_review: review.ok ? (review.count || 0) : 0,
    duplicate: dup.ok ? (dup.count || 0) : 0,
    pending_moves: pending.ok ? (pending.count || 0) : 0,
  };
}

/**
 * Newly promoted OM intakes within the last N hours.
 *
 * Surfaces OMs that made it through the full pipeline (extraction → match →
 * promote) in the recent past so the daily briefing tells a broker "4 new
 * deals landed overnight — here they are." Queries
 * staged_intake_promotions, which intake-promoter writes one row per
 * successful promotion to.
 *
 * Designed to be called from the briefing assembler (Phase 4b) and
 * rendered as its own "New OM Intakes" section alongside Inbox Summary.
 *
 * @param {string} workspaceId
 * @param {number} hours   — lookback window (default 24h)
 * @param {number} limit   — max rows (default 10)
 */
export async function fetchNewIntakes(workspaceId, hours = 24, limit = 10) {
  const sinceIso = new Date(Date.now() - hours * 3600 * 1000).toISOString();
  // pipeline_result is the promoter's full response blob (listing,
  // broker_contact, property_financials, etc.). We unpack it client-side
  // to avoid scattering jsonb extraction across the rendering code.
  const path =
    `staged_intake_promotions?workspace_id=eq.${encodeURIComponent(workspaceId)}` +
    `&promoted_at=gte.${encodeURIComponent(sinceIso)}` +
    `&select=id,intake_id,entity_id,pipeline_result,promoted_at,promoted_by` +
    `&order=promoted_at.desc&limit=${Math.max(1, Math.min(limit, 50))}`;
  const res = await opsQuery('GET', path, undefined, { countMode: 'none' });
  const rawItems = Array.isArray(res.data) ? res.data : [];
  const mapped = rawItems.map((r) => {
    const pr = r.pipeline_result || {};
    const listing = pr.listing || {};
    const snap    = pr.snapshot || {};
    return {
      id:              r.id,
      intake_id:       r.intake_id,
      entity_id:       r.entity_id,
      promoted_at:     r.promoted_at,
      domain:          pr.domain || null,
      property_id:     pr.match?.property_id || listing.property_id || null,
      listing_id:      listing.listing_id || null,
      address:         snap.address || listing.address || null,
      city:            snap.city || listing.city || null,
      state:           snap.state || listing.state || null,
      tenant_agency:   snap.tenant_agency || snap.tenant_name || null,
      listing_broker:  snap.listing_broker || null,
      asking_price:    snap.asking_price ?? null,
    };
  });
  // Dedup re-promotions of the same deal (same address+tenant+price showed
  // twice in the 2026-06-05 deep dive). Keep the most recent promotion —
  // rows are already ordered promoted_at.desc.
  const seen = new Set();
  const items = [];
  for (const it of mapped) {
    const key = [it.address, it.city, it.tenant_agency, it.asking_price]
      .map((v) => String(v ?? '').trim().toLowerCase()).join('|');
    if (key !== '|||' && seen.has(key)) continue;
    seen.add(key);
    items.push(it);
  }
  return {
    window_hours: hours,
    count:        items.length,
    items,
  };
}

export async function fetchUnassignedWork(workspaceId, limit = 10) {
  const path =
    `v_unassigned_work?workspace_id=eq.${encodeURIComponent(workspaceId)}` +
    `&limit=${Math.max(1, Math.min(limit, 50))}` +
    '&order=created_at.desc';
  const result = await opsQuery('GET', path, undefined, { countMode: 'none' });
  return Array.isArray(result.data) ? result.data : [];
}

export async function fetchSyncHealthSnapshot(workspaceId) {
  // Three reads use only .data; openSfTasks uses .count for queue_drift.
  const [connectors, recentJobs, unresolvedErrors, openSfTasks] = await Promise.all([
    opsQuery('GET',
      `connector_accounts?workspace_id=eq.${encodeURIComponent(workspaceId)}&select=id,user_id,connector_type,status,last_sync_at,last_error,external_user_id&order=connector_type,display_name`,
      undefined, { countMode: 'none' }
    ),
    opsQuery('GET',
      `sync_jobs?workspace_id=eq.${encodeURIComponent(workspaceId)}&created_at=gte.${encodeURIComponent(new Date(Date.now() - 86400000).toISOString())}&select=id,status,direction,entity_type,records_processed,records_failed,completed_at&order=created_at.desc&limit=50`,
      undefined, { countMode: 'none' }
    ),
    opsQuery('GET',
      `sync_errors?workspace_id=eq.${encodeURIComponent(workspaceId)}&resolved_at=is.null&select=id,error_message,is_retryable,retry_count,created_at&order=created_at.desc&limit=25`,
      undefined, { countMode: 'none' }
    ),
    opsQuery('GET',
      `inbox_items?workspace_id=eq.${encodeURIComponent(workspaceId)}&source_type=eq.sf_task&status=in.(new,triaged)&select=id&limit=1`,
      undefined, { countMode: 'exact' }
    )
  ]);

  const connectorList = connectors.data || [];
  const jobs = recentJobs.data || [];
  const outboundTracked = jobs.filter((job) => job.direction === 'outbound' && ['completed', 'failed', 'partial'].includes(job.status));
  const outboundCompleted = outboundTracked.filter((job) => job.status === 'completed').length;
  const latestSfInbound = jobs.find((job) => job.entity_type === 'sf_activity' && ['completed', 'partial'].includes(job.status));
  const sfOpenTaskCount = openSfTasks.count || 0;
  const sfLastProcessed = Number(latestSfInbound?.records_processed || 0);
  const estimatedGap = Math.max(sfOpenTaskCount - sfLastProcessed, 0);

  return {
    summary: {
      total_connectors: connectorList.length,
      healthy: connectorList.filter((c) => c.status === 'healthy').length,
      degraded: connectorList.filter((c) => c.status === 'degraded').length,
      error: connectorList.filter((c) => c.status === 'error').length,
      disconnected: connectorList.filter((c) => c.status === 'disconnected').length,
      pending: connectorList.filter((c) => c.status === 'pending_setup').length,
      outbound_success_rate_24h: outboundTracked.length ? Number((outboundCompleted / outboundTracked.length).toFixed(3)) : null
    },
    unresolved_errors: unresolvedErrors.data || [],
    queue_drift: {
      source: 'salesforce',
      salesforce_open_task_count: sfOpenTaskCount,
      last_sf_records_processed: sfLastProcessed,
      estimated_gap: estimatedGap,
      drift_flag: estimatedGap > 25,
      last_inbound_completed_at: latestSfInbound?.completed_at || null
    }
  };
}

export async function fetchRecentSfActivity(workspaceId, limit = 30) {
  const sevenDaysAgo = new Date(Date.now() - 7 * 86400000).toISOString();
  const result = await opsQuery('GET',
    `activity_events?workspace_id=eq.${encodeURIComponent(workspaceId)}&source_type=eq.salesforce&occurred_at=gte.${encodeURIComponent(sevenDaysAgo)}&order=occurred_at.desc&limit=${limit}&select=id,category,title,body,source_type,external_url,metadata,occurred_at`
  );
  return Array.isArray(result.data) ? result.data : [];
}

export async function fetchHotContacts(limit = 15) {
  const path = `unified_contacts?contact_class=eq.business&engagement_score=gt.0&order=engagement_score.desc&limit=${limit}&select=unified_id,full_name,email,company_name,title,engagement_score,last_call_date,last_email_date,last_meeting_date,total_calls,total_emails_sent`;
  // A9b: the contacts hub follows CONTACTS_HUB. When 'ops', read the canonical
  // LCC Opps hub (so this reader sees the reconciled/merged rows); else the
  // legacy gov copy. Repoints together with the contacts-handler routing flip.
  if ((process.env.CONTACTS_HUB || 'gov').toLowerCase() === 'ops') {
    try { const r = await opsQuery('GET', path); return Array.isArray(r.data) ? r.data : []; }
    catch { return []; }
  }
  if (!GOV_URL || !GOV_KEY) return [];
  try {
    const res = await fetchWithTimeout(
      `${GOV_URL}/rest/v1/${path}`,
      { headers: { 'apikey': GOV_KEY, 'Authorization': `Bearer ${GOV_KEY}` } },
      5000
    );
    return res.ok ? await res.json() : [];
  } catch { return []; }
}

export async function fetchDiaPipeline() {
  if (!DIA_URL || !DIA_KEY) return { deals: [], leads: [] };
  try {
    const [dealsRes, leadsRes] = await Promise.all([
      // NOTE: dia salesforce_activities has no is_closed column — the old
      // is_closed=eq.false filter 400'd at PostgREST and this function
      // silently returned empty deals/leads forever (found 2026-06-05).
      // "Open" status is the open marker; Opportunities also use "In Progress".
      fetchWithTimeout(`${DIA_URL}/rest/v1/salesforce_activities?nm_type=eq.Opportunity&status=in.(Open,%22In%20Progress%22)&order=activity_date.desc&limit=20&select=id,subject,who_name,what_name,status,activity_date,due_date,priority,description`, {
        headers: { 'apikey': DIA_KEY, 'Authorization': `Bearer ${DIA_KEY}` }
      }, 5000),
      fetchWithTimeout(`${DIA_URL}/rest/v1/salesforce_activities?nm_type=eq.Task&status=in.(Open,%22In%20Progress%22,%22Not%20Started%22)&order=due_date.asc.nullslast&limit=20&select=id,subject,who_name,what_name,status,activity_date,due_date,priority,description`, {
        headers: { 'apikey': DIA_KEY, 'Authorization': `Bearer ${DIA_KEY}` }
      }, 5000)
    ]);
    return {
      deals: dealsRes.ok ? await dealsRes.json() : [],
      leads: leadsRes.ok ? await leadsRes.json() : []
    };
  } catch { return { deals: [], leads: [] }; }
}

// ---------------------------------------------------------------------------
// Strategic priority scoring engine
// ---------------------------------------------------------------------------

export async function buildStrategicPriorities(roleView, myWork, inboxItems, sfActivity, hotContacts, diaPipeline, unassignedWork, syncHealth, workCounts) {
  const today = new Date();
  const weekEnd = new Date(today);
  weekEnd.setDate(today.getDate() + 7);

  const hotContactMap = new Map();
  (hotContacts || []).forEach(c => {
    if (c.email) hotContactMap.set(c.email.toLowerCase(), c);
  });

  const allItems = [];

  for (const item of (inboxItems || [])) {
    const { score, tier } = scoreItem(item, hotContactMap);
    allItems.push({ ...item, _score: score, _tier: tier, _source: 'inbox' });
  }

  for (const item of (myWork || [])) {
    const { score, tier } = scoreItem(item, hotContactMap);
    allItems.push({ ...item, _score: score, _tier: tier, _source: 'work' });
  }

  for (const item of (sfActivity || [])) {
    const { score, tier } = scoreItem(item, hotContactMap);
    if (score >= 30) {
      allItems.push({
        id: item.id,
        title: item.title,
        status: item.metadata?.sf_status || 'open',
        priority: item.metadata?.priority || 'normal',
        due_date: item.metadata?.activity_date || null,
        domain: null,
        type: 'sf_activity',
        metadata: item.metadata,
        _score: score,
        _tier: tier,
        _source: 'salesforce'
      });
    }
  }

  for (const deal of (diaPipeline?.deals || [])) {
    const pseudoItem = {
      title: deal.subject || deal.what_name || '(deal)',
      body: deal.description || '',
      due_date: deal.due_date || deal.activity_date,
      priority: deal.priority === 'High' ? 'high' : 'normal',
      metadata: { sf_who: deal.who_name, sf_what: deal.what_name }
    };
    const { score, tier } = scoreItem(pseudoItem, hotContactMap);
    if (score >= 20) {
      allItems.push({
        id: deal.id,
        title: deal.subject || deal.what_name || '(deal)',
        status: deal.status || 'open',
        priority: pseudoItem.priority,
        due_date: pseudoItem.due_date,
        domain: 'dialysis',
        type: 'sf_deal',
        _score: score + 20,
        _tier: tier === 'urgent' ? 'important' : tier,
        _source: 'pipeline'
      });
    }
  }

  allItems.sort((a, b) => b._score - a._score);

  const strategic = allItems.filter(i => i._tier === 'strategic');
  const important = allItems.filter(i => i._tier === 'important');
  const urgent = allItems.filter(i => i._tier === 'urgent');

  const todayPriorities = [
    ...strategic.slice(0, 3),
    ...important.slice(0, 3),
    ...urgent.slice(0, 4)
  ].slice(0, 7);

  const now = Date.now();
  const touchpointCandidates = (hotContacts || [])
    .filter(c => {
      const lastTouch = Math.max(
        c.last_call_date ? new Date(c.last_call_date).getTime() : 0,
        c.last_email_date ? new Date(c.last_email_date).getTime() : 0,
        c.last_meeting_date ? new Date(c.last_meeting_date).getTime() : 0
      );
      return lastTouch > 0 && (now - lastTouch) > 14 * 86400000;
    })
    .sort((a, b) => (b.engagement_score || 0) - (a.engagement_score || 0))
    .slice(0, 10)
    .map(c => ({
      id: c.unified_id,
      name: c.full_name,
      company: c.company_name,
      score: c.engagement_score,
      days_since_touch: Math.floor((now - Math.max(
        c.last_call_date ? new Date(c.last_call_date).getTime() : 0,
        c.last_email_date ? new Date(c.last_email_date).getTime() : 0,
        c.last_meeting_date ? new Date(c.last_meeting_date).getTime() : 0
      )) / 86400000),
      reason: 'High engagement contact overdue for touchpoint'
    }));

  const weightedCandidates = await Promise.all(
    touchpointCandidates.map(async (contact) => {
      let weight = 1.0;
      try {
        const weightResult = await Promise.race([
          opsQuery('POST', 'rpc/get_contact_recommendation_weight', { p_entity_id: contact.id }),
          new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 500))
        ]);
        if (weightResult.ok && weightResult.data != null) {
          const parsed = typeof weightResult.data === 'number' ? weightResult.data : parseFloat(weightResult.data);
          if (!isNaN(parsed)) weight = parsed;
        }
      } catch { /* timeout or query error */ }

      const recommendation_note = weight === 0.5 ? 'Previously dismissed \u2014 lower priority'
        : weight === 1.5 ? 'High engagement history \u2014 prioritize'
        : '';

      return { ...contact, recommendation_weight: weight, recommendation_note };
    })
  );

  const staleTouchpoints = weightedCandidates
    .sort((a, b) => ((b.days_since_touch || 0) * b.recommendation_weight) - ((a.days_since_touch || 0) * a.recommendation_weight))
    .slice(0, 5);

  if (process.env.TEAMS_COLD_ALERTS_ENABLED === 'true') {
    const goingCold = (hotContacts || [])
      .filter(c => {
        const lastTouch = Math.max(
          c.last_call_date ? new Date(c.last_call_date).getTime() : 0,
          c.last_email_date ? new Date(c.last_email_date).getTime() : 0,
          c.last_meeting_date ? new Date(c.last_meeting_date).getTime() : 0
        );
        const daysSince = lastTouch > 0 ? Math.floor((now - lastTouch) / 86400000) : 0;
        return lastTouch > 0 && daysSince > 60 && (c.engagement_score || 0) > 40;
      })
      .slice(0, 3);

    for (const c of goingCold) {
      const lastTouch = Math.max(
        c.last_call_date ? new Date(c.last_call_date).getTime() : 0,
        c.last_email_date ? new Date(c.last_email_date).getTime() : 0,
        c.last_meeting_date ? new Date(c.last_meeting_date).getTime() : 0
      );
      const daysSince = Math.floor((now - lastTouch) / 86400000);
      const lastTouchDate = new Date(lastTouch).toISOString().split('T')[0];

      sendTeamsAlert({
        title: 'Warm Contact Going Cold',
        summary: `${c.full_name || 'Unknown'} \u2014 ${daysSince} days since last touch`,
        severity: 'high',
        facts: [
          ['Contact', c.full_name || 'Unknown'],
          ['Company', c.company_name || 'Unknown'],
          ['Last Touch', lastTouchDate],
          ['Relationship Score', c.engagement_score || 0],
          ['Active Pursuits', c.total_calls || 0]
        ],
        actions: [{ label: 'View Contact', url: `${process.env.LCC_BASE_URL || ''}/contacts` }]
      }).catch(() => {});
    }
  }

  const overdue = allItems.filter(i => i.due_date && new Date(i.due_date) < today);
  const dueThisWeek = allItems.filter(i => {
    if (!i.due_date) return false;
    const due = new Date(i.due_date);
    return due >= today && due <= weekEnd;
  });

  return {
    today_priorities: todayPriorities
      .map((i) => {
        const title = deriveItemTitle(i);
        if (!title) return null;
        return {
          id: i.id,
          title,
          status: i.status || null,
          priority: i.priority || null,
          due_date: i.due_date || null,
          domain: i.domain || null,
          type: i.type || i.item_type || i.source_type || 'action',
          tier: i._tier,
          score: i._score,
          source: i._source
        };
      })
      .filter(Boolean),
    strategic_count: strategic.length,
    important_count: important.length,
    urgent_count: urgent.length,
    my_overdue: mapPriorityItems(overdue, 5),
    my_due_this_week: mapPriorityItems(dueThisWeek, 5),
    recommended_calls: staleTouchpoints,
    recommended_followups: mapPriorityItems(
      inboxItems.filter(i => {
        const { score } = scoreItem(i, hotContactMap);
        return score >= 20;
      }).slice(0, 5),
      5
    ),
    pipeline_deals: (diaPipeline?.deals || []).slice(0, 5).map(d => ({
      id: d.id,
      title: d.subject || d.what_name,
      contact: d.who_name,
      status: d.status,
      due: d.due_date || d.activity_date,
      domain: 'dialysis'
    })),
    sf_activity_summary: {
      total_7d: (sfActivity || []).length,
      calls: (sfActivity || []).filter(a => a.category === 'call').length,
      emails: (sfActivity || []).filter(a => a.category === 'email').length,
      tasks: (sfActivity || []).filter(a => a.category === 'note').length
    }
  };
}

// ===========================================================================
// Briefing v2 — executive-briefing data fetchers
//
// The v2 email layers market + capital-markets + sector-news content on top
// of the existing Strategic / Urgent / Pipeline sections. These helpers are
// additive: they pull from the daily intel snapshot (cached by the
// briefing-intel-snapshot edge function) and from dia/gov Supabase tables
// for fresh deal intelligence. Each one degrades gracefully — if a data
// source is missing or errors, the corresponding email section renders an
// empty-state placeholder rather than blocking the briefing.
// ===========================================================================

/**
 * Read today's cached intel snapshot (market data, Fed outlook, AI analyst
 * take, sector news, reading list). Written by the briefing-intel-snapshot
 * edge function at 5:30 AM CT.
 *
 * Returns the freshest row matching today's CT date, or null if the cron
 * hasn't landed yet (cold-start morning, manual flow trigger, etc). The
 * renderer treats null as "skip the macro/news sections."
 *
 * @param {string|null} workspaceId
 * @returns {Promise<object|null>}
 */
export async function fetchIntelSnapshot(workspaceId) {
  // CT date — the snapshot row keys on America/Chicago, not UTC, so a 6 AM
  // CT briefing reads today's row even though UTC has rolled over.
  const ctNow = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Chicago' }));
  const ctDate = ctNow.toISOString().slice(0, 10);

  // Prefer the workspace-specific row if present, else the global (null) row.
  // PostgREST's in.() operator treats "null" as a string, not SQL NULL, so we
  // need an or= clause to match the workspace-specific row OR the global row.
  // Order by workspace_id desc (nullslast) so the workspace-specific row wins.
  const wsFilter = workspaceId
    ? `or=(workspace_id.eq.${encodeURIComponent(workspaceId)},workspace_id.is.null)`
    : 'workspace_id=is.null';

  // Resilience: if today's snapshot is missing (cron miss, DB outage, late
  // refresh), fall back to the freshest row from the last 3 days. The
  // renderer surfaces a "Data from MM/DD" tag on stale rows so the broker
  // knows. Without this, an email rendered before 5:30 AM CT — or on a day
  // the cron got swallowed by an OPS outage — drops every macro/news
  // section and ships a half-empty briefing.
  const cutoff = new Date(Date.now() - 3 * 86400000).toISOString().slice(0, 10);
  const path =
    `briefing_intel_snapshot?as_of_date=gte.${cutoff}&${wsFilter}` +
    `&order=as_of_date.desc,workspace_id.desc.nullslast,generated_at.desc&limit=1`;
  const res = await opsQuery('GET', path, undefined, { countMode: 'none' });
  if (!res.ok || !Array.isArray(res.data) || !res.data.length) return null;
  const row = res.data[0];
  // Decorate with staleness info so the renderer can flag old data.
  row._is_today = row.as_of_date === ctDate;
  return row;
}

/**
 * Enrich a list of rows that carry property_id with tenant/city/state pulled
 * from the domain's properties table. Used by listings + sales-comps fetchers
 * so the email can render a meaningful tenant name and location, rather than
 * "(tenant unknown)" / no city. Batches the property fetch into a single
 * id=in.() call per domain. Mutates and returns the rows.
 *
 * Both dia.properties and gov.properties carry `tenant`, `city`, `state`.
 * Gov also has `tenant_agency`; we keep an existing tenant_agency value if
 * the row already had one (e.g. from gov.available_listings.tenant_agency).
 */
async function enrichPropertyContext(rows, domain) {
  if (!Array.isArray(rows) || rows.length === 0) return rows;
  const url = domain === 'dia' ? DIA_URL : GOV_URL;
  const key = domain === 'dia' ? DIA_KEY : GOV_KEY;
  if (!url || !key) return rows;
  const ids = Array.from(new Set(rows.map((r) => r.property_id).filter(Boolean)));
  if (!ids.length) return rows;
  try {
    const r = await fetchWithTimeout(
      `${url}/rest/v1/properties?property_id=in.(${ids.map(encodeURIComponent).join(',')})` +
        `&select=property_id,tenant,city,state,address`,
      { headers: { apikey: key, Authorization: `Bearer ${key}` } },
      4000,
    );
    if (!r.ok) return rows;
    const props = await r.json();
    if (!Array.isArray(props)) return rows;
    const byId = new Map(props.map((p) => [String(p.property_id), p]));
    for (const row of rows) {
      const p = byId.get(String(row.property_id));
      if (!p) continue;
      if (!row.tenant_agency && p.tenant) row.tenant_agency = p.tenant;
      if (!row.tenant) row.tenant = p.tenant || row.tenant || null;
      if (!row.city)   row.city   = p.city  || null;
      if (!row.state)  row.state  = p.state || null;
      if (!row.address) row.address = p.address || null;
    }
  } catch {
    /* leave rows unenriched */
  }
  return rows;
}

/**
 * Recently-closed sales transactions across dia + gov — surfaces comparable
 * deals a broker should be aware of for pricing conversations.
 *
 * @param {number} sinceDays  — lookback window (default 60 days)
 * @param {number} limit      — per-domain row cap (default 8)
 * @returns {Promise<{ dialysis: Array, government: Array }>}
 */
export async function fetchRecentSalesComps(sinceDays = 60, limit = 8) {
  const sinceIso = new Date(Date.now() - sinceDays * 86400000)
    .toISOString().slice(0, 10);
  // dia + gov both use sold_price (not sale_price) and store buyer/seller
  // in *_name columns. property_id is the join key; no tenant col on the
  // sales row itself in dia, so we project an empty placeholder server-side.
  const fields = 'sale_id,property_id,sale_date,sold_price,cap_rate,buyer_name,seller_name';
  const headers = (key) => ({ apikey: key, Authorization: `Bearer ${key}` });

  const calls = [];
  if (DIA_URL && DIA_KEY) {
    calls.push(
      fetchWithTimeout(
        `${DIA_URL}/rest/v1/sales_transactions?sale_date=gte.${sinceIso}` +
          `&order=sale_date.desc&limit=${limit}&select=${fields}`,
        { headers: headers(DIA_KEY) },
        5000,
      ).then((r) => (r.ok ? r.json() : [])).catch(() => []),
    );
  } else {
    calls.push(Promise.resolve([]));
  }
  if (GOV_URL && GOV_KEY) {
    calls.push(
      fetchWithTimeout(
        `${GOV_URL}/rest/v1/sales_transactions?sale_date=gte.${sinceIso}` +
          `&order=sale_date.desc&limit=${limit}&select=${fields}`,
        { headers: headers(GOV_KEY) },
        5000,
      ).then((r) => (r.ok ? r.json() : [])).catch(() => []),
    );
  } else {
    calls.push(Promise.resolve([]));
  }

  const [dia, gov] = await Promise.all(calls);
  // Normalize the renderer's expected shape (sale_price + tenant/city/state).
  // tenant/city/state aren't on the sales row — they're on the linked property,
  // so we enrich via a follow-up batch fetch (enrichPropertyContext).
  const normalize = (rows) => (Array.isArray(rows) ? rows : []).map((r) => ({
    property_id:   r.property_id,
    sale_date:     r.sale_date,
    sale_price:    r.sold_price,
    cap_rate:      r.cap_rate,
    buyer:         r.buyer_name,
    seller:        r.seller_name,
    tenant_agency: null,
    tenant:        null,
    city:          null,
    state:         null,
  }));
  const diaNorm = normalize(dia);
  const govNorm = normalize(gov);
  await Promise.all([
    enrichPropertyContext(diaNorm, 'dia'),
    enrichPropertyContext(govNorm, 'gov'),
  ]);
  return { dialysis: diaNorm, government: govNorm };
}

/**
 * Leases expiring inside a forward window — drives the "Lease Expirations"
 * watchlist. A 90-day default keeps the list short enough to act on without
 * being noisy.
 *
 * @param {number} windowDays  — forward look-ahead (default 90 days)
 * @param {number} limit       — per-domain row cap (default 6)
 * @returns {Promise<{ dialysis: Array, government: Array }>}
 */
export async function fetchUpcomingLeaseExpirations(windowDays = 90, limit = 6) {
  const today = new Date().toISOString().slice(0, 10);
  const horizonIso = new Date(Date.now() + windowDays * 86400000)
    .toISOString().slice(0, 10);
  const headers = (key) => ({ apikey: key, Authorization: `Bearer ${key}` });

  const calls = [];
  if (DIA_URL && DIA_KEY) {
    calls.push(
      fetchWithTimeout(
        `${DIA_URL}/rest/v1/leases?lease_expiration=gte.${today}` +
          `&lease_expiration=lte.${horizonIso}&is_active=eq.true` +
          `&order=lease_expiration.asc&limit=${limit}` +
          `&select=property_id,tenant,lease_expiration,annual_rent,rent_per_sf,leased_area`,
        { headers: headers(DIA_KEY) },
        5000,
      ).then((r) => (r.ok ? r.json() : [])).catch(() => []),
    );
  } else {
    calls.push(Promise.resolve([]));
  }
  if (GOV_URL && GOV_KEY) {
    calls.push(
      fetchWithTimeout(
        `${GOV_URL}/rest/v1/leases?lease_expiration=gte.${today}` +
          `&lease_expiration=lte.${horizonIso}&is_active=eq.true` +
          `&order=lease_expiration.asc&limit=${limit}` +
          `&select=property_id,tenant,tenant_agency,lease_expiration,annual_rent,rent_per_sf,leased_area`,
        { headers: headers(GOV_KEY) },
        5000,
      ).then((r) => (r.ok ? r.json() : [])).catch(() => []),
    );
  } else {
    calls.push(Promise.resolve([]));
  }

  const [dia, gov] = await Promise.all(calls);
  const diaRows = Array.isArray(dia) ? dia : [];
  const govRows = Array.isArray(gov) ? gov : [];
  // Enrich with city/state so the email can render location next to each
  // expiring lease (a 5-day-out DaVita with no city is much less actionable).
  await Promise.all([
    enrichPropertyContext(diaRows, 'dia'),
    enrichPropertyContext(govRows, 'gov'),
  ]);
  return { dialysis: diaRows, government: govRows };
}

/**
 * Newest active listings across dia + gov — "New on Market" alongside the
 * 24h OM intake feed.
 *
 * @param {number} sinceDays — lookback (default 7)
 * @param {number} limit     — per-domain cap (default 5)
 * @returns {Promise<{ dialysis: Array, government: Array }>}
 */
export async function fetchNewActiveListings(sinceDays = 7, limit = 5) {
  const sinceIso = new Date(Date.now() - sinceDays * 86400000)
    .toISOString().slice(0, 10);
  const headers = (key) => ({ apikey: key, Authorization: `Bearer ${key}` });

  // Both DBs use last_price as the current asking — gov has asking_price as
  // a separate column but we COALESCE in the renderer. Cap rate column is
  // current_cap_rate (falls back to cap_rate). No tenant/city/state on the
  // listing row; those come from the joined property.
  const calls = [];
  if (DIA_URL && DIA_KEY) {
    calls.push(
      fetchWithTimeout(
        `${DIA_URL}/rest/v1/available_listings?listing_date=gte.${sinceIso}` +
          `&is_active=eq.true&order=listing_date.desc&limit=${limit}` +
          `&select=listing_id,property_id,listing_date,last_price,initial_price,current_cap_rate,cap_rate,listing_broker,listing_url`,
        { headers: headers(DIA_KEY) },
        5000,
      ).then((r) => (r.ok ? r.json() : [])).catch(() => []),
    );
  } else {
    calls.push(Promise.resolve([]));
  }
  if (GOV_URL && GOV_KEY) {
    calls.push(
      fetchWithTimeout(
        `${GOV_URL}/rest/v1/available_listings?listing_date=gte.${sinceIso}` +
          `&is_active=eq.true&order=listing_date.desc&limit=${limit}` +
          `&select=listing_id,property_id,listing_date,asking_price,last_price,initial_price,current_cap_rate,cap_rate,tenant_agency,listing_broker,listing_url`,
        { headers: headers(GOV_KEY) },
        5000,
      ).then((r) => (r.ok ? r.json() : [])).catch(() => []),
    );
  } else {
    calls.push(Promise.resolve([]));
  }

  const [dia, gov] = await Promise.all(calls);
  // Normalize to {asking_price, cap_rate} for the renderer. tenant/city/state
  // come from the linked property — enrich with a follow-up batch fetch so the
  // email shows the operator name and location instead of "(tenant unknown)".
  const normalize = (rows, isGov) => (Array.isArray(rows) ? rows : []).map((r) => ({
    property_id:    r.property_id,
    listing_date:   r.listing_date,
    asking_price:   isGov ? (r.asking_price ?? r.last_price ?? r.initial_price)
                          : (r.last_price ?? r.initial_price),
    cap_rate:       r.current_cap_rate ?? r.cap_rate,
    tenant_agency:  isGov ? r.tenant_agency : null,
    tenant:         null,
    city:           null,
    state:          null,
    listing_broker: r.listing_broker,
    listing_url:    r.listing_url,
  }));
  const diaNorm = normalize(dia, false);
  const govNorm = normalize(gov, true);
  await Promise.all([
    enrichPropertyContext(diaNorm, 'dia'),
    enrichPropertyContext(govNorm, 'gov'),
  ]);
  return { dialysis: diaNorm, government: govNorm };
}

/**
 * Pipeline value roll-up from open SF opportunities — supports the
 * "Deal Intelligence" callout card. Returns counts grouped by stage.
 *
 * Reads via dia_db salesforce_activities; defensive — returns zeros on
 * any failure.
 *
 * @returns {Promise<{ open_count, total_value, weighted_value, by_stage: Array }>}
 */
export async function fetchPipelineRollup() {
  const zero = { open_count: 0, total_value: 0, weighted_value: 0, by_stage: [] };
  if (!DIA_URL || !DIA_KEY) return zero;
  try {
    // NOTE: is_closed does not exist on dia salesforce_activities — the old
    // filter made PostgREST return 400 and this rollup reported "Pipeline: 0
    // open opportunities" in every briefing (found 2026-06-05). Open pipeline
    // = status Open or In Progress (excludes Not Started bulk-import noise,
    // Completed, Abandoned).
    const r = await fetchWithTimeout(
      `${DIA_URL}/rest/v1/salesforce_activities?nm_type=eq.Opportunity` +
        `&status=in.(Open,%22In%20Progress%22)` +
        `&select=id,status,priority,what_name,description&limit=2000`,
      { headers: { apikey: DIA_KEY, Authorization: `Bearer ${DIA_KEY}` } },
      5000,
    );
    if (!r.ok) return zero;
    const rows = await r.json();
    if (!Array.isArray(rows)) return zero;

    // Stages and amounts aren't in the salesforce_activities projection we
    // currently read; this rolls up by status only. When a richer SF view
    // lands, expand the select to include Amount + StageName.
    const byStage = new Map();
    for (const row of rows) {
      const stage = row.status || 'Unknown';
      byStage.set(stage, (byStage.get(stage) || 0) + 1);
    }
    return {
      open_count: rows.length,
      total_value: 0,        // pending SF Amount field projection
      weighted_value: 0,     // pending SF Probability field projection
      by_stage: Array.from(byStage.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 6)
        .map(([stage, count]) => ({ stage, count })),
    };
  } catch {
    return zero;
  }
}

/**
 * Parse Power Automate-supplied calendar / todo / weather payload from the
 * briefing-email POST body. The flow uses the Outlook + To Do connectors
 * (running under the broker's identity) to fetch today's events and tasks
 * pre-call. We accept whatever shape PA sends and normalize.
 *
 * Expected body shape (lenient; missing keys are OK):
 * {
 *   "today": { "iso_date": "2026-05-23", "weekday": "Saturday" },
 *   "calendar": { "events": [{ start, end, subject, location, attendees, is_all_day }] },
 *   "todo":     { "tasks":  [{ title, due, importance, list_name, completed }] },
 *   "weather":  { "high_f", "low_f", "condition", "location" }
 * }
 *
 * Never throws; bad input → empty arrays.
 *
 * @param {any} body — raw POST body
 * @returns {{ events: Array, tasks: Array, weather: object|null }}
 */
// Coerce a value that should be an array. Accepts:
//   - a real array (returned as-is)
//   - a JSON-stringified array (parsed back into an array)
//   - anything else → returns []
// Why: Power Automate's HTTP body field validates JSON statically and
// rejects naked-array expressions like `"events": @{outputs(...)}` with
// "Enter a valid JSON." Wrapping the expression in quotes (so it becomes
// `"events": "@{outputs(...)}"`) passes validation but PA then stringifies
// the array at substitution time. This coercion lets the briefing flow
// use the string-quoted form without backend changes per flow update.
function coerceArray(value) {
  if (Array.isArray(value)) return value;
  if (typeof value === 'string' && value.trim().startsWith('[')) {
    try {
      const parsed = JSON.parse(value);
      return Array.isArray(parsed) ? parsed : [];
    } catch { /* fall through */ }
  }
  return [];
}

export function normalizePersonalContext(body) {
  const out = { events: [], tasks: [], weather: null };
  if (!body || typeof body !== 'object') return out;

  const events = coerceArray(body.calendar?.events);
  if (events.length) {
    out.events = events
      .map((e) => ({
        start:      e.start || e.startTime || e.start_time || null,
        end:        e.end || e.endTime || e.end_time || null,
        subject:    e.subject || e.title || e.summary || '(busy)',
        location:   e.location?.displayName || e.location || null,
        attendees:  Array.isArray(e.attendees)
                      ? e.attendees.map((a) => a.emailAddress?.name || a.name || a.email || '')
                          .filter(Boolean)
                      : [],
        is_all_day: !!(e.isAllDay || e.is_all_day),
      }))
      .filter((e) => e.subject)
      .sort((a, b) => (a.start || '').localeCompare(b.start || ''))
      .slice(0, 8);
  }

  const tasks = coerceArray(body.todo?.tasks ?? body.tasks);
  if (tasks.length) {
    out.tasks = tasks
      .filter((t) => !t.completed && !t.isCompleted)
      .map((t) => ({
        title:      t.title || t.subject || '(untitled task)',
        due:        t.due || t.dueDateTime?.dateTime || t.due_date || null,
        importance: (t.importance || t.priority || 'normal').toLowerCase(),
        list_name:  t.list_name || t.listName || t.parentList || null,
      }))
      .sort((a, b) => {
        if (a.importance === 'high' && b.importance !== 'high') return -1;
        if (b.importance === 'high' && a.importance !== 'high') return 1;
        return (a.due || '9999').localeCompare(b.due || '9999');
      })
      .slice(0, 6);
  }

  if (body.weather && typeof body.weather === 'object') {
    const w = body.weather;
    out.weather = {
      high_f:    Number.isFinite(+w.high_f) ? Math.round(+w.high_f) : null,
      low_f:     Number.isFinite(+w.low_f) ? Math.round(+w.low_f) : null,
      condition: w.condition || w.summary || null,
      location:  w.location || null,
    };
  }

  return out;
}

// ===========================================================================
// Market-stats RPC (TTM sales volume, cap-rate distribution, on-market count)
//
// Calls the per-domain lcc_briefing_market_stats(p_days) RPC defined in
// migrations/{dialysis,government}_db/20260523_briefing_market_stats.sql.
// Both RPCs return the same jsonb shape so callers can render either
// domain through the same tile group.
//
// Returns the parsed object on success, or null on any failure.
// ===========================================================================

async function rpcDomain(domain, fnName, body, timeoutMs = 5000) {
  const url = domain === 'dia' ? DIA_URL : GOV_URL;
  const key = domain === 'dia' ? DIA_KEY : GOV_KEY;
  if (!url || !key) return null;
  try {
    const r = await fetchWithTimeout(
      `${url}/rest/v1/rpc/${fnName}`,
      {
        method:  'POST',
        headers: {
          apikey:        key,
          Authorization: `Bearer ${key}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body || {}),
      },
      timeoutMs,
    );
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  }
}

/**
 * Pull TTM market stats for both verticals. Resolves to:
 *   { dialysis: stats|null, government: stats|null }
 * where each stats object is { window_days, ttm_volume, ttm_count, avg_cap,
 * median_cap, q1_cap, q3_cap, on_market_count, on_market_volume }.
 */
export async function fetchMarketStats(days = 365) {
  const [dia, gov] = await Promise.all([
    rpcDomain('dia', 'lcc_briefing_market_stats', { p_days: days }),
    rpcDomain('gov', 'lcc_briefing_market_stats', { p_days: days }),
  ]);
  return { dialysis: dia, government: gov };
}

/**
 * Research progress: per-domain counts (comps + listings added, property
 * coverage) plus workspace-wide engagement metrics (touchpoints, prospects).
 *
 * Returns:
 *   {
 *     window_days,
 *     workspace: { touchpoints_this_week, prospects_added_this_week,
 *                  total_entities, entities_with_recent_activity,
 *                  pct_accounts_prospected },
 *     dialysis:  { comps_added, listings_added, props_total,
 *                  props_with_owner, props_with_developer,
 *                  pct_owner, pct_developer },
 *     government: { ...same... },
 *   }
 */
/**
 * Count Salesforce activities in the trailing window directly from the
 * domain DBs. Fallback feed for the Touchpoints tile: LCC's activity_events
 * has no call/email/meeting rows yet (the SF → activity_events mirror is not
 * built), so the workspace RPC reports 0 even in weeks with hundreds of
 * logged SF activities (2026-06-05 audit). Future-dated SF tasks are
 * excluded — activity_date can be a scheduled date.
 */
async function fetchSfTouchpoints(days = 7) {
  const today = new Date().toISOString().slice(0, 10);
  const since = new Date(Date.now() - days * 86400000).toISOString().slice(0, 10);
  const countOf = async (url, key, path) => {
    if (!url || !key) return 0;
    try {
      const r = await fetchWithTimeout(`${url}/rest/v1/${path}`, {
        method: 'HEAD',
        headers: { apikey: key, Authorization: `Bearer ${key}`, Prefer: 'count=exact' },
      }, 5000);
      const range = r.headers.get('content-range') || '';
      const m = range.match(/\/(\d+)/);
      return m ? parseInt(m[1], 10) : 0;
    } catch { return 0; }
  };
  const [govN, diaN] = await Promise.all([
    countOf(GOV_URL, GOV_KEY,
      `sf_activities?activity_date=gte.${since}&activity_date=lte.${today}&select=sf_task_id&limit=1`),
    countOf(DIA_URL, DIA_KEY,
      `salesforce_activities?activity_date=gte.${since}&activity_date=lte.${today}&select=activity_id&limit=1`),
  ]);
  return (govN || 0) + (diaN || 0);
}

export async function fetchResearchProgress(workspaceId, days = 7) {
  const [wsRow, dia, gov, sfTouchpoints] = await Promise.all([
    workspaceId
      ? opsQuery(
          'POST',
          'rpc/lcc_briefing_research_progress',
          { p_workspace: workspaceId, p_days: days },
        ).then((r) => (r.ok ? r.data : null)).catch(() => null)
      : Promise.resolve(null),
    rpcDomain('dia', 'lcc_briefing_research_counts', { p_days: days }),
    rpcDomain('gov', 'lcc_briefing_research_counts', { p_days: days }),
    fetchSfTouchpoints(days).catch(() => 0),
  ]);

  const wrap = (row) => {
    if (!row) return null;
    const total = Number(row.props_total) || 0;
    return {
      comps_added:          Number(row.comps_added) || 0,
      listings_added:       Number(row.listings_added) || 0,
      props_total:          total,
      props_with_owner:     Number(row.props_with_owner) || 0,
      props_with_developer: Number(row.props_with_developer) || 0,
      pct_owner:            total ? (Number(row.props_with_owner) || 0) / total : null,
      pct_developer:        total ? (Number(row.props_with_developer) || 0) / total : null,
    };
  };

  let workspace = null;
  if (wsRow) {
    const totalEnt = Number(wsRow.total_entities) || 0;
    const withAct  = Number(wsRow.entities_with_recent_activity) || 0;
    workspace = {
      touchpoints_this_week:        Number(wsRow.touchpoints_this_week) || 0,
      sf_touchpoints:               Number(sfTouchpoints) || 0,
      prospects_added_this_week:    Number(wsRow.prospects_added_this_week) || 0,
      opportunities_open:           Number(wsRow.opportunities_open) || 0,
      opportunities_opened_this_week: Number(wsRow.opportunities_opened_this_week) || 0,
      total_entities:               totalEnt,
      entities_with_recent_activity: withAct,
      pct_accounts_prospected:      totalEnt ? withAct / totalEnt : null,
    };
  }

  return {
    window_days: days,
    workspace,
    dialysis:   wrap(dia),
    government: wrap(gov),
  };
}
